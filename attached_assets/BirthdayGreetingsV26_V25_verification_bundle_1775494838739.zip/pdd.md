## 1. Executive Summary
The “birthday greetingsV26” project automates a daily personal workflow: at 8:00am, birthdays are checked in Google Calendar and a warm, funny, lightly sarcastic birthday email is sent from the user’s Gmail account. The current manual approach is simple but prone to missed sends when the user forgets. The to-be solution will run fully autonomously on unattended robots via UiPath Orchestrator Triggers, retrieve today’s birthday events from the built-in Google “Birthdays” calendar feed, resolve the recipient’s email address via Google Contacts (preferring “Personal” when multiple emails exist), generate a personalized message using UiPath native GenAI capabilities (no OpenAI/Azure OpenAI usage), send via the Gmail Integration Service connector for **ninemush@gmail.com**, and record a sent-log to prevent duplicates within the same day.

## 2. Process Scope
This automation is in scope to execute once per day at 8:00am and complete all birthday greetings for that same calendar date. It reads birthday events from the built-in Google “Birthdays” calendar feed (displayed as “Birthdays”), where each event title contains only the person’s full name. It then performs an exact-name lookup in Google Contacts to find a recipient email labeled “Personal” or “Home,” prioritizing “Personal.” If no valid email is found, the automation skips that person without further action.

The email is sent exclusively from the Gmail account connected in UiPath Integration Service as **Gmail – ninemush@gmail.com**. The content is AI-generated using UiPath native capabilities (UiPath GenAI Activities / Agents) and follows an approved default style specification (warm, funny, lightly sarcastic; no emojis; one short subject line; 40–90 words). Photo usage (e.g., Google Photos) and any relationship-based personalization are explicitly out of scope for this iteration.

## 3. As-Is Process Description

![As-Is Process Map](/api/ideas/fcbe5f6d-60a1-45f7-8c96-5df24f1173b0/process-map/image?viewType=as-is&v=1775217506353)
The current (approved) process begins with a daily manual reminder at 8:00am to check for birthdays (As-Is Step 1.0). The user opens Google Calendar and navigates to the “Birthdays” calendar (Step 2.0), then determines whether there are any birthday events occurring that day (Step 3.0). If there are no birthday events, the user takes no action and the process ends (Step 4.0). There is no “forgot scenario” when there are no birthdays; doing nothing is the correct outcome.

When birthdays exist, the user iterates through each birthday event and notes the full name from the calendar entry (Step 4.1). For each name, the user searches Google Contacts to locate the person (Step 5.0) and checks whether a personal/home email address is available (Step 6.0). If no email is found, the user skips that person and does nothing further (Step 7.0). If multiple email addresses exist, the user chooses the personal email (Step 8.0).

The user then drafts a personal birthday message in their voice (Step 9.0)—warm, funny, sarcastic—and sends the birthday email from Gmail (Step 10.0). The user repeats these actions for all birthday events (Steps 11.0 onward/looping steps in the approved map) until all greetings are completed and the process ends (Step 12.0 / end states).

## 4. To-Be Process Description

![To-Be Process Map](/api/ideas/fcbe5f6d-60a1-45f7-8c96-5df24f1173b0/process-map/image?viewType=to-be&v=1775217506353)
In the automated future state, UiPath Orchestrator initiates an unattended run daily at 8:00am (To-Be Step 1.0). The workflow retrieves today’s birthday events specifically from the built-in Google “Birthdays” calendar feed using **Google Calendar via UiPath GSuite Activities** (Step 2.0). The process evaluates whether any birthdays exist today (Step 3.0). If none exist, the job ends cleanly with no further action (Step 4.0).

If birthdays are present, the workflow processes each event in a loop. For each event, it normalizes the full name from the event title (Step 4.1) and performs an exact-match lookup in Google Contacts using **Google Contacts via UiPath GSuite Activities** (Step 5.0). The automation then checks whether an email labeled Personal/Home exists (Step 6.0). If no suitable email is found, the workflow skips this person (Step 7.0) and returns to the loop for the next birthday event (loop steps).

When an email is available, the workflow deterministically selects the recipient address, preferring “Personal” over “Home” (Step 8.0). Before generating or sending anything, it executes a deduplication check against a persistent sent-log stored in **UiPath Data Service / Data Fabric** to ensure it has not already sent a birthday greeting for this person on the same day (Step 9.0). If the log indicates a send already occurred, the automation skips the duplicate (Step 10.0) and continues to the next event.

If a send has not yet occurred, the workflow generates a subject and body using **UiPath native GenAI capabilities** (Step 10.1 “Generate Birthday Email Draft (Your Voice)”). The generation is guided by the approved default style spec: warm + funny + light sarcasm, 40–90 words, no emojis, one short subject line, and no sensitive content. The automation performs an automated safety/completeness validation to ensure both subject and body are present and the content is appropriate for sending (Step 11.0). If the draft fails validation (edge cases only), the workflow creates a human review task in **UiPath Action Center** (Step 12.0), waits for approved/edited text (Step 12.1), and then proceeds.

The automation sends the email via **Integration Service – Gmail connector using the “ninemush@gmail.com” connection** (Step 13.0 for direct send, Step 14.0 post-review send in the edge-case path). After sending, it records a sent-log entry containing at minimum the full name, selected email address, send date, and Gmail messageId in **UiPath Data Service / Data Fabric** (Steps 15.0 / 16.0 depending on path). The workflow continues looping until no birthday events remain (Steps 17.0 onward), then ends with “Birthday Batch Completed End” (Step 20.0). Same-day sending is allowed: if the job runs late or is re-run later the same day, the deduplication check prevents repeated sends while still allowing completion within the same calendar date.

## 5. Pain Points and Inefficiencies
The primary pain point is reliability: the manual process depends on a human remembering to check the calendar at 8:00am, and missed days translate directly into missed greetings. The current workflow also requires repetitive effort—opening the calendar, copying names, searching contacts, choosing the correct email label, drafting content, and sending—repeated for every birthday event. Variability in event formatting (all-day vs timed events) and the possibility of multiple email addresses per contact introduce small but frequent decision points, which add friction and increase the chance of inconsistencies. Finally, without a structured “sent log,” it is difficult to prevent duplicate sends if the process is repeated or rechecked.

## 6. Automation Opportunity Assessment
This process is a strong candidate for a hybrid automation pattern: deterministic system steps (calendar retrieval, contact lookup, email selection, sending, logging) are best handled through workflow-based RPA/integration activities, while the email content creation benefits from generative AI. The automation will run fully unattended using Orchestrator scheduling and will eliminate the “forgetting” failure mode. The deduplication mechanism adds operational robustness by preventing accidental multiple sends on the same day.

From a platform perspective, the automation can leverage:
- **Orchestrator Triggers** for the daily 8:00am run and reliable unattended execution.
- **UiPath GSuite Activities** to access the built-in Google “Birthdays” calendar and Google Contacts (since Google Calendar is not listed as an active Integration Service connection here).
- **Integration Service – Gmail (ninemush@gmail.com)** to send emails through the pre-existing connector, avoiding UI automation and improving stability.
- **UiPath GenAI Activities / Agents** for native message generation (explicitly not using OpenAI/Azure OpenAI).
- **Data Service / Data Fabric** to store a sent-log for same-day deduplication and traceability.
- **Action Center** for exceptional cases where generated content fails validation, while still keeping the standard path fully autonomous.

[AUTOMATION_TYPE: HYBRID] (Deterministic workflow + native GenAI generation, with Action Center only for edge cases.)

## 7. Assumptions and Exceptions
This design assumes the birthday source is the built-in Google “Birthdays” calendar feed and that each relevant event’s title contains the recipient’s full name in a form that matches exactly to a Google Contact. The process assumes recipient emails are stored in Google Contacts and labeled as “Personal” or “Home,” and that “Personal” should be selected when multiple addresses exist. If no email address is found (or no exact contact match exists), the automation will take no action for that person and will not attempt alternative matching.

The automation assumes message generation can be guided sufficiently by a default style spec (warm, funny, lightly sarcastic; no emojis; 40–90 words; one short subject). It also assumes that “same day” is the only timing requirement; greetings can be sent later the same day if the run is delayed. Duplicate send prevention is implemented at the “same-day per person” level; the system will skip if already sent that day, even if the workflow is re-run.

Exceptions include: (a) contact lookup returns multiple contacts with the same exact full name; (b) no labeled “Personal”/“Home” email exists; (c) GenAI output fails basic checks (missing subject/body or inappropriate content). In (b), the person is skipped. In (c) and selected (a) scenarios, the workflow will create an Action Center item for human resolution, after which it can proceed to send and log.

## 8. Data and System Requirements
The automation requires authenticated access to Google Calendar and Google Contacts via **UiPath GSuite Activities**, configured under a service identity capable of reading the built-in “Birthdays” calendar feed and the Contacts directory. It requires the **Integration Service Gmail connector** configured as **“ninemush@gmail.com”** to send outbound emails. No Google Drive usage is permitted in this version, and no Slack/Teams/Twilio integrations will be used.

A persistent sent-log must be available to support deduplication and auditability. This will be implemented using **UiPath Data Service / Data Fabric**, with a simple entity schema including at minimum: FullName (string), RecipientEmail (string), SendDate (date), MessageId (string), and optionally CalendarEventId (string) and RunId (string) for traceability. Orchestrator Assets should store configuration values such as: the calendar identifier for the built-in “Birthdays” feed, the default email style spec, and any runtime parameters (e.g., retry policy).

The solution must be designed for **unattended execution only** (11 unattended robots available) with no user interaction. Orchestrator scheduling triggers the daily job at 8:00am. Action Center is permitted only for rare exceptions; the standard flow remains fully autonomous end-to-end.