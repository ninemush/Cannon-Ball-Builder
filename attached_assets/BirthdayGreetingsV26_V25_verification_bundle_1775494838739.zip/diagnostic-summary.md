# Diagnostic Summary

## Run Metadata
- **Run ID:** f72fd2d1-ba45-4ad0-95dc-cbda63df50bd
- **Idea ID:** fcbe5f6d-60a1-45f7-8c96-5df24f1173b0
- **Status:** completed_with_warnings
- **Generation Mode:** baseline_openable
- **Triggered By:** chat
- **Created At:** Mon Apr 06 2026 16:54:27 GMT+0000 (Coordinated Universal Time)
- **Completed At:** Mon Apr 06 2026 16:58:32 GMT+0000 (Coordinated Universal Time)
- **Duration:** 244.9s

## Stage Timing

| Stage | Status | Duration (ms) |
|-------|--------|--------------|
| sdd_validation | succeeded | 65 |
| pipeline_sdd_validation | succeeded | 62 |
| spec_generation | succeeded | 235380 |
| spec_context_loading | succeeded | 6 |
| spec_prompt_assembly | succeeded | 2 |
| pre_complexity_estimation | succeeded | 1 |
| spec_scaffold | succeeded | 41758 |
| workflow_budget_check | succeeded | 0 |
| spec_merge | succeeded | 0 |
| spec_handoff | succeeded | 1 |
| build_pipeline | succeeded | 9370 |
| pipeline_build_pipeline | succeeded | 9371 |
| pipeline_decomposition | succeeded | 2 |
| pipeline_pre_complexity_estimation | succeeded | 0 |
| pipeline_workflow_budget_check | succeeded | 0 |
| pipeline_complexity_classification | succeeded | 0 |
| pipeline_xaml_emission | succeeded | 2770 |
| pipeline_xaml_emission_fallback | degraded | 0 |
| pipeline_xaml_emission_fallback | degraded | 0 |
| pipeline_xaml_emission_fallback | degraded | 0 |
| pipeline_xaml_emission_fallback | degraded | 0 |
| pipeline_xaml_emission_fallback | degraded | 0 |
| pipeline_compliance_normalization | succeeded | 27 |
| pipeline_validation | succeeded | 222 |
| pipeline_packaging_dhg | succeeded | 0 |
| pipeline_final_artifact_validation | succeeded | 386 |
| pipeline_packaging_dhg_guide | succeeded | 57 |
| pipeline_structural-deduplication_fallback | degraded | 0 |
| pipeline_dependency-crosscheck_fallback | degraded | 0 |
| pipeline_post-assembly-validation_fallback | degraded | 0 |
| pipeline_post-assembly-validation_fallback | degraded | 0 |
| pipeline_post-assembly-validation_fallback | degraded | 0 |
| pipeline_remediating_fallback | degraded | 0 |
| pipeline_complete | succeeded | 0 |

## Deterministic Transforms

| Transform Type | Count |
|---------------|-------|
| compliance_normalization | 12 |
| activity_policy_filter | 6 |
| workflow_analyzer_autofix | 6 |
| expression_lint | 4 |
| required_property_enforcement | 2 |

## Quality Gate Summary

- **Passed:** false
- **Total Errors:** 10
- **Total Warnings:** 33
- **Completeness:** functional

## Meta-Validation Summary

- **Engaged:** true
- **Mode:** Always
- **Corrections Applied:** 0
- **Corrections Skipped:** 1
- **Corrections Failed:** 1
- **Confidence Score:** 0.35294117647058826
- **Duration:** 57ms

## Remediations

- {"level":"validation-finding","file":"HandleHumanReview.xaml","remediationCode":"STUB_ACTIVITY_UNKNOWN","reason":"Line 257: Adjacent identifiers \"timed out(\" — possible missing operator or comma in expression: {&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;\\&quot;Actio...","classifiedCheck":"EXPRESSION_SYNTAX_UNFIXABLE","developerAction":"Manually implement activity in HandleHumanReview.xaml — estimated 15 min","estimatedEffortMinutes":15}
- {"level":"validation-finding","file":"Finalize.xaml","remediationCode":"STUB_ACTIVITY_UNKNOWN","reason":"Line 180: String.Format() expects 2-10 argument(s) but got 12 in expression: {&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;String.Forma...","classifiedCheck":"EXPRESSION_SYNTAX_UNFIXABLE","developerAction":"Manually implement activity in Finalize.xaml — estimated 15 min","estimatedEffortMinutes":15}
- {"level":"validation-finding","file":"HandleHumanReview.xaml","remediationCode":"STUB_ACTIVITY_UNKNOWN","reason":"Line 262: ugs:GmailSendMessage is missing required property \"Body\"","classifiedCheck":"MISSING_REQUIRED_ACTIVITY_PROPERTY","developerAction":"Manually implement activity in HandleHumanReview.xaml — estimated 15 min","estimatedEffortMinutes":15}
- {"level":"validation-finding","file":"Finalize.xaml","remediationCode":"STUB_ACTIVITY_UNKNOWN","reason":"Line 185: ugs:GmailSendMessage is missing required property \"Body\"","classifiedCheck":"MISSING_REQUIRED_ACTIVITY_PROPERTY","developerAction":"Manually implement activity in Finalize.xaml — estimated 15 min","estimatedEffortMinutes":15}
- {"level":"workflow","file":"Finalize.xaml","remediationCode":"STUB_WORKFLOW_BLOCKING","reason":"Final validation: XAML well-formedness violations — replaced with stub. Details: [xml-wellformedness] XML parse error at line 180, col 187 (code: InvalidChar): char '&' is not expected.","classifiedCheck":"xml-wellformedness","developerAction":"Fix XML structure in Finalize.xaml — [xml-wellformedness] XML parse error at line 180, col 187 (code: InvalidChar): char '&' is not expected.","estimatedEffortMinutes":15}
- {"level":"activity","file":"","remediationCode":"POST_ASSEMBLY_REPAIR","reason":"[MISSING_REQUIRED_PROPERTY_DEFECT] ugs:GmailSendMessage.Body has no valid source binding and no contract-valid fallback — structured defect, property left absent","classifiedCheck":"post-assembly-repair","developerAction":"ugs:GmailSendMessage.Body has no valid source binding and no contract-valid fallback — structured defect, property left absent","estimatedEffortMinutes":5}
- {"level":"activity","file":"","remediationCode":"POST_ASSEMBLY_REPAIR","reason":"[MISSING_REQUIRED_PROPERTY_DEFECT] ugs:GmailSendMessage.Body has no valid source binding and no contract-valid fallback — structured defect, property left absent","classifiedCheck":"post-assembly-repair","developerAction":"ugs:GmailSendMessage.Body has no valid source binding and no contract-valid fallback — structured defect, property left absent","estimatedEffortMinutes":5}
- {"level":"workflow","file":"Main.xaml","remediationCode":"STUB_WORKFLOW_BLOCKING","reason":"Pre-archive assertion: object_payload_in_target_value_slot — Object payload in target/value slot: <Assign.To><OutArgument x:TypeArguments=\"x:String\">Nothing</OutArgument></Assign.To>\n              <Assign.Value><InArgu","classifiedCheck":"pre-archive-canonicalization","developerAction":"Resolve object_payload_in_target_value_slot in Main.xaml","estimatedEffortMinutes":10}
- {"level":"workflow","file":"GetBirthdays.xaml","remediationCode":"STUB_WORKFLOW_BLOCKING","reason":"Pre-archive assertion: object_payload_in_target_value_slot — Object payload in target/value slot: <Assign.To><OutArgument x:TypeArguments=\"x:String\">Nothing</OutArgument></Assign.To>\n              <Assign.Value><InArgu","classifiedCheck":"pre-archive-canonicalization","developerAction":"Resolve object_payload_in_target_value_slot in GetBirthdays.xaml","estimatedEffortMinutes":10}
- {"level":"workflow","file":"ProcessBirthday.xaml","remediationCode":"STUB_WORKFLOW_BLOCKING","reason":"Pre-archive assertion: object_payload_in_target_value_slot — Object payload in target/value slot: <Assign.To><OutArgument x:TypeArguments=\"x:String\">Nothing</OutArgument></Assign.To>\n              <Assign.Value><InArgu","classifiedCheck":"pre-archive-canonicalization","developerAction":"Resolve object_payload_in_target_value_slot in ProcessBirthday.xaml","estimatedEffortMinutes":10}
- {"level":"workflow","file":"GenerateAndValidateDraft.xaml","remediationCode":"STUB_WORKFLOW_BLOCKING","reason":"Pre-archive assertion: object_payload_in_target_value_slot — Object payload in target/value slot: <Assign.To><OutArgument x:TypeArguments=\"x:String\">Nothing</OutArgument></Assign.To>\n              <Assign.Value><InArgu","classifiedCheck":"pre-archive-canonicalization","developerAction":"Resolve object_payload_in_target_value_slot in GenerateAndValidateDraft.xaml","estimatedEffortMinutes":10}
- {"level":"workflow","file":"HandleHumanReview.xaml","remediationCode":"STUB_WORKFLOW_BLOCKING","reason":"Pre-archive assertion: object_payload_in_target_value_slot — Object payload in target/value slot: <Assign.To><OutArgument x:TypeArguments=\"x:String\">Nothing</OutArgument></Assign.To>\n              <Assign.Value><InArgu","classifiedCheck":"pre-archive-canonicalization","developerAction":"Resolve object_payload_in_target_value_slot in HandleHumanReview.xaml","estimatedEffortMinutes":10}
- {"level":"workflow","file":"InitAllSettings.xaml","remediationCode":"STUB_WORKFLOW_BLOCKING","reason":"Pre-archive assertion: malformed_attribute_quoting — Malformed attribute quoting detected: AssetName=\"[&quot;BGV26_GSuite_ServiceAccount_Credential&quot;]","classifiedCheck":"pre-archive-canonicalization","developerAction":"Resolve malformed_attribute_quoting in InitAllSettings.xaml","estimatedEffortMinutes":10}

## Auto-Repairs

- {"repairCode":"REPAIR_GENERIC","file":"Main.xaml","description":"Catalog (fallback): Moved ui:GetAsset.Value from attribute to child-element in Main.xaml"}
- {"repairCode":"REPAIR_GENERIC","file":"Main.xaml","description":"Catalog (fallback): Moved ui:GetAsset.Value from attribute to child-element in Main.xaml"}
- {"repairCode":"REPAIR_GENERIC","file":"Main.xaml","description":"Catalog (fallback): Moved ui:GetAsset.Value from attribute to child-element in Main.xaml"}
- {"repairCode":"REPAIR_GENERIC","file":"Main.xaml","description":"Catalog (fallback): Moved ui:GetAsset.Value from attribute to child-element in Main.xaml"}
- {"repairCode":"REPAIR_GENERIC","file":"Main.xaml","description":"Catalog (fallback): Moved ui:GetAsset.Value from attribute to child-element in Main.xaml"}
- {"repairCode":"REPAIR_GENERIC","file":"Main.xaml","description":"Catalog (fallback): Moved ui:GetAsset.Value from attribute to child-element in Main.xaml"}
- {"repairCode":"REPAIR_GENERIC","file":"Main.xaml","description":"Catalog (fallback): Moved ui:GetAsset.Value from attribute to child-element in Main.xaml"}
- {"repairCode":"REPAIR_GENERIC","file":"Main.xaml","description":"Catalog (fallback): Moved ui:GetAsset.Value from attribute to child-element in Main.xaml"}
- {"repairCode":"REPAIR_GENERIC","file":"Main.xaml","description":"Catalog (fallback): Moved uds:CreateEntityRecord.EntityObject from attribute to child-element in Main.xaml"}
- {"repairCode":"REPAIR_GENERIC","file":"Main.xaml","description":"Catalog (fallback): Moved ForEach.Values from attribute to child-element in Main.xaml"}
