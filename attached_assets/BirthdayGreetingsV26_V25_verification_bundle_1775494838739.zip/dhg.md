# Developer Handoff Guide

**Project:** BirthdayGreetingsV26
**Generated:** 2026-04-06
**Generation Mode:** Baseline Openable (minimal, deterministic)
**Deployment Readiness:** Mostly Ready (68%)

**7 workflows: 0 fully generated, 0 with handoff blocks, 7 workflow-level stubs**
**Total Estimated Effort: ~145 minutes (2.4 hours)**
**Remediations:** 13 total (0 property, 2 activity, 0 sequence, 0 structural-leaf, 7 workflow)
**Auto-Repairs:** 10
**Quality Warnings:** 68

---

### Per-Workflow Preservation Summary

| # | Workflow | Tier | Business Steps (SDD) | Preserved | Degraded (Handoff) | Manual | Bind Points |
|---|----------|------|-------------|-----------|-------------------|--------|-------------|
| 1 | `Main.xaml` | Stub | 4 | 0 | 0 | 4 | 0 |
| 2 | `GetBirthdays.xaml` | Stub | 4 | 0 | 0 | 4 | 0 |
| 3 | `ProcessBirthday.xaml` | Stub | 4 | 0 | 0 | 4 | 0 |
| 4 | `GenerateAndValidateDraft.xaml` | Stub | 4 | 0 | 0 | 4 | 0 |
| 5 | `HandleHumanReview.xaml` | Stub | 4 | 0 | 0 | 4 | 0 |
| 6 | `Finalize.xaml` | Stub | 4 | 0 | 0 | 4 | 0 |
| 7 | `InitAllSettings.xaml` | Stub | 4 | 0 | 0 | 4 | 0 |

## 1. Generated Logic (ready to use)

Generated XAML that is Studio-openable and does not contain handoff blocks or workflow-level stubs. May include auto-resolved property remediations or placeholders for fine-tuning.

No workflows were generated without handoff blocks or stubs.

### AI-Resolved with Smart Defaults (10)

The following issue(s) were automatically corrected during the build pipeline. **No developer action required.**

| # | Code | File | Description | Est. Minutes Saved |
|---|------|------|-------------|-------------------|
| 1 | `REPAIR_GENERIC` | `Main.xaml` | Catalog (fallback): Moved ui:GetAsset.Value from attribute to child-element in Main.xaml | undefined |
| 2 | `REPAIR_GENERIC` | `Main.xaml` | Catalog (fallback): Moved ui:GetAsset.Value from attribute to child-element in Main.xaml | undefined |
| 3 | `REPAIR_GENERIC` | `Main.xaml` | Catalog (fallback): Moved ui:GetAsset.Value from attribute to child-element in Main.xaml | undefined |
| 4 | `REPAIR_GENERIC` | `Main.xaml` | Catalog (fallback): Moved ui:GetAsset.Value from attribute to child-element in Main.xaml | undefined |
| 5 | `REPAIR_GENERIC` | `Main.xaml` | Catalog (fallback): Moved ui:GetAsset.Value from attribute to child-element in Main.xaml | undefined |
| 6 | `REPAIR_GENERIC` | `Main.xaml` | Catalog (fallback): Moved ui:GetAsset.Value from attribute to child-element in Main.xaml | undefined |
| 7 | `REPAIR_GENERIC` | `Main.xaml` | Catalog (fallback): Moved ui:GetAsset.Value from attribute to child-element in Main.xaml | undefined |
| 8 | `REPAIR_GENERIC` | `Main.xaml` | Catalog (fallback): Moved ui:GetAsset.Value from attribute to child-element in Main.xaml | undefined |
| 9 | `REPAIR_GENERIC` | `Main.xaml` | Catalog (fallback): Moved uds:CreateEntityRecord.EntityObject from attribute to child-element in ... | undefined |
| 10 | `REPAIR_GENERIC` | `Main.xaml` | Catalog (fallback): Moved ForEach.Values from attribute to child-element in Main.xaml | undefined |

### Studio Compatibility

| # | Workflow | Compatibility | Failure Category | Blockers |
|---|----------|--------------|-----------------|----------|
| 1 | `Main.xaml` | Studio-openable | — | — |
| 2 | `GetBirthdays.xaml` | Studio-openable | — | — |
| 3 | `ProcessBirthday.xaml` | Studio-openable | — | — |
| 4 | `GenerateAndValidateDraft.xaml` | Studio-openable | — | — |
| 5 | `HandleHumanReview.xaml` | Studio-openable | — | — |
| 6 | `Finalize.xaml` | Studio-openable | — | — |
| 7 | `InitAllSettings.xaml` | Studio-openable | — | — |

**Summary:** 7 Studio-loadable, 0 with warnings, 0 not Studio-loadable

## 2. Handoff Blocks (business logic preserved, implementation required)

Blocks where business logic is preserved as documentation but implementation requires manual Studio work. Each entry includes the workflow file, block type, business description from the SDD (when available), expected inputs/outputs, and the developer action required.

**2 handoff block(s) requiring manual implementation**

#### 1. `` — — (activity)

- **Workflow File:** ``
- **Block Type:** activity
- **Business Description (SDD):** —
- **Business Rule:** —
- **Expected Inputs:** —
- **Expected Outputs:** —
- **Contained Activities:** —
- **Remediation Code:** `POST_ASSEMBLY_REPAIR`
- **Developer Action:** ugs:GmailSendMessage.Body has no valid source binding and no contract-valid fallback — structured defect, property left absent
- **Estimated Effort:** 5 minutes

#### 2. `` — — (activity)

- **Workflow File:** ``
- **Block Type:** activity
- **Business Description (SDD):** —
- **Business Rule:** —
- **Expected Inputs:** —
- **Expected Outputs:** —
- **Contained Activities:** —
- **Remediation Code:** `POST_ASSEMBLY_REPAIR`
- **Developer Action:** ugs:GmailSendMessage.Body has no valid source binding and no contract-valid fallback — structured defect, property left absent
- **Estimated Effort:** 5 minutes

## 3. Manual Work Remaining

Consolidated developer TODO list organized by workflow, with estimated effort per item.

**81 items remaining — ~825 minutes (13.8 hours) total estimated effort**

### Finalize.xaml (3 items, ~45 min)

| # | Priority | Category | Description | Developer Action | Est. Minutes |
|---|----------|----------|-------------|-----------------|-------------|
| 1 | High | Workflow Stub | Entire workflow `Finalize.xaml` replaced with Studio-openable stub | Fix XML structure in Finalize.xaml — [xml-wellformedness] XML parse error at ... | 15 |
| 2 | Low | Validation Finding | Quality gate finding: `EXPRESSION_SYNTAX_UNFIXABLE` | Manually implement activity in Finalize.xaml — estimated 15 min | 15 |
| 3 | Low | Validation Finding | Quality gate finding: `MISSING_REQUIRED_ACTIVITY_PROPERTY` | Manually implement activity in Finalize.xaml — estimated 15 min | 15 |

### GenerateAndValidateDraft.xaml (11 items, ~110 min)

| # | Priority | Category | Description | Developer Action | Est. Minutes |
|---|----------|----------|-------------|-----------------|-------------|
| 4 | High | Workflow Stub | Entire workflow `GenerateAndValidateDraft.xaml` replaced with Studio-openable... | Resolve object_payload_in_target_value_slot in GenerateAndValidateDraft.xaml | 10 |
| 5 | Low | Implementation Required | Contains 1 placeholder value(s) matching "\bPLACEHOLDER\b" [Developer Impleme... | Implement in Studio | 10 |
| 6 | Low | Quality Warning | hardcoded-retry-count: Line 122: retry count hardcoded as 3 — consider extern... | Review and address | 10 |
| 7 | Low | Quality Warning | hardcoded-retry-interval: Line 79: retry interval hardcoded as "{&quot;type&q... | Review and address | 10 |
| 8 | Low | Quality Warning | hardcoded-retry-interval: Line 122: retry interval hardcoded as "00:00:05" — ... | Review and address | 10 |
| 9 | Low | Quality Warning | EXPRESSION_SYNTAX: Line 73: C# 'true' should be VB.NET 'True' in expression: ... | Review and address | 10 |
| 10 | Low | Quality Warning | EXPRESSION_SYNTAX: Line 178: C# 'null' should be VB.NET 'Nothing' in expressi... | Review and address | 10 |
| 11 | Low | Quality Warning | COMPLEX_EXPRESSION_PASSTHROUGH: Line 240: Complex expression (lambdas, LINQ, ... | Review and address | 10 |
| 12 | Low | Quality Warning | COMPLEX_EXPRESSION_PASSTHROUGH: Line 295: Complex expression (lambdas, LINQ, ... | Review and address | 10 |
| 13 | Low | Quality Warning | COMPLEX_EXPRESSION_PASSTHROUGH: Line 311: Complex expression (lambdas, LINQ, ... | Review and address | 10 |
| 14 | Low | Quality Warning | RETRY_INTERVAL_DEFAULTED: Post-repair: RetryInterval defaulted to "00:00:05" ... | Review and address | 10 |

### GetBirthdays.xaml (7 items, ~70 min)

| # | Priority | Category | Description | Developer Action | Est. Minutes |
|---|----------|----------|-------------|-----------------|-------------|
| 15 | High | Workflow Stub | Entire workflow `GetBirthdays.xaml` replaced with Studio-openable stub | Resolve object_payload_in_target_value_slot in GetBirthdays.xaml | 10 |
| 16 | Low | Implementation Required | Contains 1 placeholder value(s) matching "\bPLACEHOLDER\b" [Developer Impleme... | Implement in Studio | 10 |
| 17 | Low | Quality Warning | hardcoded-retry-count: Line 178: retry count hardcoded as 3 — consider extern... | Review and address | 10 |
| 18 | Low | Quality Warning | hardcoded-retry-interval: Line 125: retry interval hardcoded as "{&quot;type&... | Review and address | 10 |
| 19 | Low | Quality Warning | hardcoded-retry-interval: Line 178: retry interval hardcoded as "00:00:05" — ... | Review and address | 10 |
| 20 | Low | Quality Warning | COMPLEX_EXPRESSION_PASSTHROUGH: Line 173: Complex expression (lambdas, LINQ, ... | Review and address | 10 |
| 21 | Low | Quality Warning | RETRY_INTERVAL_DEFAULTED: Post-repair: RetryInterval defaulted to "00:00:05" ... | Review and address | 10 |

### HandleHumanReview.xaml (8 items, ~90 min)

| # | Priority | Category | Description | Developer Action | Est. Minutes |
|---|----------|----------|-------------|-----------------|-------------|
| 22 | High | Workflow Stub | Entire workflow `HandleHumanReview.xaml` replaced with Studio-openable stub | Resolve object_payload_in_target_value_slot in HandleHumanReview.xaml | 10 |
| 23 | Low | Validation Finding | Quality gate finding: `EXPRESSION_SYNTAX_UNFIXABLE` | Manually implement activity in HandleHumanReview.xaml — estimated 15 min | 15 |
| 24 | Low | Validation Finding | Quality gate finding: `MISSING_REQUIRED_ACTIVITY_PROPERTY` | Manually implement activity in HandleHumanReview.xaml — estimated 15 min | 15 |
| 25 | Low | Implementation Required | Contains 1 placeholder value(s) matching "\bPLACEHOLDER\b" [Developer Impleme... | Implement in Studio | 10 |
| 26 | Low | Quality Warning | hardcoded-retry-count: Line 141: retry count hardcoded as 3 — consider extern... | Review and address | 10 |
| 27 | Low | Quality Warning | hardcoded-retry-interval: Line 141: retry interval hardcoded as "00:00:05" — ... | Review and address | 10 |
| 28 | Low | Quality Warning | EXPRESSION_SYNTAX: Line 88: Unbalanced parentheses: 0 open vs 1 close — remov... | Review and address | 10 |
| 29 | Low | Quality Warning | RETRY_INTERVAL_DEFAULTED: Post-repair: RetryInterval defaulted to "00:00:05" ... | Review and address | 10 |

### InitAllSettings.xaml (21 items, ~210 min)

| # | Priority | Category | Description | Developer Action | Est. Minutes |
|---|----------|----------|-------------|-----------------|-------------|
| 30 | High | Workflow Stub | Entire workflow `InitAllSettings.xaml` replaced with Studio-openable stub | Resolve malformed_attribute_quoting in InitAllSettings.xaml | 10 |
| 31 | Low | Quality Warning | hardcoded-asset-name: Line 100: asset name "BGV26_GSuite_ServiceAccount_Crede... | Review and address | 10 |
| 32 | Low | Quality Warning | hardcoded-asset-name: Line 105: asset name "BGV26_BirthdaysCalendarName" is h... | Review and address | 10 |
| 33 | Low | Quality Warning | hardcoded-asset-name: Line 114: asset name "BGV26_TimeZone" is hardcoded — co... | Review and address | 10 |
| 34 | Low | Quality Warning | hardcoded-asset-name: Line 123: asset name "BGV26_EmailStyleSpec" is hardcode... | Review and address | 10 |
| 35 | Low | Quality Warning | hardcoded-asset-name: Line 132: asset name "BGV26_EmailWordCountMin" is hardc... | Review and address | 10 |
| 36 | Low | Quality Warning | hardcoded-asset-name: Line 141: asset name "BGV26_EmailWordCountMax" is hardc... | Review and address | 10 |
| 37 | Low | Quality Warning | hardcoded-asset-name: Line 150: asset name "BGV26_AllowActionCenterFallback" ... | Review and address | 10 |
| 38 | Low | Quality Warning | hardcoded-asset-name: Line 159: asset name "BGV26_GmailFromConnectionName" is... | Review and address | 10 |
| 39 | Low | Quality Warning | hardcoded-asset-name: Line 168: asset name "BGV26_DedupeScope" is hardcoded —... | Review and address | 10 |
| 40 | Low | Quality Warning | BARE_TOKEN_QUOTED: Auto-quoted bare token "Settings" for uexcel:ExcelReadRang... | Review and address | 10 |
| 41 | Low | Quality Warning | BARE_TOKEN_QUOTED: Auto-quoted bare token "Constants" for uexcel:ExcelReadRan... | Review and address | 10 |
| 42 | Low | Quality Warning | BARE_TOKEN_QUOTED: Auto-quoted bare token "BGV26_GSuite_ServiceAccount_Creden... | Review and address | 10 |
| 43 | Low | Quality Warning | BARE_TOKEN_QUOTED: Auto-quoted bare token "BGV26_BirthdaysCalendarName" for u... | Review and address | 10 |
| 44 | Low | Quality Warning | BARE_TOKEN_QUOTED: Auto-quoted bare token "BGV26_TimeZone" for ui:GetAsset.As... | Review and address | 10 |
| 45 | Low | Quality Warning | BARE_TOKEN_QUOTED: Auto-quoted bare token "BGV26_EmailStyleSpec" for ui:GetAs... | Review and address | 10 |
| 46 | Low | Quality Warning | BARE_TOKEN_QUOTED: Auto-quoted bare token "BGV26_EmailWordCountMin" for ui:Ge... | Review and address | 10 |
| 47 | Low | Quality Warning | BARE_TOKEN_QUOTED: Auto-quoted bare token "BGV26_EmailWordCountMax" for ui:Ge... | Review and address | 10 |
| 48 | Low | Quality Warning | BARE_TOKEN_QUOTED: Auto-quoted bare token "BGV26_AllowActionCenterFallback" f... | Review and address | 10 |
| 49 | Low | Quality Warning | BARE_TOKEN_QUOTED: Auto-quoted bare token "BGV26_GmailFromConnectionName" for... | Review and address | 10 |
| 50 | Low | Quality Warning | BARE_TOKEN_QUOTED: Auto-quoted bare token "BGV26_DedupeScope" for ui:GetAsset... | Review and address | 10 |

### Main.xaml (14 items, ~140 min)

| # | Priority | Category | Description | Developer Action | Est. Minutes |
|---|----------|----------|-------------|-----------------|-------------|
| 51 | High | Workflow Stub | Entire workflow `Main.xaml` replaced with Studio-openable stub | Resolve object_payload_in_target_value_slot in Main.xaml | 10 |
| 52 | Low | Quality Warning | hardcoded-retry-count: Line 403: retry count hardcoded as 3 — consider extern... | Review and address | 10 |
| 53 | Low | Quality Warning | hardcoded-retry-interval: Line 403: retry interval hardcoded as "00:00:05" — ... | Review and address | 10 |
| 54 | Low | Quality Warning | hardcoded-asset-name: Line 78: asset name "{&quot;type&quot;:&quot;literal&qu... | Review and address | 10 |
| 55 | Low | Quality Warning | hardcoded-asset-name: Line 118: asset name "{&quot;type&quot;:&quot;literal&q... | Review and address | 10 |
| 56 | Low | Quality Warning | hardcoded-asset-name: Line 157: asset name "{&quot;type&quot;:&quot;literal&q... | Review and address | 10 |
| 57 | Low | Quality Warning | hardcoded-asset-name: Line 196: asset name "{&quot;type&quot;:&quot;literal&q... | Review and address | 10 |
| 58 | Low | Quality Warning | hardcoded-asset-name: Line 239: asset name "{&quot;type&quot;:&quot;literal&q... | Review and address | 10 |
| 59 | Low | Quality Warning | hardcoded-asset-name: Line 282: asset name "{&quot;type&quot;:&quot;literal&q... | Review and address | 10 |
| 60 | Low | Quality Warning | hardcoded-asset-name: Line 325: asset name "{&quot;type&quot;:&quot;literal&q... | Review and address | 10 |
| 61 | Low | Quality Warning | hardcoded-asset-name: Line 364: asset name "{&quot;type&quot;:&quot;literal&q... | Review and address | 10 |
| 62 | Low | Quality Warning | COMPLEX_EXPRESSION_PASSTHROUGH: Line 71: Complex expression (lambdas, LINQ, n... | Review and address | 10 |
| 63 | Low | Quality Warning | EXPRESSION_SYNTAX: Line 320: C# 'true' should be VB.NET 'True' in expression:... | Review and address | 10 |
| 64 | Low | Quality Warning | RETRY_INTERVAL_DEFAULTED: Post-repair: RetryInterval defaulted to "00:00:05" ... | Review and address | 10 |

### ProcessBirthday.xaml (7 items, ~70 min)

| # | Priority | Category | Description | Developer Action | Est. Minutes |
|---|----------|----------|-------------|-----------------|-------------|
| 65 | High | Workflow Stub | Entire workflow `ProcessBirthday.xaml` replaced with Studio-openable stub | Resolve object_payload_in_target_value_slot in ProcessBirthday.xaml | 10 |
| 66 | Low | Implementation Required | Contains 1 placeholder value(s) matching "\bPLACEHOLDER\b" [Developer Impleme... | Implement in Studio | 10 |
| 67 | Low | Quality Warning | unguarded-array-index: Line 279: array indexing ".Rows(N)" without a precedin... | Review and address | 10 |
| 68 | Low | Quality Warning | unguarded-array-index: Line 283: array indexing ".Rows(N)" without a precedin... | Review and address | 10 |
| 69 | Low | Quality Warning | hardcoded-retry-interval: Line 79: retry interval hardcoded as "{&quot;type&q... | Review and address | 10 |
| 70 | Low | Quality Warning | hardcoded-retry-interval: Line 325: retry interval hardcoded as "{&quot;type&... | Review and address | 10 |
| 71 | Low | Quality Warning | COMPLEX_EXPRESSION_PASSTHROUGH: Line 203: Complex expression (lambdas, LINQ, ... | Review and address | 10 |

### Unknown.xaml (2 items, ~10 min)

| # | Priority | Category | Description | Developer Action | Est. Minutes |
|---|----------|----------|-------------|-----------------|-------------|
| 72 | Medium | Activity Stub | Activity "unknown" stubbed | ugs:GmailSendMessage.Body has no valid source binding and no contract-valid f... | 5 |
| 73 | Medium | Activity Stub | Activity "unknown" stubbed | ugs:GmailSendMessage.Body has no valid source binding and no contract-valid f... | 5 |

### orchestrator.xaml (8 items, ~80 min)

| # | Priority | Category | Description | Developer Action | Est. Minutes |
|---|----------|----------|-------------|-----------------|-------------|
| 74 | Low | Quality Warning | undeclared-asset: Asset "{type:literal,value:BGV26_BirthdaysCalendarName}" is... | Review and address | 10 |
| 75 | Low | Quality Warning | undeclared-asset: Asset "{type:literal,value:BGV26_TimeZone}" is referenced i... | Review and address | 10 |
| 76 | Low | Quality Warning | undeclared-asset: Asset "{type:literal,value:BGV26_EmailStyleSpec}" is refere... | Review and address | 10 |
| 77 | Low | Quality Warning | undeclared-asset: Asset "{type:literal,value:BGV26_EmailWordCountMin}" is ref... | Review and address | 10 |
| 78 | Low | Quality Warning | undeclared-asset: Asset "{type:literal,value:BGV26_EmailWordCountMax}" is ref... | Review and address | 10 |
| 79 | Low | Quality Warning | undeclared-asset: Asset "{type:literal,value:BGV26_AllowActionCenterFallback}... | Review and address | 10 |
| 80 | Low | Quality Warning | undeclared-asset: Asset "{type:literal,value:BGV26_GmailFromConnectionName}" ... | Review and address | 10 |
| 81 | Low | Quality Warning | undeclared-asset: Asset "{type:literal,value:BGV26_DedupeScope}" is reference... | Review and address | 10 |

## 4. Process Context (from Pipeline)

### Idea Description

Automate birthday greetings to friends and family

### PDD Summary

## 1. Executive Summary
The “birthday greetingsV26” project automates a daily personal workflow: at 8:00am, birthdays are checked in Google Calendar and a warm, funny, lightly sarcastic birthday email is sent from the user’s Gmail account. The current manual approach is simple but prone to missed sends when the user forgets. The to-be solution will run fully autonomously on unattended robots via UiPath Orchestrator Triggers, retrieve today’s birthday events from the built-in Google “Birthdays” calendar feed, resolve the recipient’s email address via Google Contacts (preferring “Personal” when multiple emails exist), generate a personalized message using UiPath native GenAI capabilities (no OpenAI/Azure OpenAI usage), send via the Gmail Integration Service connector for **ninemush@gmail.com**, and record a sent-log to prevent duplicates within the same day.

## 2. Process Scope
This automation is in scope to execute once per day at 8:00am and complete all birthday greetings for that same calendar date. It reads birthday events from the built-in Google “Birthdays” calendar feed (displayed as “Birthdays”), where each event title contains only the person’s full name. It then performs an exact-name lookup in Google Contacts to find a recipient email labeled “Personal” or “Home,” prioritizing “Personal.” If no valid email is found, the automation skips that person without further action.

The email is sent exclusively from the Gmail account connected in UiPath Integration Service as **Gmail – ninemush@gmail.com**. The content is AI-generated using UiPath native capabilities (UiPath GenAI Activities / Agents) and follows an approved default style specification (warm, funny, lightly sarcastic; no emojis; one short subject line; 40–90 words). Photo usage (e.g., Google Photos) and any relationship-based personalization are explicitly out of scope for this iteration.

## 3. As-Is Process Description

![As-Is Process Map](/api/ideas/fcbe5f6d-60a1-45f7-8c96-5df24f1173b0/process-...

### SDD Summary

## 1. Automation Architecture Overview

### 1.1 Chosen automation type and rationale
**Automation type: Hybrid (Workflow + Native GenAI), unattended-first, exception-only human-in-the-loop.**

- **Deterministic steps** (schedule, calendar read, exact contact lookup, email selection, dedupe, send, logging) are best implemented as **unattended workflow automation** for reliability and operability.
- **Generative step** (subject/body drafting in the approved default voice spec) is best implemented using **UiPath native GenAI capabilities** invoked from the workflow. This is not a “pure Agent” process because the core is deterministic and must be strongly governed (exact-match, dedupe, same-day rules).
- **Action Center** is included only for **edge cases** (draft validation failure, ambiguous contacts if exact name returns multiples) to keep the standard path fully autonomous while still preventing unsafe or incomplete sends.

### 1.2 High-level architecture (services used)
- **Orchestrator**
  - **Time-based Trigger**: daily at **08:00**.
  - **Unattended job execution** on available unattended slots (11).
  - **Assets** for configuration (calendar name/id, voice spec, validation thresholds).
  - **Monitoring & alerting hooks**: job state, custom logs, and failure notifications.
- **Integration Service**
  - **Gmail connector** to send email from **connection “ninemush@gmail.com” (ID: 0a0d5ee1-a1e8-477a-a943-58161e6f3272)**.
  - Rationale: connector-based sending is more stable and auditable than UI automation, and avoids custom HTTP per platform rule.
- **Google access**
  - Calendar + Contacts access in the PDD is via **UiPath GSuite Activities** (Google APIs).
  - Rationale: quick, stable, no UI; also avoids building/maintaining bespoke HTTP integrations.
- **Data Service**
  - Stores persistent **sent-log** and run trace data to enforce deduplication (**once per person per year**, and at minimum also same-day).
  - Rationale vs Orchestrator Queue:
    - **Queue** ...

**Automation Type:** hybrid
**Rationale:** The calendar/contact lookup + sending are deterministic and best as RPA, while drafting “warm/funny/sarcastic” unique messages is generative and best handled by a UiPath GenAI-powered agent step with guardrails and fallback.
**Feasibility Complexity:** medium
**Effort Estimate:** 1-2 weeks

## 5. Business Process Overview

### Process Steps

| # | Step | Role | System | Type | Pain Point |
|---|------|------|--------|------|------------|
| 1 | 8am Daily Birthday Run Trigger | System | Orchestrator Triggers | start | — |
| 2 | Get Today’s Birthday Events (Built-in Birthdays Calendar) | System | Google Calendar (UiPath GSuite Activities) | task | — |
| 3 | Any birthdays today? | System | Google Calendar (UiPath GSuite Activities) | decision | — |
| 4 | No Birthdays Today End | System | Orchestrator | end | — |
| 5 | For Each Birthday Event: Normalize Full Name | System | Workflow | task | — |
| 6 | Exact Match Contact by Full Name | System | Google Contacts (UiPath GSuite Activities) | task | — |
| 7 | Personal/Home email available? | System | Google Contacts (UiPath GSuite Activities) | decision | — |
| 8 | Skip Person (No Email) | System | Workflow | task | — |
| 9 | Select Recipient Email (Prefer Personal) | System | Google Contacts (UiPath GSuite Activities) | task | — |
| 10 | Already Sent Today for This Person? | System | Data Service / Data Fabric | decision | — |
| 11 | Skip Duplicate Send | System | Workflow | task | — |
| 12 | Generate Birthday Email Draft (Your Voice) | System | UiPath Agents + UiPath GenAI Activities | agent-task | — |
| 13 | Draft Safe/Complete? (no sensitive content, has subject+body) | System | UiPath Agents | agent-decision | — |
| 14 | Create Human Review Task (Edge Case) | System | Action Center | task | — |
| 15 | Apply Approved/Edited Text from Action Center | System | Action Center | task | — |
| 16 | Send Birthday Email | System | Integration Service - Gmail (ninemush@gmail.com) | task | — |
| 17 | Send Birthday Email (Post-Review) | System | Integration Service - Gmail (ninemush@gmail.com) | task | — |
| 18 | Record Sent Log (name, email, date, messageId) | System | Data Service / Data Fabric | task | — |
| 19 | More birthday events remaining? | System | Workflow | decision | — |
| 20 | Process Next Event | System | Workflow | task | — |
| 21 | Birthday Batch Completed End | System | Orchestrator | end | — |
| 22 | Loop Back to Next Contact Lookup | System | Workflow | task | — |
| 23 | Merge Skips Back to Loop | System | Workflow | task | — |
| 24 | Merge Duplicate Skips Back to Loop | System | Workflow | task | — |
| 25 | Continue Loop | System | Workflow | task | — |
| 26 | Return to “More events remaining?” decision | System | Workflow | task | — |
| 27 | Loop to Contact Lookup | System | Workflow | task | — |
| 28 | Loop Connection | System | Workflow | task | — |

### Target Applications / Systems

The following applications were identified from the process map and must be accessible from the robot machine:

- Orchestrator Triggers
- Google Calendar (UiPath GSuite Activities)
- Orchestrator
- Workflow
- Google Contacts (UiPath GSuite Activities)
- Data Service / Data Fabric
- UiPath Agents + UiPath GenAI Activities
- UiPath Agents
- Action Center
- Integration Service - Gmail (ninemush@gmail.com)

### User Roles Involved

- System

### Decision Points (Process Map Topology)

**Any birthdays today?**
  - [No] → No Birthdays Today End
  - [Yes] → For Each Birthday Event: Normalize Full Name

**Personal/Home email available?**
  - [No] → Skip Person (No Email)
  - [Yes] → Select Recipient Email (Prefer Personal)

**Already Sent Today for This Person?**
  - [Yes] → Skip Duplicate Send
  - [No] → Generate Birthday Email Draft (Your Voice)

**More birthday events remaining?**
  - [Yes] → Process Next Event
  - [No] → Birthday Batch Completed End

## 6. Environment Setup

| Requirement | Value |
|---|---|
| Target Framework | Windows (required) |
| Robot Type | Unattended |
| Modern Activities | No |
| Studio Version | 25.10.7 |
| Orchestrator Connection | Required |
| Machine Template | Standard |
| Action Center | Required |
| Data Service | Required |

### Machine Template

**Recommended:** Standard
Standard unattended machine template

### Orchestrator Folder Structure

Create a Modern Folder with at least one unattended robot assignment. Use folder-level credential stores for asset isolation.

### NuGet Dependencies

| # | Package |
|---|--------|
| 1 | `UiPath.System.Activities` |
| 2 | `UiPath.DataService.Activities` |
| 3 | `UiPath.UIAutomation.Activities` |
| 4 | `UiPath.ComplexScenarios.Activities` |
| 5 | `UiPath.GSuite.Activities` |
| 6 | `UiPath.WebAPI.Activities` |
| 7 | `Newtonsoft.Json` |
| 8 | `UiPath.Persistence.Activities` |
| 9 | `UiPath.Excel.Activities` |

### Target Applications (from Process Map)

The following applications were identified from the business process map. Ensure network connectivity and access credentials are configured on the robot machine:

- Orchestrator Triggers
- Google Calendar (UiPath GSuite Activities)
- Orchestrator
- Workflow
- Google Contacts (UiPath GSuite Activities)
- Data Service / Data Fabric
- UiPath Agents + UiPath GenAI Activities
- UiPath Agents
- Action Center
- Integration Service - Gmail (ninemush@gmail.com)

## 7. Credential & Asset Inventory

**Total:** 25 activities (0 hardcoded, 25 variable-driven)

### Orchestrator Credentials to Provision

| # | Credential Name | Type | Consuming Activity | File | Action |
|---|----------------|------|-------------------|------|--------|
| 1 | `[BGV26_GSuite_ServiceAccount_Credential]` | Credential | — | `InitAllSettings.xaml` | Verify exists in target environment |

### Orchestrator Assets to Provision

| # | Asset Name | Value Type | Consuming Activity | File | Action |
|---|-----------|-----------|-------------------|------|--------|
| 1 | `[` | Unknown | — | `Main.xaml` | Verify exists in target environment |
| 2 | `[BGV26_BirthdaysCalendarName]` | Unknown | — | `InitAllSettings.xaml` | Verify exists in target environment |
| 3 | `[BGV26_TimeZone]` | Unknown | — | `InitAllSettings.xaml` | Verify exists in target environment |
| 4 | `[BGV26_EmailStyleSpec]` | Unknown | — | `InitAllSettings.xaml` | Verify exists in target environment |
| 5 | `[BGV26_EmailWordCountMin]` | Unknown | — | `InitAllSettings.xaml` | Verify exists in target environment |
| 6 | `[BGV26_EmailWordCountMax]` | Unknown | — | `InitAllSettings.xaml` | Verify exists in target environment |
| 7 | `[BGV26_AllowActionCenterFallback]` | Unknown | — | `InitAllSettings.xaml` | Verify exists in target environment |
| 8 | `[BGV26_GmailFromConnectionName]` | Unknown | — | `InitAllSettings.xaml` | Verify exists in target environment |
| 9 | `[BGV26_DedupeScope]` | Unknown | — | `InitAllSettings.xaml` | Verify exists in target environment |

### Detailed Usage Map

| File | Line | Activity | Asset/Credential | Type | Variable | Hardcoded |
|------|------|----------|-----------------|------|----------|----------|
| `Main.xaml` | 78 | GetAsset | `[` | Unknown | — | No |
| `Main.xaml` | 118 | GetAsset | `[` | Unknown | — | No |
| `Main.xaml` | 157 | GetAsset | `[` | Unknown | — | No |
| `Main.xaml` | 196 | GetAsset | `[` | Unknown | — | No |
| `Main.xaml` | 239 | GetAsset | `[` | Unknown | — | No |
| `Main.xaml` | 282 | GetAsset | `[` | Unknown | — | No |
| `Main.xaml` | 325 | GetAsset | `[` | Unknown | — | No |
| `Main.xaml` | 364 | GetAsset | `[` | Unknown | — | No |
| `InitAllSettings.xaml` | 100 | GetCredential | `[BGV26_GSuite_ServiceAccount_Credential]` | Credential | — | No |
| `InitAllSettings.xaml` | 105 | GetAsset | `[BGV26_BirthdaysCalendarName]` | Unknown | — | No |
| `InitAllSettings.xaml` | 106 | GetAsset | `UNKNOWN` | Unknown | — | No |
| `InitAllSettings.xaml` | 114 | GetAsset | `[BGV26_TimeZone]` | Unknown | — | No |
| `InitAllSettings.xaml` | 115 | GetAsset | `UNKNOWN` | Unknown | — | No |
| `InitAllSettings.xaml` | 123 | GetAsset | `[BGV26_EmailStyleSpec]` | Unknown | — | No |
| `InitAllSettings.xaml` | 124 | GetAsset | `UNKNOWN` | Unknown | — | No |
| `InitAllSettings.xaml` | 132 | GetAsset | `[BGV26_EmailWordCountMin]` | Unknown | — | No |
| `InitAllSettings.xaml` | 133 | GetAsset | `UNKNOWN` | Unknown | — | No |
| `InitAllSettings.xaml` | 141 | GetAsset | `[BGV26_EmailWordCountMax]` | Unknown | — | No |
| `InitAllSettings.xaml` | 142 | GetAsset | `UNKNOWN` | Unknown | — | No |
| `InitAllSettings.xaml` | 150 | GetAsset | `[BGV26_AllowActionCenterFallback]` | Unknown | — | No |
| `InitAllSettings.xaml` | 151 | GetAsset | `UNKNOWN` | Unknown | — | No |
| `InitAllSettings.xaml` | 159 | GetAsset | `[BGV26_GmailFromConnectionName]` | Unknown | — | No |
| `InitAllSettings.xaml` | 160 | GetAsset | `UNKNOWN` | Unknown | — | No |
| `InitAllSettings.xaml` | 168 | GetAsset | `[BGV26_DedupeScope]` | Unknown | — | No |
| `InitAllSettings.xaml` | 169 | GetAsset | `UNKNOWN` | Unknown | — | No |

## 8. SDD × XAML Artifact Reconciliation

**Summary:** 0 aligned, 10 SDD-only, 10 XAML-only

> **Warning:** 10 artifact(s) declared in the SDD were not found in the generated XAML. These must be provisioned in Orchestrator but are not referenced in code — verify the SDD spec or add the corresponding activities.

> **Warning:** 10 artifact(s) found in XAML are not declared in the SDD. Update the SDD orchestrator_artifacts block to include these, or the deployment manifest will be incomplete.

| # | Name | Type | Status | SDD Config | XAML File | XAML Line |
|---|------|------|--------|-----------|----------|----------|
| 1 | `BGV26_GSuite_ServiceAccount_Credential` | credential | **SDD Only** | type: Credential, description: Credential for Google Workspace/GSuite Activities authentication (service identity) to read Google Calendar 'Birthdays' feed and Google Contacts. | — | — |
| 2 | `BGV26_BirthdaysCalendarName` | asset | **SDD Only** | type: Text, value: Birthdays, description: Display name of the built-in Google Calendar feed used as source for birthdays. | — | — |
| 3 | `BGV26_TimeZone` | asset | **SDD Only** | type: Text, value: America/New_York, description: Time zone used to compute 'today' for birthday event retrieval and deduplication. | — | — |
| 4 | `BGV26_EmailStyleSpec` | asset | **SDD Only** | type: Text, value: Write a warm, funny, lightly sarcastic birthday email. No emojis. Provide one short subject line and an email body of 40–90 words. Keep it appropriate for workplace/friends; no sensitive or offensive content., description: Default prompt/style specification passed to UiPath native GenAI generation. | — | — |
| 5 | `BGV26_EmailWordCountMin` | asset | **SDD Only** | type: Integer, value: 40, description: Minimum allowed word count for generated email body. | — | — |
| 6 | `BGV26_EmailWordCountMax` | asset | **SDD Only** | type: Integer, value: 90, description: Maximum allowed word count for generated email body. | — | — |
| 7 | `BGV26_AllowActionCenterFallback` | asset | **SDD Only** | type: Bool, value: true, description: If true, create an Action Center task when GenAI output fails validation or contact match is ambiguous. | — | — |
| 8 | `BGV26_GmailFromConnectionName` | asset | **SDD Only** | type: Text, value: ninemush@gmail.com, description: Integration Service Gmail connection name to be used for sending. | — | — |
| 9 | `BGV26_DedupeScope` | asset | **SDD Only** | type: Text, value: FullName+SendDate, description: Deduplication key scope for sent-log checks. | — | — |
| 10 | `[` | asset | **XAML Only** | — | `Main.xaml` | 78 |
| 11 | `[BGV26_BirthdaysCalendarName]` | asset | **XAML Only** | — | `InitAllSettings.xaml` | 105 |
| 12 | `[BGV26_TimeZone]` | asset | **XAML Only** | — | `InitAllSettings.xaml` | 114 |
| 13 | `[BGV26_EmailStyleSpec]` | asset | **XAML Only** | — | `InitAllSettings.xaml` | 123 |
| 14 | `[BGV26_EmailWordCountMin]` | asset | **XAML Only** | — | `InitAllSettings.xaml` | 132 |
| 15 | `[BGV26_EmailWordCountMax]` | asset | **XAML Only** | — | `InitAllSettings.xaml` | 141 |
| 16 | `[BGV26_AllowActionCenterFallback]` | asset | **XAML Only** | — | `InitAllSettings.xaml` | 150 |
| 17 | `[BGV26_GmailFromConnectionName]` | asset | **XAML Only** | — | `InitAllSettings.xaml` | 159 |
| 18 | `[BGV26_DedupeScope]` | asset | **XAML Only** | — | `InitAllSettings.xaml` | 168 |
| 19 | `[BGV26_GSuite_ServiceAccount_Credential]` | credential | **XAML Only** | — | `InitAllSettings.xaml` | 100 |
| 20 | `birthdayGreetingsV26_Exceptions` | queue | **SDD Only** | maxRetries: 2, uniqueReference: true, description: Queue for non-blocking exceptions and reprocessing items (e.g., ambiguous contact match, transient integration failures) for birthday greetings run. | — | — |

## 9. Queue Management

No queue activities detected in the package.

## 10. Exception Handling Coverage

**Coverage:** 9/26 high-risk activities inside TryCatch (35%)

### Files Without TryCatch

- `Finalize.xaml`
- `InitAllSettings.xaml`

### Uncovered High-Risk Activities

| # | Location | Activity |
|---|----------|----------|
| 1 | `InitAllSettings.xaml:100` | Get BGV26_GSuite_ServiceAccount_Credential |
| 2 | `InitAllSettings.xaml:105` | Get BGV26_BirthdaysCalendarName |
| 3 | `InitAllSettings.xaml:106` | ui:GetAsset |
| 4 | `InitAllSettings.xaml:114` | Get BGV26_TimeZone |
| 5 | `InitAllSettings.xaml:115` | ui:GetAsset |
| 6 | `InitAllSettings.xaml:123` | Get BGV26_EmailStyleSpec |
| 7 | `InitAllSettings.xaml:124` | ui:GetAsset |
| 8 | `InitAllSettings.xaml:132` | Get BGV26_EmailWordCountMin |
| 9 | `InitAllSettings.xaml:133` | ui:GetAsset |
| 10 | `InitAllSettings.xaml:141` | Get BGV26_EmailWordCountMax |
| 11 | `InitAllSettings.xaml:142` | ui:GetAsset |
| 12 | `InitAllSettings.xaml:150` | Get BGV26_AllowActionCenterFallback |
| 13 | `InitAllSettings.xaml:151` | ui:GetAsset |
| 14 | `InitAllSettings.xaml:159` | Get BGV26_GmailFromConnectionName |
| 15 | `InitAllSettings.xaml:160` | ui:GetAsset |
| 16 | `InitAllSettings.xaml:168` | Get BGV26_DedupeScope |
| 17 | `InitAllSettings.xaml:169` | ui:GetAsset |

> **Recommendation:** Wrap these activities in TryCatch blocks with appropriate exception types (BusinessRuleException for data errors, System.Exception for general failures).

## 11. Trigger Configuration

Based on the process analysis, the following trigger configuration is recommended:

| # | Trigger Type | Reason | Configuration |
|---|-------------|--------|---------------|
| 1 | **Schedule** | Defined in SDD orchestrator_artifacts: TRG_BirthdayGreetingsV26_Daily_0800 | SDD-specified: TRG_BirthdayGreetingsV26_Daily_0800 | Cron: 0 0 8 ? * * * | Runs the birthdayGreetingsV26 job daily at 08:00. |

## 12. Upstream Quality Findings

The following quality warnings were produced by upstream pipeline stages (selector scoring, type validation, expression linting, etc.) and should be addressed during development:

| Code | Severity | Count | Sample Message |
|------|----------|-------|----------------|
| placeholder-value | warning | 4 | Contains 1 placeholder value(s) matching "\bPLACEHOLDER\b" [Developer Implementation Required] |
| undeclared-asset | warning | 8 | Asset "{type:literal,value:BGV26_BirthdaysCalendarName}" is referenced in XAML but not declared in orchestrator artifact... |
| unguarded-array-index | warning | 2 | Line 279: array indexing ".Rows(N)" without a preceding row count check — may throw IndexOutOfRangeException at runtime |
| hardcoded-retry-count | warning | 4 | Line 403: retry count hardcoded as 3 — consider externalizing to Config.xlsx (e.g., in_Config("MaxRetryNumber")) |
| hardcoded-retry-interval | warning | 8 | Line 403: retry interval hardcoded as "00:00:05" — consider externalizing to Config.xlsx |
| hardcoded-asset-name | warning | 17 | Line 78: asset name "{&quot;type&quot;:&quot;literal&quot;,&quot;value&quot;:&quot;BGV26_BirthdaysCalendarName&quot;}" i... |
| COMPLEX_EXPRESSION_PASSTHROUGH | warning | 6 | Line 71: Complex expression (lambdas, LINQ, nested calls, or 3+ operators) — emitting as-is to avoid regex corruption in... |
| EXPRESSION_SYNTAX | warning | 4 | Line 320: C# 'true' should be VB.NET 'True' in expression: {&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;... |
| BARE_TOKEN_QUOTED | warning | 11 | Auto-quoted bare token "Settings" for uexcel:ExcelReadRange.SheetName (expected String type) — wrapped in VB string quot... |
| RETRY_INTERVAL_DEFAULTED | warning | 4 | Post-repair: RetryInterval defaulted to "00:00:05" — verify this is appropriate for the workflow context |

## 13. Pre-Deployment Checklist

| # | Category | Task | Required |
|---|----------|------|----------|
| 1 | Deployment | Publish package to Orchestrator feed | Yes |
| 2 | Deployment | Create Process in target folder | Yes |
| 3 | Environment | Verify Orchestrator connection from robot | Yes |
| 4 | Credentials | Provision credential: `[BGV26_GSuite_ServiceAccount_Credential]` | Yes |
| 5 | Assets | Provision asset: `[` | Yes |
| 6 | Assets | Provision asset: `[BGV26_BirthdaysCalendarName]` | Yes |
| 7 | Assets | Provision asset: `[BGV26_TimeZone]` | Yes |
| 8 | Assets | Provision asset: `[BGV26_EmailStyleSpec]` | Yes |
| 9 | Assets | Provision asset: `[BGV26_EmailWordCountMin]` | Yes |
| 10 | Assets | Provision asset: `[BGV26_EmailWordCountMax]` | Yes |
| 11 | Assets | Provision asset: `[BGV26_AllowActionCenterFallback]` | Yes |
| 12 | Assets | Provision asset: `[BGV26_GmailFromConnectionName]` | Yes |
| 13 | Assets | Provision asset: `[BGV26_DedupeScope]` | Yes |
| 14 | Trigger | Configure trigger (schedule/queue/API) | Yes |
| 15 | Testing | Run smoke test in target environment | Yes |
| 16 | Monitoring | Verify logging output in Orchestrator | Recommended |
| 17 | Governance | UAT test execution completed and sign-off obtained | Yes |
| 18 | Governance | Peer code review completed | Yes |
| 19 | Governance | All quality gate warnings addressed or risk-accepted | Yes |
| 20 | Governance | Business process owner validation obtained | Yes |
| 21 | Governance | CoE approval obtained | Yes |
| 22 | Governance | Production readiness assessment completed (monitoring, alerting, rollback plan documented) | Yes |

## 14. Deployment Readiness Score

**Overall: Mostly Ready — 34/50 (68%)**

| Section | Score | Notes |
|---------|-------|-------|
| Credentials & Assets | 10/10 | All credentials/assets properly configured |
| Exception Handling | 3/10 | Only 35% of high-risk activities covered by TryCatch; 2 file(s) with no TryCatch blocks |
| Queue Management | 10/10 | No queue activities — section not applicable |
| Build Quality | 1/10 | 68 quality warnings — significant remediation needed; 13 remediations — stub replacements need developer attention |
| Environment Setup | 10/10 | Environment requirements are straightforward |

> **Almost There:** A few items need attention before production deployment.

## 15. Pre-emission Spec Validation

Validation was performed on the WorkflowSpec tree before XAML assembly. Issues caught at this stage are cheaper to fix than post-emission quality gate findings.

| Metric | Count |
|---|---|
| Total activities checked | 0 |
| Valid activities | 0 |
| Unknown → Comment stubs | 0 |
| Non-catalog properties stripped | 0 |
| Enum values auto-corrected | 0 |
| Missing required props filled | 0 |
| Total issues | 0 |

### Pre-emission vs Post-emission

| Stage | Issues Caught/Fixed |
|---|---|
| Pre-emission (spec validation) | 0 auto-fixed, 0 total issues |
| Post-emission (quality gate) | 81 warnings/remediations |

## 16. Catalog Filter Adoption Report

Shows which pipeline stages use the filtered activity catalog (deprecated, non-emission-approved, and target-incompatible activities are excluded).

| Stage | Adopted | Total Lookups | Approved | Deprecated | Non-Approved | Target-Incompatible | Unknown |
|---|---|---|---|---|---|---|---|
| quality-gate | Yes | 750 | 750 | 0 | 0 | 0 | 0 |
| deterministic-validators | Yes | 9088 | 5024 | 0 | 0 | 0 | 4064 |
| iterative-llm-corrector | Yes | 0 | 0 | 0 | 0 | 0 | 0 |
| workflow-tree-assembler | Yes | 0 | 0 | 0 | 0 | 0 | 0 |
| xaml-compliance | Yes | 9852 | 6327 | 0 | 1980 | 0 | 1545 |
| executable-path-validator | Yes | 566 | 493 | 0 | 0 | 0 | 73 |
| post-emission-dependency-analyzer | Yes | 9 | 9 | 0 | 0 | 0 | 0 |

---

## 17. Structured Report (JSON)

The following JSON appendix contains the full pipeline outcome report for programmatic consumption:

```json
{
  "fullyGeneratedFiles": [],
  "autoRepairs": [
    {
      "repairCode": "REPAIR_GENERIC",
      "file": "Main.xaml",
      "description": "Catalog (fallback): Moved ui:GetAsset.Value from attribute to child-element in Main.xaml"
    },
    {
      "repairCode": "REPAIR_GENERIC",
      "file": "Main.xaml",
      "description": "Catalog (fallback): Moved ui:GetAsset.Value from attribute to child-element in Main.xaml"
    },
    {
      "repairCode": "REPAIR_GENERIC",
      "file": "Main.xaml",
      "description": "Catalog (fallback): Moved ui:GetAsset.Value from attribute to child-element in Main.xaml"
    },
    {
      "repairCode": "REPAIR_GENERIC",
      "file": "Main.xaml",
      "description": "Catalog (fallback): Moved ui:GetAsset.Value from attribute to child-element in Main.xaml"
    },
    {
      "repairCode": "REPAIR_GENERIC",
      "file": "Main.xaml",
      "description": "Catalog (fallback): Moved ui:GetAsset.Value from attribute to child-element in Main.xaml"
    },
    {
      "repairCode": "REPAIR_GENERIC",
      "file": "Main.xaml",
      "description": "Catalog (fallback): Moved ui:GetAsset.Value from attribute to child-element in Main.xaml"
    },
    {
      "repairCode": "REPAIR_GENERIC",
      "file": "Main.xaml",
      "description": "Catalog (fallback): Moved ui:GetAsset.Value from attribute to child-element in Main.xaml"
    },
    {
      "repairCode": "REPAIR_GENERIC",
      "file": "Main.xaml",
      "description": "Catalog (fallback): Moved ui:GetAsset.Value from attribute to child-element in Main.xaml"
    },
    {
      "repairCode": "REPAIR_GENERIC",
      "file": "Main.xaml",
      "description": "Catalog (fallback): Moved uds:CreateEntityRecord.EntityObject from attribute to child-element in Main.xaml"
    },
    {
      "repairCode": "REPAIR_GENERIC",
      "file": "Main.xaml",
      "description": "Catalog (fallback): Moved ForEach.Values from attribute to child-element in Main.xaml"
    }
  ],
  "remediations": [
    {
      "level": "validation-finding",
      "file": "HandleHumanReview.xaml",
      "remediationCode": "STUB_ACTIVITY_UNKNOWN",
      "reason": "Line 257: Adjacent identifiers \"timed out(\" — possible missing operator or comma in expression: {&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;\\&quot;Actio...",
      "classifiedCheck": "EXPRESSION_SYNTAX_UNFIXABLE",
      "developerAction": "Manually implement activity in HandleHumanReview.xaml — estimated 15 min",
      "estimatedEffortMinutes": 15
    },
    {
      "level": "validation-finding",
      "file": "Finalize.xaml",
      "remediationCode": "STUB_ACTIVITY_UNKNOWN",
      "reason": "Line 180: String.Format() expects 2-10 argument(s) but got 12 in expression: {&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;String.Forma...",
      "classifiedCheck": "EXPRESSION_SYNTAX_UNFIXABLE",
      "developerAction": "Manually implement activity in Finalize.xaml — estimated 15 min",
      "estimatedEffortMinutes": 15
    },
    {
      "level": "validation-finding",
      "file": "HandleHumanReview.xaml",
      "remediationCode": "STUB_ACTIVITY_UNKNOWN",
      "reason": "Line 262: ugs:GmailSendMessage is missing required property \"Body\"",
      "classifiedCheck": "MISSING_REQUIRED_ACTIVITY_PROPERTY",
      "developerAction": "Manually implement activity in HandleHumanReview.xaml — estimated 15 min",
      "estimatedEffortMinutes": 15
    },
    {
      "level": "validation-finding",
      "file": "Finalize.xaml",
      "remediationCode": "STUB_ACTIVITY_UNKNOWN",
      "reason": "Line 185: ugs:GmailSendMessage is missing required property \"Body\"",
      "classifiedCheck": "MISSING_REQUIRED_ACTIVITY_PROPERTY",
      "developerAction": "Manually implement activity in Finalize.xaml — estimated 15 min",
      "estimatedEffortMinutes": 15
    },
    {
      "level": "workflow",
      "file": "Finalize.xaml",
      "remediationCode": "STUB_WORKFLOW_BLOCKING",
      "reason": "Final validation: XAML well-formedness violations — replaced with stub. Details: [xml-wellformedness] XML parse error at line 180, col 187 (code: InvalidChar): char '&' is not expected.",
      "classifiedCheck": "xml-wellformedness",
      "developerAction": "Fix XML structure in Finalize.xaml — [xml-wellformedness] XML parse error at line 180, col 187 (code: InvalidChar): char '&' is not expected.",
      "estimatedEffortMinutes": 15
    },
    {
      "level": "activity",
      "file": "",
      "remediationCode": "POST_ASSEMBLY_REPAIR",
      "reason": "[MISSING_REQUIRED_PROPERTY_DEFECT] ugs:GmailSendMessage.Body has no valid source binding and no contract-valid fallback — structured defect, property left absent",
      "classifiedCheck": "post-assembly-repair",
      "developerAction": "ugs:GmailSendMessage.Body has no valid source binding and no contract-valid fallback — structured defect, property left absent",
      "estimatedEffortMinutes": 5
    },
    {
      "level": "activity",
      "file": "",
      "remediationCode": "POST_ASSEMBLY_REPAIR",
      "reason": "[MISSING_REQUIRED_PROPERTY_DEFECT] ugs:GmailSendMessage.Body has no valid source binding and no contract-valid fallback — structured defect, property left absent",
      "classifiedCheck": "post-assembly-repair",
      "developerAction": "ugs:GmailSendMessage.Body has no valid source binding and no contract-valid fallback — structured defect, property left absent",
      "estimatedEffortMinutes": 5
    },
    {
      "level": "workflow",
      "file": "Main.xaml",
      "remediationCode": "STUB_WORKFLOW_BLOCKING",
      "reason": "Pre-archive assertion: object_payload_in_target_value_slot — Object payload in target/value slot: <Assign.To><OutArgument x:TypeArguments=\"x:String\">Nothing</OutArgument></Assign.To>\n              <Assign.Value><InArgu",
      "classifiedCheck": "pre-archive-canonicalization",
      "developerAction": "Resolve object_payload_in_target_value_slot in Main.xaml",
      "estimatedEffortMinutes": 10
    },
    {
      "level": "workflow",
      "file": "GetBirthdays.xaml",
      "remediationCode": "STUB_WORKFLOW_BLOCKING",
      "reason": "Pre-archive assertion: object_payload_in_target_value_slot — Object payload in target/value slot: <Assign.To><OutArgument x:TypeArguments=\"x:String\">Nothing</OutArgument></Assign.To>\n              <Assign.Value><InArgu",
      "classifiedCheck": "pre-archive-canonicalization",
      "developerAction": "Resolve object_payload_in_target_value_slot in GetBirthdays.xaml",
      "estimatedEffortMinutes": 10
    },
    {
      "level": "workflow",
      "file": "ProcessBirthday.xaml",
      "remediationCode": "STUB_WORKFLOW_BLOCKING",
      "reason": "Pre-archive assertion: object_payload_in_target_value_slot — Object payload in target/value slot: <Assign.To><OutArgument x:TypeArguments=\"x:String\">Nothing</OutArgument></Assign.To>\n              <Assign.Value><InArgu",
      "classifiedCheck": "pre-archive-canonicalization",
      "developerAction": "Resolve object_payload_in_target_value_slot in ProcessBirthday.xaml",
      "estimatedEffortMinutes": 10
    },
    {
      "level": "workflow",
      "file": "GenerateAndValidateDraft.xaml",
      "remediationCode": "STUB_WORKFLOW_BLOCKING",
      "reason": "Pre-archive assertion: object_payload_in_target_value_slot — Object payload in target/value slot: <Assign.To><OutArgument x:TypeArguments=\"x:String\">Nothing</OutArgument></Assign.To>\n              <Assign.Value><InArgu",
      "classifiedCheck": "pre-archive-canonicalization",
      "developerAction": "Resolve object_payload_in_target_value_slot in GenerateAndValidateDraft.xaml",
      "estimatedEffortMinutes": 10
    },
    {
      "level": "workflow",
      "file": "HandleHumanReview.xaml",
      "remediationCode": "STUB_WORKFLOW_BLOCKING",
      "reason": "Pre-archive assertion: object_payload_in_target_value_slot — Object payload in target/value slot: <Assign.To><OutArgument x:TypeArguments=\"x:String\">Nothing</OutArgument></Assign.To>\n              <Assign.Value><InArgu",
      "classifiedCheck": "pre-archive-canonicalization",
      "developerAction": "Resolve object_payload_in_target_value_slot in HandleHumanReview.xaml",
      "estimatedEffortMinutes": 10
    },
    {
      "level": "workflow",
      "file": "InitAllSettings.xaml",
      "remediationCode": "STUB_WORKFLOW_BLOCKING",
      "reason": "Pre-archive assertion: malformed_attribute_quoting — Malformed attribute quoting detected: AssetName=\"[&quot;BGV26_GSuite_ServiceAccount_Credential&quot;]",
      "classifiedCheck": "pre-archive-canonicalization",
      "developerAction": "Resolve malformed_attribute_quoting in InitAllSettings.xaml",
      "estimatedEffortMinutes": 10
    }
  ],
  "propertyRemediations": [],
  "downgradeEvents": [],
  "qualityWarnings": [
    {
      "check": "placeholder-value",
      "file": "GetBirthdays",
      "detail": "Contains 1 placeholder value(s) matching \"\\bPLACEHOLDER\\b\" [Developer Implementation Required]",
      "severity": "warning",
      "stubCategory": "handoff"
    },
    {
      "check": "placeholder-value",
      "file": "ProcessBirthday",
      "detail": "Contains 1 placeholder value(s) matching \"\\bPLACEHOLDER\\b\" [Developer Implementation Required]",
      "severity": "warning",
      "stubCategory": "handoff"
    },
    {
      "check": "placeholder-value",
      "file": "HandleHumanReview",
      "detail": "Contains 1 placeholder value(s) matching \"\\bPLACEHOLDER\\b\" [Developer Implementation Required]",
      "severity": "warning",
      "stubCategory": "handoff"
    },
    {
      "check": "placeholder-value",
      "file": "GenerateAndValidateDraft",
      "detail": "Contains 1 placeholder value(s) matching \"\\bPLACEHOLDER\\b\" [Developer Implementation Required]",
      "severity": "warning",
      "stubCategory": "handoff"
    },
    {
      "check": "undeclared-asset",
      "file": "orchestrator",
      "detail": "Asset \"{type:literal,value:BGV26_BirthdaysCalendarName}\" is referenced in XAML but not declared in orchestrator artifacts",
      "severity": "warning"
    },
    {
      "check": "undeclared-asset",
      "file": "orchestrator",
      "detail": "Asset \"{type:literal,value:BGV26_TimeZone}\" is referenced in XAML but not declared in orchestrator artifacts",
      "severity": "warning"
    },
    {
      "check": "undeclared-asset",
      "file": "orchestrator",
      "detail": "Asset \"{type:literal,value:BGV26_EmailStyleSpec}\" is referenced in XAML but not declared in orchestrator artifacts",
      "severity": "warning"
    },
    {
      "check": "undeclared-asset",
      "file": "orchestrator",
      "detail": "Asset \"{type:literal,value:BGV26_EmailWordCountMin}\" is referenced in XAML but not declared in orchestrator artifacts",
      "severity": "warning"
    },
    {
      "check": "undeclared-asset",
      "file": "orchestrator",
      "detail": "Asset \"{type:literal,value:BGV26_EmailWordCountMax}\" is referenced in XAML but not declared in orchestrator artifacts",
      "severity": "warning"
    },
    {
      "check": "undeclared-asset",
      "file": "orchestrator",
      "detail": "Asset \"{type:literal,value:BGV26_AllowActionCenterFallback}\" is referenced in XAML but not declared in orchestrator artifacts",
      "severity": "warning"
    },
    {
      "check": "undeclared-asset",
      "file": "orchestrator",
      "detail": "Asset \"{type:literal,value:BGV26_GmailFromConnectionName}\" is referenced in XAML but not declared in orchestrator artifacts",
      "severity": "warning"
    },
    {
      "check": "undeclared-asset",
      "file": "orchestrator",
      "detail": "Asset \"{type:literal,value:BGV26_DedupeScope}\" is referenced in XAML but not declared in orchestrator artifacts",
      "severity": "warning"
    },
    {
      "check": "unguarded-array-index",
      "file": "ProcessBirthday.xaml",
      "detail": "Line 279: array indexing \".Rows(N)\" without a preceding row count check — may throw IndexOutOfRangeException at runtime",
      "severity": "warning"
    },
    {
      "check": "unguarded-array-index",
      "file": "ProcessBirthday.xaml",
      "detail": "Line 283: array indexing \".Rows(N)\" without a preceding row count check — may throw IndexOutOfRangeException at runtime",
      "severity": "warning"
    },
    {
      "check": "hardcoded-retry-count",
      "file": "Main.xaml",
      "detail": "Line 403: retry count hardcoded as 3 — consider externalizing to Config.xlsx (e.g., in_Config(\"MaxRetryNumber\"))",
      "severity": "warning"
    },
    {
      "check": "hardcoded-retry-interval",
      "file": "Main.xaml",
      "detail": "Line 403: retry interval hardcoded as \"00:00:05\" — consider externalizing to Config.xlsx",
      "severity": "warning"
    },
    {
      "check": "hardcoded-asset-name",
      "file": "Main.xaml",
      "detail": "Line 78: asset name \"{&quot;type&quot;:&quot;literal&quot;,&quot;value&quot;:&quot;BGV26_BirthdaysCalendarName&quot;}\" is hardcoded — consider using a Config.xlsx entry or workflow argument",
      "severity": "warning"
    },
    {
      "check": "hardcoded-asset-name",
      "file": "Main.xaml",
      "detail": "Line 118: asset name \"{&quot;type&quot;:&quot;literal&quot;,&quot;value&quot;:&quot;BGV26_TimeZone&quot;}\" is hardcoded — consider using a Config.xlsx entry or workflow argument",
      "severity": "warning"
    },
    {
      "check": "hardcoded-asset-name",
      "file": "Main.xaml",
      "detail": "Line 157: asset name \"{&quot;type&quot;:&quot;literal&quot;,&quot;value&quot;:&quot;BGV26_EmailStyleSpec&quot;}\" is hardcoded — consider using a Config.xlsx entry or workflow argument",
      "severity": "warning"
    },
    {
      "check": "hardcoded-asset-name",
      "file": "Main.xaml",
      "detail": "Line 196: asset name \"{&quot;type&quot;:&quot;literal&quot;,&quot;value&quot;:&quot;BGV26_EmailWordCountMin&quot;}\" is hardcoded — consider using a Config.xlsx entry or workflow argument",
      "severity": "warning"
    },
    {
      "check": "hardcoded-asset-name",
      "file": "Main.xaml",
      "detail": "Line 239: asset name \"{&quot;type&quot;:&quot;literal&quot;,&quot;value&quot;:&quot;BGV26_EmailWordCountMax&quot;}\" is hardcoded — consider using a Config.xlsx entry or workflow argument",
      "severity": "warning"
    },
    {
      "check": "hardcoded-asset-name",
      "file": "Main.xaml",
      "detail": "Line 282: asset name \"{&quot;type&quot;:&quot;literal&quot;,&quot;value&quot;:&quot;BGV26_AllowActionCenterFallback&quot;}\" is hardcoded — consider using a Config.xlsx entry or workflow argument",
      "severity": "warning"
    },
    {
      "check": "hardcoded-asset-name",
      "file": "Main.xaml",
      "detail": "Line 325: asset name \"{&quot;type&quot;:&quot;literal&quot;,&quot;value&quot;:&quot;BGV26_GmailFromConnectionName&quot;}\" is hardcoded — consider using a Config.xlsx entry or workflow argument",
      "severity": "warning"
    },
    {
      "check": "hardcoded-asset-name",
      "file": "Main.xaml",
      "detail": "Line 364: asset name \"{&quot;type&quot;:&quot;literal&quot;,&quot;value&quot;:&quot;BGV26_DedupeScope&quot;}\" is hardcoded — consider using a Config.xlsx entry or workflow argument",
      "severity": "warning"
    },
    {
      "check": "hardcoded-retry-count",
      "file": "GetBirthdays.xaml",
      "detail": "Line 178: retry count hardcoded as 3 — consider externalizing to Config.xlsx (e.g., in_Config(\"MaxRetryNumber\"))",
      "severity": "warning"
    },
    {
      "check": "hardcoded-retry-interval",
      "file": "GetBirthdays.xaml",
      "detail": "Line 125: retry interval hardcoded as \"{&quot;type&quot;:&quot;literal&quot;,&quot;value&quot;:&quot;00:00:05&quot;}\" — consider externalizing to Config.xlsx",
      "severity": "warning"
    },
    {
      "check": "hardcoded-retry-interval",
      "file": "GetBirthdays.xaml",
      "detail": "Line 178: retry interval hardcoded as \"00:00:05\" — consider externalizing to Config.xlsx",
      "severity": "warning"
    },
    {
      "check": "hardcoded-retry-interval",
      "file": "ProcessBirthday.xaml",
      "detail": "Line 79: retry interval hardcoded as \"{&quot;type&quot;:&quot;literal&quot;,&quot;value&quot;:&quot;00:00:05&quot;}\" — consider externalizing to Config.xlsx",
      "severity": "warning"
    },
    {
      "check": "hardcoded-retry-interval",
      "file": "ProcessBirthday.xaml",
      "detail": "Line 325: retry interval hardcoded as \"{&quot;type&quot;:&quot;literal&quot;,&quot;value&quot;:&quot;00:00:08&quot;}\" — consider externalizing to Config.xlsx",
      "severity": "warning"
    },
    {
      "check": "hardcoded-retry-count",
      "file": "GenerateAndValidateDraft.xaml",
      "detail": "Line 122: retry count hardcoded as 3 — consider externalizing to Config.xlsx (e.g., in_Config(\"MaxRetryNumber\"))",
      "severity": "warning"
    },
    {
      "check": "hardcoded-retry-interval",
      "file": "GenerateAndValidateDraft.xaml",
      "detail": "Line 79: retry interval hardcoded as \"{&quot;type&quot;:&quot;literal&quot;,&quot;value&quot;:&quot;00:00:05&quot;}\" — consider externalizing to Config.xlsx",
      "severity": "warning"
    },
    {
      "check": "hardcoded-retry-interval",
      "file": "GenerateAndValidateDraft.xaml",
      "detail": "Line 122: retry interval hardcoded as \"00:00:05\" — consider externalizing to Config.xlsx",
      "severity": "warning"
    },
    {
      "check": "hardcoded-retry-count",
      "file": "HandleHumanReview.xaml",
      "detail": "Line 141: retry count hardcoded as 3 — consider externalizing to Config.xlsx (e.g., in_Config(\"MaxRetryNumber\"))",
      "severity": "warning"
    },
    {
      "check": "hardcoded-retry-interval",
      "file": "HandleHumanReview.xaml",
      "detail": "Line 141: retry interval hardcoded as \"00:00:05\" — consider externalizing to Config.xlsx",
      "severity": "warning"
    },
    {
      "check": "hardcoded-asset-name",
      "file": "InitAllSettings.xaml",
      "detail": "Line 100: asset name \"BGV26_GSuite_ServiceAccount_Credential\" is hardcoded — consider using a Config.xlsx entry or workflow argument",
      "severity": "warning"
    },
    {
      "check": "hardcoded-asset-name",
      "file": "InitAllSettings.xaml",
      "detail": "Line 105: asset name \"BGV26_BirthdaysCalendarName\" is hardcoded — consider using a Config.xlsx entry or workflow argument",
      "severity": "warning"
    },
    {
      "check": "hardcoded-asset-name",
      "file": "InitAllSettings.xaml",
      "detail": "Line 114: asset name \"BGV26_TimeZone\" is hardcoded — consider using a Config.xlsx entry or workflow argument",
      "severity": "warning"
    },
    {
      "check": "hardcoded-asset-name",
      "file": "InitAllSettings.xaml",
      "detail": "Line 123: asset name \"BGV26_EmailStyleSpec\" is hardcoded — consider using a Config.xlsx entry or workflow argument",
      "severity": "warning"
    },
    {
      "check": "hardcoded-asset-name",
      "file": "InitAllSettings.xaml",
      "detail": "Line 132: asset name \"BGV26_EmailWordCountMin\" is hardcoded — consider using a Config.xlsx entry or workflow argument",
      "severity": "warning"
    },
    {
      "check": "hardcoded-asset-name",
      "file": "InitAllSettings.xaml",
      "detail": "Line 141: asset name \"BGV26_EmailWordCountMax\" is hardcoded — consider using a Config.xlsx entry or workflow argument",
      "severity": "warning"
    },
    {
      "check": "hardcoded-asset-name",
      "file": "InitAllSettings.xaml",
      "detail": "Line 150: asset name \"BGV26_AllowActionCenterFallback\" is hardcoded — consider using a Config.xlsx entry or workflow argument",
      "severity": "warning"
    },
    {
      "check": "hardcoded-asset-name",
      "file": "InitAllSettings.xaml",
      "detail": "Line 159: asset name \"BGV26_GmailFromConnectionName\" is hardcoded — consider using a Config.xlsx entry or workflow argument",
      "severity": "warning"
    },
    {
      "check": "hardcoded-asset-name",
      "file": "InitAllSettings.xaml",
      "detail": "Line 168: asset name \"BGV26_DedupeScope\" is hardcoded — consider using a Config.xlsx entry or workflow argument",
      "severity": "warning"
    },
    {
      "check": "COMPLEX_EXPRESSION_PASSTHROUGH",
      "file": "Main.xaml",
      "detail": "Line 71: Complex expression (lambdas, LINQ, nested calls, or 3+ operators) — emitting as-is to avoid regex corruption in expression: {&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;\\&quot;BGV26...",
      "severity": "warning"
    },
    {
      "check": "EXPRESSION_SYNTAX",
      "file": "Main.xaml",
      "detail": "Line 320: C# 'true' should be VB.NET 'True' in expression: {&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;If(String.Eq...",
      "severity": "warning"
    },
    {
      "check": "COMPLEX_EXPRESSION_PASSTHROUGH",
      "file": "GetBirthdays.xaml",
      "detail": "Line 173: Complex expression (lambdas, LINQ, nested calls, or 3+ operators) — emitting as-is to avoid regex corruption in expression: {&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;If(retryAtte...",
      "severity": "warning"
    },
    {
      "check": "COMPLEX_EXPRESSION_PASSTHROUGH",
      "file": "ProcessBirthday.xaml",
      "detail": "Line 203: Complex expression (lambdas, LINQ, nested calls, or 3+ operators) — emitting as-is to avoid regex corruption in expression: {&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;String.Join(...",
      "severity": "warning"
    },
    {
      "check": "EXPRESSION_SYNTAX",
      "file": "GenerateAndValidateDraft.xaml",
      "detail": "Line 73: C# 'true' should be VB.NET 'True' in expression: {&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;InStyleSpec ...",
      "severity": "warning"
    },
    {
      "check": "EXPRESSION_SYNTAX",
      "file": "GenerateAndValidateDraft.xaml",
      "detail": "Line 178: C# 'null' should be VB.NET 'Nothing' in expression: {&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;validationEr...",
      "severity": "warning"
    },
    {
      "check": "COMPLEX_EXPRESSION_PASSTHROUGH",
      "file": "GenerateAndValidateDraft.xaml",
      "detail": "Line 240: Complex expression (lambdas, LINQ, nested calls, or 3+ operators) — emitting as-is to avoid regex corruption in expression: {&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;validationEr...",
      "severity": "warning"
    },
    {
      "check": "COMPLEX_EXPRESSION_PASSTHROUGH",
      "file": "GenerateAndValidateDraft.xaml",
      "detail": "Line 295: Complex expression (lambdas, LINQ, nested calls, or 3+ operators) — emitting as-is to avoid regex corruption in expression: {&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;validationEr...",
      "severity": "warning"
    },
    {
      "check": "COMPLEX_EXPRESSION_PASSTHROUGH",
      "file": "GenerateAndValidateDraft.xaml",
      "detail": "Line 311: Complex expression (lambdas, LINQ, nested calls, or 3+ operators) — emitting as-is to avoid regex corruption in expression: {&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;validationEr...",
      "severity": "warning"
    },
    {
      "check": "EXPRESSION_SYNTAX",
      "file": "HandleHumanReview.xaml",
      "detail": "Line 88: Unbalanced parentheses: 0 open vs 1 close — removed 1 extra closing paren(s) | max nesting depth: 0, first imbalance near position 234, fragment: \"&amp; InFullName)&quot;}\" in expression: {&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;If(isContent...",
      "severity": "warning"
    },
    {
      "check": "BARE_TOKEN_QUOTED",
      "file": "InitAllSettings.xaml",
      "detail": "Auto-quoted bare token \"Settings\" for uexcel:ExcelReadRange.SheetName (expected String type) — wrapped in VB string quotes",
      "severity": "warning"
    },
    {
      "check": "BARE_TOKEN_QUOTED",
      "file": "InitAllSettings.xaml",
      "detail": "Auto-quoted bare token \"Constants\" for uexcel:ExcelReadRange.SheetName (expected String type) — wrapped in VB string quotes",
      "severity": "warning"
    },
    {
      "check": "BARE_TOKEN_QUOTED",
      "file": "InitAllSettings.xaml",
      "detail": "Auto-quoted bare token \"BGV26_GSuite_ServiceAccount_Credential\" for ui:GetCredential.AssetName (expected String type) — wrapped in VB string quotes",
      "severity": "warning"
    },
    {
      "check": "BARE_TOKEN_QUOTED",
      "file": "InitAllSettings.xaml",
      "detail": "Auto-quoted bare token \"BGV26_BirthdaysCalendarName\" for ui:GetAsset.AssetName (expected String type) — wrapped in VB string quotes",
      "severity": "warning"
    },
    {
      "check": "BARE_TOKEN_QUOTED",
      "file": "InitAllSettings.xaml",
      "detail": "Auto-quoted bare token \"BGV26_TimeZone\" for ui:GetAsset.AssetName (expected String type) — wrapped in VB string quotes",
      "severity": "warning"
    },
    {
      "check": "BARE_TOKEN_QUOTED",
      "file": "InitAllSettings.xaml",
      "detail": "Auto-quoted bare token \"BGV26_EmailStyleSpec\" for ui:GetAsset.AssetName (expected String type) — wrapped in VB string quotes",
      "severity": "warning"
    },
    {
      "check": "BARE_TOKEN_QUOTED",
      "file": "InitAllSettings.xaml",
      "detail": "Auto-quoted bare token \"BGV26_EmailWordCountMin\" for ui:GetAsset.AssetName (expected String type) — wrapped in VB string quotes",
      "severity": "warning"
    },
    {
      "check": "BARE_TOKEN_QUOTED",
      "file": "InitAllSettings.xaml",
      "detail": "Auto-quoted bare token \"BGV26_EmailWordCountMax\" for ui:GetAsset.AssetName (expected String type) — wrapped in VB string quotes",
      "severity": "warning"
    },
    {
      "check": "BARE_TOKEN_QUOTED",
      "file": "InitAllSettings.xaml",
      "detail": "Auto-quoted bare token \"BGV26_AllowActionCenterFallback\" for ui:GetAsset.AssetName (expected String type) — wrapped in VB string quotes",
      "severity": "warning"
    },
    {
      "check": "BARE_TOKEN_QUOTED",
      "file": "InitAllSettings.xaml",
      "detail": "Auto-quoted bare token \"BGV26_GmailFromConnectionName\" for ui:GetAsset.AssetName (expected String type) — wrapped in VB string quotes",
      "severity": "warning"
    },
    {
      "check": "BARE_TOKEN_QUOTED",
      "file": "InitAllSettings.xaml",
      "detail": "Auto-quoted bare token \"BGV26_DedupeScope\" for ui:GetAsset.AssetName (expected String type) — wrapped in VB string quotes",
      "severity": "warning"
    },
    {
      "check": "RETRY_INTERVAL_DEFAULTED",
      "file": "Main.xaml",
      "detail": "Post-repair: RetryInterval defaulted to \"00:00:05\" — verify this is appropriate for the workflow context",
      "severity": "warning"
    },
    {
      "check": "RETRY_INTERVAL_DEFAULTED",
      "file": "GetBirthdays.xaml",
      "detail": "Post-repair: RetryInterval defaulted to \"00:00:05\" — verify this is appropriate for the workflow context",
      "severity": "warning"
    },
    {
      "check": "RETRY_INTERVAL_DEFAULTED",
      "file": "GenerateAndValidateDraft.xaml",
      "detail": "Post-repair: RetryInterval defaulted to \"00:00:05\" — verify this is appropriate for the workflow context",
      "severity": "warning"
    },
    {
      "check": "RETRY_INTERVAL_DEFAULTED",
      "file": "HandleHumanReview.xaml",
      "detail": "Post-repair: RetryInterval defaulted to \"00:00:05\" — verify this is appropriate for the workflow context",
      "severity": "warning"
    }
  ],
  "totalEstimatedEffortMinutes": 145,
  "studioCompatibility": [
    {
      "file": "Main.xaml",
      "level": "studio-blocked",
      "blockers": [
        "[COMPLIANCE-FAILURE] Compliance or quality gate failure requiring manual remediation"
      ],
      "failureCategory": "compliance-failure",
      "failureSummary": "Compliance or quality gate failure requiring manual remediation"
    },
    {
      "file": "GetBirthdays.xaml",
      "level": "studio-blocked",
      "blockers": [
        "[COMPLIANCE-FAILURE] Compliance or quality gate failure requiring manual remediation"
      ],
      "failureCategory": "compliance-failure",
      "failureSummary": "Compliance or quality gate failure requiring manual remediation"
    },
    {
      "file": "ProcessBirthday.xaml",
      "level": "studio-blocked",
      "blockers": [
        "[COMPLIANCE-FAILURE] Compliance or quality gate failure requiring manual remediation"
      ],
      "failureCategory": "compliance-failure",
      "failureSummary": "Compliance or quality gate failure requiring manual remediation"
    },
    {
      "file": "GenerateAndValidateDraft.xaml",
      "level": "studio-blocked",
      "blockers": [
        "[COMPLIANCE-FAILURE] Compliance or quality gate failure requiring manual remediation"
      ],
      "failureCategory": "compliance-failure",
      "failureSummary": "Compliance or quality gate failure requiring manual remediation"
    },
    {
      "file": "HandleHumanReview.xaml",
      "level": "studio-blocked",
      "blockers": [
        "[EXPRESSION-SYNTAX] Expression syntax errors that could not be auto-corrected"
      ],
      "failureCategory": "expression-syntax",
      "failureSummary": "Expression syntax errors that could not be auto-corrected"
    },
    {
      "file": "Finalize.xaml",
      "level": "studio-blocked",
      "blockers": [
        "[XML-WELLFORMEDNESS] XML well-formedness failure in tree assembler"
      ],
      "failureCategory": "xml-wellformedness",
      "failureSummary": "XML well-formedness failure in tree assembler"
    },
    {
      "file": "InitAllSettings.xaml",
      "level": "studio-blocked",
      "blockers": [
        "[COMPLIANCE-FAILURE] Compliance or quality gate failure requiring manual remediation"
      ],
      "failureCategory": "compliance-failure",
      "failureSummary": "Compliance or quality gate failure requiring manual remediation"
    },
    {
      "file": "GetBirthdays",
      "level": "studio-blocked",
      "blockers": [
        "[COMPLIANCE-FAILURE] Compliance or quality gate failure requiring manual remediation"
      ],
      "failureCategory": "compliance-failure",
      "failureSummary": "Compliance or quality gate failure requiring manual remediation"
    },
    {
      "file": "ProcessBirthday",
      "level": "studio-blocked",
      "blockers": [
        "[COMPLIANCE-FAILURE] Compliance or quality gate failure requiring manual remediation"
      ],
      "failureCategory": "compliance-failure",
      "failureSummary": "Compliance or quality gate failure requiring manual remediation"
    },
    {
      "file": "HandleHumanReview",
      "level": "studio-blocked",
      "blockers": [
        "[COMPLIANCE-FAILURE] Compliance or quality gate failure requiring manual remediation"
      ],
      "failureCategory": "compliance-failure",
      "failureSummary": "Compliance or quality gate failure requiring manual remediation"
    },
    {
      "file": "GenerateAndValidateDraft",
      "level": "studio-blocked",
      "blockers": [
        "[COMPLIANCE-FAILURE] Compliance or quality gate failure requiring manual remediation"
      ],
      "failureCategory": "compliance-failure",
      "failureSummary": "Compliance or quality gate failure requiring manual remediation"
    }
  ],
  "invokeContractTrace": [
    {
      "callerWorkflow": "Main.xaml",
      "targetWorkflow": "GetBirthdays",
      "targetDeclaredArguments": [],
      "providedBindings": {
        "Arguments": "[{&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;New Dictionary(Of String, Object) From {{\\&quot;In_CalendarName\\&quot;, calendarName}, {\\&quot;In_TimeZone\\&quot;, timeZone}, {\\&quot;In_RunId\\&quot;, runId}, {\\&quot;Out_BirthdayWorkItems\\&quot;, Nothing}}&quot;}]",
        "Out_BirthdayWorkItems": "[{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;birthdayWorkItems&quot;}]"
      },
      "unknownTargetArguments": [
        "Arguments",
        "Out_BirthdayWorkItems"
      ],
      "missingRequiredArguments": [],
      "undeclaredSymbols": [
        "Out_BirthdayWorkItems",
        "In_CalendarName",
        "In_TimeZone",
        "In_RunId"
      ]
    },
    {
      "callerWorkflow": "Main.xaml",
      "targetWorkflow": "ProcessBirthday",
      "targetDeclaredArguments": [],
      "providedBindings": {
        "Arguments": "[{&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;New Dictionary(Of String, Object) From {{\\&quot;In_RunId\\&quot;, runId}, {\\&quot;In_FullNameRaw\\&quot;, currentFullNameRaw}, {\\&quot;In_FullNameNormalized\\&quot;, currentFullNameNormalized}, {\\&quot;In_CalendarEventId\\&quot;, currentCalendarEventId}, {\\&quot;In_EmailStyleSpec\\&quot;, emailStyleSpec}, {\\&quot;In_WordCountMin\\&quot;, wordCountMin}, {\\&quot;In_WordCountMax\\&quot;, wordCountMax}, {\\&quot;In_AllowActionCenterFallback\\&quot;, allowActionCenterFallback}, {\\&quot;In_GmailFromConnectionName\\&quot;, gmailFromConnectionName}, {\\&quot;In_DedupeScope\\&quot;, dedupeScope}, {\\&quot;Out_OutcomeStatus\\&quot;, Nothing}, {\\&quot;Out_SkipReason\\&quot;, Nothing}}&quot;}]"
      },
      "unknownTargetArguments": [
        "Arguments"
      ],
      "missingRequiredArguments": [],
      "undeclaredSymbols": [
        "In_RunId",
        "In_FullNameRaw",
        "In_FullNameNormalized",
        "In_CalendarEventId",
        "In_EmailStyleSpec",
        "In_WordCountMin",
        "In_WordCountMax",
        "In_AllowActionCenterFallback",
        "In_GmailFromConnectionName",
        "In_DedupeScope",
        "Out_OutcomeStatus",
        "Out_SkipReason"
      ]
    },
    {
      "callerWorkflow": "ProcessBirthday.xaml",
      "targetWorkflow": "HandleHumanReview",
      "targetDeclaredArguments": [],
      "providedBindings": {
        "Arguments": "[{&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;New Dictionary(Of String, Object) From {{\\&quot;InTaskType\\&quot;, \\&quot;ContactDisambiguation\\&quot;}, {\\&quot;InRunId\\&quot;, InRunId}, {\\&quot;InFullNameNormalized\\&quot;, InFullNameNormalized}, {\\&quot;InCandidateContacts\\&quot;, candidateContactsFormatted}, {\\&quot;InSentLogId\\&quot;, sentLogId}, {\\&quot;InDraftId\\&quot;, draftId}, {\\&quot;InGmailConnectionName\\&quot;, InGmailConnectionName}, {\\&quot;OutDecision\\&quot;, humanReviewOutcome}, {\\&quot;OutSelectedEmail\\&quot;, humanReviewEmail}, {\\&quot;OutApprovedSubject\\&quot;, humanReviewSubject}, {\\&quot;OutApprovedBody\\&quot;, humanReviewBody}}&quot;}]"
      },
      "unknownTargetArguments": [
        "Arguments"
      ],
      "missingRequiredArguments": [],
      "undeclaredSymbols": []
    },
    {
      "callerWorkflow": "HandleHumanReview.xaml",
      "targetWorkflow": "GenerateAndValidateDraft",
      "targetDeclaredArguments": [],
      "providedBindings": {
        "Arguments": "[{&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;New Dictionary(Of String, Object) From {{\\&quot;InFullName\\&quot;, InFullName}, {\\&quot;InStyleSpec\\&quot;, InStyleSpec}, {\\&quot;InWordCountMin\\&quot;, InWordCountMin}, {\\&quot;InWordCountMax\\&quot;, InWordCountMax}, {\\&quot;InSubjectOverride\\&quot;, approvedSubjectLocal}, {\\&quot;InBodyOverride\\&quot;, approvedBodyLocal}, {\\&quot;OutIsValid\\&quot;, revalidationIsValid}, {\\&quot;OutValidationErrors\\&quot;, revalidationErrors}, {\\&quot;OutSubject\\&quot;, revalidationSubject}, {\\&quot;OutBody\\&quot;, revalidationBody}}&quot;}]"
      },
      "unknownTargetArguments": [
        "Arguments"
      ],
      "missingRequiredArguments": [],
      "undeclaredSymbols": []
    }
  ],
  "stageHashParity": [
    {
      "workflowFile": "Main.xaml",
      "postGeneration": "1051cea5b89b2c44e1d2e65a16355646abba68e888f231a39b9bd84c29bd3258",
      "postRepair": "1051cea5b89b2c44e1d2e65a16355646abba68e888f231a39b9bd84c29bd3258",
      "postNormalization": "1051cea5b89b2c44e1d2e65a16355646abba68e888f231a39b9bd84c29bd3258",
      "preCanonicalization": "f2a17e266304c571aa81efc43041ead7fed2ec40e49496aeb6d4d28c6ae895f1",
      "archivedFile": "4d3aa2021daa709fea705da23fc9217d38ff8b1053b9a28ff0e54406e1aee57c",
      "postFinalValidationInput": "4d3aa2021daa709fea705da23fc9217d38ff8b1053b9a28ff0e54406e1aee57c",
      "preArchive": "4d3aa2021daa709fea705da23fc9217d38ff8b1053b9a28ff0e54406e1aee57c"
    },
    {
      "workflowFile": "GetBirthdays.xaml",
      "postGeneration": "19b37a725cc29d7ffd5021d34d896f0f65c254d8aa93666b93ea2c7ca3eca75f",
      "postRepair": "19b37a725cc29d7ffd5021d34d896f0f65c254d8aa93666b93ea2c7ca3eca75f",
      "postNormalization": "19b37a725cc29d7ffd5021d34d896f0f65c254d8aa93666b93ea2c7ca3eca75f",
      "preCanonicalization": "e16f95a7264925affc8a03872fb88b02c356f0bf22c34382f56215f6c90122ae",
      "archivedFile": "596456e4731485234053e5b3179b4b34ed1979de3b1dac7a8c78d000cc0a093b",
      "postFinalValidationInput": "596456e4731485234053e5b3179b4b34ed1979de3b1dac7a8c78d000cc0a093b",
      "preArchive": "596456e4731485234053e5b3179b4b34ed1979de3b1dac7a8c78d000cc0a093b"
    },
    {
      "workflowFile": "ProcessBirthday.xaml",
      "postGeneration": "eb13b38f2484a0f29a13f505d2e57fde842d82bdd92853c72a43d640da3f5d1c",
      "postRepair": "eb13b38f2484a0f29a13f505d2e57fde842d82bdd92853c72a43d640da3f5d1c",
      "postNormalization": "eb13b38f2484a0f29a13f505d2e57fde842d82bdd92853c72a43d640da3f5d1c",
      "preCanonicalization": "7dbafb0fdcbc037e701259cda69082846beb9ce85978ed72704779a9da5e0b45",
      "archivedFile": "7ed4c03a2d5a365ccfd57e69d240e853891e65486f513ec31c3f53500605f857",
      "postFinalValidationInput": "7ed4c03a2d5a365ccfd57e69d240e853891e65486f513ec31c3f53500605f857",
      "preArchive": "7ed4c03a2d5a365ccfd57e69d240e853891e65486f513ec31c3f53500605f857"
    },
    {
      "workflowFile": "GenerateAndValidateDraft.xaml",
      "postGeneration": "2e8c0288c284ae51bebb9e2395961b484f7de9bd2062fca50fe4ae88c86abc08",
      "postRepair": "2e8c0288c284ae51bebb9e2395961b484f7de9bd2062fca50fe4ae88c86abc08",
      "postNormalization": "2e8c0288c284ae51bebb9e2395961b484f7de9bd2062fca50fe4ae88c86abc08",
      "preCanonicalization": "8fc992cbef4b3ecad82711354d379b339e4896cb457665e136671bdd290fbb74",
      "archivedFile": "cc6fd67670771b37bf1d36dada9c4701465b8f675b78715008a390e7c010ee71",
      "postFinalValidationInput": "cc6fd67670771b37bf1d36dada9c4701465b8f675b78715008a390e7c010ee71",
      "preArchive": "cc6fd67670771b37bf1d36dada9c4701465b8f675b78715008a390e7c010ee71"
    },
    {
      "workflowFile": "HandleHumanReview.xaml",
      "postGeneration": "0369c75e59c8fa54be6b97e6a148c276d5621c4ab867812f017e9f6587f73235",
      "postRepair": "0369c75e59c8fa54be6b97e6a148c276d5621c4ab867812f017e9f6587f73235",
      "postNormalization": "0369c75e59c8fa54be6b97e6a148c276d5621c4ab867812f017e9f6587f73235",
      "preCanonicalization": "9447eb74d5884800b86c3d2987f56713fbd44bf405789ef3cea2cb51e5c6fe25",
      "archivedFile": "4290cad136940186018c1f7f5aafc01d1fbcf49cdeb4b3a07cc8b3529b5650d5",
      "postFinalValidationInput": "4290cad136940186018c1f7f5aafc01d1fbcf49cdeb4b3a07cc8b3529b5650d5",
      "preArchive": "4290cad136940186018c1f7f5aafc01d1fbcf49cdeb4b3a07cc8b3529b5650d5"
    },
    {
      "workflowFile": "Finalize.xaml",
      "postGeneration": "30d151e15c069bbab870160de7b34ef467634a14199a29b200f0184a8b95c9a5",
      "postRepair": "30d151e15c069bbab870160de7b34ef467634a14199a29b200f0184a8b95c9a5",
      "postNormalization": "30d151e15c069bbab870160de7b34ef467634a14199a29b200f0184a8b95c9a5",
      "preCanonicalization": "f0e47fed20ff91f6d3ac13441d9ba4d16eade3de0c2c71bb99851063b067dd1c",
      "archivedFile": "f0e47fed20ff91f6d3ac13441d9ba4d16eade3de0c2c71bb99851063b067dd1c",
      "postFinalValidationInput": "f0e47fed20ff91f6d3ac13441d9ba4d16eade3de0c2c71bb99851063b067dd1c",
      "preArchive": "f0e47fed20ff91f6d3ac13441d9ba4d16eade3de0c2c71bb99851063b067dd1c"
    },
    {
      "workflowFile": "InitAllSettings.xaml",
      "postGeneration": "645efe9f6723cd346d5cd940d19fe86ce5c283b85394fa708084fe187d6c96c8",
      "postRepair": "645efe9f6723cd346d5cd940d19fe86ce5c283b85394fa708084fe187d6c96c8",
      "postNormalization": "645efe9f6723cd346d5cd940d19fe86ce5c283b85394fa708084fe187d6c96c8",
      "preCanonicalization": "569051e3211e1316e37e1d5f58809379dd2830421beb3d5dccecb55038780d28",
      "archivedFile": "569051e3211e1316e37e1d5f58809379dd2830421beb3d5dccecb55038780d28",
      "postFinalValidationInput": "569051e3211e1316e37e1d5f58809379dd2830421beb3d5dccecb55038780d28",
      "preArchive": "569051e3211e1316e37e1d5f58809379dd2830421beb3d5dccecb55038780d28"
    },
    {
      "workflowFile": "GetBirthdays",
      "postNormalization": "d2f41e8d32dc8221f49d6a7950004a831d90b8c12a408acc7d58b70aacb4198a"
    },
    {
      "workflowFile": "ProcessBirthday",
      "postNormalization": "8b31ecf5e55e17182735399e04e5f6e1ac831ef7c9b5df99944ad9f289bcf61b"
    },
    {
      "workflowFile": "HandleHumanReview",
      "postNormalization": "afb09ea05f7d19421bc063aa97f9f4ea40c84d7a8661919b79e3c63236d10db5"
    },
    {
      "workflowFile": "GenerateAndValidateDraft",
      "postNormalization": "fe0d12729119b50076955dc590cfc68bf3d56a6f76395949584903d1e914ef87"
    }
  ],
  "preEmissionValidation": {
    "totalActivities": 0,
    "validActivities": 0,
    "unknownActivities": 0,
    "strippedProperties": 0,
    "enumCorrections": 0,
    "missingRequiredFilled": 0,
    "commentConversions": 0,
    "issueCount": 0
  },
  "invokeSerializationFixes": [
    {
      "originalForm": "Message=\"{&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;\\&quot;[Main] RunId=\\&quot; &amp; runId &amp; \\&quot; StartUtc=\\&quot; &amp; runStartTimeUtc.ToString(\\&quot;o\\&quot;)&quot;}\"",
      "canonicalizedForm": "Message=\"[\"[Main] RunId=\" & runId & \" StartUtc=\" & runStartTimeUtc.ToString(\"o\")]\"",
      "normalizationType": "json_expression_normalize",
      "file": "lib/net45/Main.xaml",
      "workflow": "Main",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "rationale": "JSON expression leak in Message normalized to VB expression"
    },
    {
      "originalForm": "Message=\"{&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;\\&quot;[Main][Asset] BGV26_BirthdaysCalendarName=\\&quot; &amp; calendarName&quot;}\"",
      "canonicalizedForm": "Message=\"[\"[Main][Asset] BGV26_BirthdaysCalendarName=\" & calendarName]\"",
      "normalizationType": "json_expression_normalize",
      "file": "lib/net45/Main.xaml",
      "workflow": "Main",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "rationale": "JSON expression leak in Message normalized to VB expression"
    },
    {
      "originalForm": "Message=\"{&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;\\&quot;[Main][Init] All assets loaded. CalendarName=\\&quot; &amp; calendarName &amp; \\&quot; TimeZone=\\&quot; &amp; timeZone &amp; \\\"",
      "canonicalizedForm": "Message=\"[\"[Main][Init] All assets loaded. CalendarName=\" & calendarName & \" TimeZone=\" & timeZone & \" WordCountMin=\" & wordCountMin.ToString() & \" WordCountMax=\" & wordCountMax.ToString() & \" AllowACFallback=\" & allowActionCenterFallback.ToString()]\"",
      "normalizationType": "json_expression_normalize",
      "file": "lib/net45/Main.xaml",
      "workflow": "Main",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "rationale": "JSON expression leak in Message normalized to VB expression"
    },
    {
      "originalForm": "Message=\"{&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;\\&quot;[Main][DataService] BGV26_Run record created. RunRecordId=\\&quot; &amp; runRecordId &amp; \\&quot; RunId=\\&quot; &amp; runId&q\"",
      "canonicalizedForm": "Message=\"[\"[Main][DataService] BGV26_Run record created. RunRecordId=\" & runRecordId & \" RunId=\" & runId]\"",
      "normalizationType": "json_expression_normalize",
      "file": "lib/net45/Main.xaml",
      "workflow": "Main",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "rationale": "JSON expression leak in Message normalized to VB expression"
    },
    {
      "originalForm": "Message=\"{&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;\\&quot;[Main][GetBirthdays] Birthday work items retrieved. Count=\\&quot; &amp; If(birthdayWorkItems Is Nothing, 0, birthdayWorkItems\"",
      "canonicalizedForm": "Message=\"[\"[Main][GetBirthdays] Birthday work items retrieved. Count=\" & If(birthdayWorkItems Is Nothing, 0, birthdayWorkItems.Rows.Count).ToString()]\"",
      "normalizationType": "json_expression_normalize",
      "file": "lib/net45/Main.xaml",
      "workflow": "Main",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "rationale": "JSON expression leak in Message normalized to VB expression"
    },
    {
      "originalForm": "Message=\"{&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;\\&quot;[Main][Decision] No birthday events found for today (\\&quot; &amp; DateTime.UtcNow.ToString(\\&quot;yyyy-MM-dd\\&quot;) &amp; \\\"",
      "canonicalizedForm": "Message=\"[\"[Main][Decision] No birthday events found for today (\" & DateTime.UtcNow.ToString(\"yyyy-MM-dd\") & \"). Job will finalize with Completed status.\"]\"",
      "normalizationType": "json_expression_normalize",
      "file": "lib/net45/Main.xaml",
      "workflow": "Main",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "rationale": "JSON expression leak in Message normalized to VB expression"
    },
    {
      "originalForm": "Message=\"{&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;\\&quot;[Main][Loop] Beginning ProcessBirthday loop. BirthdaysFound=\\&quot; &amp; birthdaysFoundCount.ToString()&quot;}\"",
      "canonicalizedForm": "Message=\"[\"[Main][Loop] Beginning ProcessBirthday loop. BirthdaysFound=\" & birthdaysFoundCount.ToString()]\"",
      "normalizationType": "json_expression_normalize",
      "file": "lib/net45/Main.xaml",
      "workflow": "Main",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "rationale": "JSON expression leak in Message normalized to VB expression"
    },
    {
      "originalForm": "Message=\"{&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;\\&quot;[Main][Loop] Processing birthday item. FullNameRaw=\\&quot; &amp; currentFullNameRaw &amp; \\&quot; FullNameNormalized=\\&quot; \"",
      "canonicalizedForm": "Message=\"[\"[Main][Loop] Processing birthday item. FullNameRaw=\" & currentFullNameRaw & \" FullNameNormalized=\" & currentFullNameNormalized & \" CalendarEventId=\" & currentCalendarEventId]\"",
      "normalizationType": "json_expression_normalize",
      "file": "lib/net45/Main.xaml",
      "workflow": "Main",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "rationale": "JSON expression leak in Message normalized to VB expression"
    },
    {
      "originalForm": "Value=\"{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;calendarName&quot;}\"",
      "canonicalizedForm": "Value=\"[calendarName]\"",
      "normalizationType": "json_expression_normalize",
      "file": "lib/net45/Main.xaml",
      "workflow": "Main",
      "activityType": "ui:GetAsset",
      "propertyName": "Value",
      "rationale": "JSON expression leak in Value normalized to VB expression"
    },
    {
      "originalForm": "Value=\"{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;timeZone&quot;}\"",
      "canonicalizedForm": "Value=\"[timeZone]\"",
      "normalizationType": "json_expression_normalize",
      "file": "lib/net45/Main.xaml",
      "workflow": "Main",
      "activityType": "ui:GetAsset",
      "propertyName": "Value",
      "rationale": "JSON expression leak in Value normalized to VB expression"
    },
    {
      "originalForm": "Value=\"{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;emailStyleSpec&quot;}\"",
      "canonicalizedForm": "Value=\"[emailStyleSpec]\"",
      "normalizationType": "json_expression_normalize",
      "file": "lib/net45/Main.xaml",
      "workflow": "Main",
      "activityType": "ui:GetAsset",
      "propertyName": "Value",
      "rationale": "JSON expression leak in Value normalized to VB expression"
    },
    {
      "originalForm": "Value=\"{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;wordCountMinStr&quot;}\"",
      "canonicalizedForm": "Value=\"[wordCountMinStr]\"",
      "normalizationType": "json_expression_normalize",
      "file": "lib/net45/Main.xaml",
      "workflow": "Main",
      "activityType": "ui:GetAsset",
      "propertyName": "Value",
      "rationale": "JSON expression leak in Value normalized to VB expression"
    },
    {
      "originalForm": "Value=\"{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;wordCountMaxStr&quot;}\"",
      "canonicalizedForm": "Value=\"[wordCountMaxStr]\"",
      "normalizationType": "json_expression_normalize",
      "file": "lib/net45/Main.xaml",
      "workflow": "Main",
      "activityType": "ui:GetAsset",
      "propertyName": "Value",
      "rationale": "JSON expression leak in Value normalized to VB expression"
    },
    {
      "originalForm": "Value=\"{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;allowActionCenterStr&quot;}\"",
      "canonicalizedForm": "Value=\"[allowActionCenterStr]\"",
      "normalizationType": "json_expression_normalize",
      "file": "lib/net45/Main.xaml",
      "workflow": "Main",
      "activityType": "ui:GetAsset",
      "propertyName": "Value",
      "rationale": "JSON expression leak in Value normalized to VB expression"
    },
    {
      "originalForm": "Value=\"{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;gmailFromConnectionName&quot;}\"",
      "canonicalizedForm": "Value=\"[gmailFromConnectionName]\"",
      "normalizationType": "json_expression_normalize",
      "file": "lib/net45/Main.xaml",
      "workflow": "Main",
      "activityType": "ui:GetAsset",
      "propertyName": "Value",
      "rationale": "JSON expression leak in Value normalized to VB expression"
    },
    {
      "originalForm": "Value=\"{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;dedupeScope&quot;}\"",
      "canonicalizedForm": "Value=\"[dedupeScope]\"",
      "normalizationType": "json_expression_normalize",
      "file": "lib/net45/Main.xaml",
      "workflow": "Main",
      "activityType": "ui:GetAsset",
      "propertyName": "Value",
      "rationale": "JSON expression leak in Value normalized to VB expression"
    },
    {
      "originalForm": "Message=\"{&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;\\&quot;[GetBirthdays] START — CalendarName='\\&quot; &amp; InCalendarName &amp; \\&quot;', TimeZone='\\&quot; &amp; InTimeZone &amp; \\&\"",
      "canonicalizedForm": "Message=\"[\"[GetBirthdays] START — CalendarName='\" & InCalendarName & \"', TimeZone='\" & InTimeZone & \"', ExecutionDate=\" & DateTime.Now.ToString(\"yyyy-MM-dd HH:mm:ss\")]\"",
      "normalizationType": "json_expression_normalize",
      "file": "lib/net45/GetBirthdays.xaml",
      "workflow": "GetBirthdays",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "rationale": "JSON expression leak in Message normalized to VB expression"
    },
    {
      "originalForm": "Message=\"{&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;\\&quot;[GetBirthdays] GoogleCalendarGetEvents attempt \\&quot; &amp; retryAttempt.ToString() &amp; \\&quot; of 3 — Calendar='\\&quot; &\"",
      "canonicalizedForm": "Message=\"[\"[GetBirthdays] GoogleCalendarGetEvents attempt \" & retryAttempt.ToString() & \" of 3 — Calendar='\" & InCalendarName & \"', Date=\" & todayDateLocal.ToString(\"yyyy-MM-dd\")]\"",
      "normalizationType": "json_expression_normalize",
      "file": "lib/net45/GetBirthdays.xaml",
      "workflow": "GetBirthdays",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "rationale": "JSON expression leak in Message normalized to VB expression"
    },
    {
      "originalForm": "Message=\"{&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;\\&quot;[GetBirthdays] GoogleCalendarGetEvents succeeded on attempt \\&quot; &amp; retryAttempt.ToString() &amp; \\&quot; — evaluating \"",
      "canonicalizedForm": "Message=\"[\"[GetBirthdays] GoogleCalendarGetEvents succeeded on attempt \" & retryAttempt.ToString() & \" — evaluating event count\"]\"",
      "normalizationType": "json_expression_normalize",
      "file": "lib/net45/GetBirthdays.xaml",
      "workflow": "GetBirthdays",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "rationale": "JSON expression leak in Message normalized to VB expression"
    },
    {
      "originalForm": "Message=\"{&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;\\&quot;[GetBirthdays] GoogleCalendarGetEvents returned null collection for date \\&quot; &amp; todayDateLocal.ToString(\\&quot;yyyy-MM\"",
      "canonicalizedForm": "Message=\"[\"[GetBirthdays] GoogleCalendarGetEvents returned null collection for date \" & todayDateLocal.ToString(\"yyyy-MM-dd\") & \" — treating as zero birthdays\"]\"",
      "normalizationType": "json_expression_normalize",
      "file": "lib/net45/GetBirthdays.xaml",
      "workflow": "GetBirthdays",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "rationale": "JSON expression leak in Message normalized to VB expression"
    },
    {
      "originalForm": "Message=\"{&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;\\&quot;[GetBirthdays] SKIP — CalendarEventId='\\&quot; &amp; calendarEventId &amp; \\&quot;' has null/empty Summary — event ignored\\&q\"",
      "canonicalizedForm": "Message=\"[\"[GetBirthdays] SKIP — CalendarEventId='\" & calendarEventId & \"' has null/empty Summary — event ignored\"]\"",
      "normalizationType": "json_expression_normalize",
      "file": "lib/net45/GetBirthdays.xaml",
      "workflow": "GetBirthdays",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "rationale": "JSON expression leak in Message normalized to VB expression"
    },
    {
      "originalForm": "Message=\"{&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;\\&quot;[GetBirthdays] Event normalized — Raw='\\&quot; &amp; fullNameRaw &amp; \\&quot;', Normalized='\\&quot; &amp; fullNameNormalized\"",
      "canonicalizedForm": "Message=\"[\"[GetBirthdays] Event normalized — Raw='\" & fullNameRaw & \"', Normalized='\" & fullNameNormalized & \"', EventId='\" & calendarEventId & \"'\"]\"",
      "normalizationType": "json_expression_normalize",
      "file": "lib/net45/GetBirthdays.xaml",
      "workflow": "GetBirthdays",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "rationale": "JSON expression leak in Message normalized to VB expression"
    },
    {
      "originalForm": "Message=\"{&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;\\&quot;[GetBirthdays] COMPLETE — Date=\\&quot; &amp; todayDateLocal.ToString(\\&quot;yyyy-MM-dd\\&quot;) &amp; \\&quot;, BirthdaysFound=\"",
      "canonicalizedForm": "Message=\"[\"[GetBirthdays] COMPLETE — Date=\" & todayDateLocal.ToString(\"yyyy-MM-dd\") & \", BirthdaysFound=\" & birthdaysFoundCount.ToString() & \", TimeZone='\" & InTimeZone & \"'\"]\"",
      "normalizationType": "json_expression_normalize",
      "file": "lib/net45/GetBirthdays.xaml",
      "workflow": "GetBirthdays",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "rationale": "JSON expression leak in Message normalized to VB expression"
    },
    {
      "originalForm": "Message=\"{&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;\\&quot;[ProcessBirthday][Start] Processing birthday for '\\&quot; &amp; InFullNameNormalized &amp; \\&quot;' | RunId=\\&quot; &amp; InR\"",
      "canonicalizedForm": "Message=\"[\"[ProcessBirthday][Start] Processing birthday for '\" & InFullNameNormalized & \"' | RunId=\" & InRunId & \" | EventId=\" & InCalendarEventId]\"",
      "normalizationType": "json_expression_normalize",
      "file": "lib/net45/ProcessBirthday.xaml",
      "workflow": "ProcessBirthday",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "rationale": "JSON expression leak in Message normalized to VB expression"
    },
    {
      "originalForm": "Message=\"{&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;\\&quot;[ProcessBirthday][ContactLookup] Found \\&quot; &amp; If(contactSearchResults Is Nothing, 0, contactSearchResults.Rows.Count).\"",
      "canonicalizedForm": "Message=\"[\"[ProcessBirthday][ContactLookup] Found \" & If(contactSearchResults Is Nothing, 0, contactSearchResults.Rows.Count).ToString() & \" contact(s) for '\" & InFullNameNormalized & \"'\"]\"",
      "normalizationType": "json_expression_normalize",
      "file": "lib/net45/ProcessBirthday.xaml",
      "workflow": "ProcessBirthday",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "rationale": "JSON expression leak in Message normalized to VB expression"
    },
    {
      "originalForm": "Message=\"{&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;\\&quot;[ProcessBirthday][Skip] No Google Contact found for '\\&quot; &amp; InFullNameNormalized &amp; \\&quot;' — skipping. RunId=\\&qu\"",
      "canonicalizedForm": "Message=\"[\"[ProcessBirthday][Skip] No Google Contact found for '\" & InFullNameNormalized & \"' — skipping. RunId=\" & InRunId]\"",
      "normalizationType": "json_expression_normalize",
      "file": "lib/net45/ProcessBirthday.xaml",
      "workflow": "ProcessBirthday",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "rationale": "JSON expression leak in Message normalized to VB expression"
    },
    {
      "originalForm": "Message=\"{&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;\\&quot;[ProcessBirthday][AmbiguousContact] \\&quot; &amp; contactCount.ToString() &amp; \\&quot; contacts found for '\\&quot; &amp; InF\"",
      "canonicalizedForm": "Message=\"[\"[ProcessBirthday][AmbiguousContact] \" & contactCount.ToString() & \" contacts found for '\" & InFullNameNormalized & \"'. AllowACFallback=\" & InAllowActionCenterFallback.ToString() & \" | RunId=\" & InRunId]\"",
      "normalizationType": "json_expression_normalize",
      "file": "lib/net45/ProcessBirthday.xaml",
      "workflow": "ProcessBirthday",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "rationale": "JSON expression leak in Message normalized to VB expression"
    },
    {
      "originalForm": "Message=\"{&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;\\&quot;[ProcessBirthday][EmailSelected] Recipient email selected for '\\&quot; &amp; InFullNameNormalized &amp; \\&quot;': \\&quot; &am\"",
      "canonicalizedForm": "Message=\"[\"[ProcessBirthday][EmailSelected] Recipient email selected for '\" & InFullNameNormalized & \"': \" & selectedEmail & \" | RunId=\" & InRunId]\"",
      "normalizationType": "json_expression_normalize",
      "file": "lib/net45/ProcessBirthday.xaml",
      "workflow": "ProcessBirthday",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "rationale": "JSON expression leak in Message normalized to VB expression"
    },
    {
      "originalForm": "Message=\"{&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;\\&quot;[ProcessBirthday][DedupeCheck] AlreadySentThisYear=\\&quot; &amp; alreadySentThisYear.ToString() &amp; \\&quot; for '\\&quot; &a\"",
      "canonicalizedForm": "Message=\"[\"[ProcessBirthday][DedupeCheck] AlreadySentThisYear=\" & alreadySentThisYear.ToString() & \" for '\" & InFullNameNormalized & \"' year=\" & greetingYear.ToString() & \" | RunId=\" & InRunId]\"",
      "normalizationType": "json_expression_normalize",
      "file": "lib/net45/ProcessBirthday.xaml",
      "workflow": "ProcessBirthday",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "rationale": "JSON expression leak in Message normalized to VB expression"
    },
    {
      "originalForm": "Result=\"{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;contactSearchResults&quot;}\"",
      "canonicalizedForm": "Result=\"[contactSearchResults]\"",
      "normalizationType": "json_expression_normalize",
      "file": "lib/net45/ProcessBirthday.xaml",
      "workflow": "ProcessBirthday",
      "activityType": "ugs:GoogleContactsSearchContacts",
      "propertyName": "Result",
      "rationale": "JSON expression leak in Result normalized to VB expression"
    },
    {
      "originalForm": "Result=\"{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;dedupeQueryResults&quot;}\"",
      "canonicalizedForm": "Result=\"[dedupeQueryResults]\"",
      "normalizationType": "json_expression_normalize",
      "file": "lib/net45/ProcessBirthday.xaml",
      "workflow": "ProcessBirthday",
      "activityType": "uds:QueryEntity",
      "propertyName": "Result",
      "rationale": "JSON expression leak in Result normalized to VB expression"
    },
    {
      "originalForm": "Message=\"{&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;\\&quot;[GenerateAndValidateDraft] START — FullName='\\&quot; &amp; InFullName &amp; \\&quot;' WordCountRange=[\\&quot; &amp; InWordCoun\"",
      "canonicalizedForm": "Message=\"[\"[GenerateAndValidateDraft] START — FullName='\" & InFullName & \"' WordCountRange=[\" & InWordCountMin & \",\" & InWordCountMax & \"]']\"",
      "normalizationType": "json_expression_normalize",
      "file": "lib/net45/GenerateAndValidateDraft.xaml",
      "workflow": "GenerateAndValidateDraft",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "rationale": "JSON expression leak in Message normalized to VB expression"
    },
    {
      "originalForm": "Message=\"{&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;\\&quot;[GenerateAndValidateDraft] GenAI prompt assembled (length=\\&quot; &amp; genAiPrompt.Length.ToString() &amp; \\&quot;) for '\\&q\"",
      "canonicalizedForm": "Message=\"[\"[GenerateAndValidateDraft] GenAI prompt assembled (length=\" & genAiPrompt.Length.ToString() & \") for '\" & InFullName & \"'\"]\"",
      "normalizationType": "json_expression_normalize",
      "file": "lib/net45/GenerateAndValidateDraft.xaml",
      "workflow": "GenerateAndValidateDraft",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "rationale": "JSON expression leak in Message normalized to VB expression"
    },
    {
      "originalForm": "Message=\"{&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;\\&quot;[GenerateAndValidateDraft] GenAI raw response received (length=\\&quot; &amp; If(genAiRawResponse Is Nothing, \\&quot;NULL\\&quo\"",
      "canonicalizedForm": "Message=\"[\"[GenerateAndValidateDraft] GenAI raw response received (length=\" & If(genAiRawResponse Is Nothing, \"NULL\", genAiRawResponse.Length.ToString()) & \") for '\" & InFullName & \"'\"]\"",
      "normalizationType": "json_expression_normalize",
      "file": "lib/net45/GenerateAndValidateDraft.xaml",
      "workflow": "GenerateAndValidateDraft",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "rationale": "JSON expression leak in Message normalized to VB expression"
    },
    {
      "originalForm": "Message=\"{&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;\\&quot;[GenerateAndValidateDraft] ERROR — GenAI response is null/empty for '\\&quot; &amp; InFullName &amp; \\&quot;'. Will flag for h\"",
      "canonicalizedForm": "Message=\"[\"[GenerateAndValidateDraft] ERROR — GenAI response is null/empty for '\" & InFullName & \"'. Will flag for human review.\"]\"",
      "normalizationType": "json_expression_normalize",
      "file": "lib/net45/GenerateAndValidateDraft.xaml",
      "workflow": "GenerateAndValidateDraft",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "rationale": "JSON expression leak in Message normalized to VB expression"
    },
    {
      "originalForm": "Message=\"{&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;\\&quot;[GenerateAndValidateDraft] GenAI JSON parsed successfully for '\\&quot; &amp; InFullName &amp; \\&quot;'\\&quot;&quot;}\"",
      "canonicalizedForm": "Message=\"[\"[GenerateAndValidateDraft] GenAI JSON parsed successfully for '\" & InFullName & \"'\"]\"",
      "normalizationType": "json_expression_normalize",
      "file": "lib/net45/GenerateAndValidateDraft.xaml",
      "workflow": "GenerateAndValidateDraft",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "rationale": "JSON expression leak in Message normalized to VB expression"
    },
    {
      "originalForm": "Message=\"{&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;\\&quot;[GenerateAndValidateDraft] Extracted — Subject length=\\&quot; &amp; parsedSubject.Length.ToString() &amp; \\&quot; Body length\"",
      "canonicalizedForm": "Message=\"[\"[GenerateAndValidateDraft] Extracted — Subject length=\" & parsedSubject.Length.ToString() & \" Body length=\" & parsedBody.Length.ToString() & \" for '\" & InFullName & \"'\"]\"",
      "normalizationType": "json_expression_normalize",
      "file": "lib/net45/GenerateAndValidateDraft.xaml",
      "workflow": "GenerateAndValidateDraft",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "rationale": "JSON expression leak in Message normalized to VB expression"
    },
    {
      "originalForm": "Message=\"{&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;\\&quot;[GenerateAndValidateDraft] WordCount=\\&quot; &amp; wordCount.ToString() &amp; \\&quot; (allowed \\&quot; &amp; InWordCountMin.T\"",
      "canonicalizedForm": "Message=\"[\"[GenerateAndValidateDraft] WordCount=\" & wordCount.ToString() & \" (allowed \" & InWordCountMin.ToString() & \"-\" & InWordCountMax.ToString() & \") for '\" & InFullName & \"'\"]\"",
      "normalizationType": "json_expression_normalize",
      "file": "lib/net45/GenerateAndValidateDraft.xaml",
      "workflow": "GenerateAndValidateDraft",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "rationale": "JSON expression leak in Message normalized to VB expression"
    },
    {
      "originalForm": "Message=\"{&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;\\&quot;[GenerateAndValidateDraft] EmojiCheck=\\&quot; &amp; containsEmoji.ToString() &amp; \\&quot; for '\\&quot; &amp; InFullName &amp\"",
      "canonicalizedForm": "Message=\"[\"[GenerateAndValidateDraft] EmojiCheck=\" & containsEmoji.ToString() & \" for '\" & InFullName & \"'\"]\"",
      "normalizationType": "json_expression_normalize",
      "file": "lib/net45/GenerateAndValidateDraft.xaml",
      "workflow": "GenerateAndValidateDraft",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "rationale": "JSON expression leak in Message normalized to VB expression"
    },
    {
      "originalForm": "Message=\"{&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;\\&quot;[HandleHumanReview] ENTER ReviewType=\\&quot; &amp; InReviewType &amp; \\&quot; FullName=\\&quot; &amp; InFullName &amp; \\&quot;\"",
      "canonicalizedForm": "Message=\"[\"[HandleHumanReview] ENTER ReviewType=\" & InReviewType & \" FullName=\" & InFullName & \" RunId=\" & InRunId & \" SentLogId=\" & InSentLogId & \" DraftId=\" & InDraftId]\"",
      "normalizationType": "json_expression_normalize",
      "file": "lib/net45/HandleHumanReview.xaml",
      "workflow": "HandleHumanReview",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "rationale": "JSON expression leak in Message normalized to VB expression"
    },
    {
      "originalForm": "Message=\"{&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;\\&quot;[HandleHumanReview] Creating Action Center task Title=\\&quot; &amp; taskTitle &amp; \\&quot; Schema=\\&quot; &amp; taskFormSche\"",
      "canonicalizedForm": "Message=\"[\"[HandleHumanReview] Creating Action Center task Title=\" & taskTitle & \" Schema=\" & taskFormSchemaPath & \" RunId=\" & InRunId]\"",
      "normalizationType": "json_expression_normalize",
      "file": "lib/net45/HandleHumanReview.xaml",
      "workflow": "HandleHumanReview",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "rationale": "JSON expression leak in Message normalized to VB expression"
    },
    {
      "originalForm": "Message=\"{&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;\\&quot;[HandleHumanReview] Action Center task created. RunId=\\&quot; &amp; InRunId &amp; \\&quot; FullName=\\&quot; &amp; InFullName &\"",
      "canonicalizedForm": "Message=\"[\"[HandleHumanReview] Action Center task created. RunId=\" & InRunId & \" FullName=\" & InFullName & \" ReviewType=\" & InReviewType]\"",
      "normalizationType": "json_expression_normalize",
      "file": "lib/net45/HandleHumanReview.xaml",
      "workflow": "HandleHumanReview",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "rationale": "JSON expression leak in Message normalized to VB expression"
    },
    {
      "originalForm": "Message=\"{&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;\\&quot;[HandleHumanReview] Task resumed. TimedOut=\\&quot; &amp; taskTimedOut.ToString() &amp; \\&quot; RunId=\\&quot; &amp; InRunId &a\"",
      "canonicalizedForm": "Message=\"[\"[HandleHumanReview] Task resumed. TimedOut=\" & taskTimedOut.ToString() & \" RunId=\" & InRunId & \" FullName=\" & InFullName]\"",
      "normalizationType": "json_expression_normalize",
      "file": "lib/net45/HandleHumanReview.xaml",
      "workflow": "HandleHumanReview",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "rationale": "JSON expression leak in Message normalized to VB expression"
    },
    {
      "originalForm": "Message=\"{&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;\\&quot;[HandleHumanReview] SLA TIMEOUT. FullName=\\&quot; &amp; InFullName &amp; \\&quot; RunId=\\&quot; &amp; InRunId &amp; \\&quot; No\"",
      "canonicalizedForm": "Message=\"[\"[HandleHumanReview] SLA TIMEOUT. FullName=\" & InFullName & \" RunId=\" & InRunId & \" NowLocal=\" & nowLocal.ToString(\"yyyy-MM-dd HH:mm:ss\") & \" BeyondCutoff=\" & isBeyondCutoff.ToString()]\"",
      "normalizationType": "json_expression_normalize",
      "file": "lib/net45/HandleHumanReview.xaml",
      "workflow": "HandleHumanReview",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "rationale": "JSON expression leak in Message normalized to VB expression"
    },
    {
      "originalForm": "Message=\"{&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;\\&quot;[HandleHumanReview] Escalation email sent to ninemush@gmail.com. FullName=\\&quot; &amp; InFullName &amp; \\&quot; RunId=\\&quot\"",
      "canonicalizedForm": "Message=\"[\"[HandleHumanReview] Escalation email sent to ninemush@gmail.com. FullName=\" & InFullName & \" RunId=\" & InRunId]\"",
      "normalizationType": "json_expression_normalize",
      "file": "lib/net45/HandleHumanReview.xaml",
      "workflow": "HandleHumanReview",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "rationale": "JSON expression leak in Message normalized to VB expression"
    },
    {
      "originalForm": "Message=\"{&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;\\&quot;[HandleHumanReview] Reviewer decision extracted. Decision=\\&quot; &amp; taskDecisionRaw &amp; \\&quot; FullName=\\&quot; &amp; \"",
      "canonicalizedForm": "Message=\"[\"[HandleHumanReview] Reviewer decision extracted. Decision=\" & taskDecisionRaw & \" FullName=\" & InFullName & \" RunId=\" & InRunId]\"",
      "normalizationType": "json_expression_normalize",
      "file": "lib/net45/HandleHumanReview.xaml",
      "workflow": "HandleHumanReview",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "rationale": "JSON expression leak in Message normalized to VB expression"
    },
    {
      "originalForm": "Result=\"{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;taskOutcome&quot;}\"",
      "canonicalizedForm": "Result=\"[taskOutcome]\"",
      "normalizationType": "json_expression_normalize",
      "file": "lib/net45/HandleHumanReview.xaml",
      "workflow": "HandleHumanReview",
      "activityType": "upers:WaitForFormTaskAndResume",
      "propertyName": "Result",
      "rationale": "JSON expression leak in Result normalized to VB expression"
    }
  ],
  "expressionCanonicalizationFixes": [],
  "symbolScopeDefects": [
    {
      "file": "lib/net45/Main.xaml",
      "workflow": "Main",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "referencedSymbol": "runId",
      "offendingExpression": "[&quot;[Main] RunId=&quot; &amp; runId &amp; &quot; StartUtc=&quot; &amp; runStartTimeUtc.ToString(&quot;o&quot;)]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"runId\" referenced in Message but not declared in workflow \"Main\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/Main.xaml",
      "workflow": "Main",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "referencedSymbol": "runStartTimeUtc",
      "offendingExpression": "[&quot;[Main] RunId=&quot; &amp; runId &amp; &quot; StartUtc=&quot; &amp; runStartTimeUtc.ToString(&quot;o&quot;)]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"runStartTimeUtc\" referenced in Message but not declared in workflow \"Main\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/Main.xaml",
      "workflow": "Main",
      "activityType": "ui:GetAsset",
      "propertyName": "Value",
      "referencedSymbol": "calendarName",
      "offendingExpression": "[calendarName]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"calendarName\" referenced in Value but not declared in workflow \"Main\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/Main.xaml",
      "workflow": "Main",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "referencedSymbol": "calendarName",
      "offendingExpression": "[&quot;[Main][Asset] BGV26_BirthdaysCalendarName=&quot; &amp; calendarName]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"calendarName\" referenced in Message but not declared in workflow \"Main\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/Main.xaml",
      "workflow": "Main",
      "activityType": "ui:GetAsset",
      "propertyName": "Value",
      "referencedSymbol": "timeZone",
      "offendingExpression": "[timeZone]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"timeZone\" referenced in Value but not declared in workflow \"Main\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/Main.xaml",
      "workflow": "Main",
      "activityType": "ui:GetAsset",
      "propertyName": "Value",
      "referencedSymbol": "emailStyleSpec",
      "offendingExpression": "[emailStyleSpec]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"emailStyleSpec\" referenced in Value but not declared in workflow \"Main\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/Main.xaml",
      "workflow": "Main",
      "activityType": "ui:GetAsset",
      "propertyName": "Value",
      "referencedSymbol": "wordCountMinStr",
      "offendingExpression": "[wordCountMinStr]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"wordCountMinStr\" referenced in Value but not declared in workflow \"Main\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/Main.xaml",
      "workflow": "Main",
      "activityType": "ui:GetAsset",
      "propertyName": "Value",
      "referencedSymbol": "wordCountMaxStr",
      "offendingExpression": "[wordCountMaxStr]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"wordCountMaxStr\" referenced in Value but not declared in workflow \"Main\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/Main.xaml",
      "workflow": "Main",
      "activityType": "ui:GetAsset",
      "propertyName": "Value",
      "referencedSymbol": "allowActionCenterStr",
      "offendingExpression": "[allowActionCenterStr]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"allowActionCenterStr\" referenced in Value but not declared in workflow \"Main\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/Main.xaml",
      "workflow": "Main",
      "activityType": "ui:GetAsset",
      "propertyName": "Value",
      "referencedSymbol": "gmailFromConnectionName",
      "offendingExpression": "[gmailFromConnectionName]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"gmailFromConnectionName\" referenced in Value but not declared in workflow \"Main\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/Main.xaml",
      "workflow": "Main",
      "activityType": "ui:GetAsset",
      "propertyName": "Value",
      "referencedSymbol": "dedupeScope",
      "offendingExpression": "[dedupeScope]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"dedupeScope\" referenced in Value but not declared in workflow \"Main\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/Main.xaml",
      "workflow": "Main",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "referencedSymbol": "calendarName",
      "offendingExpression": "[&quot;[Main][Init] All assets loaded. CalendarName=&quot; &amp; calendarName &amp; &quot; TimeZone=&quot; &amp; timeZone &amp; &quot; WordCountMin=&quot; &amp; wordCountMin.ToString() &amp; &quot; Wo",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"calendarName\" referenced in Message but not declared in workflow \"Main\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/Main.xaml",
      "workflow": "Main",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "referencedSymbol": "timeZone",
      "offendingExpression": "[&quot;[Main][Init] All assets loaded. CalendarName=&quot; &amp; calendarName &amp; &quot; TimeZone=&quot; &amp; timeZone &amp; &quot; WordCountMin=&quot; &amp; wordCountMin.ToString() &amp; &quot; Wo",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"timeZone\" referenced in Message but not declared in workflow \"Main\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/Main.xaml",
      "workflow": "Main",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "referencedSymbol": "wordCountMin",
      "offendingExpression": "[&quot;[Main][Init] All assets loaded. CalendarName=&quot; &amp; calendarName &amp; &quot; TimeZone=&quot; &amp; timeZone &amp; &quot; WordCountMin=&quot; &amp; wordCountMin.ToString() &amp; &quot; Wo",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"wordCountMin\" referenced in Message but not declared in workflow \"Main\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/Main.xaml",
      "workflow": "Main",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "referencedSymbol": "wordCountMax",
      "offendingExpression": "[&quot;[Main][Init] All assets loaded. CalendarName=&quot; &amp; calendarName &amp; &quot; TimeZone=&quot; &amp; timeZone &amp; &quot; WordCountMin=&quot; &amp; wordCountMin.ToString() &amp; &quot; Wo",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"wordCountMax\" referenced in Message but not declared in workflow \"Main\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/Main.xaml",
      "workflow": "Main",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "referencedSymbol": "allowActionCenterFallback",
      "offendingExpression": "[&quot;[Main][Init] All assets loaded. CalendarName=&quot; &amp; calendarName &amp; &quot; TimeZone=&quot; &amp; timeZone &amp; &quot; WordCountMin=&quot; &amp; wordCountMin.ToString() &amp; &quot; Wo",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"allowActionCenterFallback\" referenced in Message but not declared in workflow \"Main\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/Main.xaml",
      "workflow": "Main",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "referencedSymbol": "runRecordId",
      "offendingExpression": "[&quot;[Main][DataService] BGV26_Run record created. RunRecordId=&quot; &amp; runRecordId &amp; &quot; RunId=&quot; &amp; runId]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"runRecordId\" referenced in Message but not declared in workflow \"Main\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/Main.xaml",
      "workflow": "Main",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "referencedSymbol": "runId",
      "offendingExpression": "[&quot;[Main][DataService] BGV26_Run record created. RunRecordId=&quot; &amp; runRecordId &amp; &quot; RunId=&quot; &amp; runId]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"runId\" referenced in Message but not declared in workflow \"Main\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/Main.xaml",
      "workflow": "Main",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "referencedSymbol": "birthdayWorkItems",
      "offendingExpression": "[&quot;[Main][GetBirthdays] Birthday work items retrieved. Count=&quot; &amp; If(birthdayWorkItems Is Nothing, 0, birthdayWorkItems.Rows.Count).ToString()]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"birthdayWorkItems\" referenced in Message but not declared in workflow \"Main\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/Main.xaml",
      "workflow": "Main",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "referencedSymbol": "birthdaysFoundCount",
      "offendingExpression": "[&quot;[Main][Loop] Beginning ProcessBirthday loop. BirthdaysFound=&quot; &amp; birthdaysFoundCount.ToString()]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"birthdaysFoundCount\" referenced in Message but not declared in workflow \"Main\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/Main.xaml",
      "workflow": "Main",
      "activityType": "ForEach",
      "propertyName": "Values",
      "referencedSymbol": "birthdayWorkItems",
      "offendingExpression": "[birthdayWorkItems.AsEnumerable()]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"birthdayWorkItems\" referenced in Values but not declared in workflow \"Main\" — expression replaced with \"Nothing\""
    },
    {
      "file": "lib/net45/Main.xaml",
      "workflow": "Main",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "referencedSymbol": "currentFullNameRaw",
      "offendingExpression": "[&quot;[Main][Loop] Processing birthday item. FullNameRaw=&quot; &amp; currentFullNameRaw &amp; &quot; FullNameNormalized=&quot; &amp; currentFullNameNormalized &amp; &quot; CalendarEventId=&quot; &am",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"currentFullNameRaw\" referenced in Message but not declared in workflow \"Main\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/Main.xaml",
      "workflow": "Main",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "referencedSymbol": "currentFullNameNormalized",
      "offendingExpression": "[&quot;[Main][Loop] Processing birthday item. FullNameRaw=&quot; &amp; currentFullNameRaw &amp; &quot; FullNameNormalized=&quot; &amp; currentFullNameNormalized &amp; &quot; CalendarEventId=&quot; &am",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"currentFullNameNormalized\" referenced in Message but not declared in workflow \"Main\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/Main.xaml",
      "workflow": "Main",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "referencedSymbol": "currentCalendarEventId",
      "offendingExpression": "[&quot;[Main][Loop] Processing birthday item. FullNameRaw=&quot; &amp; currentFullNameRaw &amp; &quot; FullNameNormalized=&quot; &amp; currentFullNameNormalized &amp; &quot; CalendarEventId=&quot; &am",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"currentCalendarEventId\" referenced in Message but not declared in workflow \"Main\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/Main.xaml",
      "workflow": "Main",
      "activityType": "Assign",
      "propertyName": "Value",
      "referencedSymbol": "wordCountMinStr",
      "offendingExpression": "[If(Integer.TryParse(wordCountMinStr, Nothing), Integer.Parse(wordCountMinStr), 40)]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"wordCountMinStr\" referenced in child element <Assign.Value> but not declared in workflow \"Main\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/Main.xaml",
      "workflow": "Main",
      "activityType": "Assign",
      "propertyName": "Value",
      "referencedSymbol": "wordCountMaxStr",
      "offendingExpression": "[If(Integer.TryParse(wordCountMaxStr, Nothing), Integer.Parse(wordCountMaxStr), 90)]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"wordCountMaxStr\" referenced in child element <Assign.Value> but not declared in workflow \"Main\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/Main.xaml",
      "workflow": "Main",
      "activityType": "Assign",
      "propertyName": "Value",
      "referencedSymbol": "birthdayWorkItems",
      "offendingExpression": "[If(birthdayWorkItems IsNot Nothing, birthdayWorkItems.Rows.Count, 0)]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"birthdayWorkItems\" referenced in child element <Assign.Value> but not declared in workflow \"Main\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/GetBirthdays.xaml",
      "workflow": "GetBirthdays",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "referencedSymbol": "retryAttempt",
      "offendingExpression": "[&quot;[GetBirthdays] GoogleCalendarGetEvents attempt &quot; &amp; retryAttempt.ToString() &amp; &quot; of 3 — Calendar=&apos;&quot; &amp; InCalendarName &amp; &quot;&apos;, Date=&quot; &amp; todayDat",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"retryAttempt\" referenced in Message but not declared in workflow \"GetBirthdays\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/GetBirthdays.xaml",
      "workflow": "GetBirthdays",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "referencedSymbol": "todayDateLocal",
      "offendingExpression": "[&quot;[GetBirthdays] GoogleCalendarGetEvents attempt &quot; &amp; retryAttempt.ToString() &amp; &quot; of 3 — Calendar=&apos;&quot; &amp; InCalendarName &amp; &quot;&apos;, Date=&quot; &amp; todayDat",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"todayDateLocal\" referenced in Message but not declared in workflow \"GetBirthdays\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/GetBirthdays.xaml",
      "workflow": "GetBirthdays",
      "activityType": "If",
      "propertyName": "Condition",
      "referencedSymbol": "fullNameRaw",
      "offendingExpression": "[String.IsNullOrWhiteSpace(fullNameRaw)]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "False",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"fullNameRaw\" referenced in Condition but not declared in workflow \"GetBirthdays\" — expression replaced with \"False\""
    },
    {
      "file": "lib/net45/GetBirthdays.xaml",
      "workflow": "GetBirthdays",
      "activityType": "Assign",
      "propertyName": "Value",
      "referencedSymbol": "todayDateLocal",
      "offendingExpression": "[todayDateLocal.AddDays(1).AddSeconds(-1)]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"todayDateLocal\" referenced in child element <Assign.Value> but not declared in workflow \"GetBirthdays\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/GetBirthdays.xaml",
      "workflow": "GetBirthdays",
      "activityType": "Assign",
      "propertyName": "Value",
      "referencedSymbol": "retryAttempt",
      "offendingExpression": "[retryAttempt + 1]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"retryAttempt\" referenced in child element <Assign.Value> but not declared in workflow \"GetBirthdays\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/GetBirthdays.xaml",
      "workflow": "GetBirthdays",
      "activityType": "Assign",
      "propertyName": "Value",
      "referencedSymbol": "currentEvent",
      "offendingExpression": "[CType(currentEvent, Google.Apis.Calendar.v3.Data.Event).Summary]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"currentEvent\" referenced in child element <Assign.Value> but not declared in workflow \"GetBirthdays\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/GetBirthdays.xaml",
      "workflow": "GetBirthdays",
      "activityType": "Assign",
      "propertyName": "Value",
      "referencedSymbol": "currentEvent",
      "offendingExpression": "[CType(currentEvent, Google.Apis.Calendar.v3.Data.Event).Id]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"currentEvent\" referenced in child element <Assign.Value> but not declared in workflow \"GetBirthdays\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/GetBirthdays.xaml",
      "workflow": "GetBirthdays",
      "activityType": "Assign",
      "propertyName": "Value",
      "referencedSymbol": "birthdaysFoundCount",
      "offendingExpression": "[birthdaysFoundCount + 1]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"birthdaysFoundCount\" referenced in child element <Assign.Value> but not declared in workflow \"GetBirthdays\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/ProcessBirthday.xaml",
      "workflow": "ProcessBirthday",
      "activityType": "ugs:GoogleContactsSearchContacts",
      "propertyName": "Result",
      "referencedSymbol": "contactSearchResults",
      "offendingExpression": "[contactSearchResults]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "execution_blocking",
      "rationale": "Variable \"contactSearchResults\" referenced in Result but not declared in workflow \"ProcessBirthday\" — expression replaced with \"Nothing\""
    },
    {
      "file": "lib/net45/ProcessBirthday.xaml",
      "workflow": "ProcessBirthday",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "referencedSymbol": "contactCount",
      "offendingExpression": "[&quot;[ProcessBirthday][AmbiguousContact] &quot; &amp; contactCount.ToString() &amp; &quot; contacts found for &apos;&quot; &amp; InFullNameNormalized &amp; &quot;&apos;. AllowACFallback=&quot; &amp;",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"contactCount\" referenced in Message but not declared in workflow \"ProcessBirthday\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/ProcessBirthday.xaml",
      "workflow": "ProcessBirthday",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "referencedSymbol": "selectedEmail",
      "offendingExpression": "[&quot;[ProcessBirthday][EmailSelected] Recipient email selected for &apos;&quot; &amp; InFullNameNormalized &amp; &quot;&apos;: &quot; &amp; selectedEmail &amp; &quot; | RunId=&quot; &amp; InRunId]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"selectedEmail\" referenced in Message but not declared in workflow \"ProcessBirthday\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/ProcessBirthday.xaml",
      "workflow": "ProcessBirthday",
      "activityType": "uds:QueryEntity",
      "propertyName": "Result",
      "referencedSymbol": "dedupeQueryResults",
      "offendingExpression": "[dedupeQueryResults]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "execution_blocking",
      "rationale": "Variable \"dedupeQueryResults\" referenced in Result but not declared in workflow \"ProcessBirthday\" — expression replaced with \"Nothing\""
    },
    {
      "file": "lib/net45/ProcessBirthday.xaml",
      "workflow": "ProcessBirthday",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "referencedSymbol": "alreadySentThisYear",
      "offendingExpression": "[&quot;[ProcessBirthday][DedupeCheck] AlreadySentThisYear=&quot; &amp; alreadySentThisYear.ToString() &amp; &quot; for &apos;&quot; &amp; InFullNameNormalized &amp; &quot;&apos; year=&quot; &amp; gree",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"alreadySentThisYear\" referenced in Message but not declared in workflow \"ProcessBirthday\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/ProcessBirthday.xaml",
      "workflow": "ProcessBirthday",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "referencedSymbol": "greetingYear",
      "offendingExpression": "[&quot;[ProcessBirthday][DedupeCheck] AlreadySentThisYear=&quot; &amp; alreadySentThisYear.ToString() &amp; &quot; for &apos;&quot; &amp; InFullNameNormalized &amp; &quot;&apos; year=&quot; &amp; gree",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"greetingYear\" referenced in Message but not declared in workflow \"ProcessBirthday\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/ProcessBirthday.xaml",
      "workflow": "ProcessBirthday",
      "activityType": "Assign",
      "propertyName": "Value",
      "referencedSymbol": "ContactLookup",
      "offendingExpression": "[ContactLookup]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"ContactLookup\" referenced in child element <Assign.Value> but not declared in workflow \"ProcessBirthday\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/ProcessBirthday.xaml",
      "workflow": "ProcessBirthday",
      "activityType": "Assign",
      "propertyName": "Value",
      "referencedSymbol": "contactSearchResults",
      "offendingExpression": "[If(contactSearchResults Is Nothing, 0, contactSearchResults.Rows.Count)]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"contactSearchResults\" referenced in child element <Assign.Value> but not declared in workflow \"ProcessBirthday\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/ProcessBirthday.xaml",
      "workflow": "ProcessBirthday",
      "activityType": "Assign",
      "propertyName": "Value",
      "referencedSymbol": "Skipped",
      "offendingExpression": "[Skipped]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"Skipped\" referenced in child element <Assign.Value> but not declared in workflow \"ProcessBirthday\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/ProcessBirthday.xaml",
      "workflow": "ProcessBirthday",
      "activityType": "Assign",
      "propertyName": "Value",
      "referencedSymbol": "NoContact",
      "offendingExpression": "[NoContact]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"NoContact\" referenced in child element <Assign.Value> but not declared in workflow \"ProcessBirthday\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/ProcessBirthday.xaml",
      "workflow": "ProcessBirthday",
      "activityType": "Assign",
      "propertyName": "Value",
      "referencedSymbol": "DedupeCheck",
      "offendingExpression": "[DedupeCheck]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"DedupeCheck\" referenced in child element <Assign.Value> but not declared in workflow \"ProcessBirthday\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/GenerateAndValidateDraft.xaml",
      "workflow": "GenerateAndValidateDraft",
      "activityType": "Assign",
      "propertyName": "Value",
      "referencedSymbol": "validationErrorsList",
      "offendingExpression": "[validationErrorsList.Length = 0]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"validationErrorsList\" referenced in child element <Assign.Value> but not declared in workflow \"GenerateAndValidateDraft\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/HandleHumanReview.xaml",
      "workflow": "HandleHumanReview",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "referencedSymbol": "taskTitle",
      "offendingExpression": "[&quot;[HandleHumanReview] Creating Action Center task Title=&quot; &amp; taskTitle &amp; &quot; Schema=&quot; &amp; taskFormSchemaPath &amp; &quot; RunId=&quot; &amp; InRunId]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"taskTitle\" referenced in Message but not declared in workflow \"HandleHumanReview\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/HandleHumanReview.xaml",
      "workflow": "HandleHumanReview",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "referencedSymbol": "taskFormSchemaPath",
      "offendingExpression": "[&quot;[HandleHumanReview] Creating Action Center task Title=&quot; &amp; taskTitle &amp; &quot; Schema=&quot; &amp; taskFormSchemaPath &amp; &quot; RunId=&quot; &amp; InRunId]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"taskFormSchemaPath\" referenced in Message but not declared in workflow \"HandleHumanReview\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/HandleHumanReview.xaml",
      "workflow": "HandleHumanReview",
      "activityType": "upers:WaitForFormTaskAndResume",
      "propertyName": "Result",
      "referencedSymbol": "taskOutcome",
      "offendingExpression": "[taskOutcome]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "execution_blocking",
      "rationale": "Variable \"taskOutcome\" referenced in Result but not declared in workflow \"HandleHumanReview\" — expression replaced with \"Nothing\""
    },
    {
      "file": "lib/net45/HandleHumanReview.xaml",
      "workflow": "HandleHumanReview",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "referencedSymbol": "taskTimedOut",
      "offendingExpression": "[&quot;[HandleHumanReview] Task resumed. TimedOut=&quot; &amp; taskTimedOut.ToString() &amp; &quot; RunId=&quot; &amp; InRunId &amp; &quot; FullName=&quot; &amp; InFullName]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"taskTimedOut\" referenced in Message but not declared in workflow \"HandleHumanReview\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/HandleHumanReview.xaml",
      "workflow": "HandleHumanReview",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "referencedSymbol": "nowLocal",
      "offendingExpression": "[&quot;[HandleHumanReview] SLA TIMEOUT. FullName=&quot; &amp; InFullName &amp; &quot; RunId=&quot; &amp; InRunId &amp; &quot; NowLocal=&quot; &amp; nowLocal.ToString(&quot;yyyy-MM-dd HH:mm:ss&quot;) &",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"nowLocal\" referenced in Message but not declared in workflow \"HandleHumanReview\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/HandleHumanReview.xaml",
      "workflow": "HandleHumanReview",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "referencedSymbol": "isBeyondCutoff",
      "offendingExpression": "[&quot;[HandleHumanReview] SLA TIMEOUT. FullName=&quot; &amp; InFullName &amp; &quot; RunId=&quot; &amp; InRunId &amp; &quot; NowLocal=&quot; &amp; nowLocal.ToString(&quot;yyyy-MM-dd HH:mm:ss&quot;) &",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"isBeyondCutoff\" referenced in Message but not declared in workflow \"HandleHumanReview\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/HandleHumanReview.xaml",
      "workflow": "HandleHumanReview",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "referencedSymbol": "taskDecisionRaw",
      "offendingExpression": "[&quot;[HandleHumanReview] Reviewer decision extracted. Decision=&quot; &amp; taskDecisionRaw &amp; &quot; FullName=&quot; &amp; InFullName &amp; &quot; RunId=&quot; &amp; InRunId]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"taskDecisionRaw\" referenced in Message but not declared in workflow \"HandleHumanReview\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/HandleHumanReview.xaml",
      "workflow": "HandleHumanReview",
      "activityType": "Assign",
      "propertyName": "Value",
      "referencedSymbol": "Reject",
      "offendingExpression": "[Reject]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"Reject\" referenced in child element <Assign.Value> but not declared in workflow \"HandleHumanReview\" — expression replaced with \"\"\"\""
    }
  ],
  "targetValueCanonicalizationSummary": "Target/value canonicalization: 0 expression fix(es), 55 symbol scope defect(s), 0 sentinel replacement(s), 106 unresolvable JSON defect(s)",
  "residualExpressionSerializationDefects": [
    {
      "file": "lib/net45/Main.xaml",
      "workflow": "Main",
      "activityType": "If",
      "propertyName": "Condition",
      "originalValue": "[{&quot;type&quot;:&quot;expression&quot;,&quot;left&quot;:&quot;birthdayWorkItems Is Nothing OrElse birthdayWorkItems.Rows.Count&quot;,&quot;operator&quot;:&quot;=&quot;,&quot;right&quot;:&quot;0&quo",
      "defectType": "json_expression_leak",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON expression payload in Condition — manual remediation required"
    },
    {
      "file": "lib/net45/GetBirthdays.xaml",
      "workflow": "GetBirthdays",
      "activityType": "If",
      "propertyName": "Condition",
      "originalValue": "[{&quot;type&quot;:&quot;expression&quot;,&quot;left&quot;:&quot;calendarEvents&quot;,&quot;operator&quot;:&quot;Is&quot;,&quot;right&quot;:&quot;Nothing&quot;}]",
      "defectType": "json_expression_leak",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON expression payload in Condition — manual remediation required"
    },
    {
      "file": "lib/net45/ProcessBirthday.xaml",
      "workflow": "ProcessBirthday",
      "activityType": "If",
      "propertyName": "Condition",
      "originalValue": "[{&quot;type&quot;:&quot;expression&quot;,&quot;left&quot;:&quot;contactCount&quot;,&quot;operator&quot;:&quot;=&quot;,&quot;right&quot;:&quot;0&quot;}]",
      "defectType": "json_expression_leak",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON expression payload in Condition — manual remediation required"
    },
    {
      "file": "lib/net45/ProcessBirthday.xaml",
      "workflow": "ProcessBirthday",
      "activityType": "If",
      "propertyName": "Condition",
      "originalValue": "[{&quot;type&quot;:&quot;expression&quot;,&quot;left&quot;:&quot;contactCount&quot;,&quot;operator&quot;:&quot;&gt;&quot;,&quot;right&quot;:&quot;1&quot;}]",
      "defectType": "json_expression_leak",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON expression payload in Condition — manual remediation required"
    },
    {
      "file": "lib/net45/ProcessBirthday.xaml",
      "workflow": "ProcessBirthday",
      "activityType": "If",
      "propertyName": "Condition",
      "originalValue": "[{&quot;type&quot;:&quot;expression&quot;,&quot;left&quot;:&quot;InAllowActionCenterFallback&quot;,&quot;operator&quot;:&quot;=&quot;,&quot;right&quot;:&quot;True&quot;}]",
      "defectType": "json_expression_leak",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON expression payload in Condition — manual remediation required"
    },
    {
      "file": "lib/net45/ProcessBirthday.xaml",
      "workflow": "ProcessBirthday",
      "activityType": "If",
      "propertyName": "Condition",
      "originalValue": "[{&quot;type&quot;:&quot;expression&quot;,&quot;left&quot;:&quot;humanReviewOutcome&quot;,&quot;operator&quot;:&quot;=&quot;,&quot;right&quot;:&quot;Skip&quot;}]",
      "defectType": "json_expression_leak",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON expression payload in Condition — manual remediation required"
    },
    {
      "file": "lib/net45/ProcessBirthday.xaml",
      "workflow": "ProcessBirthday",
      "activityType": "If",
      "propertyName": "Condition",
      "originalValue": "[{&quot;type&quot;:&quot;expression&quot;,&quot;left&quot;:&quot;personalEmail&quot;,&quot;operator&quot;:&quot;&lt;&gt;&quot;,&quot;right&quot;:&quot;Nothing&quot;}]",
      "defectType": "json_expression_leak",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON expression payload in Condition — manual remediation required"
    },
    {
      "file": "lib/net45/ProcessBirthday.xaml",
      "workflow": "ProcessBirthday",
      "activityType": "If",
      "propertyName": "Condition",
      "originalValue": "[{&quot;type&quot;:&quot;expression&quot;,&quot;left&quot;:&quot;homeEmail&quot;,&quot;operator&quot;:&quot;&lt;&gt;&quot;,&quot;right&quot;:&quot;Nothing&quot;}]",
      "defectType": "json_expression_leak",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON expression payload in Condition — manual remediation required"
    },
    {
      "file": "lib/net45/GenerateAndValidateDraft.xaml",
      "workflow": "GenerateAndValidateDraft",
      "activityType": "If",
      "propertyName": "Condition",
      "originalValue": "[{&quot;type&quot;:&quot;expression&quot;,&quot;left&quot;:&quot;String.IsNullOrWhiteSpace(genAiRawResponse)&quot;,&quot;operator&quot;:&quot;=&quot;,&quot;right&quot;:&quot;True&quot;}]",
      "defectType": "json_expression_leak",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON expression payload in Condition — manual remediation required"
    },
    {
      "file": "lib/net45/GenerateAndValidateDraft.xaml",
      "workflow": "GenerateAndValidateDraft",
      "activityType": "If",
      "propertyName": "Condition",
      "originalValue": "[{&quot;type&quot;:&quot;expression&quot;,&quot;left&quot;:&quot;jsonParseSuccess AndAlso parsedJson(\\&quot;needsReview\\&quot;) IsNot Nothing AndAlso CBool(parsedJson(\\&quot;needsReview\\&quot;))&quot;",
      "defectType": "json_expression_leak",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON expression payload in Condition — manual remediation required"
    },
    {
      "file": "lib/net45/GenerateAndValidateDraft.xaml",
      "workflow": "GenerateAndValidateDraft",
      "activityType": "If",
      "propertyName": "Condition",
      "originalValue": "[{&quot;type&quot;:&quot;expression&quot;,&quot;left&quot;:&quot;String.IsNullOrWhiteSpace(parsedSubject)&quot;,&quot;operator&quot;:&quot;=&quot;,&quot;right&quot;:&quot;True&quot;}]",
      "defectType": "json_expression_leak",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON expression payload in Condition — manual remediation required"
    },
    {
      "file": "lib/net45/GenerateAndValidateDraft.xaml",
      "workflow": "GenerateAndValidateDraft",
      "activityType": "If",
      "propertyName": "Condition",
      "originalValue": "[{&quot;type&quot;:&quot;expression&quot;,&quot;left&quot;:&quot;String.IsNullOrWhiteSpace(parsedBody)&quot;,&quot;operator&quot;:&quot;=&quot;,&quot;right&quot;:&quot;True&quot;}]",
      "defectType": "json_expression_leak",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON expression payload in Condition — manual remediation required"
    },
    {
      "file": "lib/net45/GenerateAndValidateDraft.xaml",
      "workflow": "GenerateAndValidateDraft",
      "activityType": "If",
      "propertyName": "Condition",
      "originalValue": "[{&quot;type&quot;:&quot;expression&quot;,&quot;left&quot;:&quot;wordCount&quot;,&quot;operator&quot;:&quot;&lt;&quot;,&quot;right&quot;:&quot;InWordCountMin&quot;}]",
      "defectType": "json_expression_leak",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON expression payload in Condition — manual remediation required"
    },
    {
      "file": "lib/net45/GenerateAndValidateDraft.xaml",
      "workflow": "GenerateAndValidateDraft",
      "activityType": "If",
      "propertyName": "Condition",
      "originalValue": "[{&quot;type&quot;:&quot;expression&quot;,&quot;left&quot;:&quot;wordCount&quot;,&quot;operator&quot;:&quot;&gt;&quot;,&quot;right&quot;:&quot;InWordCountMax&quot;}]",
      "defectType": "json_expression_leak",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON expression payload in Condition — manual remediation required"
    },
    {
      "file": "lib/net45/GenerateAndValidateDraft.xaml",
      "workflow": "GenerateAndValidateDraft",
      "activityType": "If",
      "propertyName": "Condition",
      "originalValue": "[{&quot;type&quot;:&quot;expression&quot;,&quot;left&quot;:&quot;containsEmoji&quot;,&quot;operator&quot;:&quot;=&quot;,&quot;right&quot;:&quot;True&quot;}]",
      "defectType": "json_expression_leak",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON expression payload in Condition — manual remediation required"
    },
    {
      "file": "lib/net45/HandleHumanReview.xaml",
      "workflow": "HandleHumanReview",
      "activityType": "If",
      "propertyName": "Condition",
      "originalValue": "[{&quot;type&quot;:&quot;expression&quot;,&quot;left&quot;:&quot;isContentReview&quot;,&quot;operator&quot;:&quot;=&quot;,&quot;right&quot;:&quot;True&quot;}]",
      "defectType": "json_expression_leak",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON expression payload in Condition — manual remediation required"
    },
    {
      "file": "lib/net45/HandleHumanReview.xaml",
      "workflow": "HandleHumanReview",
      "activityType": "If",
      "propertyName": "Condition",
      "originalValue": "[{&quot;type&quot;:&quot;expression&quot;,&quot;left&quot;:&quot;taskTimedOut&quot;,&quot;operator&quot;:&quot;=&quot;,&quot;right&quot;:&quot;True&quot;}]",
      "defectType": "json_expression_leak",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON expression payload in Condition — manual remediation required"
    },
    {
      "file": "lib/net45/HandleHumanReview.xaml",
      "workflow": "HandleHumanReview",
      "activityType": "If",
      "propertyName": "Condition",
      "originalValue": "[{&quot;type&quot;:&quot;expression&quot;,&quot;left&quot;:&quot;isContentReview&quot;,&quot;operator&quot;:&quot;=&quot;,&quot;right&quot;:&quot;True&quot;}]",
      "defectType": "json_expression_leak",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON expression payload in Condition — manual remediation required"
    },
    {
      "file": "lib/net45/HandleHumanReview.xaml",
      "workflow": "HandleHumanReview",
      "activityType": "If",
      "propertyName": "Condition",
      "originalValue": "[{&quot;type&quot;:&quot;expression&quot;,&quot;left&quot;:&quot;isContentReview AndAlso (approvalDecisionLocal = \\&quot;Approve\\&quot; OrElse approvalDecisionLocal = \\&quot;EditAndApprove\\&quot;)&quo",
      "defectType": "json_expression_leak",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON expression payload in Condition — manual remediation required"
    }
  ],
  "sentinelReplacements": [],
  "unresolvableJsonDefects": [
    {
      "file": "lib/net45/Main.xaml",
      "workflow": "Main",
      "activityType": "Assign",
      "propertyName": "To",
      "originalValue": "\"{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;runStartTimeUtc&quot;}\"",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.To> replaced with platform-safe value \"Nothing\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/Main.xaml",
      "workflow": "Main",
      "activityType": "Assign",
      "propertyName": "To",
      "originalValue": "\"{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;runId&quot;}\"",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.To> replaced with platform-safe value \"Nothing\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/Main.xaml",
      "workflow": "Main",
      "activityType": "Assign",
      "propertyName": "To",
      "originalValue": "\"{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;wordCountMin&quot;}\"",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.To> replaced with platform-safe value \"Nothing\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/Main.xaml",
      "workflow": "Main",
      "activityType": "Assign",
      "propertyName": "To",
      "originalValue": "\"{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;wordCountMax&quot;}\"",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.To> replaced with platform-safe value \"Nothing\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/Main.xaml",
      "workflow": "Main",
      "activityType": "Assign",
      "propertyName": "To",
      "originalValue": "\"{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;allowActionCenterFallback&quot;}\"",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.To> replaced with platform-safe value \"Nothing\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/Main.xaml",
      "workflow": "Main",
      "activityType": "Assign",
      "propertyName": "To",
      "originalValue": "\"{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;birthdaysFoundCount&quot;}\"",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.To> replaced with platform-safe value \"Nothing\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/Main.xaml",
      "workflow": "Main",
      "activityType": "Assign",
      "propertyName": "To",
      "originalValue": "\"{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;currentFullNameRaw&quot;}\"",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.To> replaced with platform-safe value \"Nothing\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/Main.xaml",
      "workflow": "Main",
      "activityType": "Assign",
      "propertyName": "To",
      "originalValue": "\"{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;currentFullNameNormalized&quot;}\"",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.To> replaced with platform-safe value \"Nothing\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/Main.xaml",
      "workflow": "Main",
      "activityType": "Assign",
      "propertyName": "To",
      "originalValue": "\"{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;currentCalendarEventId&quot;}\"",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.To> replaced with platform-safe value \"Nothing\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/Main.xaml",
      "workflow": "Main",
      "activityType": "Assign",
      "propertyName": "To",
      "originalValue": "\"{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;processOutcomeStatus&quot;}\"",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.To> replaced with platform-safe value \"Nothing\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/Main.xaml",
      "workflow": "Main",
      "activityType": "Assign",
      "propertyName": "To",
      "originalValue": "\"{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;processSkipReason&quot;}\"",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.To> replaced with platform-safe value \"Nothing\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/Main.xaml",
      "workflow": "Main",
      "activityType": "Assign",
      "propertyName": "Value",
      "originalValue": "[{&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;\\&quot;BGV26_\\&quot; &amp; DateTime.UtcNow.ToString(\\&quot;yyyyMMdd_HHmmss\\&quot;) &amp; \\&quot;_\\&quot; &amp; Guid.NewGuid().ToStr",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.Value> replaced with platform-safe value \"\"\"\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/Main.xaml",
      "workflow": "Main",
      "activityType": "Assign",
      "propertyName": "Value",
      "originalValue": "[{&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;If(String.Equals(allowActionCenterStr, \\&quot;true\\&quot;, StringComparison.OrdinalIgnoreCase), True, False)&quot;}]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.Value> replaced with platform-safe value \"\"\"\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/Main.xaml",
      "workflow": "Main",
      "activityType": "Assign",
      "propertyName": "Value",
      "originalValue": "[{&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;workItemRow(\\&quot;FullNameRaw\\&quot;).ToString().Trim()&quot;}]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.Value> replaced with platform-safe value \"\"\"\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/Main.xaml",
      "workflow": "Main",
      "activityType": "Assign",
      "propertyName": "Value",
      "originalValue": "[{&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;workItemRow(\\&quot;FullNameNormalized\\&quot;).ToString().Trim()&quot;}]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.Value> replaced with platform-safe value \"\"\"\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/Main.xaml",
      "workflow": "Main",
      "activityType": "Assign",
      "propertyName": "Value",
      "originalValue": "[{&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;workItemRow(\\&quot;CalendarEventId\\&quot;).ToString()&quot;}]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.Value> replaced with platform-safe value \"\"\"\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/GetBirthdays.xaml",
      "workflow": "GetBirthdays",
      "activityType": "Assign",
      "propertyName": "To",
      "originalValue": "\"{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;todayDateLocal&quot;}\"",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.To> replaced with platform-safe value \"Nothing\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/GetBirthdays.xaml",
      "workflow": "GetBirthdays",
      "activityType": "Assign",
      "propertyName": "To",
      "originalValue": "\"{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;startOfDay&quot;}\"",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.To> replaced with platform-safe value \"Nothing\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/GetBirthdays.xaml",
      "workflow": "GetBirthdays",
      "activityType": "Assign",
      "propertyName": "To",
      "originalValue": "\"{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;endOfDay&quot;}\"",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.To> replaced with platform-safe value \"Nothing\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/GetBirthdays.xaml",
      "workflow": "GetBirthdays",
      "activityType": "Assign",
      "propertyName": "To",
      "originalValue": "\"{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;retryAttempt&quot;}\"",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.To> replaced with platform-safe value \"Nothing\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/GetBirthdays.xaml",
      "workflow": "GetBirthdays",
      "activityType": "Assign",
      "propertyName": "To",
      "originalValue": "\"{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;retryAttempt&quot;}\"",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.To> replaced with platform-safe value \"Nothing\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/GetBirthdays.xaml",
      "workflow": "GetBirthdays",
      "activityType": "Assign",
      "propertyName": "To",
      "originalValue": "\"{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;delaySeconds&quot;}\"",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.To> replaced with platform-safe value \"Nothing\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/GetBirthdays.xaml",
      "workflow": "GetBirthdays",
      "activityType": "Assign",
      "propertyName": "To",
      "originalValue": "\"{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;currentEvent&quot;}\"",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.To> replaced with platform-safe value \"Nothing\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/GetBirthdays.xaml",
      "workflow": "GetBirthdays",
      "activityType": "Assign",
      "propertyName": "To",
      "originalValue": "\"{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;fullNameRaw&quot;}\"",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.To> replaced with platform-safe value \"Nothing\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/GetBirthdays.xaml",
      "workflow": "GetBirthdays",
      "activityType": "Assign",
      "propertyName": "To",
      "originalValue": "\"{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;calendarEventId&quot;}\"",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.To> replaced with platform-safe value \"Nothing\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/GetBirthdays.xaml",
      "workflow": "GetBirthdays",
      "activityType": "Assign",
      "propertyName": "To",
      "originalValue": "\"{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;fullNameNormalized&quot;}\"",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.To> replaced with platform-safe value \"Nothing\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/GetBirthdays.xaml",
      "workflow": "GetBirthdays",
      "activityType": "Assign",
      "propertyName": "To",
      "originalValue": "\"{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;birthdaysFoundCount&quot;}\"",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.To> replaced with platform-safe value \"Nothing\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/GetBirthdays.xaml",
      "workflow": "GetBirthdays",
      "activityType": "Assign",
      "propertyName": "To",
      "originalValue": "\"{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;OutBirthdayItems&quot;}\"",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.To> replaced with platform-safe value \"Nothing\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/GetBirthdays.xaml",
      "workflow": "GetBirthdays",
      "activityType": "Assign",
      "propertyName": "To",
      "originalValue": "\"{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;OutTodayDateLocal&quot;}\"",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.To> replaced with platform-safe value \"Nothing\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/GetBirthdays.xaml",
      "workflow": "GetBirthdays",
      "activityType": "Assign",
      "propertyName": "Value",
      "originalValue": "[{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;todayDateLocal&quot;}]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.Value> replaced with platform-safe value \"\"\"\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/GetBirthdays.xaml",
      "workflow": "GetBirthdays",
      "activityType": "Assign",
      "propertyName": "Value",
      "originalValue": "[{&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;If(retryAttempt &lt;= 1, 0, CInt(Math.Pow(2, retryAttempt - 1)))&quot;}]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.Value> replaced with platform-safe value \"\"\"\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/GetBirthdays.xaml",
      "workflow": "GetBirthdays",
      "activityType": "Assign",
      "propertyName": "Value",
      "originalValue": "[{&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;System.Text.RegularExpressions.Regex.Replace(fullNameRaw.Trim(), \\&quot;\\\\s+\\&quot;, \\&quot; \\&quot;)&quot;}]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.Value> replaced with platform-safe value \"\"\"\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/GetBirthdays.xaml",
      "workflow": "GetBirthdays",
      "activityType": "Assign",
      "propertyName": "Value",
      "originalValue": "[{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;birthdayItemsDt&quot;}]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.Value> replaced with platform-safe value \"\"\"\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/GetBirthdays.xaml",
      "workflow": "GetBirthdays",
      "activityType": "Assign",
      "propertyName": "Value",
      "originalValue": "[{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;todayDateLocal&quot;}]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.Value> replaced with platform-safe value \"\"\"\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/ProcessBirthday.xaml",
      "workflow": "ProcessBirthday",
      "activityType": "Assign",
      "propertyName": "To",
      "originalValue": "\"{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;greetingYear&quot;}\"",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.To> replaced with platform-safe value \"Nothing\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/ProcessBirthday.xaml",
      "workflow": "ProcessBirthday",
      "activityType": "Assign",
      "propertyName": "To",
      "originalValue": "\"{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;currentStepName&quot;}\"",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.To> replaced with platform-safe value \"Nothing\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/ProcessBirthday.xaml",
      "workflow": "ProcessBirthday",
      "activityType": "Assign",
      "propertyName": "To",
      "originalValue": "\"{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;contactCount&quot;}\"",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.To> replaced with platform-safe value \"Nothing\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/ProcessBirthday.xaml",
      "workflow": "ProcessBirthday",
      "activityType": "Assign",
      "propertyName": "To",
      "originalValue": "\"{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;OutOutcomeStatus&quot;}\"",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.To> replaced with platform-safe value \"Nothing\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/ProcessBirthday.xaml",
      "workflow": "ProcessBirthday",
      "activityType": "Assign",
      "propertyName": "To",
      "originalValue": "\"{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;OutSkipReason&quot;}\"",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.To> replaced with platform-safe value \"Nothing\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/ProcessBirthday.xaml",
      "workflow": "ProcessBirthday",
      "activityType": "Assign",
      "propertyName": "To",
      "originalValue": "\"{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;isAmbiguousContact&quot;}\"",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.To> replaced with platform-safe value \"Nothing\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/ProcessBirthday.xaml",
      "workflow": "ProcessBirthday",
      "activityType": "Assign",
      "propertyName": "To",
      "originalValue": "\"{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;candidateContactsFormatted&quot;}\"",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.To> replaced with platform-safe value \"Nothing\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/ProcessBirthday.xaml",
      "workflow": "ProcessBirthday",
      "activityType": "Assign",
      "propertyName": "To",
      "originalValue": "\"{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;selectedEmail&quot;}\"",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.To> replaced with platform-safe value \"Nothing\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/ProcessBirthday.xaml",
      "workflow": "ProcessBirthday",
      "activityType": "Assign",
      "propertyName": "To",
      "originalValue": "\"{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;personalEmail&quot;}\"",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.To> replaced with platform-safe value \"Nothing\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/ProcessBirthday.xaml",
      "workflow": "ProcessBirthday",
      "activityType": "Assign",
      "propertyName": "To",
      "originalValue": "\"{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;homeEmail&quot;}\"",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.To> replaced with platform-safe value \"Nothing\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/ProcessBirthday.xaml",
      "workflow": "ProcessBirthday",
      "activityType": "Assign",
      "propertyName": "To",
      "originalValue": "\"{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;selectedEmail&quot;}\"",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.To> replaced with platform-safe value \"Nothing\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/ProcessBirthday.xaml",
      "workflow": "ProcessBirthday",
      "activityType": "Assign",
      "propertyName": "To",
      "originalValue": "\"{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;selectedEmail&quot;}\"",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.To> replaced with platform-safe value \"Nothing\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/ProcessBirthday.xaml",
      "workflow": "ProcessBirthday",
      "activityType": "Assign",
      "propertyName": "To",
      "originalValue": "\"{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;currentStepName&quot;}\"",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.To> replaced with platform-safe value \"Nothing\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/ProcessBirthday.xaml",
      "workflow": "ProcessBirthday",
      "activityType": "Assign",
      "propertyName": "To",
      "originalValue": "\"{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;alreadySentThisYear&quot;}\"",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.To> replaced with platform-safe value \"Nothing\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/ProcessBirthday.xaml",
      "workflow": "ProcessBirthday",
      "activityType": "Assign",
      "propertyName": "Value",
      "originalValue": "[{&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;String.Join(Environment.NewLine, (From row As DataRow In contactSearchResults.AsEnumerable() Select \\&quot;Name: \\&quot; &amp; row(",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.Value> replaced with platform-safe value \"\"\"\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/ProcessBirthday.xaml",
      "workflow": "ProcessBirthday",
      "activityType": "Assign",
      "propertyName": "Value",
      "originalValue": "[{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;humanReviewEmail&quot;}]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.Value> replaced with platform-safe value \"\"\"\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/ProcessBirthday.xaml",
      "workflow": "ProcessBirthday",
      "activityType": "Assign",
      "propertyName": "Value",
      "originalValue": "[{&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;If(contactSearchResults IsNot Nothing AndAlso contactSearchResults.Rows.Count = 1 AndAlso contactSearchResults.Columns.Contains(\\&q",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.Value> replaced with platform-safe value \"\"\"\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/ProcessBirthday.xaml",
      "workflow": "ProcessBirthday",
      "activityType": "Assign",
      "propertyName": "Value",
      "originalValue": "[{&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;If(contactSearchResults IsNot Nothing AndAlso contactSearchResults.Rows.Count = 1 AndAlso contactSearchResults.Columns.Contains(\\&q",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.Value> replaced with platform-safe value \"\"\"\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/ProcessBirthday.xaml",
      "workflow": "ProcessBirthday",
      "activityType": "Assign",
      "propertyName": "Value",
      "originalValue": "[{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;personalEmail&quot;}]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.Value> replaced with platform-safe value \"\"\"\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/ProcessBirthday.xaml",
      "workflow": "ProcessBirthday",
      "activityType": "Assign",
      "propertyName": "Value",
      "originalValue": "[{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;homeEmail&quot;}]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.Value> replaced with platform-safe value \"\"\"\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/ProcessBirthday.xaml",
      "workflow": "ProcessBirthday",
      "activityType": "Assign",
      "propertyName": "Value",
      "originalValue": "[{&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;dedupeQueryResults IsNot Nothing AndAlso dedupeQueryResults.Rows.Count &gt; 0&quot;}]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.Value> replaced with platform-safe value \"\"\"\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/GenerateAndValidateDraft.xaml",
      "workflow": "GenerateAndValidateDraft",
      "activityType": "Assign",
      "propertyName": "To",
      "originalValue": "\"{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;genAiPrompt&quot;}\"",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.To> replaced with platform-safe value \"Nothing\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/GenerateAndValidateDraft.xaml",
      "workflow": "GenerateAndValidateDraft",
      "activityType": "Assign",
      "propertyName": "To",
      "originalValue": "\"{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;validationErrorsList&quot;}\"",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.To> replaced with platform-safe value \"Nothing\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/GenerateAndValidateDraft.xaml",
      "workflow": "GenerateAndValidateDraft",
      "activityType": "Assign",
      "propertyName": "To",
      "originalValue": "\"{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;jsonParseSuccess&quot;}\"",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.To> replaced with platform-safe value \"Nothing\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/GenerateAndValidateDraft.xaml",
      "workflow": "GenerateAndValidateDraft",
      "activityType": "Assign",
      "propertyName": "To",
      "originalValue": "\"{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;validationErrorsList&quot;}\"",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.To> replaced with platform-safe value \"Nothing\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/GenerateAndValidateDraft.xaml",
      "workflow": "GenerateAndValidateDraft",
      "activityType": "Assign",
      "propertyName": "To",
      "originalValue": "\"{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;validationErrorsList&quot;}\"",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.To> replaced with platform-safe value \"Nothing\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/GenerateAndValidateDraft.xaml",
      "workflow": "GenerateAndValidateDraft",
      "activityType": "Assign",
      "propertyName": "To",
      "originalValue": "\"{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;validationErrorsList&quot;}\"",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.To> replaced with platform-safe value \"Nothing\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/GenerateAndValidateDraft.xaml",
      "workflow": "GenerateAndValidateDraft",
      "activityType": "Assign",
      "propertyName": "To",
      "originalValue": "\"{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;wordCount&quot;}\"",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.To> replaced with platform-safe value \"Nothing\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/GenerateAndValidateDraft.xaml",
      "workflow": "GenerateAndValidateDraft",
      "activityType": "Assign",
      "propertyName": "To",
      "originalValue": "\"{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;validationErrorsList&quot;}\"",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.To> replaced with platform-safe value \"Nothing\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/GenerateAndValidateDraft.xaml",
      "workflow": "GenerateAndValidateDraft",
      "activityType": "Assign",
      "propertyName": "To",
      "originalValue": "\"{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;validationErrorsList&quot;}\"",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.To> replaced with platform-safe value \"Nothing\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/GenerateAndValidateDraft.xaml",
      "workflow": "GenerateAndValidateDraft",
      "activityType": "Assign",
      "propertyName": "To",
      "originalValue": "\"{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;containsEmoji&quot;}\"",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.To> replaced with platform-safe value \"Nothing\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/GenerateAndValidateDraft.xaml",
      "workflow": "GenerateAndValidateDraft",
      "activityType": "Assign",
      "propertyName": "To",
      "originalValue": "\"{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;validationErrorsList&quot;}\"",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.To> replaced with platform-safe value \"Nothing\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/GenerateAndValidateDraft.xaml",
      "workflow": "GenerateAndValidateDraft",
      "activityType": "Assign",
      "propertyName": "To",
      "originalValue": "\"{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;isValid&quot;}\"",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.To> replaced with platform-safe value \"Nothing\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/GenerateAndValidateDraft.xaml",
      "workflow": "GenerateAndValidateDraft",
      "activityType": "Assign",
      "propertyName": "Value",
      "originalValue": "[{&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;InStyleSpec &amp; Environment.NewLine &amp; \\&quot;Recipient full name: \\&quot; &amp; InFullName &amp; Environment.NewLine &amp; \\&",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.Value> replaced with platform-safe value \"\"\"\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/GenerateAndValidateDraft.xaml",
      "workflow": "GenerateAndValidateDraft",
      "activityType": "Assign",
      "propertyName": "Value",
      "originalValue": "[{&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;validationErrorsList.Concat(New String() {\\&quot;GenAI returned empty or null response\\&quot;}).ToArray()&quot;}]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.Value> replaced with platform-safe value \"\"\"\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/GenerateAndValidateDraft.xaml",
      "workflow": "GenerateAndValidateDraft",
      "activityType": "Assign",
      "propertyName": "Value",
      "originalValue": "[{&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;validationErrorsList.Concat(New String() {\\&quot;GenAI self-reported needsReview=true: \\&quot; &amp; If(parsedJson(\\&quot;reason\\&q",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.Value> replaced with platform-safe value \"\"\"\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/GenerateAndValidateDraft.xaml",
      "workflow": "GenerateAndValidateDraft",
      "activityType": "Assign",
      "propertyName": "Value",
      "originalValue": "[{&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;validationErrorsList.Concat(New String() {\\&quot;Subject is empty or whitespace\\&quot;}).ToArray()&quot;}]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.Value> replaced with platform-safe value \"\"\"\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/GenerateAndValidateDraft.xaml",
      "workflow": "GenerateAndValidateDraft",
      "activityType": "Assign",
      "propertyName": "Value",
      "originalValue": "[{&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;validationErrorsList.Concat(New String() {\\&quot;Body is empty or whitespace\\&quot;}).ToArray()&quot;}]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.Value> replaced with platform-safe value \"\"\"\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/GenerateAndValidateDraft.xaml",
      "workflow": "GenerateAndValidateDraft",
      "activityType": "Assign",
      "propertyName": "Value",
      "originalValue": "[{&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;If(String.IsNullOrWhiteSpace(parsedBody), 0, parsedBody.Split(New Char() {\\&quot; \\&quot;c, Environment.NewLine.ToCharArray()(0), E",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.Value> replaced with platform-safe value \"\"\"\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/GenerateAndValidateDraft.xaml",
      "workflow": "GenerateAndValidateDraft",
      "activityType": "Assign",
      "propertyName": "Value",
      "originalValue": "[{&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;validationErrorsList.Concat(New String() {\\&quot;Body word count \\&quot; &amp; wordCount.ToString() &amp; \\&quot; is below minimum ",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.Value> replaced with platform-safe value \"\"\"\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/GenerateAndValidateDraft.xaml",
      "workflow": "GenerateAndValidateDraft",
      "activityType": "Assign",
      "propertyName": "Value",
      "originalValue": "[{&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;validationErrorsList.Concat(New String() {\\&quot;Body word count \\&quot; &amp; wordCount.ToString() &amp; \\&quot; exceeds maximum \\",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.Value> replaced with platform-safe value \"\"\"\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/GenerateAndValidateDraft.xaml",
      "workflow": "GenerateAndValidateDraft",
      "activityType": "Assign",
      "propertyName": "Value",
      "originalValue": "[{&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;System.Text.RegularExpressions.Regex.IsMatch(parsedBody &amp; parsedSubject, \\&quot;[\\\\uD83C-\\\\uDBFF\\\\uDC00-\\\\uDFFF\\\\u2600-\\\\u27BF\\",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.Value> replaced with platform-safe value \"\"\"\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/GenerateAndValidateDraft.xaml",
      "workflow": "GenerateAndValidateDraft",
      "activityType": "Assign",
      "propertyName": "Value",
      "originalValue": "[{&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;validationErrorsList.Concat(New String() {\\&quot;Subject or body contains emoji characters which are not permitted\\&quot;}).ToArray",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.Value> replaced with platform-safe value \"\"\"\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/HandleHumanReview.xaml",
      "workflow": "HandleHumanReview",
      "activityType": "Assign",
      "propertyName": "To",
      "originalValue": "\"{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;isContentReview&quot;}\"",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.To> replaced with platform-safe value \"Nothing\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/HandleHumanReview.xaml",
      "workflow": "HandleHumanReview",
      "activityType": "Assign",
      "propertyName": "To",
      "originalValue": "\"{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;taskTitle&quot;}\"",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.To> replaced with platform-safe value \"Nothing\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/HandleHumanReview.xaml",
      "workflow": "HandleHumanReview",
      "activityType": "Assign",
      "propertyName": "To",
      "originalValue": "\"{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;taskFormSchemaPath&quot;}\"",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.To> replaced with platform-safe value \"Nothing\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/HandleHumanReview.xaml",
      "workflow": "HandleHumanReview",
      "activityType": "Assign",
      "propertyName": "To",
      "originalValue": "\"{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;taskData&quot;}\"",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.To> replaced with platform-safe value \"Nothing\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/HandleHumanReview.xaml",
      "workflow": "HandleHumanReview",
      "activityType": "Assign",
      "propertyName": "To",
      "originalValue": "\"{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;nowLocal&quot;}\"",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.To> replaced with platform-safe value \"Nothing\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/HandleHumanReview.xaml",
      "workflow": "HandleHumanReview",
      "activityType": "Assign",
      "propertyName": "To",
      "originalValue": "\"{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;cutoffTime&quot;}\"",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.To> replaced with platform-safe value \"Nothing\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/HandleHumanReview.xaml",
      "workflow": "HandleHumanReview",
      "activityType": "Assign",
      "propertyName": "To",
      "originalValue": "\"{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;isBeyondCutoff&quot;}\"",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.To> replaced with platform-safe value \"Nothing\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/HandleHumanReview.xaml",
      "workflow": "HandleHumanReview",
      "activityType": "Assign",
      "propertyName": "To",
      "originalValue": "\"{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;approvalDecisionLocal&quot;}\"",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.To> replaced with platform-safe value \"Nothing\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/HandleHumanReview.xaml",
      "workflow": "HandleHumanReview",
      "activityType": "Assign",
      "propertyName": "To",
      "originalValue": "\"{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;escalationSubject&quot;}\"",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.To> replaced with platform-safe value \"Nothing\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/HandleHumanReview.xaml",
      "workflow": "HandleHumanReview",
      "activityType": "Assign",
      "propertyName": "To",
      "originalValue": "\"{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;escalationBody&quot;}\"",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.To> replaced with platform-safe value \"Nothing\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/HandleHumanReview.xaml",
      "workflow": "HandleHumanReview",
      "activityType": "Assign",
      "propertyName": "To",
      "originalValue": "\"{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;taskDecisionRaw&quot;}\"",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.To> replaced with platform-safe value \"Nothing\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/HandleHumanReview.xaml",
      "workflow": "HandleHumanReview",
      "activityType": "Assign",
      "propertyName": "To",
      "originalValue": "\"{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;approvalDecisionLocal&quot;}\"",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.To> replaced with platform-safe value \"Nothing\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/HandleHumanReview.xaml",
      "workflow": "HandleHumanReview",
      "activityType": "Assign",
      "propertyName": "To",
      "originalValue": "\"{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;approvedSubjectLocal&quot;}\"",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.To> replaced with platform-safe value \"Nothing\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/HandleHumanReview.xaml",
      "workflow": "HandleHumanReview",
      "activityType": "Assign",
      "propertyName": "To",
      "originalValue": "\"{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;approvedBodyLocal&quot;}\"",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.To> replaced with platform-safe value \"Nothing\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/HandleHumanReview.xaml",
      "workflow": "HandleHumanReview",
      "activityType": "Assign",
      "propertyName": "To",
      "originalValue": "\"{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;selectedEmailLocal&quot;}\"",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.To> replaced with platform-safe value \"Nothing\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/HandleHumanReview.xaml",
      "workflow": "HandleHumanReview",
      "activityType": "Assign",
      "propertyName": "To",
      "originalValue": "\"{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;reviewerCommentsLocal&quot;}\"",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.To> replaced with platform-safe value \"Nothing\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/HandleHumanReview.xaml",
      "workflow": "HandleHumanReview",
      "activityType": "Assign",
      "propertyName": "Value",
      "originalValue": "[{&quot;type&quot;:&quot;expression&quot;,&quot;left&quot;:&quot;InReviewType&quot;,&quot;operator&quot;:&quot;=&quot;,&quot;right&quot;:&quot;\\&quot;ContentReview\\&quot;&quot;}]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.Value> replaced with platform-safe value \"\"\"\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/HandleHumanReview.xaml",
      "workflow": "HandleHumanReview",
      "activityType": "Assign",
      "propertyName": "Value",
      "originalValue": "[{&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;If(isContentReview, \\&quot;BirthdayGreetingsV26_ContentReview - \\&quot; &amp; InFullName, \\&quot;BirthdayGreetingsV26_ContactDisamb",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.Value> replaced with platform-safe value \"\"\"\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/HandleHumanReview.xaml",
      "workflow": "HandleHumanReview",
      "activityType": "Assign",
      "propertyName": "Value",
      "originalValue": "[{&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;If(isContentReview, \\&quot;Forms\\\\ContentReviewForm.json\\&quot;, \\&quot;Forms\\\\ContactDisambiguationForm.json\\&quot;)&quot;}]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.Value> replaced with platform-safe value \"\"\"\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/HandleHumanReview.xaml",
      "workflow": "HandleHumanReview",
      "activityType": "Assign",
      "propertyName": "Value",
      "originalValue": "[{&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;New Dictionary(Of String, Object) From {{\\&quot;RunId\\&quot;, InRunId}, {\\&quot;FullName\\&quot;, InFullName}, {\\&quot;RecipientEmai",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.Value> replaced with platform-safe value \"\"\"\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/HandleHumanReview.xaml",
      "workflow": "HandleHumanReview",
      "activityType": "Assign",
      "propertyName": "Value",
      "originalValue": "[{&quot;type&quot;:&quot;expression&quot;,&quot;left&quot;:&quot;nowLocal&quot;,&quot;operator&quot;:&quot;&gt;&quot;,&quot;right&quot;:&quot;cutoffTime&quot;}]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.Value> replaced with platform-safe value \"\"\"\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/HandleHumanReview.xaml",
      "workflow": "HandleHumanReview",
      "activityType": "Assign",
      "propertyName": "Value",
      "originalValue": "[{&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;\\&quot;[BGV26 SLA Alert] Human review timed out for \\&quot; &amp; InFullName &amp; \\&quot; (\\&quot; &amp; InReviewType &amp; \\&quot",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.Value> replaced with platform-safe value \"\"\"\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/HandleHumanReview.xaml",
      "workflow": "HandleHumanReview",
      "activityType": "Assign",
      "propertyName": "Value",
      "originalValue": "[{&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;\\&quot;Action Center task for birthday greeting review timed out (6-hour SLA).\\&quot; &amp; Environment.NewLine &amp; \\&quot;RunId:",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.Value> replaced with platform-safe value \"\"\"\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/HandleHumanReview.xaml",
      "workflow": "HandleHumanReview",
      "activityType": "Assign",
      "propertyName": "Value",
      "originalValue": "[{&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;If(taskOutcome IsNot Nothing AndAlso CType(taskOutcome, Dictionary(Of String, Object)).ContainsKey(\\&quot;ApprovalDecision\\&quot;),",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.Value> replaced with platform-safe value \"\"\"\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/HandleHumanReview.xaml",
      "workflow": "HandleHumanReview",
      "activityType": "Assign",
      "propertyName": "Value",
      "originalValue": "[{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;taskDecisionRaw&quot;}]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.Value> replaced with platform-safe value \"\"\"\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/HandleHumanReview.xaml",
      "workflow": "HandleHumanReview",
      "activityType": "Assign",
      "propertyName": "Value",
      "originalValue": "[{&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;If(taskOutcome IsNot Nothing AndAlso CType(taskOutcome, Dictionary(Of String, Object)).ContainsKey(\\&quot;ProposedSubject\\&quot;), ",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.Value> replaced with platform-safe value \"\"\"\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/HandleHumanReview.xaml",
      "workflow": "HandleHumanReview",
      "activityType": "Assign",
      "propertyName": "Value",
      "originalValue": "[{&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;If(taskOutcome IsNot Nothing AndAlso CType(taskOutcome, Dictionary(Of String, Object)).ContainsKey(\\&quot;ProposedBody\\&quot;), CSt",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.Value> replaced with platform-safe value \"\"\"\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/HandleHumanReview.xaml",
      "workflow": "HandleHumanReview",
      "activityType": "Assign",
      "propertyName": "Value",
      "originalValue": "[{&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;If(taskOutcome IsNot Nothing AndAlso CType(taskOutcome, Dictionary(Of String, Object)).ContainsKey(\\&quot;SelectedRecipientEmail\\&q",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.Value> replaced with platform-safe value \"\"\"\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/HandleHumanReview.xaml",
      "workflow": "HandleHumanReview",
      "activityType": "Assign",
      "propertyName": "Value",
      "originalValue": "[{&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;If(taskOutcome IsNot Nothing AndAlso CType(taskOutcome, Dictionary(Of String, Object)).ContainsKey(\\&quot;ReviewerComments\\&quot;),",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.Value> replaced with platform-safe value \"\"\"\" — non-deterministic canonicalization, degradation substitute"
    }
  ],
  "requiredPropertyBindings": [
    {
      "file": "Main.xaml",
      "workflow": "Main",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;=== Starting: Main ===&quot;]",
      "resolvedValue": "[&quot;=== Starting: Main ===&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;=== Starting: Main ===&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "Main.xaml",
      "workflow": "Main",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[Main] BirthdayGreetingsV26 Main workflow started. Initializing run context.",
      "resolvedValue": "[Main] BirthdayGreetingsV26 Main workflow started. Initializing run context.",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 1,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[Main] BirthdayGreetingsV26 Main workflow started. Initializing run context.",
        "precedenceTier": 4
      }
    },
    {
      "file": "Main.xaml",
      "workflow": "Main",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "[DateTime.UtcNow]",
      "resolvedValue": "[DateTime.UtcNow]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[DateTime.UtcNow]",
        "precedenceTier": 4
      }
    },
    {
      "file": "Main.xaml",
      "workflow": "Main",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "\"\"",
      "resolvedValue": "\"\"",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 1,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "\"\"",
        "precedenceTier": 4
      }
    },
    {
      "file": "Main.xaml",
      "workflow": "Main",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot captured for error diagnostics&quot;]",
      "resolvedValue": "[&quot;Screenshot captured for error diagnostics&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 3,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot captured for error diagnostics&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "Main.xaml",
      "workflow": "Main",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
      "resolvedValue": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 4,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
        "precedenceTier": 4
      }
    },
    {
      "file": "Main.xaml",
      "workflow": "Main",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;[Error] Read asset BGV26_BirthdaysCalendarName failed (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "resolvedValue": "[&quot;[Error] Read asset BGV26_BirthdaysCalendarName failed (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 5,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;[Error] Read asset BGV26_BirthdaysCalendarName failed (&quot; &amp; excep",
        "precedenceTier": 4
      }
    },
    {
      "file": "Main.xaml",
      "workflow": "Main",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot captured for error diagnostics&quot;]",
      "resolvedValue": "[&quot;Screenshot captured for error diagnostics&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 7,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot captured for error diagnostics&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "Main.xaml",
      "workflow": "Main",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
      "resolvedValue": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 8,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
        "precedenceTier": 4
      }
    },
    {
      "file": "Main.xaml",
      "workflow": "Main",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;[Error] Read asset BGV26_TimeZone failed (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "resolvedValue": "[&quot;[Error] Read asset BGV26_TimeZone failed (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 9,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;[Error] Read asset BGV26_TimeZone failed (&quot; &amp; exception.GetType(",
        "precedenceTier": 4
      }
    },
    {
      "file": "Main.xaml",
      "workflow": "Main",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot captured for error diagnostics&quot;]",
      "resolvedValue": "[&quot;Screenshot captured for error diagnostics&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 10,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot captured for error diagnostics&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "Main.xaml",
      "workflow": "Main",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
      "resolvedValue": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 11,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
        "precedenceTier": 4
      }
    },
    {
      "file": "Main.xaml",
      "workflow": "Main",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;[Error] Read asset BGV26_EmailStyleSpec failed (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "resolvedValue": "[&quot;[Error] Read asset BGV26_EmailStyleSpec failed (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 12,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;[Error] Read asset BGV26_EmailStyleSpec failed (&quot; &amp; exception.Ge",
        "precedenceTier": 4
      }
    },
    {
      "file": "Main.xaml",
      "workflow": "Main",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot captured for error diagnostics&quot;]",
      "resolvedValue": "[&quot;Screenshot captured for error diagnostics&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 13,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot captured for error diagnostics&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "Main.xaml",
      "workflow": "Main",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
      "resolvedValue": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 14,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
        "precedenceTier": 4
      }
    },
    {
      "file": "Main.xaml",
      "workflow": "Main",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;[Error] Read asset BGV26_EmailWordCountMin (as text) failed (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "resolvedValue": "[&quot;[Error] Read asset BGV26_EmailWordCountMin (as text) failed (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 15,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;[Error] Read asset BGV26_EmailWordCountMin (as text) failed (&quot; &amp;",
        "precedenceTier": 4
      }
    },
    {
      "file": "Main.xaml",
      "workflow": "Main",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "\"\"",
      "resolvedValue": "\"\"",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 2,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "\"\"",
        "precedenceTier": 4
      }
    },
    {
      "file": "Main.xaml",
      "workflow": "Main",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot captured for error diagnostics&quot;]",
      "resolvedValue": "[&quot;Screenshot captured for error diagnostics&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 16,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot captured for error diagnostics&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "Main.xaml",
      "workflow": "Main",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
      "resolvedValue": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 17,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
        "precedenceTier": 4
      }
    },
    {
      "file": "Main.xaml",
      "workflow": "Main",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;[Error] Read asset BGV26_EmailWordCountMax (as text) failed (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "resolvedValue": "[&quot;[Error] Read asset BGV26_EmailWordCountMax (as text) failed (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 18,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;[Error] Read asset BGV26_EmailWordCountMax (as text) failed (&quot; &amp;",
        "precedenceTier": 4
      }
    },
    {
      "file": "Main.xaml",
      "workflow": "Main",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "\"\"",
      "resolvedValue": "\"\"",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 3,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "\"\"",
        "precedenceTier": 4
      }
    },
    {
      "file": "Main.xaml",
      "workflow": "Main",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot captured for error diagnostics&quot;]",
      "resolvedValue": "[&quot;Screenshot captured for error diagnostics&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 19,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot captured for error diagnostics&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "Main.xaml",
      "workflow": "Main",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
      "resolvedValue": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 20,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
        "precedenceTier": 4
      }
    },
    {
      "file": "Main.xaml",
      "workflow": "Main",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;[Error] Read asset BGV26_AllowActionCenterFallback (as text) failed (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "resolvedValue": "[&quot;[Error] Read asset BGV26_AllowActionCenterFallback (as text) failed (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 21,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;[Error] Read asset BGV26_AllowActionCenterFallback (as text) failed (&quo",
        "precedenceTier": 4
      }
    },
    {
      "file": "Main.xaml",
      "workflow": "Main",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "\"\"",
      "resolvedValue": "\"\"",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 4,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "\"\"",
        "precedenceTier": 4
      }
    },
    {
      "file": "Main.xaml",
      "workflow": "Main",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot captured for error diagnostics&quot;]",
      "resolvedValue": "[&quot;Screenshot captured for error diagnostics&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 22,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot captured for error diagnostics&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "Main.xaml",
      "workflow": "Main",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
      "resolvedValue": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 23,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
        "precedenceTier": 4
      }
    },
    {
      "file": "Main.xaml",
      "workflow": "Main",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;[Error] Read asset BGV26_GmailFromConnectionName failed (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "resolvedValue": "[&quot;[Error] Read asset BGV26_GmailFromConnectionName failed (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 24,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;[Error] Read asset BGV26_GmailFromConnectionName failed (&quot; &amp; exc",
        "precedenceTier": 4
      }
    },
    {
      "file": "Main.xaml",
      "workflow": "Main",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot captured for error diagnostics&quot;]",
      "resolvedValue": "[&quot;Screenshot captured for error diagnostics&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 25,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot captured for error diagnostics&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "Main.xaml",
      "workflow": "Main",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
      "resolvedValue": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 26,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
        "precedenceTier": 4
      }
    },
    {
      "file": "Main.xaml",
      "workflow": "Main",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;[Error] Read asset BGV26_DedupeScope failed (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "resolvedValue": "[&quot;[Error] Read asset BGV26_DedupeScope failed (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 27,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;[Error] Read asset BGV26_DedupeScope failed (&quot; &amp; exception.GetTy",
        "precedenceTier": 4
      }
    },
    {
      "file": "Main.xaml",
      "workflow": "Main",
      "activityType": "CreateEntityRecord",
      "propertyName": "EntityType",
      "sourceBinding": "attribute-value",
      "originalValue": "BGV26_Run",
      "resolvedValue": "BGV26_Run",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "BGV26_Run",
        "precedenceTier": 4
      }
    },
    {
      "file": "Main.xaml",
      "workflow": "Main",
      "activityType": "CreateEntityRecord",
      "propertyName": "EntityObject",
      "sourceBinding": "attribute-value",
      "originalValue": "{&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;New Dictionary(Of String, Object) From {{\\&quot;RunId\\&quot;, runId}, {\\&quot;StartTimeUtc\\&quot;, runStartTimeUtc}, {\\&quot;RunStatus\\&quot;, \\&quot;Started\\&quot;}, {\\&quot;BirthdaysFound\\&quot;, 0}, {\\&quot;SentCount\\&quot;, 0}, {\\&quot;SkippedCount\\&quot;, 0}, {\\&quot;ErrorCount\\&quot;, 0}, {\\&quot;OrchestratorJobKey\\&quot;, orchestratorJobKey}}&quot;}",
      "resolvedValue": "[New Dictionary(Of String, Object) From {{\"RunId\", runId}, {\"StartTimeUtc\", runStartTimeUtc}, {\"RunStatus\", \"Started\"}, {\"BirthdaysFound\", 0}, {\"SentCount\", 0}, {\"SkippedCount\", 0}, {\"ErrorCount\", 0}, {\"OrchestratorJobKey\", orchestratorJobKey}}]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "{&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;New Dictiona",
        "precedenceTier": 4
      }
    },
    {
      "file": "Main.xaml",
      "workflow": "Main",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Retry exhausted for Create BGV26_Run record in Data Service with status Started, screenshot captured&quot;]",
      "resolvedValue": "[&quot;Retry exhausted for Create BGV26_Run record in Data Service with status Started, screenshot captured&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 29,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Retry exhausted for Create BGV26_Run record in Data Service with status S",
        "precedenceTier": 4
      }
    },
    {
      "file": "Main.xaml",
      "workflow": "Main",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot capture failed: &quot; &amp; ssEx.Message]",
      "resolvedValue": "[&quot;Screenshot capture failed: &quot; &amp; ssEx.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 30,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot capture failed: &quot; &amp; ssEx.Message]",
        "precedenceTier": 4
      }
    },
    {
      "file": "Main.xaml",
      "workflow": "Main",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;[Retry Exhausted] Create BGV26_Run record in Data Service with status Started failed after retries — &quot; &amp; retryEx.Message]",
      "resolvedValue": "[&quot;[Retry Exhausted] Create BGV26_Run record in Data Service with status Started failed after retries — &quot; &amp; retryEx.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 31,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;[Retry Exhausted] Create BGV26_Run record in Data Service with status Sta",
        "precedenceTier": 4
      }
    },
    {
      "file": "Main.xaml",
      "workflow": "Main",
      "activityType": "InvokeWorkflowFile",
      "propertyName": "WorkflowFileName",
      "sourceBinding": "attribute-value",
      "originalValue": "GetBirthdays.xaml",
      "resolvedValue": "GetBirthdays.xaml",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "GetBirthdays.xaml",
        "precedenceTier": 4
      }
    },
    {
      "file": "Main.xaml",
      "workflow": "Main",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot captured for error diagnostics&quot;]",
      "resolvedValue": "[&quot;Screenshot captured for error diagnostics&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 33,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot captured for error diagnostics&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "Main.xaml",
      "workflow": "Main",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
      "resolvedValue": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 34,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
        "precedenceTier": 4
      }
    },
    {
      "file": "Main.xaml",
      "workflow": "Main",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;[Error] Invoke GetBirthdays workflow to retrieve today&apos;s birthday work items failed (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "resolvedValue": "[&quot;[Error] Invoke GetBirthdays workflow to retrieve today&apos;s birthday work items failed (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 35,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;[Error] Invoke GetBirthdays workflow to retrieve today&apos;s birthday wo",
        "precedenceTier": 4
      }
    },
    {
      "file": "Main.xaml",
      "workflow": "Main",
      "activityType": "If",
      "propertyName": "Condition",
      "sourceBinding": "attribute-value",
      "originalValue": "[{&quot;type&quot;:&quot;expression&quot;,&quot;left&quot;:&quot;birthdayWorkItems Is Nothing OrElse birthdayWorkItems.Rows.Count&quot;,&quot;operator&quot;:&quot;=&quot;,&quot;right&quot;:&quot;0&quot;}]",
      "resolvedValue": "[{&quot;type&quot;:&quot;expression&quot;,&quot;left&quot;:&quot;birthdayWorkItems Is Nothing OrElse birthdayWorkItems.Rows.Count&quot;,&quot;operator&quot;:&quot;=&quot;,&quot;right&quot;:&quot;0&quot;}]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[{&quot;type&quot;:&quot;expression&quot;,&quot;left&quot;:&quot;birthdayWorkIte",
        "precedenceTier": 4
      }
    },
    {
      "file": "Main.xaml",
      "workflow": "Main",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Then path: If no birthday work items found, log and skip to Finalize&quot;]",
      "resolvedValue": "[&quot;Then path: If no birthday work items found, log and skip to Finalize&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 37,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Then path: If no birthday work items found, log and skip to Finalize&quot",
        "precedenceTier": 4
      }
    },
    {
      "file": "Main.xaml",
      "workflow": "Main",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Else path: If no birthday work items found, log and skip to Finalize&quot;]",
      "resolvedValue": "[&quot;Else path: If no birthday work items found, log and skip to Finalize&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 38,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Else path: If no birthday work items found, log and skip to Finalize&quot",
        "precedenceTier": 4
      }
    },
    {
      "file": "Main.xaml",
      "workflow": "Main",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;[Main][Decision] No birthday events found for today (&quot; &amp; DateTime.UtcNow.ToString(&quot;yyyy-MM-dd&quot;) &amp; &quot;). Job will finalize with Completed status.&quot;]",
      "resolvedValue": "[&quot;[Main][Decision] No birthday events found for today (&quot; &amp; DateTime.UtcNow.ToString(&quot;yyyy-MM-dd&quot;) &amp; &quot;). Job will finalize with Completed status.&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 39,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;[Main][Decision] No birthday events found for today (&quot; &amp; DateTim",
        "precedenceTier": 4
      }
    },
    {
      "file": "Main.xaml",
      "workflow": "Main",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "\"\"",
      "resolvedValue": "\"\"",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 5,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "\"\"",
        "precedenceTier": 4
      }
    },
    {
      "file": "Main.xaml",
      "workflow": "Main",
      "activityType": "ForEach",
      "propertyName": "Values",
      "sourceBinding": "attribute-value",
      "originalValue": "Nothing",
      "resolvedValue": "Nothing",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "Nothing",
        "precedenceTier": 4
      }
    },
    {
      "file": "Main.xaml",
      "workflow": "Main",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Processing item in: ForEach birthday work item in birthdayWorkItems — process each birthday&quot;]",
      "resolvedValue": "[&quot;Processing item in: ForEach birthday work item in birthdayWorkItems — process each birthday&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 41,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Processing item in: ForEach birthday work item in birthdayWorkItems — pro",
        "precedenceTier": 4
      }
    },
    {
      "file": "Main.xaml",
      "workflow": "Main",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "\"\"",
      "resolvedValue": "\"\"",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 6,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "\"\"",
        "precedenceTier": 4
      }
    },
    {
      "file": "Main.xaml",
      "workflow": "Main",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "\"\"",
      "resolvedValue": "\"\"",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 7,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "\"\"",
        "precedenceTier": 4
      }
    },
    {
      "file": "Main.xaml",
      "workflow": "Main",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "\"\"",
      "resolvedValue": "\"\"",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 8,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "\"\"",
        "precedenceTier": 4
      }
    },
    {
      "file": "Main.xaml",
      "workflow": "Main",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "[]",
      "resolvedValue": "[]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 9,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[]",
        "precedenceTier": 4
      }
    },
    {
      "file": "Main.xaml",
      "workflow": "Main",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "[]",
      "resolvedValue": "[]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 10,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[]",
        "precedenceTier": 4
      }
    },
    {
      "file": "Main.xaml",
      "workflow": "Main",
      "activityType": "InvokeWorkflowFile",
      "propertyName": "WorkflowFileName",
      "sourceBinding": "attribute-value",
      "originalValue": "ProcessBirthday.xaml",
      "resolvedValue": "ProcessBirthday.xaml",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 1,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "ProcessBirthday.xaml",
        "precedenceTier": 4
      }
    },
    {
      "file": "Main.xaml",
      "workflow": "Main",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;=== Completed: Main ===&quot;]",
      "resolvedValue": "[&quot;=== Completed: Main ===&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 43,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;=== Completed: Main ===&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "GetBirthdays.xaml",
      "workflow": "GetBirthdays",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;=== Starting: GetBirthdays ===&quot;]",
      "resolvedValue": "[&quot;=== Starting: GetBirthdays ===&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;=== Starting: GetBirthdays ===&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "GetBirthdays.xaml",
      "workflow": "GetBirthdays",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;[GetBirthdays] START — CalendarName=&apos;&quot; &amp; InCalendarName &amp; &quot;&apos;, TimeZone=&apos;&quot; &amp; InTimeZone &amp; &quot;&apos;, ExecutionDate=&quot; &amp; DateTime.Now.ToString(&quot;yyyy-MM-dd HH:mm:ss&quot;)]",
      "resolvedValue": "[&quot;[GetBirthdays] START — CalendarName=&apos;&quot; &amp; InCalendarName &amp; &quot;&apos;, TimeZone=&apos;&quot; &amp; InTimeZone &amp; &quot;&apos;, ExecutionDate=&quot; &amp; DateTime.Now.ToString(&quot;yyyy-MM-dd HH:mm:ss&quot;)]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 1,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;[GetBirthdays] START — CalendarName=&apos;&quot; &amp; InCalendarName &am",
        "precedenceTier": 4
      }
    },
    {
      "file": "GetBirthdays.xaml",
      "workflow": "GetBirthdays",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "[TimeZoneInfo.ConvertTimeFromUtc(DateTime.UtcNow, TimeZoneInfo.FindSystemTimeZoneById(InTimeZone)).Date]",
      "resolvedValue": "[TimeZoneInfo.ConvertTimeFromUtc(DateTime.UtcNow, TimeZoneInfo.FindSystemTimeZoneById(InTimeZone)).Date]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[TimeZoneInfo.ConvertTimeFromUtc(DateTime.UtcNow, TimeZoneInfo.FindSystemTimeZon",
        "precedenceTier": 4
      }
    },
    {
      "file": "GetBirthdays.xaml",
      "workflow": "GetBirthdays",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot captured for error diagnostics&quot;]",
      "resolvedValue": "[&quot;Screenshot captured for error diagnostics&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 2,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot captured for error diagnostics&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "GetBirthdays.xaml",
      "workflow": "GetBirthdays",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
      "resolvedValue": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 3,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
        "precedenceTier": 4
      }
    },
    {
      "file": "GetBirthdays.xaml",
      "workflow": "GetBirthdays",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;[Error] Resolve today&apos;s local date from InTimeZone argument failed (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "resolvedValue": "[&quot;[Error] Resolve today&apos;s local date from InTimeZone argument failed (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 4,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;[Error] Resolve today&apos;s local date from InTimeZone argument failed (",
        "precedenceTier": 4
      }
    },
    {
      "file": "GetBirthdays.xaml",
      "workflow": "GetBirthdays",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "\"\"",
      "resolvedValue": "\"\"",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 1,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "\"\"",
        "precedenceTier": 4
      }
    },
    {
      "file": "GetBirthdays.xaml",
      "workflow": "GetBirthdays",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "\"\"",
      "resolvedValue": "\"\"",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 2,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "\"\"",
        "precedenceTier": 4
      }
    },
    {
      "file": "GetBirthdays.xaml",
      "workflow": "GetBirthdays",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "[0]",
      "resolvedValue": "[0]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 3,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[0]",
        "precedenceTier": 4
      }
    },
    {
      "file": "GetBirthdays.xaml",
      "workflow": "GetBirthdays",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot captured for error diagnostics&quot;]",
      "resolvedValue": "[&quot;Screenshot captured for error diagnostics&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 5,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot captured for error diagnostics&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "GetBirthdays.xaml",
      "workflow": "GetBirthdays",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
      "resolvedValue": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 6,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
        "precedenceTier": 4
      }
    },
    {
      "file": "GetBirthdays.xaml",
      "workflow": "GetBirthdays",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;[Error] RetryScope: Call Google Calendar API with up to 3 attempts and exponential backoff failed (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "resolvedValue": "[&quot;[Error] RetryScope: Call Google Calendar API with up to 3 attempts and exponential backoff failed (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 7,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;[Error] RetryScope: Call Google Calendar API with up to 3 attempts and ex",
        "precedenceTier": 4
      }
    },
    {
      "file": "GetBirthdays.xaml",
      "workflow": "GetBirthdays",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "\"\"",
      "resolvedValue": "\"\"",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 4,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "\"\"",
        "precedenceTier": 4
      }
    },
    {
      "file": "GetBirthdays.xaml",
      "workflow": "GetBirthdays",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "\"\"",
      "resolvedValue": "\"\"",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 5,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "\"\"",
        "precedenceTier": 4
      }
    },
    {
      "file": "GetBirthdays.xaml",
      "workflow": "GetBirthdays",
      "activityType": "Delay",
      "propertyName": "Duration",
      "sourceBinding": "attribute-value",
      "originalValue": "TimeSpan.FromSeconds(delaySeconds)",
      "resolvedValue": "TimeSpan.FromSeconds(delaySeconds)",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "TimeSpan.FromSeconds(delaySeconds)",
        "precedenceTier": 4
      }
    },
    {
      "file": "GetBirthdays.xaml",
      "workflow": "GetBirthdays",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Retry exhausted for Get today&apos;s birthday events from Google Calendar, screenshot captured&quot;]",
      "resolvedValue": "[&quot;Retry exhausted for Get today&apos;s birthday events from Google Calendar, screenshot captured&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 9,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Retry exhausted for Get today&apos;s birthday events from Google Calendar",
        "precedenceTier": 4
      }
    },
    {
      "file": "GetBirthdays.xaml",
      "workflow": "GetBirthdays",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot capture failed: &quot; &amp; ssEx.Message]",
      "resolvedValue": "[&quot;Screenshot capture failed: &quot; &amp; ssEx.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 10,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot capture failed: &quot; &amp; ssEx.Message]",
        "precedenceTier": 4
      }
    },
    {
      "file": "GetBirthdays.xaml",
      "workflow": "GetBirthdays",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;[Retry Exhausted] Get today&apos;s birthday events from Google Calendar failed after retries — &quot; &amp; retryEx.Message]",
      "resolvedValue": "[&quot;[Retry Exhausted] Get today&apos;s birthday events from Google Calendar failed after retries — &quot; &amp; retryEx.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 11,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;[Retry Exhausted] Get today&apos;s birthday events from Google Calendar f",
        "precedenceTier": 4
      }
    },
    {
      "file": "GetBirthdays.xaml",
      "workflow": "GetBirthdays",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;[GetBirthdays] GoogleCalendarGetEvents succeeded on attempt &quot; &amp; retryAttempt.ToString() &amp; &quot; — evaluating event count&quot;]",
      "resolvedValue": "[&quot;[GetBirthdays] GoogleCalendarGetEvents succeeded on attempt &quot; &amp; retryAttempt.ToString() &amp; &quot; — evaluating event count&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 12,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;[GetBirthdays] GoogleCalendarGetEvents succeeded on attempt &quot; &amp; ",
        "precedenceTier": 4
      }
    },
    {
      "file": "GetBirthdays.xaml",
      "workflow": "GetBirthdays",
      "activityType": "If",
      "propertyName": "Condition",
      "sourceBinding": "attribute-value",
      "originalValue": "[{&quot;type&quot;:&quot;expression&quot;,&quot;left&quot;:&quot;calendarEvents&quot;,&quot;operator&quot;:&quot;Is&quot;,&quot;right&quot;:&quot;Nothing&quot;}]",
      "resolvedValue": "[{&quot;type&quot;:&quot;expression&quot;,&quot;left&quot;:&quot;calendarEvents&quot;,&quot;operator&quot;:&quot;Is&quot;,&quot;right&quot;:&quot;Nothing&quot;}]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[{&quot;type&quot;:&quot;expression&quot;,&quot;left&quot;:&quot;calendarEvents&",
        "precedenceTier": 4
      }
    },
    {
      "file": "GetBirthdays.xaml",
      "workflow": "GetBirthdays",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Then path: Check if any birthday events were returned&quot;]",
      "resolvedValue": "[&quot;Then path: Check if any birthday events were returned&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 13,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Then path: Check if any birthday events were returned&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "GetBirthdays.xaml",
      "workflow": "GetBirthdays",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Else path: Check if any birthday events were returned&quot;]",
      "resolvedValue": "[&quot;Else path: Check if any birthday events were returned&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 14,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Else path: Check if any birthday events were returned&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "GetBirthdays.xaml",
      "workflow": "GetBirthdays",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;[GetBirthdays] GoogleCalendarGetEvents returned null collection for date &quot; &amp; todayDateLocal.ToString(&quot;yyyy-MM-dd&quot;) &amp; &quot; — treating as zero birthdays&quot;]",
      "resolvedValue": "[&quot;[GetBirthdays] GoogleCalendarGetEvents returned null collection for date &quot; &amp; todayDateLocal.ToString(&quot;yyyy-MM-dd&quot;) &amp; &quot; — treating as zero birthdays&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 15,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;[GetBirthdays] GoogleCalendarGetEvents returned null collection for date ",
        "precedenceTier": 4
      }
    },
    {
      "file": "GetBirthdays.xaml",
      "workflow": "GetBirthdays",
      "activityType": "ForEach",
      "propertyName": "Values",
      "sourceBinding": "attribute-value",
      "originalValue": "[{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;calendarEvents&quot;}]",
      "resolvedValue": "[{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;calendarEvents&quot;}]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;calendarEvents&qu",
        "precedenceTier": 4
      }
    },
    {
      "file": "GetBirthdays.xaml",
      "workflow": "GetBirthdays",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Processing item in: For each birthday event returned by Google Calendar&quot;]",
      "resolvedValue": "[&quot;Processing item in: For each birthday event returned by Google Calendar&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 16,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Processing item in: For each birthday event returned by Google Calendar&q",
        "precedenceTier": 4
      }
    },
    {
      "file": "GetBirthdays.xaml",
      "workflow": "GetBirthdays",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "[item]",
      "resolvedValue": "[item]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 6,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[item]",
        "precedenceTier": 4
      }
    },
    {
      "file": "GetBirthdays.xaml",
      "workflow": "GetBirthdays",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "\"\"",
      "resolvedValue": "\"\"",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 7,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "\"\"",
        "precedenceTier": 4
      }
    },
    {
      "file": "GetBirthdays.xaml",
      "workflow": "GetBirthdays",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot captured for error diagnostics&quot;]",
      "resolvedValue": "[&quot;Screenshot captured for error diagnostics&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 17,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot captured for error diagnostics&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "GetBirthdays.xaml",
      "workflow": "GetBirthdays",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
      "resolvedValue": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 18,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
        "precedenceTier": 4
      }
    },
    {
      "file": "GetBirthdays.xaml",
      "workflow": "GetBirthdays",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;[Error] Extract raw event title (FullNameRaw) from current calendar event failed (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "resolvedValue": "[&quot;[Error] Extract raw event title (FullNameRaw) from current calendar event failed (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 19,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;[Error] Extract raw event title (FullNameRaw) from current calendar event",
        "precedenceTier": 4
      }
    },
    {
      "file": "GetBirthdays.xaml",
      "workflow": "GetBirthdays",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "\"\"",
      "resolvedValue": "\"\"",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 8,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "\"\"",
        "precedenceTier": 4
      }
    },
    {
      "file": "GetBirthdays.xaml",
      "workflow": "GetBirthdays",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot captured for error diagnostics&quot;]",
      "resolvedValue": "[&quot;Screenshot captured for error diagnostics&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 20,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot captured for error diagnostics&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "GetBirthdays.xaml",
      "workflow": "GetBirthdays",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
      "resolvedValue": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 21,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
        "precedenceTier": 4
      }
    },
    {
      "file": "GetBirthdays.xaml",
      "workflow": "GetBirthdays",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;[Error] Extract CalendarEventId from current event failed (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "resolvedValue": "[&quot;[Error] Extract CalendarEventId from current event failed (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 22,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;[Error] Extract CalendarEventId from current event failed (&quot; &amp; e",
        "precedenceTier": 4
      }
    },
    {
      "file": "GetBirthdays.xaml",
      "workflow": "GetBirthdays",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Then path: Guard: skip event if FullNameRaw is null or empty&quot;]",
      "resolvedValue": "[&quot;Then path: Guard: skip event if FullNameRaw is null or empty&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 23,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Then path: Guard: skip event if FullNameRaw is null or empty&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "GetBirthdays.xaml",
      "workflow": "GetBirthdays",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Else path: Guard: skip event if FullNameRaw is null or empty&quot;]",
      "resolvedValue": "[&quot;Else path: Guard: skip event if FullNameRaw is null or empty&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 24,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Else path: Guard: skip event if FullNameRaw is null or empty&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "GetBirthdays.xaml",
      "workflow": "GetBirthdays",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;[GetBirthdays] SKIP — CalendarEventId=&apos;&quot; &amp; calendarEventId &amp; &quot;&apos; has null/empty Summary — event ignored&quot;]",
      "resolvedValue": "[&quot;[GetBirthdays] SKIP — CalendarEventId=&apos;&quot; &amp; calendarEventId &amp; &quot;&apos; has null/empty Summary — event ignored&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 25,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;[GetBirthdays] SKIP — CalendarEventId=&apos;&quot; &amp; calendarEventId ",
        "precedenceTier": 4
      }
    },
    {
      "file": "GetBirthdays.xaml",
      "workflow": "GetBirthdays",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "\"\"",
      "resolvedValue": "\"\"",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 9,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "\"\"",
        "precedenceTier": 4
      }
    },
    {
      "file": "GetBirthdays.xaml",
      "workflow": "GetBirthdays",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;[GetBirthdays] Event normalized — Raw=&apos;&quot; &amp; fullNameRaw &amp; &quot;&apos;, Normalized=&apos;&quot; &amp; fullNameNormalized &amp; &quot;&apos;, EventId=&apos;&quot; &amp; calendarEventId &amp; &quot;&apos;&quot;]",
      "resolvedValue": "[&quot;[GetBirthdays] Event normalized — Raw=&apos;&quot; &amp; fullNameRaw &amp; &quot;&apos;, Normalized=&apos;&quot; &amp; fullNameNormalized &amp; &quot;&apos;, EventId=&apos;&quot; &amp; calendarEventId &amp; &quot;&apos;&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 26,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;[GetBirthdays] Event normalized — Raw=&apos;&quot; &amp; fullNameRaw &amp",
        "precedenceTier": 4
      }
    },
    {
      "file": "GetBirthdays.xaml",
      "workflow": "GetBirthdays",
      "activityType": "AddDataRow",
      "propertyName": "DataTable",
      "sourceBinding": "attribute-value",
      "originalValue": "{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;birthdayItemsDt&quot;}",
      "resolvedValue": "[birthdayItemsDt]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;birthdayItemsDt&qu",
        "precedenceTier": 4
      }
    },
    {
      "file": "GetBirthdays.xaml",
      "workflow": "GetBirthdays",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot captured for error diagnostics&quot;]",
      "resolvedValue": "[&quot;Screenshot captured for error diagnostics&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 27,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot captured for error diagnostics&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "GetBirthdays.xaml",
      "workflow": "GetBirthdays",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
      "resolvedValue": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 28,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
        "precedenceTier": 4
      }
    },
    {
      "file": "GetBirthdays.xaml",
      "workflow": "GetBirthdays",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;[Error] Add normalized birthday work item row to output DataTable failed (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "resolvedValue": "[&quot;[Error] Add normalized birthday work item row to output DataTable failed (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 29,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;[Error] Add normalized birthday work item row to output DataTable failed ",
        "precedenceTier": 4
      }
    },
    {
      "file": "GetBirthdays.xaml",
      "workflow": "GetBirthdays",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "\"\"",
      "resolvedValue": "\"\"",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 10,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "\"\"",
        "precedenceTier": 4
      }
    },
    {
      "file": "GetBirthdays.xaml",
      "workflow": "GetBirthdays",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "\"\"",
      "resolvedValue": "\"\"",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 11,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "\"\"",
        "precedenceTier": 4
      }
    },
    {
      "file": "GetBirthdays.xaml",
      "workflow": "GetBirthdays",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "\"\"",
      "resolvedValue": "\"\"",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 12,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "\"\"",
        "precedenceTier": 4
      }
    },
    {
      "file": "GetBirthdays.xaml",
      "workflow": "GetBirthdays",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;[GetBirthdays] COMPLETE — Date=&quot; &amp; todayDateLocal.ToString(&quot;yyyy-MM-dd&quot;) &amp; &quot;, BirthdaysFound=&quot; &amp; birthdaysFoundCount.ToString() &amp; &quot;, TimeZone=&apos;&quot; &amp; InTimeZone &amp; &quot;&apos;&quot;]",
      "resolvedValue": "[&quot;[GetBirthdays] COMPLETE — Date=&quot; &amp; todayDateLocal.ToString(&quot;yyyy-MM-dd&quot;) &amp; &quot;, BirthdaysFound=&quot; &amp; birthdaysFoundCount.ToString() &amp; &quot;, TimeZone=&apos;&quot; &amp; InTimeZone &amp; &quot;&apos;&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 30,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;[GetBirthdays] COMPLETE — Date=&quot; &amp; todayDateLocal.ToString(&quot",
        "precedenceTier": 4
      }
    },
    {
      "file": "GetBirthdays.xaml",
      "workflow": "GetBirthdays",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;=== Completed: GetBirthdays ===&quot;]",
      "resolvedValue": "[&quot;=== Completed: GetBirthdays ===&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 31,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;=== Completed: GetBirthdays ===&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "ProcessBirthday.xaml",
      "workflow": "ProcessBirthday",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;=== Starting: ProcessBirthday ===&quot;]",
      "resolvedValue": "[&quot;=== Starting: ProcessBirthday ===&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;=== Starting: ProcessBirthday ===&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "ProcessBirthday.xaml",
      "workflow": "ProcessBirthday",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;[ProcessBirthday][Start] Processing birthday for &apos;&quot; &amp; InFullNameNormalized &amp; &quot;&apos; | RunId=&quot; &amp; InRunId &amp; &quot; | EventId=&quot; &amp; InCalendarEventId]",
      "resolvedValue": "[&quot;[ProcessBirthday][Start] Processing birthday for &apos;&quot; &amp; InFullNameNormalized &amp; &quot;&apos; | RunId=&quot; &amp; InRunId &amp; &quot; | EventId=&quot; &amp; InCalendarEventId]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 1,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;[ProcessBirthday][Start] Processing birthday for &apos;&quot; &amp; InFul",
        "precedenceTier": 4
      }
    },
    {
      "file": "ProcessBirthday.xaml",
      "workflow": "ProcessBirthday",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "[InTodayDateLocal.Year]",
      "resolvedValue": "[InTodayDateLocal.Year]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[InTodayDateLocal.Year]",
        "precedenceTier": 4
      }
    },
    {
      "file": "ProcessBirthday.xaml",
      "workflow": "ProcessBirthday",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "\"\"",
      "resolvedValue": "\"\"",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 1,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "\"\"",
        "precedenceTier": 4
      }
    },
    {
      "file": "ProcessBirthday.xaml",
      "workflow": "ProcessBirthday",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot captured for error diagnostics&quot;]",
      "resolvedValue": "[&quot;Screenshot captured for error diagnostics&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 2,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot captured for error diagnostics&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "ProcessBirthday.xaml",
      "workflow": "ProcessBirthday",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
      "resolvedValue": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 3,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
        "precedenceTier": 4
      }
    },
    {
      "file": "ProcessBirthday.xaml",
      "workflow": "ProcessBirthday",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;[Error] Search Google Contacts by exact full name (RetryScope for transient API errors) failed (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "resolvedValue": "[&quot;[Error] Search Google Contacts by exact full name (RetryScope for transient API errors) failed (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 4,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;[Error] Search Google Contacts by exact full name (RetryScope for transie",
        "precedenceTier": 4
      }
    },
    {
      "file": "ProcessBirthday.xaml",
      "workflow": "ProcessBirthday",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot captured for error diagnostics&quot;]",
      "resolvedValue": "[&quot;Screenshot captured for error diagnostics&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 5,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot captured for error diagnostics&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "ProcessBirthday.xaml",
      "workflow": "ProcessBirthday",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
      "resolvedValue": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 6,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
        "precedenceTier": 4
      }
    },
    {
      "file": "ProcessBirthday.xaml",
      "workflow": "ProcessBirthday",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;[Error] GoogleContactsSearchContacts — exact name query failed (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "resolvedValue": "[&quot;[Error] GoogleContactsSearchContacts — exact name query failed (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 7,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;[Error] GoogleContactsSearchContacts — exact name query failed (&quot; &a",
        "precedenceTier": 4
      }
    },
    {
      "file": "ProcessBirthday.xaml",
      "workflow": "ProcessBirthday",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;[ProcessBirthday][ContactLookup] Found &quot; &amp; If(contactSearchResults Is Nothing, 0, contactSearchResults.Rows.Count).ToString() &amp; &quot; contact(s) for &apos;&quot; &amp; InFullNameNormalized &amp; &quot;&apos;&quot;]",
      "resolvedValue": "[&quot;[ProcessBirthday][ContactLookup] Found &quot; &amp; If(contactSearchResults Is Nothing, 0, contactSearchResults.Rows.Count).ToString() &amp; &quot; contact(s) for &apos;&quot; &amp; InFullNameNormalized &amp; &quot;&apos;&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 8,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;[ProcessBirthday][ContactLookup] Found &quot; &amp; If(contactSearchResul",
        "precedenceTier": 4
      }
    },
    {
      "file": "ProcessBirthday.xaml",
      "workflow": "ProcessBirthday",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "\"\"",
      "resolvedValue": "\"\"",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 2,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "\"\"",
        "precedenceTier": 4
      }
    },
    {
      "file": "ProcessBirthday.xaml",
      "workflow": "ProcessBirthday",
      "activityType": "If",
      "propertyName": "Condition",
      "sourceBinding": "attribute-value",
      "originalValue": "[{&quot;type&quot;:&quot;expression&quot;,&quot;left&quot;:&quot;contactCount&quot;,&quot;operator&quot;:&quot;=&quot;,&quot;right&quot;:&quot;0&quot;}]",
      "resolvedValue": "[{&quot;type&quot;:&quot;expression&quot;,&quot;left&quot;:&quot;contactCount&quot;,&quot;operator&quot;:&quot;=&quot;,&quot;right&quot;:&quot;0&quot;}]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[{&quot;type&quot;:&quot;expression&quot;,&quot;left&quot;:&quot;contactCount&qu",
        "precedenceTier": 4
      }
    },
    {
      "file": "ProcessBirthday.xaml",
      "workflow": "ProcessBirthday",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Then path: If contactCount = 0 then skip with NoContact reason&quot;]",
      "resolvedValue": "[&quot;Then path: If contactCount = 0 then skip with NoContact reason&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 9,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Then path: If contactCount = 0 then skip with NoContact reason&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "ProcessBirthday.xaml",
      "workflow": "ProcessBirthday",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Else path: If contactCount = 0 then skip with NoContact reason&quot;]",
      "resolvedValue": "[&quot;Else path: If contactCount = 0 then skip with NoContact reason&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 10,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Else path: If contactCount = 0 then skip with NoContact reason&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "ProcessBirthday.xaml",
      "workflow": "ProcessBirthday",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "\"\"",
      "resolvedValue": "\"\"",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 3,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "\"\"",
        "precedenceTier": 4
      }
    },
    {
      "file": "ProcessBirthday.xaml",
      "workflow": "ProcessBirthday",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "\"\"",
      "resolvedValue": "\"\"",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 4,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "\"\"",
        "precedenceTier": 4
      }
    },
    {
      "file": "ProcessBirthday.xaml",
      "workflow": "ProcessBirthday",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;[ProcessBirthday][Skip] No Google Contact found for &apos;&quot; &amp; InFullNameNormalized &amp; &quot;&apos; — skipping. RunId=&quot; &amp; InRunId]",
      "resolvedValue": "[&quot;[ProcessBirthday][Skip] No Google Contact found for &apos;&quot; &amp; InFullNameNormalized &amp; &quot;&apos; — skipping. RunId=&quot; &amp; InRunId]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 11,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;[ProcessBirthday][Skip] No Google Contact found for &apos;&quot; &amp; In",
        "precedenceTier": 4
      }
    },
    {
      "file": "ProcessBirthday.xaml",
      "workflow": "ProcessBirthday",
      "activityType": "If",
      "propertyName": "Condition",
      "sourceBinding": "attribute-value",
      "originalValue": "[{&quot;type&quot;:&quot;expression&quot;,&quot;left&quot;:&quot;contactCount&quot;,&quot;operator&quot;:&quot;&gt;&quot;,&quot;right&quot;:&quot;1&quot;}]",
      "resolvedValue": "[{&quot;type&quot;:&quot;expression&quot;,&quot;left&quot;:&quot;contactCount&quot;,&quot;operator&quot;:&quot;&gt;&quot;,&quot;right&quot;:&quot;1&quot;}]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 1,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[{&quot;type&quot;:&quot;expression&quot;,&quot;left&quot;:&quot;contactCount&qu",
        "precedenceTier": 4
      }
    },
    {
      "file": "ProcessBirthday.xaml",
      "workflow": "ProcessBirthday",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Then path: If contactCount &gt; 1 then flag as ambiguous contact&quot;]",
      "resolvedValue": "[&quot;Then path: If contactCount &gt; 1 then flag as ambiguous contact&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 12,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Then path: If contactCount &gt; 1 then flag as ambiguous contact&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "ProcessBirthday.xaml",
      "workflow": "ProcessBirthday",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Else path: If contactCount &gt; 1 then flag as ambiguous contact&quot;]",
      "resolvedValue": "[&quot;Else path: If contactCount &gt; 1 then flag as ambiguous contact&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 13,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Else path: If contactCount &gt; 1 then flag as ambiguous contact&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "ProcessBirthday.xaml",
      "workflow": "ProcessBirthday",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "[True]",
      "resolvedValue": "[True]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 5,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[True]",
        "precedenceTier": 4
      }
    },
    {
      "file": "ProcessBirthday.xaml",
      "workflow": "ProcessBirthday",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "\"\"",
      "resolvedValue": "\"\"",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 6,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "\"\"",
        "precedenceTier": 4
      }
    },
    {
      "file": "ProcessBirthday.xaml",
      "workflow": "ProcessBirthday",
      "activityType": "If",
      "propertyName": "Condition",
      "sourceBinding": "attribute-value",
      "originalValue": "[{&quot;type&quot;:&quot;expression&quot;,&quot;left&quot;:&quot;InAllowActionCenterFallback&quot;,&quot;operator&quot;:&quot;=&quot;,&quot;right&quot;:&quot;True&quot;}]",
      "resolvedValue": "[{&quot;type&quot;:&quot;expression&quot;,&quot;left&quot;:&quot;InAllowActionCenterFallback&quot;,&quot;operator&quot;:&quot;=&quot;,&quot;right&quot;:&quot;True&quot;}]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 2,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[{&quot;type&quot;:&quot;expression&quot;,&quot;left&quot;:&quot;InAllowActionCe",
        "precedenceTier": 4
      }
    },
    {
      "file": "ProcessBirthday.xaml",
      "workflow": "ProcessBirthday",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Then path: If InAllowActionCenterFallback=True invoke HandleHumanReview for disambiguation else skip&quot;]",
      "resolvedValue": "[&quot;Then path: If InAllowActionCenterFallback=True invoke HandleHumanReview for disambiguation else skip&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 15,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Then path: If InAllowActionCenterFallback=True invoke HandleHumanReview f",
        "precedenceTier": 4
      }
    },
    {
      "file": "ProcessBirthday.xaml",
      "workflow": "ProcessBirthday",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Else path: If InAllowActionCenterFallback=True invoke HandleHumanReview for disambiguation else skip&quot;]",
      "resolvedValue": "[&quot;Else path: If InAllowActionCenterFallback=True invoke HandleHumanReview for disambiguation else skip&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 16,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Else path: If InAllowActionCenterFallback=True invoke HandleHumanReview f",
        "precedenceTier": 4
      }
    },
    {
      "file": "ProcessBirthday.xaml",
      "workflow": "ProcessBirthday",
      "activityType": "InvokeWorkflowFile",
      "propertyName": "WorkflowFileName",
      "sourceBinding": "attribute-value",
      "originalValue": "HandleHumanReview.xaml",
      "resolvedValue": "HandleHumanReview.xaml",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "HandleHumanReview.xaml",
        "precedenceTier": 4
      }
    },
    {
      "file": "ProcessBirthday.xaml",
      "workflow": "ProcessBirthday",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot captured for error diagnostics&quot;]",
      "resolvedValue": "[&quot;Screenshot captured for error diagnostics&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 17,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot captured for error diagnostics&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "ProcessBirthday.xaml",
      "workflow": "ProcessBirthday",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
      "resolvedValue": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 18,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
        "precedenceTier": 4
      }
    },
    {
      "file": "ProcessBirthday.xaml",
      "workflow": "ProcessBirthday",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;[Error] Invoke HandleHumanReview for contact disambiguation failed (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "resolvedValue": "[&quot;[Error] Invoke HandleHumanReview for contact disambiguation failed (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 19,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;[Error] Invoke HandleHumanReview for contact disambiguation failed (&quot",
        "precedenceTier": 4
      }
    },
    {
      "file": "ProcessBirthday.xaml",
      "workflow": "ProcessBirthday",
      "activityType": "If",
      "propertyName": "Condition",
      "sourceBinding": "attribute-value",
      "originalValue": "[{&quot;type&quot;:&quot;expression&quot;,&quot;left&quot;:&quot;humanReviewOutcome&quot;,&quot;operator&quot;:&quot;=&quot;,&quot;right&quot;:&quot;Skip&quot;}]",
      "resolvedValue": "[{&quot;type&quot;:&quot;expression&quot;,&quot;left&quot;:&quot;humanReviewOutcome&quot;,&quot;operator&quot;:&quot;=&quot;,&quot;right&quot;:&quot;Skip&quot;}]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 3,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[{&quot;type&quot;:&quot;expression&quot;,&quot;left&quot;:&quot;humanReviewOutc",
        "precedenceTier": 4
      }
    },
    {
      "file": "ProcessBirthday.xaml",
      "workflow": "ProcessBirthday",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Then path: If disambiguation outcome is Skip then set skip outputs&quot;]",
      "resolvedValue": "[&quot;Then path: If disambiguation outcome is Skip then set skip outputs&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 20,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Then path: If disambiguation outcome is Skip then set skip outputs&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "ProcessBirthday.xaml",
      "workflow": "ProcessBirthday",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Else path: If disambiguation outcome is Skip then set skip outputs&quot;]",
      "resolvedValue": "[&quot;Else path: If disambiguation outcome is Skip then set skip outputs&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 21,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Else path: If disambiguation outcome is Skip then set skip outputs&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "ProcessBirthday.xaml",
      "workflow": "ProcessBirthday",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "\"\"",
      "resolvedValue": "\"\"",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 7,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "\"\"",
        "precedenceTier": 4
      }
    },
    {
      "file": "ProcessBirthday.xaml",
      "workflow": "ProcessBirthday",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "\"\"",
      "resolvedValue": "\"\"",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 8,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "\"\"",
        "precedenceTier": 4
      }
    },
    {
      "file": "ProcessBirthday.xaml",
      "workflow": "ProcessBirthday",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "\"\"",
      "resolvedValue": "\"\"",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 9,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "\"\"",
        "precedenceTier": 4
      }
    },
    {
      "file": "ProcessBirthday.xaml",
      "workflow": "ProcessBirthday",
      "activityType": "If",
      "propertyName": "Condition",
      "sourceBinding": "attribute-value",
      "originalValue": "[{&quot;type&quot;:&quot;expression&quot;,&quot;left&quot;:&quot;personalEmail&quot;,&quot;operator&quot;:&quot;&lt;&gt;&quot;,&quot;right&quot;:&quot;Nothing&quot;}]",
      "resolvedValue": "[{&quot;type&quot;:&quot;expression&quot;,&quot;left&quot;:&quot;personalEmail&quot;,&quot;operator&quot;:&quot;&lt;&gt;&quot;,&quot;right&quot;:&quot;Nothing&quot;}]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 4,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[{&quot;type&quot;:&quot;expression&quot;,&quot;left&quot;:&quot;personalEmail&q",
        "precedenceTier": 4
      }
    },
    {
      "file": "ProcessBirthday.xaml",
      "workflow": "ProcessBirthday",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Then path: Select recipient email — prefer Personal over Home&quot;]",
      "resolvedValue": "[&quot;Then path: Select recipient email — prefer Personal over Home&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 22,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Then path: Select recipient email — prefer Personal over Home&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "ProcessBirthday.xaml",
      "workflow": "ProcessBirthday",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Else path: Select recipient email — prefer Personal over Home&quot;]",
      "resolvedValue": "[&quot;Else path: Select recipient email — prefer Personal over Home&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 23,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Else path: Select recipient email — prefer Personal over Home&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "ProcessBirthday.xaml",
      "workflow": "ProcessBirthday",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "\"\"",
      "resolvedValue": "\"\"",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 10,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "\"\"",
        "precedenceTier": 4
      }
    },
    {
      "file": "ProcessBirthday.xaml",
      "workflow": "ProcessBirthday",
      "activityType": "If",
      "propertyName": "Condition",
      "sourceBinding": "attribute-value",
      "originalValue": "[{&quot;type&quot;:&quot;expression&quot;,&quot;left&quot;:&quot;homeEmail&quot;,&quot;operator&quot;:&quot;&lt;&gt;&quot;,&quot;right&quot;:&quot;Nothing&quot;}]",
      "resolvedValue": "[{&quot;type&quot;:&quot;expression&quot;,&quot;left&quot;:&quot;homeEmail&quot;,&quot;operator&quot;:&quot;&lt;&gt;&quot;,&quot;right&quot;:&quot;Nothing&quot;}]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 5,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[{&quot;type&quot;:&quot;expression&quot;,&quot;left&quot;:&quot;homeEmail&quot;",
        "precedenceTier": 4
      }
    },
    {
      "file": "ProcessBirthday.xaml",
      "workflow": "ProcessBirthday",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Then path: If homeEmail non-empty assign selectedEmail=homeEmail else skip NoEligibleEmail&quot;]",
      "resolvedValue": "[&quot;Then path: If homeEmail non-empty assign selectedEmail=homeEmail else skip NoEligibleEmail&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 24,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Then path: If homeEmail non-empty assign selectedEmail=homeEmail else ski",
        "precedenceTier": 4
      }
    },
    {
      "file": "ProcessBirthday.xaml",
      "workflow": "ProcessBirthday",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Else path: If homeEmail non-empty assign selectedEmail=homeEmail else skip NoEligibleEmail&quot;]",
      "resolvedValue": "[&quot;Else path: If homeEmail non-empty assign selectedEmail=homeEmail else skip NoEligibleEmail&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 25,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Else path: If homeEmail non-empty assign selectedEmail=homeEmail else ski",
        "precedenceTier": 4
      }
    },
    {
      "file": "ProcessBirthday.xaml",
      "workflow": "ProcessBirthday",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "\"\"",
      "resolvedValue": "\"\"",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 11,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "\"\"",
        "precedenceTier": 4
      }
    },
    {
      "file": "ProcessBirthday.xaml",
      "workflow": "ProcessBirthday",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "\"\"",
      "resolvedValue": "\"\"",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 12,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "\"\"",
        "precedenceTier": 4
      }
    },
    {
      "file": "ProcessBirthday.xaml",
      "workflow": "ProcessBirthday",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot captured for error diagnostics&quot;]",
      "resolvedValue": "[&quot;Screenshot captured for error diagnostics&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 27,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot captured for error diagnostics&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "ProcessBirthday.xaml",
      "workflow": "ProcessBirthday",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
      "resolvedValue": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 28,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
        "precedenceTier": 4
      }
    },
    {
      "file": "ProcessBirthday.xaml",
      "workflow": "ProcessBirthday",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;[Error] Query BGV26_SentLog for existing sent record (deduplication) with RetryScope failed (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "resolvedValue": "[&quot;[Error] Query BGV26_SentLog for existing sent record (deduplication) with RetryScope failed (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 29,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;[Error] Query BGV26_SentLog for existing sent record (deduplication) with",
        "precedenceTier": 4
      }
    },
    {
      "file": "ProcessBirthday.xaml",
      "workflow": "ProcessBirthday",
      "activityType": "QueryEntity",
      "propertyName": "EntityType",
      "sourceBinding": "attribute-value",
      "originalValue": "BGV26_SentLog",
      "resolvedValue": "BGV26_SentLog",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "BGV26_SentLog",
        "precedenceTier": 4
      }
    },
    {
      "file": "ProcessBirthday.xaml",
      "workflow": "ProcessBirthday",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot captured for error diagnostics&quot;]",
      "resolvedValue": "[&quot;Screenshot captured for error diagnostics&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 30,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot captured for error diagnostics&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "ProcessBirthday.xaml",
      "workflow": "ProcessBirthday",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
      "resolvedValue": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 31,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
        "precedenceTier": 4
      }
    },
    {
      "file": "ProcessBirthday.xaml",
      "workflow": "ProcessBirthday",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;[Error] QueryEntity BGV26_SentLog for FullNameNormalized+GreetingYear+Status=Sent failed (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "resolvedValue": "[&quot;[Error] QueryEntity BGV26_SentLog for FullNameNormalized+GreetingYear+Status=Sent failed (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 32,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;[Error] QueryEntity BGV26_SentLog for FullNameNormalized+GreetingYear+Sta",
        "precedenceTier": 4
      }
    },
    {
      "file": "ProcessBirthday.xaml",
      "workflow": "ProcessBirthday",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "\"\"",
      "resolvedValue": "\"\"",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 13,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "\"\"",
        "precedenceTier": 4
      }
    },
    {
      "file": "ProcessBirthday.xaml",
      "workflow": "ProcessBirthday",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;=== Completed: ProcessBirthday ===&quot;]",
      "resolvedValue": "[&quot;=== Completed: ProcessBirthday ===&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 34,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;=== Completed: ProcessBirthday ===&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "GenerateAndValidateDraft.xaml",
      "workflow": "GenerateAndValidateDraft",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;=== Starting: GenerateAndValidateDraft ===&quot;]",
      "resolvedValue": "[&quot;=== Starting: GenerateAndValidateDraft ===&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;=== Starting: GenerateAndValidateDraft ===&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "GenerateAndValidateDraft.xaml",
      "workflow": "GenerateAndValidateDraft",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;[GenerateAndValidateDraft] START — FullName=&apos;&quot; &amp; InFullName &amp; &quot;&apos; WordCountRange=[&quot; &amp; InWordCountMin &amp; &quot;,&quot; &amp; InWordCountMax &amp; &quot;]&apos;]",
      "resolvedValue": "[&quot;[GenerateAndValidateDraft] START — FullName=&apos;&quot; &amp; InFullName &amp; &quot;&apos; WordCountRange=[&quot; &amp; InWordCountMin &amp; &quot;,&quot; &amp; InWordCountMax &amp; &quot;]&apos;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 1,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;[GenerateAndValidateDraft] START — FullName=&apos;&quot; &amp; InFullName",
        "precedenceTier": 4
      }
    },
    {
      "file": "GenerateAndValidateDraft.xaml",
      "workflow": "GenerateAndValidateDraft",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "\"\"",
      "resolvedValue": "\"\"",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "\"\"",
        "precedenceTier": 4
      }
    },
    {
      "file": "GenerateAndValidateDraft.xaml",
      "workflow": "GenerateAndValidateDraft",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;[GenerateAndValidateDraft] GenAI prompt assembled (length=&quot; &amp; genAiPrompt.Length.ToString() &amp; &quot;) for &apos;&quot; &amp; InFullName &amp; &quot;&apos;&quot;]",
      "resolvedValue": "[&quot;[GenerateAndValidateDraft] GenAI prompt assembled (length=&quot; &amp; genAiPrompt.Length.ToString() &amp; &quot;) for &apos;&quot; &amp; InFullName &amp; &quot;&apos;&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 2,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;[GenerateAndValidateDraft] GenAI prompt assembled (length=&quot; &amp; ge",
        "precedenceTier": 4
      }
    },
    {
      "file": "GenerateAndValidateDraft.xaml",
      "workflow": "GenerateAndValidateDraft",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot captured for error diagnostics&quot;]",
      "resolvedValue": "[&quot;Screenshot captured for error diagnostics&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 3,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot captured for error diagnostics&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "GenerateAndValidateDraft.xaml",
      "workflow": "GenerateAndValidateDraft",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
      "resolvedValue": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 4,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
        "precedenceTier": 4
      }
    },
    {
      "file": "GenerateAndValidateDraft.xaml",
      "workflow": "GenerateAndValidateDraft",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;[Error] Invoke GenAI Generate Text via Integration Service connection (with retry on transient API failures) failed (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "resolvedValue": "[&quot;[Error] Invoke GenAI Generate Text via Integration Service connection (with retry on transient API failures) failed (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 5,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;[Error] Invoke GenAI Generate Text via Integration Service connection (wi",
        "precedenceTier": 4
      }
    },
    {
      "file": "GenerateAndValidateDraft.xaml",
      "workflow": "GenerateAndValidateDraft",
      "activityType": "HttpClientRequest",
      "propertyName": "EndPoint",
      "sourceBinding": "attribute-value",
      "originalValue": "https://cloud.uipath.com/llmgateway_/api/GenerateText",
      "resolvedValue": "https://cloud.uipath.com/llmgateway_/api/GenerateText",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "https://cloud.uipath.com/llmgateway_/api/GenerateText",
        "precedenceTier": 4
      }
    },
    {
      "file": "GenerateAndValidateDraft.xaml",
      "workflow": "GenerateAndValidateDraft",
      "activityType": "HttpClientRequest",
      "propertyName": "Method",
      "sourceBinding": "attribute-value",
      "originalValue": "POST",
      "resolvedValue": "POST",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "POST",
        "precedenceTier": 4
      }
    },
    {
      "file": "GenerateAndValidateDraft.xaml",
      "workflow": "GenerateAndValidateDraft",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Retry exhausted for Call GenAI Generate Text endpoint (Integration Service GenAI connection), screenshot captured&quot;]",
      "resolvedValue": "[&quot;Retry exhausted for Call GenAI Generate Text endpoint (Integration Service GenAI connection), screenshot captured&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 6,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Retry exhausted for Call GenAI Generate Text endpoint (Integration Servic",
        "precedenceTier": 4
      }
    },
    {
      "file": "GenerateAndValidateDraft.xaml",
      "workflow": "GenerateAndValidateDraft",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot capture failed: &quot; &amp; ssEx.Message]",
      "resolvedValue": "[&quot;Screenshot capture failed: &quot; &amp; ssEx.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 7,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot capture failed: &quot; &amp; ssEx.Message]",
        "precedenceTier": 4
      }
    },
    {
      "file": "GenerateAndValidateDraft.xaml",
      "workflow": "GenerateAndValidateDraft",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;[Retry Exhausted] Call GenAI Generate Text endpoint (Integration Service GenAI connection) failed after retries — &quot; &amp; retryEx.Message]",
      "resolvedValue": "[&quot;[Retry Exhausted] Call GenAI Generate Text endpoint (Integration Service GenAI connection) failed after retries — &quot; &amp; retryEx.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 8,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;[Retry Exhausted] Call GenAI Generate Text endpoint (Integration Service ",
        "precedenceTier": 4
      }
    },
    {
      "file": "GenerateAndValidateDraft.xaml",
      "workflow": "GenerateAndValidateDraft",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;[GenerateAndValidateDraft] GenAI raw response received (length=&quot; &amp; If(genAiRawResponse Is Nothing, &quot;NULL&quot;, genAiRawResponse.Length.ToString()) &amp; &quot;) for &apos;&quot; &amp; InFullName &amp; &quot;&apos;&quot;]",
      "resolvedValue": "[&quot;[GenerateAndValidateDraft] GenAI raw response received (length=&quot; &amp; If(genAiRawResponse Is Nothing, &quot;NULL&quot;, genAiRawResponse.Length.ToString()) &amp; &quot;) for &apos;&quot; &amp; InFullName &amp; &quot;&apos;&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 9,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;[GenerateAndValidateDraft] GenAI raw response received (length=&quot; &am",
        "precedenceTier": 4
      }
    },
    {
      "file": "GenerateAndValidateDraft.xaml",
      "workflow": "GenerateAndValidateDraft",
      "activityType": "If",
      "propertyName": "Condition",
      "sourceBinding": "attribute-value",
      "originalValue": "[{&quot;type&quot;:&quot;expression&quot;,&quot;left&quot;:&quot;String.IsNullOrWhiteSpace(genAiRawResponse)&quot;,&quot;operator&quot;:&quot;=&quot;,&quot;right&quot;:&quot;True&quot;}]",
      "resolvedValue": "[{&quot;type&quot;:&quot;expression&quot;,&quot;left&quot;:&quot;String.IsNullOrWhiteSpace(genAiRawResponse)&quot;,&quot;operator&quot;:&quot;=&quot;,&quot;right&quot;:&quot;True&quot;}]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[{&quot;type&quot;:&quot;expression&quot;,&quot;left&quot;:&quot;String.IsNullOr",
        "precedenceTier": 4
      }
    },
    {
      "file": "GenerateAndValidateDraft.xaml",
      "workflow": "GenerateAndValidateDraft",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Then path: Guard: check GenAI response is not null or empty before parsing&quot;]",
      "resolvedValue": "[&quot;Then path: Guard: check GenAI response is not null or empty before parsing&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 10,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Then path: Guard: check GenAI response is not null or empty before parsin",
        "precedenceTier": 4
      }
    },
    {
      "file": "GenerateAndValidateDraft.xaml",
      "workflow": "GenerateAndValidateDraft",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Else path: Guard: check GenAI response is not null or empty before parsing&quot;]",
      "resolvedValue": "[&quot;Else path: Guard: check GenAI response is not null or empty before parsing&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 11,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Else path: Guard: check GenAI response is not null or empty before parsin",
        "precedenceTier": 4
      }
    },
    {
      "file": "GenerateAndValidateDraft.xaml",
      "workflow": "GenerateAndValidateDraft",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "\"\"",
      "resolvedValue": "\"\"",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 1,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "\"\"",
        "precedenceTier": 4
      }
    },
    {
      "file": "GenerateAndValidateDraft.xaml",
      "workflow": "GenerateAndValidateDraft",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;[GenerateAndValidateDraft] ERROR — GenAI response is null/empty for &apos;&quot; &amp; InFullName &amp; &quot;&apos;. Will flag for human review.&quot;]",
      "resolvedValue": "[&quot;[GenerateAndValidateDraft] ERROR — GenAI response is null/empty for &apos;&quot; &amp; InFullName &amp; &quot;&apos;. Will flag for human review.&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 12,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;[GenerateAndValidateDraft] ERROR — GenAI response is null/empty for &apos",
        "precedenceTier": 4
      }
    },
    {
      "file": "GenerateAndValidateDraft.xaml",
      "workflow": "GenerateAndValidateDraft",
      "activityType": "DeserializeJson",
      "propertyName": "JsonString",
      "sourceBinding": "attribute-value",
      "originalValue": "{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;genAiRawResponse&quot;}",
      "resolvedValue": "[genAiRawResponse]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;genAiRawResponse&q",
        "precedenceTier": 4
      }
    },
    {
      "file": "GenerateAndValidateDraft.xaml",
      "workflow": "GenerateAndValidateDraft",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot captured for error diagnostics&quot;]",
      "resolvedValue": "[&quot;Screenshot captured for error diagnostics&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 13,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot captured for error diagnostics&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "GenerateAndValidateDraft.xaml",
      "workflow": "GenerateAndValidateDraft",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
      "resolvedValue": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 14,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
        "precedenceTier": 4
      }
    },
    {
      "file": "GenerateAndValidateDraft.xaml",
      "workflow": "GenerateAndValidateDraft",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;[Error] Deserialize GenAI JSON response failed (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "resolvedValue": "[&quot;[Error] Deserialize GenAI JSON response failed (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 15,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;[Error] Deserialize GenAI JSON response failed (&quot; &amp; exception.Ge",
        "precedenceTier": 4
      }
    },
    {
      "file": "GenerateAndValidateDraft.xaml",
      "workflow": "GenerateAndValidateDraft",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "[True]",
      "resolvedValue": "[True]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 2,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[True]",
        "precedenceTier": 4
      }
    },
    {
      "file": "GenerateAndValidateDraft.xaml",
      "workflow": "GenerateAndValidateDraft",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;[GenerateAndValidateDraft] GenAI JSON parsed successfully for &apos;&quot; &amp; InFullName &amp; &quot;&apos;&quot;]",
      "resolvedValue": "[&quot;[GenerateAndValidateDraft] GenAI JSON parsed successfully for &apos;&quot; &amp; InFullName &amp; &quot;&apos;&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 16,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;[GenerateAndValidateDraft] GenAI JSON parsed successfully for &apos;&quot",
        "precedenceTier": 4
      }
    },
    {
      "file": "GenerateAndValidateDraft.xaml",
      "workflow": "GenerateAndValidateDraft",
      "activityType": "If",
      "propertyName": "Condition",
      "sourceBinding": "attribute-value",
      "originalValue": "[{&quot;type&quot;:&quot;expression&quot;,&quot;left&quot;:&quot;jsonParseSuccess AndAlso parsedJson(\\&quot;needsReview\\&quot;) IsNot Nothing AndAlso CBool(parsedJson(\\&quot;needsReview\\&quot;))&quot;,&quot;operator&quot;:&quot;=&quot;,&quot;right&quot;:&quot;True&quot;}]",
      "resolvedValue": "[{&quot;type&quot;:&quot;expression&quot;,&quot;left&quot;:&quot;jsonParseSuccess AndAlso parsedJson(\\&quot;needsReview\\&quot;) IsNot Nothing AndAlso CBool(parsedJson(\\&quot;needsReview\\&quot;))&quot;,&quot;operator&quot;:&quot;=&quot;,&quot;right&quot;:&quot;True&quot;}]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 1,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[{&quot;type&quot;:&quot;expression&quot;,&quot;left&quot;:&quot;jsonParseSucces",
        "precedenceTier": 4
      }
    },
    {
      "file": "GenerateAndValidateDraft.xaml",
      "workflow": "GenerateAndValidateDraft",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Then path: Check if GenAI signalled needsReview in response&quot;]",
      "resolvedValue": "[&quot;Then path: Check if GenAI signalled needsReview in response&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 17,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Then path: Check if GenAI signalled needsReview in response&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "GenerateAndValidateDraft.xaml",
      "workflow": "GenerateAndValidateDraft",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Else path: Check if GenAI signalled needsReview in response&quot;]",
      "resolvedValue": "[&quot;Else path: Check if GenAI signalled needsReview in response&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 18,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Else path: Check if GenAI signalled needsReview in response&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "GenerateAndValidateDraft.xaml",
      "workflow": "GenerateAndValidateDraft",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "\"\"",
      "resolvedValue": "\"\"",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 3,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "\"\"",
        "precedenceTier": 4
      }
    },
    {
      "file": "GenerateAndValidateDraft.xaml",
      "workflow": "GenerateAndValidateDraft",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;[GenerateAndValidateDraft] Extracted — Subject length=&quot; &amp; parsedSubject.Length.ToString() &amp; &quot; Body length=&quot; &amp; parsedBody.Length.ToString() &amp; &quot; for &apos;&quot; &amp; InFullName &amp; &quot;&apos;&quot;]",
      "resolvedValue": "[&quot;[GenerateAndValidateDraft] Extracted — Subject length=&quot; &amp; parsedSubject.Length.ToString() &amp; &quot; Body length=&quot; &amp; parsedBody.Length.ToString() &amp; &quot; for &apos;&quot; &amp; InFullName &amp; &quot;&apos;&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 19,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;[GenerateAndValidateDraft] Extracted — Subject length=&quot; &amp; parsed",
        "precedenceTier": 4
      }
    },
    {
      "file": "GenerateAndValidateDraft.xaml",
      "workflow": "GenerateAndValidateDraft",
      "activityType": "If",
      "propertyName": "Condition",
      "sourceBinding": "attribute-value",
      "originalValue": "[{&quot;type&quot;:&quot;expression&quot;,&quot;left&quot;:&quot;String.IsNullOrWhiteSpace(parsedSubject)&quot;,&quot;operator&quot;:&quot;=&quot;,&quot;right&quot;:&quot;True&quot;}]",
      "resolvedValue": "[{&quot;type&quot;:&quot;expression&quot;,&quot;left&quot;:&quot;String.IsNullOrWhiteSpace(parsedSubject)&quot;,&quot;operator&quot;:&quot;=&quot;,&quot;right&quot;:&quot;True&quot;}]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 2,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[{&quot;type&quot;:&quot;expression&quot;,&quot;left&quot;:&quot;String.IsNullOr",
        "precedenceTier": 4
      }
    },
    {
      "file": "GenerateAndValidateDraft.xaml",
      "workflow": "GenerateAndValidateDraft",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Then path: Validate subject is non-empty&quot;]",
      "resolvedValue": "[&quot;Then path: Validate subject is non-empty&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 20,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Then path: Validate subject is non-empty&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "GenerateAndValidateDraft.xaml",
      "workflow": "GenerateAndValidateDraft",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Else path: Validate subject is non-empty&quot;]",
      "resolvedValue": "[&quot;Else path: Validate subject is non-empty&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 21,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Else path: Validate subject is non-empty&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "GenerateAndValidateDraft.xaml",
      "workflow": "GenerateAndValidateDraft",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "\"\"",
      "resolvedValue": "\"\"",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 4,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "\"\"",
        "precedenceTier": 4
      }
    },
    {
      "file": "GenerateAndValidateDraft.xaml",
      "workflow": "GenerateAndValidateDraft",
      "activityType": "If",
      "propertyName": "Condition",
      "sourceBinding": "attribute-value",
      "originalValue": "[{&quot;type&quot;:&quot;expression&quot;,&quot;left&quot;:&quot;String.IsNullOrWhiteSpace(parsedBody)&quot;,&quot;operator&quot;:&quot;=&quot;,&quot;right&quot;:&quot;True&quot;}]",
      "resolvedValue": "[{&quot;type&quot;:&quot;expression&quot;,&quot;left&quot;:&quot;String.IsNullOrWhiteSpace(parsedBody)&quot;,&quot;operator&quot;:&quot;=&quot;,&quot;right&quot;:&quot;True&quot;}]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 3,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[{&quot;type&quot;:&quot;expression&quot;,&quot;left&quot;:&quot;String.IsNullOr",
        "precedenceTier": 4
      }
    },
    {
      "file": "GenerateAndValidateDraft.xaml",
      "workflow": "GenerateAndValidateDraft",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Then path: Validate body is non-empty&quot;]",
      "resolvedValue": "[&quot;Then path: Validate body is non-empty&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 22,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Then path: Validate body is non-empty&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "GenerateAndValidateDraft.xaml",
      "workflow": "GenerateAndValidateDraft",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Else path: Validate body is non-empty&quot;]",
      "resolvedValue": "[&quot;Else path: Validate body is non-empty&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 23,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Else path: Validate body is non-empty&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "GenerateAndValidateDraft.xaml",
      "workflow": "GenerateAndValidateDraft",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "\"\"",
      "resolvedValue": "\"\"",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 5,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "\"\"",
        "precedenceTier": 4
      }
    },
    {
      "file": "GenerateAndValidateDraft.xaml",
      "workflow": "GenerateAndValidateDraft",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "\"\"",
      "resolvedValue": "\"\"",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 6,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "\"\"",
        "precedenceTier": 4
      }
    },
    {
      "file": "GenerateAndValidateDraft.xaml",
      "workflow": "GenerateAndValidateDraft",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;[GenerateAndValidateDraft] WordCount=&quot; &amp; wordCount.ToString() &amp; &quot; (allowed &quot; &amp; InWordCountMin.ToString() &amp; &quot;-&quot; &amp; InWordCountMax.ToString() &amp; &quot;) for &apos;&quot; &amp; InFullName &amp; &quot;&apos;&quot;]",
      "resolvedValue": "[&quot;[GenerateAndValidateDraft] WordCount=&quot; &amp; wordCount.ToString() &amp; &quot; (allowed &quot; &amp; InWordCountMin.ToString() &amp; &quot;-&quot; &amp; InWordCountMax.ToString() &amp; &quot;) for &apos;&quot; &amp; InFullName &amp; &quot;&apos;&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 24,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;[GenerateAndValidateDraft] WordCount=&quot; &amp; wordCount.ToString() &a",
        "precedenceTier": 4
      }
    },
    {
      "file": "GenerateAndValidateDraft.xaml",
      "workflow": "GenerateAndValidateDraft",
      "activityType": "If",
      "propertyName": "Condition",
      "sourceBinding": "attribute-value",
      "originalValue": "[{&quot;type&quot;:&quot;expression&quot;,&quot;left&quot;:&quot;wordCount&quot;,&quot;operator&quot;:&quot;&lt;&quot;,&quot;right&quot;:&quot;InWordCountMin&quot;}]",
      "resolvedValue": "[{&quot;type&quot;:&quot;expression&quot;,&quot;left&quot;:&quot;wordCount&quot;,&quot;operator&quot;:&quot;&lt;&quot;,&quot;right&quot;:&quot;InWordCountMin&quot;}]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 4,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[{&quot;type&quot;:&quot;expression&quot;,&quot;left&quot;:&quot;wordCount&quot;",
        "precedenceTier": 4
      }
    },
    {
      "file": "GenerateAndValidateDraft.xaml",
      "workflow": "GenerateAndValidateDraft",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Then path: Validate word count below minimum&quot;]",
      "resolvedValue": "[&quot;Then path: Validate word count below minimum&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 25,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Then path: Validate word count below minimum&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "GenerateAndValidateDraft.xaml",
      "workflow": "GenerateAndValidateDraft",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Else path: Validate word count below minimum&quot;]",
      "resolvedValue": "[&quot;Else path: Validate word count below minimum&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 26,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Else path: Validate word count below minimum&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "GenerateAndValidateDraft.xaml",
      "workflow": "GenerateAndValidateDraft",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "\"\"",
      "resolvedValue": "\"\"",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 7,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "\"\"",
        "precedenceTier": 4
      }
    },
    {
      "file": "GenerateAndValidateDraft.xaml",
      "workflow": "GenerateAndValidateDraft",
      "activityType": "If",
      "propertyName": "Condition",
      "sourceBinding": "attribute-value",
      "originalValue": "[{&quot;type&quot;:&quot;expression&quot;,&quot;left&quot;:&quot;wordCount&quot;,&quot;operator&quot;:&quot;&gt;&quot;,&quot;right&quot;:&quot;InWordCountMax&quot;}]",
      "resolvedValue": "[{&quot;type&quot;:&quot;expression&quot;,&quot;left&quot;:&quot;wordCount&quot;,&quot;operator&quot;:&quot;&gt;&quot;,&quot;right&quot;:&quot;InWordCountMax&quot;}]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 5,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[{&quot;type&quot;:&quot;expression&quot;,&quot;left&quot;:&quot;wordCount&quot;",
        "precedenceTier": 4
      }
    },
    {
      "file": "GenerateAndValidateDraft.xaml",
      "workflow": "GenerateAndValidateDraft",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Then path: Validate word count above maximum&quot;]",
      "resolvedValue": "[&quot;Then path: Validate word count above maximum&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 27,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Then path: Validate word count above maximum&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "GenerateAndValidateDraft.xaml",
      "workflow": "GenerateAndValidateDraft",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Else path: Validate word count above maximum&quot;]",
      "resolvedValue": "[&quot;Else path: Validate word count above maximum&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 28,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Else path: Validate word count above maximum&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "GenerateAndValidateDraft.xaml",
      "workflow": "GenerateAndValidateDraft",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "\"\"",
      "resolvedValue": "\"\"",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 8,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "\"\"",
        "precedenceTier": 4
      }
    },
    {
      "file": "GenerateAndValidateDraft.xaml",
      "workflow": "GenerateAndValidateDraft",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "\"\"",
      "resolvedValue": "\"\"",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 9,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "\"\"",
        "precedenceTier": 4
      }
    },
    {
      "file": "GenerateAndValidateDraft.xaml",
      "workflow": "GenerateAndValidateDraft",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot captured for error diagnostics&quot;]",
      "resolvedValue": "[&quot;Screenshot captured for error diagnostics&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 29,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot captured for error diagnostics&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "GenerateAndValidateDraft.xaml",
      "workflow": "GenerateAndValidateDraft",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
      "resolvedValue": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 30,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
        "precedenceTier": 4
      }
    },
    {
      "file": "GenerateAndValidateDraft.xaml",
      "workflow": "GenerateAndValidateDraft",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;[Error] Check body for emoji characters using regex failed (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "resolvedValue": "[&quot;[Error] Check body for emoji characters using regex failed (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 31,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;[Error] Check body for emoji characters using regex failed (&quot; &amp; ",
        "precedenceTier": 4
      }
    },
    {
      "file": "GenerateAndValidateDraft.xaml",
      "workflow": "GenerateAndValidateDraft",
      "activityType": "If",
      "propertyName": "Condition",
      "sourceBinding": "attribute-value",
      "originalValue": "[{&quot;type&quot;:&quot;expression&quot;,&quot;left&quot;:&quot;containsEmoji&quot;,&quot;operator&quot;:&quot;=&quot;,&quot;right&quot;:&quot;True&quot;}]",
      "resolvedValue": "[{&quot;type&quot;:&quot;expression&quot;,&quot;left&quot;:&quot;containsEmoji&quot;,&quot;operator&quot;:&quot;=&quot;,&quot;right&quot;:&quot;True&quot;}]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 6,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[{&quot;type&quot;:&quot;expression&quot;,&quot;left&quot;:&quot;containsEmoji&q",
        "precedenceTier": 4
      }
    },
    {
      "file": "GenerateAndValidateDraft.xaml",
      "workflow": "GenerateAndValidateDraft",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Then path: If emoji detected, add validation error&quot;]",
      "resolvedValue": "[&quot;Then path: If emoji detected, add validation error&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 32,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Then path: If emoji detected, add validation error&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "GenerateAndValidateDraft.xaml",
      "workflow": "GenerateAndValidateDraft",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Else path: If emoji detected, add validation error&quot;]",
      "resolvedValue": "[&quot;Else path: If emoji detected, add validation error&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 33,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Else path: If emoji detected, add validation error&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "GenerateAndValidateDraft.xaml",
      "workflow": "GenerateAndValidateDraft",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "\"\"",
      "resolvedValue": "\"\"",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 10,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "\"\"",
        "precedenceTier": 4
      }
    },
    {
      "file": "GenerateAndValidateDraft.xaml",
      "workflow": "GenerateAndValidateDraft",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;[GenerateAndValidateDraft] EmojiCheck=&quot; &amp; containsEmoji.ToString() &amp; &quot; for &apos;&quot; &amp; InFullName &amp; &quot;&apos;&quot;]",
      "resolvedValue": "[&quot;[GenerateAndValidateDraft] EmojiCheck=&quot; &amp; containsEmoji.ToString() &amp; &quot; for &apos;&quot; &amp; InFullName &amp; &quot;&apos;&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 34,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;[GenerateAndValidateDraft] EmojiCheck=&quot; &amp; containsEmoji.ToString",
        "precedenceTier": 4
      }
    },
    {
      "file": "GenerateAndValidateDraft.xaml",
      "workflow": "GenerateAndValidateDraft",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "\"\"",
      "resolvedValue": "\"\"",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 11,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "\"\"",
        "precedenceTier": 4
      }
    },
    {
      "file": "GenerateAndValidateDraft.xaml",
      "workflow": "GenerateAndValidateDraft",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;=== Completed: GenerateAndValidateDraft ===&quot;]",
      "resolvedValue": "[&quot;=== Completed: GenerateAndValidateDraft ===&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 35,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;=== Completed: GenerateAndValidateDraft ===&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "HandleHumanReview.xaml",
      "workflow": "HandleHumanReview",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;=== Starting: HandleHumanReview ===&quot;]",
      "resolvedValue": "[&quot;=== Starting: HandleHumanReview ===&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;=== Starting: HandleHumanReview ===&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "HandleHumanReview.xaml",
      "workflow": "HandleHumanReview",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;[HandleHumanReview] ENTER ReviewType=&quot; &amp; InReviewType &amp; &quot; FullName=&quot; &amp; InFullName &amp; &quot; RunId=&quot; &amp; InRunId &amp; &quot; SentLogId=&quot; &amp; InSentLogId &amp; &quot; DraftId=&quot; &amp; InDraftId]",
      "resolvedValue": "[&quot;[HandleHumanReview] ENTER ReviewType=&quot; &amp; InReviewType &amp; &quot; FullName=&quot; &amp; InFullName &amp; &quot; RunId=&quot; &amp; InRunId &amp; &quot; SentLogId=&quot; &amp; InSentLogId &amp; &quot; DraftId=&quot; &amp; InDraftId]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 1,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;[HandleHumanReview] ENTER ReviewType=&quot; &amp; InReviewType &amp; &quo",
        "precedenceTier": 4
      }
    },
    {
      "file": "HandleHumanReview.xaml",
      "workflow": "HandleHumanReview",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "\"\"",
      "resolvedValue": "\"\"",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "\"\"",
        "precedenceTier": 4
      }
    },
    {
      "file": "HandleHumanReview.xaml",
      "workflow": "HandleHumanReview",
      "activityType": "If",
      "propertyName": "Condition",
      "sourceBinding": "attribute-value",
      "originalValue": "[{&quot;type&quot;:&quot;expression&quot;,&quot;left&quot;:&quot;isContentReview&quot;,&quot;operator&quot;:&quot;=&quot;,&quot;right&quot;:&quot;True&quot;}]",
      "resolvedValue": "[{&quot;type&quot;:&quot;expression&quot;,&quot;left&quot;:&quot;isContentReview&quot;,&quot;operator&quot;:&quot;=&quot;,&quot;right&quot;:&quot;True&quot;}]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[{&quot;type&quot;:&quot;expression&quot;,&quot;left&quot;:&quot;isContentReview",
        "precedenceTier": 4
      }
    },
    {
      "file": "HandleHumanReview.xaml",
      "workflow": "HandleHumanReview",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Then path: Branch: set task title and form schema path based on review type&quot;]",
      "resolvedValue": "[&quot;Then path: Branch: set task title and form schema path based on review type&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 2,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Then path: Branch: set task title and form schema path based on review ty",
        "precedenceTier": 4
      }
    },
    {
      "file": "HandleHumanReview.xaml",
      "workflow": "HandleHumanReview",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Else path: Branch: set task title and form schema path based on review type&quot;]",
      "resolvedValue": "[&quot;Else path: Branch: set task title and form schema path based on review type&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 3,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Else path: Branch: set task title and form schema path based on review ty",
        "precedenceTier": 4
      }
    },
    {
      "file": "HandleHumanReview.xaml",
      "workflow": "HandleHumanReview",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "\"\"",
      "resolvedValue": "\"\"",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 1,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "\"\"",
        "precedenceTier": 4
      }
    },
    {
      "file": "HandleHumanReview.xaml",
      "workflow": "HandleHumanReview",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "\"\"",
      "resolvedValue": "\"\"",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 2,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "\"\"",
        "precedenceTier": 4
      }
    },
    {
      "file": "HandleHumanReview.xaml",
      "workflow": "HandleHumanReview",
      "activityType": "CreateFormTask",
      "propertyName": "Title",
      "sourceBinding": "attribute-value",
      "originalValue": "{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;taskTitle&quot;}",
      "resolvedValue": "[taskTitle]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;taskTitle&quot;}",
        "precedenceTier": 4
      }
    },
    {
      "file": "HandleHumanReview.xaml",
      "workflow": "HandleHumanReview",
      "activityType": "CreateFormTask",
      "propertyName": "FormSchemaPath",
      "sourceBinding": "attribute-value",
      "originalValue": "{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;taskFormSchemaPath&quot;}",
      "resolvedValue": "[taskFormSchemaPath]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;taskFormSchemaPath",
        "precedenceTier": 4
      }
    },
    {
      "file": "HandleHumanReview.xaml",
      "workflow": "HandleHumanReview",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot captured for error diagnostics&quot;]",
      "resolvedValue": "[&quot;Screenshot captured for error diagnostics&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 5,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot captured for error diagnostics&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "HandleHumanReview.xaml",
      "workflow": "HandleHumanReview",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
      "resolvedValue": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 6,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
        "precedenceTier": 4
      }
    },
    {
      "file": "HandleHumanReview.xaml",
      "workflow": "HandleHumanReview",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;[Error] Create Action Center FormTask with review data failed (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "resolvedValue": "[&quot;[Error] Create Action Center FormTask with review data failed (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 7,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;[Error] Create Action Center FormTask with review data failed (&quot; &am",
        "precedenceTier": 4
      }
    },
    {
      "file": "HandleHumanReview.xaml",
      "workflow": "HandleHumanReview",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "\"\"",
      "resolvedValue": "\"\"",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 3,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "\"\"",
        "precedenceTier": 4
      }
    },
    {
      "file": "HandleHumanReview.xaml",
      "workflow": "HandleHumanReview",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;[HandleHumanReview] Action Center task created. RunId=&quot; &amp; InRunId &amp; &quot; FullName=&quot; &amp; InFullName &amp; &quot; ReviewType=&quot; &amp; InReviewType]",
      "resolvedValue": "[&quot;[HandleHumanReview] Action Center task created. RunId=&quot; &amp; InRunId &amp; &quot; FullName=&quot; &amp; InFullName &amp; &quot; ReviewType=&quot; &amp; InReviewType]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 8,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;[HandleHumanReview] Action Center task created. RunId=&quot; &amp; InRunI",
        "precedenceTier": 4
      }
    },
    {
      "file": "HandleHumanReview.xaml",
      "workflow": "HandleHumanReview",
      "activityType": "UpdateEntity",
      "propertyName": "EntityType",
      "sourceBinding": "attribute-value",
      "originalValue": "BGV26_SentLog",
      "resolvedValue": "BGV26_SentLog",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "BGV26_SentLog",
        "precedenceTier": 4
      }
    },
    {
      "file": "HandleHumanReview.xaml",
      "workflow": "HandleHumanReview",
      "activityType": "UpdateEntity",
      "propertyName": "EntityObject",
      "sourceBinding": "attribute-value",
      "originalValue": "{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;sentLogUpdateObj&quot;}",
      "resolvedValue": "[sentLogUpdateObj]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;sentLogUpdateObj&q",
        "precedenceTier": 4
      }
    },
    {
      "file": "HandleHumanReview.xaml",
      "workflow": "HandleHumanReview",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Retry exhausted for Update BGV26_SentLog status to PendingReview before suspending, screenshot captured&quot;]",
      "resolvedValue": "[&quot;Retry exhausted for Update BGV26_SentLog status to PendingReview before suspending, screenshot captured&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 9,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Retry exhausted for Update BGV26_SentLog status to PendingReview before s",
        "precedenceTier": 4
      }
    },
    {
      "file": "HandleHumanReview.xaml",
      "workflow": "HandleHumanReview",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot capture failed: &quot; &amp; ssEx.Message]",
      "resolvedValue": "[&quot;Screenshot capture failed: &quot; &amp; ssEx.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 10,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot capture failed: &quot; &amp; ssEx.Message]",
        "precedenceTier": 4
      }
    },
    {
      "file": "HandleHumanReview.xaml",
      "workflow": "HandleHumanReview",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;[Retry Exhausted] Update BGV26_SentLog status to PendingReview before suspending failed after retries — &quot; &amp; retryEx.Message]",
      "resolvedValue": "[&quot;[Retry Exhausted] Update BGV26_SentLog status to PendingReview before suspending failed after retries — &quot; &amp; retryEx.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 11,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;[Retry Exhausted] Update BGV26_SentLog status to PendingReview before sus",
        "precedenceTier": 4
      }
    },
    {
      "file": "HandleHumanReview.xaml",
      "workflow": "HandleHumanReview",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot captured for error diagnostics&quot;]",
      "resolvedValue": "[&quot;Screenshot captured for error diagnostics&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 12,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot captured for error diagnostics&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "HandleHumanReview.xaml",
      "workflow": "HandleHumanReview",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
      "resolvedValue": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 13,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
        "precedenceTier": 4
      }
    },
    {
      "file": "HandleHumanReview.xaml",
      "workflow": "HandleHumanReview",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;[Error] Wait for Form Task completion (suspends workflow until reviewer acts or SLA expires) failed (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "resolvedValue": "[&quot;[Error] Wait for Form Task completion (suspends workflow until reviewer acts or SLA expires) failed (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 14,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;[Error] Wait for Form Task completion (suspends workflow until reviewer a",
        "precedenceTier": 4
      }
    },
    {
      "file": "HandleHumanReview.xaml",
      "workflow": "HandleHumanReview",
      "activityType": "If",
      "propertyName": "Condition",
      "sourceBinding": "attribute-value",
      "originalValue": "[{&quot;type&quot;:&quot;expression&quot;,&quot;left&quot;:&quot;taskTimedOut&quot;,&quot;operator&quot;:&quot;=&quot;,&quot;right&quot;:&quot;True&quot;}]",
      "resolvedValue": "[{&quot;type&quot;:&quot;expression&quot;,&quot;left&quot;:&quot;taskTimedOut&quot;,&quot;operator&quot;:&quot;=&quot;,&quot;right&quot;:&quot;True&quot;}]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 1,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[{&quot;type&quot;:&quot;expression&quot;,&quot;left&quot;:&quot;taskTimedOut&qu",
        "precedenceTier": 4
      }
    },
    {
      "file": "HandleHumanReview.xaml",
      "workflow": "HandleHumanReview",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Then path: Branch on timeout: check if task timed out for SLA escalation&quot;]",
      "resolvedValue": "[&quot;Then path: Branch on timeout: check if task timed out for SLA escalation&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 16,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Then path: Branch on timeout: check if task timed out for SLA escalation&",
        "precedenceTier": 4
      }
    },
    {
      "file": "HandleHumanReview.xaml",
      "workflow": "HandleHumanReview",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Else path: Branch on timeout: check if task timed out for SLA escalation&quot;]",
      "resolvedValue": "[&quot;Else path: Branch on timeout: check if task timed out for SLA escalation&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 17,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Else path: Branch on timeout: check if task timed out for SLA escalation&",
        "precedenceTier": 4
      }
    },
    {
      "file": "HandleHumanReview.xaml",
      "workflow": "HandleHumanReview",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "[DateTime.Now]",
      "resolvedValue": "[DateTime.Now]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 4,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[DateTime.Now]",
        "precedenceTier": 4
      }
    },
    {
      "file": "HandleHumanReview.xaml",
      "workflow": "HandleHumanReview",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "[New DateTime(DateTime.Now.Year, DateTime.Now.Month, DateTime.Now.Day, 23, 30, 0)]",
      "resolvedValue": "[New DateTime(DateTime.Now.Year, DateTime.Now.Month, DateTime.Now.Day, 23, 30, 0)]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 5,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[New DateTime(DateTime.Now.Year, DateTime.Now.Month, DateTime.Now.Day, 23, 30, 0",
        "precedenceTier": 4
      }
    },
    {
      "file": "HandleHumanReview.xaml",
      "workflow": "HandleHumanReview",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "\"\"",
      "resolvedValue": "\"\"",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 6,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "\"\"",
        "precedenceTier": 4
      }
    },
    {
      "file": "HandleHumanReview.xaml",
      "workflow": "HandleHumanReview",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "\"\"",
      "resolvedValue": "\"\"",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 7,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "\"\"",
        "precedenceTier": 4
      }
    },
    {
      "file": "HandleHumanReview.xaml",
      "workflow": "HandleHumanReview",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "\"\"",
      "resolvedValue": "\"\"",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 8,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "\"\"",
        "precedenceTier": 4
      }
    },
    {
      "file": "HandleHumanReview.xaml",
      "workflow": "HandleHumanReview",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "\"\"",
      "resolvedValue": "\"\"",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 9,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "\"\"",
        "precedenceTier": 4
      }
    },
    {
      "file": "HandleHumanReview.xaml",
      "workflow": "HandleHumanReview",
      "activityType": "GmailSendMessage",
      "propertyName": "To",
      "sourceBinding": "attribute-value",
      "originalValue": "ninemush@gmail.com",
      "resolvedValue": "ninemush@gmail.com",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "ninemush@gmail.com",
        "precedenceTier": 4
      }
    },
    {
      "file": "HandleHumanReview.xaml",
      "workflow": "HandleHumanReview",
      "activityType": "GmailSendMessage",
      "propertyName": "Subject",
      "sourceBinding": "attribute-value",
      "originalValue": "{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;escalationSubject&quot;}",
      "resolvedValue": "[escalationSubject]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;escalationSubject&",
        "precedenceTier": 4
      }
    },
    {
      "file": "HandleHumanReview.xaml",
      "workflow": "HandleHumanReview",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot captured for error diagnostics&quot;]",
      "resolvedValue": "[&quot;Screenshot captured for error diagnostics&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 19,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot captured for error diagnostics&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "HandleHumanReview.xaml",
      "workflow": "HandleHumanReview",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
      "resolvedValue": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 20,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
        "precedenceTier": 4
      }
    },
    {
      "file": "HandleHumanReview.xaml",
      "workflow": "HandleHumanReview",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;[Error] Send SLA escalation notification email via GmailSendMessage failed (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "resolvedValue": "[&quot;[Error] Send SLA escalation notification email via GmailSendMessage failed (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 21,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;[Error] Send SLA escalation notification email via GmailSendMessage faile",
        "precedenceTier": 4
      }
    },
    {
      "file": "HandleHumanReview.xaml",
      "workflow": "HandleHumanReview",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;[HandleHumanReview] Escalation email sent to ninemush@gmail.com. FullName=&quot; &amp; InFullName &amp; &quot; RunId=&quot; &amp; InRunId]",
      "resolvedValue": "[&quot;[HandleHumanReview] Escalation email sent to ninemush@gmail.com. FullName=&quot; &amp; InFullName &amp; &quot; RunId=&quot; &amp; InRunId]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 22,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;[HandleHumanReview] Escalation email sent to ninemush@gmail.com. FullName",
        "precedenceTier": 4
      }
    },
    {
      "file": "HandleHumanReview.xaml",
      "workflow": "HandleHumanReview",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "\"\"",
      "resolvedValue": "\"\"",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 10,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "\"\"",
        "precedenceTier": 4
      }
    },
    {
      "file": "HandleHumanReview.xaml",
      "workflow": "HandleHumanReview",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot captured for error diagnostics&quot;]",
      "resolvedValue": "[&quot;Screenshot captured for error diagnostics&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 23,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot captured for error diagnostics&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "HandleHumanReview.xaml",
      "workflow": "HandleHumanReview",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
      "resolvedValue": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 24,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
        "precedenceTier": 4
      }
    },
    {
      "file": "HandleHumanReview.xaml",
      "workflow": "HandleHumanReview",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;[Error] Extract decision from taskOutcome on normal completion (non-timeout branch) failed (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "resolvedValue": "[&quot;[Error] Extract decision from taskOutcome on normal completion (non-timeout branch) failed (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 25,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;[Error] Extract decision from taskOutcome on normal completion (non-timeo",
        "precedenceTier": 4
      }
    },
    {
      "file": "HandleHumanReview.xaml",
      "workflow": "HandleHumanReview",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "\"\"",
      "resolvedValue": "\"\"",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 11,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "\"\"",
        "precedenceTier": 4
      }
    },
    {
      "file": "HandleHumanReview.xaml",
      "workflow": "HandleHumanReview",
      "activityType": "If",
      "propertyName": "Condition",
      "sourceBinding": "attribute-value",
      "originalValue": "[{&quot;type&quot;:&quot;expression&quot;,&quot;left&quot;:&quot;isContentReview&quot;,&quot;operator&quot;:&quot;=&quot;,&quot;right&quot;:&quot;True&quot;}]",
      "resolvedValue": "[{&quot;type&quot;:&quot;expression&quot;,&quot;left&quot;:&quot;isContentReview&quot;,&quot;operator&quot;:&quot;=&quot;,&quot;right&quot;:&quot;True&quot;}]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 2,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[{&quot;type&quot;:&quot;expression&quot;,&quot;left&quot;:&quot;isContentReview",
        "precedenceTier": 4
      }
    },
    {
      "file": "HandleHumanReview.xaml",
      "workflow": "HandleHumanReview",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Then path: Branch on review type to extract type-specific output fields&quot;]",
      "resolvedValue": "[&quot;Then path: Branch on review type to extract type-specific output fields&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 27,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Then path: Branch on review type to extract type-specific output fields&q",
        "precedenceTier": 4
      }
    },
    {
      "file": "HandleHumanReview.xaml",
      "workflow": "HandleHumanReview",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Else path: Branch on review type to extract type-specific output fields&quot;]",
      "resolvedValue": "[&quot;Else path: Branch on review type to extract type-specific output fields&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 28,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Else path: Branch on review type to extract type-specific output fields&q",
        "precedenceTier": 4
      }
    },
    {
      "file": "HandleHumanReview.xaml",
      "workflow": "HandleHumanReview",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "\"\"",
      "resolvedValue": "\"\"",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 12,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "\"\"",
        "precedenceTier": 4
      }
    },
    {
      "file": "HandleHumanReview.xaml",
      "workflow": "HandleHumanReview",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot captured for error diagnostics&quot;]",
      "resolvedValue": "[&quot;Screenshot captured for error diagnostics&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 29,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot captured for error diagnostics&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "HandleHumanReview.xaml",
      "workflow": "HandleHumanReview",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
      "resolvedValue": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 30,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
        "precedenceTier": 4
      }
    },
    {
      "file": "HandleHumanReview.xaml",
      "workflow": "HandleHumanReview",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;[Error] Extract ApprovedSubject from taskOutcome for ContentReview failed (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "resolvedValue": "[&quot;[Error] Extract ApprovedSubject from taskOutcome for ContentReview failed (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 31,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;[Error] Extract ApprovedSubject from taskOutcome for ContentReview failed",
        "precedenceTier": 4
      }
    },
    {
      "file": "HandleHumanReview.xaml",
      "workflow": "HandleHumanReview",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "\"\"",
      "resolvedValue": "\"\"",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 13,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "\"\"",
        "precedenceTier": 4
      }
    },
    {
      "file": "HandleHumanReview.xaml",
      "workflow": "HandleHumanReview",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot captured for error diagnostics&quot;]",
      "resolvedValue": "[&quot;Screenshot captured for error diagnostics&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 32,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot captured for error diagnostics&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "HandleHumanReview.xaml",
      "workflow": "HandleHumanReview",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
      "resolvedValue": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 33,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
        "precedenceTier": 4
      }
    },
    {
      "file": "HandleHumanReview.xaml",
      "workflow": "HandleHumanReview",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;[Error] Extract ApprovedBody from taskOutcome for ContentReview failed (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "resolvedValue": "[&quot;[Error] Extract ApprovedBody from taskOutcome for ContentReview failed (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 34,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;[Error] Extract ApprovedBody from taskOutcome for ContentReview failed (&",
        "precedenceTier": 4
      }
    },
    {
      "file": "HandleHumanReview.xaml",
      "workflow": "HandleHumanReview",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "\"\"",
      "resolvedValue": "\"\"",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 14,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "\"\"",
        "precedenceTier": 4
      }
    },
    {
      "file": "HandleHumanReview.xaml",
      "workflow": "HandleHumanReview",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot captured for error diagnostics&quot;]",
      "resolvedValue": "[&quot;Screenshot captured for error diagnostics&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 35,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot captured for error diagnostics&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "HandleHumanReview.xaml",
      "workflow": "HandleHumanReview",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
      "resolvedValue": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 36,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
        "precedenceTier": 4
      }
    },
    {
      "file": "HandleHumanReview.xaml",
      "workflow": "HandleHumanReview",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;[Error] Extract SelectedRecipientEmail from taskOutcome for ContactDisambiguation failed (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "resolvedValue": "[&quot;[Error] Extract SelectedRecipientEmail from taskOutcome for ContactDisambiguation failed (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 37,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;[Error] Extract SelectedRecipientEmail from taskOutcome for ContactDisamb",
        "precedenceTier": 4
      }
    },
    {
      "file": "HandleHumanReview.xaml",
      "workflow": "HandleHumanReview",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "\"\"",
      "resolvedValue": "\"\"",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 15,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "\"\"",
        "precedenceTier": 4
      }
    },
    {
      "file": "HandleHumanReview.xaml",
      "workflow": "HandleHumanReview",
      "activityType": "If",
      "propertyName": "Condition",
      "sourceBinding": "attribute-value",
      "originalValue": "[{&quot;type&quot;:&quot;expression&quot;,&quot;left&quot;:&quot;isContentReview AndAlso (approvalDecisionLocal = \\&quot;Approve\\&quot; OrElse approvalDecisionLocal = \\&quot;EditAndApprove\\&quot;)&quot;,&quot;operator&quot;:&quot;=&quot;,&quot;right&quot;:&quot;True&quot;}]",
      "resolvedValue": "[{&quot;type&quot;:&quot;expression&quot;,&quot;left&quot;:&quot;isContentReview AndAlso (approvalDecisionLocal = \\&quot;Approve\\&quot; OrElse approvalDecisionLocal = \\&quot;EditAndApprove\\&quot;)&quot;,&quot;operator&quot;:&quot;=&quot;,&quot;right&quot;:&quot;True&quot;}]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 3,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[{&quot;type&quot;:&quot;expression&quot;,&quot;left&quot;:&quot;isContentReview",
        "precedenceTier": 4
      }
    },
    {
      "file": "HandleHumanReview.xaml",
      "workflow": "HandleHumanReview",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Then path: Conditional re-validation of reviewer-approved content for ContentReview path&quot;]",
      "resolvedValue": "[&quot;Then path: Conditional re-validation of reviewer-approved content for ContentReview path&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 38,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Then path: Conditional re-validation of reviewer-approved content for Con",
        "precedenceTier": 4
      }
    },
    {
      "file": "HandleHumanReview.xaml",
      "workflow": "HandleHumanReview",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Else path: Conditional re-validation of reviewer-approved content for ContentReview path&quot;]",
      "resolvedValue": "[&quot;Else path: Conditional re-validation of reviewer-approved content for ContentReview path&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 39,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Else path: Conditional re-validation of reviewer-approved content for Con",
        "precedenceTier": 4
      }
    },
    {
      "file": "HandleHumanReview.xaml",
      "workflow": "HandleHumanReview",
      "activityType": "InvokeWorkflowFile",
      "propertyName": "WorkflowFileName",
      "sourceBinding": "attribute-value",
      "originalValue": "GenerateAndValidateDraft.xaml",
      "resolvedValue": "GenerateAndValidateDraft.xaml",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "GenerateAndValidateDraft.xaml",
        "precedenceTier": 4
      }
    },
    {
      "file": "HandleHumanReview.xaml",
      "workflow": "HandleHumanReview",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot captured for error diagnostics&quot;]",
      "resolvedValue": "[&quot;Screenshot captured for error diagnostics&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 40,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot captured for error diagnostics&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "HandleHumanReview.xaml",
      "workflow": "HandleHumanReview",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
      "resolvedValue": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 41,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
        "precedenceTier": 4
      }
    },
    {
      "file": "HandleHumanReview.xaml",
      "workflow": "HandleHumanReview",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;[Error] Invoke GenerateAndValidateDraft to re-validate reviewer-edited content failed (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "resolvedValue": "[&quot;[Error] Invoke GenerateAndValidateDraft to re-validate reviewer-edited content failed (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 42,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;[Error] Invoke GenerateAndValidateDraft to re-validate reviewer-edited co",
        "precedenceTier": 4
      }
    },
    {
      "file": "HandleHumanReview.xaml",
      "workflow": "HandleHumanReview",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;=== Completed: HandleHumanReview ===&quot;]",
      "resolvedValue": "[&quot;=== Completed: HandleHumanReview ===&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 43,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;=== Completed: HandleHumanReview ===&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "Finalize.xaml",
      "workflow": "Finalize",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;STUB: Finalize — Final validation remediation — original XAML had well-formedness violations. Implement the actual logic here.&quot;]",
      "resolvedValue": "[&quot;STUB: Finalize — Final validation remediation — original XAML had well-formedness violations. Implement the actual logic here.&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;STUB: Finalize — Final validation remediation — original XAML had well-fo",
        "precedenceTier": 4
      }
    },
    {
      "file": "Finalize.xaml",
      "workflow": "Finalize",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;=== Completed: Finalize ===&quot;]",
      "resolvedValue": "[&quot;=== Completed: Finalize ===&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 1,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;=== Completed: Finalize ===&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "InitAllSettings.xaml",
      "workflow": "InitAllSettings",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Reading configuration from Config.xlsx...&quot;]",
      "resolvedValue": "[&quot;Reading configuration from Config.xlsx...&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Reading configuration from Config.xlsx...&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "InitAllSettings.xaml",
      "workflow": "InitAllSettings",
      "activityType": "ExcelApplicationScope",
      "propertyName": "WorkbookPath",
      "sourceBinding": "variable",
      "originalValue": "[str_ConfigPath]",
      "resolvedValue": "[str_ConfigPath]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "variable",
        "sourceName": "str_ConfigPath",
        "sourceWorkflow": "InitAllSettings",
        "precedenceTier": 2
      }
    },
    {
      "file": "InitAllSettings.xaml",
      "workflow": "InitAllSettings",
      "activityType": "ExcelReadRange",
      "propertyName": "DataTable",
      "sourceBinding": "variable",
      "originalValue": "[dt_Settings]",
      "resolvedValue": "[dt_Settings]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "variable",
        "sourceName": "dt_Settings",
        "sourceWorkflow": "InitAllSettings",
        "precedenceTier": 2
      }
    },
    {
      "file": "InitAllSettings.xaml",
      "workflow": "InitAllSettings",
      "activityType": "ExcelReadRange",
      "propertyName": "DataTable",
      "sourceBinding": "variable",
      "originalValue": "[dt_Constants]",
      "resolvedValue": "[dt_Constants]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 1,
      "provenance": {
        "sourceKind": "variable",
        "sourceName": "dt_Constants",
        "sourceWorkflow": "InitAllSettings",
        "precedenceTier": 2
      }
    },
    {
      "file": "InitAllSettings.xaml",
      "workflow": "InitAllSettings",
      "activityType": "ForEach",
      "propertyName": "Values",
      "sourceBinding": "attribute-value",
      "originalValue": "[dt_Settings.Rows]",
      "resolvedValue": "[dt_Settings.Rows]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[dt_Settings.Rows]",
        "precedenceTier": 4
      }
    },
    {
      "file": "InitAllSettings.xaml",
      "workflow": "InitAllSettings",
      "activityType": "Assign",
      "propertyName": "To",
      "sourceBinding": "attribute-value",
      "originalValue": "[dict_Config(row(&quot;Name&quot;).ToString)]",
      "resolvedValue": "[dict_Config(row(&quot;Name&quot;).ToString)]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[dict_Config(row(&quot;Name&quot;).ToString)]",
        "precedenceTier": 4
      }
    },
    {
      "file": "InitAllSettings.xaml",
      "workflow": "InitAllSettings",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "[row(&quot;Value&quot;)]",
      "resolvedValue": "[row(&quot;Value&quot;)]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[row(&quot;Value&quot;)]",
        "precedenceTier": 4
      }
    },
    {
      "file": "InitAllSettings.xaml",
      "workflow": "InitAllSettings",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Processing setting: &quot; &amp; row(&quot;Name&quot;).ToString]",
      "resolvedValue": "[&quot;Processing setting: &quot; &amp; row(&quot;Name&quot;).ToString]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 1,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Processing setting: &quot; &amp; row(&quot;Name&quot;).ToString]",
        "precedenceTier": 4
      }
    },
    {
      "file": "InitAllSettings.xaml",
      "workflow": "InitAllSettings",
      "activityType": "GetCredential",
      "propertyName": "AssetName",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;BGV26_GSuite_ServiceAccount_Credential&quot;]",
      "resolvedValue": "[&quot;BGV26_GSuite_ServiceAccount_Credential&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;BGV26_GSuite_ServiceAccount_Credential&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "InitAllSettings.xaml",
      "workflow": "InitAllSettings",
      "activityType": "Assign",
      "propertyName": "To",
      "sourceBinding": "attribute-value",
      "originalValue": "[dict_Config(&quot;BGV26_GSuite_ServiceAccount_Credential&quot;)]",
      "resolvedValue": "[dict_Config(&quot;BGV26_GSuite_ServiceAccount_Credential&quot;)]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 1,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[dict_Config(&quot;BGV26_GSuite_ServiceAccount_Credential&quot;)]",
        "precedenceTier": 4
      }
    },
    {
      "file": "InitAllSettings.xaml",
      "workflow": "InitAllSettings",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "variable",
      "originalValue": "[str_TempUser]",
      "resolvedValue": "[str_TempUser]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 1,
      "provenance": {
        "sourceKind": "variable",
        "sourceName": "str_TempUser",
        "sourceWorkflow": "InitAllSettings",
        "precedenceTier": 2
      }
    },
    {
      "file": "InitAllSettings.xaml",
      "workflow": "InitAllSettings",
      "activityType": "Assign",
      "propertyName": "To",
      "sourceBinding": "attribute-value",
      "originalValue": "[dict_Config(&quot;BGV26_BirthdaysCalendarName&quot;)]",
      "resolvedValue": "[dict_Config(&quot;BGV26_BirthdaysCalendarName&quot;)]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 2,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[dict_Config(&quot;BGV26_BirthdaysCalendarName&quot;)]",
        "precedenceTier": 4
      }
    },
    {
      "file": "InitAllSettings.xaml",
      "workflow": "InitAllSettings",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "variable",
      "originalValue": "[str_AssetValue]",
      "resolvedValue": "[str_AssetValue]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 2,
      "provenance": {
        "sourceKind": "variable",
        "sourceName": "str_AssetValue",
        "sourceWorkflow": "InitAllSettings",
        "precedenceTier": 2
      }
    },
    {
      "file": "InitAllSettings.xaml",
      "workflow": "InitAllSettings",
      "activityType": "Assign",
      "propertyName": "To",
      "sourceBinding": "attribute-value",
      "originalValue": "[dict_Config(&quot;BGV26_TimeZone&quot;)]",
      "resolvedValue": "[dict_Config(&quot;BGV26_TimeZone&quot;)]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 3,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[dict_Config(&quot;BGV26_TimeZone&quot;)]",
        "precedenceTier": 4
      }
    },
    {
      "file": "InitAllSettings.xaml",
      "workflow": "InitAllSettings",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "variable",
      "originalValue": "[str_AssetValue]",
      "resolvedValue": "[str_AssetValue]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 3,
      "provenance": {
        "sourceKind": "variable",
        "sourceName": "str_AssetValue",
        "sourceWorkflow": "InitAllSettings",
        "precedenceTier": 2
      }
    },
    {
      "file": "InitAllSettings.xaml",
      "workflow": "InitAllSettings",
      "activityType": "Assign",
      "propertyName": "To",
      "sourceBinding": "attribute-value",
      "originalValue": "[dict_Config(&quot;BGV26_EmailStyleSpec&quot;)]",
      "resolvedValue": "[dict_Config(&quot;BGV26_EmailStyleSpec&quot;)]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 4,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[dict_Config(&quot;BGV26_EmailStyleSpec&quot;)]",
        "precedenceTier": 4
      }
    },
    {
      "file": "InitAllSettings.xaml",
      "workflow": "InitAllSettings",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "variable",
      "originalValue": "[str_AssetValue]",
      "resolvedValue": "[str_AssetValue]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 4,
      "provenance": {
        "sourceKind": "variable",
        "sourceName": "str_AssetValue",
        "sourceWorkflow": "InitAllSettings",
        "precedenceTier": 2
      }
    },
    {
      "file": "InitAllSettings.xaml",
      "workflow": "InitAllSettings",
      "activityType": "Assign",
      "propertyName": "To",
      "sourceBinding": "attribute-value",
      "originalValue": "[dict_Config(&quot;BGV26_EmailWordCountMin&quot;)]",
      "resolvedValue": "[dict_Config(&quot;BGV26_EmailWordCountMin&quot;)]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 5,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[dict_Config(&quot;BGV26_EmailWordCountMin&quot;)]",
        "precedenceTier": 4
      }
    },
    {
      "file": "InitAllSettings.xaml",
      "workflow": "InitAllSettings",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "variable",
      "originalValue": "[str_AssetValue]",
      "resolvedValue": "[str_AssetValue]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 5,
      "provenance": {
        "sourceKind": "variable",
        "sourceName": "str_AssetValue",
        "sourceWorkflow": "InitAllSettings",
        "precedenceTier": 2
      }
    },
    {
      "file": "InitAllSettings.xaml",
      "workflow": "InitAllSettings",
      "activityType": "Assign",
      "propertyName": "To",
      "sourceBinding": "attribute-value",
      "originalValue": "[dict_Config(&quot;BGV26_EmailWordCountMax&quot;)]",
      "resolvedValue": "[dict_Config(&quot;BGV26_EmailWordCountMax&quot;)]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 6,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[dict_Config(&quot;BGV26_EmailWordCountMax&quot;)]",
        "precedenceTier": 4
      }
    },
    {
      "file": "InitAllSettings.xaml",
      "workflow": "InitAllSettings",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "variable",
      "originalValue": "[str_AssetValue]",
      "resolvedValue": "[str_AssetValue]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 6,
      "provenance": {
        "sourceKind": "variable",
        "sourceName": "str_AssetValue",
        "sourceWorkflow": "InitAllSettings",
        "precedenceTier": 2
      }
    },
    {
      "file": "InitAllSettings.xaml",
      "workflow": "InitAllSettings",
      "activityType": "Assign",
      "propertyName": "To",
      "sourceBinding": "attribute-value",
      "originalValue": "[dict_Config(&quot;BGV26_AllowActionCenterFallback&quot;)]",
      "resolvedValue": "[dict_Config(&quot;BGV26_AllowActionCenterFallback&quot;)]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 7,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[dict_Config(&quot;BGV26_AllowActionCenterFallback&quot;)]",
        "precedenceTier": 4
      }
    },
    {
      "file": "InitAllSettings.xaml",
      "workflow": "InitAllSettings",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "variable",
      "originalValue": "[str_AssetValue]",
      "resolvedValue": "[str_AssetValue]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 7,
      "provenance": {
        "sourceKind": "variable",
        "sourceName": "str_AssetValue",
        "sourceWorkflow": "InitAllSettings",
        "precedenceTier": 2
      }
    },
    {
      "file": "InitAllSettings.xaml",
      "workflow": "InitAllSettings",
      "activityType": "Assign",
      "propertyName": "To",
      "sourceBinding": "attribute-value",
      "originalValue": "[dict_Config(&quot;BGV26_GmailFromConnectionName&quot;)]",
      "resolvedValue": "[dict_Config(&quot;BGV26_GmailFromConnectionName&quot;)]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 8,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[dict_Config(&quot;BGV26_GmailFromConnectionName&quot;)]",
        "precedenceTier": 4
      }
    },
    {
      "file": "InitAllSettings.xaml",
      "workflow": "InitAllSettings",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "variable",
      "originalValue": "[str_AssetValue]",
      "resolvedValue": "[str_AssetValue]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 8,
      "provenance": {
        "sourceKind": "variable",
        "sourceName": "str_AssetValue",
        "sourceWorkflow": "InitAllSettings",
        "precedenceTier": 2
      }
    },
    {
      "file": "InitAllSettings.xaml",
      "workflow": "InitAllSettings",
      "activityType": "Assign",
      "propertyName": "To",
      "sourceBinding": "attribute-value",
      "originalValue": "[dict_Config(&quot;BGV26_DedupeScope&quot;)]",
      "resolvedValue": "[dict_Config(&quot;BGV26_DedupeScope&quot;)]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 9,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[dict_Config(&quot;BGV26_DedupeScope&quot;)]",
        "precedenceTier": 4
      }
    },
    {
      "file": "InitAllSettings.xaml",
      "workflow": "InitAllSettings",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "variable",
      "originalValue": "[str_AssetValue]",
      "resolvedValue": "[str_AssetValue]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 9,
      "provenance": {
        "sourceKind": "variable",
        "sourceName": "str_AssetValue",
        "sourceWorkflow": "InitAllSettings",
        "precedenceTier": 2
      }
    },
    {
      "file": "InitAllSettings.xaml",
      "workflow": "InitAllSettings",
      "activityType": "ForEach",
      "propertyName": "Values",
      "sourceBinding": "attribute-value",
      "originalValue": "[dt_Constants.Rows]",
      "resolvedValue": "[dt_Constants.Rows]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 1,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[dt_Constants.Rows]",
        "precedenceTier": 4
      }
    },
    {
      "file": "InitAllSettings.xaml",
      "workflow": "InitAllSettings",
      "activityType": "Assign",
      "propertyName": "To",
      "sourceBinding": "attribute-value",
      "originalValue": "[dict_Config(constRow(&quot;Name&quot;).ToString)]",
      "resolvedValue": "[dict_Config(constRow(&quot;Name&quot;).ToString)]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 10,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[dict_Config(constRow(&quot;Name&quot;).ToString)]",
        "precedenceTier": 4
      }
    },
    {
      "file": "InitAllSettings.xaml",
      "workflow": "InitAllSettings",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "[constRow(&quot;Value&quot;)]",
      "resolvedValue": "[constRow(&quot;Value&quot;)]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 10,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[constRow(&quot;Value&quot;)]",
        "precedenceTier": 4
      }
    },
    {
      "file": "InitAllSettings.xaml",
      "workflow": "InitAllSettings",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Loaded constant: &quot; &amp; constRow(&quot;Name&quot;).ToString]",
      "resolvedValue": "[&quot;Loaded constant: &quot; &amp; constRow(&quot;Name&quot;).ToString]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 2,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Loaded constant: &quot; &amp; constRow(&quot;Name&quot;).ToString]",
        "precedenceTier": 4
      }
    },
    {
      "file": "InitAllSettings.xaml",
      "workflow": "InitAllSettings",
      "activityType": "Assign",
      "propertyName": "To",
      "sourceBinding": "workflowArgument",
      "originalValue": "[out_Config]",
      "resolvedValue": "[out_Config]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 11,
      "provenance": {
        "sourceKind": "workflowArgument",
        "sourceName": "out_Config",
        "sourceWorkflow": "InitAllSettings",
        "precedenceTier": 1
      }
    },
    {
      "file": "InitAllSettings.xaml",
      "workflow": "InitAllSettings",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "variable",
      "originalValue": "[dict_Config]",
      "resolvedValue": "[dict_Config]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 11,
      "provenance": {
        "sourceKind": "variable",
        "sourceName": "dict_Config",
        "sourceWorkflow": "InitAllSettings",
        "precedenceTier": 2
      }
    },
    {
      "file": "InitAllSettings.xaml",
      "workflow": "InitAllSettings",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Configuration loaded successfully&quot;]",
      "resolvedValue": "[&quot;Configuration loaded successfully&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 3,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Configuration loaded successfully&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "InitAllSettings.xaml",
      "workflow": "InitAllSettings",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;=== Completed: InitAllSettings ===&quot;]",
      "resolvedValue": "[&quot;=== Completed: InitAllSettings ===&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 4,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;=== Completed: InitAllSettings ===&quot;]",
        "precedenceTier": 4
      }
    }
  ],
  "unresolvedRequiredPropertyDefects": [
    {
      "file": "Main.xaml",
      "workflow": "Main",
      "activityType": "Assign",
      "propertyName": "To",
      "failureReason": "Required property \"To\" on Assign contains generic type default \"Nothing\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "Nothing",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "Main.xaml",
      "workflow": "Main",
      "activityType": "Assign",
      "propertyName": "To",
      "failureReason": "Required property \"To\" on Assign contains generic type default \"Nothing\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "Nothing",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "Main.xaml",
      "workflow": "Main",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "failureReason": "Required property \"Message\" on LogMessage contains generic type default \"\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "Main.xaml",
      "workflow": "Main",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "failureReason": "Required property \"Message\" on LogMessage contains generic type default \"\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "Main.xaml",
      "workflow": "Main",
      "activityType": "Assign",
      "propertyName": "To",
      "failureReason": "Required property \"To\" on Assign contains generic type default \"Nothing\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "Nothing",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "Main.xaml",
      "workflow": "Main",
      "activityType": "Assign",
      "propertyName": "To",
      "failureReason": "Required property \"To\" on Assign contains generic type default \"Nothing\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "Nothing",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "Main.xaml",
      "workflow": "Main",
      "activityType": "Assign",
      "propertyName": "To",
      "failureReason": "Required property \"To\" on Assign contains generic type default \"Nothing\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "Nothing",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "Main.xaml",
      "workflow": "Main",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "failureReason": "Required property \"Message\" on LogMessage contains generic type default \"\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "Main.xaml",
      "workflow": "Main",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "failureReason": "Required property \"Message\" on LogMessage contains generic type default \"\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "Main.xaml",
      "workflow": "Main",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "failureReason": "Required property \"Message\" on LogMessage contains generic type default \"\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "Main.xaml",
      "workflow": "Main",
      "activityType": "Assign",
      "propertyName": "To",
      "failureReason": "Required property \"To\" on Assign contains generic type default \"Nothing\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "Nothing",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "Main.xaml",
      "workflow": "Main",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "failureReason": "Required property \"Message\" on LogMessage contains generic type default \"\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "Main.xaml",
      "workflow": "Main",
      "activityType": "Assign",
      "propertyName": "To",
      "failureReason": "Required property \"To\" on Assign contains generic type default \"Nothing\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "Nothing",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "Main.xaml",
      "workflow": "Main",
      "activityType": "Assign",
      "propertyName": "To",
      "failureReason": "Required property \"To\" on Assign contains generic type default \"Nothing\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "Nothing",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "Main.xaml",
      "workflow": "Main",
      "activityType": "Assign",
      "propertyName": "To",
      "failureReason": "Required property \"To\" on Assign contains generic type default \"Nothing\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "Nothing",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "Main.xaml",
      "workflow": "Main",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "failureReason": "Required property \"Message\" on LogMessage contains generic type default \"\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "Main.xaml",
      "workflow": "Main",
      "activityType": "Assign",
      "propertyName": "To",
      "failureReason": "Required property \"To\" on Assign contains generic type default \"Nothing\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "Nothing",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "Main.xaml",
      "workflow": "Main",
      "activityType": "Assign",
      "propertyName": "To",
      "failureReason": "Required property \"To\" on Assign contains generic type default \"Nothing\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "Nothing",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "GetBirthdays.xaml",
      "workflow": "GetBirthdays",
      "activityType": "Assign",
      "propertyName": "To",
      "failureReason": "Required property \"To\" on Assign contains generic type default \"Nothing\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "Nothing",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "GetBirthdays.xaml",
      "workflow": "GetBirthdays",
      "activityType": "Assign",
      "propertyName": "To",
      "failureReason": "Required property \"To\" on Assign contains generic type default \"Nothing\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "Nothing",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "GetBirthdays.xaml",
      "workflow": "GetBirthdays",
      "activityType": "Assign",
      "propertyName": "To",
      "failureReason": "Required property \"To\" on Assign contains generic type default \"Nothing\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "Nothing",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "GetBirthdays.xaml",
      "workflow": "GetBirthdays",
      "activityType": "Assign",
      "propertyName": "To",
      "failureReason": "Required property \"To\" on Assign contains generic type default \"Nothing\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "Nothing",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "GetBirthdays.xaml",
      "workflow": "GetBirthdays",
      "activityType": "Assign",
      "propertyName": "To",
      "failureReason": "Required property \"To\" on Assign contains generic type default \"Nothing\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "Nothing",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "GetBirthdays.xaml",
      "workflow": "GetBirthdays",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "failureReason": "Required property \"Message\" on LogMessage contains generic type default \"\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "GetBirthdays.xaml",
      "workflow": "GetBirthdays",
      "activityType": "Assign",
      "propertyName": "To",
      "failureReason": "Required property \"To\" on Assign contains generic type default \"Nothing\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "Nothing",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "GetBirthdays.xaml",
      "workflow": "GetBirthdays",
      "activityType": "Assign",
      "propertyName": "To",
      "failureReason": "Required property \"To\" on Assign contains generic type default \"Nothing\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "Nothing",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "GetBirthdays.xaml",
      "workflow": "GetBirthdays",
      "activityType": "Assign",
      "propertyName": "To",
      "failureReason": "Required property \"To\" on Assign contains generic type default \"Nothing\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "Nothing",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "GetBirthdays.xaml",
      "workflow": "GetBirthdays",
      "activityType": "Assign",
      "propertyName": "To",
      "failureReason": "Required property \"To\" on Assign contains generic type default \"Nothing\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "Nothing",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "GetBirthdays.xaml",
      "workflow": "GetBirthdays",
      "activityType": "If",
      "propertyName": "Condition",
      "failureReason": "Required property \"Condition\" on If contains generic type default \"False\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "False",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "GetBirthdays.xaml",
      "workflow": "GetBirthdays",
      "activityType": "Assign",
      "propertyName": "To",
      "failureReason": "Required property \"To\" on Assign contains generic type default \"Nothing\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "Nothing",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "GetBirthdays.xaml",
      "workflow": "GetBirthdays",
      "activityType": "Assign",
      "propertyName": "To",
      "failureReason": "Required property \"To\" on Assign contains generic type default \"Nothing\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "Nothing",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "GetBirthdays.xaml",
      "workflow": "GetBirthdays",
      "activityType": "Assign",
      "propertyName": "To",
      "failureReason": "Required property \"To\" on Assign contains generic type default \"Nothing\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "Nothing",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "GetBirthdays.xaml",
      "workflow": "GetBirthdays",
      "activityType": "Assign",
      "propertyName": "To",
      "failureReason": "Required property \"To\" on Assign contains generic type default \"Nothing\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "Nothing",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "ProcessBirthday.xaml",
      "workflow": "ProcessBirthday",
      "activityType": "Assign",
      "propertyName": "To",
      "failureReason": "Required property \"To\" on Assign contains generic type default \"Nothing\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "Nothing",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "ProcessBirthday.xaml",
      "workflow": "ProcessBirthday",
      "activityType": "Assign",
      "propertyName": "To",
      "failureReason": "Required property \"To\" on Assign contains generic type default \"Nothing\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "Nothing",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "ProcessBirthday.xaml",
      "workflow": "ProcessBirthday",
      "activityType": "Assign",
      "propertyName": "To",
      "failureReason": "Required property \"To\" on Assign contains generic type default \"Nothing\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "Nothing",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "ProcessBirthday.xaml",
      "workflow": "ProcessBirthday",
      "activityType": "Assign",
      "propertyName": "To",
      "failureReason": "Required property \"To\" on Assign contains generic type default \"Nothing\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "Nothing",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "ProcessBirthday.xaml",
      "workflow": "ProcessBirthday",
      "activityType": "Assign",
      "propertyName": "To",
      "failureReason": "Required property \"To\" on Assign contains generic type default \"Nothing\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "Nothing",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "ProcessBirthday.xaml",
      "workflow": "ProcessBirthday",
      "activityType": "Assign",
      "propertyName": "To",
      "failureReason": "Required property \"To\" on Assign contains generic type default \"Nothing\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "Nothing",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "ProcessBirthday.xaml",
      "workflow": "ProcessBirthday",
      "activityType": "Assign",
      "propertyName": "To",
      "failureReason": "Required property \"To\" on Assign contains generic type default \"Nothing\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "Nothing",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "ProcessBirthday.xaml",
      "workflow": "ProcessBirthday",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "failureReason": "Required property \"Message\" on LogMessage contains generic type default \"\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "ProcessBirthday.xaml",
      "workflow": "ProcessBirthday",
      "activityType": "Assign",
      "propertyName": "To",
      "failureReason": "Required property \"To\" on Assign contains generic type default \"Nothing\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "Nothing",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "ProcessBirthday.xaml",
      "workflow": "ProcessBirthday",
      "activityType": "Assign",
      "propertyName": "To",
      "failureReason": "Required property \"To\" on Assign contains generic type default \"Nothing\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "Nothing",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "ProcessBirthday.xaml",
      "workflow": "ProcessBirthday",
      "activityType": "Assign",
      "propertyName": "To",
      "failureReason": "Required property \"To\" on Assign contains generic type default \"Nothing\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "Nothing",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "ProcessBirthday.xaml",
      "workflow": "ProcessBirthday",
      "activityType": "Assign",
      "propertyName": "To",
      "failureReason": "Required property \"To\" on Assign contains generic type default \"Nothing\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "Nothing",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "ProcessBirthday.xaml",
      "workflow": "ProcessBirthday",
      "activityType": "Assign",
      "propertyName": "To",
      "failureReason": "Required property \"To\" on Assign contains generic type default \"Nothing\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "Nothing",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "ProcessBirthday.xaml",
      "workflow": "ProcessBirthday",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "failureReason": "Required property \"Message\" on LogMessage contains generic type default \"\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "ProcessBirthday.xaml",
      "workflow": "ProcessBirthday",
      "activityType": "Assign",
      "propertyName": "To",
      "failureReason": "Required property \"To\" on Assign contains generic type default \"Nothing\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "Nothing",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "ProcessBirthday.xaml",
      "workflow": "ProcessBirthday",
      "activityType": "Assign",
      "propertyName": "To",
      "failureReason": "Required property \"To\" on Assign contains generic type default \"Nothing\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "Nothing",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "ProcessBirthday.xaml",
      "workflow": "ProcessBirthday",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "failureReason": "Required property \"Message\" on LogMessage contains generic type default \"\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "GenerateAndValidateDraft.xaml",
      "workflow": "GenerateAndValidateDraft",
      "activityType": "Assign",
      "propertyName": "To",
      "failureReason": "Required property \"To\" on Assign contains generic type default \"Nothing\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "Nothing",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "GenerateAndValidateDraft.xaml",
      "workflow": "GenerateAndValidateDraft",
      "activityType": "Assign",
      "propertyName": "To",
      "failureReason": "Required property \"To\" on Assign contains generic type default \"Nothing\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "Nothing",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "GenerateAndValidateDraft.xaml",
      "workflow": "GenerateAndValidateDraft",
      "activityType": "Assign",
      "propertyName": "To",
      "failureReason": "Required property \"To\" on Assign contains generic type default \"Nothing\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "Nothing",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "GenerateAndValidateDraft.xaml",
      "workflow": "GenerateAndValidateDraft",
      "activityType": "Assign",
      "propertyName": "To",
      "failureReason": "Required property \"To\" on Assign contains generic type default \"Nothing\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "Nothing",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "GenerateAndValidateDraft.xaml",
      "workflow": "GenerateAndValidateDraft",
      "activityType": "Assign",
      "propertyName": "To",
      "failureReason": "Required property \"To\" on Assign contains generic type default \"Nothing\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "Nothing",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "GenerateAndValidateDraft.xaml",
      "workflow": "GenerateAndValidateDraft",
      "activityType": "Assign",
      "propertyName": "To",
      "failureReason": "Required property \"To\" on Assign contains generic type default \"Nothing\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "Nothing",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "GenerateAndValidateDraft.xaml",
      "workflow": "GenerateAndValidateDraft",
      "activityType": "Assign",
      "propertyName": "To",
      "failureReason": "Required property \"To\" on Assign contains generic type default \"Nothing\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "Nothing",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "GenerateAndValidateDraft.xaml",
      "workflow": "GenerateAndValidateDraft",
      "activityType": "Assign",
      "propertyName": "To",
      "failureReason": "Required property \"To\" on Assign contains generic type default \"Nothing\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "Nothing",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "GenerateAndValidateDraft.xaml",
      "workflow": "GenerateAndValidateDraft",
      "activityType": "Assign",
      "propertyName": "To",
      "failureReason": "Required property \"To\" on Assign contains generic type default \"Nothing\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "Nothing",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "GenerateAndValidateDraft.xaml",
      "workflow": "GenerateAndValidateDraft",
      "activityType": "Assign",
      "propertyName": "To",
      "failureReason": "Required property \"To\" on Assign contains generic type default \"Nothing\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "Nothing",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "GenerateAndValidateDraft.xaml",
      "workflow": "GenerateAndValidateDraft",
      "activityType": "Assign",
      "propertyName": "To",
      "failureReason": "Required property \"To\" on Assign contains generic type default \"Nothing\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "Nothing",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "GenerateAndValidateDraft.xaml",
      "workflow": "GenerateAndValidateDraft",
      "activityType": "Assign",
      "propertyName": "To",
      "failureReason": "Required property \"To\" on Assign contains generic type default \"Nothing\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "Nothing",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "HandleHumanReview.xaml",
      "workflow": "HandleHumanReview",
      "activityType": "Assign",
      "propertyName": "To",
      "failureReason": "Required property \"To\" on Assign contains generic type default \"Nothing\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "Nothing",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "HandleHumanReview.xaml",
      "workflow": "HandleHumanReview",
      "activityType": "Assign",
      "propertyName": "To",
      "failureReason": "Required property \"To\" on Assign contains generic type default \"Nothing\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "Nothing",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "HandleHumanReview.xaml",
      "workflow": "HandleHumanReview",
      "activityType": "Assign",
      "propertyName": "To",
      "failureReason": "Required property \"To\" on Assign contains generic type default \"Nothing\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "Nothing",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "HandleHumanReview.xaml",
      "workflow": "HandleHumanReview",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "failureReason": "Required property \"Message\" on LogMessage contains generic type default \"\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "HandleHumanReview.xaml",
      "workflow": "HandleHumanReview",
      "activityType": "Assign",
      "propertyName": "To",
      "failureReason": "Required property \"To\" on Assign contains generic type default \"Nothing\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "Nothing",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "HandleHumanReview.xaml",
      "workflow": "HandleHumanReview",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "failureReason": "Required property \"Message\" on LogMessage contains generic type default \"\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "HandleHumanReview.xaml",
      "workflow": "HandleHumanReview",
      "activityType": "Assign",
      "propertyName": "To",
      "failureReason": "Required property \"To\" on Assign contains generic type default \"Nothing\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "Nothing",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "HandleHumanReview.xaml",
      "workflow": "HandleHumanReview",
      "activityType": "Assign",
      "propertyName": "To",
      "failureReason": "Required property \"To\" on Assign contains generic type default \"Nothing\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "Nothing",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "HandleHumanReview.xaml",
      "workflow": "HandleHumanReview",
      "activityType": "Assign",
      "propertyName": "To",
      "failureReason": "Required property \"To\" on Assign contains generic type default \"Nothing\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "Nothing",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "HandleHumanReview.xaml",
      "workflow": "HandleHumanReview",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "failureReason": "Required property \"Message\" on LogMessage contains generic type default \"\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "HandleHumanReview.xaml",
      "workflow": "HandleHumanReview",
      "activityType": "Assign",
      "propertyName": "To",
      "failureReason": "Required property \"To\" on Assign contains generic type default \"Nothing\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "Nothing",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "HandleHumanReview.xaml",
      "workflow": "HandleHumanReview",
      "activityType": "Assign",
      "propertyName": "To",
      "failureReason": "Required property \"To\" on Assign contains generic type default \"Nothing\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "Nothing",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "HandleHumanReview.xaml",
      "workflow": "HandleHumanReview",
      "activityType": "Assign",
      "propertyName": "To",
      "failureReason": "Required property \"To\" on Assign contains generic type default \"Nothing\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "Nothing",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "HandleHumanReview.xaml",
      "workflow": "HandleHumanReview",
      "activityType": "GmailSendMessage",
      "propertyName": "Body",
      "failureReason": "Required property \"Body\" on GmailSendMessage has no valid source binding and no contract-valid fallback",
      "originalValue": "",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "HandleHumanReview.xaml",
      "workflow": "HandleHumanReview",
      "activityType": "Assign",
      "propertyName": "To",
      "failureReason": "Required property \"To\" on Assign contains generic type default \"Nothing\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "Nothing",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "HandleHumanReview.xaml",
      "workflow": "HandleHumanReview",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "failureReason": "Required property \"Message\" on LogMessage contains generic type default \"\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "HandleHumanReview.xaml",
      "workflow": "HandleHumanReview",
      "activityType": "Assign",
      "propertyName": "To",
      "failureReason": "Required property \"To\" on Assign contains generic type default \"Nothing\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "Nothing",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "HandleHumanReview.xaml",
      "workflow": "HandleHumanReview",
      "activityType": "Assign",
      "propertyName": "To",
      "failureReason": "Required property \"To\" on Assign contains generic type default \"Nothing\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "Nothing",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "HandleHumanReview.xaml",
      "workflow": "HandleHumanReview",
      "activityType": "Assign",
      "propertyName": "To",
      "failureReason": "Required property \"To\" on Assign contains generic type default \"Nothing\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "Nothing",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "HandleHumanReview.xaml",
      "workflow": "HandleHumanReview",
      "activityType": "Assign",
      "propertyName": "To",
      "failureReason": "Required property \"To\" on Assign contains generic type default \"Nothing\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "Nothing",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "HandleHumanReview.xaml",
      "workflow": "HandleHumanReview",
      "activityType": "Assign",
      "propertyName": "To",
      "failureReason": "Required property \"To\" on Assign contains generic type default \"Nothing\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "Nothing",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    }
  ],
  "expressionLoweringFixes": [
    {
      "file": "Main.xaml",
      "workflow": "Main",
      "activityType": "CreateEntityRecord",
      "propertyName": "EntityObject",
      "originalValue": "{&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;New Dictionary(Of String, Object) From {{\\&quot;RunId\\&quot;, runId}, {\\&quot;StartTimeUtc\\&quot;, runStartTimeUtc}, {\\&quot;RunStatus\\&quot;, \\&quot;Started\\&quot;}, {\\&quot;BirthdaysFound\\&quot;, 0}, {\\&quot;SentCount\\&quot;, 0}, {\\&quot;SkippedCount\\&quot;, 0}, {\\&quot;ErrorCount\\&quot;, 0}, {\\&quot;OrchestratorJobKey\\&quot;, orchestratorJobKey}}&quot;}",
      "resolvedValue": "[New Dictionary(Of String, Object) From {{\"RunId\", runId}, {\"StartTimeUtc\", runStartTimeUtc}, {\"RunStatus\", \"Started\"}, {\"BirthdaysFound\", 0}, {\"SentCount\", 0}, {\"SkippedCount\", 0}, {\"ErrorCount\", 0}, {\"OrchestratorJobKey\", orchestratorJobKey}}]",
      "severity": "info",
      "packageModeOutcome": "lowered",
      "occurrenceIndex": 0
    },
    {
      "file": "GetBirthdays.xaml",
      "workflow": "GetBirthdays",
      "activityType": "AddDataRow",
      "propertyName": "DataTable",
      "originalValue": "{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;birthdayItemsDt&quot;}",
      "resolvedValue": "[birthdayItemsDt]",
      "severity": "info",
      "packageModeOutcome": "lowered",
      "occurrenceIndex": 0
    },
    {
      "file": "GenerateAndValidateDraft.xaml",
      "workflow": "GenerateAndValidateDraft",
      "activityType": "DeserializeJson",
      "propertyName": "JsonString",
      "originalValue": "{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;genAiRawResponse&quot;}",
      "resolvedValue": "[genAiRawResponse]",
      "severity": "info",
      "packageModeOutcome": "lowered",
      "occurrenceIndex": 0
    },
    {
      "file": "HandleHumanReview.xaml",
      "workflow": "HandleHumanReview",
      "activityType": "CreateFormTask",
      "propertyName": "Title",
      "originalValue": "{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;taskTitle&quot;}",
      "resolvedValue": "[taskTitle]",
      "severity": "info",
      "packageModeOutcome": "lowered",
      "occurrenceIndex": 0
    },
    {
      "file": "HandleHumanReview.xaml",
      "workflow": "HandleHumanReview",
      "activityType": "CreateFormTask",
      "propertyName": "FormSchemaPath",
      "originalValue": "{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;taskFormSchemaPath&quot;}",
      "resolvedValue": "[taskFormSchemaPath]",
      "severity": "info",
      "packageModeOutcome": "lowered",
      "occurrenceIndex": 0
    },
    {
      "file": "HandleHumanReview.xaml",
      "workflow": "HandleHumanReview",
      "activityType": "UpdateEntity",
      "propertyName": "EntityObject",
      "originalValue": "{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;sentLogUpdateObj&quot;}",
      "resolvedValue": "[sentLogUpdateObj]",
      "severity": "info",
      "packageModeOutcome": "lowered",
      "occurrenceIndex": 0
    },
    {
      "file": "HandleHumanReview.xaml",
      "workflow": "HandleHumanReview",
      "activityType": "GmailSendMessage",
      "propertyName": "Subject",
      "originalValue": "{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;escalationSubject&quot;}",
      "resolvedValue": "[escalationSubject]",
      "severity": "info",
      "packageModeOutcome": "lowered",
      "occurrenceIndex": 0
    }
  ],
  "expressionLoweringFailures": [],
  "requiredPropertyEnforcementSummary": "318 required property binding(s) resolved; 83 unresolved required property defect(s); 7 structured expression(s) lowered; 82 invalid generic substitution(s) blocked",
  "preComplianceGuardPassed": true,
  "preComplianceGuardViolationCount": 0,
  "canonicalizationArchiveParity": [
    {
      "file": "Main.xaml",
      "preCanonicalizationHash": "f2a17e266304c571aa81efc43041ead7fed2ec40e49496aeb6d4d28c6ae895f1",
      "canonicalizedHash": "4d3aa2021daa709fea705da23fc9217d38ff8b1053b9a28ff0e54406e1aee57c",
      "archivedHash": "4d3aa2021daa709fea705da23fc9217d38ff8b1053b9a28ff0e54406e1aee57c",
      "identical": true,
      "mutated": true
    },
    {
      "file": "GetBirthdays.xaml",
      "preCanonicalizationHash": "e16f95a7264925affc8a03872fb88b02c356f0bf22c34382f56215f6c90122ae",
      "canonicalizedHash": "596456e4731485234053e5b3179b4b34ed1979de3b1dac7a8c78d000cc0a093b",
      "archivedHash": "596456e4731485234053e5b3179b4b34ed1979de3b1dac7a8c78d000cc0a093b",
      "identical": true,
      "mutated": true
    },
    {
      "file": "ProcessBirthday.xaml",
      "preCanonicalizationHash": "7dbafb0fdcbc037e701259cda69082846beb9ce85978ed72704779a9da5e0b45",
      "canonicalizedHash": "7ed4c03a2d5a365ccfd57e69d240e853891e65486f513ec31c3f53500605f857",
      "archivedHash": "7ed4c03a2d5a365ccfd57e69d240e853891e65486f513ec31c3f53500605f857",
      "identical": true,
      "mutated": true
    },
    {
      "file": "GenerateAndValidateDraft.xaml",
      "preCanonicalizationHash": "8fc992cbef4b3ecad82711354d379b339e4896cb457665e136671bdd290fbb74",
      "canonicalizedHash": "cc6fd67670771b37bf1d36dada9c4701465b8f675b78715008a390e7c010ee71",
      "archivedHash": "cc6fd67670771b37bf1d36dada9c4701465b8f675b78715008a390e7c010ee71",
      "identical": true,
      "mutated": true
    },
    {
      "file": "HandleHumanReview.xaml",
      "preCanonicalizationHash": "9447eb74d5884800b86c3d2987f56713fbd44bf405789ef3cea2cb51e5c6fe25",
      "canonicalizedHash": "4290cad136940186018c1f7f5aafc01d1fbcf49cdeb4b3a07cc8b3529b5650d5",
      "archivedHash": "4290cad136940186018c1f7f5aafc01d1fbcf49cdeb4b3a07cc8b3529b5650d5",
      "identical": true,
      "mutated": true
    },
    {
      "file": "Finalize.xaml",
      "preCanonicalizationHash": "f0e47fed20ff91f6d3ac13441d9ba4d16eade3de0c2c71bb99851063b067dd1c",
      "canonicalizedHash": "f0e47fed20ff91f6d3ac13441d9ba4d16eade3de0c2c71bb99851063b067dd1c",
      "archivedHash": "f0e47fed20ff91f6d3ac13441d9ba4d16eade3de0c2c71bb99851063b067dd1c",
      "identical": true,
      "mutated": false
    },
    {
      "file": "InitAllSettings.xaml",
      "preCanonicalizationHash": "569051e3211e1316e37e1d5f58809379dd2830421beb3d5dccecb55038780d28",
      "canonicalizedHash": "569051e3211e1316e37e1d5f58809379dd2830421beb3d5dccecb55038780d28",
      "archivedHash": "569051e3211e1316e37e1d5f58809379dd2830421beb3d5dccecb55038780d28",
      "identical": true,
      "mutated": false
    }
  ],
  "preArchiveStructuralDefects": [
    {
      "file": "Main.xaml",
      "pattern": "object_payload_in_target_value_slot",
      "detail": "Object payload in target/value slot: <Assign.To><OutArgument x:TypeArguments=\"x:String\">Nothing</OutArgument></Assign.To>\n              <Assign.Value><InArgu"
    },
    {
      "file": "GetBirthdays.xaml",
      "pattern": "object_payload_in_target_value_slot",
      "detail": "Object payload in target/value slot: <Assign.To><OutArgument x:TypeArguments=\"x:String\">Nothing</OutArgument></Assign.To>\n              <Assign.Value><InArgu"
    },
    {
      "file": "ProcessBirthday.xaml",
      "pattern": "object_payload_in_target_value_slot",
      "detail": "Object payload in target/value slot: <Assign.To><OutArgument x:TypeArguments=\"x:String\">Nothing</OutArgument></Assign.To>\n              <Assign.Value><InArgu"
    },
    {
      "file": "GenerateAndValidateDraft.xaml",
      "pattern": "object_payload_in_target_value_slot",
      "detail": "Object payload in target/value slot: <Assign.To><OutArgument x:TypeArguments=\"x:String\">Nothing</OutArgument></Assign.To>\n              <Assign.Value><InArgu"
    },
    {
      "file": "HandleHumanReview.xaml",
      "pattern": "object_payload_in_target_value_slot",
      "detail": "Object payload in target/value slot: <Assign.To><OutArgument x:TypeArguments=\"x:String\">Nothing</OutArgument></Assign.To>\n              <Assign.Value><InArgu"
    },
    {
      "file": "InitAllSettings.xaml",
      "pattern": "malformed_attribute_quoting",
      "detail": "Malformed attribute quoting detected: AssetName=\"[&quot;BGV26_GSuite_ServiceAccount_Credential&quot;]"
    }
  ],
  "postClassifierMutationTrace": {
    "entries": [
      {
        "stage": "pre-freeze-snapshot",
        "function": "freezeArchiveWorkflows",
        "file": "Finalize.xaml",
        "mutationType": "xaml_bytes",
        "preHash": "N/A",
        "postHash": "f0e47fed20ff91f6d3ac13441d9ba4d16eade3de0c2c71bb99851063b067dd1c",
        "allowed": true,
        "reason": "Workflow \"Finalize.xaml\" content captured at freeze point (status=stub)",
        "changedBytes": false,
        "changedStatus": false,
        "enforcementAction": "none"
      },
      {
        "stage": "pre-freeze-snapshot",
        "function": "freezeArchiveWorkflows",
        "file": "GenerateAndValidateDraft.xaml",
        "mutationType": "xaml_bytes",
        "preHash": "N/A",
        "postHash": "cc6fd67670771b37bf1d36dada9c4701465b8f675b78715008a390e7c010ee71",
        "allowed": true,
        "reason": "Workflow \"GenerateAndValidateDraft.xaml\" content captured at freeze point (status=non-stub)",
        "changedBytes": false,
        "changedStatus": false,
        "enforcementAction": "none"
      },
      {
        "stage": "pre-freeze-snapshot",
        "function": "freezeArchiveWorkflows",
        "file": "GetBirthdays.xaml",
        "mutationType": "xaml_bytes",
        "preHash": "N/A",
        "postHash": "596456e4731485234053e5b3179b4b34ed1979de3b1dac7a8c78d000cc0a093b",
        "allowed": true,
        "reason": "Workflow \"GetBirthdays.xaml\" content captured at freeze point (status=non-stub)",
        "changedBytes": false,
        "changedStatus": false,
        "enforcementAction": "none"
      },
      {
        "stage": "pre-freeze-snapshot",
        "function": "freezeArchiveWorkflows",
        "file": "HandleHumanReview.xaml",
        "mutationType": "xaml_bytes",
        "preHash": "N/A",
        "postHash": "4290cad136940186018c1f7f5aafc01d1fbcf49cdeb4b3a07cc8b3529b5650d5",
        "allowed": true,
        "reason": "Workflow \"HandleHumanReview.xaml\" content captured at freeze point (status=non-stub)",
        "changedBytes": false,
        "changedStatus": false,
        "enforcementAction": "none"
      },
      {
        "stage": "pre-freeze-snapshot",
        "function": "freezeArchiveWorkflows",
        "file": "InitAllSettings.xaml",
        "mutationType": "xaml_bytes",
        "preHash": "N/A",
        "postHash": "569051e3211e1316e37e1d5f58809379dd2830421beb3d5dccecb55038780d28",
        "allowed": true,
        "reason": "Workflow \"InitAllSettings.xaml\" content captured at freeze point (status=non-stub)",
        "changedBytes": false,
        "changedStatus": false,
        "enforcementAction": "none"
      },
      {
        "stage": "pre-freeze-snapshot",
        "function": "freezeArchiveWorkflows",
        "file": "Main.xaml",
        "mutationType": "xaml_bytes",
        "preHash": "N/A",
        "postHash": "4d3aa2021daa709fea705da23fc9217d38ff8b1053b9a28ff0e54406e1aee57c",
        "allowed": true,
        "reason": "Workflow \"Main.xaml\" content captured at freeze point (status=non-stub)",
        "changedBytes": false,
        "changedStatus": false,
        "enforcementAction": "none"
      },
      {
        "stage": "pre-freeze-snapshot",
        "function": "freezeArchiveWorkflows",
        "file": "ProcessBirthday.xaml",
        "mutationType": "xaml_bytes",
        "preHash": "N/A",
        "postHash": "7ed4c03a2d5a365ccfd57e69d240e853891e65486f513ec31c3f53500605f857",
        "allowed": true,
        "reason": "Workflow \"ProcessBirthday.xaml\" content captured at freeze point (status=non-stub)",
        "changedBytes": false,
        "changedStatus": false,
        "enforcementAction": "none"
      }
    ],
    "perFileMutationCounts": {
      "Finalize.xaml": 1,
      "GenerateAndValidateDraft.xaml": 1,
      "GetBirthdays.xaml": 1,
      "HandleHumanReview.xaml": 1,
      "InitAllSettings.xaml": 1,
      "Main.xaml": 1,
      "ProcessBirthday.xaml": 1
    },
    "filesChangedAfterFreeze": [],
    "summary": {
      "totalAttemptedMutations": 7,
      "totalBlockedMutations": 0,
      "totalAllowedPreFreezeMutations": 7,
      "totalPostFreezeViolations": 0,
      "totalUnexpectedPostFreezeMutations": 0,
      "filesChangedAfterFreeze": 0
    }
  },
  "postFreezeMutationTrace": {
    "entries": [
      {
        "stage": "pre-freeze-snapshot",
        "function": "freezeArchiveWorkflows",
        "file": "Finalize.xaml",
        "mutationType": "xaml_bytes",
        "preHash": "N/A",
        "postHash": "f0e47fed20ff91f6d3ac13441d9ba4d16eade3de0c2c71bb99851063b067dd1c",
        "allowed": true,
        "reason": "Workflow \"Finalize.xaml\" content captured at freeze point (status=stub)",
        "changedBytes": false,
        "changedStatus": false,
        "enforcementAction": "none"
      },
      {
        "stage": "pre-freeze-snapshot",
        "function": "freezeArchiveWorkflows",
        "file": "GenerateAndValidateDraft.xaml",
        "mutationType": "xaml_bytes",
        "preHash": "N/A",
        "postHash": "cc6fd67670771b37bf1d36dada9c4701465b8f675b78715008a390e7c010ee71",
        "allowed": true,
        "reason": "Workflow \"GenerateAndValidateDraft.xaml\" content captured at freeze point (status=non-stub)",
        "changedBytes": false,
        "changedStatus": false,
        "enforcementAction": "none"
      },
      {
        "stage": "pre-freeze-snapshot",
        "function": "freezeArchiveWorkflows",
        "file": "GetBirthdays.xaml",
        "mutationType": "xaml_bytes",
        "preHash": "N/A",
        "postHash": "596456e4731485234053e5b3179b4b34ed1979de3b1dac7a8c78d000cc0a093b",
        "allowed": true,
        "reason": "Workflow \"GetBirthdays.xaml\" content captured at freeze point (status=non-stub)",
        "changedBytes": false,
        "changedStatus": false,
        "enforcementAction": "none"
      },
      {
        "stage": "pre-freeze-snapshot",
        "function": "freezeArchiveWorkflows",
        "file": "HandleHumanReview.xaml",
        "mutationType": "xaml_bytes",
        "preHash": "N/A",
        "postHash": "4290cad136940186018c1f7f5aafc01d1fbcf49cdeb4b3a07cc8b3529b5650d5",
        "allowed": true,
        "reason": "Workflow \"HandleHumanReview.xaml\" content captured at freeze point (status=non-stub)",
        "changedBytes": false,
        "changedStatus": false,
        "enforcementAction": "none"
      },
      {
        "stage": "pre-freeze-snapshot",
        "function": "freezeArchiveWorkflows",
        "file": "InitAllSettings.xaml",
        "mutationType": "xaml_bytes",
        "preHash": "N/A",
        "postHash": "569051e3211e1316e37e1d5f58809379dd2830421beb3d5dccecb55038780d28",
        "allowed": true,
        "reason": "Workflow \"InitAllSettings.xaml\" content captured at freeze point (status=non-stub)",
        "changedBytes": false,
        "changedStatus": false,
        "enforcementAction": "none"
      },
      {
        "stage": "pre-freeze-snapshot",
        "function": "freezeArchiveWorkflows",
        "file": "Main.xaml",
        "mutationType": "xaml_bytes",
        "preHash": "N/A",
        "postHash": "4d3aa2021daa709fea705da23fc9217d38ff8b1053b9a28ff0e54406e1aee57c",
        "allowed": true,
        "reason": "Workflow \"Main.xaml\" content captured at freeze point (status=non-stub)",
        "changedBytes": false,
        "changedStatus": false,
        "enforcementAction": "none"
      },
      {
        "stage": "pre-freeze-snapshot",
        "function": "freezeArchiveWorkflows",
        "file": "ProcessBirthday.xaml",
        "mutationType": "xaml_bytes",
        "preHash": "N/A",
        "postHash": "7ed4c03a2d5a365ccfd57e69d240e853891e65486f513ec31c3f53500605f857",
        "allowed": true,
        "reason": "Workflow \"ProcessBirthday.xaml\" content captured at freeze point (status=non-stub)",
        "changedBytes": false,
        "changedStatus": false,
        "enforcementAction": "none"
      }
    ],
    "perFileMutationCounts": {
      "Finalize.xaml": 1,
      "GenerateAndValidateDraft.xaml": 1,
      "GetBirthdays.xaml": 1,
      "HandleHumanReview.xaml": 1,
      "InitAllSettings.xaml": 1,
      "Main.xaml": 1,
      "ProcessBirthday.xaml": 1
    },
    "filesChangedAfterFreeze": [],
    "summary": {
      "totalAttemptedMutations": 7,
      "totalBlockedMutations": 0,
      "totalAllowedPreFreezeMutations": 7,
      "totalPostFreezeViolations": 0,
      "totalUnexpectedPostFreezeMutations": 0,
      "filesChangedAfterFreeze": 0
    }
  },
  "workflowAutoWiringDiagnostics": {
    "entries": [
      {
        "file": "Main.xaml",
        "generated": true,
        "required": true,
        "workflowRole": "entrypoint",
        "classificationSourceRule": "basename_match:Main",
        "requiredByPath": "Main.xaml (entry point)",
        "expectedCaller": null,
        "callerCandidates": [],
        "invokeAttempted": false,
        "invokeSucceeded": false,
        "invokeSkippedReason": "entrypoint workflow — wired by framework structure",
        "invokeRejectedReason": null,
        "actualCallers": [],
        "reachableFromMain": true,
        "finalWiringStatus": "wired_and_reachable",
        "rootCauseCategory": "none",
        "remediationHint": null,
        "unwiredSeverity": "none"
      },
      {
        "file": "GetBirthdays.xaml",
        "generated": true,
        "required": true,
        "workflowRole": "decomposed_child",
        "classificationSourceRule": "generated_by_spec_decomposition",
        "requiredByPath": "Main.xaml → Main.xaml → spec-decomposition:GetBirthdays",
        "expectedCaller": "Main.xaml",
        "callerCandidates": [
          "Main.xaml",
          "Process.xaml"
        ],
        "invokeAttempted": true,
        "invokeSucceeded": true,
        "invokeSkippedReason": null,
        "invokeRejectedReason": null,
        "actualCallers": [
          "Main.xaml"
        ],
        "reachableFromMain": true,
        "finalWiringStatus": "wired_and_reachable",
        "rootCauseCategory": "none",
        "remediationHint": null,
        "unwiredSeverity": "none"
      },
      {
        "file": "ProcessBirthday.xaml",
        "generated": true,
        "required": true,
        "workflowRole": "decomposed_child",
        "classificationSourceRule": "generated_by_spec_decomposition",
        "requiredByPath": "Main.xaml → Main.xaml → spec-decomposition:ProcessBirthday",
        "expectedCaller": "Main.xaml",
        "callerCandidates": [
          "Main.xaml",
          "Process.xaml"
        ],
        "invokeAttempted": true,
        "invokeSucceeded": true,
        "invokeSkippedReason": null,
        "invokeRejectedReason": null,
        "actualCallers": [
          "Main.xaml"
        ],
        "reachableFromMain": true,
        "finalWiringStatus": "wired_and_reachable",
        "rootCauseCategory": "none",
        "remediationHint": null,
        "unwiredSeverity": "none"
      },
      {
        "file": "GenerateAndValidateDraft.xaml",
        "generated": true,
        "required": true,
        "workflowRole": "decomposed_child",
        "classificationSourceRule": "generated_by_spec_decomposition",
        "requiredByPath": "Main.xaml → HandleHumanReview.xaml → spec-decomposition:GenerateAndValidateDraft",
        "expectedCaller": "HandleHumanReview.xaml",
        "callerCandidates": [
          "HandleHumanReview.xaml",
          "Process.xaml",
          "Main.xaml"
        ],
        "invokeAttempted": true,
        "invokeSucceeded": true,
        "invokeSkippedReason": null,
        "invokeRejectedReason": null,
        "actualCallers": [
          "HandleHumanReview.xaml"
        ],
        "reachableFromMain": true,
        "finalWiringStatus": "wired_and_reachable",
        "rootCauseCategory": "none",
        "remediationHint": null,
        "unwiredSeverity": "none"
      },
      {
        "file": "HandleHumanReview.xaml",
        "generated": true,
        "required": true,
        "workflowRole": "decomposed_child",
        "classificationSourceRule": "generated_by_spec_decomposition",
        "requiredByPath": "Main.xaml → ProcessBirthday.xaml → spec-decomposition:HandleHumanReview",
        "expectedCaller": "ProcessBirthday.xaml",
        "callerCandidates": [
          "ProcessBirthday.xaml",
          "Process.xaml",
          "Main.xaml"
        ],
        "invokeAttempted": true,
        "invokeSucceeded": true,
        "invokeSkippedReason": null,
        "invokeRejectedReason": null,
        "actualCallers": [
          "ProcessBirthday.xaml"
        ],
        "reachableFromMain": true,
        "finalWiringStatus": "wired_and_reachable",
        "rootCauseCategory": "none",
        "remediationHint": null,
        "unwiredSeverity": "none"
      },
      {
        "file": "Finalize.xaml",
        "generated": true,
        "required": true,
        "workflowRole": "decomposed_child",
        "classificationSourceRule": "generated_by_spec_decomposition",
        "requiredByPath": "Main.xaml → Process.xaml → spec-decomposition:Finalize",
        "expectedCaller": "Process.xaml",
        "callerCandidates": [
          "Process.xaml",
          "Main.xaml"
        ],
        "invokeAttempted": true,
        "invokeSucceeded": false,
        "invokeSkippedReason": null,
        "invokeRejectedReason": "Process.xaml content is empty or not found — no wiring target available",
        "actualCallers": [],
        "reachableFromMain": false,
        "finalWiringStatus": "unwired_but_retained",
        "rootCauseCategory": "invoke_emission_skipped_no_process_xaml",
        "remediationHint": "Process.xaml content is empty or not found — no wiring target available",
        "unwiredSeverity": "package_fatal"
      },
      {
        "file": "InitAllSettings.xaml",
        "generated": false,
        "required": false,
        "workflowRole": "helper",
        "classificationSourceRule": "infrastructure_basename_match:initallsettings",
        "unwiredSeverity": "none",
        "requiredByPath": "infrastructure utility",
        "expectedCaller": "Main.xaml",
        "callerCandidates": [
          "Main.xaml"
        ],
        "invokeAttempted": false,
        "invokeSucceeded": false,
        "invokeSkippedReason": "infrastructure file — always included",
        "invokeRejectedReason": null,
        "actualCallers": [],
        "reachableFromMain": false,
        "finalWiringStatus": "skipped_infrastructure",
        "rootCauseCategory": "none",
        "remediationHint": null
      }
    ],
    "summary": {
      "totalGeneratedWorkflows": 6,
      "totalRequiredWorkflows": 6,
      "totalRequiredWorkflowsWired": 5,
      "totalGeneratedButUnwired": 1,
      "totalUnreachableFromMain": 1,
      "totalMissingInvokeEdges": 0,
      "totalCallerMismatchDefects": 0,
      "totalInvokeEmissionFailures": 1
    },
    "activePathProof": {
      "reachabilityComputedOnFinalizedSet": true,
      "reachabilityPruningSkipped": false,
      "wiringComputedOnFinalizedSet": true,
      "workflowSetHashAtWiringTime": "ea59b4bbcecf5536",
      "workflowSetHashAtReachabilityTime": "ea59b4bbcecf5536",
      "consistent": true
    }
  },
  "catalogFilterAdoption": [
    {
      "stage": "quality-gate",
      "adopted": true,
      "lookups": {
        "total": 750,
        "approved": 750,
        "deprecated": 0,
        "nonEmissionApproved": 0,
        "targetIncompatible": 0,
        "unknown": 0
      }
    },
    {
      "stage": "deterministic-validators",
      "adopted": true,
      "lookups": {
        "total": 9088,
        "approved": 5024,
        "deprecated": 0,
        "nonEmissionApproved": 0,
        "targetIncompatible": 0,
        "unknown": 4064
      }
    },
    {
      "stage": "iterative-llm-corrector",
      "adopted": true,
      "lookups": {
        "total": 0,
        "approved": 0,
        "deprecated": 0,
        "nonEmissionApproved": 0,
        "targetIncompatible": 0,
        "unknown": 0
      }
    },
    {
      "stage": "workflow-tree-assembler",
      "adopted": true,
      "lookups": {
        "total": 0,
        "approved": 0,
        "deprecated": 0,
        "nonEmissionApproved": 0,
        "targetIncompatible": 0,
        "unknown": 0
      }
    },
    {
      "stage": "xaml-compliance",
      "adopted": true,
      "lookups": {
        "total": 9852,
        "approved": 6327,
        "deprecated": 0,
        "nonEmissionApproved": 1980,
        "targetIncompatible": 0,
        "unknown": 1545
      }
    },
    {
      "stage": "executable-path-validator",
      "adopted": true,
      "lookups": {
        "total": 566,
        "approved": 493,
        "deprecated": 0,
        "nonEmissionApproved": 0,
        "targetIncompatible": 0,
        "unknown": 73
      }
    },
    {
      "stage": "post-emission-dependency-analyzer",
      "adopted": true,
      "lookups": {
        "total": 9,
        "approved": 9,
        "deprecated": 0,
        "nonEmissionApproved": 0,
        "targetIncompatible": 0,
        "unknown": 0
      }
    }
  ]
}
```
