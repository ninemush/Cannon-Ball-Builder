# Developer Handoff Guide

**Project:** WeatherAndTravelNotification
**Description:** Unattended RPA automation that retrieves live weather data, TfL Underground status, and National Rail C2C status every weekday at 6:45am, applies route recommendation logic, and delivers a formatted HTML commute intelligence email to Yusuf.yasin@uipath.com before 7am departure.
**Generated:** 2026-03-18
**Architecture:** REFramework (Queue-based transactional)
**Generation Mode:** Full Implementation
**Mode Reason:** Pattern "transactional-queue" supports full implementation with REFramework

**Readiness Score: 85%** | Estimated developer effort: **~3.0 hours** (0 selectors, 3 credentials, 105 min mandatory validation)

---

## 1. Quality Gate Results

### Warnings (66)

These are minor issues that do not prevent the package from being opened or used. They represent areas where a developer can improve the generated output.

| # | File | Check | Detail |
|---|------|-------|---------|
| 1 | `Main.xaml` | hardcoded-credential | Potential hardcoded credential detected (pattern: password\s*[:=]\s*["'](?!\[)[^...) |
| 2 | `Main.xaml` | missing-package-dep | Activity "ui:HttpClient" requires package "UiPath.Web.Activities" which is not in project.json dependencies |
| 3 | `Main.xaml` | unknown-activity | Line 485: unknown activity "ui:InvokeCode" — not in known activity registry (may be hallucinated) |
| 4 | `Main.xaml` | missing-package-dep | Activity "ui:HttpClient" requires package "UiPath.Web.Activities" which is not in project.json dependencies |
| 5 | `Main.xaml` | unknown-activity | Line 647: unknown activity "ui:InvokeCode" — not in known activity registry (may be hallucinated) |
| 6 | `Main.xaml` | unknown-activity | Line 699: unknown activity "ui:InvokeCode" — not in known activity registry (may be hallucinated) |
| 7 | `Main.xaml` | missing-package-dep | Activity "ui:HttpClient" requires package "UiPath.Web.Activities" which is not in project.json dependencies |
| 8 | `Main.xaml` | unknown-activity | Line 794: unknown activity "ui:InvokeCode" — not in known activity registry (may be hallucinated) |
| 9 | `Main.xaml` | unknown-activity | Line 830: unknown activity "ui:InvokeCode" — not in known activity registry (may be hallucinated) |
| 10 | `Main.xaml` | invalid-activity-property | Line 61: property "Main" is not a known property of ui:LogMessage |
| 11 | `Main.xaml` | invalid-activity-property | Line 427: property "lat" is not a known property of ui:HttpClient |
| 12 | `Main.xaml` | invalid-activity-property | Line 427: property "lon" is not a known property of ui:HttpClient |
| 13 | `Main.xaml` | invalid-activity-property | Line 427: property "appid" is not a known property of ui:HttpClient |
| 14 | `Main.xaml` | invalid-activity-property | Line 427: property "units" is not a known property of ui:HttpClient |
| 15 | `Main.xaml` | invalid-activity-property | Line 427: property "Timeout" is not a known property of ui:HttpClient |
| 16 | `Main.xaml` | invalid-activity-property | Line 589: property "Timeout" is not a known property of ui:HttpClient |
| 17 | `Main.xaml` | invalid-activity-property | Line 712: property "primaryRouteDisrupted" is not a known property of ui:LogMessage |
| 18 | `Main.xaml` | invalid-activity-property | Line 736: property "Timeout" is not a known property of ui:HttpClient |
| 19 | `Main.xaml` | invalid-activity-property | Line 838: property "c2cAvailable" is not a known property of ui:LogMessage |
| 20 | `Main.xaml` | invalid-activity-property | Line 1043: property "Host" is not a known property of ui:SendSmtpMailMessage |
| 21 | `Main.xaml` | invalid-activity-property | Line 1043: property "EnableSsl" is not a known property of ui:SendSmtpMailMessage |
| 22 | `Main.xaml` | invalid-activity-property | Line 1043: property "Username" is not a known property of ui:SendSmtpMailMessage |
| 23 | `Main.xaml` | invalid-activity-property | Line 1043: property "From" is not a known property of ui:SendSmtpMailMessage |
| 24 | `Main.xaml` | invalid-activity-property | Line 1043: property "Timeout" is not a known property of ui:SendSmtpMailMessage |
| 25 | `Main.xaml` | invalid-activity-property | Line 1083: property "Host" is not a known property of ui:SendSmtpMailMessage |
| 26 | `Main.xaml` | invalid-activity-property | Line 1083: property "EnableSsl" is not a known property of ui:SendSmtpMailMessage |
| 27 | `Main.xaml` | invalid-activity-property | Line 1083: property "Username" is not a known property of ui:SendSmtpMailMessage |
| 28 | `Main.xaml` | invalid-activity-property | Line 1083: property "From" is not a known property of ui:SendSmtpMailMessage |
| 29 | `Main.xaml` | invalid-activity-property | Line 1083: property "Timeout" is not a known property of ui:SendSmtpMailMessage |
| 30 | `Main.xaml` | invalid-activity-property | Line 1130: property "Main" is not a known property of ui:LogMessage |
| 31 | `Main.xaml` | invalid-type-argument | Line 39: x:TypeArguments="AssemblyReference" may not be a valid .NET type |
| 32 | `InitAllSettings.xaml` | missing-package-dep | Activity "ui:ExcelApplicationScope" requires package "UiPath.Excel.Activities" which is not in project.json dependencies |
| 33 | `InitAllSettings.xaml` | missing-package-dep | Activity "ui:ExcelReadRange" requires package "UiPath.Excel.Activities" which is not in project.json dependencies |
| 34 | `InitAllSettings.xaml` | missing-package-dep | Activity "ui:ExcelReadRange" requires package "UiPath.Excel.Activities" which is not in project.json dependencies |
| 35 | `InitAllSettings.xaml` | invalid-activity-property | Line 151: property "InitAllSettings" is not a known property of ui:LogMessage |
| 36 | `InitAllSettings.xaml` | invalid-type-argument | Line 39: x:TypeArguments="AssemblyReference" may not be a valid .NET type |
| 37 | `Main.xaml` | hardcoded-asset-name | Line 146: asset name "WeatherAPI_Key" is hardcoded — consider using a Config.xlsx entry or workflow argument |
| 38 | `Main.xaml` | hardcoded-asset-name | Line 185: asset name "Gmail_Username" is hardcoded — consider using a Config.xlsx entry or workflow argument |
| 39 | `Main.xaml` | hardcoded-asset-name | Line 224: asset name "Gmail_AppPassword" is hardcoded — consider using a Config.xlsx entry or workflow argument |
| 40 | `Main.xaml` | hardcoded-asset-name | Line 263: asset name "NationalRail_ApiKey" is hardcoded — consider using a Config.xlsx entry or workflow argument |
| 41 | `Main.xaml` | hardcoded-asset-name | Line 302: asset name "Recipient_Email" is hardcoded — consider using a Config.xlsx entry or workflow argument |
| 42 | `Main.xaml` | hardcoded-asset-name | Line 341: asset name "Home_Lat" is hardcoded — consider using a Config.xlsx entry or workflow argument |
| 43 | `Main.xaml` | hardcoded-asset-name | Line 380: asset name "Home_Lon" is hardcoded — consider using a Config.xlsx entry or workflow argument |
| 44 | `Main.xaml` | hardcoded-time-interval | Line 1079: time interval "Duration=00:30" is hardcoded — consider externalizing to Config.xlsx |
| 45 | `InitAllSettings.xaml` | hardcoded-asset-name | Line 102: asset name "WeatherAPI_Key" is hardcoded — consider using a Config.xlsx entry or workflow argument |
| 46 | `InitAllSettings.xaml` | hardcoded-asset-name | Line 114: asset name "Gmail_AppPassword" is hardcoded — consider using a Config.xlsx entry or workflow argument |
| 47 | `InitAllSettings.xaml` | hardcoded-asset-name | Line 123: asset name "NationalRail_ApiKey" is hardcoded — consider using a Config.xlsx entry or workflow argument |
| 48 | `InitAllSettings.xaml` | hardcoded-asset-name | Line 132: asset name "Gmail_Username" is hardcoded — consider using a Config.xlsx entry or workflow argument |
| 49 | `InitAllSettings.xaml` | hardcoded-asset-name | Line 133: asset name "Recipient_Email" is hardcoded — consider using a Config.xlsx entry or workflow argument |
| 50 | `InitAllSettings.xaml` | hardcoded-asset-name | Line 134: asset name "Home_Lat" is hardcoded — consider using a Config.xlsx entry or workflow argument |
| 51 | `InitAllSettings.xaml` | hardcoded-asset-name | Line 135: asset name "Home_Lon" is hardcoded — consider using a Config.xlsx entry or workflow argument |
| 52 | `DeveloperHandoffGuide.md` | archive-parity-missing-artifact | Expected artifact "DeveloperHandoffGuide.md" is not present in the archive manifest |
| 53 | `Main.xaml` | CATALOG_VIOLATION | Unrecognized child property "Try" on TryCatch — not in catalog schema |
| 54 | `Main.xaml` | CATALOG_VIOLATION | Unrecognized child property "TryCatch.Try" on TryCatch — not in catalog schema |
| 55 | `Main.xaml` | CATALOG_VIOLATION | Unrecognized child property "Catches" on TryCatch — not in catalog schema |
| 56 | `Main.xaml` | CATALOG_VIOLATION | Unrecognized child property "TryCatch.Catches" on TryCatch — not in catalog schema |
| 57 | `Main.xaml` | CATALOG_VIOLATION | Missing required property "EndpointUrl" on ui:HttpClient |
| 58 | `Main.xaml` | CATALOG_VIOLATION | Unrecognized child property "Then" on If — not in catalog schema |
| 59 | `Main.xaml` | CATALOG_VIOLATION | Unrecognized child property "If.Then" on If — not in catalog schema |
| 60 | `Main.xaml` | CATALOG_VIOLATION | Unrecognized child property "Else" on If — not in catalog schema |
| 61 | `Main.xaml` | CATALOG_VIOLATION | Unrecognized child property "If.Else" on If — not in catalog schema |
| 62 | `Main.xaml` | CATALOG_VIOLATION | Unrecognized attribute "Host" on ui:SendSmtpMailMessage — not in catalog schema |
| 63 | `Main.xaml` | CATALOG_VIOLATION | Unrecognized attribute "EnableSsl" on ui:SendSmtpMailMessage — not in catalog schema |
| 64 | `Main.xaml` | CATALOG_VIOLATION | Unrecognized attribute "Username" on ui:SendSmtpMailMessage — not in catalog schema |
| 65 | `Main.xaml` | CATALOG_VIOLATION | Unrecognized attribute "From" on ui:SendSmtpMailMessage — not in catalog schema |
| 66 | `InitAllSettings.xaml` | CATALOG_VIOLATION | Unrecognized attribute "TypeArguments" on ForEach — not in catalog schema |

---

## 2. Tier 1 — AI Completed (No Human Action Required)

The following items were fully automated by CannonBall. These are verified facts from deterministic analysis.

### Workflow Inventory

**6 XAML workflow(s)** generated containing **0 activities** total.

| # | Workflow File | Purpose | Role |
|---|--------------|---------|------|
| 1 | `Main.xaml` | REFramework State Machine entry point | Entry Point |
| 2 | `GetTransactionData.xaml` | Sub-workflow | Sub-workflow |
| 3 | `Process.xaml` | Sub-workflow | Sub-workflow |
| 4 | `SetTransactionStatus.xaml` | Sub-workflow | Sub-workflow |
| 5 | `CloseAllApplications.xaml` | Sub-workflow | Sub-workflow |
| 6 | `KillAllProcesses.xaml` | Sub-workflow | Sub-workflow |

### Workflow Analyzer Compliance

Analyzed 2 workflow file(s) against UiPath Workflow Analyzer rules.

| Rule ID | Rule | Category | Status | Auto-Fixed | Remaining |
|---------|------|----------|--------|------------|----------|
| ST-NMG-001 | Variable naming convention | naming | Auto-Fixed | 7 | 0 |
| ST-NMG-004 | Argument naming convention | naming | Passed | 0 | 0 |
| ST-NMG-009 | Activity must have DisplayName | naming | Passed | 0 | 0 |
| ST-DBP-002 | Empty Catch block | best-practice | Passed | 0 | 0 |
| ST-DBP-006 | Delay activity usage | best-practice | Passed | 0 | 0 |
| ST-DBP-020 | Hardcoded timeout | best-practice | Passed | 0 | 0 |
| ST-DBP-025 | Workflow start/end logging | best-practice | Needs Review | 1 | 1 |
| ST-USG-005 | Unused variable | usage | Needs Review | 0 | 8 |
| ST-USG-017 | Deeply nested If activities | usage | Passed | 0 | 0 |
| ST-SEC-004 | Sensitive data in log message | security | Needs Review | 0 | 6 |
| ST-SEC-005 | Plaintext credential in property | security | Needs Review | 0 | 2 |
| ST-ARG-001 | Invalid bare Argument tag in Catch | usage | Auto-Fixed | 2 | 0 |
| ST-ARG-002 | Missing declaration for invoked argument | usage | Passed | 0 | 0 |
| ST-ARG-003 | Undeclared variable in expression | usage | Passed | 0 | 0 |

**Result:** 20 of 28 rules passed across 2 workflow files. 10 violation(s) auto-corrected, 17 remaining for review.

**Per-Workflow Breakdown:**

| Workflow | Rules Checked | Passed | Auto-Fixed | Remaining |
|----------|--------------|--------|------------|----------|
| `Main.xaml` | 14 | 10 | 5 | 14 |
| `InitAllSettings.xaml` | 14 | 10 | 5 | 3 |

### Standards Enforcement

| Standard | What Was Done |
|----------|---------------|
| Naming Conventions | Variables renamed to `{type}_{PascalCase}`, arguments to `{direction}_{PascalCase}` |
| Activity Annotations | Every activity annotated with source step number, business context, and error handling strategy |
| Error Handling | All business activities wrapped in TryCatch with Log + Rethrow; UI activities include RetryScope (3 retries, 5s) |
| Logging | Start/end LogMessage in every workflow; exceptions logged at Error level before rethrow |
| Argument Validation | Entry points validate required arguments at workflow start |

### Architecture Decision

**REFramework** selected — queue-based transactional processing with built-in retry and recovery.

```
Init → Get Transaction → Process Transaction → Get Transaction (loop)
                                    ↓ (exception)
                              Close Apps → Get Transaction (retry)
                    ↓ (no more items)
                       End Process
```

---

## 3. Tier 2 — AI Resolved with Smart Defaults (Review Recommended)

The AI set these values based on SDD analysis. They are likely correct but **must be verified** against your target environment before production use.

### Asset Values

| Asset | Type | AI-Set Value | Action Required |
|-------|------|--------------|-----------------|
| `Gmail_Username` | Text | `(empty)` | Verify matches your environment. Gmail sender account username for SMTP email delivery. |
| `Recipient_Email` | Text | `Yusuf.yasin@uipath.com` | Verify matches your environment. Target email address for daily commute notification. |
| `Home_Lat` | Text | `51.5586` | Verify matches your environment. Home location latitude for OpenWeatherMap API geolocation (RM14 1BT). |
| `Home_Lon` | Text | `0.2490` | Verify matches your environment. Home location longitude for OpenWeatherMap API geolocation (RM14 1BT). |

### Trigger Configuration

| Trigger | Type | Schedule | Timezone | Status | Action Required |
|---------|------|----------|----------|--------|-----------------|
| `WTN-WeekdayMorningTrigger` | Time | Cron: `0 45 6 ? * MON-FRI` | UTC | unknown | Verify schedule matches business requirements |

---

## 4. Process Logic Validation

Use this section to verify that the generated automation correctly implements the business rules defined in the SDD. Each item below should be confirmed against the live system before UAT.

### Extracted Business Rules — Verification Checklist

The following rules were extracted from the SDD. Verify each is correctly implemented in the generated workflows:

| # | Category | Rule / Requirement | Verified |
|---|----------|-------------------|----------|
| 1 | Retry / SLA Requirements | retry once after 30 seconds, fail job if second attempt fails \| | [ ] |

---

## 5. Tier 3 — Requires Human Access (Developer Work Required)

These items require a developer with access to target systems and UiPath Studio. **Every generated package requires this work.**

### Credentials (3 items)

These require access to production/UAT credential stores. **Credentials are never auto-filled** — you must set real values.

| # | Asset | Orchestrator ID | Description | Where to Set |
|---|-------|-----------------|-------------|-------------|
| 1 | `WeatherAPI_Key` | — | OpenWeatherMap API key for weather data retrieval. Register free at openweathermap.org/api. | Orchestrator > Assets > `WeatherAPI_Key` > Edit |
| 2 | `Gmail_AppPassword` | — | Gmail App Password for SMTP authentication. Generate in Google Account security settings. | Orchestrator > Assets > `Gmail_AppPassword` > Edit |
| 3 | `NationalRail_ApiKey` | — | National Rail Open Data API key. Register free at opendata.nationalrail.co.uk. | Orchestrator > Assets > `NationalRail_ApiKey` > Edit |

### Business Logic & Manual Steps (1 items)

| # | Category | Activity | Description | Est. Time |
|---|----------|----------|-------------|----------|
| 1 | logic | `ErrorHandling` | Review SDD Section 5 error handling strategy and ensure all exception paths are implemented | 60 min |

### Machine & Robot Configuration

Machines provisioned: `WTN-UNATTENDED-01`. Verify they are assigned to the correct folder and have available unattended slots.

### Action Center Configuration

| # | Task Catalog | Status | ID | Action Required |
|---|-------------|--------|----|-----------------|
| 1 | `WTN-DeliveryFailureReview` | unknown | — | Assign role (Process Owner), configure form fields, set SLA (suggested: 2 hours) |

### Mandatory: Studio Validation & Testing

Every generated package requires these steps regardless of AI enrichment quality:

| # | Task | Description | Est. Time |
|---|------|-------------|----------|
| 1 | Studio Import | Open .nupkg in UiPath Studio. Install missing packages, resolve dependency conflicts, verify project compiles without errors. | 15 min |
| 2 | Credential Setup | Set real username/password for 3 credential asset(s) in Orchestrator > Assets. | 15 min |
| 3 | End-to-End Testing | Execute all 6 workflows in Studio Debug mode against UAT/test environment. Verify queue processing, exception handling, and business rules. | 30 min |
| 4 | UAT Sign-off | Business stakeholder validation with real data and real systems. Confirm outputs match expected results for representative scenarios. | 60 min |

**Total Tier 3 Effort: ~3.3 hours** (0 selectors, 3 credentials, 1 logic items, mandatory validation)

---

## 6. Code Review Checklist

Use this checklist during peer review before promoting to UAT.

### Workflow Analyzer Remaining Violations

| Severity | Rule | File | Message |
|----------|------|------|---------|
| warning | ST-USG-005 | Main.xaml | Variable "obj_WeatherResponseStatus" is declared but never used |
| warning | ST-USG-005 | Main.xaml | Variable "obj_TflResponseStatus" is declared but never used |
| warning | ST-USG-005 | Main.xaml | Variable "bool_PrimaryRouteDisrupted" is declared but never used |
| warning | ST-USG-005 | Main.xaml | Variable "obj_C2cResponseStatus" is declared but never used |
| warning | ST-USG-005 | Main.xaml | Variable "bool_C2cAvailable" is declared but never used |
| warning | ST-USG-005 | Main.xaml | Variable "str_ScreenshotPath" is declared but never used |
| error | ST-SEC-004 | Main.xaml | LogMessage may contain sensitive data (matched: "api_key") — use SecureString or mask the value |
| error | ST-SEC-004 | Main.xaml | LogMessage may contain sensitive data (matched: "password") — use SecureString or mask the value |
| error | ST-SEC-004 | Main.xaml | LogMessage may contain sensitive data (matched: "apikey") — use SecureString or mask the value |
| error | ST-SEC-004 | Main.xaml | LogMessage may contain sensitive data (matched: "token(?!ize)") — use SecureString or mask the value |
| error | ST-SEC-004 | Main.xaml | LogMessage may contain sensitive data (matched: "token(?!ize)") — use SecureString or mask the value |
| error | ST-SEC-004 | Main.xaml | LogMessage may contain sensitive data (matched: "token(?!ize)") — use SecureString or mask the value |
| error | ST-SEC-005 | Main.xaml | Possible plaintext credential detected — use Orchestrator Asset or Windows Credential Manager |
| error | ST-SEC-005 | Main.xaml | Possible plaintext credential detected — use Orchestrator Asset or Windows Credential Manager |
| warning | ST-DBP-025 | InitAllSettings.xaml | Workflow does not contain an initial LogMessage activity |
| warning | ST-USG-005 | InitAllSettings.xaml | Variable "str_ConfigPath" is declared but never used |
| warning | ST-USG-005 | InitAllSettings.xaml | Variable "drow_RowCurrent" is declared but never used |

### Review Rubric

| Category | Check | Status |
|----------|-------|---------|
| Exception Handling | All activities in TryCatch? Catch blocks log + rethrow? | AI: Done |
| Transaction Integrity | Queue items set to Success/Failed/BusinessException? | AI: Done (REFramework) |
| Logging | Info log at start/end of each workflow? Critical decisions logged? | AI: Done |
| Selector Reliability | Selectors use stable attributes (automationid, name)? | N/A |
| Credential Security | All credentials in Orchestrator Assets, not hardcoded? | AI: Verified |
| Naming Conventions | Variables/arguments follow type/direction prefixes? | AI: Auto-corrected |
| Annotations | Every activity annotated with business context? | AI: Done |
| Argument Validation | Entry points validate required arguments? | AI: Done |
| Config Management | Environment-specific values in Config.xlsx? | AI: Done |

### Pre-Deployment Verification

1. Open the project in UiPath Studio
2. Run **Analyze File** > **Workflow Analyzer** on all files
3. Confirm zero errors and zero warnings
4. Run all unit tests in Test Manager
5. Execute a full end-to-end run in Dev environment

### Sign-Off

| Field | Value |
|-------|-------|
| Reviewer | _________________ |
| Date | _________________ |
| Approval | [ ] Approved for UAT  [ ] Requires Changes |
| Notes | _________________ |

---

## 7. Package Contents

| File | Purpose |
|------|--------|
| `project.json` | UiPath project manifest with dependencies |
| `Main.xaml` | REFramework State Machine entry point |
| `GetTransactionData.xaml` | Fetches next queue item |
| `Process.xaml` | Business logic for single transaction |
| `SetTransactionStatus.xaml` | Marks transaction Success/Failed |
| `CloseAllApplications.xaml` | Graceful app cleanup |
| `KillAllProcesses.xaml` | Force-kill hanging processes |
| `InitAllSettings.xaml` | Configuration initialization |
| `Data/Config.xlsx` | Configuration settings |
| `DeveloperHandoffGuide.md` | This guide |

**Required Packages:** `UiPath.System.Activities`, `UiPath.UIAutomation.Activities`, `UiPath.Mail.Activities`

---

## 8. Test Suite

| # | Test Case | Type | Priority | Status |
|---|-----------|------|----------|--------|
| 1 | `TC001 - Happy Path No Disruptions` | Functional | Medium | unknown |
| 2 | `TC002 - District Line Disrupted C2C Available` | Functional | Medium | unknown |
| 3 | `TC003 - Both Routes Disrupted` | Functional | Medium | unknown |
| 4 | `TC004 - Weather API Failure` | Functional | Medium | unknown |
| 5 | `TC005 - Gmail SMTP Failure` | Functional | Medium | unknown |
| 6 | `TC006 - All APIs Unavailable` | Functional | Medium | unknown |

| # | Test Set | Mode | Test Cases | Status |
|---|----------|------|------------|--------|
| 1 | `Happy Path Tests` | Sequential | 1 | unknown |
| 2 | `Disruption Scenario Tests` | Sequential | 2 | unknown |
| 3 | `Exception Handling Tests` | Sequential | 3 | unknown |

---

## 9. Requirements Traceability

| # | Requirement | Type | Priority | Status |
|---|------------|------|----------|--------|
| 1 | `REQ-001: Daily weekday email notification` | Functional | Medium | unknown |
| 2 | `REQ-002: Weather data for 7am departure` | Functional | Medium | unknown |
| 3 | `REQ-003: TfL Underground status check` | Functional | Medium | unknown |
| 4 | `REQ-004: National Rail C2C fallback check` | Functional | Medium | unknown |
| 5 | `REQ-005: Route recommendation in email` | Functional | Medium | unknown |
| 6 | `REQ-006: Graceful degradation on API failure` | Functional | Medium | unknown |

---

## 10. Infrastructure

**Machines:** `WTN-UNATTENDED-01` (Unattended, 1 slots)
**Storage:** `WTN-Logs` (Orchestrator)

### Action Center

**WTN-DeliveryFailureReview** (unknown) — SLA: 2 hours

---

## 11. Go-Live Checklist

#### Development
- [ ] Open project in UiPath Studio — install missing packages
- [ ] Run Workflow Analyzer — confirm zero violations
- [ ] Complete Tier 3 items (selectors, credentials, business logic)
- [ ] Config.xlsx updated with Dev values

#### UAT
- [ ] UAT Orchestrator folder with separate assets/queues
- [ ] Full end-to-end run with real data
- [ ] Business stakeholder sign-off

#### Production
- [ ] Production credentials and assets configured
- [ ] Triggers/schedules active
- [ ] Monitoring and alerting configured
- [ ] Runbook documentation completed
