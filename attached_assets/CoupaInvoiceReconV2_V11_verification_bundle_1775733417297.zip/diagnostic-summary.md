# Diagnostic Summary

## Run Metadata
- **Run ID:** aec751d3-bd77-4902-93d3-253159c827c5
- **Idea ID:** 71e79d15-265d-433c-a414-f8a2c7c0d290
- **Status:** completed_with_warnings
- **Generation Mode:** baseline_openable
- **Triggered By:** chat
- **Created At:** Thu Apr 09 2026 11:06:18 GMT+0000 (Coordinated Universal Time)
- **Completed At:** Thu Apr 09 2026 11:13:07 GMT+0000 (Coordinated Universal Time)
- **Duration:** 409.3s

## Stage Timing

| Stage | Status | Duration (ms) |
|-------|--------|--------------|
| sdd_validation | succeeded | 18 |
| pipeline_sdd_validation | succeeded | 18 |
| spec_generation | succeeded | 389468 |
| spec_context_loading | succeeded | 4 |
| spec_prompt_assembly | succeeded | 2 |
| pre_complexity_estimation | succeeded | 0 |
| spec_scaffold | succeeded | 47328 |
| spec_workflow_detail_ActionCenterTaskCreator_retry | failed | 0 |
| workflow_budget_check | succeeded | 0 |
| spec_merge | succeeded | 0 |
| spec_handoff | succeeded | 0 |
| build_pipeline | succeeded | 19746 |
| pipeline_build_pipeline | succeeded | 19747 |
| pipeline_decomposition | succeeded | 3 |
| pipeline_pre_complexity_estimation | succeeded | 0 |
| pipeline_workflow_budget_check | succeeded | 0 |
| pipeline_complexity_classification | succeeded | 1 |
| pipeline_xaml_emission | succeeded | 12118 |
| pipeline_xaml_emission_fallback | degraded | 0 |
| pipeline_xaml_emission_fallback | degraded | 0 |
| pipeline_xaml_emission_fallback | degraded | 0 |
| pipeline_xaml_emission_fallback | degraded | 0 |
| pipeline_xaml_emission_fallback | degraded | 0 |
| pipeline_xaml_emission_fallback | degraded | 0 |
| pipeline_xaml_emission_fallback | degraded | 0 |
| pipeline_compliance_normalization | succeeded | 7 |
| pipeline_validation | succeeded | 1068 |
| pipeline_packaging_dhg | succeeded | 0 |
| pipeline_final_artifact_validation | succeeded | 557 |
| pipeline_packaging_dhg_guide | succeeded | 35 |
| pipeline_dependency-compatibility_fallback | degraded | 0 |
| pipeline_dependency-compatibility_fallback | degraded | 0 |
| pipeline_dependency-compatibility_fallback | degraded | 0 |
| pipeline_authoritative-namespace-injection_fallback | degraded | 0 |
| pipeline_authoritative-namespace-injection_fallback | degraded | 0 |
| pipeline_post-assembly-validation_fallback | degraded | 0 |
| pipeline_post-assembly-validation_fallback | degraded | 0 |
| pipeline_remediating_fallback | degraded | 0 |
| pipeline_complete | succeeded | 0 |

## Deterministic Transforms

| Transform Type | Count |
|---------------|-------|
| compliance_normalization | 21 |
| workflow_analyzer_autofix | 18 |
| activity_policy_filter | 2 |
| expression_lint | 1 |
| type_compatibility | 3 |
| required_property_enforcement | 2 |

## Quality Gate Summary

- **Passed:** false
- **Total Errors:** 2
- **Total Warnings:** 9
- **Completeness:** structural

## Meta-Validation Summary

- **Engaged:** true
- **Mode:** Always
- **Corrections Applied:** 0
- **Corrections Skipped:** 4
- **Corrections Failed:** 3
- **Confidence Score:** 0.5588235294117647
- **Duration:** 265ms

## Remediations

- {"level":"workflow","file":"CoupaSessionManager.xaml","remediationCode":"STUB_WORKFLOW_GENERATOR_FAILURE","reason":"Compliance transform failed — XAML XML well-formedness validation failed: XML well-formedness error at line 26, col 163: char '&' is not expected. (code: InvalidChar)","classifiedCheck":"compliance-crash","developerAction":"TODO: Implement CoupaSessionManager — review SDD for workflow requirements","estimatedEffortMinutes":15}
- {"level":"workflow","file":"Dispatcher.xaml","remediationCode":"STUB_WORKFLOW_GENERATOR_FAILURE","reason":"Compliance transform failed — XAML XML well-formedness validation failed: XML well-formedness error at line 29, col 142: char '&' is not expected. (code: InvalidChar)","classifiedCheck":"compliance-crash","developerAction":"TODO: Implement Dispatcher — review SDD for workflow requirements","estimatedEffortMinutes":15}
- {"level":"workflow","file":"InitPerformer.xaml","remediationCode":"STUB_WORKFLOW_GENERATOR_FAILURE","reason":"Compliance transform failed — XAML XML well-formedness validation failed: XML well-formedness error at line 671, col 151: char '&' is not expected. (code: InvalidChar)","classifiedCheck":"compliance-crash","developerAction":"TODO: Implement InitPerformer — review SDD for workflow requirements","estimatedEffortMinutes":15}
- {"level":"workflow","file":"ProcessInvoice.xaml","remediationCode":"STUB_WORKFLOW_GENERATOR_FAILURE","reason":"Compliance transform failed — XAML XML well-formedness validation failed: XML well-formedness error at line 461, col 161: char '&' is not expected. (code: InvalidChar)","classifiedCheck":"compliance-crash","developerAction":"TODO: Implement ProcessInvoice — review SDD for workflow requirements","estimatedEffortMinutes":15}
- {"level":"workflow","file":"ActionCenterTaskCreator.xaml","remediationCode":"STUB_WORKFLOW_GENERATOR_FAILURE","reason":"Compliance transform failed — XAML XML well-formedness validation failed: XML well-formedness error at line 42, col 169: char '&' is not expected. (code: InvalidChar)","classifiedCheck":"compliance-crash","developerAction":"TODO: Implement ActionCenterTaskCreator — review SDD for workflow requirements","estimatedEffortMinutes":15}
- {"level":"workflow","file":"ActionCenterCallbackHandler.xaml","remediationCode":"STUB_WORKFLOW_GENERATOR_FAILURE","reason":"Compliance transform failed — XAML XML well-formedness validation failed: XML well-formedness error at line 731, col 136: char '&' is not expected. (code: InvalidChar)","classifiedCheck":"compliance-crash","developerAction":"TODO: Implement ActionCenterCallbackHandler — review SDD for workflow requirements","estimatedEffortMinutes":15}
- {"level":"workflow","file":"Main.xaml","remediationCode":"STUB_WORKFLOW_GENERATOR_FAILURE","reason":"Compliance transform failed — XAML XML well-formedness validation failed: XML well-formedness error at line 327, col 136: char '&' is not expected. (code: InvalidChar)","classifiedCheck":"compliance-crash","developerAction":"TODO: Implement Main — review SDD for workflow requirements","estimatedEffortMinutes":15}
- {"level":"validation-finding","file":"Process.xaml","remediationCode":"STUB_ACTIVITY_UNKNOWN","reason":"Line 103: Undeclared variable \"Provide\" in expression: Provide Data — variable is not declared in any <Variable> block in scope","classifiedCheck":"UNDECLARED_VARIABLE","developerAction":"Manually implement activity in Process.xaml — estimated 15 min","estimatedEffortMinutes":15}
- {"level":"validation-finding","file":"Process.xaml","remediationCode":"STUB_ACTIVITY_UNKNOWN","reason":"Line 103: Undeclared variable \"Data\" in expression: Provide Data — variable is not declared in any <Variable> block in scope","classifiedCheck":"UNDECLARED_VARIABLE","developerAction":"Manually implement activity in Process.xaml — estimated 15 min","estimatedEffortMinutes":15}
- {"level":"validation-finding","file":"Process.xaml","remediationCode":"STUB_ACTIVITY_UNKNOWN","reason":"Line 158: Standalone word \"Approved\" may be an undeclared variable — should it be a string literal \"Approved\"? in expression: Approved","classifiedCheck":"EXPRESSION_SYNTAX_UNFIXABLE","developerAction":"Manually implement activity in Process.xaml — estimated 15 min","estimatedEffortMinutes":15}
- {"level":"validation-finding","file":"Process.xaml","remediationCode":"STUB_ACTIVITY_UNKNOWN","reason":"Line 158: Undeclared variable \"Approved\" in expression: Approved — variable is not declared in any <Variable> block in scope","classifiedCheck":"UNDECLARED_VARIABLE","developerAction":"Manually implement activity in Process.xaml — estimated 15 min","estimatedEffortMinutes":15}
- {"level":"validation-finding","file":"Process.xaml","remediationCode":"STUB_ACTIVITY_UNKNOWN","reason":"XAML file is missing TextExpression.NamespacesForImplementation block — Studio cannot resolve expression types without this declaration","classifiedCheck":"MISSING_TEXT_EXPRESSION_NAMESPACES","developerAction":"Manually implement activity in Process.xaml — estimated 15 min","estimatedEffortMinutes":15}
- {"level":"validation-finding","file":"Process.xaml","remediationCode":"STUB_ACTIVITY_UNKNOWN","reason":"XAML file is missing TextExpression.ReferencesForImplementation block — Studio cannot resolve assembly references without this declaration","classifiedCheck":"MISSING_TEXT_EXPRESSION_REFERENCES","developerAction":"Manually implement activity in Process.xaml — estimated 15 min","estimatedEffortMinutes":15}
- {"level":"validation-finding","file":"InitAllSettings.xaml","remediationCode":"STUB_ACTIVITY_UNKNOWN","reason":"Line 173: uexcel:ExcelApplicationScope is missing required property \"ExistingWorkbook\"","classifiedCheck":"MISSING_REQUIRED_ACTIVITY_PROPERTY","developerAction":"Manually implement activity in InitAllSettings.xaml — estimated 15 min","estimatedEffortMinutes":15}
- {"level":"validation-finding","file":"InitAllSettings.xaml","remediationCode":"STUB_ACTIVITY_UNKNOWN","reason":"Line 274: ui:GetCredential is missing required property \"Target\"","classifiedCheck":"MISSING_REQUIRED_ACTIVITY_PROPERTY","developerAction":"Manually implement activity in InitAllSettings.xaml — estimated 15 min","estimatedEffortMinutes":15}
- {"level":"validation-finding","file":"Process.xaml","remediationCode":"STUB_ACTIVITY_CATALOG_VIOLATION","reason":"Property \"TaskPriority\" on upers:CreateFormTask must be a child element, not an attribute","classifiedCheck":"CATALOG_STRUCTURAL_VIOLATION","developerAction":"Fix property syntax for activity in Process.xaml — move attribute to child-element or vice versa per UiPath catalog","estimatedEffortMinutes":15}
- {"level":"validation-finding","file":"Process.xaml","remediationCode":"STUB_ACTIVITY_CATALOG_VIOLATION","reason":"ENUM_VIOLATION: Invalid value \"TODO_Provide_value_for_TaskPriority\" for \"TaskPriority\" on upers:CreateFormTask — valid values: Low, Medium, High, Critical. No normalization match found.","classifiedCheck":"ENUM_VIOLATION","developerAction":"Fix enum value for activity in Process.xaml — use valid enum from UiPath documentation","estimatedEffortMinutes":5}
- {"level":"validation-finding","file":"InitAllSettings.xaml","remediationCode":"STUB_ACTIVITY_CATALOG_VIOLATION","reason":"Property \"ExistingWorkbook\" on uexcel:ExcelApplicationScope must be a child element, not an attribute","classifiedCheck":"CATALOG_STRUCTURAL_VIOLATION","developerAction":"Fix property syntax for activity in InitAllSettings.xaml — move attribute to child-element or vice versa per UiPath catalog","estimatedEffortMinutes":15}
- {"level":"validation-finding","file":"InitAllSettings.xaml","remediationCode":"STUB_ACTIVITY_CATALOG_VIOLATION","reason":"Property \"To\" on Assign must be a child element, not an attribute","classifiedCheck":"CATALOG_STRUCTURAL_VIOLATION","developerAction":"Fix property syntax for activity in InitAllSettings.xaml — move attribute to child-element or vice versa per UiPath catalog","estimatedEffortMinutes":15}
- {"level":"validation-finding","file":"InitAllSettings.xaml","remediationCode":"STUB_ACTIVITY_CATALOG_VIOLATION","reason":"Property \"Value\" on Assign must be a child element, not an attribute","classifiedCheck":"CATALOG_STRUCTURAL_VIOLATION","developerAction":"Fix property syntax for activity in InitAllSettings.xaml — move attribute to child-element or vice versa per UiPath catalog","estimatedEffortMinutes":15}
- {"level":"validation-finding","file":"Main.xaml","remediationCode":"STUB_ACTIVITY_CATALOG_VIOLATION","reason":"Property \"To\" on Assign must be a child element, not an attribute","classifiedCheck":"CATALOG_STRUCTURAL_VIOLATION","developerAction":"Fix property syntax for activity in Main.xaml — move attribute to child-element or vice versa per UiPath catalog","estimatedEffortMinutes":15}
- {"level":"validation-finding","file":"Main.xaml","remediationCode":"STUB_ACTIVITY_CATALOG_VIOLATION","reason":"Property \"Value\" on Assign must be a child element, not an attribute","classifiedCheck":"CATALOG_STRUCTURAL_VIOLATION","developerAction":"Fix property syntax for activity in Main.xaml — move attribute to child-element or vice versa per UiPath catalog","estimatedEffortMinutes":15}
- {"level":"validation-finding","file":"GetTransactionData.xaml","remediationCode":"STUB_ACTIVITY_CATALOG_VIOLATION","reason":"Property \"To\" on Assign must be a child element, not an attribute","classifiedCheck":"CATALOG_STRUCTURAL_VIOLATION","developerAction":"Fix property syntax for activity in GetTransactionData.xaml — move attribute to child-element or vice versa per UiPath catalog","estimatedEffortMinutes":15}
- {"level":"validation-finding","file":"GetTransactionData.xaml","remediationCode":"STUB_ACTIVITY_CATALOG_VIOLATION","reason":"Property \"Value\" on Assign must be a child element, not an attribute","classifiedCheck":"CATALOG_STRUCTURAL_VIOLATION","developerAction":"Fix property syntax for activity in GetTransactionData.xaml — move attribute to child-element or vice versa per UiPath catalog","estimatedEffortMinutes":15}
- {"level":"validation-finding","file":"Init.xaml","remediationCode":"STUB_ACTIVITY_CATALOG_VIOLATION","reason":"Property \"To\" on Assign must be a child element, not an attribute","classifiedCheck":"CATALOG_STRUCTURAL_VIOLATION","developerAction":"Fix property syntax for activity in Init.xaml — move attribute to child-element or vice versa per UiPath catalog","estimatedEffortMinutes":15}
- {"level":"validation-finding","file":"Init.xaml","remediationCode":"STUB_ACTIVITY_CATALOG_VIOLATION","reason":"Property \"Value\" on Assign must be a child element, not an attribute","classifiedCheck":"CATALOG_STRUCTURAL_VIOLATION","developerAction":"Fix property syntax for activity in Init.xaml — move attribute to child-element or vice versa per UiPath catalog","estimatedEffortMinutes":15}
- {"level":"validation-finding","file":"Init.xaml","remediationCode":"STUB_ACTIVITY_CATALOG_VIOLATION","reason":"Property \"Exception\" on Throw must be a child element, not an attribute","classifiedCheck":"CATALOG_STRUCTURAL_VIOLATION","developerAction":"Fix property syntax for activity in Init.xaml — move attribute to child-element or vice versa per UiPath catalog","estimatedEffortMinutes":15}
- {"level":"activity","file":"Process.xaml","remediationCode":"UNDECLARED_VARIABLE_MANUAL","reason":"Undeclared variable \"Provide\" — type cannot be auto-inferred (no recognized naming prefix)","classifiedCheck":"UNDECLARED_VARIABLE","developerAction":"Declare variable \"Provide\" in Process.xaml with the appropriate type. Expression context: Provide Data","estimatedEffortMinutes":5}
- {"level":"activity","file":"Process.xaml","remediationCode":"UNDECLARED_VARIABLE_MANUAL","reason":"Undeclared variable \"Data\" — type cannot be auto-inferred (no recognized naming prefix)","classifiedCheck":"UNDECLARED_VARIABLE","developerAction":"Declare variable \"Data\" in Process.xaml with the appropriate type. Expression context: Provide Data","estimatedEffortMinutes":5}
- {"level":"activity","file":"Process.xaml","remediationCode":"UNDECLARED_VARIABLE_MANUAL","reason":"Undeclared variable \"Approved\" — type cannot be auto-inferred (no recognized naming prefix)","classifiedCheck":"UNDECLARED_VARIABLE","developerAction":"Declare variable \"Approved\" in Process.xaml with the appropriate type. Expression context: Approved","estimatedEffortMinutes":5}
- {"level":"activity","file":"","remediationCode":"POST_ASSEMBLY_REPAIR","reason":"[MISSING_REQUIRED_PROPERTY_DEFECT] uexcel:ExcelApplicationScope.ExistingWorkbook has no valid source binding and no contract-valid fallback — structured defect, property left absent","classifiedCheck":"post-assembly-repair","developerAction":"uexcel:ExcelApplicationScope.ExistingWorkbook has no valid source binding and no contract-valid fallback — structured defect, property left absent","estimatedEffortMinutes":5}
- {"level":"activity","file":"","remediationCode":"POST_ASSEMBLY_REPAIR","reason":"[MISSING_REQUIRED_PROPERTY_DEFECT] uexcel:ExcelApplicationScope.ExistingWorkbook has no valid source binding and no contract-valid fallback — structured defect, property left absent","classifiedCheck":"post-assembly-repair","developerAction":"uexcel:ExcelApplicationScope.ExistingWorkbook has no valid source binding and no contract-valid fallback — structured defect, property left absent","estimatedEffortMinutes":5}
- {"level":"workflow","file":"InitAllSettings.xaml","remediationCode":"STUB_WORKFLOW_BLOCKING","reason":"Pre-archive assertion: malformed_attribute_quoting — Malformed attribute quoting detected: AssetName=\"[&quot;Coupa_IRV2_Credentials&quot;]","classifiedCheck":"pre-archive-canonicalization","developerAction":"Resolve malformed_attribute_quoting in InitAllSettings.xaml","estimatedEffortMinutes":10}

## Auto-Repairs

- {"repairCode":"REPAIR_PLACEHOLDER_CLEANUP","file":"Process.xaml","description":"Stripped 4 placeholder token(s) from Process.xaml","developerAction":"Review Process.xaml for Comment elements marking where placeholder activities were removed","estimatedEffortMinutes":5}
- {"repairCode":"REPAIR_GENERIC","file":"InitAllSettings.xaml","description":"Catalog (DOM): move-to-child-element uexcel:ExcelReadRange.DataTable in InitAllSettings.xaml"}
- {"repairCode":"REPAIR_GENERIC","file":"InitAllSettings.xaml","description":"Catalog (DOM): move-to-child-element uexcel:ExcelReadRange.DataTable in InitAllSettings.xaml"}
- {"repairCode":"REPAIR_GENERIC","file":"InitAllSettings.xaml","description":"Catalog (DOM): move-to-child-element ForEach.Values in InitAllSettings.xaml"}
- {"repairCode":"REPAIR_GENERIC","file":"InitAllSettings.xaml","description":"Catalog (DOM): move-to-child-element ui:GetCredential.Username in InitAllSettings.xaml"}
- {"repairCode":"REPAIR_GENERIC","file":"InitAllSettings.xaml","description":"Catalog (DOM): move-to-child-element ui:GetCredential.Password in InitAllSettings.xaml"}
- {"repairCode":"REPAIR_GENERIC","file":"InitAllSettings.xaml","description":"Catalog (DOM): move-to-child-element ForEach.Values in InitAllSettings.xaml"}
- {"repairCode":"REPAIR_GENERIC","file":"GetTransactionData.xaml","description":"Catalog (DOM): move-to-child-element ui:GetTransactionItem.QueueName in GetTransactionData.xaml"}
- {"repairCode":"REPAIR_TYPE_MISMATCH","file":"Main.xaml","description":"No known conversion from scg:Dictionary(x:String, x:Object) to System.Collections.Generic.Dictionary`<System.String, System.Activities.Argument> — review the variable type or activity property"}
- {"repairCode":"REPAIR_TYPE_MISMATCH","file":"Main.xaml","description":"No known conversion from UiPath.Core.QueueItem to System.Collections.Generic.Dictionary`<System.String, System.Activities.Argument> — review the variable type or activity property"}
- {"repairCode":"REPAIR_TYPE_MISMATCH","file":"Init.xaml","description":"No known conversion from scg:Dictionary(x:String, x:Object) to System.Collections.Generic.Dictionary`<System.String, System.Activities.Argument> — review the variable type or activity property"}
