# Developer Handoff Guide

**Project:** CoupaInvoiceReconV2
**Generated:** 2026-04-09
**Generation Mode:** Baseline Openable (minimal, deterministic)
**Deployment Readiness:** Mostly Ready (66%)

**14 workflows: 5 fully generated, 1 with handoff blocks, 8 workflow-level stubs**
**Total Estimated Effort: ~430 minutes (7.2 hours)**
**Remediations:** 33 total (0 property, 5 activity, 0 sequence, 0 structural-leaf, 8 workflow)
**Auto-Repairs:** 11
**Quality Warnings:** 41

---

### Per-Workflow Preservation Summary

| # | Workflow | Tier | Business Steps (SDD) | Preserved | Degraded (Handoff) | Manual | Bind Points |
|---|----------|------|-------------|-----------|-------------------|--------|-------------|
| 1 | `CoupaSessionManager.xaml` | Stub | 1 | 0 | 0 | 1 | 0 |
| 2 | `Dispatcher.xaml` | Stub | 1 | 0 | 0 | 1 | 0 |
| 3 | `InitPerformer.xaml` | Stub | 1 | 0 | 0 | 1 | 0 |
| 4 | `ProcessInvoice.xaml` | Stub | 1 | 0 | 0 | 1 | 0 |
| 5 | `ActionCenterTaskCreator.xaml` | Stub | 1 | 0 | 0 | 1 | 0 |
| 6 | `ActionCenterCallbackHandler.xaml` | Stub | 1 | 0 | 0 | 1 | 0 |
| 7 | `Main.xaml` | Stub | 1 | 0 | 0 | 1 | 0 |
| 8 | `Process.xaml` | Handoff | 1 | 0 | 3 | 3 | 0 |
| 9 | `InitAllSettings.xaml` | Stub | 1 | 0 | 0 | 1 | 0 |
| 10 | `GetTransactionData.xaml` | Generated | 1 | 1 | 0 | 0 | 0 |
| 11 | `SetTransactionStatus.xaml` | Generated | 1 | 1 | 0 | 0 | 0 |
| 12 | `CloseAllApplications.xaml` | Generated | 1 | 1 | 0 | 0 | 0 |
| 13 | `KillAllProcesses.xaml` | Generated | 1 | 1 | 0 | 0 | 0 |
| 14 | `Init.xaml` | Generated | 1 | 1 | 0 | 0 | 0 |

## 1. Generated Logic (ready to use)

Generated XAML that is Studio-openable and does not contain handoff blocks or workflow-level stubs. May include auto-resolved property remediations or placeholders for fine-tuning.

The following 5 workflow(s) were fully generated and are ready to use:

| # | Workflow | Status | Studio Compatibility |
|---|----------|--------|---------------------|
| 1 | `GetTransactionData.xaml` | Generated with Remediations | Studio-openable |
| 2 | `SetTransactionStatus.xaml` | Fully Generated | Studio-openable |
| 3 | `CloseAllApplications.xaml` | Fully Generated | Studio-openable |
| 4 | `KillAllProcesses.xaml` | Fully Generated | Studio-openable |
| 5 | `Init.xaml` | Generated with Remediations | Openable with warnings |

### AI-Resolved with Smart Defaults (11)

The following issue(s) were automatically corrected during the build pipeline. **No developer action required.**

| # | Code | File | Description | Est. Minutes Saved |
|---|------|------|-------------|-------------------|
| 1 | `REPAIR_PLACEHOLDER_CLEANUP` | `Process.xaml` | Stripped 4 placeholder token(s) from Process.xaml | 5 |
| 2 | `REPAIR_GENERIC` | `InitAllSettings.xaml` | Catalog (DOM): move-to-child-element uexcel:ExcelReadRange.DataTable in InitAllSettings.xaml | undefined |
| 3 | `REPAIR_GENERIC` | `InitAllSettings.xaml` | Catalog (DOM): move-to-child-element uexcel:ExcelReadRange.DataTable in InitAllSettings.xaml | undefined |
| 4 | `REPAIR_GENERIC` | `InitAllSettings.xaml` | Catalog (DOM): move-to-child-element ForEach.Values in InitAllSettings.xaml | undefined |
| 5 | `REPAIR_GENERIC` | `InitAllSettings.xaml` | Catalog (DOM): move-to-child-element ui:GetCredential.Username in InitAllSettings.xaml | undefined |
| 6 | `REPAIR_GENERIC` | `InitAllSettings.xaml` | Catalog (DOM): move-to-child-element ui:GetCredential.Password in InitAllSettings.xaml | undefined |
| 7 | `REPAIR_GENERIC` | `InitAllSettings.xaml` | Catalog (DOM): move-to-child-element ForEach.Values in InitAllSettings.xaml | undefined |
| 8 | `REPAIR_GENERIC` | `GetTransactionData.xaml` | Catalog (DOM): move-to-child-element ui:GetTransactionItem.QueueName in GetTransactionData.xaml | undefined |
| 9 | `REPAIR_TYPE_MISMATCH` | `Main.xaml` | No known conversion from scg:Dictionary(x:String, x:Object) to System.Collections.Generic.Diction... | undefined |
| 10 | `REPAIR_TYPE_MISMATCH` | `Main.xaml` | No known conversion from UiPath.Core.QueueItem to System.Collections.Generic.Dictionary`<System.S... | undefined |
| 11 | `REPAIR_TYPE_MISMATCH` | `Init.xaml` | No known conversion from scg:Dictionary(x:String, x:Object) to System.Collections.Generic.Diction... | undefined |

### Studio Compatibility

| # | Workflow | Compatibility | Failure Category | Blockers |
|---|----------|--------------|-----------------|----------|
| 1 | `CoupaSessionManager.xaml` | Studio-openable | — | — |
| 2 | `Dispatcher.xaml` | Studio-openable | — | — |
| 3 | `InitPerformer.xaml` | Studio-openable | — | — |
| 4 | `ProcessInvoice.xaml` | Studio-openable | — | — |
| 5 | `ActionCenterTaskCreator.xaml` | Studio-openable | — | — |
| 6 | `ActionCenterCallbackHandler.xaml` | Studio-openable | — | — |
| 7 | `Main.xaml` | Openable with warnings | Unclassified | — |
| 8 | `Process.xaml` | Openable with warnings | Unclassified | — |
| 9 | `InitAllSettings.xaml` | Openable with warnings | Unclassified | — |
| 10 | `GetTransactionData.xaml` | Studio-openable | — | — |
| 11 | `SetTransactionStatus.xaml` | Studio-openable | — | — |
| 12 | `CloseAllApplications.xaml` | Studio-openable | — | — |
| 13 | `KillAllProcesses.xaml` | Studio-openable | — | — |
| 14 | `Init.xaml` | Openable with warnings | Unclassified | — |

**Summary:** 10 Studio-loadable, 4 with warnings, 0 not Studio-loadable

## 2. Handoff Blocks (business logic preserved, implementation required)

Blocks where business logic is preserved as documentation but implementation requires manual Studio work. Each entry includes the workflow file, block type, business description from the SDD (when available), expected inputs/outputs, and the developer action required.

**5 handoff block(s) requiring manual implementation**

#### 1. `Process.xaml` — — (activity)

- **Workflow File:** `Process.xaml`
- **Block Type:** activity
- **Business Description (SDD):** —
- **Business Rule:** —
- **Expected Inputs:** —
- **Expected Outputs:** —
- **Contained Activities:** —
- **Remediation Code:** `UNDECLARED_VARIABLE_MANUAL`
- **Developer Action:** Declare variable "Provide" in Process.xaml with the appropriate type. Expression context: Provide Data
- **Estimated Effort:** 5 minutes

#### 2. `Process.xaml` — — (activity)

- **Workflow File:** `Process.xaml`
- **Block Type:** activity
- **Business Description (SDD):** —
- **Business Rule:** —
- **Expected Inputs:** —
- **Expected Outputs:** —
- **Contained Activities:** —
- **Remediation Code:** `UNDECLARED_VARIABLE_MANUAL`
- **Developer Action:** Declare variable "Data" in Process.xaml with the appropriate type. Expression context: Provide Data
- **Estimated Effort:** 5 minutes

#### 3. `Process.xaml` — — (activity)

- **Workflow File:** `Process.xaml`
- **Block Type:** activity
- **Business Description (SDD):** —
- **Business Rule:** —
- **Expected Inputs:** —
- **Expected Outputs:** —
- **Contained Activities:** —
- **Remediation Code:** `UNDECLARED_VARIABLE_MANUAL`
- **Developer Action:** Declare variable "Approved" in Process.xaml with the appropriate type. Expression context: Approved
- **Estimated Effort:** 5 minutes

#### 4. `` — — (activity)

- **Workflow File:** ``
- **Block Type:** activity
- **Business Description (SDD):** —
- **Business Rule:** —
- **Expected Inputs:** —
- **Expected Outputs:** —
- **Contained Activities:** —
- **Remediation Code:** `POST_ASSEMBLY_REPAIR`
- **Developer Action:** uexcel:ExcelApplicationScope.ExistingWorkbook has no valid source binding and no contract-valid fallback — structured defect, property left absent
- **Estimated Effort:** 5 minutes

#### 5. `` — — (activity)

- **Workflow File:** ``
- **Block Type:** activity
- **Business Description (SDD):** —
- **Business Rule:** —
- **Expected Inputs:** —
- **Expected Outputs:** —
- **Contained Activities:** —
- **Remediation Code:** `POST_ASSEMBLY_REPAIR`
- **Developer Action:** uexcel:ExcelApplicationScope.ExistingWorkbook has no valid source binding and no contract-valid fallback — structured defect, property left absent
- **Estimated Effort:** 5 minutes

## 3. Manual Work Remaining

Consolidated developer TODO list organized by workflow, with estimated effort per item.

**74 items remaining — ~840 minutes (14.0 hours) total estimated effort**

### ActionCenterCallbackHandler.xaml (2 items, ~25 min)

| # | Priority | Category | Description | Developer Action | Est. Minutes |
|---|----------|----------|-------------|-----------------|-------------|
| 1 | High | Workflow Stub | Entire workflow `ActionCenterCallbackHandler.xaml` replaced with Studio-opena... | TODO: Implement ActionCenterCallbackHandler — review SDD for workflow require... | 15 |
| 2 | Low | Implementation Required | Contains 1 placeholder value(s) matching "\bPLACEHOLDER\b" [Developer Impleme... | Implement in Studio | 10 |

### ActionCenterTaskCreator.xaml (2 items, ~25 min)

| # | Priority | Category | Description | Developer Action | Est. Minutes |
|---|----------|----------|-------------|-----------------|-------------|
| 3 | High | Workflow Stub | Entire workflow `ActionCenterTaskCreator.xaml` replaced with Studio-openable ... | TODO: Implement ActionCenterTaskCreator — review SDD for workflow requirements | 15 |
| 4 | Low | Implementation Required | Contains 1 placeholder value(s) matching "\bPLACEHOLDER\b" [Developer Impleme... | Implement in Studio | 10 |

### CoupaSessionManager.xaml (2 items, ~25 min)

| # | Priority | Category | Description | Developer Action | Est. Minutes |
|---|----------|----------|-------------|-----------------|-------------|
| 5 | High | Workflow Stub | Entire workflow `CoupaSessionManager.xaml` replaced with Studio-openable stub | TODO: Implement CoupaSessionManager — review SDD for workflow requirements | 15 |
| 6 | Low | Implementation Required | Contains 1 placeholder value(s) matching "\bPLACEHOLDER\b" [Developer Impleme... | Implement in Studio | 10 |

### Dispatcher.xaml (2 items, ~25 min)

| # | Priority | Category | Description | Developer Action | Est. Minutes |
|---|----------|----------|-------------|-----------------|-------------|
| 7 | High | Workflow Stub | Entire workflow `Dispatcher.xaml` replaced with Studio-openable stub | TODO: Implement Dispatcher — review SDD for workflow requirements | 15 |
| 8 | Low | Implementation Required | Contains 1 placeholder value(s) matching "\bPLACEHOLDER\b" [Developer Impleme... | Implement in Studio | 10 |

### InitAllSettings.xaml (30 items, ~325 min)

| # | Priority | Category | Description | Developer Action | Est. Minutes |
|---|----------|----------|-------------|-----------------|-------------|
| 9 | High | Workflow Stub | Entire workflow `InitAllSettings.xaml` replaced with Studio-openable stub | Resolve malformed_attribute_quoting in InitAllSettings.xaml | 10 |
| 10 | Low | Validation Finding | Quality gate finding: `MISSING_REQUIRED_ACTIVITY_PROPERTY` | Manually implement activity in InitAllSettings.xaml — estimated 15 min | 15 |
| 11 | Low | Validation Finding | Quality gate finding: `MISSING_REQUIRED_ACTIVITY_PROPERTY` | Manually implement activity in InitAllSettings.xaml — estimated 15 min | 15 |
| 12 | Low | Validation Finding | Quality gate finding: `CATALOG_STRUCTURAL_VIOLATION` | Fix property syntax for activity in InitAllSettings.xaml — move attribute to ... | 15 |
| 13 | Low | Validation Finding | Quality gate finding: `CATALOG_STRUCTURAL_VIOLATION` | Fix property syntax for activity in InitAllSettings.xaml — move attribute to ... | 15 |
| 14 | Low | Validation Finding | Quality gate finding: `CATALOG_STRUCTURAL_VIOLATION` | Fix property syntax for activity in InitAllSettings.xaml — move attribute to ... | 15 |
| 15 | Low | Quality Warning | missing-package-dep: Activity "ui:GetCredential" requires package "UiPath.Cre... | Review and address | 10 |
| 16 | Low | Quality Warning | invalid-activity-property: Line 274: property "AssetName" is not a known prop... | Review and address | 10 |
| 17 | Low | Quality Warning | invalid-type-argument: Line 190: x:TypeArguments="uexcel:DataTable" may not b... | Review and address | 10 |
| 18 | Low | Quality Warning | invalid-type-argument: Line 197: x:TypeArguments="uexcel:DataTable" may not b... | Review and address | 10 |
| 19 | Low | Quality Warning | hardcoded-asset-name: Line 274: asset name "Coupa_IRV2_Credentials" is hardco... | Review and address | 10 |
| 20 | Low | Quality Warning | hardcoded-asset-name: Line 300: asset name "Coupa_IRV2_BaseUrl" is hardcoded ... | Review and address | 10 |
| 21 | Low | Quality Warning | hardcoded-asset-name: Line 331: asset name "Coupa_IRV2_TolerancePercent" is h... | Review and address | 10 |
| 22 | Low | Quality Warning | hardcoded-asset-name: Line 362: asset name "Coupa_IRV2_RejectComment_POMismat... | Review and address | 10 |
| 23 | Low | Quality Warning | hardcoded-asset-name: Line 393: asset name "Coupa_IRV2_RejectComment_OutOfTol... | Review and address | 10 |
| 24 | Low | Quality Warning | hardcoded-asset-name: Line 424: asset name "Coupa_IRV2_RejectComment_Insuffic... | Review and address | 10 |
| 25 | Low | Quality Warning | hardcoded-asset-name: Line 455: asset name "Coupa_IRV2_MaxTransactionSeconds"... | Review and address | 10 |
| 26 | Low | Quality Warning | hardcoded-asset-name: Line 486: asset name "Coupa_IRV2_MaxConsecutiveSystemFa... | Review and address | 10 |
| 27 | Low | Quality Warning | hardcoded-asset-name: Line 517: asset name "Coupa_IRV2_EnableEvidenceSnapshot... | Review and address | 10 |
| 28 | Low | Quality Warning | BARE_TOKEN_QUOTED: Auto-quoted bare token "Settings" for uexcel:ExcelReadRang... | Review and address | 10 |
| 29 | Low | Quality Warning | BARE_TOKEN_QUOTED: Auto-quoted bare token "Constants" for uexcel:ExcelReadRan... | Review and address | 10 |
| 30 | Low | Quality Warning | BARE_TOKEN_QUOTED: Auto-quoted bare token "Coupa_IRV2_Credentials" for ui:Get... | Review and address | 10 |
| 31 | Low | Quality Warning | BARE_TOKEN_QUOTED: Auto-quoted bare token "Coupa_IRV2_BaseUrl" for ui:GetAsse... | Review and address | 10 |
| 32 | Low | Quality Warning | BARE_TOKEN_QUOTED: Auto-quoted bare token "Coupa_IRV2_TolerancePercent" for u... | Review and address | 10 |
| 33 | Low | Quality Warning | BARE_TOKEN_QUOTED: Auto-quoted bare token "Coupa_IRV2_RejectComment_POMismatc... | Review and address | 10 |
| 34 | Low | Quality Warning | BARE_TOKEN_QUOTED: Auto-quoted bare token "Coupa_IRV2_RejectComment_OutOfTole... | Review and address | 10 |
| 35 | Low | Quality Warning | BARE_TOKEN_QUOTED: Auto-quoted bare token "Coupa_IRV2_RejectComment_Insuffici... | Review and address | 10 |
| 36 | Low | Quality Warning | BARE_TOKEN_QUOTED: Auto-quoted bare token "Coupa_IRV2_MaxTransactionSeconds" ... | Review and address | 10 |
| 37 | Low | Quality Warning | BARE_TOKEN_QUOTED: Auto-quoted bare token "Coupa_IRV2_MaxConsecutiveSystemFai... | Review and address | 10 |
| 38 | Low | Quality Warning | BARE_TOKEN_QUOTED: Auto-quoted bare token "Coupa_IRV2_EnableEvidenceSnapshots... | Review and address | 10 |

### InitPerformer.xaml (2 items, ~25 min)

| # | Priority | Category | Description | Developer Action | Est. Minutes |
|---|----------|----------|-------------|-----------------|-------------|
| 39 | High | Workflow Stub | Entire workflow `InitPerformer.xaml` replaced with Studio-openable stub | TODO: Implement InitPerformer — review SDD for workflow requirements | 15 |
| 40 | Low | Implementation Required | Contains 1 placeholder value(s) matching "\bPLACEHOLDER\b" [Developer Impleme... | Implement in Studio | 10 |

### Main.xaml (5 items, ~65 min)

| # | Priority | Category | Description | Developer Action | Est. Minutes |
|---|----------|----------|-------------|-----------------|-------------|
| 41 | High | Workflow Stub | Entire workflow `Main.xaml` replaced with Studio-openable stub | TODO: Implement Main — review SDD for workflow requirements | 15 |
| 42 | Low | Validation Finding | Quality gate finding: `CATALOG_STRUCTURAL_VIOLATION` | Fix property syntax for activity in Main.xaml — move attribute to child-eleme... | 15 |
| 43 | Low | Validation Finding | Quality gate finding: `CATALOG_STRUCTURAL_VIOLATION` | Fix property syntax for activity in Main.xaml — move attribute to child-eleme... | 15 |
| 44 | Low | Quality Warning | TYPE_MISMATCH: Line 81: Type mismatch — variable "dict_Config" (scg:Dictionar... | Review and address | 10 |
| 45 | Low | Quality Warning | TYPE_MISMATCH: Line 134: Type mismatch — variable "qi_TransactionItem" (UiPat... | Review and address | 10 |

### ProcessInvoice.xaml (2 items, ~25 min)

| # | Priority | Category | Description | Developer Action | Est. Minutes |
|---|----------|----------|-------------|-----------------|-------------|
| 46 | High | Workflow Stub | Entire workflow `ProcessInvoice.xaml` replaced with Studio-openable stub | TODO: Implement ProcessInvoice — review SDD for workflow requirements | 15 |
| 47 | Low | Implementation Required | Contains 1 placeholder value(s) matching "\bPLACEHOLDER\b" [Developer Impleme... | Implement in Studio | 10 |

### Process.xaml (16 items, ~175 min)

| # | Priority | Category | Description | Developer Action | Est. Minutes |
|---|----------|----------|-------------|-----------------|-------------|
| 48 | Medium | Activity Stub | Activity "unknown" stubbed | Declare variable "Provide" in Process.xaml with the appropriate type. Express... | 5 |
| 49 | Medium | Activity Stub | Activity "unknown" stubbed | Declare variable "Data" in Process.xaml with the appropriate type. Expression... | 5 |
| 50 | Medium | Activity Stub | Activity "unknown" stubbed | Declare variable "Approved" in Process.xaml with the appropriate type. Expres... | 5 |
| 51 | Low | Validation Finding | Quality gate finding: `UNDECLARED_VARIABLE` | Manually implement activity in Process.xaml — estimated 15 min | 15 |
| 52 | Low | Validation Finding | Quality gate finding: `UNDECLARED_VARIABLE` | Manually implement activity in Process.xaml — estimated 15 min | 15 |
| 53 | Low | Validation Finding | Quality gate finding: `EXPRESSION_SYNTAX_UNFIXABLE` | Manually implement activity in Process.xaml — estimated 15 min | 15 |
| 54 | Low | Validation Finding | Quality gate finding: `UNDECLARED_VARIABLE` | Manually implement activity in Process.xaml — estimated 15 min | 15 |
| 55 | Low | Validation Finding | Quality gate finding: `MISSING_TEXT_EXPRESSION_NAMESPACES` | Manually implement activity in Process.xaml — estimated 15 min | 15 |
| 56 | Low | Validation Finding | Quality gate finding: `MISSING_TEXT_EXPRESSION_REFERENCES` | Manually implement activity in Process.xaml — estimated 15 min | 15 |
| 57 | Low | Validation Finding | Quality gate finding: `CATALOG_STRUCTURAL_VIOLATION` | Fix property syntax for activity in Process.xaml — move attribute to child-el... | 15 |
| 58 | Low | Validation Finding | Quality gate finding: `ENUM_VIOLATION` | Fix enum value for activity in Process.xaml — use valid enum from UiPath docu... | 5 |
| 59 | Low | Implementation Required | Contains 2 placeholder value(s) matching "\bTODO\b" [Developer Implementation... | Implement in Studio | 10 |
| 60 | Low | Quality Warning | invalid-type-argument: Line 22: x:TypeArguments="UiPath.Persistence.Activitie... | Review and address | 10 |
| 61 | Low | Quality Warning | EXPRESSION_SYNTAX: Line 42: Standalone "Yes" corrected to "True" in expressio... | Review and address | 10 |
| 62 | Low | Quality Warning | EXPRESSION_SYNTAX: Line 123: Standalone "Yes" corrected to "True" in expressi... | Review and address | 10 |
| 63 | Low | Quality Warning | EXPRESSION_SYNTAX: Line 142: Standalone "Yes" corrected to "True" in expressi... | Review and address | 10 |

### Unknown.xaml (2 items, ~10 min)

| # | Priority | Category | Description | Developer Action | Est. Minutes |
|---|----------|----------|-------------|-----------------|-------------|
| 64 | Medium | Activity Stub | Activity "unknown" stubbed | uexcel:ExcelApplicationScope.ExistingWorkbook has no valid source binding and... | 5 |
| 65 | Medium | Activity Stub | Activity "unknown" stubbed | uexcel:ExcelApplicationScope.ExistingWorkbook has no valid source binding and... | 5 |

### GetTransactionData.xaml (2 items, ~30 min)

| # | Priority | Category | Description | Developer Action | Est. Minutes |
|---|----------|----------|-------------|-----------------|-------------|
| 66 | Low | Validation Finding | Quality gate finding: `CATALOG_STRUCTURAL_VIOLATION` | Fix property syntax for activity in GetTransactionData.xaml — move attribute ... | 15 |
| 67 | Low | Validation Finding | Quality gate finding: `CATALOG_STRUCTURAL_VIOLATION` | Fix property syntax for activity in GetTransactionData.xaml — move attribute ... | 15 |

### Init.xaml (4 items, ~55 min)

| # | Priority | Category | Description | Developer Action | Est. Minutes |
|---|----------|----------|-------------|-----------------|-------------|
| 68 | Low | Validation Finding | Quality gate finding: `CATALOG_STRUCTURAL_VIOLATION` | Fix property syntax for activity in Init.xaml — move attribute to child-eleme... | 15 |
| 69 | Low | Validation Finding | Quality gate finding: `CATALOG_STRUCTURAL_VIOLATION` | Fix property syntax for activity in Init.xaml — move attribute to child-eleme... | 15 |
| 70 | Low | Validation Finding | Quality gate finding: `CATALOG_STRUCTURAL_VIOLATION` | Fix property syntax for activity in Init.xaml — move attribute to child-eleme... | 15 |
| 71 | Low | Quality Warning | TYPE_MISMATCH: Line 68: Type mismatch — variable "dict_Config" (scg:Dictionar... | Review and address | 10 |

### KillAllProcesses.xaml (3 items, ~30 min)

| # | Priority | Category | Description | Developer Action | Est. Minutes |
|---|----------|----------|-------------|-----------------|-------------|
| 72 | Low | Quality Warning | BARE_TOKEN_QUOTED: Auto-quoted bare token "chrome" for ui:KillProcess.Process... | Review and address | 10 |
| 73 | Low | Quality Warning | BARE_TOKEN_QUOTED: Auto-quoted bare token "iexplore" for ui:KillProcess.Proce... | Review and address | 10 |
| 74 | Low | Quality Warning | BARE_TOKEN_QUOTED: Auto-quoted bare token "EXCEL" for ui:KillProcess.ProcessN... | Review and address | 10 |

## 4. Process Context (from Pipeline)

### Idea Description

Test recon

### PDD Summary

## 1. Executive Summary  
The “PO and invoice reconciliationV2” project will automate the first-pass validation and routing of vendor-submitted invoices in Coupa. Today, the AP Clerk/Approver manually opens each invoice, verifies that the invoice PO number matches the Coupa PO, checks that the invoice amount is within a 5% tolerance of the PO amount, and then routes matched invoices into Coupa’s Delegation of Authority (DOA) approval chain. Any invoice failing these checks is rejected in Coupa with a free-text rejection comment; Coupa then automatically notifies the supplier, and the supplier resubmits a corrected invoice as a new submission. The process occurs ~50 times per day and averages ~10 minutes per invoice.  

The future state will use UiPath Orchestrator triggers to detect newly submitted Coupa invoices, retrieve structured header data already surfaced by Coupa (PO number, amount, supplier), perform automated validations, and either route invoices for DOA approval or reject them in Coupa with standardized free-text comments. Action Center will be used only for exception handling when required data is missing or ambiguous. The automation is designed for fully unattended execution, aligned with the available robot landscape (11 unattended robots) and the requirement that approvals/rejections and supplier notifications remain managed within Coupa.

## 2. Process Scope  
This PDD covers invoice intake-to-disposition for vendor invoices submitted directly in Coupa as PDFs, where Coupa already surfaces PO number and amount as structured fields in its interface. The process begins when a vendor submits an invoice in Coupa and ends when either (a) the invoice is routed into and progressed by the Coupa DOA approval chain to the next stage, or (b) the invoice is rejected in Coupa (triggering Coupa’s built-in supplier notification). Resubmissions are explicitly treated as new invoice submissions and will re-enter the process from the start.

Out of scope are: three-w...

### SDD Summary

## 1. Automation Architecture Overview

### 1.1 Chosen automation type and rationale
[AUTOMATION_TYPE: RPA (Unattended) + HITL (Action Center exceptions)]

- **Primary path is deterministic and rules-based** (PO exists/match; invoice amount within ±5% tolerance; route to DOA), which is best served by **unattended RPA**.
- **Human-in-the-loop is only needed** when Coupa’s structured header fields are **missing/invalid/ambiguous** or when Coupa/UI/API behavior is inconsistent (rare but operationally critical). This is implemented via **Action Center**, not attended robots (none available).
- **Agents** are not used in the critical path because the decisioning is explicit and auditable. Agents may be introduced later for non-critical enrichment (see Platform Recommendations).

### 1.2 Architecture pattern
**Queue-driven dispatcher/performer with REFramework-style robustness**:
- **Trigger** detects/receives “new invoice submitted” events and creates **Queue Items** (one per invoice).
- **Performer** processes queue items with retries, idempotency controls, and standardized exception handling.
- **Action Center** is invoked only for exceptions (missing data / ambiguity), enabling full unattended execution.

This is intentionally chosen over a single monolithic workflow because it:
- Provides **natural scaling** across **11 unattended slots**.
- Gives **retry semantics** and operational visibility per invoice via Queue analytics.
- Simplifies **SLA management** and dead-letter handling.

### 1.3 UiPath services used and why
- **Orchestrator (Queues, Assets, Triggers, Logs, Processes):** Core orchestration, scaling, retries, centralized audit.
- **Triggers:** Queue Trigger to auto-start performer jobs and/or invoke dispatcher on schedule/webhook.
- **Action Center:** Exception tasks for “missing/invalid data” with due dates/escalations.
- **Data Service (Data Fabric):** Persistent, queryable record of invoice decisions, exceptions, and outcomes across runs (for audit, rep...

**Automation Type:** rpa
**Rationale:** The inputs (PO number, amounts) are already structured in Coupa and the decisions are deterministic (match + 5% tolerance + DOA-driven routing), so a rules-based unattended RPA with minimal human-in-the-loop is the best fit.
**Feasibility Complexity:** medium
**Effort Estimate:** 2-4 weeks

## 5. Business Process Overview

### Process Steps

| # | Step | Role | System | Type | Pain Point |
|---|------|------|--------|------|------------|
| 1 | Invoice Submitted in Coupa | Vendor | Coupa | start | — |
| 2 | Ingest New Invoice Event | System | Orchestrator/Triggers | task | — |
| 3 | Get Invoice Header Data (PO, amount, supplier) | System | Coupa | task | — |
| 4 | Invoice Data Complete? | System | Coupa | decision | — |
| 5 | Validate PO Exists in Coupa | System | Coupa | task | — |
| 6 | Route to AP Exception Review (missing data) | AP Clerk/Approver | Action Center | task | — |
| 7 | AP Provides Missing Data / Confirms Rejection | AP Clerk/Approver | Action Center | decision | — |
| 8 | Update Invoice Data in Coupa | System | Coupa | task | — |
| 9 | Reject Invoice in Coupa (insufficient data) | System | Coupa | task | — |
| 10 | PO Match Successful? | System | Coupa | decision | — |
| 11 | Calculate Amount Variance vs PO | System | Coupa | task | — |
| 12 | Reject Invoice in Coupa (PO mismatch) | System | Coupa | task | — |
| 13 | Amount Within 5% Tolerance? | System | Coupa | decision | — |
| 14 | Route Invoice for Approval (per DOA) | System | Coupa | task | — |
| 15 | Approved in Coupa (DOA chain outcome) | AP Clerk/Approver | Coupa | decision | — |
| 16 | Invoice Progressed to Next Stage End | System | Coupa | end | — |
| 17 | Reject Invoice in Coupa (DOA rejected) | AP Clerk/Approver | Coupa | task | — |
| 18 | Reject Invoice in Coupa (out of tolerance) | System | Coupa | task | — |
| 19 | Coupa Sends Rejection Notification to Supplier | System | Coupa | task | — |
| 20 | Invoice Rejected End | System | Coupa | end | — |

### Target Applications / Systems

The following applications were identified from the process map and must be accessible from the robot machine:

- Coupa
- Orchestrator/Triggers
- Action Center

### User Roles Involved

- Vendor
- System
- AP Clerk/Approver

### Decision Points (Process Map Topology)

**Invoice Data Complete?**
  - [Yes] → Validate PO Exists in Coupa
  - [No] → Route to AP Exception Review (missing data)

**AP Provides Missing Data / Confirms Rejection**
  - [Provide Data] → Update Invoice Data in Coupa
  - [Reject] → Reject Invoice in Coupa (insufficient data)

**PO Match Successful?**
  - [Yes] → Calculate Amount Variance vs PO
  - [No] → Reject Invoice in Coupa (PO mismatch)

**Amount Within 5% Tolerance?**
  - [Yes] → Route Invoice for Approval (per DOA)
  - [No] → Reject Invoice in Coupa (out of tolerance)

**Approved in Coupa (DOA chain outcome)**
  - [Approved] → Invoice Progressed to Next Stage End
  - [Rejected] → Reject Invoice in Coupa (DOA rejected)

## 6. Environment Setup

| Requirement | Value |
|---|---|
| Target Framework | Windows (required) |
| Robot Type | Unattended |
| Modern Activities | No |
| Studio Version | 25.10.7 |
| Orchestrator Connection | Required |
| Machine Template | Standard |
| Action Center | Required |

### Machine Template

**Recommended:** Standard
Standard unattended machine template

### Orchestrator Folder Structure

Create a Modern Folder with unattended robot pool (2+ robots recommended for queue-based processing). Enable Auto-scaling if available.

### NuGet Dependencies

| # | Package |
|---|--------|
| 1 | `UiPath.System.Activities` |
| 2 | `UiPath.UIAutomation.Activities` |
| 3 | `UiPath.Persistence.Activities` |
| 4 | `UiPath.Excel.Activities` |

### Target Applications (from Process Map)

The following applications were identified from the business process map. Ensure network connectivity and access credentials are configured on the robot machine:

- Coupa
- Orchestrator/Triggers
- Action Center

## 7. Credential & Asset Inventory

**Total:** 19 activities (0 hardcoded, 19 variable-driven)

### Orchestrator Credentials to Provision

| # | Credential Name | Type | Consuming Activity | File | Action |
|---|----------------|------|-------------------|------|--------|
| 1 | `[Coupa_IRV2_Credentials]` | Credential | — | `InitAllSettings.xaml` | Verify exists in target environment |

### Orchestrator Assets to Provision

| # | Asset Name | Value Type | Consuming Activity | File | Action |
|---|-----------|-----------|-------------------|------|--------|
| 1 | `[Coupa_IRV2_BaseUrl]` | Unknown | — | `InitAllSettings.xaml` | Verify exists in target environment |
| 2 | `[Coupa_IRV2_TolerancePercent]` | Unknown | — | `InitAllSettings.xaml` | Verify exists in target environment |
| 3 | `[Coupa_IRV2_RejectComment_POMismatch]` | Unknown | — | `InitAllSettings.xaml` | Verify exists in target environment |
| 4 | `[Coupa_IRV2_RejectComment_OutOfTolerance]` | Unknown | — | `InitAllSettings.xaml` | Verify exists in target environment |
| 5 | `[Coupa_IRV2_RejectComment_InsufficientData]` | Unknown | — | `InitAllSettings.xaml` | Verify exists in target environment |
| 6 | `[Coupa_IRV2_MaxTransactionSeconds]` | Unknown | — | `InitAllSettings.xaml` | Verify exists in target environment |
| 7 | `[Coupa_IRV2_MaxConsecutiveSystemFailures]` | Unknown | — | `InitAllSettings.xaml` | Verify exists in target environment |
| 8 | `[Coupa_IRV2_EnableEvidenceSnapshots]` | Unknown | — | `InitAllSettings.xaml` | Verify exists in target environment |

### Detailed Usage Map

| File | Line | Activity | Asset/Credential | Type | Variable | Hardcoded |
|------|------|----------|-----------------|------|----------|----------|
| `InitAllSettings.xaml` | 276 | GetCredential | `[Coupa_IRV2_Credentials]` | Credential | — | No |
| `InitAllSettings.xaml` | 277 | GetCredential | `UNKNOWN` | Credential | — | No |
| `InitAllSettings.xaml` | 280 | GetCredential | `UNKNOWN` | Credential | — | No |
| `InitAllSettings.xaml` | 302 | GetAsset | `[Coupa_IRV2_BaseUrl]` | Unknown | — | No |
| `InitAllSettings.xaml` | 305 | GetAsset | `UNKNOWN` | Unknown | — | No |
| `InitAllSettings.xaml` | 333 | GetAsset | `[Coupa_IRV2_TolerancePercent]` | Unknown | — | No |
| `InitAllSettings.xaml` | 336 | GetAsset | `UNKNOWN` | Unknown | — | No |
| `InitAllSettings.xaml` | 364 | GetAsset | `[Coupa_IRV2_RejectComment_POMismatch]` | Unknown | — | No |
| `InitAllSettings.xaml` | 367 | GetAsset | `UNKNOWN` | Unknown | — | No |
| `InitAllSettings.xaml` | 395 | GetAsset | `[Coupa_IRV2_RejectComment_OutOfTolerance]` | Unknown | — | No |
| `InitAllSettings.xaml` | 398 | GetAsset | `UNKNOWN` | Unknown | — | No |
| `InitAllSettings.xaml` | 426 | GetAsset | `[Coupa_IRV2_RejectComment_InsufficientData]` | Unknown | — | No |
| `InitAllSettings.xaml` | 429 | GetAsset | `UNKNOWN` | Unknown | — | No |
| `InitAllSettings.xaml` | 457 | GetAsset | `[Coupa_IRV2_MaxTransactionSeconds]` | Unknown | — | No |
| `InitAllSettings.xaml` | 460 | GetAsset | `UNKNOWN` | Unknown | — | No |
| `InitAllSettings.xaml` | 488 | GetAsset | `[Coupa_IRV2_MaxConsecutiveSystemFailures]` | Unknown | — | No |
| `InitAllSettings.xaml` | 491 | GetAsset | `UNKNOWN` | Unknown | — | No |
| `InitAllSettings.xaml` | 519 | GetAsset | `[Coupa_IRV2_EnableEvidenceSnapshots]` | Unknown | — | No |
| `InitAllSettings.xaml` | 522 | GetAsset | `UNKNOWN` | Unknown | — | No |

## 8. SDD × XAML Artifact Reconciliation

**Summary:** 0 aligned, 11 SDD-only, 9 XAML-only

> **Warning:** 11 artifact(s) declared in the SDD were not found in the generated XAML. These must be provisioned in Orchestrator but are not referenced in code — verify the SDD spec or add the corresponding activities.

> **Warning:** 9 artifact(s) found in XAML are not declared in the SDD. Update the SDD orchestrator_artifacts block to include these, or the deployment manifest will be incomplete.

| # | Name | Type | Status | SDD Config | XAML File | XAML Line |
|---|------|------|--------|-----------|----------|----------|
| 1 | `Coupa_IRV2_Credentials` | credential | **SDD Only** | type: Credential, description: Credential for Coupa access used by unattended robot (service account). | — | — |
| 2 | `Coupa_IRV2_BaseUrl` | asset | **SDD Only** | type: Text, value: https://<tenant>.coupahost.com, description: Coupa tenant base URL used to navigate/API-call invoice and PO resources. | — | — |
| 3 | `Coupa_IRV2_TolerancePercent` | asset | **SDD Only** | type: Integer, value: 5, description: Invoice amount tolerance percentage vs PO amount (±). Default 5 per PDD. | — | — |
| 4 | `Coupa_IRV2_RejectComment_POMismatch` | asset | **SDD Only** | type: Text, value: PO mismatch—please resubmit with correct PO number., description: Standardized Coupa rejection comment template for PO mismatch. | — | — |
| 5 | `Coupa_IRV2_RejectComment_OutOfTolerance` | asset | **SDD Only** | type: Text, value: Amount exceeds 5% tolerance vs PO—please correct and resubmit., description: Standardized Coupa rejection comment template for out-of-tolerance invoices. | — | — |
| 6 | `Coupa_IRV2_RejectComment_InsufficientData` | asset | **SDD Only** | type: Text, value: Insufficient data (missing/invalid PO number and/or amount)—please correct and resubmit., description: Standardized Coupa rejection comment template for missing/ambiguous data. | — | — |
| 7 | `Coupa_IRV2_MaxTransactionSeconds` | asset | **SDD Only** | type: Integer, value: 600, description: Transaction-level timeout guardrail in seconds (default aligned to current ~10 minutes manual handling). | — | — |
| 8 | `Coupa_IRV2_MaxConsecutiveSystemFailures` | asset | **SDD Only** | type: Integer, value: 5, description: If exceeded, stop normal processing and route to OperationsExceptions queue to protect SLA/operability. | — | — |
| 9 | `Coupa_IRV2_EnableEvidenceSnapshots` | asset | **SDD Only** | type: Bool, value: true, description: When true, store minimal evidence (screenshots/log extracts) to Storage Bucket for audit/troubleshooting. | — | — |
| 10 | `[Coupa_IRV2_BaseUrl]` | asset | **XAML Only** | — | `InitAllSettings.xaml` | 302 |
| 11 | `[Coupa_IRV2_TolerancePercent]` | asset | **XAML Only** | — | `InitAllSettings.xaml` | 333 |
| 12 | `[Coupa_IRV2_RejectComment_POMismatch]` | asset | **XAML Only** | — | `InitAllSettings.xaml` | 364 |
| 13 | `[Coupa_IRV2_RejectComment_OutOfTolerance]` | asset | **XAML Only** | — | `InitAllSettings.xaml` | 395 |
| 14 | `[Coupa_IRV2_RejectComment_InsufficientData]` | asset | **XAML Only** | — | `InitAllSettings.xaml` | 426 |
| 15 | `[Coupa_IRV2_MaxTransactionSeconds]` | asset | **XAML Only** | — | `InitAllSettings.xaml` | 457 |
| 16 | `[Coupa_IRV2_MaxConsecutiveSystemFailures]` | asset | **XAML Only** | — | `InitAllSettings.xaml` | 488 |
| 17 | `[Coupa_IRV2_EnableEvidenceSnapshots]` | asset | **XAML Only** | — | `InitAllSettings.xaml` | 519 |
| 18 | `[Coupa_IRV2_Credentials]` | credential | **XAML Only** | — | `InitAllSettings.xaml` | 276 |
| 19 | `Coupa_InvoiceReconciliationV2_Invoices` | queue | **SDD Only** | maxRetries: 3, uniqueReference: true, description: Work queue for newly submitted Coupa invoices to be validated (PO existence/match and 5% tolerance) and routed or rejected. | — | — |
| 20 | `Coupa_InvoiceReconciliationV2_OperationsExceptions` | queue | **SDD Only** | maxRetries: 1, uniqueReference: true, description: Operational exceptions requiring support intervention (e.g., Coupa unavailable, repeated UI/API failures). | — | — |

## 9. Queue Management

**Pattern:** Transactional (Dispatcher/Performer)

### SDD-Defined Queues (Not Yet in XAML)

| # | Queue Name | Unique Reference | Max Retries | SLA | Note |
|---|-----------|-----------------|-------------|-----|------|
| 1 | `Coupa_InvoiceReconciliationV2_Invoices` | Yes | 3x | — | Defined in SDD but no matching XAML activity — verify implementation |
| 2 | `Coupa_InvoiceReconciliationV2_OperationsExceptions` | Yes | 1x | — | Defined in SDD but no matching XAML activity — verify implementation |

### Queue Activity Summary

| Capability | Present |
|---|---|
| Add Queue Item | No |
| Get Transaction Item | Yes |
| Set Transaction Status | Yes |

### Retry Policy

Transactional pattern detected — configure Auto Retry (recommended: 3 retries) in Orchestrator Queue settings

### SLA Guidance

Configure SLA in Orchestrator: set Maximum Execution Time per transaction item and monitor Queue SLA reports. Recommended: base SLA on observed P95 processing time + 20% buffer.

### Dead-Letter / Failed Items Handling

Items exceeding max retries are marked as Failed. Review failed items in Orchestrator Queues dashboard. Consider: (1) Create a separate cleanup/reprocessing workflow for DLQ items, (2) Set up email alerts for failed transaction counts exceeding threshold, (3) Log detailed failure context in SetTransactionStatus output for troubleshooting.

> **Note:** This is a Performer process — a separate Dispatcher process is needed to populate the queue.

## 10. Exception Handling Coverage

**Coverage:** 0/24 high-risk activities inside TryCatch (0%)

### Files Without TryCatch

- `CoupaSessionManager.xaml`
- `Dispatcher.xaml`
- `InitPerformer.xaml`
- `ProcessInvoice.xaml`
- `ActionCenterTaskCreator.xaml`
- `ActionCenterCallbackHandler.xaml`
- `InitAllSettings.xaml`
- `GetTransactionData.xaml`
- `KillAllProcesses.xaml`

### Uncovered High-Risk Activities

| # | Location | Activity |
|---|----------|----------|
| 1 | `InitAllSettings.xaml:276` | Get Coupa_IRV2_Credentials |
| 2 | `InitAllSettings.xaml:277` | ui:GetCredential |
| 3 | `InitAllSettings.xaml:280` | ui:GetCredential |
| 4 | `InitAllSettings.xaml:302` | Get Coupa_IRV2_BaseUrl |
| 5 | `InitAllSettings.xaml:305` | ui:GetAsset |
| 6 | `InitAllSettings.xaml:333` | Get Coupa_IRV2_TolerancePercent |
| 7 | `InitAllSettings.xaml:336` | ui:GetAsset |
| 8 | `InitAllSettings.xaml:364` | Get Coupa_IRV2_RejectComment_POMismatch |
| 9 | `InitAllSettings.xaml:367` | ui:GetAsset |
| 10 | `InitAllSettings.xaml:395` | Get Coupa_IRV2_RejectComment_OutOfTolerance |
| 11 | `InitAllSettings.xaml:398` | ui:GetAsset |
| 12 | `InitAllSettings.xaml:426` | Get Coupa_IRV2_RejectComment_InsufficientData |
| 13 | `InitAllSettings.xaml:429` | ui:GetAsset |
| 14 | `InitAllSettings.xaml:457` | Get Coupa_IRV2_MaxTransactionSeconds |
| 15 | `InitAllSettings.xaml:460` | ui:GetAsset |
| 16 | `InitAllSettings.xaml:488` | Get Coupa_IRV2_MaxConsecutiveSystemFailures |
| 17 | `InitAllSettings.xaml:491` | ui:GetAsset |
| 18 | `InitAllSettings.xaml:519` | Get Coupa_IRV2_EnableEvidenceSnapshots |
| 19 | `InitAllSettings.xaml:522` | ui:GetAsset |
| 20 | `GetTransactionData.xaml:158` | Get Queue Item |
| 21 | `GetTransactionData.xaml:160` | ui:GetTransactionItem |
| 22 | `GetTransactionData.xaml:169` | ui:GetTransactionItem |
| 23 | `SetTransactionStatus.xaml:68` | Set Success |
| 24 | `SetTransactionStatus.xaml:90` | Set Failed |

> **Recommendation:** Wrap these activities in TryCatch blocks with appropriate exception types (BusinessRuleException for data errors, System.Exception for general failures).

## 11. Trigger Configuration

Based on the process analysis, the following trigger configuration is recommended:

| # | Trigger Type | Reason | Configuration |
|---|-------------|--------|---------------|
| 1 | **Queue** | Defined in SDD orchestrator_artifacts: TRG_Coupa_IRV2_Queue_NewInvoices | SDD-specified: TRG_Coupa_IRV2_Queue_NewInvoices | Queue: Coupa_InvoiceReconciliationV2_Invoices | Queue trigger to process newly submitted Coupa invoices as they arrive (fan-out across unattended slots). |
| 2 | **Schedule** | Defined in SDD orchestrator_artifacts: TRG_Coupa_IRV2_Time_SafetyNet_Poller | SDD-specified: TRG_Coupa_IRV2_Time_SafetyNet_Poller | Cron: 0 0/30 * ? * MON-FRI * | Safety-net schedule every 30 minutes on business days to handle missed events/backlog recovery (e.g., transient trigger failures). |

## 12. Upstream Quality Findings

The following quality warnings were produced by upstream pipeline stages (selector scoring, type validation, expression linting, etc.) and should be addressed during development:

| Code | Severity | Count | Sample Message |
|------|----------|-------|----------------|
| placeholder-value | warning | 7 | Contains 2 placeholder value(s) matching "\bTODO\b" [Developer Implementation Required] |
| invalid-type-argument | warning | 3 | Line 22: x:TypeArguments="UiPath.Persistence.Activities.FormTask" may not be a valid .NET type |
| missing-package-dep | warning | 1 | Activity "ui:GetCredential" requires package "UiPath.Credentials.Activities" which is not in project.json dependencies |
| invalid-activity-property | warning | 1 | Line 274: property "AssetName" is not a known property of ui:GetCredential |
| hardcoded-asset-name | warning | 9 | Line 274: asset name "Coupa_IRV2_Credentials" is hardcoded — consider using a Config.xlsx entry or workflow argument |
| EXPRESSION_SYNTAX | warning | 3 | Line 42: Standalone "Yes" corrected to "True" in expression: Yes |
| BARE_TOKEN_QUOTED | warning | 14 | Auto-quoted bare token "Settings" for uexcel:ExcelReadRange.SheetName (expected String type) — wrapped in VB string quot... |
| TYPE_MISMATCH | warning | 3 | Line 81: Type mismatch — variable "dict_Config" (scg:Dictionary(x:String, x:Object)) bound to ui:InvokeWorkflowFile.Argu... |

## 13. Pre-Deployment Checklist

| # | Category | Task | Required |
|---|----------|------|----------|
| 1 | Deployment | Publish package to Orchestrator feed | Yes |
| 2 | Deployment | Create Process in target folder | Yes |
| 3 | Environment | Verify Orchestrator connection from robot | Yes |
| 4 | Credentials | Provision credential: `[Coupa_IRV2_Credentials]` | Yes |
| 5 | Assets | Provision asset: `[Coupa_IRV2_BaseUrl]` | Yes |
| 6 | Assets | Provision asset: `[Coupa_IRV2_TolerancePercent]` | Yes |
| 7 | Assets | Provision asset: `[Coupa_IRV2_RejectComment_POMismatch]` | Yes |
| 8 | Assets | Provision asset: `[Coupa_IRV2_RejectComment_OutOfTolerance]` | Yes |
| 9 | Assets | Provision asset: `[Coupa_IRV2_RejectComment_InsufficientData]` | Yes |
| 10 | Assets | Provision asset: `[Coupa_IRV2_MaxTransactionSeconds]` | Yes |
| 11 | Assets | Provision asset: `[Coupa_IRV2_MaxConsecutiveSystemFailures]` | Yes |
| 12 | Assets | Provision asset: `[Coupa_IRV2_EnableEvidenceSnapshots]` | Yes |
| 13 | Trigger | Configure trigger (schedule/queue/API) | Yes |
| 14 | Testing | Run smoke test in target environment | Yes |
| 15 | Monitoring | Verify logging output in Orchestrator | Recommended |
| 16 | Governance | UAT test execution completed and sign-off obtained | Yes |
| 17 | Governance | Peer code review completed | Yes |
| 18 | Governance | All quality gate warnings addressed or risk-accepted | Yes |
| 19 | Governance | Business process owner validation obtained | Yes |
| 20 | Governance | CoE approval obtained | Yes |
| 21 | Governance | Production readiness assessment completed (monitoring, alerting, rollback plan documented) | Yes |

## 14. Deployment Readiness Score

**Overall: Mostly Ready — 33/50 (66%)**

| Section | Score | Notes |
|---------|-------|-------|
| Credentials & Assets | 10/10 | All credentials/assets properly configured |
| Exception Handling | 2/10 | Only 0% of high-risk activities covered by TryCatch; 9 file(s) with no TryCatch blocks |
| Queue Management | 10/10 | Queue configuration looks good |
| Build Quality | 1/10 | 41 quality warnings — significant remediation needed; 33 remediations — stub replacements need developer attention |
| Environment Setup | 10/10 | Environment requirements are straightforward |

> **Almost There:** A few items need attention before production deployment.

## 15. Pre-emission Spec Validation

Validation was performed on the WorkflowSpec tree before XAML assembly. Issues caught at this stage are cheaper to fix than post-emission quality gate findings.

| Metric | Count |
|---|---|
| Total activities checked | 0 |
| Valid activities | 0 |
| Unknown → Comment stubs | 0 |
| Non-catalog properties stripped | 0 |
| Enum values auto-corrected | 0 |
| Missing required props filled | 0 |
| Total issues | 0 |

### Pre-emission vs Post-emission

| Stage | Issues Caught/Fixed |
|---|---|
| Pre-emission (spec validation) | 0 auto-fixed, 0 total issues |
| Post-emission (quality gate) | 74 warnings/remediations |

## 16. Catalog Filter Adoption Report

Shows which pipeline stages use the filtered activity catalog (deprecated, non-emission-approved, and target-incompatible activities are excluded).

| Stage | Adopted | Total Lookups | Approved | Deprecated | Non-Approved | Target-Incompatible | Unknown |
|---|---|---|---|---|---|---|---|
| quality-gate | Yes | 248 | 248 | 0 | 0 | 0 | 0 |
| deterministic-validators | Yes | 4160 | 1480 | 0 | 0 | 0 | 2680 |
| iterative-llm-corrector | Yes | 0 | 0 | 0 | 0 | 0 | 0 |
| workflow-tree-assembler | Yes | 0 | 0 | 0 | 0 | 0 | 0 |
| xaml-compliance | Yes | 189054 | 80130 | 0 | 107469 | 0 | 1455 |
| executable-path-validator | Yes | 204 | 190 | 0 | 0 | 0 | 14 |
| post-emission-dependency-analyzer | Yes | 9 | 9 | 0 | 0 | 0 | 0 |

---

## 17. Structured Report (JSON)

The following JSON appendix contains the full pipeline outcome report for programmatic consumption:

```json
{
  "fullyGeneratedFiles": [
    "SetTransactionStatus.xaml",
    "CloseAllApplications.xaml",
    "KillAllProcesses.xaml"
  ],
  "autoRepairs": [
    {
      "repairCode": "REPAIR_PLACEHOLDER_CLEANUP",
      "file": "Process.xaml",
      "description": "Stripped 4 placeholder token(s) from Process.xaml",
      "developerAction": "Review Process.xaml for Comment elements marking where placeholder activities were removed",
      "estimatedEffortMinutes": 5
    },
    {
      "repairCode": "REPAIR_GENERIC",
      "file": "InitAllSettings.xaml",
      "description": "Catalog (DOM): move-to-child-element uexcel:ExcelReadRange.DataTable in InitAllSettings.xaml"
    },
    {
      "repairCode": "REPAIR_GENERIC",
      "file": "InitAllSettings.xaml",
      "description": "Catalog (DOM): move-to-child-element uexcel:ExcelReadRange.DataTable in InitAllSettings.xaml"
    },
    {
      "repairCode": "REPAIR_GENERIC",
      "file": "InitAllSettings.xaml",
      "description": "Catalog (DOM): move-to-child-element ForEach.Values in InitAllSettings.xaml"
    },
    {
      "repairCode": "REPAIR_GENERIC",
      "file": "InitAllSettings.xaml",
      "description": "Catalog (DOM): move-to-child-element ui:GetCredential.Username in InitAllSettings.xaml"
    },
    {
      "repairCode": "REPAIR_GENERIC",
      "file": "InitAllSettings.xaml",
      "description": "Catalog (DOM): move-to-child-element ui:GetCredential.Password in InitAllSettings.xaml"
    },
    {
      "repairCode": "REPAIR_GENERIC",
      "file": "InitAllSettings.xaml",
      "description": "Catalog (DOM): move-to-child-element ForEach.Values in InitAllSettings.xaml"
    },
    {
      "repairCode": "REPAIR_GENERIC",
      "file": "GetTransactionData.xaml",
      "description": "Catalog (DOM): move-to-child-element ui:GetTransactionItem.QueueName in GetTransactionData.xaml"
    },
    {
      "repairCode": "REPAIR_TYPE_MISMATCH",
      "file": "Main.xaml",
      "description": "No known conversion from scg:Dictionary(x:String, x:Object) to System.Collections.Generic.Dictionary`<System.String, System.Activities.Argument> — review the variable type or activity property"
    },
    {
      "repairCode": "REPAIR_TYPE_MISMATCH",
      "file": "Main.xaml",
      "description": "No known conversion from UiPath.Core.QueueItem to System.Collections.Generic.Dictionary`<System.String, System.Activities.Argument> — review the variable type or activity property"
    },
    {
      "repairCode": "REPAIR_TYPE_MISMATCH",
      "file": "Init.xaml",
      "description": "No known conversion from scg:Dictionary(x:String, x:Object) to System.Collections.Generic.Dictionary`<System.String, System.Activities.Argument> — review the variable type or activity property"
    }
  ],
  "remediations": [
    {
      "level": "workflow",
      "file": "CoupaSessionManager.xaml",
      "remediationCode": "STUB_WORKFLOW_GENERATOR_FAILURE",
      "reason": "Compliance transform failed — XAML XML well-formedness validation failed: XML well-formedness error at line 26, col 163: char '&' is not expected. (code: InvalidChar)",
      "classifiedCheck": "compliance-crash",
      "developerAction": "TODO: Implement CoupaSessionManager — review SDD for workflow requirements",
      "estimatedEffortMinutes": 15
    },
    {
      "level": "workflow",
      "file": "Dispatcher.xaml",
      "remediationCode": "STUB_WORKFLOW_GENERATOR_FAILURE",
      "reason": "Compliance transform failed — XAML XML well-formedness validation failed: XML well-formedness error at line 29, col 142: char '&' is not expected. (code: InvalidChar)",
      "classifiedCheck": "compliance-crash",
      "developerAction": "TODO: Implement Dispatcher — review SDD for workflow requirements",
      "estimatedEffortMinutes": 15
    },
    {
      "level": "workflow",
      "file": "InitPerformer.xaml",
      "remediationCode": "STUB_WORKFLOW_GENERATOR_FAILURE",
      "reason": "Compliance transform failed — XAML XML well-formedness validation failed: XML well-formedness error at line 671, col 151: char '&' is not expected. (code: InvalidChar)",
      "classifiedCheck": "compliance-crash",
      "developerAction": "TODO: Implement InitPerformer — review SDD for workflow requirements",
      "estimatedEffortMinutes": 15
    },
    {
      "level": "workflow",
      "file": "ProcessInvoice.xaml",
      "remediationCode": "STUB_WORKFLOW_GENERATOR_FAILURE",
      "reason": "Compliance transform failed — XAML XML well-formedness validation failed: XML well-formedness error at line 461, col 161: char '&' is not expected. (code: InvalidChar)",
      "classifiedCheck": "compliance-crash",
      "developerAction": "TODO: Implement ProcessInvoice — review SDD for workflow requirements",
      "estimatedEffortMinutes": 15
    },
    {
      "level": "workflow",
      "file": "ActionCenterTaskCreator.xaml",
      "remediationCode": "STUB_WORKFLOW_GENERATOR_FAILURE",
      "reason": "Compliance transform failed — XAML XML well-formedness validation failed: XML well-formedness error at line 42, col 169: char '&' is not expected. (code: InvalidChar)",
      "classifiedCheck": "compliance-crash",
      "developerAction": "TODO: Implement ActionCenterTaskCreator — review SDD for workflow requirements",
      "estimatedEffortMinutes": 15
    },
    {
      "level": "workflow",
      "file": "ActionCenterCallbackHandler.xaml",
      "remediationCode": "STUB_WORKFLOW_GENERATOR_FAILURE",
      "reason": "Compliance transform failed — XAML XML well-formedness validation failed: XML well-formedness error at line 731, col 136: char '&' is not expected. (code: InvalidChar)",
      "classifiedCheck": "compliance-crash",
      "developerAction": "TODO: Implement ActionCenterCallbackHandler — review SDD for workflow requirements",
      "estimatedEffortMinutes": 15
    },
    {
      "level": "workflow",
      "file": "Main.xaml",
      "remediationCode": "STUB_WORKFLOW_GENERATOR_FAILURE",
      "reason": "Compliance transform failed — XAML XML well-formedness validation failed: XML well-formedness error at line 327, col 136: char '&' is not expected. (code: InvalidChar)",
      "classifiedCheck": "compliance-crash",
      "developerAction": "TODO: Implement Main — review SDD for workflow requirements",
      "estimatedEffortMinutes": 15
    },
    {
      "level": "validation-finding",
      "file": "Process.xaml",
      "remediationCode": "STUB_ACTIVITY_UNKNOWN",
      "reason": "Line 103: Undeclared variable \"Provide\" in expression: Provide Data — variable is not declared in any <Variable> block in scope",
      "classifiedCheck": "UNDECLARED_VARIABLE",
      "developerAction": "Manually implement activity in Process.xaml — estimated 15 min",
      "estimatedEffortMinutes": 15
    },
    {
      "level": "validation-finding",
      "file": "Process.xaml",
      "remediationCode": "STUB_ACTIVITY_UNKNOWN",
      "reason": "Line 103: Undeclared variable \"Data\" in expression: Provide Data — variable is not declared in any <Variable> block in scope",
      "classifiedCheck": "UNDECLARED_VARIABLE",
      "developerAction": "Manually implement activity in Process.xaml — estimated 15 min",
      "estimatedEffortMinutes": 15
    },
    {
      "level": "validation-finding",
      "file": "Process.xaml",
      "remediationCode": "STUB_ACTIVITY_UNKNOWN",
      "reason": "Line 158: Standalone word \"Approved\" may be an undeclared variable — should it be a string literal \"Approved\"? in expression: Approved",
      "classifiedCheck": "EXPRESSION_SYNTAX_UNFIXABLE",
      "developerAction": "Manually implement activity in Process.xaml — estimated 15 min",
      "estimatedEffortMinutes": 15
    },
    {
      "level": "validation-finding",
      "file": "Process.xaml",
      "remediationCode": "STUB_ACTIVITY_UNKNOWN",
      "reason": "Line 158: Undeclared variable \"Approved\" in expression: Approved — variable is not declared in any <Variable> block in scope",
      "classifiedCheck": "UNDECLARED_VARIABLE",
      "developerAction": "Manually implement activity in Process.xaml — estimated 15 min",
      "estimatedEffortMinutes": 15
    },
    {
      "level": "validation-finding",
      "file": "Process.xaml",
      "remediationCode": "STUB_ACTIVITY_UNKNOWN",
      "reason": "XAML file is missing TextExpression.NamespacesForImplementation block — Studio cannot resolve expression types without this declaration",
      "classifiedCheck": "MISSING_TEXT_EXPRESSION_NAMESPACES",
      "developerAction": "Manually implement activity in Process.xaml — estimated 15 min",
      "estimatedEffortMinutes": 15
    },
    {
      "level": "validation-finding",
      "file": "Process.xaml",
      "remediationCode": "STUB_ACTIVITY_UNKNOWN",
      "reason": "XAML file is missing TextExpression.ReferencesForImplementation block — Studio cannot resolve assembly references without this declaration",
      "classifiedCheck": "MISSING_TEXT_EXPRESSION_REFERENCES",
      "developerAction": "Manually implement activity in Process.xaml — estimated 15 min",
      "estimatedEffortMinutes": 15
    },
    {
      "level": "validation-finding",
      "file": "InitAllSettings.xaml",
      "remediationCode": "STUB_ACTIVITY_UNKNOWN",
      "reason": "Line 173: uexcel:ExcelApplicationScope is missing required property \"ExistingWorkbook\"",
      "classifiedCheck": "MISSING_REQUIRED_ACTIVITY_PROPERTY",
      "developerAction": "Manually implement activity in InitAllSettings.xaml — estimated 15 min",
      "estimatedEffortMinutes": 15
    },
    {
      "level": "validation-finding",
      "file": "InitAllSettings.xaml",
      "remediationCode": "STUB_ACTIVITY_UNKNOWN",
      "reason": "Line 274: ui:GetCredential is missing required property \"Target\"",
      "classifiedCheck": "MISSING_REQUIRED_ACTIVITY_PROPERTY",
      "developerAction": "Manually implement activity in InitAllSettings.xaml — estimated 15 min",
      "estimatedEffortMinutes": 15
    },
    {
      "level": "validation-finding",
      "file": "Process.xaml",
      "remediationCode": "STUB_ACTIVITY_CATALOG_VIOLATION",
      "reason": "Property \"TaskPriority\" on upers:CreateFormTask must be a child element, not an attribute",
      "classifiedCheck": "CATALOG_STRUCTURAL_VIOLATION",
      "developerAction": "Fix property syntax for activity in Process.xaml — move attribute to child-element or vice versa per UiPath catalog",
      "estimatedEffortMinutes": 15
    },
    {
      "level": "validation-finding",
      "file": "Process.xaml",
      "remediationCode": "STUB_ACTIVITY_CATALOG_VIOLATION",
      "reason": "ENUM_VIOLATION: Invalid value \"TODO_Provide_value_for_TaskPriority\" for \"TaskPriority\" on upers:CreateFormTask — valid values: Low, Medium, High, Critical. No normalization match found.",
      "classifiedCheck": "ENUM_VIOLATION",
      "developerAction": "Fix enum value for activity in Process.xaml — use valid enum from UiPath documentation",
      "estimatedEffortMinutes": 5
    },
    {
      "level": "validation-finding",
      "file": "InitAllSettings.xaml",
      "remediationCode": "STUB_ACTIVITY_CATALOG_VIOLATION",
      "reason": "Property \"ExistingWorkbook\" on uexcel:ExcelApplicationScope must be a child element, not an attribute",
      "classifiedCheck": "CATALOG_STRUCTURAL_VIOLATION",
      "developerAction": "Fix property syntax for activity in InitAllSettings.xaml — move attribute to child-element or vice versa per UiPath catalog",
      "estimatedEffortMinutes": 15
    },
    {
      "level": "validation-finding",
      "file": "InitAllSettings.xaml",
      "remediationCode": "STUB_ACTIVITY_CATALOG_VIOLATION",
      "reason": "Property \"To\" on Assign must be a child element, not an attribute",
      "classifiedCheck": "CATALOG_STRUCTURAL_VIOLATION",
      "developerAction": "Fix property syntax for activity in InitAllSettings.xaml — move attribute to child-element or vice versa per UiPath catalog",
      "estimatedEffortMinutes": 15
    },
    {
      "level": "validation-finding",
      "file": "InitAllSettings.xaml",
      "remediationCode": "STUB_ACTIVITY_CATALOG_VIOLATION",
      "reason": "Property \"Value\" on Assign must be a child element, not an attribute",
      "classifiedCheck": "CATALOG_STRUCTURAL_VIOLATION",
      "developerAction": "Fix property syntax for activity in InitAllSettings.xaml — move attribute to child-element or vice versa per UiPath catalog",
      "estimatedEffortMinutes": 15
    },
    {
      "level": "validation-finding",
      "file": "Main.xaml",
      "remediationCode": "STUB_ACTIVITY_CATALOG_VIOLATION",
      "reason": "Property \"To\" on Assign must be a child element, not an attribute",
      "classifiedCheck": "CATALOG_STRUCTURAL_VIOLATION",
      "developerAction": "Fix property syntax for activity in Main.xaml — move attribute to child-element or vice versa per UiPath catalog",
      "estimatedEffortMinutes": 15
    },
    {
      "level": "validation-finding",
      "file": "Main.xaml",
      "remediationCode": "STUB_ACTIVITY_CATALOG_VIOLATION",
      "reason": "Property \"Value\" on Assign must be a child element, not an attribute",
      "classifiedCheck": "CATALOG_STRUCTURAL_VIOLATION",
      "developerAction": "Fix property syntax for activity in Main.xaml — move attribute to child-element or vice versa per UiPath catalog",
      "estimatedEffortMinutes": 15
    },
    {
      "level": "validation-finding",
      "file": "GetTransactionData.xaml",
      "remediationCode": "STUB_ACTIVITY_CATALOG_VIOLATION",
      "reason": "Property \"To\" on Assign must be a child element, not an attribute",
      "classifiedCheck": "CATALOG_STRUCTURAL_VIOLATION",
      "developerAction": "Fix property syntax for activity in GetTransactionData.xaml — move attribute to child-element or vice versa per UiPath catalog",
      "estimatedEffortMinutes": 15
    },
    {
      "level": "validation-finding",
      "file": "GetTransactionData.xaml",
      "remediationCode": "STUB_ACTIVITY_CATALOG_VIOLATION",
      "reason": "Property \"Value\" on Assign must be a child element, not an attribute",
      "classifiedCheck": "CATALOG_STRUCTURAL_VIOLATION",
      "developerAction": "Fix property syntax for activity in GetTransactionData.xaml — move attribute to child-element or vice versa per UiPath catalog",
      "estimatedEffortMinutes": 15
    },
    {
      "level": "validation-finding",
      "file": "Init.xaml",
      "remediationCode": "STUB_ACTIVITY_CATALOG_VIOLATION",
      "reason": "Property \"To\" on Assign must be a child element, not an attribute",
      "classifiedCheck": "CATALOG_STRUCTURAL_VIOLATION",
      "developerAction": "Fix property syntax for activity in Init.xaml — move attribute to child-element or vice versa per UiPath catalog",
      "estimatedEffortMinutes": 15
    },
    {
      "level": "validation-finding",
      "file": "Init.xaml",
      "remediationCode": "STUB_ACTIVITY_CATALOG_VIOLATION",
      "reason": "Property \"Value\" on Assign must be a child element, not an attribute",
      "classifiedCheck": "CATALOG_STRUCTURAL_VIOLATION",
      "developerAction": "Fix property syntax for activity in Init.xaml — move attribute to child-element or vice versa per UiPath catalog",
      "estimatedEffortMinutes": 15
    },
    {
      "level": "validation-finding",
      "file": "Init.xaml",
      "remediationCode": "STUB_ACTIVITY_CATALOG_VIOLATION",
      "reason": "Property \"Exception\" on Throw must be a child element, not an attribute",
      "classifiedCheck": "CATALOG_STRUCTURAL_VIOLATION",
      "developerAction": "Fix property syntax for activity in Init.xaml — move attribute to child-element or vice versa per UiPath catalog",
      "estimatedEffortMinutes": 15
    },
    {
      "level": "activity",
      "file": "Process.xaml",
      "remediationCode": "UNDECLARED_VARIABLE_MANUAL",
      "reason": "Undeclared variable \"Provide\" — type cannot be auto-inferred (no recognized naming prefix)",
      "classifiedCheck": "UNDECLARED_VARIABLE",
      "developerAction": "Declare variable \"Provide\" in Process.xaml with the appropriate type. Expression context: Provide Data",
      "estimatedEffortMinutes": 5
    },
    {
      "level": "activity",
      "file": "Process.xaml",
      "remediationCode": "UNDECLARED_VARIABLE_MANUAL",
      "reason": "Undeclared variable \"Data\" — type cannot be auto-inferred (no recognized naming prefix)",
      "classifiedCheck": "UNDECLARED_VARIABLE",
      "developerAction": "Declare variable \"Data\" in Process.xaml with the appropriate type. Expression context: Provide Data",
      "estimatedEffortMinutes": 5
    },
    {
      "level": "activity",
      "file": "Process.xaml",
      "remediationCode": "UNDECLARED_VARIABLE_MANUAL",
      "reason": "Undeclared variable \"Approved\" — type cannot be auto-inferred (no recognized naming prefix)",
      "classifiedCheck": "UNDECLARED_VARIABLE",
      "developerAction": "Declare variable \"Approved\" in Process.xaml with the appropriate type. Expression context: Approved",
      "estimatedEffortMinutes": 5
    },
    {
      "level": "activity",
      "file": "",
      "remediationCode": "POST_ASSEMBLY_REPAIR",
      "reason": "[MISSING_REQUIRED_PROPERTY_DEFECT] uexcel:ExcelApplicationScope.ExistingWorkbook has no valid source binding and no contract-valid fallback — structured defect, property left absent",
      "classifiedCheck": "post-assembly-repair",
      "developerAction": "uexcel:ExcelApplicationScope.ExistingWorkbook has no valid source binding and no contract-valid fallback — structured defect, property left absent",
      "estimatedEffortMinutes": 5
    },
    {
      "level": "activity",
      "file": "",
      "remediationCode": "POST_ASSEMBLY_REPAIR",
      "reason": "[MISSING_REQUIRED_PROPERTY_DEFECT] uexcel:ExcelApplicationScope.ExistingWorkbook has no valid source binding and no contract-valid fallback — structured defect, property left absent",
      "classifiedCheck": "post-assembly-repair",
      "developerAction": "uexcel:ExcelApplicationScope.ExistingWorkbook has no valid source binding and no contract-valid fallback — structured defect, property left absent",
      "estimatedEffortMinutes": 5
    },
    {
      "level": "workflow",
      "file": "InitAllSettings.xaml",
      "remediationCode": "STUB_WORKFLOW_BLOCKING",
      "reason": "Pre-archive assertion: malformed_attribute_quoting — Malformed attribute quoting detected: AssetName=\"[&quot;Coupa_IRV2_Credentials&quot;]",
      "classifiedCheck": "pre-archive-canonicalization",
      "developerAction": "Resolve malformed_attribute_quoting in InitAllSettings.xaml",
      "estimatedEffortMinutes": 10
    }
  ],
  "propertyRemediations": [],
  "downgradeEvents": [],
  "qualityWarnings": [
    {
      "check": "placeholder-value",
      "file": "Process.xaml",
      "detail": "Contains 2 placeholder value(s) matching \"\\bTODO\\b\" [Developer Implementation Required]",
      "severity": "warning",
      "stubCategory": "handoff"
    },
    {
      "check": "placeholder-value",
      "file": "CoupaSessionManager.xaml",
      "detail": "Contains 1 placeholder value(s) matching \"\\bPLACEHOLDER\\b\" [Developer Implementation Required]",
      "severity": "warning",
      "stubCategory": "handoff"
    },
    {
      "check": "placeholder-value",
      "file": "Dispatcher.xaml",
      "detail": "Contains 1 placeholder value(s) matching \"\\bPLACEHOLDER\\b\" [Developer Implementation Required]",
      "severity": "warning",
      "stubCategory": "handoff"
    },
    {
      "check": "placeholder-value",
      "file": "InitPerformer.xaml",
      "detail": "Contains 1 placeholder value(s) matching \"\\bPLACEHOLDER\\b\" [Developer Implementation Required]",
      "severity": "warning",
      "stubCategory": "handoff"
    },
    {
      "check": "placeholder-value",
      "file": "ProcessInvoice.xaml",
      "detail": "Contains 1 placeholder value(s) matching \"\\bPLACEHOLDER\\b\" [Developer Implementation Required]",
      "severity": "warning",
      "stubCategory": "handoff"
    },
    {
      "check": "placeholder-value",
      "file": "ActionCenterTaskCreator.xaml",
      "detail": "Contains 1 placeholder value(s) matching \"\\bPLACEHOLDER\\b\" [Developer Implementation Required]",
      "severity": "warning",
      "stubCategory": "handoff"
    },
    {
      "check": "placeholder-value",
      "file": "ActionCenterCallbackHandler.xaml",
      "detail": "Contains 1 placeholder value(s) matching \"\\bPLACEHOLDER\\b\" [Developer Implementation Required]",
      "severity": "warning",
      "stubCategory": "handoff"
    },
    {
      "check": "invalid-type-argument",
      "file": "Process.xaml",
      "detail": "Line 22: x:TypeArguments=\"UiPath.Persistence.Activities.FormTask\" may not be a valid .NET type",
      "severity": "warning"
    },
    {
      "check": "missing-package-dep",
      "file": "InitAllSettings.xaml",
      "detail": "Activity \"ui:GetCredential\" requires package \"UiPath.Credentials.Activities\" which is not in project.json dependencies",
      "severity": "warning"
    },
    {
      "check": "invalid-activity-property",
      "file": "InitAllSettings.xaml",
      "detail": "Line 274: property \"AssetName\" is not a known property of ui:GetCredential",
      "severity": "warning"
    },
    {
      "check": "invalid-type-argument",
      "file": "InitAllSettings.xaml",
      "detail": "Line 190: x:TypeArguments=\"uexcel:DataTable\" may not be a valid .NET type",
      "severity": "warning"
    },
    {
      "check": "invalid-type-argument",
      "file": "InitAllSettings.xaml",
      "detail": "Line 197: x:TypeArguments=\"uexcel:DataTable\" may not be a valid .NET type",
      "severity": "warning"
    },
    {
      "check": "hardcoded-asset-name",
      "file": "InitAllSettings.xaml",
      "detail": "Line 274: asset name \"Coupa_IRV2_Credentials\" is hardcoded — consider using a Config.xlsx entry or workflow argument",
      "severity": "warning"
    },
    {
      "check": "hardcoded-asset-name",
      "file": "InitAllSettings.xaml",
      "detail": "Line 300: asset name \"Coupa_IRV2_BaseUrl\" is hardcoded — consider using a Config.xlsx entry or workflow argument",
      "severity": "warning"
    },
    {
      "check": "hardcoded-asset-name",
      "file": "InitAllSettings.xaml",
      "detail": "Line 331: asset name \"Coupa_IRV2_TolerancePercent\" is hardcoded — consider using a Config.xlsx entry or workflow argument",
      "severity": "warning"
    },
    {
      "check": "hardcoded-asset-name",
      "file": "InitAllSettings.xaml",
      "detail": "Line 362: asset name \"Coupa_IRV2_RejectComment_POMismatch\" is hardcoded — consider using a Config.xlsx entry or workflow argument",
      "severity": "warning"
    },
    {
      "check": "hardcoded-asset-name",
      "file": "InitAllSettings.xaml",
      "detail": "Line 393: asset name \"Coupa_IRV2_RejectComment_OutOfTolerance\" is hardcoded — consider using a Config.xlsx entry or workflow argument",
      "severity": "warning"
    },
    {
      "check": "hardcoded-asset-name",
      "file": "InitAllSettings.xaml",
      "detail": "Line 424: asset name \"Coupa_IRV2_RejectComment_InsufficientData\" is hardcoded — consider using a Config.xlsx entry or workflow argument",
      "severity": "warning"
    },
    {
      "check": "hardcoded-asset-name",
      "file": "InitAllSettings.xaml",
      "detail": "Line 455: asset name \"Coupa_IRV2_MaxTransactionSeconds\" is hardcoded — consider using a Config.xlsx entry or workflow argument",
      "severity": "warning"
    },
    {
      "check": "hardcoded-asset-name",
      "file": "InitAllSettings.xaml",
      "detail": "Line 486: asset name \"Coupa_IRV2_MaxConsecutiveSystemFailures\" is hardcoded — consider using a Config.xlsx entry or workflow argument",
      "severity": "warning"
    },
    {
      "check": "hardcoded-asset-name",
      "file": "InitAllSettings.xaml",
      "detail": "Line 517: asset name \"Coupa_IRV2_EnableEvidenceSnapshots\" is hardcoded — consider using a Config.xlsx entry or workflow argument",
      "severity": "warning"
    },
    {
      "check": "EXPRESSION_SYNTAX",
      "file": "Process.xaml",
      "detail": "Line 42: Standalone \"Yes\" corrected to \"True\" in expression: Yes",
      "severity": "warning"
    },
    {
      "check": "EXPRESSION_SYNTAX",
      "file": "Process.xaml",
      "detail": "Line 123: Standalone \"Yes\" corrected to \"True\" in expression: Yes",
      "severity": "warning"
    },
    {
      "check": "EXPRESSION_SYNTAX",
      "file": "Process.xaml",
      "detail": "Line 142: Standalone \"Yes\" corrected to \"True\" in expression: Yes",
      "severity": "warning"
    },
    {
      "check": "BARE_TOKEN_QUOTED",
      "file": "InitAllSettings.xaml",
      "detail": "Auto-quoted bare token \"Settings\" for uexcel:ExcelReadRange.SheetName (expected String type) — wrapped in VB string quotes",
      "severity": "warning"
    },
    {
      "check": "BARE_TOKEN_QUOTED",
      "file": "InitAllSettings.xaml",
      "detail": "Auto-quoted bare token \"Constants\" for uexcel:ExcelReadRange.SheetName (expected String type) — wrapped in VB string quotes",
      "severity": "warning"
    },
    {
      "check": "BARE_TOKEN_QUOTED",
      "file": "InitAllSettings.xaml",
      "detail": "Auto-quoted bare token \"Coupa_IRV2_Credentials\" for ui:GetCredential.AssetName (expected String type) — wrapped in VB string quotes",
      "severity": "warning"
    },
    {
      "check": "BARE_TOKEN_QUOTED",
      "file": "InitAllSettings.xaml",
      "detail": "Auto-quoted bare token \"Coupa_IRV2_BaseUrl\" for ui:GetAsset.AssetName (expected String type) — wrapped in VB string quotes",
      "severity": "warning"
    },
    {
      "check": "BARE_TOKEN_QUOTED",
      "file": "InitAllSettings.xaml",
      "detail": "Auto-quoted bare token \"Coupa_IRV2_TolerancePercent\" for ui:GetAsset.AssetName (expected String type) — wrapped in VB string quotes",
      "severity": "warning"
    },
    {
      "check": "BARE_TOKEN_QUOTED",
      "file": "InitAllSettings.xaml",
      "detail": "Auto-quoted bare token \"Coupa_IRV2_RejectComment_POMismatch\" for ui:GetAsset.AssetName (expected String type) — wrapped in VB string quotes",
      "severity": "warning"
    },
    {
      "check": "BARE_TOKEN_QUOTED",
      "file": "InitAllSettings.xaml",
      "detail": "Auto-quoted bare token \"Coupa_IRV2_RejectComment_OutOfTolerance\" for ui:GetAsset.AssetName (expected String type) — wrapped in VB string quotes",
      "severity": "warning"
    },
    {
      "check": "BARE_TOKEN_QUOTED",
      "file": "InitAllSettings.xaml",
      "detail": "Auto-quoted bare token \"Coupa_IRV2_RejectComment_InsufficientData\" for ui:GetAsset.AssetName (expected String type) — wrapped in VB string quotes",
      "severity": "warning"
    },
    {
      "check": "BARE_TOKEN_QUOTED",
      "file": "InitAllSettings.xaml",
      "detail": "Auto-quoted bare token \"Coupa_IRV2_MaxTransactionSeconds\" for ui:GetAsset.AssetName (expected String type) — wrapped in VB string quotes",
      "severity": "warning"
    },
    {
      "check": "BARE_TOKEN_QUOTED",
      "file": "InitAllSettings.xaml",
      "detail": "Auto-quoted bare token \"Coupa_IRV2_MaxConsecutiveSystemFailures\" for ui:GetAsset.AssetName (expected String type) — wrapped in VB string quotes",
      "severity": "warning"
    },
    {
      "check": "BARE_TOKEN_QUOTED",
      "file": "InitAllSettings.xaml",
      "detail": "Auto-quoted bare token \"Coupa_IRV2_EnableEvidenceSnapshots\" for ui:GetAsset.AssetName (expected String type) — wrapped in VB string quotes",
      "severity": "warning"
    },
    {
      "check": "TYPE_MISMATCH",
      "file": "Main.xaml",
      "detail": "Line 81: Type mismatch — variable \"dict_Config\" (scg:Dictionary(x:String, x:Object)) bound to ui:InvokeWorkflowFile.Arguments (expects System.Collections.Generic.Dictionary`<System.String, System.Activities.Argument>). No known conversion from scg:Dictionary(x:String, x:Object) to System.Collections.Generic.Dictionary`<System.String, System.Activities.Argument> — review the variable type or activity property",
      "severity": "warning"
    },
    {
      "check": "TYPE_MISMATCH",
      "file": "Main.xaml",
      "detail": "Line 134: Type mismatch — variable \"qi_TransactionItem\" (UiPath.Core.QueueItem) bound to ui:InvokeWorkflowFile.Arguments (expects System.Collections.Generic.Dictionary`<System.String, System.Activities.Argument>). No known conversion from UiPath.Core.QueueItem to System.Collections.Generic.Dictionary`<System.String, System.Activities.Argument> — review the variable type or activity property",
      "severity": "warning"
    },
    {
      "check": "BARE_TOKEN_QUOTED",
      "file": "KillAllProcesses.xaml",
      "detail": "Auto-quoted bare token \"chrome\" for ui:KillProcess.ProcessName (expected String type) — wrapped in VB string quotes",
      "severity": "warning"
    },
    {
      "check": "BARE_TOKEN_QUOTED",
      "file": "KillAllProcesses.xaml",
      "detail": "Auto-quoted bare token \"iexplore\" for ui:KillProcess.ProcessName (expected String type) — wrapped in VB string quotes",
      "severity": "warning"
    },
    {
      "check": "BARE_TOKEN_QUOTED",
      "file": "KillAllProcesses.xaml",
      "detail": "Auto-quoted bare token \"EXCEL\" for ui:KillProcess.ProcessName (expected String type) — wrapped in VB string quotes",
      "severity": "warning"
    },
    {
      "check": "TYPE_MISMATCH",
      "file": "Init.xaml",
      "detail": "Line 68: Type mismatch — variable \"dict_Config\" (scg:Dictionary(x:String, x:Object)) bound to ui:InvokeWorkflowFile.Arguments (expects System.Collections.Generic.Dictionary`<System.String, System.Activities.Argument>). No known conversion from scg:Dictionary(x:String, x:Object) to System.Collections.Generic.Dictionary`<System.String, System.Activities.Argument> — review the variable type or activity property",
      "severity": "warning"
    }
  ],
  "totalEstimatedEffortMinutes": 430,
  "studioCompatibility": [
    {
      "file": "Process.xaml",
      "level": "studio-blocked",
      "blockers": [
        "[EXPRESSION_SYNTAX_UNFIXABLE] Line 158: Standalone word \"Approved\" may be an undeclared variable — should it be a string literal \"Approved\"? in expression: Approved",
        "[CATALOG_STRUCTURAL_VIOLATION] Property \"TaskPriority\" on upers:CreateFormTask must be a child element, not an attribute"
      ]
    },
    {
      "file": "InitAllSettings.xaml",
      "level": "studio-blocked",
      "blockers": [
        "[COMPLIANCE-FAILURE] Compliance or quality gate failure requiring manual remediation"
      ],
      "failureCategory": "compliance-failure",
      "failureSummary": "Compliance or quality gate failure requiring manual remediation"
    },
    {
      "file": "Main.xaml",
      "level": "studio-blocked",
      "blockers": [
        "[GENERATION-FAILURE] Workflow generation failed — LLM output could not be parsed into valid XAML"
      ],
      "failureCategory": "generation-failure",
      "failureSummary": "Workflow generation failed — LLM output could not be parsed into valid XAML"
    },
    {
      "file": "GetTransactionData.xaml",
      "level": "studio-blocked",
      "blockers": [
        "[CATALOG_STRUCTURAL_VIOLATION] Property \"To\" on Assign must be a child element, not an attribute",
        "[CATALOG_STRUCTURAL_VIOLATION] Property \"Value\" on Assign must be a child element, not an attribute"
      ]
    },
    {
      "file": "SetTransactionStatus.xaml",
      "level": "studio-clean",
      "blockers": []
    },
    {
      "file": "CloseAllApplications.xaml",
      "level": "studio-clean",
      "blockers": []
    },
    {
      "file": "KillAllProcesses.xaml",
      "level": "studio-clean",
      "blockers": []
    },
    {
      "file": "Init.xaml",
      "level": "studio-blocked",
      "blockers": [
        "[CATALOG_STRUCTURAL_VIOLATION] Property \"To\" on Assign must be a child element, not an attribute",
        "[CATALOG_STRUCTURAL_VIOLATION] Property \"Value\" on Assign must be a child element, not an attribute",
        "[CATALOG_STRUCTURAL_VIOLATION] Property \"Exception\" on Throw must be a child element, not an attribute"
      ]
    },
    {
      "file": "CoupaSessionManager.xaml",
      "level": "studio-blocked",
      "blockers": [
        "[GENERATION-FAILURE] Workflow generation failed — LLM output could not be parsed into valid XAML"
      ],
      "failureCategory": "generation-failure",
      "failureSummary": "Workflow generation failed — LLM output could not be parsed into valid XAML"
    },
    {
      "file": "Dispatcher.xaml",
      "level": "studio-blocked",
      "blockers": [
        "[GENERATION-FAILURE] Workflow generation failed — LLM output could not be parsed into valid XAML"
      ],
      "failureCategory": "generation-failure",
      "failureSummary": "Workflow generation failed — LLM output could not be parsed into valid XAML"
    },
    {
      "file": "InitPerformer.xaml",
      "level": "studio-blocked",
      "blockers": [
        "[GENERATION-FAILURE] Workflow generation failed — LLM output could not be parsed into valid XAML"
      ],
      "failureCategory": "generation-failure",
      "failureSummary": "Workflow generation failed — LLM output could not be parsed into valid XAML"
    },
    {
      "file": "ProcessInvoice.xaml",
      "level": "studio-blocked",
      "blockers": [
        "[GENERATION-FAILURE] Workflow generation failed — LLM output could not be parsed into valid XAML"
      ],
      "failureCategory": "generation-failure",
      "failureSummary": "Workflow generation failed — LLM output could not be parsed into valid XAML"
    },
    {
      "file": "ActionCenterTaskCreator.xaml",
      "level": "studio-blocked",
      "blockers": [
        "[GENERATION-FAILURE] Workflow generation failed — LLM output could not be parsed into valid XAML"
      ],
      "failureCategory": "generation-failure",
      "failureSummary": "Workflow generation failed — LLM output could not be parsed into valid XAML"
    },
    {
      "file": "ActionCenterCallbackHandler.xaml",
      "level": "studio-blocked",
      "blockers": [
        "[GENERATION-FAILURE] Workflow generation failed — LLM output could not be parsed into valid XAML"
      ],
      "failureCategory": "generation-failure",
      "failureSummary": "Workflow generation failed — LLM output could not be parsed into valid XAML"
    }
  ],
  "invokeContractTrace": [
    {
      "callerWorkflow": "Main.xaml",
      "targetWorkflow": "Init",
      "targetDeclaredArguments": [
        "in_Config",
        "io_Config"
      ],
      "providedBindings": {
        "Nothing": "[dict_Config]"
      },
      "unknownTargetArguments": [
        "Nothing"
      ],
      "missingRequiredArguments": [
        "in_Config"
      ],
      "undeclaredSymbols": []
    },
    {
      "callerWorkflow": "Main.xaml",
      "targetWorkflow": "GetTransactionData",
      "targetDeclaredArguments": [
        "in_QueueName",
        "out_TransactionItem",
        "io_TransactionNumber"
      ],
      "providedBindings": {
        "Nothing": "[int_TransactionNumber]"
      },
      "unknownTargetArguments": [
        "Nothing"
      ],
      "missingRequiredArguments": [
        "in_QueueName"
      ],
      "undeclaredSymbols": []
    },
    {
      "callerWorkflow": "Main.xaml",
      "targetWorkflow": "Process",
      "targetDeclaredArguments": [
        "in_TransactionItem"
      ],
      "providedBindings": {
        "Nothing": "[qi_TransactionItem]"
      },
      "unknownTargetArguments": [
        "Nothing"
      ],
      "missingRequiredArguments": [
        "in_TransactionItem"
      ],
      "undeclaredSymbols": []
    },
    {
      "callerWorkflow": "Main.xaml",
      "targetWorkflow": "SetTransactionStatus",
      "targetDeclaredArguments": [
        "in_TransactionItem",
        "in_Status",
        "in_ErrorMessage"
      ],
      "providedBindings": {
        "Nothing": "\"Successful\""
      },
      "unknownTargetArguments": [
        "Nothing",
        "Nothing"
      ],
      "missingRequiredArguments": [
        "in_TransactionItem",
        "in_Status",
        "in_ErrorMessage",
        "in_TransactionItem",
        "in_Status",
        "in_ErrorMessage"
      ],
      "undeclaredSymbols": []
    },
    {
      "callerWorkflow": "Main.xaml",
      "targetWorkflow": "InitAllSettings",
      "targetDeclaredArguments": [
        "out_Config",
        "in_TransactionItem",
        "in_Status"
      ],
      "providedBindings": {},
      "unknownTargetArguments": [],
      "missingRequiredArguments": [
        "in_TransactionItem",
        "in_Status"
      ],
      "undeclaredSymbols": []
    },
    {
      "callerWorkflow": "Main.xaml",
      "targetWorkflow": "CoupaSessionManager",
      "targetDeclaredArguments": [],
      "providedBindings": {},
      "unknownTargetArguments": [],
      "missingRequiredArguments": [],
      "undeclaredSymbols": []
    },
    {
      "callerWorkflow": "Main.xaml",
      "targetWorkflow": "Dispatcher",
      "targetDeclaredArguments": [],
      "providedBindings": {},
      "unknownTargetArguments": [],
      "missingRequiredArguments": [],
      "undeclaredSymbols": []
    },
    {
      "callerWorkflow": "Main.xaml",
      "targetWorkflow": "InitPerformer",
      "targetDeclaredArguments": [],
      "providedBindings": {},
      "unknownTargetArguments": [],
      "missingRequiredArguments": [],
      "undeclaredSymbols": []
    },
    {
      "callerWorkflow": "Main.xaml",
      "targetWorkflow": "ProcessInvoice",
      "targetDeclaredArguments": [],
      "providedBindings": {},
      "unknownTargetArguments": [],
      "missingRequiredArguments": [],
      "undeclaredSymbols": []
    },
    {
      "callerWorkflow": "Main.xaml",
      "targetWorkflow": "ActionCenterTaskCreator",
      "targetDeclaredArguments": [],
      "providedBindings": {},
      "unknownTargetArguments": [],
      "missingRequiredArguments": [],
      "undeclaredSymbols": []
    },
    {
      "callerWorkflow": "Main.xaml",
      "targetWorkflow": "ActionCenterCallbackHandler",
      "targetDeclaredArguments": [],
      "providedBindings": {},
      "unknownTargetArguments": [],
      "missingRequiredArguments": [],
      "undeclaredSymbols": []
    },
    {
      "callerWorkflow": "Main.xaml",
      "targetWorkflow": "SetTransactionStatus",
      "targetDeclaredArguments": [
        "in_TransactionItem",
        "in_Status",
        "in_ErrorMessage"
      ],
      "providedBindings": {
        "Nothing": "\"Failed\""
      },
      "unknownTargetArguments": [
        "Nothing",
        "Nothing"
      ],
      "missingRequiredArguments": [
        "in_TransactionItem",
        "in_Status",
        "in_ErrorMessage",
        "in_TransactionItem",
        "in_Status",
        "in_ErrorMessage"
      ],
      "undeclaredSymbols": []
    },
    {
      "callerWorkflow": "Main.xaml",
      "targetWorkflow": "CloseAllApplications",
      "targetDeclaredArguments": [],
      "providedBindings": {},
      "unknownTargetArguments": [],
      "missingRequiredArguments": [],
      "undeclaredSymbols": []
    },
    {
      "callerWorkflow": "Main.xaml",
      "targetWorkflow": "CloseAllApplications",
      "targetDeclaredArguments": [],
      "providedBindings": {},
      "unknownTargetArguments": [],
      "missingRequiredArguments": [],
      "undeclaredSymbols": []
    },
    {
      "callerWorkflow": "CloseAllApplications.xaml",
      "targetWorkflow": "KillAllProcesses",
      "targetDeclaredArguments": [],
      "providedBindings": {},
      "unknownTargetArguments": [],
      "missingRequiredArguments": [],
      "undeclaredSymbols": []
    },
    {
      "callerWorkflow": "Init.xaml",
      "targetWorkflow": "InitAllSettings",
      "targetDeclaredArguments": [
        "out_Config",
        "in_TransactionItem",
        "in_Status"
      ],
      "providedBindings": {
        "Nothing": "[dict_Config]"
      },
      "unknownTargetArguments": [
        "Nothing"
      ],
      "missingRequiredArguments": [
        "in_TransactionItem",
        "in_Status"
      ],
      "undeclaredSymbols": []
    }
  ],
  "stageHashParity": [
    {
      "workflowFile": "CoupaSessionManager.xaml",
      "postGeneration": "49522f0179626a803dc0e0c015be64a9bd19b25546e38aa1f016bb0232911067",
      "postRepair": "49522f0179626a803dc0e0c015be64a9bd19b25546e38aa1f016bb0232911067",
      "postNormalization": "aebaea901fb4ecbc6428399e7367f79a73b4ea6e8a7b34e8760a00e8dca6431b",
      "preCanonicalization": "aebaea901fb4ecbc6428399e7367f79a73b4ea6e8a7b34e8760a00e8dca6431b",
      "archivedFile": "ac4f7a40c272d08e7b93869945092b52e5cd0b721557c04d7c2ba527fe2ab744",
      "postFinalValidationInput": "ac4f7a40c272d08e7b93869945092b52e5cd0b721557c04d7c2ba527fe2ab744",
      "preArchive": "ac4f7a40c272d08e7b93869945092b52e5cd0b721557c04d7c2ba527fe2ab744"
    },
    {
      "workflowFile": "Dispatcher.xaml",
      "postGeneration": "d9088fa38c2164e9cb5317b9efa7c07b99a0d7c487d48801f0860cf041402361",
      "postRepair": "d9088fa38c2164e9cb5317b9efa7c07b99a0d7c487d48801f0860cf041402361",
      "postNormalization": "4b65cab9ba31553d3de89a04a1542e7715246cd7a478d4d9a81198421720220c",
      "preCanonicalization": "4b65cab9ba31553d3de89a04a1542e7715246cd7a478d4d9a81198421720220c",
      "archivedFile": "40c09b9f670344b0e461a71b48a9d32632cf9c611a02083370d68ed1cf3afb60",
      "postFinalValidationInput": "40c09b9f670344b0e461a71b48a9d32632cf9c611a02083370d68ed1cf3afb60",
      "preArchive": "40c09b9f670344b0e461a71b48a9d32632cf9c611a02083370d68ed1cf3afb60"
    },
    {
      "workflowFile": "InitPerformer.xaml",
      "postGeneration": "704fae1e753717e96457f494876a5414726f07a43e34a0570ec96ed49a97b5f5",
      "postRepair": "704fae1e753717e96457f494876a5414726f07a43e34a0570ec96ed49a97b5f5",
      "postNormalization": "59fd7d794558fde0e1c074c5a4a1dee65cd3383da74dbf8880d221725991a6cc",
      "preCanonicalization": "59fd7d794558fde0e1c074c5a4a1dee65cd3383da74dbf8880d221725991a6cc",
      "archivedFile": "7d8ad75a18bd9fa24c6ab01f5fbefcbbc6d70abde33bb9ff76c23ffc966d534a",
      "postFinalValidationInput": "7d8ad75a18bd9fa24c6ab01f5fbefcbbc6d70abde33bb9ff76c23ffc966d534a",
      "preArchive": "7d8ad75a18bd9fa24c6ab01f5fbefcbbc6d70abde33bb9ff76c23ffc966d534a"
    },
    {
      "workflowFile": "ProcessInvoice.xaml",
      "postGeneration": "4a58c23e85f36c00a734db0610c6177469be8794f574eea068c69ee65c2578f1",
      "postRepair": "4a58c23e85f36c00a734db0610c6177469be8794f574eea068c69ee65c2578f1",
      "postNormalization": "47bd3c33e1e8d82d0d4d9555c589e9f92d6f6a6d3419a0ef262ab4ff591858fd",
      "preCanonicalization": "47bd3c33e1e8d82d0d4d9555c589e9f92d6f6a6d3419a0ef262ab4ff591858fd",
      "archivedFile": "13a18f3f9fa89aabdc42ef25ad680c631a3a47653a726d081da36d685157adeb",
      "postFinalValidationInput": "13a18f3f9fa89aabdc42ef25ad680c631a3a47653a726d081da36d685157adeb",
      "preArchive": "13a18f3f9fa89aabdc42ef25ad680c631a3a47653a726d081da36d685157adeb"
    },
    {
      "workflowFile": "ActionCenterTaskCreator.xaml",
      "postGeneration": "0bda756e92e4be337e80e10852474337ecb3f53ec0c562250975450a726847fa",
      "postRepair": "0bda756e92e4be337e80e10852474337ecb3f53ec0c562250975450a726847fa",
      "postNormalization": "574b00c61bea8c161298e11a1a9532cc1691a203080cf44f140f63a68601d341",
      "preCanonicalization": "574b00c61bea8c161298e11a1a9532cc1691a203080cf44f140f63a68601d341",
      "archivedFile": "bce9f4dc2cb1317ca5276d679cebf39bdd488ff0d994e33ba831382aa0eaa416",
      "postFinalValidationInput": "bce9f4dc2cb1317ca5276d679cebf39bdd488ff0d994e33ba831382aa0eaa416",
      "preArchive": "bce9f4dc2cb1317ca5276d679cebf39bdd488ff0d994e33ba831382aa0eaa416"
    },
    {
      "workflowFile": "ActionCenterCallbackHandler.xaml",
      "postGeneration": "2c03d5d167110e60449454c9be031467454d3508b29de1a1a7391a8bf744d1b7",
      "postRepair": "2c03d5d167110e60449454c9be031467454d3508b29de1a1a7391a8bf744d1b7",
      "postNormalization": "bca00b23bc0b4d29d6bff6bad5c5259b46aafa055d02c4e4d7e78a458bdc1e9b",
      "preCanonicalization": "bca00b23bc0b4d29d6bff6bad5c5259b46aafa055d02c4e4d7e78a458bdc1e9b",
      "archivedFile": "fed1fece0b925c9a0f3988b11dd468f2f7499163a906bb72da87c5544cb8ee38",
      "postFinalValidationInput": "fed1fece0b925c9a0f3988b11dd468f2f7499163a906bb72da87c5544cb8ee38",
      "preArchive": "fed1fece0b925c9a0f3988b11dd468f2f7499163a906bb72da87c5544cb8ee38"
    },
    {
      "workflowFile": "Main.xaml",
      "postGeneration": "4e3de5417557b8facfe246350329deca0c1b5408d3555e3a313b75aa2c39f61a",
      "postRepair": "4e3de5417557b8facfe246350329deca0c1b5408d3555e3a313b75aa2c39f61a",
      "postNormalization": "65033d643958cd41e6db835211fee2244a31c6bba515901ef49ed6e8b6c1bebd",
      "preCanonicalization": "65033d643958cd41e6db835211fee2244a31c6bba515901ef49ed6e8b6c1bebd",
      "archivedFile": "f84ecb9786a94e73a68b02245542149f421a71edf25b38647ce2366e451ac6ea",
      "postFinalValidationInput": "f84ecb9786a94e73a68b02245542149f421a71edf25b38647ce2366e451ac6ea",
      "preArchive": "f84ecb9786a94e73a68b02245542149f421a71edf25b38647ce2366e451ac6ea"
    },
    {
      "workflowFile": "Process.xaml",
      "postGeneration": "e565a716f91d0bf197b7ebe30989066da76c01f76a21c0bc2478a012468f0ee3",
      "postRepair": "e565a716f91d0bf197b7ebe30989066da76c01f76a21c0bc2478a012468f0ee3",
      "postNormalization": "e565a716f91d0bf197b7ebe30989066da76c01f76a21c0bc2478a012468f0ee3",
      "preCanonicalization": "11102051d2210cb8e76b64c59274afc4bbdbbbf4f24df53bc7aac08a51de3e06",
      "archivedFile": "829d105bbbb6f2e7a6364c6cd1351d787719d50a5a8d6cc2edf00a7f39134907",
      "postFinalValidationInput": "829d105bbbb6f2e7a6364c6cd1351d787719d50a5a8d6cc2edf00a7f39134907",
      "preArchive": "829d105bbbb6f2e7a6364c6cd1351d787719d50a5a8d6cc2edf00a7f39134907"
    },
    {
      "workflowFile": "InitAllSettings.xaml",
      "postGeneration": "fb9e5a14dd4888a974e0cbfaadd74be0290b449d24820e98fa6d401e5534ecbf",
      "postRepair": "fb9e5a14dd4888a974e0cbfaadd74be0290b449d24820e98fa6d401e5534ecbf",
      "postNormalization": "c115894deac39570582591cd878879c213961b7f24c790afa9d36bb4ee0099b5",
      "preCanonicalization": "a5593ec0010278c233a441d106ce5baaa20b5a5db0fd41ff5df7f6b395f900cc",
      "archivedFile": "a5593ec0010278c233a441d106ce5baaa20b5a5db0fd41ff5df7f6b395f900cc",
      "postFinalValidationInput": "a5593ec0010278c233a441d106ce5baaa20b5a5db0fd41ff5df7f6b395f900cc",
      "preArchive": "a5593ec0010278c233a441d106ce5baaa20b5a5db0fd41ff5df7f6b395f900cc"
    },
    {
      "workflowFile": "GetTransactionData.xaml",
      "postGeneration": "36e01376637da856cd901a32fe16d33294da06bcced0df8a1b36d98ff186b4fc",
      "postRepair": "36e01376637da856cd901a32fe16d33294da06bcced0df8a1b36d98ff186b4fc",
      "postNormalization": "7150edd3b90e8ba2e95ace071e17c76a10d53da263e2e0cdeba88f3ddcd9d686",
      "preCanonicalization": "7150edd3b90e8ba2e95ace071e17c76a10d53da263e2e0cdeba88f3ddcd9d686",
      "archivedFile": "7150edd3b90e8ba2e95ace071e17c76a10d53da263e2e0cdeba88f3ddcd9d686",
      "postFinalValidationInput": "7150edd3b90e8ba2e95ace071e17c76a10d53da263e2e0cdeba88f3ddcd9d686",
      "preArchive": "7150edd3b90e8ba2e95ace071e17c76a10d53da263e2e0cdeba88f3ddcd9d686"
    },
    {
      "workflowFile": "Init.xaml",
      "postGeneration": "59937d8b7a8ccb91771dafe3273b012e5a2a6cbc0c3850c53980d22d718afc7a",
      "postRepair": "59937d8b7a8ccb91771dafe3273b012e5a2a6cbc0c3850c53980d22d718afc7a",
      "postNormalization": "59937d8b7a8ccb91771dafe3273b012e5a2a6cbc0c3850c53980d22d718afc7a",
      "preCanonicalization": "59937d8b7a8ccb91771dafe3273b012e5a2a6cbc0c3850c53980d22d718afc7a",
      "archivedFile": "f44213c3e46b46c17650f45dfdfe51edffafbd18cc4a5294d890a3dd0b9b38bf",
      "postFinalValidationInput": "f44213c3e46b46c17650f45dfdfe51edffafbd18cc4a5294d890a3dd0b9b38bf",
      "preArchive": "f44213c3e46b46c17650f45dfdfe51edffafbd18cc4a5294d890a3dd0b9b38bf"
    }
  ],
  "preEmissionValidation": {
    "totalActivities": 0,
    "validActivities": 0,
    "unknownActivities": 0,
    "strippedProperties": 0,
    "enumCorrections": 0,
    "missingRequiredFilled": 0,
    "commentConversions": 0,
    "issueCount": 0
  },
  "invokeSerializationFixes": [],
  "expressionCanonicalizationFixes": [],
  "symbolScopeDefects": [
    {
      "file": "lib/net45/Main.xaml",
      "workflow": "Main",
      "activityType": "InOutArgument",
      "propertyName": "Key",
      "referencedSymbol": "io_Config",
      "offendingExpression": "io_Config",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "undeclared_argument_reference",
      "severity": "handoff_required",
      "rationale": "Argument \"io_Config\" referenced in Key but not declared in workflow \"Main\" — expression replaced with \"Nothing\""
    },
    {
      "file": "lib/net45/Main.xaml",
      "workflow": "Main",
      "activityType": "InArgument",
      "propertyName": "Key",
      "referencedSymbol": "in_QueueName",
      "offendingExpression": "in_QueueName",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "undeclared_argument_reference",
      "severity": "handoff_required",
      "rationale": "Argument \"in_QueueName\" referenced in Key but not declared in workflow \"Main\" — expression replaced with \"Nothing\""
    },
    {
      "file": "lib/net45/Main.xaml",
      "workflow": "Main",
      "activityType": "OutArgument",
      "propertyName": "Key",
      "referencedSymbol": "out_TransactionItem",
      "offendingExpression": "out_TransactionItem",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "undeclared_argument_reference",
      "severity": "handoff_required",
      "rationale": "Argument \"out_TransactionItem\" referenced in Key but not declared in workflow \"Main\" — expression replaced with \"Nothing\""
    },
    {
      "file": "lib/net45/Main.xaml",
      "workflow": "Main",
      "activityType": "InOutArgument",
      "propertyName": "Key",
      "referencedSymbol": "io_TransactionNumber",
      "offendingExpression": "io_TransactionNumber",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "undeclared_argument_reference",
      "severity": "handoff_required",
      "rationale": "Argument \"io_TransactionNumber\" referenced in Key but not declared in workflow \"Main\" — expression replaced with \"Nothing\""
    },
    {
      "file": "lib/net45/Main.xaml",
      "workflow": "Main",
      "activityType": "InArgument",
      "propertyName": "Key",
      "referencedSymbol": "in_TransactionItem",
      "offendingExpression": "in_TransactionItem",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "undeclared_argument_reference",
      "severity": "handoff_required",
      "rationale": "Argument \"in_TransactionItem\" referenced in Key but not declared in workflow \"Main\" — expression replaced with \"Nothing\""
    },
    {
      "file": "lib/net45/Main.xaml",
      "workflow": "Main",
      "activityType": "InArgument",
      "propertyName": "Key",
      "referencedSymbol": "in_TransactionItem",
      "offendingExpression": "in_TransactionItem",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "undeclared_argument_reference",
      "severity": "handoff_required",
      "rationale": "Argument \"in_TransactionItem\" referenced in Key but not declared in workflow \"Main\" — expression replaced with \"Nothing\""
    },
    {
      "file": "lib/net45/Main.xaml",
      "workflow": "Main",
      "activityType": "InArgument",
      "propertyName": "Key",
      "referencedSymbol": "in_Status",
      "offendingExpression": "in_Status",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "undeclared_argument_reference",
      "severity": "handoff_required",
      "rationale": "Argument \"in_Status\" referenced in Key but not declared in workflow \"Main\" — expression replaced with \"Nothing\""
    },
    {
      "file": "lib/net45/Main.xaml",
      "workflow": "Main",
      "activityType": "InArgument",
      "propertyName": "Key",
      "referencedSymbol": "in_TransactionItem",
      "offendingExpression": "in_TransactionItem",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "undeclared_argument_reference",
      "severity": "handoff_required",
      "rationale": "Argument \"in_TransactionItem\" referenced in Key but not declared in workflow \"Main\" — expression replaced with \"Nothing\""
    },
    {
      "file": "lib/net45/Main.xaml",
      "workflow": "Main",
      "activityType": "InArgument",
      "propertyName": "Key",
      "referencedSymbol": "in_Status",
      "offendingExpression": "in_Status",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "undeclared_argument_reference",
      "severity": "handoff_required",
      "rationale": "Argument \"in_Status\" referenced in Key but not declared in workflow \"Main\" — expression replaced with \"Nothing\""
    },
    {
      "file": "lib/net45/Process.xaml",
      "workflow": "Process",
      "activityType": "If",
      "propertyName": "Condition",
      "referencedSymbol": "Yes",
      "offendingExpression": "[Yes]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "False",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"Yes\" referenced in Condition but not declared in workflow \"Process\" — expression replaced with \"False\""
    },
    {
      "file": "lib/net45/Process.xaml",
      "workflow": "Process",
      "activityType": "If",
      "propertyName": "Condition",
      "referencedSymbol": "Provide",
      "offendingExpression": "[Provide Data]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "False",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"Provide\" referenced in Condition but not declared in workflow \"Process\" — expression replaced with \"False\""
    },
    {
      "file": "lib/net45/Process.xaml",
      "workflow": "Process",
      "activityType": "If",
      "propertyName": "Condition",
      "referencedSymbol": "Data",
      "offendingExpression": "[Provide Data]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "False",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"Data\" referenced in Condition but not declared in workflow \"Process\" — expression replaced with \"False\""
    },
    {
      "file": "lib/net45/Process.xaml",
      "workflow": "Process",
      "activityType": "If",
      "propertyName": "Condition",
      "referencedSymbol": "Yes",
      "offendingExpression": "[Yes]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "False",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"Yes\" referenced in Condition but not declared in workflow \"Process\" — expression replaced with \"False\""
    },
    {
      "file": "lib/net45/Process.xaml",
      "workflow": "Process",
      "activityType": "If",
      "propertyName": "Condition",
      "referencedSymbol": "Yes",
      "offendingExpression": "[Yes]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "False",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"Yes\" referenced in Condition but not declared in workflow \"Process\" — expression replaced with \"False\""
    },
    {
      "file": "lib/net45/Process.xaml",
      "workflow": "Process",
      "activityType": "If",
      "propertyName": "Condition",
      "referencedSymbol": "Approved",
      "offendingExpression": "[Approved]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "False",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"Approved\" referenced in Condition but not declared in workflow \"Process\" — expression replaced with \"False\""
    },
    {
      "file": "lib/net45/Init.xaml",
      "workflow": "Init",
      "activityType": "OutArgument",
      "propertyName": "Key",
      "referencedSymbol": "out_Config",
      "offendingExpression": "out_Config",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "undeclared_argument_reference",
      "severity": "handoff_required",
      "rationale": "Argument \"out_Config\" referenced in Key but not declared in workflow \"Init\" — expression replaced with \"Nothing\""
    }
  ],
  "targetValueCanonicalizationSummary": "Target/value canonicalization: 0 expression fix(es), 16 symbol scope defect(s), 6 sentinel replacement(s), 0 unresolvable JSON defect(s)",
  "residualExpressionSerializationDefects": [
    {
      "file": "lib/net45/CoupaSessionManager.xaml",
      "workflow": "CoupaSessionManager",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "originalValue": "[&quot;STUB: CoupaSessionManager — this workflow was auto-generated as a placeholder because it is referenced by InvokeWorkflowFile but was not part of the original process map. Implement the actual l",
      "defectType": "placeholder_in_executable",
      "severity": "handoff_required",
      "rationale": "Placeholder sentinel in executable property Message — requires business value"
    },
    {
      "file": "lib/net45/Dispatcher.xaml",
      "workflow": "Dispatcher",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "originalValue": "[&quot;STUB: Dispatcher — this workflow was auto-generated as a placeholder because it is referenced by InvokeWorkflowFile but was not part of the original process map. Implement the actual logic here",
      "defectType": "placeholder_in_executable",
      "severity": "handoff_required",
      "rationale": "Placeholder sentinel in executable property Message — requires business value"
    },
    {
      "file": "lib/net45/InitPerformer.xaml",
      "workflow": "InitPerformer",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "originalValue": "[&quot;STUB: InitPerformer — this workflow was auto-generated as a placeholder because it is referenced by InvokeWorkflowFile but was not part of the original process map. Implement the actual logic h",
      "defectType": "placeholder_in_executable",
      "severity": "handoff_required",
      "rationale": "Placeholder sentinel in executable property Message — requires business value"
    },
    {
      "file": "lib/net45/ProcessInvoice.xaml",
      "workflow": "ProcessInvoice",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "originalValue": "[&quot;STUB: ProcessInvoice — this workflow was auto-generated as a placeholder because it is referenced by InvokeWorkflowFile but was not part of the original process map. Implement the actual logic ",
      "defectType": "placeholder_in_executable",
      "severity": "handoff_required",
      "rationale": "Placeholder sentinel in executable property Message — requires business value"
    },
    {
      "file": "lib/net45/ActionCenterTaskCreator.xaml",
      "workflow": "ActionCenterTaskCreator",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "originalValue": "[&quot;STUB: ActionCenterTaskCreator — this workflow was auto-generated as a placeholder because it is referenced by InvokeWorkflowFile but was not part of the original process map. Implement the actu",
      "defectType": "placeholder_in_executable",
      "severity": "handoff_required",
      "rationale": "Placeholder sentinel in executable property Message — requires business value"
    },
    {
      "file": "lib/net45/ActionCenterCallbackHandler.xaml",
      "workflow": "ActionCenterCallbackHandler",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "originalValue": "[&quot;STUB: ActionCenterCallbackHandler — this workflow was auto-generated as a placeholder because it is referenced by InvokeWorkflowFile but was not part of the original process map. Implement the ",
      "defectType": "placeholder_in_executable",
      "severity": "handoff_required",
      "rationale": "Placeholder sentinel in executable property Message — requires business value"
    }
  ],
  "sentinelReplacements": [
    {
      "file": "lib/net45/CoupaSessionManager.xaml",
      "workflow": "CoupaSessionManager",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "originalValue": "[&quot;STUB: CoupaSessionManager — this workflow was auto-generated as a placeholder because it is referenced by InvokeWorkflowFile but was not part of the original process map. Implement the actual l",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "placeholder_sentinel",
      "severity": "execution_blocking",
      "rationale": "Sentinel \"[&quot;STUB: CoupaSessionManager — this workflow was auto-generated as a placeho\" in executable property Message replaced with platform-safe value \"\"\"\" — not executable, degradation substitute"
    },
    {
      "file": "lib/net45/Dispatcher.xaml",
      "workflow": "Dispatcher",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "originalValue": "[&quot;STUB: Dispatcher — this workflow was auto-generated as a placeholder because it is referenced by InvokeWorkflowFile but was not part of the original process map. Implement the actual logic here",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "placeholder_sentinel",
      "severity": "execution_blocking",
      "rationale": "Sentinel \"[&quot;STUB: Dispatcher — this workflow was auto-generated as a placeholder beca\" in executable property Message replaced with platform-safe value \"\"\"\" — not executable, degradation substitute"
    },
    {
      "file": "lib/net45/InitPerformer.xaml",
      "workflow": "InitPerformer",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "originalValue": "[&quot;STUB: InitPerformer — this workflow was auto-generated as a placeholder because it is referenced by InvokeWorkflowFile but was not part of the original process map. Implement the actual logic h",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "placeholder_sentinel",
      "severity": "execution_blocking",
      "rationale": "Sentinel \"[&quot;STUB: InitPerformer — this workflow was auto-generated as a placeholder b\" in executable property Message replaced with platform-safe value \"\"\"\" — not executable, degradation substitute"
    },
    {
      "file": "lib/net45/ProcessInvoice.xaml",
      "workflow": "ProcessInvoice",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "originalValue": "[&quot;STUB: ProcessInvoice — this workflow was auto-generated as a placeholder because it is referenced by InvokeWorkflowFile but was not part of the original process map. Implement the actual logic ",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "placeholder_sentinel",
      "severity": "execution_blocking",
      "rationale": "Sentinel \"[&quot;STUB: ProcessInvoice — this workflow was auto-generated as a placeholder \" in executable property Message replaced with platform-safe value \"\"\"\" — not executable, degradation substitute"
    },
    {
      "file": "lib/net45/ActionCenterTaskCreator.xaml",
      "workflow": "ActionCenterTaskCreator",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "originalValue": "[&quot;STUB: ActionCenterTaskCreator — this workflow was auto-generated as a placeholder because it is referenced by InvokeWorkflowFile but was not part of the original process map. Implement the actu",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "placeholder_sentinel",
      "severity": "execution_blocking",
      "rationale": "Sentinel \"[&quot;STUB: ActionCenterTaskCreator — this workflow was auto-generated as a pla\" in executable property Message replaced with platform-safe value \"\"\"\" — not executable, degradation substitute"
    },
    {
      "file": "lib/net45/ActionCenterCallbackHandler.xaml",
      "workflow": "ActionCenterCallbackHandler",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "originalValue": "[&quot;STUB: ActionCenterCallbackHandler — this workflow was auto-generated as a placeholder because it is referenced by InvokeWorkflowFile but was not part of the original process map. Implement the ",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "placeholder_sentinel",
      "severity": "execution_blocking",
      "rationale": "Sentinel \"[&quot;STUB: ActionCenterCallbackHandler — this workflow was auto-generated as a\" in executable property Message replaced with platform-safe value \"\"\"\" — not executable, degradation substitute"
    }
  ],
  "unresolvableJsonDefects": [],
  "requiredPropertyBindings": [
    {
      "file": "CoupaSessionManager.xaml",
      "workflow": "CoupaSessionManager",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "",
      "resolvedValue": "",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "",
        "precedenceTier": 4
      }
    },
    {
      "file": "CoupaSessionManager.xaml",
      "workflow": "CoupaSessionManager",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;=== Completed: CoupaSessionManager ===&quot;]",
      "resolvedValue": "[&quot;=== Completed: CoupaSessionManager ===&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 1,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;=== Completed: CoupaSessionManager ===&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "Dispatcher.xaml",
      "workflow": "Dispatcher",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "",
      "resolvedValue": "",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "",
        "precedenceTier": 4
      }
    },
    {
      "file": "Dispatcher.xaml",
      "workflow": "Dispatcher",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;=== Completed: Dispatcher ===&quot;]",
      "resolvedValue": "[&quot;=== Completed: Dispatcher ===&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 1,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;=== Completed: Dispatcher ===&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "InitPerformer.xaml",
      "workflow": "InitPerformer",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "",
      "resolvedValue": "",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "",
        "precedenceTier": 4
      }
    },
    {
      "file": "InitPerformer.xaml",
      "workflow": "InitPerformer",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;=== Completed: InitPerformer ===&quot;]",
      "resolvedValue": "[&quot;=== Completed: InitPerformer ===&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 1,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;=== Completed: InitPerformer ===&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "ProcessInvoice.xaml",
      "workflow": "ProcessInvoice",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "",
      "resolvedValue": "",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "",
        "precedenceTier": 4
      }
    },
    {
      "file": "ProcessInvoice.xaml",
      "workflow": "ProcessInvoice",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;=== Completed: ProcessInvoice ===&quot;]",
      "resolvedValue": "[&quot;=== Completed: ProcessInvoice ===&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 1,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;=== Completed: ProcessInvoice ===&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "ActionCenterTaskCreator.xaml",
      "workflow": "ActionCenterTaskCreator",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "",
      "resolvedValue": "",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "",
        "precedenceTier": 4
      }
    },
    {
      "file": "ActionCenterTaskCreator.xaml",
      "workflow": "ActionCenterTaskCreator",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;=== Completed: ActionCenterTaskCreator ===&quot;]",
      "resolvedValue": "[&quot;=== Completed: ActionCenterTaskCreator ===&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 1,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;=== Completed: ActionCenterTaskCreator ===&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "ActionCenterCallbackHandler.xaml",
      "workflow": "ActionCenterCallbackHandler",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "",
      "resolvedValue": "",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "",
        "precedenceTier": 4
      }
    },
    {
      "file": "ActionCenterCallbackHandler.xaml",
      "workflow": "ActionCenterCallbackHandler",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;=== Completed: ActionCenterCallbackHandler ===&quot;]",
      "resolvedValue": "[&quot;=== Completed: ActionCenterCallbackHandler ===&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 1,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;=== Completed: ActionCenterCallbackHandler ===&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "Main.xaml",
      "workflow": "Main",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;=== Initializing CoupaInvoiceReconV2 ===&quot;]",
      "resolvedValue": "[&quot;=== Initializing CoupaInvoiceReconV2 ===&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;=== Initializing CoupaInvoiceReconV2 ===&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "Main.xaml",
      "workflow": "Main",
      "activityType": "InvokeWorkflowFile",
      "propertyName": "WorkflowFileName",
      "sourceBinding": "attribute-value",
      "originalValue": "Init.xaml",
      "resolvedValue": "Init.xaml",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "Init.xaml",
        "precedenceTier": 4
      }
    },
    {
      "file": "Main.xaml",
      "workflow": "Main",
      "activityType": "Assign",
      "propertyName": "To",
      "sourceBinding": "variable",
      "originalValue": "[bool_SystemReady]",
      "resolvedValue": "[bool_SystemReady]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "variable",
        "sourceName": "bool_SystemReady",
        "sourceWorkflow": "Main",
        "precedenceTier": 2
      }
    },
    {
      "file": "Main.xaml",
      "workflow": "Main",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "True",
      "resolvedValue": "True",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "True",
        "precedenceTier": 4
      }
    },
    {
      "file": "Main.xaml",
      "workflow": "Main",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Initialization complete&quot;]",
      "resolvedValue": "[&quot;Initialization complete&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 1,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Initialization complete&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "Main.xaml",
      "workflow": "Main",
      "activityType": "InvokeWorkflowFile",
      "propertyName": "WorkflowFileName",
      "sourceBinding": "attribute-value",
      "originalValue": "GetTransactionData.xaml",
      "resolvedValue": "GetTransactionData.xaml",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 1,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "GetTransactionData.xaml",
        "precedenceTier": 4
      }
    },
    {
      "file": "Main.xaml",
      "workflow": "Main",
      "activityType": "InvokeWorkflowFile",
      "propertyName": "WorkflowFileName",
      "sourceBinding": "attribute-value",
      "originalValue": "Process.xaml",
      "resolvedValue": "Process.xaml",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 2,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "Process.xaml",
        "precedenceTier": 4
      }
    },
    {
      "file": "Main.xaml",
      "workflow": "Main",
      "activityType": "InvokeWorkflowFile",
      "propertyName": "WorkflowFileName",
      "sourceBinding": "attribute-value",
      "originalValue": "SetTransactionStatus.xaml",
      "resolvedValue": "SetTransactionStatus.xaml",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 3,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "SetTransactionStatus.xaml",
        "precedenceTier": 4
      }
    },
    {
      "file": "Main.xaml",
      "workflow": "Main",
      "activityType": "Assign",
      "propertyName": "To",
      "sourceBinding": "variable",
      "originalValue": "[int_RetryNumber]",
      "resolvedValue": "[int_RetryNumber]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 1,
      "provenance": {
        "sourceKind": "variable",
        "sourceName": "int_RetryNumber",
        "sourceWorkflow": "Main",
        "precedenceTier": 2
      }
    },
    {
      "file": "Main.xaml",
      "workflow": "Main",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "0",
      "resolvedValue": "0",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 1,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "0",
        "precedenceTier": 4
      }
    },
    {
      "file": "Main.xaml",
      "workflow": "Main",
      "activityType": "InvokeWorkflowFile",
      "propertyName": "WorkflowFileName",
      "sourceBinding": "attribute-value",
      "originalValue": "InitAllSettings.xaml",
      "resolvedValue": "InitAllSettings.xaml",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 4,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "InitAllSettings.xaml",
        "precedenceTier": 4
      }
    },
    {
      "file": "Main.xaml",
      "workflow": "Main",
      "activityType": "InvokeWorkflowFile",
      "propertyName": "WorkflowFileName",
      "sourceBinding": "attribute-value",
      "originalValue": "CoupaSessionManager.xaml",
      "resolvedValue": "CoupaSessionManager.xaml",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 5,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "CoupaSessionManager.xaml",
        "precedenceTier": 4
      }
    },
    {
      "file": "Main.xaml",
      "workflow": "Main",
      "activityType": "InvokeWorkflowFile",
      "propertyName": "WorkflowFileName",
      "sourceBinding": "attribute-value",
      "originalValue": "Dispatcher.xaml",
      "resolvedValue": "Dispatcher.xaml",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 6,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "Dispatcher.xaml",
        "precedenceTier": 4
      }
    },
    {
      "file": "Main.xaml",
      "workflow": "Main",
      "activityType": "InvokeWorkflowFile",
      "propertyName": "WorkflowFileName",
      "sourceBinding": "attribute-value",
      "originalValue": "InitPerformer.xaml",
      "resolvedValue": "InitPerformer.xaml",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 7,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "InitPerformer.xaml",
        "precedenceTier": 4
      }
    },
    {
      "file": "Main.xaml",
      "workflow": "Main",
      "activityType": "InvokeWorkflowFile",
      "propertyName": "WorkflowFileName",
      "sourceBinding": "attribute-value",
      "originalValue": "ProcessInvoice.xaml",
      "resolvedValue": "ProcessInvoice.xaml",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 8,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "ProcessInvoice.xaml",
        "precedenceTier": 4
      }
    },
    {
      "file": "Main.xaml",
      "workflow": "Main",
      "activityType": "InvokeWorkflowFile",
      "propertyName": "WorkflowFileName",
      "sourceBinding": "attribute-value",
      "originalValue": "ActionCenterTaskCreator.xaml",
      "resolvedValue": "ActionCenterTaskCreator.xaml",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 9,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "ActionCenterTaskCreator.xaml",
        "precedenceTier": 4
      }
    },
    {
      "file": "Main.xaml",
      "workflow": "Main",
      "activityType": "InvokeWorkflowFile",
      "propertyName": "WorkflowFileName",
      "sourceBinding": "attribute-value",
      "originalValue": "ActionCenterCallbackHandler.xaml",
      "resolvedValue": "ActionCenterCallbackHandler.xaml",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 10,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "ActionCenterCallbackHandler.xaml",
        "precedenceTier": 4
      }
    },
    {
      "file": "Main.xaml",
      "workflow": "Main",
      "activityType": "Assign",
      "propertyName": "To",
      "sourceBinding": "variable",
      "originalValue": "[str_ErrorScreenshotPath]",
      "resolvedValue": "[str_ErrorScreenshotPath]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 2,
      "provenance": {
        "sourceKind": "variable",
        "sourceName": "str_ErrorScreenshotPath",
        "sourceWorkflow": "Main",
        "precedenceTier": 2
      }
    },
    {
      "file": "Main.xaml",
      "workflow": "Main",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "[\"screenshots/error_tx_\" &amp; int_TransactionNumber.ToString &amp; \"_\" &amp; DateTime.Now.ToString(\"yyyyMMdd_HHmmss\") &amp; \".png\"]",
      "resolvedValue": "[\"screenshots/error_tx_\" &amp; int_TransactionNumber.ToString &amp; \"_\" &amp; DateTime.Now.ToString(\"yyyyMMdd_HHmmss\") &amp; \".png\"]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 2,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[\"screenshots/error_tx_\" &amp; int_TransactionNumber.ToString &amp; \"_\" &amp; Da",
        "precedenceTier": 4
      }
    },
    {
      "file": "Main.xaml",
      "workflow": "Main",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot capture failed: &quot; &amp; ssEx.Message]",
      "resolvedValue": "[&quot;Screenshot capture failed: &quot; &amp; ssEx.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 2,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot capture failed: &quot; &amp; ssEx.Message]",
        "precedenceTier": 4
      }
    },
    {
      "file": "Main.xaml",
      "workflow": "Main",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Transaction #&quot; &amp; int_TransactionNumber.ToString &amp; &quot; failed: &quot; &amp; exception.Message &amp; &quot; | Screenshot: &quot; &amp; str_ErrorScreenshotPath]",
      "resolvedValue": "[&quot;Transaction #&quot; &amp; int_TransactionNumber.ToString &amp; &quot; failed: &quot; &amp; exception.Message &amp; &quot; | Screenshot: &quot; &amp; str_ErrorScreenshotPath]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 3,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Transaction #&quot; &amp; int_TransactionNumber.ToString &amp; &quot; fai",
        "precedenceTier": 4
      }
    },
    {
      "file": "Main.xaml",
      "workflow": "Main",
      "activityType": "InvokeWorkflowFile",
      "propertyName": "WorkflowFileName",
      "sourceBinding": "attribute-value",
      "originalValue": "SetTransactionStatus.xaml",
      "resolvedValue": "SetTransactionStatus.xaml",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 11,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "SetTransactionStatus.xaml",
        "precedenceTier": 4
      }
    },
    {
      "file": "Main.xaml",
      "workflow": "Main",
      "activityType": "InvokeWorkflowFile",
      "propertyName": "WorkflowFileName",
      "sourceBinding": "attribute-value",
      "originalValue": "CloseAllApplications.xaml",
      "resolvedValue": "CloseAllApplications.xaml",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 12,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "CloseAllApplications.xaml",
        "precedenceTier": 4
      }
    },
    {
      "file": "Main.xaml",
      "workflow": "Main",
      "activityType": "InvokeWorkflowFile",
      "propertyName": "WorkflowFileName",
      "sourceBinding": "attribute-value",
      "originalValue": "CloseAllApplications.xaml",
      "resolvedValue": "CloseAllApplications.xaml",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 13,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "CloseAllApplications.xaml",
        "precedenceTier": 4
      }
    },
    {
      "file": "Main.xaml",
      "workflow": "Main",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;=== CoupaInvoiceReconV2 Complete. Transactions processed: &quot; &amp; int_TransactionNumber.ToString]",
      "resolvedValue": "[&quot;=== CoupaInvoiceReconV2 Complete. Transactions processed: &quot; &amp; int_TransactionNumber.ToString]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 4,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;=== CoupaInvoiceReconV2 Complete. Transactions processed: &quot; &amp; in",
        "precedenceTier": 4
      }
    },
    {
      "file": "Process.xaml",
      "workflow": "Process",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;=== Starting: Process ===&quot;]",
      "resolvedValue": "[&quot;=== Starting: Process ===&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;=== Starting: Process ===&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "Process.xaml",
      "workflow": "Process",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Initialization: Invoice Submitted in Coupa&quot;]",
      "resolvedValue": "[&quot;Initialization: Invoice Submitted in Coupa&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 1,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Initialization: Invoice Submitted in Coupa&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "Process.xaml",
      "workflow": "Process",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "&quot;Executing: Ingest New Invoice Event&quot;",
      "resolvedValue": "&quot;Executing: Ingest New Invoice Event&quot;",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 2,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "&quot;Executing: Ingest New Invoice Event&quot;",
        "precedenceTier": 4
      }
    },
    {
      "file": "Process.xaml",
      "workflow": "Process",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "&quot;Executing: Get Invoice Header Data (PO, amount, supplier)&quot;",
      "resolvedValue": "&quot;Executing: Get Invoice Header Data (PO, amount, supplier)&quot;",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 3,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "&quot;Executing: Get Invoice Header Data (PO, amount, supplier)&quot;",
        "precedenceTier": 4
      }
    },
    {
      "file": "Process.xaml",
      "workflow": "Process",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "&quot;Executing: Validate PO Exists in Coupa&quot;",
      "resolvedValue": "&quot;Executing: Validate PO Exists in Coupa&quot;",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 4,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "&quot;Executing: Validate PO Exists in Coupa&quot;",
        "precedenceTier": 4
      }
    },
    {
      "file": "Process.xaml",
      "workflow": "Process",
      "activityType": "CreateFormTask",
      "propertyName": "Title",
      "sourceBinding": "variable",
      "originalValue": "[str_TaskTitle]",
      "resolvedValue": "[str_TaskTitle]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "variable",
        "sourceName": "str_TaskTitle",
        "sourceWorkflow": "Process",
        "precedenceTier": 2
      }
    },
    {
      "file": "Process.xaml",
      "workflow": "Process",
      "activityType": "CreateFormTask",
      "propertyName": "FormSchemaPath",
      "sourceBinding": "attribute-value",
      "originalValue": "&quot;TODO: Set form schema path&quot;",
      "resolvedValue": "&quot;TODO: Set form schema path&quot;",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "&quot;TODO: Set form schema path&quot;",
        "precedenceTier": 4
      }
    },
    {
      "file": "Process.xaml",
      "workflow": "Process",
      "activityType": "CreateFormTask",
      "propertyName": "TaskPriority",
      "sourceBinding": "attribute-value",
      "originalValue": "Normal",
      "resolvedValue": "Normal",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "Normal",
        "precedenceTier": 4
      }
    },
    {
      "file": "Process.xaml",
      "workflow": "Process",
      "activityType": "CreateFormTask",
      "propertyName": "TaskTitle",
      "sourceBinding": "variable",
      "originalValue": "[str_TaskTitle]",
      "resolvedValue": "[str_TaskTitle]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "variable",
        "sourceName": "str_TaskTitle",
        "sourceWorkflow": "Process",
        "precedenceTier": 2
      }
    },
    {
      "file": "Process.xaml",
      "workflow": "Process",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "&quot;Executing: Validate PO Exists in Coupa&quot;",
      "resolvedValue": "&quot;Executing: Validate PO Exists in Coupa&quot;",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 5,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "&quot;Executing: Validate PO Exists in Coupa&quot;",
        "precedenceTier": 4
      }
    },
    {
      "file": "Process.xaml",
      "workflow": "Process",
      "activityType": "CreateFormTask",
      "propertyName": "Title",
      "sourceBinding": "variable",
      "originalValue": "[str_TaskTitle]",
      "resolvedValue": "[str_TaskTitle]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 1,
      "provenance": {
        "sourceKind": "variable",
        "sourceName": "str_TaskTitle",
        "sourceWorkflow": "Process",
        "precedenceTier": 2
      }
    },
    {
      "file": "Process.xaml",
      "workflow": "Process",
      "activityType": "CreateFormTask",
      "propertyName": "FormSchemaPath",
      "sourceBinding": "attribute-value",
      "originalValue": "&quot;TODO: Set form schema path&quot;",
      "resolvedValue": "&quot;TODO: Set form schema path&quot;",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 1,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "&quot;TODO: Set form schema path&quot;",
        "precedenceTier": 4
      }
    },
    {
      "file": "Process.xaml",
      "workflow": "Process",
      "activityType": "CreateFormTask",
      "propertyName": "TaskPriority",
      "sourceBinding": "attribute-value",
      "originalValue": "Normal",
      "resolvedValue": "Normal",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 1,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "Normal",
        "precedenceTier": 4
      }
    },
    {
      "file": "Process.xaml",
      "workflow": "Process",
      "activityType": "CreateFormTask",
      "propertyName": "TaskTitle",
      "sourceBinding": "variable",
      "originalValue": "[str_TaskTitle]",
      "resolvedValue": "[str_TaskTitle]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 1,
      "provenance": {
        "sourceKind": "variable",
        "sourceName": "str_TaskTitle",
        "sourceWorkflow": "Process",
        "precedenceTier": 2
      }
    },
    {
      "file": "Process.xaml",
      "workflow": "Process",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot captured for error diagnostics&quot;]",
      "resolvedValue": "[&quot;Screenshot captured for error diagnostics&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 6,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot captured for error diagnostics&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "Process.xaml",
      "workflow": "Process",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
      "resolvedValue": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 7,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
        "precedenceTier": 4
      }
    },
    {
      "file": "Process.xaml",
      "workflow": "Process",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;[Error] Route to AP Exception Review (missing data) failed (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "resolvedValue": "[&quot;[Error] Route to AP Exception Review (missing data) failed (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 8,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;[Error] Route to AP Exception Review (missing data) failed (&quot; &amp; ",
        "precedenceTier": 4
      }
    },
    {
      "file": "Process.xaml",
      "workflow": "Process",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Then branch: AP Provides Missing Data / Confirms Rejection&quot;]",
      "resolvedValue": "[&quot;Then branch: AP Provides Missing Data / Confirms Rejection&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 9,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Then branch: AP Provides Missing Data / Confirms Rejection&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "Process.xaml",
      "workflow": "Process",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "&quot;Executing: Update Invoice Data in Coupa&quot;",
      "resolvedValue": "&quot;Executing: Update Invoice Data in Coupa&quot;",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 10,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "&quot;Executing: Update Invoice Data in Coupa&quot;",
        "precedenceTier": 4
      }
    },
    {
      "file": "Process.xaml",
      "workflow": "Process",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "&quot;Executing: Reject Invoice in Coupa (insufficient data)&quot;",
      "resolvedValue": "&quot;Executing: Reject Invoice in Coupa (insufficient data)&quot;",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 11,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "&quot;Executing: Reject Invoice in Coupa (insufficient data)&quot;",
        "precedenceTier": 4
      }
    },
    {
      "file": "Process.xaml",
      "workflow": "Process",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "&quot;Executing: Update Invoice Data in Coupa&quot;",
      "resolvedValue": "&quot;Executing: Update Invoice Data in Coupa&quot;",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 12,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "&quot;Executing: Update Invoice Data in Coupa&quot;",
        "precedenceTier": 4
      }
    },
    {
      "file": "Process.xaml",
      "workflow": "Process",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "&quot;Executing: Reject Invoice in Coupa (insufficient data)&quot;",
      "resolvedValue": "&quot;Executing: Reject Invoice in Coupa (insufficient data)&quot;",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 13,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "&quot;Executing: Reject Invoice in Coupa (insufficient data)&quot;",
        "precedenceTier": 4
      }
    },
    {
      "file": "Process.xaml",
      "workflow": "Process",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "&quot;Executing: Calculate Amount Variance vs PO&quot;",
      "resolvedValue": "&quot;Executing: Calculate Amount Variance vs PO&quot;",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 14,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "&quot;Executing: Calculate Amount Variance vs PO&quot;",
        "precedenceTier": 4
      }
    },
    {
      "file": "Process.xaml",
      "workflow": "Process",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "&quot;Executing: Reject Invoice in Coupa (PO mismatch)&quot;",
      "resolvedValue": "&quot;Executing: Reject Invoice in Coupa (PO mismatch)&quot;",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 15,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "&quot;Executing: Reject Invoice in Coupa (PO mismatch)&quot;",
        "precedenceTier": 4
      }
    },
    {
      "file": "Process.xaml",
      "workflow": "Process",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "&quot;Executing: Calculate Amount Variance vs PO&quot;",
      "resolvedValue": "&quot;Executing: Calculate Amount Variance vs PO&quot;",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 16,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "&quot;Executing: Calculate Amount Variance vs PO&quot;",
        "precedenceTier": 4
      }
    },
    {
      "file": "Process.xaml",
      "workflow": "Process",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "&quot;Executing: Reject Invoice in Coupa (PO mismatch)&quot;",
      "resolvedValue": "&quot;Executing: Reject Invoice in Coupa (PO mismatch)&quot;",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 17,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "&quot;Executing: Reject Invoice in Coupa (PO mismatch)&quot;",
        "precedenceTier": 4
      }
    },
    {
      "file": "Process.xaml",
      "workflow": "Process",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "&quot;Executing: Route Invoice for Approval (per DOA)&quot;",
      "resolvedValue": "&quot;Executing: Route Invoice for Approval (per DOA)&quot;",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 18,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "&quot;Executing: Route Invoice for Approval (per DOA)&quot;",
        "precedenceTier": 4
      }
    },
    {
      "file": "Process.xaml",
      "workflow": "Process",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "&quot;Executing: Reject Invoice in Coupa (out of tolerance)&quot;",
      "resolvedValue": "&quot;Executing: Reject Invoice in Coupa (out of tolerance)&quot;",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 19,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "&quot;Executing: Reject Invoice in Coupa (out of tolerance)&quot;",
        "precedenceTier": 4
      }
    },
    {
      "file": "Process.xaml",
      "workflow": "Process",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "&quot;Executing: Route Invoice for Approval (per DOA)&quot;",
      "resolvedValue": "&quot;Executing: Route Invoice for Approval (per DOA)&quot;",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 20,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "&quot;Executing: Route Invoice for Approval (per DOA)&quot;",
        "precedenceTier": 4
      }
    },
    {
      "file": "Process.xaml",
      "workflow": "Process",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "&quot;Executing: Invoice Progressed to Next Stage End&quot;",
      "resolvedValue": "&quot;Executing: Invoice Progressed to Next Stage End&quot;",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 21,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "&quot;Executing: Invoice Progressed to Next Stage End&quot;",
        "precedenceTier": 4
      }
    },
    {
      "file": "Process.xaml",
      "workflow": "Process",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "&quot;Executing: Reject Invoice in Coupa (DOA rejected)&quot;",
      "resolvedValue": "&quot;Executing: Reject Invoice in Coupa (DOA rejected)&quot;",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 22,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "&quot;Executing: Reject Invoice in Coupa (DOA rejected)&quot;",
        "precedenceTier": 4
      }
    },
    {
      "file": "Process.xaml",
      "workflow": "Process",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "&quot;Executing: Reject Invoice in Coupa (DOA rejected)&quot;",
      "resolvedValue": "&quot;Executing: Reject Invoice in Coupa (DOA rejected)&quot;",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 23,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "&quot;Executing: Reject Invoice in Coupa (DOA rejected)&quot;",
        "precedenceTier": 4
      }
    },
    {
      "file": "Process.xaml",
      "workflow": "Process",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "&quot;Executing: Reject Invoice in Coupa (out of tolerance)&quot;",
      "resolvedValue": "&quot;Executing: Reject Invoice in Coupa (out of tolerance)&quot;",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 24,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "&quot;Executing: Reject Invoice in Coupa (out of tolerance)&quot;",
        "precedenceTier": 4
      }
    },
    {
      "file": "Process.xaml",
      "workflow": "Process",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "&quot;Executing: Coupa Sends Rejection Notification to Supplier&quot;",
      "resolvedValue": "&quot;Executing: Coupa Sends Rejection Notification to Supplier&quot;",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 25,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "&quot;Executing: Coupa Sends Rejection Notification to Supplier&quot;",
        "precedenceTier": 4
      }
    },
    {
      "file": "Process.xaml",
      "workflow": "Process",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Completed: Invoice Progressed to Next Stage End&quot;]",
      "resolvedValue": "[&quot;Completed: Invoice Progressed to Next Stage End&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 26,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Completed: Invoice Progressed to Next Stage End&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "Process.xaml",
      "workflow": "Process",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Completed: Invoice Rejected End&quot;]",
      "resolvedValue": "[&quot;Completed: Invoice Rejected End&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 27,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Completed: Invoice Rejected End&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "Process.xaml",
      "workflow": "Process",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;=== Completed: Process ===&quot;]",
      "resolvedValue": "[&quot;=== Completed: Process ===&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 28,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;=== Completed: Process ===&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "InitAllSettings.xaml",
      "workflow": "InitAllSettings",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Reading configuration from Config.xlsx...&quot;]",
      "resolvedValue": "[&quot;Reading configuration from Config.xlsx...&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Reading configuration from Config.xlsx...&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "InitAllSettings.xaml",
      "workflow": "InitAllSettings",
      "activityType": "ExcelApplicationScope",
      "propertyName": "WorkbookPath",
      "sourceBinding": "variable",
      "originalValue": "[str_ConfigPath]",
      "resolvedValue": "[str_ConfigPath]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "variable",
        "sourceName": "str_ConfigPath",
        "sourceWorkflow": "InitAllSettings",
        "precedenceTier": 2
      }
    },
    {
      "file": "InitAllSettings.xaml",
      "workflow": "InitAllSettings",
      "activityType": "ExcelReadRange",
      "propertyName": "SheetName",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Settings&quot;]",
      "resolvedValue": "[&quot;Settings&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Settings&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "InitAllSettings.xaml",
      "workflow": "InitAllSettings",
      "activityType": "ExcelReadRange",
      "propertyName": "SheetName",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Constants&quot;]",
      "resolvedValue": "[&quot;Constants&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 1,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Constants&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "InitAllSettings.xaml",
      "workflow": "InitAllSettings",
      "activityType": "ForEach",
      "propertyName": "Values",
      "sourceBinding": "attribute-value",
      "originalValue": "[dt_Settings.Rows]",
      "resolvedValue": "[dt_Settings.Rows]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[dt_Settings.Rows]",
        "precedenceTier": 4
      }
    },
    {
      "file": "InitAllSettings.xaml",
      "workflow": "InitAllSettings",
      "activityType": "Assign",
      "propertyName": "To",
      "sourceBinding": "attribute-value",
      "originalValue": "[dict_Config(row(&quot;Name&quot;).ToString)]",
      "resolvedValue": "[dict_Config(row(&quot;Name&quot;).ToString)]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[dict_Config(row(&quot;Name&quot;).ToString)]",
        "precedenceTier": 4
      }
    },
    {
      "file": "InitAllSettings.xaml",
      "workflow": "InitAllSettings",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "[row(&quot;Value&quot;)]",
      "resolvedValue": "[row(&quot;Value&quot;)]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[row(&quot;Value&quot;)]",
        "precedenceTier": 4
      }
    },
    {
      "file": "InitAllSettings.xaml",
      "workflow": "InitAllSettings",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Processing setting: &quot; &amp; row(&quot;Name&quot;).ToString]",
      "resolvedValue": "[&quot;Processing setting: &quot; &amp; row(&quot;Name&quot;).ToString]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 1,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Processing setting: &quot; &amp; row(&quot;Name&quot;).ToString]",
        "precedenceTier": 4
      }
    },
    {
      "file": "InitAllSettings.xaml",
      "workflow": "InitAllSettings",
      "activityType": "GetCredential",
      "propertyName": "AssetName",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Coupa_IRV2_Credentials&quot;]",
      "resolvedValue": "[&quot;Coupa_IRV2_Credentials&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Coupa_IRV2_Credentials&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "InitAllSettings.xaml",
      "workflow": "InitAllSettings",
      "activityType": "Assign",
      "propertyName": "To",
      "sourceBinding": "attribute-value",
      "originalValue": "[dict_Config(&quot;Coupa_IRV2_Credentials&quot;)]",
      "resolvedValue": "[dict_Config(&quot;Coupa_IRV2_Credentials&quot;)]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 1,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[dict_Config(&quot;Coupa_IRV2_Credentials&quot;)]",
        "precedenceTier": 4
      }
    },
    {
      "file": "InitAllSettings.xaml",
      "workflow": "InitAllSettings",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "variable",
      "originalValue": "[str_TempUser]",
      "resolvedValue": "[str_TempUser]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 1,
      "provenance": {
        "sourceKind": "variable",
        "sourceName": "str_TempUser",
        "sourceWorkflow": "InitAllSettings",
        "precedenceTier": 2
      }
    },
    {
      "file": "InitAllSettings.xaml",
      "workflow": "InitAllSettings",
      "activityType": "Assign",
      "propertyName": "To",
      "sourceBinding": "attribute-value",
      "originalValue": "[dict_Config(&quot;Coupa_IRV2_BaseUrl&quot;)]",
      "resolvedValue": "[dict_Config(&quot;Coupa_IRV2_BaseUrl&quot;)]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 2,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[dict_Config(&quot;Coupa_IRV2_BaseUrl&quot;)]",
        "precedenceTier": 4
      }
    },
    {
      "file": "InitAllSettings.xaml",
      "workflow": "InitAllSettings",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "variable",
      "originalValue": "[str_AssetValue]",
      "resolvedValue": "[str_AssetValue]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 2,
      "provenance": {
        "sourceKind": "variable",
        "sourceName": "str_AssetValue",
        "sourceWorkflow": "InitAllSettings",
        "precedenceTier": 2
      }
    },
    {
      "file": "InitAllSettings.xaml",
      "workflow": "InitAllSettings",
      "activityType": "Assign",
      "propertyName": "To",
      "sourceBinding": "attribute-value",
      "originalValue": "[dict_Config(&quot;Coupa_IRV2_TolerancePercent&quot;)]",
      "resolvedValue": "[dict_Config(&quot;Coupa_IRV2_TolerancePercent&quot;)]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 3,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[dict_Config(&quot;Coupa_IRV2_TolerancePercent&quot;)]",
        "precedenceTier": 4
      }
    },
    {
      "file": "InitAllSettings.xaml",
      "workflow": "InitAllSettings",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "variable",
      "originalValue": "[str_AssetValue]",
      "resolvedValue": "[str_AssetValue]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 3,
      "provenance": {
        "sourceKind": "variable",
        "sourceName": "str_AssetValue",
        "sourceWorkflow": "InitAllSettings",
        "precedenceTier": 2
      }
    },
    {
      "file": "InitAllSettings.xaml",
      "workflow": "InitAllSettings",
      "activityType": "Assign",
      "propertyName": "To",
      "sourceBinding": "attribute-value",
      "originalValue": "[dict_Config(&quot;Coupa_IRV2_RejectComment_POMismatch&quot;)]",
      "resolvedValue": "[dict_Config(&quot;Coupa_IRV2_RejectComment_POMismatch&quot;)]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 4,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[dict_Config(&quot;Coupa_IRV2_RejectComment_POMismatch&quot;)]",
        "precedenceTier": 4
      }
    },
    {
      "file": "InitAllSettings.xaml",
      "workflow": "InitAllSettings",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "variable",
      "originalValue": "[str_AssetValue]",
      "resolvedValue": "[str_AssetValue]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 4,
      "provenance": {
        "sourceKind": "variable",
        "sourceName": "str_AssetValue",
        "sourceWorkflow": "InitAllSettings",
        "precedenceTier": 2
      }
    },
    {
      "file": "InitAllSettings.xaml",
      "workflow": "InitAllSettings",
      "activityType": "Assign",
      "propertyName": "To",
      "sourceBinding": "attribute-value",
      "originalValue": "[dict_Config(&quot;Coupa_IRV2_RejectComment_OutOfTolerance&quot;)]",
      "resolvedValue": "[dict_Config(&quot;Coupa_IRV2_RejectComment_OutOfTolerance&quot;)]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 5,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[dict_Config(&quot;Coupa_IRV2_RejectComment_OutOfTolerance&quot;)]",
        "precedenceTier": 4
      }
    },
    {
      "file": "InitAllSettings.xaml",
      "workflow": "InitAllSettings",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "variable",
      "originalValue": "[str_AssetValue]",
      "resolvedValue": "[str_AssetValue]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 5,
      "provenance": {
        "sourceKind": "variable",
        "sourceName": "str_AssetValue",
        "sourceWorkflow": "InitAllSettings",
        "precedenceTier": 2
      }
    },
    {
      "file": "InitAllSettings.xaml",
      "workflow": "InitAllSettings",
      "activityType": "Assign",
      "propertyName": "To",
      "sourceBinding": "attribute-value",
      "originalValue": "[dict_Config(&quot;Coupa_IRV2_RejectComment_InsufficientData&quot;)]",
      "resolvedValue": "[dict_Config(&quot;Coupa_IRV2_RejectComment_InsufficientData&quot;)]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 6,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[dict_Config(&quot;Coupa_IRV2_RejectComment_InsufficientData&quot;)]",
        "precedenceTier": 4
      }
    },
    {
      "file": "InitAllSettings.xaml",
      "workflow": "InitAllSettings",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "variable",
      "originalValue": "[str_AssetValue]",
      "resolvedValue": "[str_AssetValue]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 6,
      "provenance": {
        "sourceKind": "variable",
        "sourceName": "str_AssetValue",
        "sourceWorkflow": "InitAllSettings",
        "precedenceTier": 2
      }
    },
    {
      "file": "InitAllSettings.xaml",
      "workflow": "InitAllSettings",
      "activityType": "Assign",
      "propertyName": "To",
      "sourceBinding": "attribute-value",
      "originalValue": "[dict_Config(&quot;Coupa_IRV2_MaxTransactionSeconds&quot;)]",
      "resolvedValue": "[dict_Config(&quot;Coupa_IRV2_MaxTransactionSeconds&quot;)]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 7,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[dict_Config(&quot;Coupa_IRV2_MaxTransactionSeconds&quot;)]",
        "precedenceTier": 4
      }
    },
    {
      "file": "InitAllSettings.xaml",
      "workflow": "InitAllSettings",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "variable",
      "originalValue": "[str_AssetValue]",
      "resolvedValue": "[str_AssetValue]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 7,
      "provenance": {
        "sourceKind": "variable",
        "sourceName": "str_AssetValue",
        "sourceWorkflow": "InitAllSettings",
        "precedenceTier": 2
      }
    },
    {
      "file": "InitAllSettings.xaml",
      "workflow": "InitAllSettings",
      "activityType": "Assign",
      "propertyName": "To",
      "sourceBinding": "attribute-value",
      "originalValue": "[dict_Config(&quot;Coupa_IRV2_MaxConsecutiveSystemFailures&quot;)]",
      "resolvedValue": "[dict_Config(&quot;Coupa_IRV2_MaxConsecutiveSystemFailures&quot;)]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 8,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[dict_Config(&quot;Coupa_IRV2_MaxConsecutiveSystemFailures&quot;)]",
        "precedenceTier": 4
      }
    },
    {
      "file": "InitAllSettings.xaml",
      "workflow": "InitAllSettings",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "variable",
      "originalValue": "[str_AssetValue]",
      "resolvedValue": "[str_AssetValue]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 8,
      "provenance": {
        "sourceKind": "variable",
        "sourceName": "str_AssetValue",
        "sourceWorkflow": "InitAllSettings",
        "precedenceTier": 2
      }
    },
    {
      "file": "InitAllSettings.xaml",
      "workflow": "InitAllSettings",
      "activityType": "Assign",
      "propertyName": "To",
      "sourceBinding": "attribute-value",
      "originalValue": "[dict_Config(&quot;Coupa_IRV2_EnableEvidenceSnapshots&quot;)]",
      "resolvedValue": "[dict_Config(&quot;Coupa_IRV2_EnableEvidenceSnapshots&quot;)]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 9,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[dict_Config(&quot;Coupa_IRV2_EnableEvidenceSnapshots&quot;)]",
        "precedenceTier": 4
      }
    },
    {
      "file": "InitAllSettings.xaml",
      "workflow": "InitAllSettings",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "variable",
      "originalValue": "[str_AssetValue]",
      "resolvedValue": "[str_AssetValue]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 9,
      "provenance": {
        "sourceKind": "variable",
        "sourceName": "str_AssetValue",
        "sourceWorkflow": "InitAllSettings",
        "precedenceTier": 2
      }
    },
    {
      "file": "InitAllSettings.xaml",
      "workflow": "InitAllSettings",
      "activityType": "ForEach",
      "propertyName": "Values",
      "sourceBinding": "attribute-value",
      "originalValue": "[dt_Constants.Rows]",
      "resolvedValue": "[dt_Constants.Rows]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 1,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[dt_Constants.Rows]",
        "precedenceTier": 4
      }
    },
    {
      "file": "InitAllSettings.xaml",
      "workflow": "InitAllSettings",
      "activityType": "Assign",
      "propertyName": "To",
      "sourceBinding": "attribute-value",
      "originalValue": "[dict_Config(constRow(&quot;Name&quot;).ToString)]",
      "resolvedValue": "[dict_Config(constRow(&quot;Name&quot;).ToString)]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 10,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[dict_Config(constRow(&quot;Name&quot;).ToString)]",
        "precedenceTier": 4
      }
    },
    {
      "file": "InitAllSettings.xaml",
      "workflow": "InitAllSettings",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "[constRow(&quot;Value&quot;)]",
      "resolvedValue": "[constRow(&quot;Value&quot;)]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 10,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[constRow(&quot;Value&quot;)]",
        "precedenceTier": 4
      }
    },
    {
      "file": "InitAllSettings.xaml",
      "workflow": "InitAllSettings",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Loaded constant: &quot; &amp; constRow(&quot;Name&quot;).ToString]",
      "resolvedValue": "[&quot;Loaded constant: &quot; &amp; constRow(&quot;Name&quot;).ToString]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 2,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Loaded constant: &quot; &amp; constRow(&quot;Name&quot;).ToString]",
        "precedenceTier": 4
      }
    },
    {
      "file": "InitAllSettings.xaml",
      "workflow": "InitAllSettings",
      "activityType": "Assign",
      "propertyName": "To",
      "sourceBinding": "workflowArgument",
      "originalValue": "[out_Config]",
      "resolvedValue": "[out_Config]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 11,
      "provenance": {
        "sourceKind": "workflowArgument",
        "sourceName": "out_Config",
        "sourceWorkflow": "InitAllSettings",
        "precedenceTier": 1
      }
    },
    {
      "file": "InitAllSettings.xaml",
      "workflow": "InitAllSettings",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "variable",
      "originalValue": "[dict_Config]",
      "resolvedValue": "[dict_Config]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 11,
      "provenance": {
        "sourceKind": "variable",
        "sourceName": "dict_Config",
        "sourceWorkflow": "InitAllSettings",
        "precedenceTier": 2
      }
    },
    {
      "file": "InitAllSettings.xaml",
      "workflow": "InitAllSettings",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Configuration loaded successfully&quot;]",
      "resolvedValue": "[&quot;Configuration loaded successfully&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 3,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Configuration loaded successfully&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "InitAllSettings.xaml",
      "workflow": "InitAllSettings",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;=== Completed: InitAllSettings ===&quot;]",
      "resolvedValue": "[&quot;=== Completed: InitAllSettings ===&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 4,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;=== Completed: InitAllSettings ===&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "GetTransactionData.xaml",
      "workflow": "GetTransactionData",
      "activityType": "If",
      "propertyName": "Condition",
      "sourceBinding": "attribute-value",
      "originalValue": "[out_TransactionItem IsNot Nothing]",
      "resolvedValue": "[out_TransactionItem IsNot Nothing]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[out_TransactionItem IsNot Nothing]",
        "precedenceTier": 4
      }
    },
    {
      "file": "GetTransactionData.xaml",
      "workflow": "GetTransactionData",
      "activityType": "Assign",
      "propertyName": "To",
      "sourceBinding": "workflowArgument",
      "originalValue": "[io_TransactionNumber]",
      "resolvedValue": "[io_TransactionNumber]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "workflowArgument",
        "sourceName": "io_TransactionNumber",
        "sourceWorkflow": "GetTransactionData",
        "precedenceTier": 1
      }
    },
    {
      "file": "GetTransactionData.xaml",
      "workflow": "GetTransactionData",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "[io_TransactionNumber + 1]",
      "resolvedValue": "[io_TransactionNumber + 1]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[io_TransactionNumber + 1]",
        "precedenceTier": 4
      }
    },
    {
      "file": "GetTransactionData.xaml",
      "workflow": "GetTransactionData",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Processing transaction #&quot; &amp; io_TransactionNumber.ToString &amp; &quot; - Ref: &quot; &amp; out_TransactionItem.Reference]",
      "resolvedValue": "[&quot;Processing transaction #&quot; &amp; io_TransactionNumber.ToString &amp; &quot; - Ref: &quot; &amp; out_TransactionItem.Reference]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Processing transaction #&quot; &amp; io_TransactionNumber.ToString &amp; ",
        "precedenceTier": 4
      }
    },
    {
      "file": "GetTransactionData.xaml",
      "workflow": "GetTransactionData",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;No more transactions in queue&quot;]",
      "resolvedValue": "[&quot;No more transactions in queue&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 1,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;No more transactions in queue&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "GetTransactionData.xaml",
      "workflow": "GetTransactionData",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;=== Completed: GetTransactionData ===&quot;]",
      "resolvedValue": "[&quot;=== Completed: GetTransactionData ===&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 2,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;=== Completed: GetTransactionData ===&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "SetTransactionStatus.xaml",
      "workflow": "SetTransactionStatus",
      "activityType": "If",
      "propertyName": "Condition",
      "sourceBinding": "attribute-value",
      "originalValue": "[in_Status = &quot;Successful&quot;]",
      "resolvedValue": "[in_Status = &quot;Successful&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[in_Status = &quot;Successful&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "SetTransactionStatus.xaml",
      "workflow": "SetTransactionStatus",
      "activityType": "SetTransactionStatus",
      "propertyName": "TransactionItem",
      "sourceBinding": "workflowArgument",
      "originalValue": "[in_TransactionItem]",
      "resolvedValue": "[in_TransactionItem]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "workflowArgument",
        "sourceName": "in_TransactionItem",
        "sourceWorkflow": "SetTransactionStatus",
        "precedenceTier": 1
      }
    },
    {
      "file": "SetTransactionStatus.xaml",
      "workflow": "SetTransactionStatus",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Transaction failure screenshot: &quot; &amp; str_ScreenshotPath]",
      "resolvedValue": "[&quot;Transaction failure screenshot: &quot; &amp; str_ScreenshotPath]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Transaction failure screenshot: &quot; &amp; str_ScreenshotPath]",
        "precedenceTier": 4
      }
    },
    {
      "file": "SetTransactionStatus.xaml",
      "workflow": "SetTransactionStatus",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot capture failed: &quot; &amp; ssEx.Message]",
      "resolvedValue": "[&quot;Screenshot capture failed: &quot; &amp; ssEx.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 1,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot capture failed: &quot; &amp; ssEx.Message]",
        "precedenceTier": 4
      }
    },
    {
      "file": "SetTransactionStatus.xaml",
      "workflow": "SetTransactionStatus",
      "activityType": "SetTransactionStatus",
      "propertyName": "TransactionItem",
      "sourceBinding": "workflowArgument",
      "originalValue": "[in_TransactionItem]",
      "resolvedValue": "[in_TransactionItem]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 1,
      "provenance": {
        "sourceKind": "workflowArgument",
        "sourceName": "in_TransactionItem",
        "sourceWorkflow": "SetTransactionStatus",
        "precedenceTier": 1
      }
    },
    {
      "file": "SetTransactionStatus.xaml",
      "workflow": "SetTransactionStatus",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Transaction failed: &quot; &amp; in_ErrorMessage]",
      "resolvedValue": "[&quot;Transaction failed: &quot; &amp; in_ErrorMessage]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 2,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Transaction failed: &quot; &amp; in_ErrorMessage]",
        "precedenceTier": 4
      }
    },
    {
      "file": "SetTransactionStatus.xaml",
      "workflow": "SetTransactionStatus",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;=== Completed: SetTransactionStatus ===&quot;]",
      "resolvedValue": "[&quot;=== Completed: SetTransactionStatus ===&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 3,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;=== Completed: SetTransactionStatus ===&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "CloseAllApplications.xaml",
      "workflow": "CloseAllApplications",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Closing all applications...&quot;]",
      "resolvedValue": "[&quot;Closing all applications...&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Closing all applications...&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "CloseAllApplications.xaml",
      "workflow": "CloseAllApplications",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;All applications closed&quot;]",
      "resolvedValue": "[&quot;All applications closed&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 1,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;All applications closed&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "CloseAllApplications.xaml",
      "workflow": "CloseAllApplications",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Error during cleanup: &quot; &amp; closeEx.Message]",
      "resolvedValue": "[&quot;Error during cleanup: &quot; &amp; closeEx.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 2,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Error during cleanup: &quot; &amp; closeEx.Message]",
        "precedenceTier": 4
      }
    },
    {
      "file": "CloseAllApplications.xaml",
      "workflow": "CloseAllApplications",
      "activityType": "InvokeWorkflowFile",
      "propertyName": "WorkflowFileName",
      "sourceBinding": "attribute-value",
      "originalValue": "KillAllProcesses.xaml",
      "resolvedValue": "KillAllProcesses.xaml",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "KillAllProcesses.xaml",
        "precedenceTier": 4
      }
    },
    {
      "file": "CloseAllApplications.xaml",
      "workflow": "CloseAllApplications",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Kill processes failed: &quot; &amp; killEx.Message]",
      "resolvedValue": "[&quot;Kill processes failed: &quot; &amp; killEx.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 3,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Kill processes failed: &quot; &amp; killEx.Message]",
        "precedenceTier": 4
      }
    },
    {
      "file": "CloseAllApplications.xaml",
      "workflow": "CloseAllApplications",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;=== Completed: CloseAllApplications ===&quot;]",
      "resolvedValue": "[&quot;=== Completed: CloseAllApplications ===&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 4,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;=== Completed: CloseAllApplications ===&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "KillAllProcesses.xaml",
      "workflow": "KillAllProcesses",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Force killing all application processes...&quot;]",
      "resolvedValue": "[&quot;Force killing all application processes...&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Force killing all application processes...&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "KillAllProcesses.xaml",
      "workflow": "KillAllProcesses",
      "activityType": "KillProcess",
      "propertyName": "ProcessName",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;chrome&quot;]",
      "resolvedValue": "[&quot;chrome&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;chrome&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "KillAllProcesses.xaml",
      "workflow": "KillAllProcesses",
      "activityType": "KillProcess",
      "propertyName": "ProcessName",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;iexplore&quot;]",
      "resolvedValue": "[&quot;iexplore&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 1,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;iexplore&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "KillAllProcesses.xaml",
      "workflow": "KillAllProcesses",
      "activityType": "KillProcess",
      "propertyName": "ProcessName",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;EXCEL&quot;]",
      "resolvedValue": "[&quot;EXCEL&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 2,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;EXCEL&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "KillAllProcesses.xaml",
      "workflow": "KillAllProcesses",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;All processes terminated&quot;]",
      "resolvedValue": "[&quot;All processes terminated&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 1,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;All processes terminated&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "KillAllProcesses.xaml",
      "workflow": "KillAllProcesses",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;=== Completed: KillAllProcesses ===&quot;]",
      "resolvedValue": "[&quot;=== Completed: KillAllProcesses ===&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 2,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;=== Completed: KillAllProcesses ===&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "Init.xaml",
      "workflow": "Init",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;=== Initialization Started ===&quot;]",
      "resolvedValue": "[&quot;=== Initialization Started ===&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;=== Initialization Started ===&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "Init.xaml",
      "workflow": "Init",
      "activityType": "InvokeWorkflowFile",
      "propertyName": "WorkflowFileName",
      "sourceBinding": "attribute-value",
      "originalValue": "InitAllSettings.xaml",
      "resolvedValue": "InitAllSettings.xaml",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "InitAllSettings.xaml",
        "precedenceTier": 4
      }
    },
    {
      "file": "Init.xaml",
      "workflow": "Init",
      "activityType": "Assign",
      "propertyName": "To",
      "sourceBinding": "workflowArgument",
      "originalValue": "[io_Config]",
      "resolvedValue": "[io_Config]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "workflowArgument",
        "sourceName": "io_Config",
        "sourceWorkflow": "Init",
        "precedenceTier": 1
      }
    },
    {
      "file": "Init.xaml",
      "workflow": "Init",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "variable",
      "originalValue": "[dict_Config]",
      "resolvedValue": "[dict_Config]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "variable",
        "sourceName": "dict_Config",
        "sourceWorkflow": "Init",
        "precedenceTier": 2
      }
    },
    {
      "file": "Init.xaml",
      "workflow": "Init",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Configuration loaded successfully&quot;]",
      "resolvedValue": "[&quot;Configuration loaded successfully&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 1,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Configuration loaded successfully&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "Init.xaml",
      "workflow": "Init",
      "activityType": "Assign",
      "propertyName": "To",
      "sourceBinding": "variable",
      "originalValue": "[bool_InitSuccess]",
      "resolvedValue": "[bool_InitSuccess]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 1,
      "provenance": {
        "sourceKind": "variable",
        "sourceName": "bool_InitSuccess",
        "sourceWorkflow": "Init",
        "precedenceTier": 2
      }
    },
    {
      "file": "Init.xaml",
      "workflow": "Init",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "True",
      "resolvedValue": "True",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 1,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "True",
        "precedenceTier": 4
      }
    },
    {
      "file": "Init.xaml",
      "workflow": "Init",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Initialization failed: &quot; &amp; exception.Message]",
      "resolvedValue": "[&quot;Initialization failed: &quot; &amp; exception.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 2,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Initialization failed: &quot; &amp; exception.Message]",
        "precedenceTier": 4
      }
    },
    {
      "file": "Init.xaml",
      "workflow": "Init",
      "activityType": "Assign",
      "propertyName": "To",
      "sourceBinding": "variable",
      "originalValue": "[bool_InitSuccess]",
      "resolvedValue": "[bool_InitSuccess]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 2,
      "provenance": {
        "sourceKind": "variable",
        "sourceName": "bool_InitSuccess",
        "sourceWorkflow": "Init",
        "precedenceTier": 2
      }
    },
    {
      "file": "Init.xaml",
      "workflow": "Init",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "False",
      "resolvedValue": "False",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 2,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "False",
        "precedenceTier": 4
      }
    },
    {
      "file": "Init.xaml",
      "workflow": "Init",
      "activityType": "If",
      "propertyName": "Condition",
      "sourceBinding": "variable",
      "originalValue": "[bool_InitSuccess]",
      "resolvedValue": "[bool_InitSuccess]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "variable",
        "sourceName": "bool_InitSuccess",
        "sourceWorkflow": "Init",
        "precedenceTier": 2
      }
    },
    {
      "file": "Init.xaml",
      "workflow": "Init",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;=== Initialization Complete ===&quot;]",
      "resolvedValue": "[&quot;=== Initialization Complete ===&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 3,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;=== Initialization Complete ===&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "Init.xaml",
      "workflow": "Init",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;=== Initialization FAILED — process cannot continue ===&quot;]",
      "resolvedValue": "[&quot;=== Initialization FAILED — process cannot continue ===&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 4,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;=== Initialization FAILED — process cannot continue ===&quot;]",
        "precedenceTier": 4
      }
    }
  ],
  "unresolvedRequiredPropertyDefects": [
    {
      "file": "Process.xaml",
      "workflow": "Process",
      "activityType": "If",
      "propertyName": "Condition",
      "failureReason": "Required property \"Condition\" on If contains disallowed generic default \"False\" per fallback policy for If.Condition — no valid source found",
      "originalValue": "False",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "Process.xaml",
      "workflow": "Process",
      "activityType": "If",
      "propertyName": "Condition",
      "failureReason": "Required property \"Condition\" on If contains disallowed generic default \"False\" per fallback policy for If.Condition — no valid source found",
      "originalValue": "False",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "Process.xaml",
      "workflow": "Process",
      "activityType": "If",
      "propertyName": "Condition",
      "failureReason": "Required property \"Condition\" on If contains disallowed generic default \"False\" per fallback policy for If.Condition — no valid source found",
      "originalValue": "False",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "Process.xaml",
      "workflow": "Process",
      "activityType": "If",
      "propertyName": "Condition",
      "failureReason": "Required property \"Condition\" on If contains disallowed generic default \"False\" per fallback policy for If.Condition — no valid source found",
      "originalValue": "False",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "Process.xaml",
      "workflow": "Process",
      "activityType": "If",
      "propertyName": "Condition",
      "failureReason": "Required property \"Condition\" on If contains disallowed generic default \"False\" per fallback policy for If.Condition — no valid source found",
      "originalValue": "False",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "InitAllSettings.xaml",
      "workflow": "InitAllSettings",
      "activityType": "ExcelApplicationScope",
      "propertyName": "ExistingWorkbook",
      "failureReason": "Required property \"ExistingWorkbook\" on ExcelApplicationScope has no valid source binding and no contract-valid fallback",
      "originalValue": "",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    }
  ],
  "expressionLoweringFixes": [],
  "expressionLoweringFailures": [],
  "requiredPropertyEnforcementSummary": "147 required property binding(s) resolved; 6 unresolved required property defect(s); 5 invalid generic substitution(s) blocked; 5 fallback-eligible resolution(s) diagnosed",
  "preComplianceGuardPassed": true,
  "preComplianceGuardViolationCount": 0,
  "canonicalizationArchiveParity": [
    {
      "file": "CoupaSessionManager.xaml",
      "preCanonicalizationHash": "aebaea901fb4ecbc6428399e7367f79a73b4ea6e8a7b34e8760a00e8dca6431b",
      "canonicalizedHash": "ac4f7a40c272d08e7b93869945092b52e5cd0b721557c04d7c2ba527fe2ab744",
      "archivedHash": "ac4f7a40c272d08e7b93869945092b52e5cd0b721557c04d7c2ba527fe2ab744",
      "identical": true,
      "mutated": true
    },
    {
      "file": "Dispatcher.xaml",
      "preCanonicalizationHash": "4b65cab9ba31553d3de89a04a1542e7715246cd7a478d4d9a81198421720220c",
      "canonicalizedHash": "40c09b9f670344b0e461a71b48a9d32632cf9c611a02083370d68ed1cf3afb60",
      "archivedHash": "40c09b9f670344b0e461a71b48a9d32632cf9c611a02083370d68ed1cf3afb60",
      "identical": true,
      "mutated": true
    },
    {
      "file": "InitPerformer.xaml",
      "preCanonicalizationHash": "59fd7d794558fde0e1c074c5a4a1dee65cd3383da74dbf8880d221725991a6cc",
      "canonicalizedHash": "7d8ad75a18bd9fa24c6ab01f5fbefcbbc6d70abde33bb9ff76c23ffc966d534a",
      "archivedHash": "7d8ad75a18bd9fa24c6ab01f5fbefcbbc6d70abde33bb9ff76c23ffc966d534a",
      "identical": true,
      "mutated": true
    },
    {
      "file": "ProcessInvoice.xaml",
      "preCanonicalizationHash": "47bd3c33e1e8d82d0d4d9555c589e9f92d6f6a6d3419a0ef262ab4ff591858fd",
      "canonicalizedHash": "13a18f3f9fa89aabdc42ef25ad680c631a3a47653a726d081da36d685157adeb",
      "archivedHash": "13a18f3f9fa89aabdc42ef25ad680c631a3a47653a726d081da36d685157adeb",
      "identical": true,
      "mutated": true
    },
    {
      "file": "ActionCenterTaskCreator.xaml",
      "preCanonicalizationHash": "574b00c61bea8c161298e11a1a9532cc1691a203080cf44f140f63a68601d341",
      "canonicalizedHash": "bce9f4dc2cb1317ca5276d679cebf39bdd488ff0d994e33ba831382aa0eaa416",
      "archivedHash": "bce9f4dc2cb1317ca5276d679cebf39bdd488ff0d994e33ba831382aa0eaa416",
      "identical": true,
      "mutated": true
    },
    {
      "file": "ActionCenterCallbackHandler.xaml",
      "preCanonicalizationHash": "bca00b23bc0b4d29d6bff6bad5c5259b46aafa055d02c4e4d7e78a458bdc1e9b",
      "canonicalizedHash": "fed1fece0b925c9a0f3988b11dd468f2f7499163a906bb72da87c5544cb8ee38",
      "archivedHash": "fed1fece0b925c9a0f3988b11dd468f2f7499163a906bb72da87c5544cb8ee38",
      "identical": true,
      "mutated": true
    },
    {
      "file": "Main.xaml",
      "preCanonicalizationHash": "65033d643958cd41e6db835211fee2244a31c6bba515901ef49ed6e8b6c1bebd",
      "canonicalizedHash": "f84ecb9786a94e73a68b02245542149f421a71edf25b38647ce2366e451ac6ea",
      "archivedHash": "f84ecb9786a94e73a68b02245542149f421a71edf25b38647ce2366e451ac6ea",
      "identical": true,
      "mutated": true
    },
    {
      "file": "Process.xaml",
      "preCanonicalizationHash": "11102051d2210cb8e76b64c59274afc4bbdbbbf4f24df53bc7aac08a51de3e06",
      "canonicalizedHash": "829d105bbbb6f2e7a6364c6cd1351d787719d50a5a8d6cc2edf00a7f39134907",
      "archivedHash": "829d105bbbb6f2e7a6364c6cd1351d787719d50a5a8d6cc2edf00a7f39134907",
      "identical": true,
      "mutated": true
    },
    {
      "file": "InitAllSettings.xaml",
      "preCanonicalizationHash": "a5593ec0010278c233a441d106ce5baaa20b5a5db0fd41ff5df7f6b395f900cc",
      "canonicalizedHash": "a5593ec0010278c233a441d106ce5baaa20b5a5db0fd41ff5df7f6b395f900cc",
      "archivedHash": "a5593ec0010278c233a441d106ce5baaa20b5a5db0fd41ff5df7f6b395f900cc",
      "identical": true,
      "mutated": false
    },
    {
      "file": "GetTransactionData.xaml",
      "preCanonicalizationHash": "7150edd3b90e8ba2e95ace071e17c76a10d53da263e2e0cdeba88f3ddcd9d686",
      "canonicalizedHash": "7150edd3b90e8ba2e95ace071e17c76a10d53da263e2e0cdeba88f3ddcd9d686",
      "archivedHash": "7150edd3b90e8ba2e95ace071e17c76a10d53da263e2e0cdeba88f3ddcd9d686",
      "identical": true,
      "mutated": false
    },
    {
      "file": "SetTransactionStatus.xaml",
      "preCanonicalizationHash": "c87cbd3f5316c54df356f2d2a569a58df6669e6af60ed6e199f37eaaf9a8624b",
      "canonicalizedHash": "c87cbd3f5316c54df356f2d2a569a58df6669e6af60ed6e199f37eaaf9a8624b",
      "archivedHash": "c87cbd3f5316c54df356f2d2a569a58df6669e6af60ed6e199f37eaaf9a8624b",
      "identical": true,
      "mutated": false
    },
    {
      "file": "CloseAllApplications.xaml",
      "preCanonicalizationHash": "b1422460d64ed0a4961f1b32e46524dd7e9a62db7898fba1568518e973bca67d",
      "canonicalizedHash": "b1422460d64ed0a4961f1b32e46524dd7e9a62db7898fba1568518e973bca67d",
      "archivedHash": "b1422460d64ed0a4961f1b32e46524dd7e9a62db7898fba1568518e973bca67d",
      "identical": true,
      "mutated": false
    },
    {
      "file": "KillAllProcesses.xaml",
      "preCanonicalizationHash": "9c6ff76dd44c4e2dad41088dc1b0d396920b62d7269b65cd42d270d0aac760cb",
      "canonicalizedHash": "9c6ff76dd44c4e2dad41088dc1b0d396920b62d7269b65cd42d270d0aac760cb",
      "archivedHash": "9c6ff76dd44c4e2dad41088dc1b0d396920b62d7269b65cd42d270d0aac760cb",
      "identical": true,
      "mutated": false
    },
    {
      "file": "Init.xaml",
      "preCanonicalizationHash": "59937d8b7a8ccb91771dafe3273b012e5a2a6cbc0c3850c53980d22d718afc7a",
      "canonicalizedHash": "f44213c3e46b46c17650f45dfdfe51edffafbd18cc4a5294d890a3dd0b9b38bf",
      "archivedHash": "f44213c3e46b46c17650f45dfdfe51edffafbd18cc4a5294d890a3dd0b9b38bf",
      "identical": true,
      "mutated": true
    }
  ],
  "preArchiveStructuralDefects": [
    {
      "file": "InitAllSettings.xaml",
      "pattern": "malformed_attribute_quoting",
      "detail": "Malformed attribute quoting detected: AssetName=\"[&quot;Coupa_IRV2_Credentials&quot;]"
    }
  ],
  "postClassifierMutationTrace": {
    "entries": [
      {
        "stage": "pre-freeze-snapshot",
        "function": "freezeArchiveWorkflows",
        "file": "ActionCenterCallbackHandler.xaml",
        "mutationType": "xaml_bytes",
        "preHash": "N/A",
        "postHash": "fed1fece0b925c9a0f3988b11dd468f2f7499163a906bb72da87c5544cb8ee38",
        "allowed": true,
        "reason": "Workflow \"ActionCenterCallbackHandler.xaml\" content captured at freeze point (status=non-stub)",
        "changedBytes": false,
        "changedStatus": false,
        "enforcementAction": "none"
      },
      {
        "stage": "pre-freeze-snapshot",
        "function": "freezeArchiveWorkflows",
        "file": "ActionCenterTaskCreator.xaml",
        "mutationType": "xaml_bytes",
        "preHash": "N/A",
        "postHash": "bce9f4dc2cb1317ca5276d679cebf39bdd488ff0d994e33ba831382aa0eaa416",
        "allowed": true,
        "reason": "Workflow \"ActionCenterTaskCreator.xaml\" content captured at freeze point (status=non-stub)",
        "changedBytes": false,
        "changedStatus": false,
        "enforcementAction": "none"
      },
      {
        "stage": "pre-freeze-snapshot",
        "function": "freezeArchiveWorkflows",
        "file": "CloseAllApplications.xaml",
        "mutationType": "xaml_bytes",
        "preHash": "N/A",
        "postHash": "b1422460d64ed0a4961f1b32e46524dd7e9a62db7898fba1568518e973bca67d",
        "allowed": true,
        "reason": "Workflow \"CloseAllApplications.xaml\" content captured at freeze point (status=non-stub)",
        "changedBytes": false,
        "changedStatus": false,
        "enforcementAction": "none"
      },
      {
        "stage": "pre-freeze-snapshot",
        "function": "freezeArchiveWorkflows",
        "file": "CoupaSessionManager.xaml",
        "mutationType": "xaml_bytes",
        "preHash": "N/A",
        "postHash": "ac4f7a40c272d08e7b93869945092b52e5cd0b721557c04d7c2ba527fe2ab744",
        "allowed": true,
        "reason": "Workflow \"CoupaSessionManager.xaml\" content captured at freeze point (status=non-stub)",
        "changedBytes": false,
        "changedStatus": false,
        "enforcementAction": "none"
      },
      {
        "stage": "pre-freeze-snapshot",
        "function": "freezeArchiveWorkflows",
        "file": "Dispatcher.xaml",
        "mutationType": "xaml_bytes",
        "preHash": "N/A",
        "postHash": "40c09b9f670344b0e461a71b48a9d32632cf9c611a02083370d68ed1cf3afb60",
        "allowed": true,
        "reason": "Workflow \"Dispatcher.xaml\" content captured at freeze point (status=non-stub)",
        "changedBytes": false,
        "changedStatus": false,
        "enforcementAction": "none"
      },
      {
        "stage": "pre-freeze-snapshot",
        "function": "freezeArchiveWorkflows",
        "file": "GetTransactionData.xaml",
        "mutationType": "xaml_bytes",
        "preHash": "N/A",
        "postHash": "7150edd3b90e8ba2e95ace071e17c76a10d53da263e2e0cdeba88f3ddcd9d686",
        "allowed": true,
        "reason": "Workflow \"GetTransactionData.xaml\" content captured at freeze point (status=non-stub)",
        "changedBytes": false,
        "changedStatus": false,
        "enforcementAction": "none"
      },
      {
        "stage": "pre-freeze-snapshot",
        "function": "freezeArchiveWorkflows",
        "file": "Init.xaml",
        "mutationType": "xaml_bytes",
        "preHash": "N/A",
        "postHash": "f44213c3e46b46c17650f45dfdfe51edffafbd18cc4a5294d890a3dd0b9b38bf",
        "allowed": true,
        "reason": "Workflow \"Init.xaml\" content captured at freeze point (status=non-stub)",
        "changedBytes": false,
        "changedStatus": false,
        "enforcementAction": "none"
      },
      {
        "stage": "pre-freeze-snapshot",
        "function": "freezeArchiveWorkflows",
        "file": "InitAllSettings.xaml",
        "mutationType": "xaml_bytes",
        "preHash": "N/A",
        "postHash": "a5593ec0010278c233a441d106ce5baaa20b5a5db0fd41ff5df7f6b395f900cc",
        "allowed": true,
        "reason": "Workflow \"InitAllSettings.xaml\" content captured at freeze point (status=non-stub)",
        "changedBytes": false,
        "changedStatus": false,
        "enforcementAction": "none"
      },
      {
        "stage": "pre-freeze-snapshot",
        "function": "freezeArchiveWorkflows",
        "file": "InitPerformer.xaml",
        "mutationType": "xaml_bytes",
        "preHash": "N/A",
        "postHash": "7d8ad75a18bd9fa24c6ab01f5fbefcbbc6d70abde33bb9ff76c23ffc966d534a",
        "allowed": true,
        "reason": "Workflow \"InitPerformer.xaml\" content captured at freeze point (status=non-stub)",
        "changedBytes": false,
        "changedStatus": false,
        "enforcementAction": "none"
      },
      {
        "stage": "pre-freeze-snapshot",
        "function": "freezeArchiveWorkflows",
        "file": "KillAllProcesses.xaml",
        "mutationType": "xaml_bytes",
        "preHash": "N/A",
        "postHash": "9c6ff76dd44c4e2dad41088dc1b0d396920b62d7269b65cd42d270d0aac760cb",
        "allowed": true,
        "reason": "Workflow \"KillAllProcesses.xaml\" content captured at freeze point (status=non-stub)",
        "changedBytes": false,
        "changedStatus": false,
        "enforcementAction": "none"
      },
      {
        "stage": "pre-freeze-snapshot",
        "function": "freezeArchiveWorkflows",
        "file": "Main.xaml",
        "mutationType": "xaml_bytes",
        "preHash": "N/A",
        "postHash": "f84ecb9786a94e73a68b02245542149f421a71edf25b38647ce2366e451ac6ea",
        "allowed": true,
        "reason": "Workflow \"Main.xaml\" content captured at freeze point (status=non-stub)",
        "changedBytes": false,
        "changedStatus": false,
        "enforcementAction": "none"
      },
      {
        "stage": "pre-freeze-snapshot",
        "function": "freezeArchiveWorkflows",
        "file": "Process.xaml",
        "mutationType": "xaml_bytes",
        "preHash": "N/A",
        "postHash": "829d105bbbb6f2e7a6364c6cd1351d787719d50a5a8d6cc2edf00a7f39134907",
        "allowed": true,
        "reason": "Workflow \"Process.xaml\" content captured at freeze point (status=non-stub)",
        "changedBytes": false,
        "changedStatus": false,
        "enforcementAction": "none"
      },
      {
        "stage": "pre-freeze-snapshot",
        "function": "freezeArchiveWorkflows",
        "file": "ProcessInvoice.xaml",
        "mutationType": "xaml_bytes",
        "preHash": "N/A",
        "postHash": "13a18f3f9fa89aabdc42ef25ad680c631a3a47653a726d081da36d685157adeb",
        "allowed": true,
        "reason": "Workflow \"ProcessInvoice.xaml\" content captured at freeze point (status=non-stub)",
        "changedBytes": false,
        "changedStatus": false,
        "enforcementAction": "none"
      },
      {
        "stage": "pre-freeze-snapshot",
        "function": "freezeArchiveWorkflows",
        "file": "SetTransactionStatus.xaml",
        "mutationType": "xaml_bytes",
        "preHash": "N/A",
        "postHash": "c87cbd3f5316c54df356f2d2a569a58df6669e6af60ed6e199f37eaaf9a8624b",
        "allowed": true,
        "reason": "Workflow \"SetTransactionStatus.xaml\" content captured at freeze point (status=non-stub)",
        "changedBytes": false,
        "changedStatus": false,
        "enforcementAction": "none"
      }
    ],
    "perFileMutationCounts": {
      "ActionCenterCallbackHandler.xaml": 1,
      "ActionCenterTaskCreator.xaml": 1,
      "CloseAllApplications.xaml": 1,
      "CoupaSessionManager.xaml": 1,
      "Dispatcher.xaml": 1,
      "GetTransactionData.xaml": 1,
      "Init.xaml": 1,
      "InitAllSettings.xaml": 1,
      "InitPerformer.xaml": 1,
      "KillAllProcesses.xaml": 1,
      "Main.xaml": 1,
      "Process.xaml": 1,
      "ProcessInvoice.xaml": 1,
      "SetTransactionStatus.xaml": 1
    },
    "filesChangedAfterFreeze": [],
    "summary": {
      "totalAttemptedMutations": 14,
      "totalBlockedMutations": 0,
      "totalAllowedPreFreezeMutations": 14,
      "totalPostFreezeViolations": 0,
      "totalUnexpectedPostFreezeMutations": 0,
      "filesChangedAfterFreeze": 0
    }
  },
  "postFreezeMutationTrace": {
    "entries": [
      {
        "stage": "pre-freeze-snapshot",
        "function": "freezeArchiveWorkflows",
        "file": "ActionCenterCallbackHandler.xaml",
        "mutationType": "xaml_bytes",
        "preHash": "N/A",
        "postHash": "fed1fece0b925c9a0f3988b11dd468f2f7499163a906bb72da87c5544cb8ee38",
        "allowed": true,
        "reason": "Workflow \"ActionCenterCallbackHandler.xaml\" content captured at freeze point (status=non-stub)",
        "changedBytes": false,
        "changedStatus": false,
        "enforcementAction": "none"
      },
      {
        "stage": "pre-freeze-snapshot",
        "function": "freezeArchiveWorkflows",
        "file": "ActionCenterTaskCreator.xaml",
        "mutationType": "xaml_bytes",
        "preHash": "N/A",
        "postHash": "bce9f4dc2cb1317ca5276d679cebf39bdd488ff0d994e33ba831382aa0eaa416",
        "allowed": true,
        "reason": "Workflow \"ActionCenterTaskCreator.xaml\" content captured at freeze point (status=non-stub)",
        "changedBytes": false,
        "changedStatus": false,
        "enforcementAction": "none"
      },
      {
        "stage": "pre-freeze-snapshot",
        "function": "freezeArchiveWorkflows",
        "file": "CloseAllApplications.xaml",
        "mutationType": "xaml_bytes",
        "preHash": "N/A",
        "postHash": "b1422460d64ed0a4961f1b32e46524dd7e9a62db7898fba1568518e973bca67d",
        "allowed": true,
        "reason": "Workflow \"CloseAllApplications.xaml\" content captured at freeze point (status=non-stub)",
        "changedBytes": false,
        "changedStatus": false,
        "enforcementAction": "none"
      },
      {
        "stage": "pre-freeze-snapshot",
        "function": "freezeArchiveWorkflows",
        "file": "CoupaSessionManager.xaml",
        "mutationType": "xaml_bytes",
        "preHash": "N/A",
        "postHash": "ac4f7a40c272d08e7b93869945092b52e5cd0b721557c04d7c2ba527fe2ab744",
        "allowed": true,
        "reason": "Workflow \"CoupaSessionManager.xaml\" content captured at freeze point (status=non-stub)",
        "changedBytes": false,
        "changedStatus": false,
        "enforcementAction": "none"
      },
      {
        "stage": "pre-freeze-snapshot",
        "function": "freezeArchiveWorkflows",
        "file": "Dispatcher.xaml",
        "mutationType": "xaml_bytes",
        "preHash": "N/A",
        "postHash": "40c09b9f670344b0e461a71b48a9d32632cf9c611a02083370d68ed1cf3afb60",
        "allowed": true,
        "reason": "Workflow \"Dispatcher.xaml\" content captured at freeze point (status=non-stub)",
        "changedBytes": false,
        "changedStatus": false,
        "enforcementAction": "none"
      },
      {
        "stage": "pre-freeze-snapshot",
        "function": "freezeArchiveWorkflows",
        "file": "GetTransactionData.xaml",
        "mutationType": "xaml_bytes",
        "preHash": "N/A",
        "postHash": "7150edd3b90e8ba2e95ace071e17c76a10d53da263e2e0cdeba88f3ddcd9d686",
        "allowed": true,
        "reason": "Workflow \"GetTransactionData.xaml\" content captured at freeze point (status=non-stub)",
        "changedBytes": false,
        "changedStatus": false,
        "enforcementAction": "none"
      },
      {
        "stage": "pre-freeze-snapshot",
        "function": "freezeArchiveWorkflows",
        "file": "Init.xaml",
        "mutationType": "xaml_bytes",
        "preHash": "N/A",
        "postHash": "f44213c3e46b46c17650f45dfdfe51edffafbd18cc4a5294d890a3dd0b9b38bf",
        "allowed": true,
        "reason": "Workflow \"Init.xaml\" content captured at freeze point (status=non-stub)",
        "changedBytes": false,
        "changedStatus": false,
        "enforcementAction": "none"
      },
      {
        "stage": "pre-freeze-snapshot",
        "function": "freezeArchiveWorkflows",
        "file": "InitAllSettings.xaml",
        "mutationType": "xaml_bytes",
        "preHash": "N/A",
        "postHash": "a5593ec0010278c233a441d106ce5baaa20b5a5db0fd41ff5df7f6b395f900cc",
        "allowed": true,
        "reason": "Workflow \"InitAllSettings.xaml\" content captured at freeze point (status=non-stub)",
        "changedBytes": false,
        "changedStatus": false,
        "enforcementAction": "none"
      },
      {
        "stage": "pre-freeze-snapshot",
        "function": "freezeArchiveWorkflows",
        "file": "InitPerformer.xaml",
        "mutationType": "xaml_bytes",
        "preHash": "N/A",
        "postHash": "7d8ad75a18bd9fa24c6ab01f5fbefcbbc6d70abde33bb9ff76c23ffc966d534a",
        "allowed": true,
        "reason": "Workflow \"InitPerformer.xaml\" content captured at freeze point (status=non-stub)",
        "changedBytes": false,
        "changedStatus": false,
        "enforcementAction": "none"
      },
      {
        "stage": "pre-freeze-snapshot",
        "function": "freezeArchiveWorkflows",
        "file": "KillAllProcesses.xaml",
        "mutationType": "xaml_bytes",
        "preHash": "N/A",
        "postHash": "9c6ff76dd44c4e2dad41088dc1b0d396920b62d7269b65cd42d270d0aac760cb",
        "allowed": true,
        "reason": "Workflow \"KillAllProcesses.xaml\" content captured at freeze point (status=non-stub)",
        "changedBytes": false,
        "changedStatus": false,
        "enforcementAction": "none"
      },
      {
        "stage": "pre-freeze-snapshot",
        "function": "freezeArchiveWorkflows",
        "file": "Main.xaml",
        "mutationType": "xaml_bytes",
        "preHash": "N/A",
        "postHash": "f84ecb9786a94e73a68b02245542149f421a71edf25b38647ce2366e451ac6ea",
        "allowed": true,
        "reason": "Workflow \"Main.xaml\" content captured at freeze point (status=non-stub)",
        "changedBytes": false,
        "changedStatus": false,
        "enforcementAction": "none"
      },
      {
        "stage": "pre-freeze-snapshot",
        "function": "freezeArchiveWorkflows",
        "file": "Process.xaml",
        "mutationType": "xaml_bytes",
        "preHash": "N/A",
        "postHash": "829d105bbbb6f2e7a6364c6cd1351d787719d50a5a8d6cc2edf00a7f39134907",
        "allowed": true,
        "reason": "Workflow \"Process.xaml\" content captured at freeze point (status=non-stub)",
        "changedBytes": false,
        "changedStatus": false,
        "enforcementAction": "none"
      },
      {
        "stage": "pre-freeze-snapshot",
        "function": "freezeArchiveWorkflows",
        "file": "ProcessInvoice.xaml",
        "mutationType": "xaml_bytes",
        "preHash": "N/A",
        "postHash": "13a18f3f9fa89aabdc42ef25ad680c631a3a47653a726d081da36d685157adeb",
        "allowed": true,
        "reason": "Workflow \"ProcessInvoice.xaml\" content captured at freeze point (status=non-stub)",
        "changedBytes": false,
        "changedStatus": false,
        "enforcementAction": "none"
      },
      {
        "stage": "pre-freeze-snapshot",
        "function": "freezeArchiveWorkflows",
        "file": "SetTransactionStatus.xaml",
        "mutationType": "xaml_bytes",
        "preHash": "N/A",
        "postHash": "c87cbd3f5316c54df356f2d2a569a58df6669e6af60ed6e199f37eaaf9a8624b",
        "allowed": true,
        "reason": "Workflow \"SetTransactionStatus.xaml\" content captured at freeze point (status=non-stub)",
        "changedBytes": false,
        "changedStatus": false,
        "enforcementAction": "none"
      }
    ],
    "perFileMutationCounts": {
      "ActionCenterCallbackHandler.xaml": 1,
      "ActionCenterTaskCreator.xaml": 1,
      "CloseAllApplications.xaml": 1,
      "CoupaSessionManager.xaml": 1,
      "Dispatcher.xaml": 1,
      "GetTransactionData.xaml": 1,
      "Init.xaml": 1,
      "InitAllSettings.xaml": 1,
      "InitPerformer.xaml": 1,
      "KillAllProcesses.xaml": 1,
      "Main.xaml": 1,
      "Process.xaml": 1,
      "ProcessInvoice.xaml": 1,
      "SetTransactionStatus.xaml": 1
    },
    "filesChangedAfterFreeze": [],
    "summary": {
      "totalAttemptedMutations": 14,
      "totalBlockedMutations": 0,
      "totalAllowedPreFreezeMutations": 14,
      "totalPostFreezeViolations": 0,
      "totalUnexpectedPostFreezeMutations": 0,
      "filesChangedAfterFreeze": 0
    }
  },
  "workflowAutoWiringDiagnostics": {
    "entries": [
      {
        "file": "CoupaSessionManager.xaml",
        "generated": true,
        "required": true,
        "workflowRole": "decomposed_child",
        "classificationSourceRule": "generated_by_spec_decomposition",
        "requiredByPath": "Main.xaml → Main.xaml → spec-decomposition:CoupaSessionManager",
        "expectedCaller": "Main.xaml",
        "callerCandidates": [
          "Main.xaml",
          "Process.xaml"
        ],
        "invokeAttempted": true,
        "invokeSucceeded": true,
        "invokeSkippedReason": null,
        "invokeRejectedReason": null,
        "actualCallers": [
          "Main.xaml"
        ],
        "reachableFromMain": true,
        "finalWiringStatus": "wired_and_reachable",
        "rootCauseCategory": "none",
        "remediationHint": null,
        "unwiredSeverity": "none"
      },
      {
        "file": "Dispatcher.xaml",
        "generated": true,
        "required": true,
        "workflowRole": "decomposed_child",
        "classificationSourceRule": "generated_by_spec_decomposition",
        "requiredByPath": "Main.xaml → Main.xaml → spec-decomposition:Dispatcher",
        "expectedCaller": "Main.xaml",
        "callerCandidates": [
          "Main.xaml",
          "Process.xaml"
        ],
        "invokeAttempted": true,
        "invokeSucceeded": true,
        "invokeSkippedReason": null,
        "invokeRejectedReason": null,
        "actualCallers": [
          "Main.xaml"
        ],
        "reachableFromMain": true,
        "finalWiringStatus": "wired_and_reachable",
        "rootCauseCategory": "none",
        "remediationHint": null,
        "unwiredSeverity": "none"
      },
      {
        "file": "InitPerformer.xaml",
        "generated": true,
        "required": true,
        "workflowRole": "decomposed_child",
        "classificationSourceRule": "generated_by_spec_decomposition",
        "requiredByPath": "Main.xaml → Main.xaml → spec-decomposition:InitPerformer",
        "expectedCaller": "Main.xaml",
        "callerCandidates": [
          "Main.xaml",
          "Process.xaml"
        ],
        "invokeAttempted": true,
        "invokeSucceeded": true,
        "invokeSkippedReason": null,
        "invokeRejectedReason": null,
        "actualCallers": [
          "Main.xaml"
        ],
        "reachableFromMain": true,
        "finalWiringStatus": "wired_and_reachable",
        "rootCauseCategory": "none",
        "remediationHint": null,
        "unwiredSeverity": "none"
      },
      {
        "file": "ProcessInvoice.xaml",
        "generated": true,
        "required": true,
        "workflowRole": "decomposed_child",
        "classificationSourceRule": "generated_by_spec_decomposition",
        "requiredByPath": "Main.xaml → Main.xaml → spec-decomposition:ProcessInvoice",
        "expectedCaller": "Main.xaml",
        "callerCandidates": [
          "Main.xaml",
          "Process.xaml"
        ],
        "invokeAttempted": true,
        "invokeSucceeded": true,
        "invokeSkippedReason": null,
        "invokeRejectedReason": null,
        "actualCallers": [
          "Main.xaml"
        ],
        "reachableFromMain": true,
        "finalWiringStatus": "wired_and_reachable",
        "rootCauseCategory": "none",
        "remediationHint": null,
        "unwiredSeverity": "none"
      },
      {
        "file": "ActionCenterTaskCreator.xaml",
        "generated": true,
        "required": true,
        "workflowRole": "decomposed_child",
        "classificationSourceRule": "generated_by_spec_decomposition",
        "requiredByPath": "Main.xaml → Main.xaml → spec-decomposition:ActionCenterTaskCreator",
        "expectedCaller": "Main.xaml",
        "callerCandidates": [
          "Main.xaml",
          "Process.xaml"
        ],
        "invokeAttempted": true,
        "invokeSucceeded": true,
        "invokeSkippedReason": null,
        "invokeRejectedReason": null,
        "actualCallers": [
          "Main.xaml"
        ],
        "reachableFromMain": true,
        "finalWiringStatus": "wired_and_reachable",
        "rootCauseCategory": "none",
        "remediationHint": null,
        "unwiredSeverity": "none"
      },
      {
        "file": "ActionCenterCallbackHandler.xaml",
        "generated": true,
        "required": true,
        "workflowRole": "decomposed_child",
        "classificationSourceRule": "generated_by_spec_decomposition",
        "requiredByPath": "Main.xaml → Main.xaml → spec-decomposition:ActionCenterCallbackHandler",
        "expectedCaller": "Main.xaml",
        "callerCandidates": [
          "Main.xaml",
          "Process.xaml"
        ],
        "invokeAttempted": true,
        "invokeSucceeded": true,
        "invokeSkippedReason": null,
        "invokeRejectedReason": null,
        "actualCallers": [
          "Main.xaml"
        ],
        "reachableFromMain": true,
        "finalWiringStatus": "wired_and_reachable",
        "rootCauseCategory": "none",
        "remediationHint": null,
        "unwiredSeverity": "none"
      },
      {
        "file": "Main.xaml",
        "generated": true,
        "required": true,
        "workflowRole": "entrypoint",
        "classificationSourceRule": "basename_match:Main",
        "requiredByPath": "Main.xaml (entry point)",
        "expectedCaller": null,
        "callerCandidates": [],
        "invokeAttempted": false,
        "invokeSucceeded": false,
        "invokeSkippedReason": "entrypoint workflow — wired by framework structure",
        "invokeRejectedReason": null,
        "actualCallers": [],
        "reachableFromMain": true,
        "finalWiringStatus": "wired_and_reachable",
        "rootCauseCategory": "none",
        "remediationHint": null,
        "unwiredSeverity": "none"
      },
      {
        "file": "Process.xaml",
        "generated": false,
        "required": true,
        "workflowRole": "entrypoint",
        "classificationSourceRule": "basename_match:Process",
        "requiredByPath": "Main.xaml (entry point)",
        "expectedCaller": "Main.xaml",
        "callerCandidates": [
          "Main.xaml"
        ],
        "invokeAttempted": false,
        "invokeSucceeded": false,
        "invokeSkippedReason": "entrypoint workflow — wired by framework structure",
        "invokeRejectedReason": null,
        "actualCallers": [
          "Main.xaml"
        ],
        "reachableFromMain": true,
        "finalWiringStatus": "wired_and_reachable",
        "rootCauseCategory": "none",
        "remediationHint": null,
        "unwiredSeverity": "none"
      },
      {
        "file": "InitAllSettings.xaml",
        "generated": false,
        "required": false,
        "workflowRole": "helper",
        "classificationSourceRule": "infrastructure_basename_match:initallsettings",
        "unwiredSeverity": "none",
        "requiredByPath": "infrastructure utility",
        "expectedCaller": "Main.xaml",
        "callerCandidates": [
          "Main.xaml"
        ],
        "invokeAttempted": false,
        "invokeSucceeded": false,
        "invokeSkippedReason": "infrastructure file — always included",
        "invokeRejectedReason": null,
        "actualCallers": [
          "Main.xaml",
          "Init.xaml"
        ],
        "reachableFromMain": true,
        "finalWiringStatus": "skipped_infrastructure",
        "rootCauseCategory": "none",
        "remediationHint": null
      },
      {
        "file": "GetTransactionData.xaml",
        "generated": false,
        "required": true,
        "workflowRole": "transaction_handler",
        "classificationSourceRule": "transaction_pattern_match:GetTransactionData",
        "requiredByPath": "Main.xaml → state-machine transition",
        "expectedCaller": "Main.xaml",
        "callerCandidates": [
          "Main.xaml"
        ],
        "invokeAttempted": true,
        "invokeSucceeded": true,
        "invokeSkippedReason": null,
        "invokeRejectedReason": null,
        "actualCallers": [
          "Main.xaml"
        ],
        "reachableFromMain": true,
        "finalWiringStatus": "wired_and_reachable",
        "rootCauseCategory": "none",
        "remediationHint": null,
        "unwiredSeverity": "none"
      },
      {
        "file": "SetTransactionStatus.xaml",
        "generated": false,
        "required": true,
        "workflowRole": "transaction_handler",
        "classificationSourceRule": "transaction_pattern_match:SetTransactionStatus",
        "requiredByPath": "Main.xaml → state-machine transition",
        "expectedCaller": "Main.xaml",
        "callerCandidates": [
          "Main.xaml"
        ],
        "invokeAttempted": true,
        "invokeSucceeded": true,
        "invokeSkippedReason": null,
        "invokeRejectedReason": null,
        "actualCallers": [
          "Main.xaml",
          "Main.xaml"
        ],
        "reachableFromMain": true,
        "finalWiringStatus": "wired_and_reachable",
        "rootCauseCategory": "none",
        "remediationHint": null,
        "unwiredSeverity": "none"
      },
      {
        "file": "CloseAllApplications.xaml",
        "generated": false,
        "required": false,
        "workflowRole": "helper",
        "classificationSourceRule": "infrastructure_basename_match:closeallapplications",
        "unwiredSeverity": "none",
        "requiredByPath": "infrastructure utility",
        "expectedCaller": "Main.xaml",
        "callerCandidates": [
          "Main.xaml"
        ],
        "invokeAttempted": false,
        "invokeSucceeded": false,
        "invokeSkippedReason": "infrastructure file — always included",
        "invokeRejectedReason": null,
        "actualCallers": [
          "Main.xaml",
          "Main.xaml"
        ],
        "reachableFromMain": true,
        "finalWiringStatus": "skipped_infrastructure",
        "rootCauseCategory": "none",
        "remediationHint": null
      },
      {
        "file": "KillAllProcesses.xaml",
        "generated": false,
        "required": false,
        "workflowRole": "helper",
        "classificationSourceRule": "infrastructure_basename_match:killallprocesses",
        "unwiredSeverity": "none",
        "requiredByPath": "infrastructure utility",
        "expectedCaller": "Main.xaml",
        "callerCandidates": [
          "Main.xaml"
        ],
        "invokeAttempted": false,
        "invokeSucceeded": false,
        "invokeSkippedReason": "infrastructure file — always included",
        "invokeRejectedReason": null,
        "actualCallers": [
          "CloseAllApplications.xaml"
        ],
        "reachableFromMain": true,
        "finalWiringStatus": "skipped_infrastructure",
        "rootCauseCategory": "none",
        "remediationHint": null
      },
      {
        "file": "Init.xaml",
        "generated": false,
        "required": false,
        "workflowRole": "helper",
        "classificationSourceRule": "non_generated_non_entrypoint",
        "requiredByPath": "Main.xaml → Main.xaml → spec-decomposition:Init",
        "expectedCaller": "Main.xaml",
        "callerCandidates": [
          "Main.xaml",
          "Process.xaml"
        ],
        "invokeAttempted": true,
        "invokeSucceeded": true,
        "invokeSkippedReason": null,
        "invokeRejectedReason": null,
        "actualCallers": [
          "Main.xaml"
        ],
        "reachableFromMain": true,
        "finalWiringStatus": "wired_and_reachable",
        "rootCauseCategory": "none",
        "remediationHint": null,
        "unwiredSeverity": "none"
      }
    ],
    "summary": {
      "totalGeneratedWorkflows": 7,
      "totalRequiredWorkflows": 10,
      "totalRequiredWorkflowsWired": 10,
      "totalGeneratedButUnwired": 0,
      "totalUnreachableFromMain": 0,
      "totalMissingInvokeEdges": 0,
      "totalCallerMismatchDefects": 1,
      "totalInvokeEmissionFailures": 0
    },
    "activePathProof": {
      "reachabilityComputedOnFinalizedSet": true,
      "reachabilityPruningSkipped": true,
      "wiringComputedOnFinalizedSet": true,
      "workflowSetHashAtWiringTime": "e2a908bb220c852f",
      "workflowSetHashAtReachabilityTime": "e2a908bb220c852f",
      "consistent": true
    }
  },
  "catalogFilterAdoption": [
    {
      "stage": "quality-gate",
      "adopted": true,
      "lookups": {
        "total": 248,
        "approved": 248,
        "deprecated": 0,
        "nonEmissionApproved": 0,
        "targetIncompatible": 0,
        "unknown": 0
      }
    },
    {
      "stage": "deterministic-validators",
      "adopted": true,
      "lookups": {
        "total": 4160,
        "approved": 1480,
        "deprecated": 0,
        "nonEmissionApproved": 0,
        "targetIncompatible": 0,
        "unknown": 2680
      }
    },
    {
      "stage": "iterative-llm-corrector",
      "adopted": true,
      "lookups": {
        "total": 0,
        "approved": 0,
        "deprecated": 0,
        "nonEmissionApproved": 0,
        "targetIncompatible": 0,
        "unknown": 0
      }
    },
    {
      "stage": "workflow-tree-assembler",
      "adopted": true,
      "lookups": {
        "total": 0,
        "approved": 0,
        "deprecated": 0,
        "nonEmissionApproved": 0,
        "targetIncompatible": 0,
        "unknown": 0
      }
    },
    {
      "stage": "xaml-compliance",
      "adopted": true,
      "lookups": {
        "total": 189054,
        "approved": 80130,
        "deprecated": 0,
        "nonEmissionApproved": 107469,
        "targetIncompatible": 0,
        "unknown": 1455
      }
    },
    {
      "stage": "executable-path-validator",
      "adopted": true,
      "lookups": {
        "total": 204,
        "approved": 190,
        "deprecated": 0,
        "nonEmissionApproved": 0,
        "targetIncompatible": 0,
        "unknown": 14
      }
    },
    {
      "stage": "post-emission-dependency-analyzer",
      "adopted": true,
      "lookups": {
        "total": 9,
        "approved": 9,
        "deprecated": 0,
        "nonEmissionApproved": 0,
        "targetIncompatible": 0,
        "unknown": 0
      }
    }
  ]
}
```
