# Developer Handoff Guide

**Project:** BirthdayGreetingsYY
**Generated:** 2026-04-14
**Generation Mode:** Full Implementation
**Deployment Readiness:** Mostly Ready (66%)
**CLI Validation:** CLI Skipped (incompatible agent) | Project Type: Windows

> **Note:** CLI authoritative validation was skipped because the current runner is not compatible with the project type (Windows). This package has been validated with custom validators only. Full CLI validation requires a Windows runner.

**19 workflows: 13 fully generated, 4 with handoff blocks, 2 workflow-level stubs**
**Total Estimated Effort: ~895 minutes (14.9 hours)**
**Remediations:** 69 total (0 property, 14 activity, 0 sequence, 0 structural-leaf, 2 workflow)
**Auto-Repairs:** 22
**Quality Warnings:** 65

---

### Per-Workflow Preservation Summary

| # | Workflow | Tier | Business Steps (SDD) | Preserved | Degraded (Handoff) | Manual | Bind Points |
|---|----------|------|-------------|-----------|-------------------|--------|-------------|
| 1 | `BGYY_GetTodaysBirthdays.xaml` | Stub | 1 | 0 | 0 | 1 | 0 |
| 2 | `BGYY_ResolveRecipient.xaml` | Handoff | 1 | 0 | 2 | 2 | 0 |
| 3 | `BGYY_CheckDedupe.xaml` | Generated | 1 | 1 | 0 | 0 | 0 |
| 4 | `BGYY_GenerateAndValidateDraft.xaml` | Generated | 1 | 1 | 0 | 0 | 0 |
| 5 | `BGYY_SendGmail.xaml` | Handoff | 1 | 0 | 2 | 2 | 0 |
| 6 | `BGYY_WriteDedupe.xaml` | Handoff | 1 | 0 | 2 | 2 | 0 |
| 7 | `BGYY_CreateReviewTask.xaml` | Handoff | 1 | 0 | 2 | 2 | 0 |
| 8 | `BGYY_Main.xaml` | Stub | 1 | 0 | 5 | 1 | 0 |
| 9 | `InitAllSettings.xaml` | Generated | 1 | 1 | 0 | 0 | 0 |
| 10 | `Main.xaml` | Generated | 1 | 1 | 0 | 0 | 0 |
| 11 | `GetTransactionData.xaml` | Generated | 1 | 1 | 0 | 0 | 0 |
| 12 | `SetTransactionStatus.xaml` | Generated | 1 | 1 | 0 | 0 | 0 |
| 13 | `CloseAllApplications.xaml` | Generated | 1 | 1 | 0 | 0 | 0 |
| 14 | `KillAllProcesses.xaml` | Generated | 1 | 1 | 0 | 0 | 0 |
| 15 | `Init.xaml` | Generated | 1 | 1 | 0 | 0 | 0 |
| 16 | `InitAllApplications.xaml` | Generated | 1 | 1 | 0 | 0 | 0 |
| 17 | `RetryCurrentTransaction.xaml` | Generated | 1 | 1 | 0 | 0 | 0 |
| 18 | `RetryInit.xaml` | Generated | 1 | 1 | 0 | 0 | 0 |
| 19 | `Process.xaml` | Generated | 1 | 1 | 0 | 0 | 0 |

## 1. Generated Logic (ready to use)

Generated XAML that is Studio-openable and does not contain handoff blocks or workflow-level stubs. May include auto-resolved property remediations or placeholders for fine-tuning.

The following 13 workflow(s) were fully generated and are ready to use:

| # | Workflow | Status | Studio Compatibility |
|---|----------|--------|---------------------|
| 1 | `BGYY_CheckDedupe.xaml` | Generated with Remediations | Studio-openable |
| 2 | `BGYY_GenerateAndValidateDraft.xaml` | Generated with Placeholders | Openable with warnings |
| 3 | `InitAllSettings.xaml` | Generated with Remediations | Studio-openable |
| 4 | `Main.xaml` | Generated with Remediations | Openable with warnings |
| 5 | `GetTransactionData.xaml` | Generated with Remediations | Studio-openable |
| 6 | `SetTransactionStatus.xaml` | Fully Generated | Studio-openable |
| 7 | `CloseAllApplications.xaml` | Fully Generated | Studio-openable |
| 8 | `KillAllProcesses.xaml` | Fully Generated | Studio-openable |
| 9 | `Init.xaml` | Generated with Remediations | Openable with warnings |
| 10 | `InitAllApplications.xaml` | Generated with Placeholders | Openable with warnings |
| 11 | `RetryCurrentTransaction.xaml` | Generated with Remediations | Studio-openable |
| 12 | `RetryInit.xaml` | Generated with Remediations | Studio-openable |
| 13 | `Process.xaml` | Fully Generated | Studio-openable |

### AI-Resolved with Smart Defaults (22)

The following issue(s) were automatically corrected during the build pipeline. **No developer action required.**

| # | Code | File | Description | Est. Minutes Saved |
|---|------|------|-------------|-------------------|
| 1 | `REPAIR_PLACEHOLDER_CLEANUP` | `BGYY_GetTodaysBirthdays.xaml` | Stripped 4 placeholder token(s) from BGYY_GetTodaysBirthdays.xaml | 5 |
| 2 | `REPAIR_PLACEHOLDER_CLEANUP` | `BGYY_ResolveRecipient.xaml` | Stripped 9 placeholder token(s) from BGYY_ResolveRecipient.xaml | 5 |
| 3 | `REPAIR_PLACEHOLDER_CLEANUP` | `BGYY_GenerateAndValidateDraft.xaml` | Stripped 6 placeholder token(s) from BGYY_GenerateAndValidateDraft.xaml | 5 |
| 4 | `REPAIR_PLACEHOLDER_CLEANUP` | `BGYY_SendGmail.xaml` | Stripped 3 placeholder token(s) from BGYY_SendGmail.xaml | 5 |
| 5 | `REPAIR_PLACEHOLDER_CLEANUP` | `BGYY_CreateReviewTask.xaml` | Stripped 1 placeholder token(s) from BGYY_CreateReviewTask.xaml | 5 |
| 6 | `REPAIR_PLACEHOLDER_CLEANUP` | `BGYY_Main.xaml` | Stripped 5 placeholder token(s) from BGYY_Main.xaml | 5 |
| 7 | `REPAIR_PLACEHOLDER_CLEANUP` | `InitAllApplications.xaml` | Stripped 1 placeholder token(s) from InitAllApplications.xaml | 5 |
| 8 | `REPAIR_GENERIC` | `BGYY_GetTodaysBirthdays.xaml` | Catalog (DOM): move-to-child-element ForEach.Values in BGYY_GetTodaysBirthdays.xaml | undefined |
| 9 | `REPAIR_GENERIC` | `BGYY_GetTodaysBirthdays.xaml` | Catalog (DOM): move-to-child-element ui:AddDataRow.DataTable in BGYY_GetTodaysBirthdays.xaml | undefined |
| 10 | `REPAIR_GENERIC` | `BGYY_ResolveRecipient.xaml` | Catalog (DOM): move-to-child-element ForEach.Values in BGYY_ResolveRecipient.xaml | undefined |
| 11 | `REPAIR_GENERIC` | `BGYY_GenerateAndValidateDraft.xaml` | Catalog (DOM): move-to-child-element ForEach.Values in BGYY_GenerateAndValidateDraft.xaml | undefined |
| 12 | `REPAIR_GENERIC` | `BGYY_Main.xaml` | Catalog (DOM): move-to-child-element ForEach.Values in BGYY_Main.xaml | undefined |
| 13 | `REPAIR_GENERIC` | `InitAllSettings.xaml` | Catalog (DOM): move-to-child-element ForEach.Values in InitAllSettings.xaml | undefined |
| 14 | `REPAIR_GENERIC` | `InitAllSettings.xaml` | Catalog (DOM): move-to-child-element ForEach.Values in InitAllSettings.xaml | undefined |
| 15 | `REPAIR_GENERIC` | `GetTransactionData.xaml` | Catalog (DOM): move-to-child-element ui:GetTransactionItem.QueueName in GetTransactionData.xaml | undefined |
| 16 | `REPAIR_MIXED_EXPRESSION_SYNTAX` | `BGYY_Main.xaml` | Mixed-expression: [BGYY_Main] Workflow started. Initializing run context. → [BGYY_Main &amp; &quo... | undefined |
| 17 | `REPAIR_TYPE_MISMATCH` | `BGYY_GetTodaysBirthdays.xaml` | Object variable is bound to a property expecting IEnumerable — retype the variable to the correct... | undefined |
| 18 | `REPAIR_TYPE_MISMATCH` | `BGYY_ResolveRecipient.xaml` | Object variable is bound to a property expecting IEnumerable — retype the variable to the correct... | undefined |
| 19 | `REPAIR_TYPE_MISMATCH` | `BGYY_SendGmail.xaml` | No known conversion from System.String to UiPath.Platform.ResourceHandling.IResource — review the... | undefined |
| 20 | `REPAIR_TYPE_MISMATCH` | `Main.xaml` | No known conversion from scg:Dictionary(x:String, x:Object) to System.Collections.Generic.Diction... | undefined |
| 21 | `REPAIR_TYPE_MISMATCH` | `Main.xaml` | No known conversion from UiPath.Core.QueueItem to System.Collections.Generic.Dictionary`<System.S... | undefined |
| 22 | `REPAIR_TYPE_MISMATCH` | `Init.xaml` | No known conversion from scg:Dictionary(x:String, x:Object) to System.Collections.Generic.Diction... | undefined |

### Studio Compatibility

| # | Workflow | Compatibility | Failure Category | Blockers |
|---|----------|--------------|-----------------|----------|
| 1 | `BGYY_GetTodaysBirthdays.xaml` | Studio-openable | — | — |
| 2 | `BGYY_ResolveRecipient.xaml` | Openable with warnings | Unclassified | — |
| 3 | `BGYY_CheckDedupe.xaml` | Studio-openable | — | — |
| 4 | `BGYY_GenerateAndValidateDraft.xaml` | Openable with warnings | Unclassified | — |
| 5 | `BGYY_SendGmail.xaml` | Openable with warnings | Unclassified | — |
| 6 | `BGYY_WriteDedupe.xaml` | Studio-openable | — | — |
| 7 | `BGYY_CreateReviewTask.xaml` | Openable with warnings | Unclassified | — |
| 8 | `BGYY_Main.xaml` | Studio-openable | — | — |
| 9 | `InitAllSettings.xaml` | Studio-openable | — | — |
| 10 | `Main.xaml` | Openable with warnings | Unclassified | — |
| 11 | `GetTransactionData.xaml` | Studio-openable | — | — |
| 12 | `SetTransactionStatus.xaml` | Studio-openable | — | — |
| 13 | `CloseAllApplications.xaml` | Studio-openable | — | — |
| 14 | `KillAllProcesses.xaml` | Studio-openable | — | — |
| 15 | `Init.xaml` | Openable with warnings | Unclassified | — |
| 16 | `InitAllApplications.xaml` | Openable with warnings | Unclassified | — |
| 17 | `RetryCurrentTransaction.xaml` | Studio-openable | — | — |
| 18 | `RetryInit.xaml` | Studio-openable | — | — |
| 19 | `Process.xaml` | Studio-openable | — | — |

**Summary:** 12 Studio-loadable, 7 with warnings, 0 not Studio-loadable

### Symbol Discovery Diagnostics

**Auto-declared:** 1 symbol(s) | **Withheld:** 349 symbol(s)

| Symbol | Category | Reason |
|--------|----------|--------|
| `Is` | variable | Withheld: excluded symbol token (keyword/CLR type/XML entity) |
| `Nothing` | variable | Withheld: excluded symbol token (keyword/CLR type/XML entity) |
| `New` | variable | Withheld: excluded symbol token (keyword/CLR type/XML entity) |
| `InvalidOperationException` | variable | Withheld: identifier used as function call |
| `If` | variable | Withheld: excluded symbol token (keyword/CLR type/XML entity) |
| `IsNot` | variable | Withheld: excluded symbol token (keyword/CLR type/XML entity) |
| `Nothing` | variable | Withheld: excluded symbol token (keyword/CLR type/XML entity) |
| `AndAlso` | variable | Withheld: excluded symbol token (keyword/CLR type/XML entity) |
| `GetType` | variable | Withheld: excluded symbol token (keyword/CLR type/XML entity) |
| `GetProperty` | variable | Withheld: identifier used as function call |
| `CStr` | variable | Withheld: excluded symbol token (keyword/CLR type/XML entity) |
| `GetValue` | variable | Withheld: identifier used as function call |
| `If` | variable | Withheld: excluded symbol token (keyword/CLR type/XML entity) |
| `IsNot` | variable | Withheld: excluded symbol token (keyword/CLR type/XML entity) |
| `Nothing` | variable | Withheld: excluded symbol token (keyword/CLR type/XML entity) |
| `AndAlso` | variable | Withheld: excluded symbol token (keyword/CLR type/XML entity) |
| `GetType` | variable | Withheld: excluded symbol token (keyword/CLR type/XML entity) |
| `GetProperty` | variable | Withheld: identifier used as function call |
| `CStr` | variable | Withheld: excluded symbol token (keyword/CLR type/XML entity) |
| `GetValue` | variable | Withheld: identifier used as function call |
| `If` | variable | Withheld: excluded symbol token (keyword/CLR type/XML entity) |
| `IsNot` | variable | Withheld: excluded symbol token (keyword/CLR type/XML entity) |
| `Nothing` | variable | Withheld: excluded symbol token (keyword/CLR type/XML entity) |
| `AndAlso` | variable | Withheld: excluded symbol token (keyword/CLR type/XML entity) |
| `GetType` | variable | Withheld: excluded symbol token (keyword/CLR type/XML entity) |
| `GetProperty` | variable | Withheld: identifier used as function call |
| `CStr` | variable | Withheld: excluded symbol token (keyword/CLR type/XML entity) |
| `GetValue` | variable | Withheld: identifier used as function call |
| `ToString` | variable | Withheld: identifier used as function call |
| `String` | variable | Withheld: excluded symbol token (keyword/CLR type/XML entity) |
| `IsNullOrWhiteSpace` | variable | Withheld: identifier used as function call |
| `OrElse` | variable | Withheld: excluded symbol token (keyword/CLR type/XML entity) |
| `True` | variable | Withheld: excluded symbol token (keyword/CLR type/XML entity) |
| `System` | variable | Withheld: excluded symbol token (keyword/CLR type/XML entity) |
| `Text` | variable | Withheld: excluded symbol token (keyword/CLR type/XML entity) |
| `RegularExpressions` | variable | Withheld: PascalCase identifier followed by dot (member access) |
| `Regex` | variable | Withheld: excluded symbol token (keyword/CLR type/XML entity) |
| `Replace` | variable | Withheld: excluded symbol token (keyword/CLR type/XML entity) |
| `Trim` | variable | Withheld: excluded symbol token (keyword/CLR type/XML entity) |
| `If` | variable | Withheld: excluded symbol token (keyword/CLR type/XML entity) |
| `DateTime` | variable | Withheld: excluded symbol token (keyword/CLR type/XML entity) |
| `TryParse` | variable | Withheld: identifier used as function call |
| `Nothing` | variable | Withheld: excluded symbol token (keyword/CLR type/XML entity) |
| `System` | variable | Withheld: excluded symbol token (keyword/CLR type/XML entity) |
| `Globalization` | variable | Withheld: excluded symbol token (keyword/CLR type/XML entity) |
| `DateTimeStyles` | variable | Withheld: PascalCase identifier followed by dot (member access) |
| `RoundtripKind` | variable | Withheld: identifier accessed as member |
| `Parse` | variable | Withheld: identifier used as function call |
| `New` | variable | Withheld: excluded symbol token (keyword/CLR type/XML entity) |
| `Object` | variable | Withheld: excluded symbol token (keyword/CLR type/XML entity) |
| `Rows` | variable | Withheld: PascalCase identifier followed by dot (member access) |
| `Count` | variable | Withheld: identifier accessed as member |
| `Trim` | variable | Withheld: excluded symbol token (keyword/CLR type/XML entity) |
| `ToLower` | variable | Withheld: identifier used as function call |
| `Is` | variable | Withheld: excluded symbol token (keyword/CLR type/XML entity) |
| `Nothing` | variable | Withheld: excluded symbol token (keyword/CLR type/XML entity) |
| `ToString` | variable | Withheld: identifier used as function call |
| `ToLower` | variable | Withheld: identifier used as function call |
| `personal` | variable | No prefix and no expression context evidence — declaration blocked to avoid generic placeholder |
| `home` | variable | No prefix and no expression context evidence — declaration blocked to avoid generic placeholder |
| `Nothing` | variable | Withheld: excluded symbol token (keyword/CLR type/XML entity) |
| `Nothing` | variable | Withheld: excluded symbol token (keyword/CLR type/XML entity) |
| `Nothing` | variable | Withheld: excluded symbol token (keyword/CLR type/XML entity) |
| `String` | variable | Withheld: excluded symbol token (keyword/CLR type/XML entity) |
| `IsNullOrWhiteSpace` | variable | Withheld: identifier used as function call |
| `ToString` | variable | Withheld: identifier used as function call |
| `If` | variable | Withheld: excluded symbol token (keyword/CLR type/XML entity) |
| `IsNot` | variable | Withheld: excluded symbol token (keyword/CLR type/XML entity) |
| `Nothing` | variable | Withheld: excluded symbol token (keyword/CLR type/XML entity) |
| `DirectCast` | variable | Withheld: excluded symbol token (keyword/CLR type/XML entity) |
| `System` | variable | Withheld: excluded symbol token (keyword/CLR type/XML entity) |
| `Collections` | variable | Withheld: excluded symbol token (keyword/CLR type/XML entity) |
| `ICollection` | variable | Withheld: identifier accessed as member |
| `Count` | variable | Withheld: identifier accessed as member |
| `IsNot` | variable | Withheld: excluded symbol token (keyword/CLR type/XML entity) |
| `Nothing` | variable | Withheld: excluded symbol token (keyword/CLR type/XML entity) |
| `If` | variable | Withheld: excluded symbol token (keyword/CLR type/XML entity) |
| `String` | variable | Withheld: excluded symbol token (keyword/CLR type/XML entity) |
| `IsNullOrWhiteSpace` | variable | Withheld: identifier used as function call |
| `New` | variable | Withheld: excluded symbol token (keyword/CLR type/XML entity) |
| `Split` | variable | Withheld: excluded symbol token (keyword/CLR type/XML entity) |
| `Environment` | variable | Withheld: excluded symbol token (keyword/CLR type/XML entity) |
| `NewLine` | variable | Withheld: identifier accessed as member |
| `StringSplitOptions` | variable | Withheld: PascalCase identifier followed by dot (member access) |
| `RemoveEmptyEntries` | variable | Withheld: identifier accessed as member |
| `Function` | variable | Withheld: VB.NET reserved word |
| `Array` | variable | Withheld: excluded symbol token (keyword/CLR type/XML entity) |
| `ConvertAll` | variable | Withheld: identifier used as function call |
| `s` | variable | Withheld: identifier too short |
| `Trim` | variable | Withheld: excluded symbol token (keyword/CLR type/XML entity) |
| `Where` | variable | Withheld: identifier used as function call |
| `Not` | variable | Withheld: excluded symbol token (keyword/CLR type/XML entity) |
| `ToArray` | variable | Withheld: identifier used as function call |
| `Environment` | variable | Withheld: excluded symbol token (keyword/CLR type/XML entity) |
| `NewLine` | variable | Withheld: identifier accessed as member |
| `If` | variable | Withheld: excluded symbol token (keyword/CLR type/XML entity) |
| `Not` | variable | Withheld: excluded symbol token (keyword/CLR type/XML entity) |
| `String` | variable | Withheld: excluded symbol token (keyword/CLR type/XML entity) |
| `IsNullOrWhiteSpace` | variable | Withheld: identifier used as function call |
| `String` | variable | Withheld: excluded symbol token (keyword/CLR type/XML entity) |
| `IsNullOrWhiteSpace` | variable | Withheld: identifier used as function call |
| `True` | variable | Withheld: excluded symbol token (keyword/CLR type/XML entity) |
| `Newtonsoft` | variable | Withheld: excluded symbol token (keyword/CLR type/XML entity) |
| `Json` | variable | Withheld: excluded symbol token (keyword/CLR type/XML entity) |
| `Linq` | variable | Withheld: excluded symbol token (keyword/CLR type/XML entity) |
| `JObject` | variable | Withheld: excluded symbol token (keyword/CLR type/XML entity) |
| `Parse` | variable | Withheld: identifier used as function call |
| `ToString` | variable | Withheld: identifier used as function call |
| `Newtonsoft` | variable | Withheld: excluded symbol token (keyword/CLR type/XML entity) |
| `Json` | variable | Withheld: excluded symbol token (keyword/CLR type/XML entity) |
| `Linq` | variable | Withheld: excluded symbol token (keyword/CLR type/XML entity) |
| `JObject` | variable | Withheld: excluded symbol token (keyword/CLR type/XML entity) |
| `Parse` | variable | Withheld: identifier used as function call |
| `ToString` | variable | Withheld: identifier used as function call |
| `Not` | variable | Withheld: excluded symbol token (keyword/CLR type/XML entity) |
| `String` | variable | Withheld: excluded symbol token (keyword/CLR type/XML entity) |
| `IsNullOrWhiteSpace` | variable | Withheld: identifier used as function call |
| `AndAlso` | variable | Withheld: excluded symbol token (keyword/CLR type/XML entity) |
| `True` | variable | Withheld: excluded symbol token (keyword/CLR type/XML entity) |
| `ToLowerInvariant` | variable | Withheld: identifier used as function call |
| `Contains` | variable | Withheld: identifier used as function call |
| `False` | variable | Withheld: excluded symbol token (keyword/CLR type/XML entity) |
| `Split` | variable | Withheld: excluded symbol token (keyword/CLR type/XML entity) |
| `New` | variable | Withheld: excluded symbol token (keyword/CLR type/XML entity) |
| `Char` | variable | Withheld: excluded symbol token (keyword/CLR type/XML entity) |
| `c` | variable | Withheld: identifier too short |
| `Environment` | variable | Withheld: excluded symbol token (keyword/CLR type/XML entity) |
| `NewLine` | variable | Withheld: identifier used as function call |
| `StringSplitOptions` | variable | Withheld: PascalCase identifier followed by dot (member access) |
| `RemoveEmptyEntries` | variable | Withheld: identifier accessed as member |
| `Length` | variable | Withheld: identifier accessed as member |
| `OrElse` | variable | Withheld: excluded symbol token (keyword/CLR type/XML entity) |
| `True` | variable | Withheld: excluded symbol token (keyword/CLR type/XML entity) |
| `AndAlso` | variable | Withheld: excluded symbol token (keyword/CLR type/XML entity) |
| `Not` | variable | Withheld: excluded symbol token (keyword/CLR type/XML entity) |
| `String` | variable | Withheld: excluded symbol token (keyword/CLR type/XML entity) |
| `IsNullOrWhiteSpace` | variable | Withheld: identifier used as function call |
| `ToLowerInvariant` | variable | Withheld: identifier used as function call |
| `Contains` | variable | Withheld: identifier used as function call |
| `Newtonsoft` | variable | Withheld: excluded symbol token (keyword/CLR type/XML entity) |
| `Json` | variable | Withheld: excluded symbol token (keyword/CLR type/XML entity) |
| `JsonConvert` | variable | Withheld: excluded symbol token (keyword/CLR type/XML entity) |
| `SerializeObject` | variable | Withheld: identifier used as function call |
| `New` | variable | Withheld: excluded symbol token (keyword/CLR type/XML entity) |
| `With` | variable | Withheld: excluded symbol token (keyword/CLR type/XML entity) |
| `RunId` | variable | Withheld: identifier accessed as member |
| `FullName` | variable | Withheld: identifier accessed as member |
| `Subject` | variable | Withheld: identifier accessed as member |
| `Body` | variable | Withheld: identifier accessed as member |
| `ValidationPassed` | variable | Withheld: identifier accessed as member |
| `ValidationReason` | variable | Withheld: identifier accessed as member |
| `If` | variable | Withheld: excluded symbol token (keyword/CLR type/XML entity) |
| `WordCount` | variable | Withheld: identifier accessed as member |
| `BannedPhraseFound` | variable | Withheld: identifier accessed as member |
| `VoiceProfileLoaded` | variable | Withheld: identifier accessed as member |
| `GeneratedAt` | variable | Withheld: identifier accessed as member |
| `DateTime` | variable | Withheld: excluded symbol token (keyword/CLR type/XML entity) |
| `UtcNow` | variable | Withheld: PascalCase identifier followed by dot (member access) |
| `ToString` | variable | Withheld: identifier used as function call |
| `System` | variable | Withheld: excluded symbol token (keyword/CLR type/XML entity) |
| `Text` | variable | Withheld: excluded symbol token (keyword/CLR type/XML entity) |
| `RegularExpressions` | variable | Withheld: PascalCase identifier followed by dot (member access) |
| `Regex` | variable | Withheld: excluded symbol token (keyword/CLR type/XML entity) |
| `Replace` | variable | Withheld: excluded symbol token (keyword/CLR type/XML entity) |
| `Boolean` | variable | Withheld: excluded symbol token (keyword/CLR type/XML entity) |
| `Parse` | variable | Withheld: identifier used as function call |
| `If` | variable | Withheld: excluded symbol token (keyword/CLR type/XML entity) |
| `String` | variable | Withheld: excluded symbol token (keyword/CLR type/XML entity) |
| `IsNullOrWhiteSpace` | variable | Withheld: identifier used as function call |
| `True` | variable | Withheld: excluded symbol token (keyword/CLR type/XML entity) |
| `String` | variable | Withheld: excluded symbol token (keyword/CLR type/XML entity) |
| `IsNullOrWhiteSpace` | variable | Withheld: identifier used as function call |
| `OrElse` | variable | Withheld: excluded symbol token (keyword/CLR type/XML entity) |
| `New` | variable | Withheld: excluded symbol token (keyword/CLR type/XML entity) |
| `System` | variable | Withheld: excluded symbol token (keyword/CLR type/XML entity) |
| `ArgumentException` | variable | Withheld: identifier used as function call |
| `System` | variable | Withheld: excluded symbol token (keyword/CLR type/XML entity) |
| `IO` | variable | Withheld: excluded symbol token (keyword/CLR type/XML entity) |
| `Path` | variable | Withheld: excluded symbol token (keyword/CLR type/XML entity) |
| `Combine` | variable | Withheld: identifier used as function call |
| `GetTempPath` | variable | Withheld: identifier used as function call |
| `DateTime` | variable | Withheld: excluded symbol token (keyword/CLR type/XML entity) |
| `UtcNow` | variable | Withheld: PascalCase identifier followed by dot (member access) |
| `ToString` | variable | Withheld: identifier used as function call |
| `GetHashCode` | variable | Withheld: identifier used as function call |
| `ToString` | variable | Withheld: identifier used as function call |
| `DateTime` | variable | Withheld: excluded symbol token (keyword/CLR type/XML entity) |
| `UtcNow` | variable | Withheld: PascalCase identifier followed by dot (member access) |
| `Trim` | variable | Withheld: excluded symbol token (keyword/CLR type/XML entity) |
| `ToLowerInvariant` | variable | Withheld: identifier used as function call |
| `True` | variable | Withheld: excluded symbol token (keyword/CLR type/XML entity) |
| `DateTime` | variable | Withheld: excluded symbol token (keyword/CLR type/XML entity) |
| `UtcNow` | variable | Withheld: PascalCase identifier followed by dot (member access) |
| `AddHours` | variable | Withheld: identifier used as function call |
| `DateTime` | variable | Withheld: excluded symbol token (keyword/CLR type/XML entity) |
| `UtcNow` | variable | Withheld: PascalCase identifier followed by dot (member access) |
| `ToString` | variable | Withheld: identifier used as function call |
| `InArgument` | variable | No prefix and no expression context evidence — declaration blocked to avoid generic placeholder |
| `x` | variable | Withheld: identifier too short |
| `Object` | variable | Withheld: excluded symbol token (keyword/CLR type/XML entity) |
| `vb_expression` | variable | No prefix and no expression context evidence — declaration blocked to avoid generic placeholder |
| `InArgument` | variable | No prefix and no expression context evidence — declaration blocked to avoid generic placeholder |
| `x` | variable | Withheld: identifier too short |
| `Object` | variable | Withheld: excluded symbol token (keyword/CLR type/XML entity) |
| `From` | variable | No prefix and no expression context evidence — declaration blocked to avoid generic placeholder |
| `New` | variable | Withheld: excluded symbol token (keyword/CLR type/XML entity) |
| `Dictionary` | variable | Withheld: excluded symbol token (keyword/CLR type/XML entity) |
| `Of` | variable | Withheld: excluded symbol token (keyword/CLR type/XML entity) |
| `String` | variable | Withheld: excluded symbol token (keyword/CLR type/XML entity) |
| `Object` | variable | Withheld: excluded symbol token (keyword/CLR type/XML entity) |
| `Nothing` | variable | Withheld: excluded symbol token (keyword/CLR type/XML entity) |
| `False` | variable | Withheld: excluded symbol token (keyword/CLR type/XML entity) |
| `Guid` | variable | Withheld: excluded symbol token (keyword/CLR type/XML entity) |
| `NewGuid` | variable | Withheld: identifier used as function call |
| `ToString` | variable | Withheld: identifier used as function call |
| `Substring` | variable | Withheld: identifier used as function call |
| `ToUpper` | variable | Withheld: identifier used as function call |
| `TimeZoneInfo` | variable | Withheld: excluded symbol token (keyword/CLR type/XML entity) |
| `FindSystemTimeZoneById` | variable | Withheld: identifier used as function call |
| `TimeZoneInfo` | variable | Withheld: excluded symbol token (keyword/CLR type/XML entity) |
| `ConvertTimeFromUtc` | variable | Withheld: identifier used as function call |
| `DateTime` | variable | Withheld: excluded symbol token (keyword/CLR type/XML entity) |
| `UtcNow` | variable | Withheld: identifier accessed as member |
| `CType` | variable | Withheld: excluded symbol token (keyword/CLR type/XML entity) |
| `Date` | variable | Withheld: excluded symbol token (keyword/CLR type/XML entity) |
| `Year` | variable | Withheld: excluded symbol token (keyword/CLR type/XML entity) |
| `String` | variable | Withheld: excluded symbol token (keyword/CLR type/XML entity) |
| `Equals` | variable | Withheld: identifier used as function call |
| `StringComparison` | variable | Withheld: PascalCase identifier followed by dot (member access) |
| `OrdinalIgnoreCase` | variable | Withheld: identifier accessed as member |
| `InArgument` | variable | No prefix and no expression context evidence — declaration blocked to avoid generic placeholder |
| `x` | variable | Withheld: identifier too short |
| `Object` | variable | Withheld: excluded symbol token (keyword/CLR type/XML entity) |
| `vb_expression` | variable | No prefix and no expression context evidence — declaration blocked to avoid generic placeholder |
| `InArgument` | variable | No prefix and no expression context evidence — declaration blocked to avoid generic placeholder |
| `x` | variable | Withheld: identifier too short |
| `Object` | variable | Withheld: excluded symbol token (keyword/CLR type/XML entity) |
| `in_TodayEastern` | argument | No type evidence from prefix for argument "in_TodayEastern" |
| `in_RunId` | argument | No type evidence from prefix for argument "in_RunId" |
| `out_BirthdayEvents` | argument | No type evidence from prefix for argument "out_BirthdayEvents" |
| `From` | variable | No prefix and no expression context evidence — declaration blocked to avoid generic placeholder |
| `New` | variable | Withheld: excluded symbol token (keyword/CLR type/XML entity) |
| `Dictionary` | variable | Withheld: excluded symbol token (keyword/CLR type/XML entity) |
| `Of` | variable | Withheld: excluded symbol token (keyword/CLR type/XML entity) |
| `String` | variable | Withheld: excluded symbol token (keyword/CLR type/XML entity) |
| `Object` | variable | Withheld: excluded symbol token (keyword/CLR type/XML entity) |
| `If` | variable | Withheld: excluded symbol token (keyword/CLR type/XML entity) |
| `IsNot` | variable | Withheld: excluded symbol token (keyword/CLR type/XML entity) |
| `Nothing` | variable | Withheld: excluded symbol token (keyword/CLR type/XML entity) |
| `Length` | variable | Withheld: identifier accessed as member |
| `Dim` | variable | Withheld: excluded symbol token (keyword/CLR type/XML entity) |
| `eventDict` | variable | Withheld: identifier used as function call |
| `CType` | variable | Withheld: excluded symbol token (keyword/CLR type/XML entity) |
| `Dictionary` | variable | Withheld: excluded symbol token (keyword/CLR type/XML entity) |
| `Of` | variable | Withheld: excluded symbol token (keyword/CLR type/XML entity) |
| `String` | variable | Withheld: excluded symbol token (keyword/CLR type/XML entity) |
| `Object` | variable | Withheld: excluded symbol token (keyword/CLR type/XML entity) |
| `If` | variable | Withheld: excluded symbol token (keyword/CLR type/XML entity) |
| `ContainsKey` | variable | Withheld: identifier used as function call |
| `ToString` | variable | Withheld: identifier used as function call |
| `Trim` | variable | Withheld: excluded symbol token (keyword/CLR type/XML entity) |
| `AndAlso` | variable | Withheld: excluded symbol token (keyword/CLR type/XML entity) |
| `IsNot` | variable | Withheld: excluded symbol token (keyword/CLR type/XML entity) |
| `Nothing` | variable | Withheld: excluded symbol token (keyword/CLR type/XML entity) |
| `Then` | variable | Withheld: excluded symbol token (keyword/CLR type/XML entity) |
| `DateTime` | variable | Withheld: excluded symbol token (keyword/CLR type/XML entity) |
| `End` | variable | Withheld: excluded symbol token (keyword/CLR type/XML entity) |
| `From` | variable | No prefix and no expression context evidence — declaration blocked to avoid generic placeholder |
| `New` | variable | Withheld: excluded symbol token (keyword/CLR type/XML entity) |
| `Dictionary` | variable | Withheld: excluded symbol token (keyword/CLR type/XML entity) |
| `Of` | variable | Withheld: excluded symbol token (keyword/CLR type/XML entity) |
| `String` | variable | Withheld: excluded symbol token (keyword/CLR type/XML entity) |
| `Object` | variable | Withheld: excluded symbol token (keyword/CLR type/XML entity) |
| `System` | variable | Withheld: excluded symbol token (keyword/CLR type/XML entity) |
| `Text` | variable | Withheld: excluded symbol token (keyword/CLR type/XML entity) |
| `RegularExpressions` | variable | Withheld: PascalCase identifier followed by dot (member access) |
| `Regex` | variable | Withheld: excluded symbol token (keyword/CLR type/XML entity) |
| `Replace` | variable | Withheld: excluded symbol token (keyword/CLR type/XML entity) |
| `Trim` | variable | Withheld: excluded symbol token (keyword/CLR type/XML entity) |
| `ToLowerInvariant` | variable | Withheld: identifier used as function call |
| `InArgument` | variable | No prefix and no expression context evidence — declaration blocked to avoid generic placeholder |
| `x` | variable | Withheld: identifier too short |
| `Object` | variable | Withheld: excluded symbol token (keyword/CLR type/XML entity) |
| `vb_expression` | variable | No prefix and no expression context evidence — declaration blocked to avoid generic placeholder |
| `InArgument` | variable | No prefix and no expression context evidence — declaration blocked to avoid generic placeholder |
| `x` | variable | Withheld: identifier too short |
| `Object` | variable | Withheld: excluded symbol token (keyword/CLR type/XML entity) |
| `in_FullName` | argument | No type evidence from prefix for argument "in_FullName" |
| `in_RunId` | argument | No type evidence from prefix for argument "in_RunId" |
| `in_EventId` | argument | No type evidence from prefix for argument "in_EventId" |
| `out_ResolvedEmail` | argument | No type evidence from prefix for argument "out_ResolvedEmail" |
| `out_IsAmbiguousMatch` | argument | No type evidence from prefix for argument "out_IsAmbiguousMatch" |
| `From` | variable | No prefix and no expression context evidence — declaration blocked to avoid generic placeholder |
| `New` | variable | Withheld: excluded symbol token (keyword/CLR type/XML entity) |
| `Dictionary` | variable | Withheld: excluded symbol token (keyword/CLR type/XML entity) |
| `Of` | variable | Withheld: excluded symbol token (keyword/CLR type/XML entity) |
| `String` | variable | Withheld: excluded symbol token (keyword/CLR type/XML entity) |
| `Object` | variable | Withheld: excluded symbol token (keyword/CLR type/XML entity) |
| `True` | variable | Withheld: excluded symbol token (keyword/CLR type/XML entity) |
| `InArgument` | variable | No prefix and no expression context evidence — declaration blocked to avoid generic placeholder |
| `x` | variable | Withheld: identifier too short |
| `Object` | variable | Withheld: excluded symbol token (keyword/CLR type/XML entity) |
| `vb_expression` | variable | No prefix and no expression context evidence — declaration blocked to avoid generic placeholder |
| `InArgument` | variable | No prefix and no expression context evidence — declaration blocked to avoid generic placeholder |
| `x` | variable | Withheld: identifier too short |
| `Object` | variable | Withheld: excluded symbol token (keyword/CLR type/XML entity) |
| `in_RunId` | argument | No type evidence from prefix for argument "in_RunId" |
| `in_EventId` | argument | No type evidence from prefix for argument "in_EventId" |
| `in_FullName` | argument | No type evidence from prefix for argument "in_FullName" |
| `in_PersonKey` | argument | No type evidence from prefix for argument "in_PersonKey" |
| `in_SelectedEmail` | argument | No type evidence from prefix for argument "in_SelectedEmail" |
| `in_Subject` | argument | No type evidence from prefix for argument "in_Subject" |
| `in_DraftBody` | argument | No type evidence from prefix for argument "in_DraftBody" |
| `in_ReviewReason` | argument | No type evidence from prefix for argument "in_ReviewReason" |
| `in_SendYear` | argument | No type evidence from prefix for argument "in_SendYear" |
| `in_CalendarOccurrenceStart` | argument | No type evidence from prefix for argument "in_CalendarOccurrenceStart" |
| `From` | variable | No prefix and no expression context evidence — declaration blocked to avoid generic placeholder |
| `New` | variable | Withheld: excluded symbol token (keyword/CLR type/XML entity) |
| `Dictionary` | variable | Withheld: excluded symbol token (keyword/CLR type/XML entity) |
| `Of` | variable | Withheld: excluded symbol token (keyword/CLR type/XML entity) |
| `String` | variable | Withheld: excluded symbol token (keyword/CLR type/XML entity) |
| `Object` | variable | Withheld: excluded symbol token (keyword/CLR type/XML entity) |
| `InArgument` | variable | No prefix and no expression context evidence — declaration blocked to avoid generic placeholder |
| `x` | variable | Withheld: identifier too short |
| `Object` | variable | Withheld: excluded symbol token (keyword/CLR type/XML entity) |
| `vb_expression` | variable | No prefix and no expression context evidence — declaration blocked to avoid generic placeholder |
| `InArgument` | variable | No prefix and no expression context evidence — declaration blocked to avoid generic placeholder |
| `x` | variable | Withheld: identifier too short |
| `Object` | variable | Withheld: excluded symbol token (keyword/CLR type/XML entity) |
| `in_PersonName` | argument | No type evidence from prefix for argument "in_PersonName" |
| `in_PersonKey` | argument | No type evidence from prefix for argument "in_PersonKey" |
| `in_SelectedEmail` | argument | No type evidence from prefix for argument "in_SelectedEmail" |
| `in_SendYear` | argument | No type evidence from prefix for argument "in_SendYear" |
| `in_Status` | argument | No type evidence from prefix for argument "in_Status" |
| `in_CalendarEventId` | argument | No type evidence from prefix for argument "in_CalendarEventId" |
| `in_CalendarOccurrenceStart` | argument | No type evidence from prefix for argument "in_CalendarOccurrenceStart" |
| `in_GmailMessageId` | argument | No type evidence from prefix for argument "in_GmailMessageId" |
| `in_SentTimestamp` | argument | No type evidence from prefix for argument "in_SentTimestamp" |
| `in_FailureReason` | argument | No type evidence from prefix for argument "in_FailureReason" |
| `in_RunId` | argument | No type evidence from prefix for argument "in_RunId" |
| `From` | variable | No prefix and no expression context evidence — declaration blocked to avoid generic placeholder |
| `New` | variable | Withheld: excluded symbol token (keyword/CLR type/XML entity) |
| `Dictionary` | variable | Withheld: excluded symbol token (keyword/CLR type/XML entity) |
| `Of` | variable | Withheld: excluded symbol token (keyword/CLR type/XML entity) |
| `String` | variable | Withheld: excluded symbol token (keyword/CLR type/XML entity) |
| `Object` | variable | Withheld: excluded symbol token (keyword/CLR type/XML entity) |
| `CType` | variable | Withheld: excluded symbol token (keyword/CLR type/XML entity) |
| `Nothing` | variable | Withheld: excluded symbol token (keyword/CLR type/XML entity) |
| `DateTime` | variable | Withheld: excluded symbol token (keyword/CLR type/XML entity) |

## 2. Handoff Blocks (business logic preserved, implementation required)

Blocks where business logic is preserved as documentation but implementation requires manual Studio work. Each entry includes the workflow file, block type, business description from the SDD (when available), expected inputs/outputs, and the developer action required.

**14 handoff block(s) requiring manual implementation**

#### 1. `BGYY_SendGmail.xaml` — — (activity)

- **Workflow File:** `BGYY_SendGmail.xaml`
- **Block Type:** activity
- **Business Description (SDD):** —
- **Business Rule:** —
- **Expected Inputs:** —
- **Expected Outputs:** —
- **Contained Activities:** —
- **Remediation Code:** `DEGRADED_ACTIVITY_MISSING_PROPERTY`
- **Developer Action:** Provide the missing properties for "UiPath.GSuite.Activities.GmailSendMessage": Body
- **Estimated Effort:** 5 minutes

#### 2. `BGYY_WriteDedupe.xaml` — — (activity)

- **Workflow File:** `BGYY_WriteDedupe.xaml`
- **Block Type:** activity
- **Business Description (SDD):** —
- **Business Rule:** —
- **Expected Inputs:** —
- **Expected Outputs:** —
- **Contained Activities:** —
- **Remediation Code:** `DEGRADED_ACTIVITY_MISSING_PROPERTY`
- **Developer Action:** Provide the missing properties for "UiPath.DataService.Activities.UpdateEntity": EntityObject
- **Estimated Effort:** 5 minutes

#### 3. `BGYY_WriteDedupe.xaml` — — (activity)

- **Workflow File:** `BGYY_WriteDedupe.xaml`
- **Block Type:** activity
- **Business Description (SDD):** —
- **Business Rule:** —
- **Expected Inputs:** —
- **Expected Outputs:** —
- **Contained Activities:** —
- **Remediation Code:** `DEGRADED_ACTIVITY_MISSING_PROPERTY`
- **Developer Action:** Provide the missing properties for "UiPath.DataService.Activities.CreateEntity": EntityObject
- **Estimated Effort:** 5 minutes

#### 4. `BGYY_CreateReviewTask.xaml` — — (activity)

- **Workflow File:** `BGYY_CreateReviewTask.xaml`
- **Block Type:** activity
- **Business Description (SDD):** —
- **Business Rule:** —
- **Expected Inputs:** —
- **Expected Outputs:** —
- **Contained Activities:** —
- **Remediation Code:** `DEGRADED_ACTIVITY_MISSING_PROPERTY`
- **Developer Action:** Provide the missing properties for "UiPath.Persistence.Activities.CreateFormTask": TaskTitle
- **Estimated Effort:** 5 minutes

#### 5. `BGYY_SendGmail.xaml` — — (activity)

- **Workflow File:** `BGYY_SendGmail.xaml`
- **Block Type:** activity
- **Business Description (SDD):** —
- **Business Rule:** —
- **Expected Inputs:** —
- **Expected Outputs:** —
- **Contained Activities:** —
- **Remediation Code:** `DEGRADED_ACTIVITY_MISSING_PROPERTY`
- **Developer Action:** Provide the missing properties for mail activity "UiPath.GSuite.Activities.GmailSendMessage": Body
- **Estimated Effort:** 5 minutes

#### 6. `BGYY_ResolveRecipient.xaml` — — (activity)

- **Workflow File:** `BGYY_ResolveRecipient.xaml`
- **Block Type:** activity
- **Business Description (SDD):** —
- **Business Rule:** —
- **Expected Inputs:** —
- **Expected Outputs:** —
- **Contained Activities:** —
- **Remediation Code:** `UNDECLARED_VARIABLE_MANUAL`
- **Developer Action:** Declare variable "personal" in BGYY_ResolveRecipient.xaml with the appropriate type. Expression context: str_CurrentEmailLabel = personal
- **Estimated Effort:** 5 minutes

#### 7. `BGYY_ResolveRecipient.xaml` — — (activity)

- **Workflow File:** `BGYY_ResolveRecipient.xaml`
- **Block Type:** activity
- **Business Description (SDD):** —
- **Business Rule:** —
- **Expected Inputs:** —
- **Expected Outputs:** —
- **Contained Activities:** —
- **Remediation Code:** `UNDECLARED_VARIABLE_MANUAL`
- **Developer Action:** Declare variable "home" in BGYY_ResolveRecipient.xaml with the appropriate type. Expression context: str_CurrentEmailLabel = home
- **Estimated Effort:** 5 minutes

#### 8. `BGYY_CreateReviewTask.xaml` — — (activity)

- **Workflow File:** `BGYY_CreateReviewTask.xaml`
- **Block Type:** activity
- **Business Description (SDD):** —
- **Business Rule:** —
- **Expected Inputs:** —
- **Expected Outputs:** —
- **Contained Activities:** —
- **Remediation Code:** `UNDECLARED_VARIABLE_MANUAL`
- **Developer Action:** Declare variable "vb_expression" in BGYY_CreateReviewTask.xaml with the appropriate type. Expression context: vb_expression
- **Estimated Effort:** 5 minutes

#### 9. `BGYY_Main.xaml` — — (activity)

- **Workflow File:** `BGYY_Main.xaml`
- **Block Type:** activity
- **Business Description (SDD):** —
- **Business Rule:** —
- **Expected Inputs:** —
- **Expected Outputs:** —
- **Contained Activities:** —
- **Remediation Code:** `UNDECLARED_VARIABLE_MANUAL`
- **Developer Action:** Declare variable "BGYY_Main" in BGYY_Main.xaml with the appropriate type. Expression context: BGYY_Main &amp; &quot; Workflow started. Initializing run co...
- **Estimated Effort:** 5 minutes

#### 10. `BGYY_Main.xaml` — — (activity)

- **Workflow File:** `BGYY_Main.xaml`
- **Block Type:** activity
- **Business Description (SDD):** —
- **Business Rule:** —
- **Expected Inputs:** —
- **Expected Outputs:** —
- **Contained Activities:** —
- **Remediation Code:** `UNDECLARED_VARIABLE_MANUAL`
- **Developer Action:** Declare variable "vb_expression" in BGYY_Main.xaml with the appropriate type. Expression context: vb_expression
- **Estimated Effort:** 5 minutes

#### 11. `BGYY_Main.xaml` — — (activity)

- **Workflow File:** `BGYY_Main.xaml`
- **Block Type:** activity
- **Business Description (SDD):** —
- **Business Rule:** —
- **Expected Inputs:** —
- **Expected Outputs:** —
- **Contained Activities:** —
- **Remediation Code:** `UNDECLARED_VARIABLE_MANUAL`
- **Developer Action:** Declare variable "vb_expression" in BGYY_Main.xaml with the appropriate type. Expression context: vb_expression
- **Estimated Effort:** 5 minutes

#### 12. `BGYY_Main.xaml` — — (activity)

- **Workflow File:** `BGYY_Main.xaml`
- **Block Type:** activity
- **Business Description (SDD):** —
- **Business Rule:** —
- **Expected Inputs:** —
- **Expected Outputs:** —
- **Contained Activities:** —
- **Remediation Code:** `UNDECLARED_VARIABLE_MANUAL`
- **Developer Action:** Declare variable "vb_expression" in BGYY_Main.xaml with the appropriate type. Expression context: vb_expression
- **Estimated Effort:** 5 minutes

#### 13. `BGYY_Main.xaml` — — (activity)

- **Workflow File:** `BGYY_Main.xaml`
- **Block Type:** activity
- **Business Description (SDD):** —
- **Business Rule:** —
- **Expected Inputs:** —
- **Expected Outputs:** —
- **Contained Activities:** —
- **Remediation Code:** `UNDECLARED_VARIABLE_MANUAL`
- **Developer Action:** Declare variable "vb_expression" in BGYY_Main.xaml with the appropriate type. Expression context: vb_expression
- **Estimated Effort:** 5 minutes

#### 14. `` — — (activity)

- **Workflow File:** ``
- **Block Type:** activity
- **Business Description (SDD):** —
- **Business Rule:** —
- **Expected Inputs:** —
- **Expected Outputs:** —
- **Contained Activities:** —
- **Remediation Code:** `POST_ASSEMBLY_REPAIR`
- **Developer Action:** uexcel:ExcelApplicationScope.ExistingWorkbook has no valid source binding and no contract-valid fallback — structured defect, property left absent
- **Estimated Effort:** 5 minutes

## 3. Manual Work Remaining

Consolidated developer TODO list organized by workflow, with estimated effort per item.

**134 items remaining — ~1545 minutes (25.8 hours) total estimated effort**

### BGYY_GetTodaysBirthdays.xaml (17 items, ~205 min)

| # | Priority | Category | Description | Developer Action | Est. Minutes |
|---|----------|----------|-------------|-----------------|-------------|
| 1 | High | Workflow Stub | Entire workflow `BGYY_GetTodaysBirthdays.xaml` replaced with Studio-openable ... | Fix XML structure in BGYY_GetTodaysBirthdays.xaml — [xml-wellformedness] XML ... | 15 |
| 2 | Low | Validation Finding | Quality gate finding: `OBJECT_TO_IENUMERABLE` | Manually implement activity in BGYY_GetTodaysBirthdays.xaml — estimated 15 min | 15 |
| 3 | Low | Validation Finding | Quality gate finding: `CATALOG_STRUCTURAL_VIOLATION` | Fix property syntax for activity in BGYY_GetTodaysBirthdays.xaml — move attri... | 15 |
| 4 | Low | Validation Finding | Quality gate finding: `CATALOG_STRUCTURAL_VIOLATION` | Fix property syntax for activity in BGYY_GetTodaysBirthdays.xaml — move attri... | 15 |
| 5 | Low | Validation Finding | Quality gate finding: `CATALOG_STRUCTURAL_VIOLATION` | Fix property syntax for activity in BGYY_GetTodaysBirthdays.xaml — move attri... | 15 |
| 6 | Low | Validation Finding | Quality gate finding: `CATALOG_STRUCTURAL_VIOLATION` | Fix property syntax for activity in BGYY_GetTodaysBirthdays.xaml — move attri... | 15 |
| 7 | Low | Validation Finding | Quality gate finding: `CATALOG_STRUCTURAL_VIOLATION` | Fix property syntax for activity in BGYY_GetTodaysBirthdays.xaml — move attri... | 15 |
| 8 | Low | Implementation Required | Contains 4 placeholder value(s) matching "\bTODO\b" [Developer Implementation... | Implement in Studio | 10 |
| 9 | Low | Implementation Required | Contains 4 placeholder value(s) matching "\bPLACEHOLDER\b" [Developer Impleme... | Implement in Studio | 10 |
| 10 | Low | Quality Warning | hardcoded-retry-count: Line 410: retry count hardcoded as 3 — consider extern... | Review and address | 10 |
| 11 | Low | Quality Warning | hardcoded-retry-count: Line 440: retry count hardcoded as 3 — consider extern... | Review and address | 10 |
| 12 | Low | Quality Warning | hardcoded-retry-count: Line 455: retry count hardcoded as 3 — consider extern... | Review and address | 10 |
| 13 | Low | Quality Warning | hardcoded-retry-interval: Line 410: retry interval hardcoded as "00:00:05" — ... | Review and address | 10 |
| 14 | Low | Quality Warning | hardcoded-retry-interval: Line 440: retry interval hardcoded as "00:00:05" — ... | Review and address | 10 |
| 15 | Low | Quality Warning | hardcoded-retry-interval: Line 455: retry interval hardcoded as "00:00:05" — ... | Review and address | 10 |
| 16 | Low | Quality Warning | EXPRESSION_SYNTAX: Line 518: C# 'null' should be VB.NET 'Nothing' in expressi... | Review and address | 10 |
| 17 | Low | Quality Warning | EXPRESSION_SYNTAX: Line 1030: C# '+' for string concatenation should be VB.NE... | Review and address | 10 |

### BGYY_Main.xaml (18 items, ~195 min)

| # | Priority | Category | Description | Developer Action | Est. Minutes |
|---|----------|----------|-------------|-----------------|-------------|
| 18 | High | Workflow Stub | Entire workflow `BGYY_Main.xaml` replaced with Studio-openable stub | Fix XML structure in BGYY_Main.xaml — [xml-wellformedness] XML parse error at... | 15 |
| 19 | Medium | Activity Stub | Activity "unknown" stubbed | Declare variable "BGYY_Main" in BGYY_Main.xaml with the appropriate type. Exp... | 5 |
| 20 | Medium | Activity Stub | Activity "unknown" stubbed | Declare variable "vb_expression" in BGYY_Main.xaml with the appropriate type.... | 5 |
| 21 | Medium | Activity Stub | Activity "unknown" stubbed | Declare variable "vb_expression" in BGYY_Main.xaml with the appropriate type.... | 5 |
| 22 | Medium | Activity Stub | Activity "unknown" stubbed | Declare variable "vb_expression" in BGYY_Main.xaml with the appropriate type.... | 5 |
| 23 | Medium | Activity Stub | Activity "unknown" stubbed | Declare variable "vb_expression" in BGYY_Main.xaml with the appropriate type.... | 5 |
| 24 | Low | Validation Finding | Quality gate finding: `UNDECLARED_VARIABLE` | Manually implement activity in BGYY_Main.xaml — estimated 15 min | 15 |
| 25 | Low | Validation Finding | Quality gate finding: `UNDECLARED_VARIABLE` | Manually implement activity in BGYY_Main.xaml — estimated 15 min | 15 |
| 26 | Low | Validation Finding | Quality gate finding: `UNDECLARED_VARIABLE` | Manually implement activity in BGYY_Main.xaml — estimated 15 min | 15 |
| 27 | Low | Validation Finding | Quality gate finding: `UNDECLARED_VARIABLE` | Manually implement activity in BGYY_Main.xaml — estimated 15 min | 15 |
| 28 | Low | Validation Finding | Quality gate finding: `UNDECLARED_VARIABLE` | Manually implement activity in BGYY_Main.xaml — estimated 15 min | 15 |
| 29 | Low | Validation Finding | Quality gate finding: `CATALOG_STRUCTURAL_VIOLATION` | Fix property syntax for activity in BGYY_Main.xaml — move attribute to child-... | 15 |
| 30 | Low | Validation Finding | Quality gate finding: `CATALOG_STRUCTURAL_VIOLATION` | Fix property syntax for activity in BGYY_Main.xaml — move attribute to child-... | 15 |
| 31 | Low | Implementation Required | Contains 5 placeholder value(s) matching "\bTODO\b" [Developer Implementation... | Implement in Studio | 10 |
| 32 | Low | Implementation Required | Contains 5 placeholder value(s) matching "\bPLACEHOLDER\b" [Developer Impleme... | Implement in Studio | 10 |
| 33 | Low | Quality Warning | hardcoded-asset-name: Line 479: asset name "BGYY_DryRun" is hardcoded — consi... | Review and address | 10 |
| 34 | Low | Quality Warning | EXPRESSION_SYNTAX: Line 1009: C# '+' for string concatenation should be VB.NE... | Review and address | 10 |
| 35 | Low | Quality Warning | BARE_TOKEN_QUOTED: Auto-quoted bare token "BGYY_DryRun" for ui:GetAsset.Asset... | Review and address | 10 |

### BGYY_CreateReviewTask.xaml (7 items, ~75 min)

| # | Priority | Category | Description | Developer Action | Est. Minutes |
|---|----------|----------|-------------|-----------------|-------------|
| 36 | Medium | Activity Stub | Activity "unknown" stubbed | Provide the missing properties for "UiPath.Persistence.Activities.CreateFormT... | 5 |
| 37 | Medium | Activity Stub | Activity "unknown" stubbed | Declare variable "vb_expression" in BGYY_CreateReviewTask.xaml with the appro... | 5 |
| 38 | Low | Validation Finding | Quality gate finding: `UNDECLARED_VARIABLE` | Manually implement activity in BGYY_CreateReviewTask.xaml — estimated 15 min | 15 |
| 39 | Low | Validation Finding | Quality gate finding: `CATALOG_STRUCTURAL_VIOLATION` | Fix property syntax for activity in BGYY_CreateReviewTask.xaml — move attribu... | 15 |
| 40 | Low | Validation Finding | Quality gate finding: `CATALOG_STRUCTURAL_VIOLATION` | Fix property syntax for activity in BGYY_CreateReviewTask.xaml — move attribu... | 15 |
| 41 | Low | Implementation Required | Contains 1 placeholder value(s) matching "\bTODO\b" [Developer Implementation... | Implement in Studio | 10 |
| 42 | Low | Implementation Required | Contains 1 placeholder value(s) matching "\bPLACEHOLDER\b" [Developer Impleme... | Implement in Studio | 10 |

### BGYY_ResolveRecipient.xaml (18 items, ~195 min)

| # | Priority | Category | Description | Developer Action | Est. Minutes |
|---|----------|----------|-------------|-----------------|-------------|
| 43 | Medium | Activity Stub | Activity "unknown" stubbed | Declare variable "personal" in BGYY_ResolveRecipient.xaml with the appropriat... | 5 |
| 44 | Medium | Activity Stub | Activity "unknown" stubbed | Declare variable "home" in BGYY_ResolveRecipient.xaml with the appropriate ty... | 5 |
| 45 | Low | Validation Finding | Quality gate finding: `UNDECLARED_VARIABLE` | Manually implement activity in BGYY_ResolveRecipient.xaml — estimated 15 min | 15 |
| 46 | Low | Validation Finding | Quality gate finding: `UNDECLARED_VARIABLE` | Manually implement activity in BGYY_ResolveRecipient.xaml — estimated 15 min | 15 |
| 47 | Low | Validation Finding | Quality gate finding: `OBJECT_TO_IENUMERABLE` | Manually implement activity in BGYY_ResolveRecipient.xaml — estimated 15 min | 15 |
| 48 | Low | Validation Finding | Quality gate finding: `CATALOG_STRUCTURAL_VIOLATION` | Fix property syntax for activity in BGYY_ResolveRecipient.xaml — move attribu... | 15 |
| 49 | Low | Validation Finding | Quality gate finding: `CATALOG_STRUCTURAL_VIOLATION` | Fix property syntax for activity in BGYY_ResolveRecipient.xaml — move attribu... | 15 |
| 50 | Low | Implementation Required | Contains 9 placeholder value(s) matching "\bTODO\b" [Developer Implementation... | Implement in Studio | 10 |
| 51 | Low | Implementation Required | Contains 9 placeholder value(s) matching "\bPLACEHOLDER\b" [Developer Impleme... | Implement in Studio | 10 |
| 52 | Low | Quality Warning | hardcoded-retry-count: Line 257: retry count hardcoded as 3 — consider extern... | Review and address | 10 |
| 53 | Low | Quality Warning | hardcoded-retry-count: Line 518: retry count hardcoded as 3 — consider extern... | Review and address | 10 |
| 54 | Low | Quality Warning | hardcoded-retry-count: Line 533: retry count hardcoded as 3 — consider extern... | Review and address | 10 |
| 55 | Low | Quality Warning | hardcoded-retry-interval: Line 257: retry interval hardcoded as "00:00:05" — ... | Review and address | 10 |
| 56 | Low | Quality Warning | hardcoded-retry-interval: Line 518: retry interval hardcoded as "00:00:05" — ... | Review and address | 10 |
| 57 | Low | Quality Warning | hardcoded-retry-interval: Line 533: retry interval hardcoded as "00:00:05" — ... | Review and address | 10 |
| 58 | Low | Quality Warning | RETRY_INTERVAL_DEFAULTED: Post-repair: RetryInterval defaulted to "00:00:05" ... | Review and address | 10 |
| 59 | Low | Quality Warning | RETRY_INTERVAL_DEFAULTED: Post-repair: RetryInterval defaulted to "00:00:05" ... | Review and address | 10 |
| 60 | Low | Quality Warning | RETRY_INTERVAL_DEFAULTED: Post-repair: RetryInterval defaulted to "00:00:05" ... | Review and address | 10 |

### BGYY_SendGmail.xaml (23 items, ~255 min)

| # | Priority | Category | Description | Developer Action | Est. Minutes |
|---|----------|----------|-------------|-----------------|-------------|
| 61 | Medium | Activity Stub | Activity "unknown" stubbed | Provide the missing properties for "UiPath.GSuite.Activities.GmailSendMessage... | 5 |
| 62 | Medium | Activity Stub | Activity "unknown" stubbed | Provide the missing properties for mail activity "UiPath.GSuite.Activities.Gm... | 5 |
| 63 | Low | Validation Finding | Quality gate finding: `CATALOG_STRUCTURAL_VIOLATION` | Fix property syntax for activity in BGYY_SendGmail.xaml — move attribute to c... | 15 |
| 64 | Low | Validation Finding | Quality gate finding: `CATALOG_STRUCTURAL_VIOLATION` | Fix property syntax for activity in BGYY_SendGmail.xaml — move attribute to c... | 15 |
| 65 | Low | Validation Finding | Quality gate finding: `CATALOG_STRUCTURAL_VIOLATION` | Fix property syntax for activity in BGYY_SendGmail.xaml — move attribute to c... | 15 |
| 66 | Low | Validation Finding | Quality gate finding: `CATALOG_STRUCTURAL_VIOLATION` | Fix property syntax for activity in BGYY_SendGmail.xaml — move attribute to c... | 15 |
| 67 | Low | Validation Finding | Quality gate finding: `CATALOG_STRUCTURAL_VIOLATION` | Fix property syntax for activity in BGYY_SendGmail.xaml — move attribute to c... | 15 |
| 68 | Low | Validation Finding | Quality gate finding: `CATALOG_STRUCTURAL_VIOLATION` | Fix property syntax for activity in BGYY_SendGmail.xaml — move attribute to c... | 15 |
| 69 | Low | Validation Finding | Quality gate finding: `CATALOG_STRUCTURAL_VIOLATION` | Fix property syntax for activity in BGYY_SendGmail.xaml — move attribute to c... | 15 |
| 70 | Low | Implementation Required | Contains 3 placeholder value(s) matching "\bTODO\b" [Developer Implementation... | Implement in Studio | 10 |
| 71 | Low | Implementation Required | Contains 3 placeholder value(s) matching "\bPLACEHOLDER\b" [Developer Impleme... | Implement in Studio | 10 |
| 72 | Low | Quality Warning | hardcoded-retry-count: Line 196: retry count hardcoded as 3 — consider extern... | Review and address | 10 |
| 73 | Low | Quality Warning | hardcoded-retry-count: Line 206: retry count hardcoded as 3 — consider extern... | Review and address | 10 |
| 74 | Low | Quality Warning | hardcoded-retry-interval: Line 196: retry interval hardcoded as "00:00:05" — ... | Review and address | 10 |
| 75 | Low | Quality Warning | hardcoded-retry-interval: Line 206: retry interval hardcoded as "00:00:05" — ... | Review and address | 10 |
| 76 | Low | Quality Warning | hardcoded-asset-name: Line 92: asset name "BGYY_DryRun" is hardcoded — consid... | Review and address | 10 |
| 77 | Low | Quality Warning | EXPRESSION_SYNTAX: Line 192: C# 'null' should be VB.NET 'Nothing' in expressi... | Review and address | 10 |
| 78 | Low | Quality Warning | COMPLEX_EXPRESSION_PASSTHROUGH: Line 263: Complex expression (lambdas, LINQ, ... | Review and address | 10 |
| 79 | Low | Quality Warning | COMPLEX_EXPRESSION_PASSTHROUGH: Line 271: Complex expression (lambdas, LINQ, ... | Review and address | 10 |
| 80 | Low | Quality Warning | TYPE_MISMATCH: Line 290: Type mismatch — variable "str_TempScreenshotFile" (S... | Review and address | 10 |
| 81 | Low | Quality Warning | BARE_TOKEN_QUOTED: Auto-quoted bare token "BGYY_DryRun" for ui:GetAsset.Asset... | Review and address | 10 |
| 82 | Low | Quality Warning | RETRY_INTERVAL_DEFAULTED: Post-repair: RetryInterval defaulted to "00:00:05" ... | Review and address | 10 |
| 83 | Low | Quality Warning | RETRY_INTERVAL_DEFAULTED: Post-repair: RetryInterval defaulted to "00:00:05" ... | Review and address | 10 |

### BGYY_WriteDedupe.xaml (10 items, ~100 min)

| # | Priority | Category | Description | Developer Action | Est. Minutes |
|---|----------|----------|-------------|-----------------|-------------|
| 84 | Medium | Activity Stub | Activity "unknown" stubbed | Provide the missing properties for "UiPath.DataService.Activities.UpdateEntit... | 5 |
| 85 | Medium | Activity Stub | Activity "unknown" stubbed | Provide the missing properties for "UiPath.DataService.Activities.CreateEntit... | 5 |
| 86 | Low | Validation Finding | Quality gate finding: `CATALOG_STRUCTURAL_VIOLATION` | Fix property syntax for activity in BGYY_WriteDedupe.xaml — move attribute to... | 15 |
| 87 | Low | Validation Finding | Quality gate finding: `CATALOG_STRUCTURAL_VIOLATION` | Fix property syntax for activity in BGYY_WriteDedupe.xaml — move attribute to... | 15 |
| 88 | Low | Quality Warning | hardcoded-retry-count: Line 98: retry count hardcoded as 3 — consider externa... | Review and address | 10 |
| 89 | Low | Quality Warning | hardcoded-retry-count: Line 103: retry count hardcoded as 3 — consider extern... | Review and address | 10 |
| 90 | Low | Quality Warning | hardcoded-retry-interval: Line 98: retry interval hardcoded as "00:00:05" — c... | Review and address | 10 |
| 91 | Low | Quality Warning | hardcoded-retry-interval: Line 103: retry interval hardcoded as "00:00:05" — ... | Review and address | 10 |
| 92 | Low | Quality Warning | RETRY_INTERVAL_DEFAULTED: Post-repair: RetryInterval defaulted to "00:00:05" ... | Review and address | 10 |
| 93 | Low | Quality Warning | RETRY_INTERVAL_DEFAULTED: Post-repair: RetryInterval defaulted to "00:00:05" ... | Review and address | 10 |

### Unknown.xaml (1 item, ~5 min)

| # | Priority | Category | Description | Developer Action | Est. Minutes |
|---|----------|----------|-------------|-----------------|-------------|
| 94 | Medium | Activity Stub | Activity "unknown" stubbed | uexcel:ExcelApplicationScope.ExistingWorkbook has no valid source binding and... | 5 |

### BGYY_CheckDedupe.xaml (2 items, ~30 min)

| # | Priority | Category | Description | Developer Action | Est. Minutes |
|---|----------|----------|-------------|-----------------|-------------|
| 95 | Low | Validation Finding | Quality gate finding: `CATALOG_STRUCTURAL_VIOLATION` | Fix property syntax for activity in BGYY_CheckDedupe.xaml — move attribute to... | 15 |
| 96 | Low | Validation Finding | Quality gate finding: `CATALOG_STRUCTURAL_VIOLATION` | Fix property syntax for activity in BGYY_CheckDedupe.xaml — move attribute to... | 15 |

### BGYY_GenerateAndValidateDraft.xaml (11 items, ~140 min)

| # | Priority | Category | Description | Developer Action | Est. Minutes |
|---|----------|----------|-------------|-----------------|-------------|
| 97 | Low | Validation Finding | Quality gate finding: `CATALOG_STRUCTURAL_VIOLATION` | Fix property syntax for activity in BGYY_GenerateAndValidateDraft.xaml — move... | 15 |
| 98 | Low | Validation Finding | Quality gate finding: `CATALOG_STRUCTURAL_VIOLATION` | Fix property syntax for activity in BGYY_GenerateAndValidateDraft.xaml — move... | 15 |
| 99 | Low | Validation Finding | Quality gate finding: `CATALOG_STRUCTURAL_VIOLATION` | Fix property syntax for activity in BGYY_GenerateAndValidateDraft.xaml — move... | 15 |
| 100 | Low | Validation Finding | Quality gate finding: `CATALOG_STRUCTURAL_VIOLATION` | Fix property syntax for activity in BGYY_GenerateAndValidateDraft.xaml — move... | 15 |
| 101 | Low | Validation Finding | Quality gate finding: `CATALOG_STRUCTURAL_VIOLATION` | Fix property syntax for activity in BGYY_GenerateAndValidateDraft.xaml — move... | 15 |
| 102 | Low | Validation Finding | Quality gate finding: `CATALOG_STRUCTURAL_VIOLATION` | Fix property syntax for activity in BGYY_GenerateAndValidateDraft.xaml — move... | 15 |
| 103 | Low | Implementation Required | Contains 6 placeholder value(s) matching "\bTODO\b" [Developer Implementation... | Implement in Studio | 10 |
| 104 | Low | Implementation Required | Contains 7 placeholder value(s) matching "\bPLACEHOLDER\b" [Developer Impleme... | Implement in Studio | 10 |
| 105 | Low | Quality Warning | COMPLEX_EXPRESSION_PASSTHROUGH: Line 1225: Complex expression (lambdas, LINQ,... | Review and address | 10 |
| 106 | Low | Quality Warning | COMPLEX_EXPRESSION_PASSTHROUGH: Line 1255: Complex expression (lambdas, LINQ,... | Review and address | 10 |
| 107 | Low | Quality Warning | COMPLEX_EXPRESSION_PASSTHROUGH: Line 594: Complex expression (lambdas, LINQ, ... | Review and address | 10 |

### GetTransactionData.xaml (2 items, ~30 min)

| # | Priority | Category | Description | Developer Action | Est. Minutes |
|---|----------|----------|-------------|-----------------|-------------|
| 108 | Low | Validation Finding | Quality gate finding: `CATALOG_STRUCTURAL_VIOLATION` | Fix property syntax for activity in GetTransactionData.xaml — move attribute ... | 15 |
| 109 | Low | Validation Finding | Quality gate finding: `CATALOG_STRUCTURAL_VIOLATION` | Fix property syntax for activity in GetTransactionData.xaml — move attribute ... | 15 |

### Init.xaml (4 items, ~55 min)

| # | Priority | Category | Description | Developer Action | Est. Minutes |
|---|----------|----------|-------------|-----------------|-------------|
| 110 | Low | Validation Finding | Quality gate finding: `CATALOG_STRUCTURAL_VIOLATION` | Fix property syntax for activity in Init.xaml — move attribute to child-eleme... | 15 |
| 111 | Low | Validation Finding | Quality gate finding: `CATALOG_STRUCTURAL_VIOLATION` | Fix property syntax for activity in Init.xaml — move attribute to child-eleme... | 15 |
| 112 | Low | Validation Finding | Quality gate finding: `CATALOG_STRUCTURAL_VIOLATION` | Fix property syntax for activity in Init.xaml — move attribute to child-eleme... | 15 |
| 113 | Low | Quality Warning | TYPE_MISMATCH: Line 68: Type mismatch — variable "dict_Config" (scg:Dictionar... | Review and address | 10 |

### InitAllApplications.xaml (2 items, ~20 min)

| # | Priority | Category | Description | Developer Action | Est. Minutes |
|---|----------|----------|-------------|-----------------|-------------|
| 114 | Low | Implementation Required | Contains 1 placeholder value(s) matching "\bTODO\b" [Developer Implementation... | Implement in Studio | 10 |
| 115 | Low | Implementation Required | Contains 1 placeholder value(s) matching "\bPLACEHOLDER\b" [Developer Impleme... | Implement in Studio | 10 |

### InitAllSettings.xaml (8 items, ~100 min)

| # | Priority | Category | Description | Developer Action | Est. Minutes |
|---|----------|----------|-------------|-----------------|-------------|
| 116 | Low | Validation Finding | Quality gate finding: `MISSING_REQUIRED_ACTIVITY_PROPERTY` | Manually implement activity in InitAllSettings.xaml — estimated 15 min | 15 |
| 117 | Low | Validation Finding | Quality gate finding: `CATALOG_STRUCTURAL_VIOLATION` | Fix property syntax for activity in InitAllSettings.xaml — move attribute to ... | 15 |
| 118 | Low | Validation Finding | Quality gate finding: `CATALOG_STRUCTURAL_VIOLATION` | Fix property syntax for activity in InitAllSettings.xaml — move attribute to ... | 15 |
| 119 | Low | Validation Finding | Quality gate finding: `CATALOG_STRUCTURAL_VIOLATION` | Fix property syntax for activity in InitAllSettings.xaml — move attribute to ... | 15 |
| 120 | Low | Quality Warning | hardcoded-asset-name: Line 266: asset name "BGYY_DryRun" is hardcoded — consi... | Review and address | 10 |
| 121 | Low | Quality Warning | BARE_TOKEN_QUOTED: Auto-quoted bare token "Settings" for uexcel:ExcelReadRang... | Review and address | 10 |
| 122 | Low | Quality Warning | BARE_TOKEN_QUOTED: Auto-quoted bare token "Constants" for uexcel:ExcelReadRan... | Review and address | 10 |
| 123 | Low | Quality Warning | BARE_TOKEN_QUOTED: Auto-quoted bare token "BGYY_DryRun" for ui:GetAsset.Asset... | Review and address | 10 |

### Main.xaml (4 items, ~50 min)

| # | Priority | Category | Description | Developer Action | Est. Minutes |
|---|----------|----------|-------------|-----------------|-------------|
| 124 | Low | Validation Finding | Quality gate finding: `CATALOG_STRUCTURAL_VIOLATION` | Fix property syntax for activity in Main.xaml — move attribute to child-eleme... | 15 |
| 125 | Low | Validation Finding | Quality gate finding: `CATALOG_STRUCTURAL_VIOLATION` | Fix property syntax for activity in Main.xaml — move attribute to child-eleme... | 15 |
| 126 | Low | Quality Warning | TYPE_MISMATCH: Line 81: Type mismatch — variable "dict_Config" (scg:Dictionar... | Review and address | 10 |
| 127 | Low | Quality Warning | TYPE_MISMATCH: Line 134: Type mismatch — variable "qi_TransactionItem" (UiPat... | Review and address | 10 |

### RetryCurrentTransaction.xaml (2 items, ~30 min)

| # | Priority | Category | Description | Developer Action | Est. Minutes |
|---|----------|----------|-------------|-----------------|-------------|
| 128 | Low | Validation Finding | Quality gate finding: `CATALOG_STRUCTURAL_VIOLATION` | Fix property syntax for activity in RetryCurrentTransaction.xaml — move attri... | 15 |
| 129 | Low | Validation Finding | Quality gate finding: `CATALOG_STRUCTURAL_VIOLATION` | Fix property syntax for activity in RetryCurrentTransaction.xaml — move attri... | 15 |

### RetryInit.xaml (2 items, ~30 min)

| # | Priority | Category | Description | Developer Action | Est. Minutes |
|---|----------|----------|-------------|-----------------|-------------|
| 130 | Low | Validation Finding | Quality gate finding: `CATALOG_STRUCTURAL_VIOLATION` | Fix property syntax for activity in RetryInit.xaml — move attribute to child-... | 15 |
| 131 | Low | Validation Finding | Quality gate finding: `CATALOG_STRUCTURAL_VIOLATION` | Fix property syntax for activity in RetryInit.xaml — move attribute to child-... | 15 |

### KillAllProcesses.xaml (3 items, ~30 min)

| # | Priority | Category | Description | Developer Action | Est. Minutes |
|---|----------|----------|-------------|-----------------|-------------|
| 132 | Low | Quality Warning | BARE_TOKEN_QUOTED: Auto-quoted bare token "chrome" for ui:KillProcess.Process... | Review and address | 10 |
| 133 | Low | Quality Warning | BARE_TOKEN_QUOTED: Auto-quoted bare token "iexplore" for ui:KillProcess.Proce... | Review and address | 10 |
| 134 | Low | Quality Warning | BARE_TOKEN_QUOTED: Auto-quoted bare token "EXCEL" for ui:KillProcess.ProcessN... | Review and address | 10 |

## 4. Process Context (from Pipeline)

### Idea Description

birthday message

### PDD Summary

## 1. Executive Summary
The “Birthday Greetings YY” automation will send personalized birthday greeting emails on your behalf each morning at 8:00 AM **America/New_York** time. Today, you manually check a dedicated Google Calendar named **“Birthdays”**, look up the person in Google Contacts to find an email address, draft a message in your warm/funny/sarcastic voice, and send it from Gmail—sometimes forgetting to do so. The future-state solution will run fully autonomously on unattended robots, read today’s recurring yearly birthday events from the **“Birthdays”** calendar, select the correct recipient email from Google Contacts (preferring **personal** over **home**), generate a personalized message using **UiPath native GenAI capabilities** (no OpenAI), send via the **Gmail connector (ninemush@gmail.com)**, and record a dedupe entry in **UiPath Data Service** to ensure only one email per person per year even if rerun.

## 2. Process Scope
The process scope begins with a scheduled trigger at 8:00 AM America/New_York and ends when all birthday events for that day have either been sent a greeting email or explicitly skipped due to missing email data or dedupe rules.

In scope are: reading events from the Google Calendar calendar named **“Birthdays”**; extracting the full name from each event (events may be all-day or timed); searching Google Contacts for a matching contact; selecting an email address labeled **personal** or **home** with a preference for **personal** when both exist; generating a personalized email draft in your voice; sending the message from **ninemush@gmail.com** using UiPath Integration Service’s Gmail connector; and writing a “sent this year” record to UiPath Data Service for deduplication.

Out of scope for this iteration are: using Google Drive (explicitly excluded); using photos from Google Photos (explicitly deferred to a later iteration); sending notifications through Slack/Teams/Twilio (explicitly excluded); and enriching content with rela...

### SDD Summary

## 1. Automation Architecture Overview

### 1.1 Chosen automation approach (with rationale)
**Pattern:** *Schedule-driven unattended orchestration with deterministic RPA + GenAI drafting + persistent dedupe state*.

**[AUTOMATION_TYPE: Hybrid (Deterministic RPA + UiPath native GenAI)]**

- **Why not “pure RPA”:** drafting a “warm / funny / sarcastic” message in your voice is non-deterministic and benefits from controlled GenAI generation + guardrails.
- **Why not “Agent-only”:** the process is primarily rules-based (calendar query, contact lookup, dedupe, send email). A full agent adds unpredictability and operational risk without clear benefit.
- **Why Hybrid is optimal:** RPA handles the repeatable integrations and business rules; UiPath native GenAI is invoked only for message generation and (optionally) self-checking.

### 1.2 Execution model and topology
- **Execution:** 100% **unattended** (11 unattended slots available). No human participation is required for normal flow.
- **Triggering:** **Orchestrator time trigger** daily at **08:00 America/New_York**.
- **Robot type:** background execution (no UI dependency). Prefer Integration Service activities over UI automation.

### 1.3 Platform services used (and why)
- **Orchestrator:** schedules, assets, logging, job control, alerts via failed jobs, and artifact deployment.
- **Integration Service:** for Google integrations and Gmail send using the existing connection **“ninemush@gmail.com”** (no custom HTTP).
- **Data Service:** persistent dedupe (“one email per person per year”), plus optional “voice profile” storage.
- **Storage Buckets:** store prompt templates, safe phrase lists, and run artifacts (e.g., generated drafts JSON) for audit/traceability.
- **Action Center (exceptional only):** used only if governance requires human approval for flagged drafts (content safety) or ambiguous contact match. Default is fully autonomous.
- **Test Manager:** automated regression suite to validate dedupe, email selection...

**Automation Type:** hybrid
**Rationale:** Calendar/event retrieval and Gmail sending are deterministic and best as RPA via Integration Service, while “write in my voice” message generation is judgment/linguistic and best handled by a UiPath Agent/GenAI step with guardrails.
**Feasibility Complexity:** medium
**Effort Estimate:** 1-2 weeks

## 5. Business Process Overview

### Process Steps

| # | Step | Role | System | Type | Pain Point |
|---|------|------|--------|------|------------|
| 1 | 8am Daily Trigger (America/New_York) | System | Orchestrator Triggers | start | — |
| 2 | Read Today's Events from "Birthdays" Calendar | System | Google Calendar | task | — |
| 3 | Any Birthday Events Today? | System | Google Calendar | decision | — |
| 4 | End (No Birthdays Today) | System | Orchestrator | end | — |
| 5 | For Each Birthday Event: Extract Full Name | System | Google Calendar | task | — |
| 6 | Find Contact by Full Name | System | Google Contacts | task | — |
| 7 | Personal/Home Email Available? | System | Google Contacts | decision | — |
| 8 | Skip Person (No Personal/Home Email) | System | Orchestrator | task | — |
| 9 | Select Recipient Email (Prefer Personal over Home) | System | Google Contacts | task | — |
| 10 | Dedupe Check: Already Sent This Year? | System | UiPath Data Service | decision | — |
| 11 | Skip Person (Already Sent This Year) | System | UiPath Data Service | task | — |
| 12 | Retrieve Style Context (If Available) | System | Data Service | decision | — |
| 13 | Load "Voice Profile" + Optional Examples | System | UiPath Data Service | task | — |
| 14 | Use Default Voice Prompt (Warm/Funny/Sarcastic) | System | Orchestrator Assets | task | — |
| 15 | Generate Personalized Birthday Email Draft (Your Voice) | System | UiPath Agents / GenAI Activities | agent-task | — |
| 16 | Draft Acceptable (No PII leakage/offensive content)? | System | UiPath Agents | agent-decision | — |
| 17 | Create Human Review Task (Edge Cases Only) | You | Action Center | task | — |
| 18 | Send Birthday Email via Gmail ("ninemush@gmail.com") | System | Gmail (Integration Service) | task | — |
| 19 | Write Dedupe Record (Name, Email, Year, CalendarEventId, MessageId) | System | UiPath Data Service | task | — |
| 20 | End (Run Completed) | System | Orchestrator | end | — |
| 21 | End (Some Recipients Skipped) | System | Orchestrator | end | — |
| 22 | End (Pending Human Review) | System | Action Center | end | — |

### Target Applications / Systems

The following applications were identified from the process map and must be accessible from the robot machine:

- Orchestrator Triggers
- Google Calendar
- Orchestrator
- Google Contacts
- UiPath Data Service
- Data Service
- Orchestrator Assets
- UiPath Agents / GenAI Activities
- UiPath Agents
- Action Center
- Gmail (Integration Service)

### User Roles Involved

- System
- You

### Decision Points (Process Map Topology)

**Any Birthday Events Today?**
  - [No] → End (No Birthdays Today)
  - [Yes] → For Each Birthday Event: Extract Full Name

**Personal/Home Email Available?**
  - [No] → Skip Person (No Personal/Home Email)
  - [Yes] → Select Recipient Email (Prefer Personal over Home)

**Dedupe Check: Already Sent This Year?**
  - [Yes] → Skip Person (Already Sent This Year)
  - [No] → Retrieve Style Context (If Available)

**Retrieve Style Context (If Available)**
  - [Available] → Load "Voice Profile" + Optional Examples
  - [Not Available] → Use Default Voice Prompt (Warm/Funny/Sarcastic)

## 6. Environment Setup

| Requirement | Value |
|---|---|
| Target Framework | Windows (required) |
| Robot Type | Unattended |
| Modern Activities | No |
| Studio Version | 25.10.7 |
| Orchestrator Connection | Required |
| Machine Template | Standard |
| Action Center | Required |
| Data Service | Required |

### Machine Template

**Recommended:** Standard
Standard unattended machine template

### Orchestrator Folder Structure

Create a Modern Folder with unattended robot pool (2+ robots recommended for queue-based processing). Enable Auto-scaling if available.

### NuGet Dependencies

| # | Package |
|---|--------|
| 1 | `UiPath.System.Activities` |
| 2 | `UiPath.UIAutomation.Activities` |
| 3 | `UiPath.GSuite.Activities` |
| 4 | `UiPath.ComplexScenarios.Activities` |
| 5 | `UiPath.DataService.Activities` |
| 6 | `UiPath.GoogleVertex.IntegrationService.Activities` |
| 7 | `UiPath.WebAPI.Activities` |
| 8 | `Newtonsoft.Json` |
| 9 | `UiPath.Excel.Activities` |

### Target Applications (from Process Map)

The following applications were identified from the business process map. Ensure network connectivity and access credentials are configured on the robot machine:

- Orchestrator Triggers
- Google Calendar
- Orchestrator
- Google Contacts
- UiPath Data Service
- Data Service
- Orchestrator Assets
- UiPath Agents / GenAI Activities
- UiPath Agents
- Action Center
- Gmail (Integration Service)

## 7. Credential & Asset Inventory

**Total:** 4 activities (0 hardcoded, 4 variable-driven)

### Orchestrator Assets to Provision

| # | Asset Name | Value Type | Consuming Activity | File | Action |
|---|-----------|-----------|-------------------|------|--------|
| 1 | `[BGYY_DryRun]` | Unknown | — | `BGYY_SendGmail.xaml` | Verify exists in target environment |

### Detailed Usage Map

| File | Line | Activity | Asset/Credential | Type | Variable | Hardcoded |
|------|------|----------|-----------------|------|----------|----------|
| `BGYY_SendGmail.xaml` | 78 | GetAsset | `[BGYY_DryRun]` | Unknown | — | No |
| `BGYY_SendGmail.xaml` | 79 | GetAsset | `UNKNOWN` | Unknown | — | No |
| `InitAllSettings.xaml` | 266 | GetAsset | `[BGYY_DryRun]` | Unknown | — | No |
| `InitAllSettings.xaml` | 269 | GetAsset | `UNKNOWN` | Unknown | — | No |

## 8. SDD × XAML Artifact Reconciliation

**Summary:** 0 aligned, 1 SDD-only, 1 XAML-only

> **Warning:** 1 artifact(s) declared in the SDD were not found in the generated XAML. These must be provisioned in Orchestrator but are not referenced in code — verify the SDD spec or add the corresponding activities.

> **Warning:** 1 artifact(s) found in XAML are not declared in the SDD. Update the SDD orchestrator_artifacts block to include these, or the deployment manifest will be incomplete.

| # | Name | Type | Status | SDD Config | XAML File | XAML Line |
|---|------|------|--------|-----------|----------|----------|
| 1 | `BGYY_DryRun` | asset | **SDD Only** | type: Bool, value: , description: Mock mode. true = generate drafts and write artifacts, do not send emails. | — | — |
| 2 | `[BGYY_DryRun]` | asset | **XAML Only** | — | `BGYY_SendGmail.xaml` | 78 |

## 9. Queue Management

**Pattern:** Transactional (Dispatcher/Performer)

### Queue Activity Summary

| Capability | Present |
|---|---|
| Add Queue Item | No |
| Get Transaction Item | Yes |
| Set Transaction Status | Yes |

### Retry Policy

Transactional pattern detected — configure Auto Retry (recommended: 3 retries) in Orchestrator Queue settings

### SLA Guidance

Configure SLA in Orchestrator: set Maximum Execution Time per transaction item and monitor Queue SLA reports. Recommended: base SLA on observed P95 processing time + 20% buffer.

### Dead-Letter / Failed Items Handling

Items exceeding max retries are marked as Failed. Review failed items in Orchestrator Queues dashboard. Consider: (1) Create a separate cleanup/reprocessing workflow for DLQ items, (2) Set up email alerts for failed transaction counts exceeding threshold, (3) Log detailed failure context in SetTransactionStatus output for troubleshooting.

> **Note:** This is a Performer process — a separate Dispatcher process is needed to populate the queue.

## 10. Exception Handling Coverage

**Coverage:** 2/9 high-risk activities inside TryCatch (22%)

### Files Without TryCatch

- `BGYY_GetTodaysBirthdays.xaml`
- `BGYY_Main.xaml`
- `InitAllSettings.xaml`
- `GetTransactionData.xaml`
- `KillAllProcesses.xaml`
- `RetryCurrentTransaction.xaml`
- `RetryInit.xaml`
- `Process.xaml`

### Uncovered High-Risk Activities

| # | Location | Activity |
|---|----------|----------|
| 1 | `InitAllSettings.xaml:266` | Get BGYY_DryRun |
| 2 | `InitAllSettings.xaml:269` | ui:GetAsset |
| 3 | `GetTransactionData.xaml:158` | Get Queue Item |
| 4 | `GetTransactionData.xaml:160` | ui:GetTransactionItem |
| 5 | `GetTransactionData.xaml:169` | ui:GetTransactionItem |
| 6 | `SetTransactionStatus.xaml:68` | Set Success |
| 7 | `SetTransactionStatus.xaml:90` | Set Failed |

> **Recommendation:** Wrap these activities in TryCatch blocks with appropriate exception types (BusinessRuleException for data errors, System.Exception for general failures).

## 11. Trigger Configuration

Based on the process analysis, the following trigger configuration is recommended:

| # | Trigger Type | Reason | Configuration |
|---|-------------|--------|---------------|
| 1 | **Schedule** | Defined in SDD orchestrator_artifacts: BGYY_Daily_0800_ET | SDD-specified: BGYY_Daily_0800_ET | Cron: 0 8 * * * | Daily time trigger to start the process at 08:00 America/New_York. |

## 12. Upstream Quality Findings

The following quality warnings were produced by upstream pipeline stages (selector scoring, type validation, expression linting, etc.) and should be addressed during development:

| Code | Severity | Count | Sample Message |
|------|----------|-------|----------------|
| placeholder-value | warning | 14 | Contains 4 placeholder value(s) matching "\bTODO\b" [Developer Implementation Required] |
| hardcoded-retry-count | warning | 10 | Line 410: retry count hardcoded as 3 — consider externalizing to Config.xlsx (e.g., in_Config("MaxRetryNumber")) |
| hardcoded-retry-interval | warning | 10 | Line 410: retry interval hardcoded as "00:00:05" — consider externalizing to Config.xlsx |
| hardcoded-asset-name | warning | 3 | Line 92: asset name "BGYY_DryRun" is hardcoded — consider using a Config.xlsx entry or workflow argument |
| EXPRESSION_SYNTAX | warning | 4 | Line 518: C# 'null' should be VB.NET 'Nothing' in expression: New InvalidOperationException(&quot;[BGYY_GetTodaysBirthda... |
| COMPLEX_EXPRESSION_PASSTHROUGH | warning | 5 | Line 1225: Complex expression (lambdas, LINQ, nested calls, or 3+ operators) — emitting as-is to avoid regex corruption ... |
| TYPE_MISMATCH | warning | 4 | Line 290: Type mismatch — variable "str_TempScreenshotFile" (System.String) bound to ucas:UploadStorageFile.FileResource... |
| BARE_TOKEN_QUOTED | warning | 8 | Auto-quoted bare token "BGYY_DryRun" for ui:GetAsset.AssetName (expected String type) — wrapped in VB string quotes |
| RETRY_INTERVAL_DEFAULTED | warning | 7 | Post-repair: RetryInterval defaulted to "00:00:05" — verify this is appropriate for the workflow context |

## 13. Pre-Deployment Checklist

| # | Category | Task | Required |
|---|----------|------|----------|
| 1 | Deployment | Publish package to Orchestrator feed | Yes |
| 2 | Deployment | Create Process in target folder | Yes |
| 3 | Environment | Verify Orchestrator connection from robot | Yes |
| 4 | Assets | Provision asset: `[BGYY_DryRun]` | Yes |
| 5 | Trigger | Configure trigger (schedule/queue/API) | Yes |
| 6 | Testing | Run smoke test in target environment | Yes |
| 7 | Monitoring | Verify logging output in Orchestrator | Recommended |
| 8 | Governance | UAT test execution completed and sign-off obtained | Yes |
| 9 | Governance | Peer code review completed | Yes |
| 10 | Governance | All quality gate warnings addressed or risk-accepted | Yes |
| 11 | Governance | Business process owner validation obtained | Yes |
| 12 | Governance | CoE approval obtained | Yes |
| 13 | Governance | Production readiness assessment completed (monitoring, alerting, rollback plan documented) | Yes |

## 14. Deployment Readiness Score

**Overall: Mostly Ready — 33/50 (66%)**

| Section | Score | Notes |
|---------|-------|-------|
| Credentials & Assets | 10/10 | All credentials/assets properly configured |
| Exception Handling | 2/10 | Only 22% of high-risk activities covered by TryCatch; 8 file(s) with no TryCatch blocks |
| Queue Management | 10/10 | Queue configuration looks good |
| Build Quality | 1/10 | 65 quality warnings — significant remediation needed; 69 remediations — stub replacements need developer attention |
| Environment Setup | 10/10 | Environment requirements are straightforward |

> **Almost There:** A few items need attention before production deployment.

## 15. Pre-emission Spec Validation

Validation was performed on the WorkflowSpec tree before XAML assembly. Issues caught at this stage are cheaper to fix than post-emission quality gate findings.

| Metric | Count |
|---|---|
| Total activities checked | 190 |
| Valid activities | 190 |
| Unknown → Comment stubs | 0 |
| Non-catalog properties stripped | 41 |
| Enum values auto-corrected | 0 |
| Missing required props filled | 0 |
| Total issues | 26 |

### Pre-emission vs Post-emission

| Stage | Issues Caught/Fixed |
|---|---|
| Pre-emission (spec validation) | 41 auto-fixed, 26 total issues |
| Post-emission (quality gate) | 134 warnings/remediations |

## 16. Catalog Filter Adoption Report

Shows which pipeline stages use the filtered activity catalog (deprecated, non-emission-approved, and target-incompatible activities are excluded).

| Stage | Adopted | Total Lookups | Approved | Deprecated | Non-Approved | Target-Incompatible | Unknown |
|---|---|---|---|---|---|---|---|
| quality-gate | Yes | 560 | 560 | 0 | 0 | 0 | 0 |
| deterministic-validators | Yes | 0 | 0 | 0 | 0 | 0 | 0 |
| iterative-llm-corrector | Yes | 0 | 0 | 0 | 0 | 0 | 0 |
| workflow-tree-assembler | Yes | 109 | 109 | 0 | 0 | 0 | 0 |
| xaml-compliance | Yes | 192326 | 167408 | 0 | 23473 | 0 | 1445 |
| executable-path-validator | Yes | 428 | 362 | 0 | 0 | 0 | 66 |
| post-emission-dependency-analyzer | Yes | 9 | 9 | 0 | 0 | 0 | 0 |

---

## 17. Structured Report (JSON)

The following JSON appendix contains the full pipeline outcome report for programmatic consumption:

```json
{
  "fullyGeneratedFiles": [
    "SetTransactionStatus.xaml",
    "CloseAllApplications.xaml",
    "KillAllProcesses.xaml",
    "InitAllApplications.xaml",
    "Process.xaml"
  ],
  "autoRepairs": [
    {
      "repairCode": "REPAIR_PLACEHOLDER_CLEANUP",
      "file": "BGYY_GetTodaysBirthdays.xaml",
      "description": "Stripped 4 placeholder token(s) from BGYY_GetTodaysBirthdays.xaml",
      "developerAction": "Review BGYY_GetTodaysBirthdays.xaml for Comment elements marking where placeholder activities were removed",
      "estimatedEffortMinutes": 5
    },
    {
      "repairCode": "REPAIR_PLACEHOLDER_CLEANUP",
      "file": "BGYY_ResolveRecipient.xaml",
      "description": "Stripped 9 placeholder token(s) from BGYY_ResolveRecipient.xaml",
      "developerAction": "Review BGYY_ResolveRecipient.xaml for Comment elements marking where placeholder activities were removed",
      "estimatedEffortMinutes": 5
    },
    {
      "repairCode": "REPAIR_PLACEHOLDER_CLEANUP",
      "file": "BGYY_GenerateAndValidateDraft.xaml",
      "description": "Stripped 6 placeholder token(s) from BGYY_GenerateAndValidateDraft.xaml",
      "developerAction": "Review BGYY_GenerateAndValidateDraft.xaml for Comment elements marking where placeholder activities were removed",
      "estimatedEffortMinutes": 5
    },
    {
      "repairCode": "REPAIR_PLACEHOLDER_CLEANUP",
      "file": "BGYY_SendGmail.xaml",
      "description": "Stripped 3 placeholder token(s) from BGYY_SendGmail.xaml",
      "developerAction": "Review BGYY_SendGmail.xaml for Comment elements marking where placeholder activities were removed",
      "estimatedEffortMinutes": 5
    },
    {
      "repairCode": "REPAIR_PLACEHOLDER_CLEANUP",
      "file": "BGYY_CreateReviewTask.xaml",
      "description": "Stripped 1 placeholder token(s) from BGYY_CreateReviewTask.xaml",
      "developerAction": "Review BGYY_CreateReviewTask.xaml for Comment elements marking where placeholder activities were removed",
      "estimatedEffortMinutes": 5
    },
    {
      "repairCode": "REPAIR_PLACEHOLDER_CLEANUP",
      "file": "BGYY_Main.xaml",
      "description": "Stripped 5 placeholder token(s) from BGYY_Main.xaml",
      "developerAction": "Review BGYY_Main.xaml for Comment elements marking where placeholder activities were removed",
      "estimatedEffortMinutes": 5
    },
    {
      "repairCode": "REPAIR_PLACEHOLDER_CLEANUP",
      "file": "InitAllApplications.xaml",
      "description": "Stripped 1 placeholder token(s) from InitAllApplications.xaml",
      "developerAction": "Review InitAllApplications.xaml for Comment elements marking where placeholder activities were removed",
      "estimatedEffortMinutes": 5
    },
    {
      "repairCode": "REPAIR_GENERIC",
      "file": "BGYY_GetTodaysBirthdays.xaml",
      "description": "Catalog (DOM): move-to-child-element ForEach.Values in BGYY_GetTodaysBirthdays.xaml"
    },
    {
      "repairCode": "REPAIR_GENERIC",
      "file": "BGYY_GetTodaysBirthdays.xaml",
      "description": "Catalog (DOM): move-to-child-element ui:AddDataRow.DataTable in BGYY_GetTodaysBirthdays.xaml"
    },
    {
      "repairCode": "REPAIR_GENERIC",
      "file": "BGYY_ResolveRecipient.xaml",
      "description": "Catalog (DOM): move-to-child-element ForEach.Values in BGYY_ResolveRecipient.xaml"
    },
    {
      "repairCode": "REPAIR_GENERIC",
      "file": "BGYY_GenerateAndValidateDraft.xaml",
      "description": "Catalog (DOM): move-to-child-element ForEach.Values in BGYY_GenerateAndValidateDraft.xaml"
    },
    {
      "repairCode": "REPAIR_GENERIC",
      "file": "BGYY_Main.xaml",
      "description": "Catalog (DOM): move-to-child-element ForEach.Values in BGYY_Main.xaml"
    },
    {
      "repairCode": "REPAIR_GENERIC",
      "file": "InitAllSettings.xaml",
      "description": "Catalog (DOM): move-to-child-element ForEach.Values in InitAllSettings.xaml"
    },
    {
      "repairCode": "REPAIR_GENERIC",
      "file": "InitAllSettings.xaml",
      "description": "Catalog (DOM): move-to-child-element ForEach.Values in InitAllSettings.xaml"
    },
    {
      "repairCode": "REPAIR_GENERIC",
      "file": "GetTransactionData.xaml",
      "description": "Catalog (DOM): move-to-child-element ui:GetTransactionItem.QueueName in GetTransactionData.xaml"
    },
    {
      "repairCode": "REPAIR_MIXED_EXPRESSION_SYNTAX",
      "file": "BGYY_Main.xaml",
      "description": "Mixed-expression: [BGYY_Main] Workflow started. Initializing run context. → [BGYY_Main &amp; &quot; Workflow started. Initializing run context.&quot;] in BGYY_Main.xaml"
    },
    {
      "repairCode": "REPAIR_TYPE_MISMATCH",
      "file": "BGYY_GetTodaysBirthdays.xaml",
      "description": "Object variable is bound to a property expecting IEnumerable — retype the variable to the correct concrete collection type (e.g., List(Of String), DataTable) based on the upstream activity output"
    },
    {
      "repairCode": "REPAIR_TYPE_MISMATCH",
      "file": "BGYY_ResolveRecipient.xaml",
      "description": "Object variable is bound to a property expecting IEnumerable — retype the variable to the correct concrete collection type (e.g., List(Of String), DataTable) based on the upstream activity output"
    },
    {
      "repairCode": "REPAIR_TYPE_MISMATCH",
      "file": "BGYY_SendGmail.xaml",
      "description": "No known conversion from System.String to UiPath.Platform.ResourceHandling.IResource — review the variable type or activity property"
    },
    {
      "repairCode": "REPAIR_TYPE_MISMATCH",
      "file": "Main.xaml",
      "description": "No known conversion from scg:Dictionary(x:String, x:Object) to System.Collections.Generic.Dictionary`<System.String, System.Activities.Argument> — review the variable type or activity property"
    },
    {
      "repairCode": "REPAIR_TYPE_MISMATCH",
      "file": "Main.xaml",
      "description": "No known conversion from UiPath.Core.QueueItem to System.Collections.Generic.Dictionary`<System.String, System.Activities.Argument> — review the variable type or activity property"
    },
    {
      "repairCode": "REPAIR_TYPE_MISMATCH",
      "file": "Init.xaml",
      "description": "No known conversion from scg:Dictionary(x:String, x:Object) to System.Collections.Generic.Dictionary`<System.String, System.Activities.Argument> — review the variable type or activity property"
    }
  ],
  "remediations": [
    {
      "level": "activity",
      "file": "BGYY_SendGmail.xaml",
      "remediationCode": "DEGRADED_ACTIVITY_MISSING_PROPERTY",
      "reason": "Activity \"Send birthday greeting email via Gmail Integration Service connector\" missing required properties: Body — degraded to handoff block",
      "classifiedCheck": "critical-activity-degradation",
      "developerAction": "Provide the missing properties for \"UiPath.GSuite.Activities.GmailSendMessage\": Body",
      "estimatedEffortMinutes": 5
    },
    {
      "level": "activity",
      "file": "BGYY_WriteDedupe.xaml",
      "remediationCode": "DEGRADED_ACTIVITY_MISSING_PROPERTY",
      "reason": "Activity \"Update Existing BGYY_BirthdaySendLog Record with Latest Status and Audit Fields\" missing required properties: EntityObject — degraded to handoff block",
      "classifiedCheck": "critical-activity-degradation",
      "developerAction": "Provide the missing properties for \"UiPath.DataService.Activities.UpdateEntity\": EntityObject",
      "estimatedEffortMinutes": 5
    },
    {
      "level": "activity",
      "file": "BGYY_WriteDedupe.xaml",
      "remediationCode": "DEGRADED_ACTIVITY_MISSING_PROPERTY",
      "reason": "Activity \"Create New BGYY_BirthdaySendLog Record with All Audit Fields\" missing required properties: EntityObject — degraded to handoff block",
      "classifiedCheck": "critical-activity-degradation",
      "developerAction": "Provide the missing properties for \"UiPath.DataService.Activities.CreateEntity\": EntityObject",
      "estimatedEffortMinutes": 5
    },
    {
      "level": "activity",
      "file": "BGYY_CreateReviewTask.xaml",
      "remediationCode": "DEGRADED_ACTIVITY_MISSING_PROPERTY",
      "reason": "Activity \"Create BGYY_DraftReview Action Center form task with all required fields\" missing required properties: TaskTitle — degraded to handoff block",
      "classifiedCheck": "critical-activity-degradation",
      "developerAction": "Provide the missing properties for \"UiPath.Persistence.Activities.CreateFormTask\": TaskTitle",
      "estimatedEffortMinutes": 5
    },
    {
      "level": "activity",
      "file": "BGYY_SendGmail.xaml",
      "remediationCode": "DEGRADED_ACTIVITY_MISSING_PROPERTY",
      "reason": "Mail activity in cluster \"BGYY_SendGmail.xaml:BGYY_SendGmail:mail-cluster-0\" missing required properties: Body — degraded to handoff block",
      "classifiedCheck": "critical-activity-degradation",
      "developerAction": "Provide the missing properties for mail activity \"UiPath.GSuite.Activities.GmailSendMessage\": Body",
      "estimatedEffortMinutes": 5
    },
    {
      "level": "validation-finding",
      "file": "BGYY_ResolveRecipient.xaml",
      "remediationCode": "STUB_ACTIVITY_UNKNOWN",
      "reason": "Line 622: Undeclared variable \"personal\" in expression: str_CurrentEmailLabel = personal — variable is not declared in any <Variable> block in scope",
      "classifiedCheck": "UNDECLARED_VARIABLE",
      "developerAction": "Manually implement activity in BGYY_ResolveRecipient.xaml — estimated 15 min",
      "estimatedEffortMinutes": 15
    },
    {
      "level": "validation-finding",
      "file": "BGYY_ResolveRecipient.xaml",
      "remediationCode": "STUB_ACTIVITY_UNKNOWN",
      "reason": "Line 667: Undeclared variable \"home\" in expression: str_CurrentEmailLabel = home — variable is not declared in any <Variable> block in scope",
      "classifiedCheck": "UNDECLARED_VARIABLE",
      "developerAction": "Manually implement activity in BGYY_ResolveRecipient.xaml — estimated 15 min",
      "estimatedEffortMinutes": 15
    },
    {
      "level": "validation-finding",
      "file": "BGYY_CreateReviewTask.xaml",
      "remediationCode": "STUB_ACTIVITY_UNKNOWN",
      "reason": "Line 116: Undeclared variable \"vb_expression\" in expression: vb_expression — variable is not declared in any <Variable> block in scope",
      "classifiedCheck": "UNDECLARED_VARIABLE",
      "developerAction": "Manually implement activity in BGYY_CreateReviewTask.xaml — estimated 15 min",
      "estimatedEffortMinutes": 15
    },
    {
      "level": "validation-finding",
      "file": "BGYY_Main.xaml",
      "remediationCode": "STUB_ACTIVITY_UNKNOWN",
      "reason": "Line 248: Undeclared variable \"BGYY_Main\" in expression: BGYY_Main &amp; &quot; Workflow started. Initializing run co... — variable is not declared in any <Variable> block in scope",
      "classifiedCheck": "UNDECLARED_VARIABLE",
      "developerAction": "Manually implement activity in BGYY_Main.xaml — estimated 15 min",
      "estimatedEffortMinutes": 15
    },
    {
      "level": "validation-finding",
      "file": "BGYY_Main.xaml",
      "remediationCode": "STUB_ACTIVITY_UNKNOWN",
      "reason": "Line 638: Undeclared variable \"vb_expression\" in expression: vb_expression — variable is not declared in any <Variable> block in scope",
      "classifiedCheck": "UNDECLARED_VARIABLE",
      "developerAction": "Manually implement activity in BGYY_Main.xaml — estimated 15 min",
      "estimatedEffortMinutes": 15
    },
    {
      "level": "validation-finding",
      "file": "BGYY_Main.xaml",
      "remediationCode": "STUB_ACTIVITY_UNKNOWN",
      "reason": "Line 1045: Undeclared variable \"vb_expression\" in expression: vb_expression — variable is not declared in any <Variable> block in scope",
      "classifiedCheck": "UNDECLARED_VARIABLE",
      "developerAction": "Manually implement activity in BGYY_Main.xaml — estimated 15 min",
      "estimatedEffortMinutes": 15
    },
    {
      "level": "validation-finding",
      "file": "BGYY_Main.xaml",
      "remediationCode": "STUB_ACTIVITY_UNKNOWN",
      "reason": "Line 1198: Undeclared variable \"vb_expression\" in expression: vb_expression — variable is not declared in any <Variable> block in scope",
      "classifiedCheck": "UNDECLARED_VARIABLE",
      "developerAction": "Manually implement activity in BGYY_Main.xaml — estimated 15 min",
      "estimatedEffortMinutes": 15
    },
    {
      "level": "validation-finding",
      "file": "BGYY_Main.xaml",
      "remediationCode": "STUB_ACTIVITY_UNKNOWN",
      "reason": "Line 1375: Undeclared variable \"vb_expression\" in expression: vb_expression — variable is not declared in any <Variable> block in scope",
      "classifiedCheck": "UNDECLARED_VARIABLE",
      "developerAction": "Manually implement activity in BGYY_Main.xaml — estimated 15 min",
      "estimatedEffortMinutes": 15
    },
    {
      "level": "validation-finding",
      "file": "BGYY_GetTodaysBirthdays.xaml",
      "remediationCode": "STUB_ACTIVITY_UNKNOWN",
      "reason": "Line 556: Type mismatch — variable \"obj_ConnectorResponseList\" (System.Object) bound to ForEach.Values (expects System.Collections.IEnumerable). Object variable is bound to a property expecting IEnumerable — retype the variable to the correct concrete collection type (e.g., List(Of String), DataTable) based on the upstream activity output",
      "classifiedCheck": "OBJECT_TO_IENUMERABLE",
      "developerAction": "Manually implement activity in BGYY_GetTodaysBirthdays.xaml — estimated 15 min",
      "estimatedEffortMinutes": 15
    },
    {
      "level": "validation-finding",
      "file": "BGYY_ResolveRecipient.xaml",
      "remediationCode": "STUB_ACTIVITY_UNKNOWN",
      "reason": "Line 592: Type mismatch — variable \"obj_EmailAddresses\" (System.Object) bound to ForEach.Values (expects System.Collections.IEnumerable). Object variable is bound to a property expecting IEnumerable — retype the variable to the correct concrete collection type (e.g., List(Of String), DataTable) based on the upstream activity output",
      "classifiedCheck": "OBJECT_TO_IENUMERABLE",
      "developerAction": "Manually implement activity in BGYY_ResolveRecipient.xaml — estimated 15 min",
      "estimatedEffortMinutes": 15
    },
    {
      "level": "validation-finding",
      "file": "InitAllSettings.xaml",
      "remediationCode": "STUB_ACTIVITY_UNKNOWN",
      "reason": "Line 173: uexcel:ExcelApplicationScope is missing required property \"ExistingWorkbook\"",
      "classifiedCheck": "MISSING_REQUIRED_ACTIVITY_PROPERTY",
      "developerAction": "Manually implement activity in InitAllSettings.xaml — estimated 15 min",
      "estimatedEffortMinutes": 15
    },
    {
      "level": "validation-finding",
      "file": "BGYY_GetTodaysBirthdays.xaml",
      "remediationCode": "STUB_ACTIVITY_CATALOG_VIOLATION",
      "reason": "Property \"To\" on Assign must be a child element, not an attribute",
      "classifiedCheck": "CATALOG_STRUCTURAL_VIOLATION",
      "developerAction": "Fix property syntax for activity in BGYY_GetTodaysBirthdays.xaml — move attribute to child-element or vice versa per UiPath catalog",
      "estimatedEffortMinutes": 15
    },
    {
      "level": "validation-finding",
      "file": "BGYY_GetTodaysBirthdays.xaml",
      "remediationCode": "STUB_ACTIVITY_CATALOG_VIOLATION",
      "reason": "Property \"Value\" on Assign must be a child element, not an attribute",
      "classifiedCheck": "CATALOG_STRUCTURAL_VIOLATION",
      "developerAction": "Fix property syntax for activity in BGYY_GetTodaysBirthdays.xaml — move attribute to child-element or vice versa per UiPath catalog",
      "estimatedEffortMinutes": 15
    },
    {
      "level": "validation-finding",
      "file": "BGYY_GetTodaysBirthdays.xaml",
      "remediationCode": "STUB_ACTIVITY_CATALOG_VIOLATION",
      "reason": "Property \"Exception\" on Throw must be a child element, not an attribute",
      "classifiedCheck": "CATALOG_STRUCTURAL_VIOLATION",
      "developerAction": "Fix property syntax for activity in BGYY_GetTodaysBirthdays.xaml — move attribute to child-element or vice versa per UiPath catalog",
      "estimatedEffortMinutes": 15
    },
    {
      "level": "validation-finding",
      "file": "BGYY_GetTodaysBirthdays.xaml",
      "remediationCode": "STUB_ACTIVITY_CATALOG_VIOLATION",
      "reason": "Property \"ArrayRow\" on ui:AddDataRow must be a child element, not an attribute",
      "classifiedCheck": "CATALOG_STRUCTURAL_VIOLATION",
      "developerAction": "Fix property syntax for activity in BGYY_GetTodaysBirthdays.xaml — move attribute to child-element or vice versa per UiPath catalog",
      "estimatedEffortMinutes": 15
    },
    {
      "level": "validation-finding",
      "file": "BGYY_GetTodaysBirthdays.xaml",
      "remediationCode": "STUB_ACTIVITY_CATALOG_VIOLATION",
      "reason": "Property \"DataRow\" on ui:AddDataRow must be a child element, not an attribute",
      "classifiedCheck": "CATALOG_STRUCTURAL_VIOLATION",
      "developerAction": "Fix property syntax for activity in BGYY_GetTodaysBirthdays.xaml — move attribute to child-element or vice versa per UiPath catalog",
      "estimatedEffortMinutes": 15
    },
    {
      "level": "validation-finding",
      "file": "BGYY_ResolveRecipient.xaml",
      "remediationCode": "STUB_ACTIVITY_CATALOG_VIOLATION",
      "reason": "Property \"To\" on Assign must be a child element, not an attribute",
      "classifiedCheck": "CATALOG_STRUCTURAL_VIOLATION",
      "developerAction": "Fix property syntax for activity in BGYY_ResolveRecipient.xaml — move attribute to child-element or vice versa per UiPath catalog",
      "estimatedEffortMinutes": 15
    },
    {
      "level": "validation-finding",
      "file": "BGYY_ResolveRecipient.xaml",
      "remediationCode": "STUB_ACTIVITY_CATALOG_VIOLATION",
      "reason": "Property \"Value\" on Assign must be a child element, not an attribute",
      "classifiedCheck": "CATALOG_STRUCTURAL_VIOLATION",
      "developerAction": "Fix property syntax for activity in BGYY_ResolveRecipient.xaml — move attribute to child-element or vice versa per UiPath catalog",
      "estimatedEffortMinutes": 15
    },
    {
      "level": "validation-finding",
      "file": "BGYY_CheckDedupe.xaml",
      "remediationCode": "STUB_ACTIVITY_CATALOG_VIOLATION",
      "reason": "Property \"To\" on Assign must be a child element, not an attribute",
      "classifiedCheck": "CATALOG_STRUCTURAL_VIOLATION",
      "developerAction": "Fix property syntax for activity in BGYY_CheckDedupe.xaml — move attribute to child-element or vice versa per UiPath catalog",
      "estimatedEffortMinutes": 15
    },
    {
      "level": "validation-finding",
      "file": "BGYY_CheckDedupe.xaml",
      "remediationCode": "STUB_ACTIVITY_CATALOG_VIOLATION",
      "reason": "Property \"Value\" on Assign must be a child element, not an attribute",
      "classifiedCheck": "CATALOG_STRUCTURAL_VIOLATION",
      "developerAction": "Fix property syntax for activity in BGYY_CheckDedupe.xaml — move attribute to child-element or vice versa per UiPath catalog",
      "estimatedEffortMinutes": 15
    },
    {
      "level": "validation-finding",
      "file": "BGYY_GenerateAndValidateDraft.xaml",
      "remediationCode": "STUB_ACTIVITY_CATALOG_VIOLATION",
      "reason": "Property \"Path\" on ucas:ReadStorageText must be a child element, not an attribute",
      "classifiedCheck": "CATALOG_STRUCTURAL_VIOLATION",
      "developerAction": "Fix property syntax for activity in BGYY_GenerateAndValidateDraft.xaml — move attribute to child-element or vice versa per UiPath catalog",
      "estimatedEffortMinutes": 15
    },
    {
      "level": "validation-finding",
      "file": "BGYY_GenerateAndValidateDraft.xaml",
      "remediationCode": "STUB_ACTIVITY_CATALOG_VIOLATION",
      "reason": "Property \"StorageBucketName\" on ucas:ReadStorageText must be a child element, not an attribute",
      "classifiedCheck": "CATALOG_STRUCTURAL_VIOLATION",
      "developerAction": "Fix property syntax for activity in BGYY_GenerateAndValidateDraft.xaml — move attribute to child-element or vice versa per UiPath catalog",
      "estimatedEffortMinutes": 15
    },
    {
      "level": "validation-finding",
      "file": "BGYY_GenerateAndValidateDraft.xaml",
      "remediationCode": "STUB_ACTIVITY_CATALOG_VIOLATION",
      "reason": "Property \"To\" on Assign must be a child element, not an attribute",
      "classifiedCheck": "CATALOG_STRUCTURAL_VIOLATION",
      "developerAction": "Fix property syntax for activity in BGYY_GenerateAndValidateDraft.xaml — move attribute to child-element or vice versa per UiPath catalog",
      "estimatedEffortMinutes": 15
    },
    {
      "level": "validation-finding",
      "file": "BGYY_GenerateAndValidateDraft.xaml",
      "remediationCode": "STUB_ACTIVITY_CATALOG_VIOLATION",
      "reason": "Property \"Value\" on Assign must be a child element, not an attribute",
      "classifiedCheck": "CATALOG_STRUCTURAL_VIOLATION",
      "developerAction": "Fix property syntax for activity in BGYY_GenerateAndValidateDraft.xaml — move attribute to child-element or vice versa per UiPath catalog",
      "estimatedEffortMinutes": 15
    },
    {
      "level": "validation-finding",
      "file": "BGYY_GenerateAndValidateDraft.xaml",
      "remediationCode": "STUB_ACTIVITY_CATALOG_VIOLATION",
      "reason": "Property \"Input\" on ui:IsMatch must be a child element, not an attribute",
      "classifiedCheck": "CATALOG_STRUCTURAL_VIOLATION",
      "developerAction": "Fix property syntax for activity in BGYY_GenerateAndValidateDraft.xaml — move attribute to child-element or vice versa per UiPath catalog",
      "estimatedEffortMinutes": 15
    },
    {
      "level": "validation-finding",
      "file": "BGYY_GenerateAndValidateDraft.xaml",
      "remediationCode": "STUB_ACTIVITY_CATALOG_VIOLATION",
      "reason": "Property \"Pattern\" on ui:IsMatch must be a child element, not an attribute",
      "classifiedCheck": "CATALOG_STRUCTURAL_VIOLATION",
      "developerAction": "Fix property syntax for activity in BGYY_GenerateAndValidateDraft.xaml — move attribute to child-element or vice versa per UiPath catalog",
      "estimatedEffortMinutes": 15
    },
    {
      "level": "validation-finding",
      "file": "BGYY_SendGmail.xaml",
      "remediationCode": "STUB_ACTIVITY_CATALOG_VIOLATION",
      "reason": "Property \"To\" on Assign must be a child element, not an attribute",
      "classifiedCheck": "CATALOG_STRUCTURAL_VIOLATION",
      "developerAction": "Fix property syntax for activity in BGYY_SendGmail.xaml — move attribute to child-element or vice versa per UiPath catalog",
      "estimatedEffortMinutes": 15
    },
    {
      "level": "validation-finding",
      "file": "BGYY_SendGmail.xaml",
      "remediationCode": "STUB_ACTIVITY_CATALOG_VIOLATION",
      "reason": "Property \"Value\" on Assign must be a child element, not an attribute",
      "classifiedCheck": "CATALOG_STRUCTURAL_VIOLATION",
      "developerAction": "Fix property syntax for activity in BGYY_SendGmail.xaml — move attribute to child-element or vice versa per UiPath catalog",
      "estimatedEffortMinutes": 15
    },
    {
      "level": "validation-finding",
      "file": "BGYY_SendGmail.xaml",
      "remediationCode": "STUB_ACTIVITY_CATALOG_VIOLATION",
      "reason": "Property \"Exception\" on Throw must be a child element, not an attribute",
      "classifiedCheck": "CATALOG_STRUCTURAL_VIOLATION",
      "developerAction": "Fix property syntax for activity in BGYY_SendGmail.xaml — move attribute to child-element or vice versa per UiPath catalog",
      "estimatedEffortMinutes": 15
    },
    {
      "level": "validation-finding",
      "file": "BGYY_SendGmail.xaml",
      "remediationCode": "STUB_ACTIVITY_CATALOG_VIOLATION",
      "reason": "Property \"Destination\" on ucas:UploadStorageFile must be a child element, not an attribute",
      "classifiedCheck": "CATALOG_STRUCTURAL_VIOLATION",
      "developerAction": "Fix property syntax for activity in BGYY_SendGmail.xaml — move attribute to child-element or vice versa per UiPath catalog",
      "estimatedEffortMinutes": 15
    },
    {
      "level": "validation-finding",
      "file": "BGYY_SendGmail.xaml",
      "remediationCode": "STUB_ACTIVITY_CATALOG_VIOLATION",
      "reason": "Property \"FileResource\" on ucas:UploadStorageFile must be a child element, not an attribute",
      "classifiedCheck": "CATALOG_STRUCTURAL_VIOLATION",
      "developerAction": "Fix property syntax for activity in BGYY_SendGmail.xaml — move attribute to child-element or vice versa per UiPath catalog",
      "estimatedEffortMinutes": 15
    },
    {
      "level": "validation-finding",
      "file": "BGYY_SendGmail.xaml",
      "remediationCode": "STUB_ACTIVITY_CATALOG_VIOLATION",
      "reason": "Property \"Path\" on ucas:UploadStorageFile must be a child element, not an attribute",
      "classifiedCheck": "CATALOG_STRUCTURAL_VIOLATION",
      "developerAction": "Fix property syntax for activity in BGYY_SendGmail.xaml — move attribute to child-element or vice versa per UiPath catalog",
      "estimatedEffortMinutes": 15
    },
    {
      "level": "validation-finding",
      "file": "BGYY_SendGmail.xaml",
      "remediationCode": "STUB_ACTIVITY_CATALOG_VIOLATION",
      "reason": "Property \"StorageBucketName\" on ucas:UploadStorageFile must be a child element, not an attribute",
      "classifiedCheck": "CATALOG_STRUCTURAL_VIOLATION",
      "developerAction": "Fix property syntax for activity in BGYY_SendGmail.xaml — move attribute to child-element or vice versa per UiPath catalog",
      "estimatedEffortMinutes": 15
    },
    {
      "level": "validation-finding",
      "file": "BGYY_WriteDedupe.xaml",
      "remediationCode": "STUB_ACTIVITY_CATALOG_VIOLATION",
      "reason": "Property \"To\" on Assign must be a child element, not an attribute",
      "classifiedCheck": "CATALOG_STRUCTURAL_VIOLATION",
      "developerAction": "Fix property syntax for activity in BGYY_WriteDedupe.xaml — move attribute to child-element or vice versa per UiPath catalog",
      "estimatedEffortMinutes": 15
    },
    {
      "level": "validation-finding",
      "file": "BGYY_WriteDedupe.xaml",
      "remediationCode": "STUB_ACTIVITY_CATALOG_VIOLATION",
      "reason": "Property \"Value\" on Assign must be a child element, not an attribute",
      "classifiedCheck": "CATALOG_STRUCTURAL_VIOLATION",
      "developerAction": "Fix property syntax for activity in BGYY_WriteDedupe.xaml — move attribute to child-element or vice versa per UiPath catalog",
      "estimatedEffortMinutes": 15
    },
    {
      "level": "validation-finding",
      "file": "BGYY_CreateReviewTask.xaml",
      "remediationCode": "STUB_ACTIVITY_CATALOG_VIOLATION",
      "reason": "Property \"To\" on Assign must be a child element, not an attribute",
      "classifiedCheck": "CATALOG_STRUCTURAL_VIOLATION",
      "developerAction": "Fix property syntax for activity in BGYY_CreateReviewTask.xaml — move attribute to child-element or vice versa per UiPath catalog",
      "estimatedEffortMinutes": 15
    },
    {
      "level": "validation-finding",
      "file": "BGYY_CreateReviewTask.xaml",
      "remediationCode": "STUB_ACTIVITY_CATALOG_VIOLATION",
      "reason": "Property \"Value\" on Assign must be a child element, not an attribute",
      "classifiedCheck": "CATALOG_STRUCTURAL_VIOLATION",
      "developerAction": "Fix property syntax for activity in BGYY_CreateReviewTask.xaml — move attribute to child-element or vice versa per UiPath catalog",
      "estimatedEffortMinutes": 15
    },
    {
      "level": "validation-finding",
      "file": "BGYY_Main.xaml",
      "remediationCode": "STUB_ACTIVITY_CATALOG_VIOLATION",
      "reason": "Property \"To\" on Assign must be a child element, not an attribute",
      "classifiedCheck": "CATALOG_STRUCTURAL_VIOLATION",
      "developerAction": "Fix property syntax for activity in BGYY_Main.xaml — move attribute to child-element or vice versa per UiPath catalog",
      "estimatedEffortMinutes": 15
    },
    {
      "level": "validation-finding",
      "file": "BGYY_Main.xaml",
      "remediationCode": "STUB_ACTIVITY_CATALOG_VIOLATION",
      "reason": "Property \"Value\" on Assign must be a child element, not an attribute",
      "classifiedCheck": "CATALOG_STRUCTURAL_VIOLATION",
      "developerAction": "Fix property syntax for activity in BGYY_Main.xaml — move attribute to child-element or vice versa per UiPath catalog",
      "estimatedEffortMinutes": 15
    },
    {
      "level": "validation-finding",
      "file": "InitAllSettings.xaml",
      "remediationCode": "STUB_ACTIVITY_CATALOG_VIOLATION",
      "reason": "Property \"ExistingWorkbook\" on uexcel:ExcelApplicationScope must be a child element, not an attribute",
      "classifiedCheck": "CATALOG_STRUCTURAL_VIOLATION",
      "developerAction": "Fix property syntax for activity in InitAllSettings.xaml — move attribute to child-element or vice versa per UiPath catalog",
      "estimatedEffortMinutes": 15
    },
    {
      "level": "validation-finding",
      "file": "InitAllSettings.xaml",
      "remediationCode": "STUB_ACTIVITY_CATALOG_VIOLATION",
      "reason": "Property \"To\" on Assign must be a child element, not an attribute",
      "classifiedCheck": "CATALOG_STRUCTURAL_VIOLATION",
      "developerAction": "Fix property syntax for activity in InitAllSettings.xaml — move attribute to child-element or vice versa per UiPath catalog",
      "estimatedEffortMinutes": 15
    },
    {
      "level": "validation-finding",
      "file": "InitAllSettings.xaml",
      "remediationCode": "STUB_ACTIVITY_CATALOG_VIOLATION",
      "reason": "Property \"Value\" on Assign must be a child element, not an attribute",
      "classifiedCheck": "CATALOG_STRUCTURAL_VIOLATION",
      "developerAction": "Fix property syntax for activity in InitAllSettings.xaml — move attribute to child-element or vice versa per UiPath catalog",
      "estimatedEffortMinutes": 15
    },
    {
      "level": "validation-finding",
      "file": "Main.xaml",
      "remediationCode": "STUB_ACTIVITY_CATALOG_VIOLATION",
      "reason": "Property \"To\" on Assign must be a child element, not an attribute",
      "classifiedCheck": "CATALOG_STRUCTURAL_VIOLATION",
      "developerAction": "Fix property syntax for activity in Main.xaml — move attribute to child-element or vice versa per UiPath catalog",
      "estimatedEffortMinutes": 15
    },
    {
      "level": "validation-finding",
      "file": "Main.xaml",
      "remediationCode": "STUB_ACTIVITY_CATALOG_VIOLATION",
      "reason": "Property \"Value\" on Assign must be a child element, not an attribute",
      "classifiedCheck": "CATALOG_STRUCTURAL_VIOLATION",
      "developerAction": "Fix property syntax for activity in Main.xaml — move attribute to child-element or vice versa per UiPath catalog",
      "estimatedEffortMinutes": 15
    },
    {
      "level": "validation-finding",
      "file": "GetTransactionData.xaml",
      "remediationCode": "STUB_ACTIVITY_CATALOG_VIOLATION",
      "reason": "Property \"To\" on Assign must be a child element, not an attribute",
      "classifiedCheck": "CATALOG_STRUCTURAL_VIOLATION",
      "developerAction": "Fix property syntax for activity in GetTransactionData.xaml — move attribute to child-element or vice versa per UiPath catalog",
      "estimatedEffortMinutes": 15
    },
    {
      "level": "validation-finding",
      "file": "GetTransactionData.xaml",
      "remediationCode": "STUB_ACTIVITY_CATALOG_VIOLATION",
      "reason": "Property \"Value\" on Assign must be a child element, not an attribute",
      "classifiedCheck": "CATALOG_STRUCTURAL_VIOLATION",
      "developerAction": "Fix property syntax for activity in GetTransactionData.xaml — move attribute to child-element or vice versa per UiPath catalog",
      "estimatedEffortMinutes": 15
    },
    {
      "level": "validation-finding",
      "file": "Init.xaml",
      "remediationCode": "STUB_ACTIVITY_CATALOG_VIOLATION",
      "reason": "Property \"To\" on Assign must be a child element, not an attribute",
      "classifiedCheck": "CATALOG_STRUCTURAL_VIOLATION",
      "developerAction": "Fix property syntax for activity in Init.xaml — move attribute to child-element or vice versa per UiPath catalog",
      "estimatedEffortMinutes": 15
    },
    {
      "level": "validation-finding",
      "file": "Init.xaml",
      "remediationCode": "STUB_ACTIVITY_CATALOG_VIOLATION",
      "reason": "Property \"Value\" on Assign must be a child element, not an attribute",
      "classifiedCheck": "CATALOG_STRUCTURAL_VIOLATION",
      "developerAction": "Fix property syntax for activity in Init.xaml — move attribute to child-element or vice versa per UiPath catalog",
      "estimatedEffortMinutes": 15
    },
    {
      "level": "validation-finding",
      "file": "Init.xaml",
      "remediationCode": "STUB_ACTIVITY_CATALOG_VIOLATION",
      "reason": "Property \"Exception\" on Throw must be a child element, not an attribute",
      "classifiedCheck": "CATALOG_STRUCTURAL_VIOLATION",
      "developerAction": "Fix property syntax for activity in Init.xaml — move attribute to child-element or vice versa per UiPath catalog",
      "estimatedEffortMinutes": 15
    },
    {
      "level": "validation-finding",
      "file": "RetryCurrentTransaction.xaml",
      "remediationCode": "STUB_ACTIVITY_CATALOG_VIOLATION",
      "reason": "Property \"To\" on Assign must be a child element, not an attribute",
      "classifiedCheck": "CATALOG_STRUCTURAL_VIOLATION",
      "developerAction": "Fix property syntax for activity in RetryCurrentTransaction.xaml — move attribute to child-element or vice versa per UiPath catalog",
      "estimatedEffortMinutes": 15
    },
    {
      "level": "validation-finding",
      "file": "RetryCurrentTransaction.xaml",
      "remediationCode": "STUB_ACTIVITY_CATALOG_VIOLATION",
      "reason": "Property \"Value\" on Assign must be a child element, not an attribute",
      "classifiedCheck": "CATALOG_STRUCTURAL_VIOLATION",
      "developerAction": "Fix property syntax for activity in RetryCurrentTransaction.xaml — move attribute to child-element or vice versa per UiPath catalog",
      "estimatedEffortMinutes": 15
    },
    {
      "level": "validation-finding",
      "file": "RetryInit.xaml",
      "remediationCode": "STUB_ACTIVITY_CATALOG_VIOLATION",
      "reason": "Property \"To\" on Assign must be a child element, not an attribute",
      "classifiedCheck": "CATALOG_STRUCTURAL_VIOLATION",
      "developerAction": "Fix property syntax for activity in RetryInit.xaml — move attribute to child-element or vice versa per UiPath catalog",
      "estimatedEffortMinutes": 15
    },
    {
      "level": "validation-finding",
      "file": "RetryInit.xaml",
      "remediationCode": "STUB_ACTIVITY_CATALOG_VIOLATION",
      "reason": "Property \"Value\" on Assign must be a child element, not an attribute",
      "classifiedCheck": "CATALOG_STRUCTURAL_VIOLATION",
      "developerAction": "Fix property syntax for activity in RetryInit.xaml — move attribute to child-element or vice versa per UiPath catalog",
      "estimatedEffortMinutes": 15
    },
    {
      "level": "workflow",
      "file": "BGYY_GetTodaysBirthdays.xaml",
      "remediationCode": "STUB_WORKFLOW_BLOCKING",
      "reason": "Final validation: XAML well-formedness violations — replaced with stub. Details: [xml-wellformedness] XML parse error at line 1030, col 129 (code: InvalidChar): char '&' is not expected.",
      "classifiedCheck": "xml-wellformedness",
      "developerAction": "Fix XML structure in BGYY_GetTodaysBirthdays.xaml — [xml-wellformedness] XML parse error at line 1030, col 129 (code: InvalidChar): char '&' is not expected.",
      "estimatedEffortMinutes": 15
    },
    {
      "level": "workflow",
      "file": "BGYY_Main.xaml",
      "remediationCode": "STUB_WORKFLOW_BLOCKING",
      "reason": "Final validation: XAML well-formedness violations — replaced with stub. Details: [xml-wellformedness] XML parse error at line 1009, col 150 (code: InvalidChar): char '&' is not expected.",
      "classifiedCheck": "xml-wellformedness",
      "developerAction": "Fix XML structure in BGYY_Main.xaml — [xml-wellformedness] XML parse error at line 1009, col 150 (code: InvalidChar): char '&' is not expected.",
      "estimatedEffortMinutes": 15
    },
    {
      "level": "activity",
      "file": "BGYY_ResolveRecipient.xaml",
      "remediationCode": "UNDECLARED_VARIABLE_MANUAL",
      "reason": "Undeclared variable \"personal\" — type cannot be auto-inferred (no recognized naming prefix)",
      "classifiedCheck": "UNDECLARED_VARIABLE",
      "developerAction": "Declare variable \"personal\" in BGYY_ResolveRecipient.xaml with the appropriate type. Expression context: str_CurrentEmailLabel = personal",
      "estimatedEffortMinutes": 5
    },
    {
      "level": "activity",
      "file": "BGYY_ResolveRecipient.xaml",
      "remediationCode": "UNDECLARED_VARIABLE_MANUAL",
      "reason": "Undeclared variable \"home\" — type cannot be auto-inferred (no recognized naming prefix)",
      "classifiedCheck": "UNDECLARED_VARIABLE",
      "developerAction": "Declare variable \"home\" in BGYY_ResolveRecipient.xaml with the appropriate type. Expression context: str_CurrentEmailLabel = home",
      "estimatedEffortMinutes": 5
    },
    {
      "level": "activity",
      "file": "BGYY_CreateReviewTask.xaml",
      "remediationCode": "UNDECLARED_VARIABLE_MANUAL",
      "reason": "Undeclared variable \"vb_expression\" — type cannot be auto-inferred (no recognized naming prefix)",
      "classifiedCheck": "UNDECLARED_VARIABLE",
      "developerAction": "Declare variable \"vb_expression\" in BGYY_CreateReviewTask.xaml with the appropriate type. Expression context: vb_expression",
      "estimatedEffortMinutes": 5
    },
    {
      "level": "activity",
      "file": "BGYY_Main.xaml",
      "remediationCode": "UNDECLARED_VARIABLE_MANUAL",
      "reason": "Undeclared variable \"BGYY_Main\" — type cannot be auto-inferred (no recognized naming prefix)",
      "classifiedCheck": "UNDECLARED_VARIABLE",
      "developerAction": "Declare variable \"BGYY_Main\" in BGYY_Main.xaml with the appropriate type. Expression context: BGYY_Main &amp; &quot; Workflow started. Initializing run co...",
      "estimatedEffortMinutes": 5
    },
    {
      "level": "activity",
      "file": "BGYY_Main.xaml",
      "remediationCode": "UNDECLARED_VARIABLE_MANUAL",
      "reason": "Undeclared variable \"vb_expression\" — type cannot be auto-inferred (no recognized naming prefix)",
      "classifiedCheck": "UNDECLARED_VARIABLE",
      "developerAction": "Declare variable \"vb_expression\" in BGYY_Main.xaml with the appropriate type. Expression context: vb_expression",
      "estimatedEffortMinutes": 5
    },
    {
      "level": "activity",
      "file": "BGYY_Main.xaml",
      "remediationCode": "UNDECLARED_VARIABLE_MANUAL",
      "reason": "Undeclared variable \"vb_expression\" — type cannot be auto-inferred (no recognized naming prefix)",
      "classifiedCheck": "UNDECLARED_VARIABLE",
      "developerAction": "Declare variable \"vb_expression\" in BGYY_Main.xaml with the appropriate type. Expression context: vb_expression",
      "estimatedEffortMinutes": 5
    },
    {
      "level": "activity",
      "file": "BGYY_Main.xaml",
      "remediationCode": "UNDECLARED_VARIABLE_MANUAL",
      "reason": "Undeclared variable \"vb_expression\" — type cannot be auto-inferred (no recognized naming prefix)",
      "classifiedCheck": "UNDECLARED_VARIABLE",
      "developerAction": "Declare variable \"vb_expression\" in BGYY_Main.xaml with the appropriate type. Expression context: vb_expression",
      "estimatedEffortMinutes": 5
    },
    {
      "level": "activity",
      "file": "BGYY_Main.xaml",
      "remediationCode": "UNDECLARED_VARIABLE_MANUAL",
      "reason": "Undeclared variable \"vb_expression\" — type cannot be auto-inferred (no recognized naming prefix)",
      "classifiedCheck": "UNDECLARED_VARIABLE",
      "developerAction": "Declare variable \"vb_expression\" in BGYY_Main.xaml with the appropriate type. Expression context: vb_expression",
      "estimatedEffortMinutes": 5
    },
    {
      "level": "activity",
      "file": "",
      "remediationCode": "POST_ASSEMBLY_REPAIR",
      "reason": "[MISSING_REQUIRED_PROPERTY_DEFECT] uexcel:ExcelApplicationScope.ExistingWorkbook has no valid source binding and no contract-valid fallback — structured defect, property left absent",
      "classifiedCheck": "post-assembly-repair",
      "developerAction": "uexcel:ExcelApplicationScope.ExistingWorkbook has no valid source binding and no contract-valid fallback — structured defect, property left absent",
      "estimatedEffortMinutes": 5
    }
  ],
  "propertyRemediations": [],
  "downgradeEvents": [],
  "qualityWarnings": [
    {
      "check": "placeholder-value",
      "file": "BGYY_GetTodaysBirthdays.xaml",
      "detail": "Contains 4 placeholder value(s) matching \"\\bTODO\\b\" [Developer Implementation Required]",
      "severity": "warning",
      "stubCategory": "handoff"
    },
    {
      "check": "placeholder-value",
      "file": "BGYY_GetTodaysBirthdays.xaml",
      "detail": "Contains 4 placeholder value(s) matching \"\\bPLACEHOLDER\\b\" [Developer Implementation Required]",
      "severity": "warning",
      "stubCategory": "handoff"
    },
    {
      "check": "placeholder-value",
      "file": "BGYY_ResolveRecipient.xaml",
      "detail": "Contains 9 placeholder value(s) matching \"\\bTODO\\b\" [Developer Implementation Required]",
      "severity": "warning",
      "stubCategory": "handoff"
    },
    {
      "check": "placeholder-value",
      "file": "BGYY_ResolveRecipient.xaml",
      "detail": "Contains 9 placeholder value(s) matching \"\\bPLACEHOLDER\\b\" [Developer Implementation Required]",
      "severity": "warning",
      "stubCategory": "handoff"
    },
    {
      "check": "placeholder-value",
      "file": "BGYY_GenerateAndValidateDraft.xaml",
      "detail": "Contains 6 placeholder value(s) matching \"\\bTODO\\b\" [Developer Implementation Required]",
      "severity": "warning",
      "stubCategory": "handoff"
    },
    {
      "check": "placeholder-value",
      "file": "BGYY_GenerateAndValidateDraft.xaml",
      "detail": "Contains 7 placeholder value(s) matching \"\\bPLACEHOLDER\\b\" [Developer Implementation Required]",
      "severity": "warning",
      "stubCategory": "handoff"
    },
    {
      "check": "placeholder-value",
      "file": "BGYY_SendGmail.xaml",
      "detail": "Contains 3 placeholder value(s) matching \"\\bTODO\\b\" [Developer Implementation Required]",
      "severity": "warning",
      "stubCategory": "handoff"
    },
    {
      "check": "placeholder-value",
      "file": "BGYY_SendGmail.xaml",
      "detail": "Contains 3 placeholder value(s) matching \"\\bPLACEHOLDER\\b\" [Developer Implementation Required]",
      "severity": "warning",
      "stubCategory": "handoff"
    },
    {
      "check": "placeholder-value",
      "file": "BGYY_CreateReviewTask.xaml",
      "detail": "Contains 1 placeholder value(s) matching \"\\bTODO\\b\" [Developer Implementation Required]",
      "severity": "warning",
      "stubCategory": "handoff"
    },
    {
      "check": "placeholder-value",
      "file": "BGYY_CreateReviewTask.xaml",
      "detail": "Contains 1 placeholder value(s) matching \"\\bPLACEHOLDER\\b\" [Developer Implementation Required]",
      "severity": "warning",
      "stubCategory": "handoff"
    },
    {
      "check": "placeholder-value",
      "file": "BGYY_Main.xaml",
      "detail": "Contains 5 placeholder value(s) matching \"\\bTODO\\b\" [Developer Implementation Required]",
      "severity": "warning",
      "stubCategory": "handoff"
    },
    {
      "check": "placeholder-value",
      "file": "BGYY_Main.xaml",
      "detail": "Contains 5 placeholder value(s) matching \"\\bPLACEHOLDER\\b\" [Developer Implementation Required]",
      "severity": "warning",
      "stubCategory": "handoff"
    },
    {
      "check": "placeholder-value",
      "file": "InitAllApplications.xaml",
      "detail": "Contains 1 placeholder value(s) matching \"\\bTODO\\b\" [Developer Implementation Required]",
      "severity": "warning",
      "stubCategory": "handoff"
    },
    {
      "check": "placeholder-value",
      "file": "InitAllApplications.xaml",
      "detail": "Contains 1 placeholder value(s) matching \"\\bPLACEHOLDER\\b\" [Developer Implementation Required]",
      "severity": "warning",
      "stubCategory": "handoff"
    },
    {
      "check": "hardcoded-retry-count",
      "file": "BGYY_GetTodaysBirthdays.xaml",
      "detail": "Line 410: retry count hardcoded as 3 — consider externalizing to Config.xlsx (e.g., in_Config(\"MaxRetryNumber\"))",
      "severity": "warning"
    },
    {
      "check": "hardcoded-retry-count",
      "file": "BGYY_GetTodaysBirthdays.xaml",
      "detail": "Line 440: retry count hardcoded as 3 — consider externalizing to Config.xlsx (e.g., in_Config(\"MaxRetryNumber\"))",
      "severity": "warning"
    },
    {
      "check": "hardcoded-retry-count",
      "file": "BGYY_GetTodaysBirthdays.xaml",
      "detail": "Line 455: retry count hardcoded as 3 — consider externalizing to Config.xlsx (e.g., in_Config(\"MaxRetryNumber\"))",
      "severity": "warning"
    },
    {
      "check": "hardcoded-retry-interval",
      "file": "BGYY_GetTodaysBirthdays.xaml",
      "detail": "Line 410: retry interval hardcoded as \"00:00:05\" — consider externalizing to Config.xlsx",
      "severity": "warning"
    },
    {
      "check": "hardcoded-retry-interval",
      "file": "BGYY_GetTodaysBirthdays.xaml",
      "detail": "Line 440: retry interval hardcoded as \"00:00:05\" — consider externalizing to Config.xlsx",
      "severity": "warning"
    },
    {
      "check": "hardcoded-retry-interval",
      "file": "BGYY_GetTodaysBirthdays.xaml",
      "detail": "Line 455: retry interval hardcoded as \"00:00:05\" — consider externalizing to Config.xlsx",
      "severity": "warning"
    },
    {
      "check": "hardcoded-retry-count",
      "file": "BGYY_ResolveRecipient.xaml",
      "detail": "Line 257: retry count hardcoded as 3 — consider externalizing to Config.xlsx (e.g., in_Config(\"MaxRetryNumber\"))",
      "severity": "warning"
    },
    {
      "check": "hardcoded-retry-count",
      "file": "BGYY_ResolveRecipient.xaml",
      "detail": "Line 518: retry count hardcoded as 3 — consider externalizing to Config.xlsx (e.g., in_Config(\"MaxRetryNumber\"))",
      "severity": "warning"
    },
    {
      "check": "hardcoded-retry-count",
      "file": "BGYY_ResolveRecipient.xaml",
      "detail": "Line 533: retry count hardcoded as 3 — consider externalizing to Config.xlsx (e.g., in_Config(\"MaxRetryNumber\"))",
      "severity": "warning"
    },
    {
      "check": "hardcoded-retry-interval",
      "file": "BGYY_ResolveRecipient.xaml",
      "detail": "Line 257: retry interval hardcoded as \"00:00:05\" — consider externalizing to Config.xlsx",
      "severity": "warning"
    },
    {
      "check": "hardcoded-retry-interval",
      "file": "BGYY_ResolveRecipient.xaml",
      "detail": "Line 518: retry interval hardcoded as \"00:00:05\" — consider externalizing to Config.xlsx",
      "severity": "warning"
    },
    {
      "check": "hardcoded-retry-interval",
      "file": "BGYY_ResolveRecipient.xaml",
      "detail": "Line 533: retry interval hardcoded as \"00:00:05\" — consider externalizing to Config.xlsx",
      "severity": "warning"
    },
    {
      "check": "hardcoded-retry-count",
      "file": "BGYY_SendGmail.xaml",
      "detail": "Line 196: retry count hardcoded as 3 — consider externalizing to Config.xlsx (e.g., in_Config(\"MaxRetryNumber\"))",
      "severity": "warning"
    },
    {
      "check": "hardcoded-retry-count",
      "file": "BGYY_SendGmail.xaml",
      "detail": "Line 206: retry count hardcoded as 3 — consider externalizing to Config.xlsx (e.g., in_Config(\"MaxRetryNumber\"))",
      "severity": "warning"
    },
    {
      "check": "hardcoded-retry-interval",
      "file": "BGYY_SendGmail.xaml",
      "detail": "Line 196: retry interval hardcoded as \"00:00:05\" — consider externalizing to Config.xlsx",
      "severity": "warning"
    },
    {
      "check": "hardcoded-retry-interval",
      "file": "BGYY_SendGmail.xaml",
      "detail": "Line 206: retry interval hardcoded as \"00:00:05\" — consider externalizing to Config.xlsx",
      "severity": "warning"
    },
    {
      "check": "hardcoded-asset-name",
      "file": "BGYY_SendGmail.xaml",
      "detail": "Line 92: asset name \"BGYY_DryRun\" is hardcoded — consider using a Config.xlsx entry or workflow argument",
      "severity": "warning"
    },
    {
      "check": "hardcoded-retry-count",
      "file": "BGYY_WriteDedupe.xaml",
      "detail": "Line 98: retry count hardcoded as 3 — consider externalizing to Config.xlsx (e.g., in_Config(\"MaxRetryNumber\"))",
      "severity": "warning"
    },
    {
      "check": "hardcoded-retry-count",
      "file": "BGYY_WriteDedupe.xaml",
      "detail": "Line 103: retry count hardcoded as 3 — consider externalizing to Config.xlsx (e.g., in_Config(\"MaxRetryNumber\"))",
      "severity": "warning"
    },
    {
      "check": "hardcoded-retry-interval",
      "file": "BGYY_WriteDedupe.xaml",
      "detail": "Line 98: retry interval hardcoded as \"00:00:05\" — consider externalizing to Config.xlsx",
      "severity": "warning"
    },
    {
      "check": "hardcoded-retry-interval",
      "file": "BGYY_WriteDedupe.xaml",
      "detail": "Line 103: retry interval hardcoded as \"00:00:05\" — consider externalizing to Config.xlsx",
      "severity": "warning"
    },
    {
      "check": "hardcoded-asset-name",
      "file": "BGYY_Main.xaml",
      "detail": "Line 479: asset name \"BGYY_DryRun\" is hardcoded — consider using a Config.xlsx entry or workflow argument",
      "severity": "warning"
    },
    {
      "check": "hardcoded-asset-name",
      "file": "InitAllSettings.xaml",
      "detail": "Line 266: asset name \"BGYY_DryRun\" is hardcoded — consider using a Config.xlsx entry or workflow argument",
      "severity": "warning"
    },
    {
      "check": "EXPRESSION_SYNTAX",
      "file": "BGYY_GetTodaysBirthdays.xaml",
      "detail": "Line 518: C# 'null' should be VB.NET 'Nothing' in expression: New InvalidOperationException(&quot;[BGYY_GetTodaysBirthdays] Google Calendar co...",
      "severity": "warning"
    },
    {
      "check": "EXPRESSION_SYNTAX",
      "file": "BGYY_GetTodaysBirthdays.xaml",
      "detail": "Line 1030: C# '+' for string concatenation should be VB.NET '&' in expression: System.Text.RegularExpressions.Regex.Replace(str_EventFullName.Trim(), &quot;\\s+...",
      "severity": "warning"
    },
    {
      "check": "COMPLEX_EXPRESSION_PASSTHROUGH",
      "file": "BGYY_GenerateAndValidateDraft.xaml",
      "detail": "Line 1225: Complex expression (lambdas, LINQ, nested calls, or 3+ operators) — emitting as-is to avoid regex corruption in expression: bool_JsonParseSuccess AndAlso Not String.IsNullOrWhiteSpace(str_ParsedBody) AndA...",
      "severity": "warning"
    },
    {
      "check": "COMPLEX_EXPRESSION_PASSTHROUGH",
      "file": "BGYY_GenerateAndValidateDraft.xaml",
      "detail": "Line 1255: Complex expression (lambdas, LINQ, nested calls, or 3+ operators) — emitting as-is to avoid regex corruption in expression: Newtonsoft.Json.JsonConvert.SerializeObject(New With {.RunId = InRunId, .FullNam...",
      "severity": "warning"
    },
    {
      "check": "COMPLEX_EXPRESSION_PASSTHROUGH",
      "file": "BGYY_GenerateAndValidateDraft.xaml",
      "detail": "Line 594: Complex expression (lambdas, LINQ, nested calls, or 3+ operators) — emitting as-is to avoid regex corruption in expression: If(String.IsNullOrWhiteSpace(str_BannedPhrasesRaw), New String(){}, str_BannedPh...",
      "severity": "warning"
    },
    {
      "check": "EXPRESSION_SYNTAX",
      "file": "BGYY_SendGmail.xaml",
      "detail": "Line 192: C# 'null' should be VB.NET 'Nothing' in expression: New System.ArgumentException(&quot;[BGYY_SendGmail] Required argument(s) null or...",
      "severity": "warning"
    },
    {
      "check": "COMPLEX_EXPRESSION_PASSTHROUGH",
      "file": "BGYY_SendGmail.xaml",
      "detail": "Line 263: Complex expression (lambdas, LINQ, nested calls, or 3+ operators) — emitting as-is to avoid regex corruption in expression: System.IO.Path.Combine(System.IO.Path.GetTempPath(), \"BGYY_SendGmail_\" &amp; InR...",
      "severity": "warning"
    },
    {
      "check": "COMPLEX_EXPRESSION_PASSTHROUGH",
      "file": "BGYY_SendGmail.xaml",
      "detail": "Line 271: Complex expression (lambdas, LINQ, nested calls, or 3+ operators) — emitting as-is to avoid regex corruption in expression: \"runs/\" &amp; InRunId &amp; \"/error/BGYY_SendGmail_\" &amp; InRecipientEmail.GetH...",
      "severity": "warning"
    },
    {
      "check": "EXPRESSION_SYNTAX",
      "file": "BGYY_Main.xaml",
      "detail": "Line 1009: C# '+' for string concatenation should be VB.NET '&' in expression: System.Text.RegularExpressions.Regex.Replace(str_CurrentFullName.Trim().ToLowerI...",
      "severity": "warning"
    },
    {
      "check": "TYPE_MISMATCH",
      "file": "BGYY_SendGmail.xaml",
      "detail": "Line 290: Type mismatch — variable \"str_TempScreenshotFile\" (System.String) bound to ucas:UploadStorageFile.FileResource (expects UiPath.Platform.ResourceHandling.IResource). No known conversion from System.String to UiPath.Platform.ResourceHandling.IResource — review the variable type or activity property",
      "severity": "warning"
    },
    {
      "check": "BARE_TOKEN_QUOTED",
      "file": "BGYY_SendGmail.xaml",
      "detail": "Auto-quoted bare token \"BGYY_DryRun\" for ui:GetAsset.AssetName (expected String type) — wrapped in VB string quotes",
      "severity": "warning"
    },
    {
      "check": "BARE_TOKEN_QUOTED",
      "file": "BGYY_Main.xaml",
      "detail": "Auto-quoted bare token \"BGYY_DryRun\" for ui:GetAsset.AssetName (expected String type) — wrapped in VB string quotes",
      "severity": "warning"
    },
    {
      "check": "BARE_TOKEN_QUOTED",
      "file": "InitAllSettings.xaml",
      "detail": "Auto-quoted bare token \"Settings\" for uexcel:ExcelReadRange.SheetName (expected String type) — wrapped in VB string quotes",
      "severity": "warning"
    },
    {
      "check": "BARE_TOKEN_QUOTED",
      "file": "InitAllSettings.xaml",
      "detail": "Auto-quoted bare token \"Constants\" for uexcel:ExcelReadRange.SheetName (expected String type) — wrapped in VB string quotes",
      "severity": "warning"
    },
    {
      "check": "BARE_TOKEN_QUOTED",
      "file": "InitAllSettings.xaml",
      "detail": "Auto-quoted bare token \"BGYY_DryRun\" for ui:GetAsset.AssetName (expected String type) — wrapped in VB string quotes",
      "severity": "warning"
    },
    {
      "check": "TYPE_MISMATCH",
      "file": "Main.xaml",
      "detail": "Line 81: Type mismatch — variable \"dict_Config\" (scg:Dictionary(x:String, x:Object)) bound to ui:InvokeWorkflowFile.Arguments (expects System.Collections.Generic.Dictionary`<System.String, System.Activities.Argument>). No known conversion from scg:Dictionary(x:String, x:Object) to System.Collections.Generic.Dictionary`<System.String, System.Activities.Argument> — review the variable type or activity property",
      "severity": "warning"
    },
    {
      "check": "TYPE_MISMATCH",
      "file": "Main.xaml",
      "detail": "Line 134: Type mismatch — variable \"qi_TransactionItem\" (UiPath.Core.QueueItem) bound to ui:InvokeWorkflowFile.Arguments (expects System.Collections.Generic.Dictionary`<System.String, System.Activities.Argument>). No known conversion from UiPath.Core.QueueItem to System.Collections.Generic.Dictionary`<System.String, System.Activities.Argument> — review the variable type or activity property",
      "severity": "warning"
    },
    {
      "check": "BARE_TOKEN_QUOTED",
      "file": "KillAllProcesses.xaml",
      "detail": "Auto-quoted bare token \"chrome\" for ui:KillProcess.ProcessName (expected String type) — wrapped in VB string quotes",
      "severity": "warning"
    },
    {
      "check": "BARE_TOKEN_QUOTED",
      "file": "KillAllProcesses.xaml",
      "detail": "Auto-quoted bare token \"iexplore\" for ui:KillProcess.ProcessName (expected String type) — wrapped in VB string quotes",
      "severity": "warning"
    },
    {
      "check": "BARE_TOKEN_QUOTED",
      "file": "KillAllProcesses.xaml",
      "detail": "Auto-quoted bare token \"EXCEL\" for ui:KillProcess.ProcessName (expected String type) — wrapped in VB string quotes",
      "severity": "warning"
    },
    {
      "check": "TYPE_MISMATCH",
      "file": "Init.xaml",
      "detail": "Line 68: Type mismatch — variable \"dict_Config\" (scg:Dictionary(x:String, x:Object)) bound to ui:InvokeWorkflowFile.Arguments (expects System.Collections.Generic.Dictionary`<System.String, System.Activities.Argument>). No known conversion from scg:Dictionary(x:String, x:Object) to System.Collections.Generic.Dictionary`<System.String, System.Activities.Argument> — review the variable type or activity property",
      "severity": "warning"
    },
    {
      "check": "RETRY_INTERVAL_DEFAULTED",
      "file": "BGYY_ResolveRecipient.xaml",
      "detail": "Post-repair: RetryInterval defaulted to \"00:00:05\" — verify this is appropriate for the workflow context",
      "severity": "warning"
    },
    {
      "check": "RETRY_INTERVAL_DEFAULTED",
      "file": "BGYY_ResolveRecipient.xaml",
      "detail": "Post-repair: RetryInterval defaulted to \"00:00:05\" — verify this is appropriate for the workflow context",
      "severity": "warning"
    },
    {
      "check": "RETRY_INTERVAL_DEFAULTED",
      "file": "BGYY_ResolveRecipient.xaml",
      "detail": "Post-repair: RetryInterval defaulted to \"00:00:05\" — verify this is appropriate for the workflow context",
      "severity": "warning"
    },
    {
      "check": "RETRY_INTERVAL_DEFAULTED",
      "file": "BGYY_SendGmail.xaml",
      "detail": "Post-repair: RetryInterval defaulted to \"00:00:05\" — verify this is appropriate for the workflow context",
      "severity": "warning"
    },
    {
      "check": "RETRY_INTERVAL_DEFAULTED",
      "file": "BGYY_SendGmail.xaml",
      "detail": "Post-repair: RetryInterval defaulted to \"00:00:05\" — verify this is appropriate for the workflow context",
      "severity": "warning"
    },
    {
      "check": "RETRY_INTERVAL_DEFAULTED",
      "file": "BGYY_WriteDedupe.xaml",
      "detail": "Post-repair: RetryInterval defaulted to \"00:00:05\" — verify this is appropriate for the workflow context",
      "severity": "warning"
    },
    {
      "check": "RETRY_INTERVAL_DEFAULTED",
      "file": "BGYY_WriteDedupe.xaml",
      "detail": "Post-repair: RetryInterval defaulted to \"00:00:05\" — verify this is appropriate for the workflow context",
      "severity": "warning"
    }
  ],
  "totalEstimatedEffortMinutes": 895,
  "studioCompatibility": [
    {
      "file": "BGYY_GetTodaysBirthdays.xaml",
      "level": "studio-blocked",
      "blockers": [
        "[XML-WELLFORMEDNESS] XML well-formedness failure in tree assembler"
      ],
      "failureCategory": "xml-wellformedness",
      "failureSummary": "XML well-formedness failure in tree assembler"
    },
    {
      "file": "BGYY_ResolveRecipient.xaml",
      "level": "studio-blocked",
      "blockers": [
        "[CATALOG_STRUCTURAL_VIOLATION] Property \"To\" on Assign must be a child element, not an attribute",
        "[CATALOG_STRUCTURAL_VIOLATION] Property \"Value\" on Assign must be a child element, not an attribute"
      ]
    },
    {
      "file": "BGYY_CheckDedupe.xaml",
      "level": "studio-blocked",
      "blockers": [
        "[CATALOG_STRUCTURAL_VIOLATION] Property \"To\" on Assign must be a child element, not an attribute",
        "[CATALOG_STRUCTURAL_VIOLATION] Property \"Value\" on Assign must be a child element, not an attribute"
      ]
    },
    {
      "file": "BGYY_GenerateAndValidateDraft.xaml",
      "level": "studio-blocked",
      "blockers": [
        "[CATALOG_STRUCTURAL_VIOLATION] Property \"Path\" on ucas:ReadStorageText must be a child element, not an attribute",
        "[CATALOG_STRUCTURAL_VIOLATION] Property \"StorageBucketName\" on ucas:ReadStorageText must be a child element, not an attribute",
        "[CATALOG_STRUCTURAL_VIOLATION] Property \"To\" on Assign must be a child element, not an attribute",
        "[CATALOG_STRUCTURAL_VIOLATION] Property \"Value\" on Assign must be a child element, not an attribute",
        "[CATALOG_STRUCTURAL_VIOLATION] Property \"Input\" on ui:IsMatch must be a child element, not an attribute",
        "[CATALOG_STRUCTURAL_VIOLATION] Property \"Pattern\" on ui:IsMatch must be a child element, not an attribute"
      ]
    },
    {
      "file": "BGYY_SendGmail.xaml",
      "level": "studio-blocked",
      "blockers": [
        "[CATALOG_STRUCTURAL_VIOLATION] Property \"To\" on Assign must be a child element, not an attribute",
        "[CATALOG_STRUCTURAL_VIOLATION] Property \"Value\" on Assign must be a child element, not an attribute",
        "[CATALOG_STRUCTURAL_VIOLATION] Property \"Exception\" on Throw must be a child element, not an attribute",
        "[CATALOG_STRUCTURAL_VIOLATION] Property \"Destination\" on ucas:UploadStorageFile must be a child element, not an attribute",
        "[CATALOG_STRUCTURAL_VIOLATION] Property \"FileResource\" on ucas:UploadStorageFile must be a child element, not an attribute",
        "[CATALOG_STRUCTURAL_VIOLATION] Property \"Path\" on ucas:UploadStorageFile must be a child element, not an attribute",
        "[CATALOG_STRUCTURAL_VIOLATION] Property \"StorageBucketName\" on ucas:UploadStorageFile must be a child element, not an attribute"
      ]
    },
    {
      "file": "BGYY_WriteDedupe.xaml",
      "level": "studio-blocked",
      "blockers": [
        "[CATALOG_STRUCTURAL_VIOLATION] Property \"To\" on Assign must be a child element, not an attribute",
        "[CATALOG_STRUCTURAL_VIOLATION] Property \"Value\" on Assign must be a child element, not an attribute"
      ]
    },
    {
      "file": "BGYY_CreateReviewTask.xaml",
      "level": "studio-blocked",
      "blockers": [
        "[CATALOG_STRUCTURAL_VIOLATION] Property \"To\" on Assign must be a child element, not an attribute",
        "[CATALOG_STRUCTURAL_VIOLATION] Property \"Value\" on Assign must be a child element, not an attribute"
      ]
    },
    {
      "file": "BGYY_Main.xaml",
      "level": "studio-blocked",
      "blockers": [
        "[XML-WELLFORMEDNESS] XML well-formedness failure in tree assembler"
      ],
      "failureCategory": "xml-wellformedness",
      "failureSummary": "XML well-formedness failure in tree assembler"
    },
    {
      "file": "InitAllSettings.xaml",
      "level": "studio-blocked",
      "blockers": [
        "[CATALOG_STRUCTURAL_VIOLATION] Property \"ExistingWorkbook\" on uexcel:ExcelApplicationScope must be a child element, not an attribute",
        "[CATALOG_STRUCTURAL_VIOLATION] Property \"To\" on Assign must be a child element, not an attribute",
        "[CATALOG_STRUCTURAL_VIOLATION] Property \"Value\" on Assign must be a child element, not an attribute"
      ]
    },
    {
      "file": "Main.xaml",
      "level": "studio-blocked",
      "blockers": [
        "[CATALOG_STRUCTURAL_VIOLATION] Property \"To\" on Assign must be a child element, not an attribute",
        "[CATALOG_STRUCTURAL_VIOLATION] Property \"Value\" on Assign must be a child element, not an attribute"
      ]
    },
    {
      "file": "GetTransactionData.xaml",
      "level": "studio-blocked",
      "blockers": [
        "[CATALOG_STRUCTURAL_VIOLATION] Property \"To\" on Assign must be a child element, not an attribute",
        "[CATALOG_STRUCTURAL_VIOLATION] Property \"Value\" on Assign must be a child element, not an attribute"
      ]
    },
    {
      "file": "SetTransactionStatus.xaml",
      "level": "studio-clean",
      "blockers": []
    },
    {
      "file": "CloseAllApplications.xaml",
      "level": "studio-clean",
      "blockers": []
    },
    {
      "file": "KillAllProcesses.xaml",
      "level": "studio-clean",
      "blockers": []
    },
    {
      "file": "Init.xaml",
      "level": "studio-blocked",
      "blockers": [
        "[CATALOG_STRUCTURAL_VIOLATION] Property \"To\" on Assign must be a child element, not an attribute",
        "[CATALOG_STRUCTURAL_VIOLATION] Property \"Value\" on Assign must be a child element, not an attribute",
        "[CATALOG_STRUCTURAL_VIOLATION] Property \"Exception\" on Throw must be a child element, not an attribute"
      ]
    },
    {
      "file": "InitAllApplications.xaml",
      "level": "studio-warnings",
      "blockers": []
    },
    {
      "file": "RetryCurrentTransaction.xaml",
      "level": "studio-blocked",
      "blockers": [
        "[CATALOG_STRUCTURAL_VIOLATION] Property \"To\" on Assign must be a child element, not an attribute",
        "[CATALOG_STRUCTURAL_VIOLATION] Property \"Value\" on Assign must be a child element, not an attribute",
        "[UNDECLARED_ARGUMENT] Post-repair: Argument \"io_RetryNumber\" referenced but not declared in x:Members or Variables"
      ]
    },
    {
      "file": "RetryInit.xaml",
      "level": "studio-blocked",
      "blockers": [
        "[CATALOG_STRUCTURAL_VIOLATION] Property \"To\" on Assign must be a child element, not an attribute",
        "[CATALOG_STRUCTURAL_VIOLATION] Property \"Value\" on Assign must be a child element, not an attribute"
      ]
    },
    {
      "file": "Process.xaml",
      "level": "studio-clean",
      "blockers": []
    }
  ],
  "propertySerializationTrace": [
    {
      "workflowFile": "BGYY_GetTodaysBirthdays.xaml",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "originalRawValue": "\"[BGYY_GetTodaysBirthdays][Init] RunId=\" & InRunId & \" | TodayET=\" & InTodayDateEt.ToString(\"yyyy-MM-dd\") & \" | Starting Google Calendar query for 'Birthdays' calendar.\"",
      "parsedIntentType": "pre-assembly:literal",
      "normalizedOutput": "[\"[BGYY_GetTodaysBirthdays][Init] RunId=\"\" & InRunId & \"\" | TodayET=\"\" & InTodayDateEt.ToString(\"\"yyyy-MM-dd\"\") & \"\" | Starting Google Calendar query for 'Birthdays' calendar.\"]",
      "fallbackUsed": false,
      "finalValueHash": "88ffcaad4eb5876cf5e213833c634d8d7b6f1c20e121b2b7b9936b406cd8373c"
    },
    {
      "workflowFile": "BGYY_GetTodaysBirthdays.xaml",
      "activityType": "LogMessage",
      "propertyName": "Level",
      "originalRawValue": "Info",
      "parsedIntentType": "pre-assembly:literal",
      "normalizedOutput": "\"Info\"",
      "fallbackUsed": false,
      "finalValueHash": "6e68b62d2aa611a44f3e7a4cb7e23da9ad1cab1b6abb592bb2795b12fe63e51c"
    },
    {
      "workflowFile": "BGYY_GetTodaysBirthdays.xaml",
      "activityType": "LogMessage",
      "propertyName": "Level",
      "originalRawValue": "Error",
      "parsedIntentType": "pre-assembly:literal",
      "normalizedOutput": "\"Error\"",
      "fallbackUsed": false,
      "finalValueHash": "fc4ac19649f0ee8f37c71d2e2030a3743038bb96c0c27359ba115dd8657565cc"
    },
    {
      "workflowFile": "BGYY_GetTodaysBirthdays.xaml",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "originalRawValue": "\"Error in Compute UTC window start (midnight ET converted to UTC): \" & exception.Message",
      "parsedIntentType": "pre-assembly:literal",
      "normalizedOutput": "[\"\"\"Error in Compute UTC window start (midnight ET converted to UTC): \"\" & exception.Message\"]",
      "fallbackUsed": false,
      "finalValueHash": "090fe77c7acb412b1e7144b24632589806376d839ef54318ab2e25c3728b6235"
    },
    {
      "workflowFile": "BGYY_GetTodaysBirthdays.xaml",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "originalRawValue": "\"[BGYY_GetTodaysBirthdays][Info] UTC query window: Start=\" & calendarQueryStartUtc.ToString(\"o\") & \" End=\" & calendarQueryEndUtc.ToString(\"o\")",
      "parsedIntentType": "pre-assembly:literal",
      "normalizedOutput": "[\"\"\"[BGYY_GetTodaysBirthdays][Info] UTC query window: Start=\"\" & calendarQueryStartUtc.ToString(\"\"o\"\") & \"\" End=\"\" & calendarQueryEndUtc.ToString(\"\"o\"\")\"]",
      "fallbackUsed": false,
      "finalValueHash": "b926462bc3f89ece16fc089d68039bdab00284138d82336346e459aa944ae310"
    },
    {
      "workflowFile": "BGYY_GetTodaysBirthdays.xaml",
      "activityType": "LogMessage",
      "propertyName": "Level",
      "originalRawValue": "Info",
      "parsedIntentType": "pre-assembly:literal",
      "normalizedOutput": "\"Info\"",
      "fallbackUsed": false,
      "finalValueHash": "6e68b62d2aa611a44f3e7a4cb7e23da9ad1cab1b6abb592bb2795b12fe63e51c"
    },
    {
      "workflowFile": "BGYY_GetTodaysBirthdays.xaml",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "originalRawValue": "\"[BGYY_GetTodaysBirthdays][Info] Attempt \" & retryAttempt.ToString() & \" of 3: Calling Google Calendar connector for 'Birthdays' calendar. BackoffDelay=\" & retryDelaySeconds.ToString() & \"s\"",
      "parsedIntentType": "pre-assembly:literal",
      "normalizedOutput": "[\"[BGYY_GetTodaysBirthdays][Info] Attempt \"\" & retryAttempt.ToString() & \"\" of 3: Calling Google Calendar connector for 'Birthdays' calendar. BackoffDelay=\"\" & retryDelaySeconds.ToString() & \"\"s\"]",
      "fallbackUsed": false,
      "finalValueHash": "7dc069e2bb5f2ef6df120df81f707b81fcbb85adf82a4f58d2fb6247a8cf6cee"
    },
    {
      "workflowFile": "BGYY_GetTodaysBirthdays.xaml",
      "activityType": "LogMessage",
      "propertyName": "Level",
      "originalRawValue": "Info",
      "parsedIntentType": "pre-assembly:literal",
      "normalizedOutput": "\"Info\"",
      "fallbackUsed": false,
      "finalValueHash": "6e68b62d2aa611a44f3e7a4cb7e23da9ad1cab1b6abb592bb2795b12fe63e51c"
    },
    {
      "workflowFile": "BGYY_GetTodaysBirthdays.xaml",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "originalRawValue": "\"[BGYY_GetTodaysBirthdays][Fatal] Google Calendar connector returned null response after 3 attempts. RunId=\" & InRunId & \" | TodayET=\" & InTodayDateEt.ToString(\"yyyy-MM-dd\") & \" | Cannot proceed without calendar data.\"",
      "parsedIntentType": "pre-assembly:literal",
      "normalizedOutput": "[\"[BGYY_GetTodaysBirthdays][Fatal] Google Calendar connector returned null response after 3 attempts. RunId=\"\" & InRunId & \"\" | TodayET=\"\" & InTodayDateEt.ToString(\"\"yyyy-MM-dd\"\") & \"\" | Cannot proceed without calendar data.\"]",
      "fallbackUsed": false,
      "finalValueHash": "150f79feeba1bf3144ed0dec75a2c22ffe6a46c2aa6f5ad00a6fdeedbaee1617"
    },
    {
      "workflowFile": "BGYY_GetTodaysBirthdays.xaml",
      "activityType": "LogMessage",
      "propertyName": "Level",
      "originalRawValue": "Fatal",
      "parsedIntentType": "pre-assembly:literal",
      "normalizedOutput": "\"Fatal\"",
      "fallbackUsed": false,
      "finalValueHash": "eeee665e2b5997986f0d50f3a55995c13f360878c1c181fee98ae6ceabd3a615"
    },
    {
      "workflowFile": "BGYY_GetTodaysBirthdays.xaml",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "originalRawValue": "\"[BGYY_GetTodaysBirthdays][Info] Google Calendar connector responded successfully on attempt \" & retryAttempt.ToString() & \". RunId=\" & InRunId",
      "parsedIntentType": "pre-assembly:literal",
      "normalizedOutput": "[\"\"\"[BGYY_GetTodaysBirthdays][Info] Google Calendar connector responded successfully on attempt \"\" & retryAttempt.ToString() & \"\". RunId=\"\" & InRunId\"]",
      "fallbackUsed": false,
      "finalValueHash": "74664a0a5bff2bbf382fb7b7cda5cdf8895bf93205e241ddad3a9b93f0484e3c"
    },
    {
      "workflowFile": "BGYY_GetTodaysBirthdays.xaml",
      "activityType": "LogMessage",
      "propertyName": "Level",
      "originalRawValue": "Info",
      "parsedIntentType": "pre-assembly:literal",
      "normalizedOutput": "\"Info\"",
      "fallbackUsed": false,
      "finalValueHash": "6e68b62d2aa611a44f3e7a4cb7e23da9ad1cab1b6abb592bb2795b12fe63e51c"
    },
    {
      "workflowFile": "BGYY_GetTodaysBirthdays.xaml",
      "activityType": "LogMessage",
      "propertyName": "Level",
      "originalRawValue": "Error",
      "parsedIntentType": "pre-assembly:literal",
      "normalizedOutput": "\"Error\"",
      "fallbackUsed": false,
      "finalValueHash": "fc4ac19649f0ee8f37c71d2e2030a3743038bb96c0c27359ba115dd8657565cc"
    },
    {
      "workflowFile": "BGYY_GetTodaysBirthdays.xaml",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "originalRawValue": "\"Error in Extract EventId from current calendar event object: \" & exception.Message",
      "parsedIntentType": "pre-assembly:literal",
      "normalizedOutput": "[\"\"\"Error in Extract EventId from current calendar event object: \"\" & exception.Message\"]",
      "fallbackUsed": false,
      "finalValueHash": "45e63b6dfbdacab255d591d0a701ab36e593eb15fba78ffc9ae982d255cad2ff"
    },
    {
      "workflowFile": "BGYY_GetTodaysBirthdays.xaml",
      "activityType": "LogMessage",
      "propertyName": "Level",
      "originalRawValue": "Error",
      "parsedIntentType": "pre-assembly:literal",
      "normalizedOutput": "\"Error\"",
      "fallbackUsed": false,
      "finalValueHash": "fc4ac19649f0ee8f37c71d2e2030a3743038bb96c0c27359ba115dd8657565cc"
    },
    {
      "workflowFile": "BGYY_GetTodaysBirthdays.xaml",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "originalRawValue": "\"Error in Extract event summary (full name) from current calendar event object: \" & exception.Message",
      "parsedIntentType": "pre-assembly:literal",
      "normalizedOutput": "[\"\"\"Error in Extract event summary (full name) from current calendar event object: \"\" & exception.Message\"]",
      "fallbackUsed": false,
      "finalValueHash": "4bd41d57bfed00a91d954ce2222fa1febd12384d90e6031ed6a2f0adb774c76b"
    },
    {
      "workflowFile": "BGYY_GetTodaysBirthdays.xaml",
      "activityType": "LogMessage",
      "propertyName": "Level",
      "originalRawValue": "Error",
      "parsedIntentType": "pre-assembly:literal",
      "normalizedOutput": "\"Error\"",
      "fallbackUsed": false,
      "finalValueHash": "fc4ac19649f0ee8f37c71d2e2030a3743038bb96c0c27359ba115dd8657565cc"
    },
    {
      "workflowFile": "BGYY_GetTodaysBirthdays.xaml",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "originalRawValue": "\"Error in Extract occurrence start date/time string from current calendar event object: \" & exception.Message",
      "parsedIntentType": "pre-assembly:literal",
      "normalizedOutput": "[\"\"\"Error in Extract occurrence start date/time string from current calendar event object: \"\" & exception.Message\"]",
      "fallbackUsed": false,
      "finalValueHash": "b0c73e526ae026f074d11bb2e05e755c5bf7ce592a23bec5ecd322736fcf554d"
    },
    {
      "workflowFile": "BGYY_GetTodaysBirthdays.xaml",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "originalRawValue": "\"[BGYY_GetTodaysBirthdays][Warn] Skipping calendar event with empty summary or ID. EventId='\" & eventId & \"' FullName='\" & eventFullName & \"' RunId=\" & InRunId",
      "parsedIntentType": "pre-assembly:literal",
      "normalizedOutput": "[\"\"\"[BGYY_GetTodaysBirthdays][Warn] Skipping calendar event with empty summary or ID. EventId='\"\" & eventId & \"\"' FullName='\"\" & eventFullName & \"\"' RunId=\"\" & InRunId\"]",
      "fallbackUsed": false,
      "finalValueHash": "cc2caa2fccf36d36e3124ef5d65b16a51ff1f9682581001779af0444a36b33dd"
    },
    {
      "workflowFile": "BGYY_GetTodaysBirthdays.xaml",
      "activityType": "LogMessage",
      "propertyName": "Level",
      "originalRawValue": "Warn",
      "parsedIntentType": "pre-assembly:literal",
      "normalizedOutput": "\"Warn\"",
      "fallbackUsed": false,
      "finalValueHash": "0817e2b865151b33aa686f0551fce818a034cb723e0044e433cd8100810ed280"
    },
    {
      "workflowFile": "BGYY_GetTodaysBirthdays.xaml",
      "activityType": "LogMessage",
      "propertyName": "Level",
      "originalRawValue": "Error",
      "parsedIntentType": "pre-assembly:literal",
      "normalizedOutput": "\"Error\"",
      "fallbackUsed": false,
      "finalValueHash": "fc4ac19649f0ee8f37c71d2e2030a3743038bb96c0c27359ba115dd8657565cc"
    },
    {
      "workflowFile": "BGYY_GetTodaysBirthdays.xaml",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "originalRawValue": "\"Error in Parse occurrence start string into DateTime (handle both date-only and datetime formats): \" & exception.Message",
      "parsedIntentType": "pre-assembly:literal",
      "normalizedOutput": "[\"\"\"Error in Parse occurrence start string into DateTime (handle both date-only and datetime formats): \"\" & exception.Message\"]",
      "fallbackUsed": false,
      "finalValueHash": "ef08cbf350ea05e11b4a9f83ecab79fbe7641d93ccdcf6191b284d7b8f16e22a"
    },
    {
      "workflowFile": "BGYY_GetTodaysBirthdays.xaml",
      "activityType": "LogMessage",
      "propertyName": "Level",
      "originalRawValue": "Error",
      "parsedIntentType": "pre-assembly:literal",
      "normalizedOutput": "\"Error\"",
      "fallbackUsed": false,
      "finalValueHash": "fc4ac19649f0ee8f37c71d2e2030a3743038bb96c0c27359ba115dd8657565cc"
    },
    {
      "workflowFile": "BGYY_GetTodaysBirthdays.xaml",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "originalRawValue": "\"Error in Add normalized birthday record row to output DataTable: \" & exception.Message",
      "parsedIntentType": "pre-assembly:literal",
      "normalizedOutput": "[\"\"\"Error in Add normalized birthday record row to output DataTable: \"\" & exception.Message\"]",
      "fallbackUsed": false,
      "finalValueHash": "9738c3085bbcfa6a7cd95c1684d062be7857d82d43efeb229ef4440141689de8"
    },
    {
      "workflowFile": "BGYY_GetTodaysBirthdays.xaml",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "originalRawValue": "\"[BGYY_GetTodaysBirthdays][Info] Birthday event normalized and added. FullName='\" & normalizedFullName & \"' EventId='\" & eventId & \"' OccurrenceStart=\" & eventStartParsed.ToString(\"yyyy-MM-ddTHH:mm:ssK\") & \" RunId=\" & InRunId",
      "parsedIntentType": "pre-assembly:literal",
      "normalizedOutput": "[\"\"\"[BGYY_GetTodaysBirthdays][Info] Birthday event normalized and added. FullName='\"\" & normalizedFullName & \"\"' EventId='\"\" & eventId & \"\"' OccurrenceStart=\"\" & eventStartParsed.ToString(\"\"yyyy-MM-ddTHH:mm:ssK\"\") & \"\" RunId=\"\" & InRunId\"]",
      "fallbackUsed": false,
      "finalValueHash": "33b6b6a5f67c299f0c79affac0e631f3d467d0043557c7b7b0e02a420200d9e0"
    },
    {
      "workflowFile": "BGYY_GetTodaysBirthdays.xaml",
      "activityType": "LogMessage",
      "propertyName": "Level",
      "originalRawValue": "Info",
      "parsedIntentType": "pre-assembly:literal",
      "normalizedOutput": "\"Info\"",
      "fallbackUsed": false,
      "finalValueHash": "6e68b62d2aa611a44f3e7a4cb7e23da9ad1cab1b6abb592bb2795b12fe63e51c"
    },
    {
      "workflowFile": "BGYY_GetTodaysBirthdays.xaml",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "originalRawValue": "\"[BGYY_GetTodaysBirthdays][Info] Completed calendar query. TotalBirthdayEventsFound=\" & eventCount.ToString() & \" | TodayET=\" & InTodayDateEt.ToString(\"yyyy-MM-dd\") & \" | RunId=\" & InRunId",
      "parsedIntentType": "pre-assembly:literal",
      "normalizedOutput": "[\"\"\"[BGYY_GetTodaysBirthdays][Info] Completed calendar query. TotalBirthdayEventsFound=\"\" & eventCount.ToString() & \"\" | TodayET=\"\" & InTodayDateEt.ToString(\"\"yyyy-MM-dd\"\") & \"\" | RunId=\"\" & InRunId\"]",
      "fallbackUsed": false,
      "finalValueHash": "55f3301fd7d8fb2767040b6b1352763f3695ec1049b1986104346346c208115e"
    },
    {
      "workflowFile": "BGYY_GetTodaysBirthdays.xaml",
      "activityType": "LogMessage",
      "propertyName": "Level",
      "originalRawValue": "Info",
      "parsedIntentType": "pre-assembly:literal",
      "normalizedOutput": "\"Info\"",
      "fallbackUsed": false,
      "finalValueHash": "6e68b62d2aa611a44f3e7a4cb7e23da9ad1cab1b6abb592bb2795b12fe63e51c"
    },
    {
      "workflowFile": "unknown",
      "activityType": "ConnectorActivity",
      "propertyName": "ConnectionId",
      "originalRawValue": "{\"type\":\"literal\",\"value\":\"GoogleCalendarConnectionId\"}",
      "parsedIntentType": "literal",
      "normalizedOutput": "\"GoogleCalendarConnectionId\"",
      "fallbackUsed": false,
      "finalValueHash": "55c6c7db60dca59d36f2a90b89f529a06397f61dd79b9ae0861e381012fe9fdf"
    },
    {
      "workflowFile": "BGYY_ResolveRecipient.xaml",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "originalRawValue": "\"[BGYY_ResolveRecipient][Init] RunId=\" & InRunId & \" | Resolving contact for FullName='\" & InFullName & \"'\"",
      "parsedIntentType": "pre-assembly:literal",
      "normalizedOutput": "[\"[BGYY_ResolveRecipient][Init] RunId=\"\" & InRunId & \"\" | Resolving contact for FullName='\"\" & InFullName & \"\"'\"]",
      "fallbackUsed": false,
      "finalValueHash": "d2048503dd5c1603c8c338508aef0c052476a32d0ae53f3ddd61a603683699f3"
    },
    {
      "workflowFile": "BGYY_ResolveRecipient.xaml",
      "activityType": "LogMessage",
      "propertyName": "Level",
      "originalRawValue": "Info",
      "parsedIntentType": "pre-assembly:literal",
      "normalizedOutput": "\"Info\"",
      "fallbackUsed": false,
      "finalValueHash": "6e68b62d2aa611a44f3e7a4cb7e23da9ad1cab1b6abb592bb2795b12fe63e51c"
    },
    {
      "workflowFile": "BGYY_ResolveRecipient.xaml",
      "activityType": "LogMessage",
      "propertyName": "Level",
      "originalRawValue": "Error",
      "parsedIntentType": "pre-assembly:literal",
      "normalizedOutput": "\"Error\"",
      "fallbackUsed": false,
      "finalValueHash": "fc4ac19649f0ee8f37c71d2e2030a3743038bb96c0c27359ba115dd8657565cc"
    },
    {
      "workflowFile": "BGYY_ResolveRecipient.xaml",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "originalRawValue": "\"Error in Search Google Contacts for matching contact by display name: \" & exception.Message",
      "parsedIntentType": "pre-assembly:literal",
      "normalizedOutput": "[\"\"\"Error in Search Google Contacts for matching contact by display name: \"\" & exception.Message\"]",
      "fallbackUsed": false,
      "finalValueHash": "3144d3f83ffdb29276ffc7845a7f4913ff9bf5ceac69308c753ba4254588178c"
    },
    {
      "workflowFile": "BGYY_ResolveRecipient.xaml",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "originalRawValue": "\"[BGYY_ResolveRecipient][Decision] RunId=\" & InRunId & \" | No Google Contacts result for '\" & InFullName & \"' — will SkippedNoEmail\"",
      "parsedIntentType": "pre-assembly:literal",
      "normalizedOutput": "[\"[BGYY_ResolveRecipient][Decision] RunId=\"\" & InRunId & \"\" | No Google Contacts result for '\"\" & InFullName & \"\"' — will SkippedNoEmail\"]",
      "fallbackUsed": false,
      "finalValueHash": "2f6d8b8f41f07e8e2ca8e89d81c626a9df252a3f7965f8c359aab96ba30d4450"
    },
    {
      "workflowFile": "BGYY_ResolveRecipient.xaml",
      "activityType": "LogMessage",
      "propertyName": "Level",
      "originalRawValue": "Warn",
      "parsedIntentType": "pre-assembly:literal",
      "normalizedOutput": "\"Warn\"",
      "fallbackUsed": false,
      "finalValueHash": "0817e2b865151b33aa686f0551fce818a034cb723e0044e433cd8100810ed280"
    },
    {
      "workflowFile": "BGYY_ResolveRecipient.xaml",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "originalRawValue": "\"[BGYY_ResolveRecipient][Decision] RunId=\" & InRunId & \" | AMBIGUOUS: \" & contactResultCount.ToString() & \" contacts found for '\" & InFullName & \"' — flagging OutIsAmbiguous=True for Action Center review\"",
      "parsedIntentType": "pre-assembly:literal",
      "normalizedOutput": "[\"[BGYY_ResolveRecipient][Decision] RunId=\"\" & InRunId & \"\" | AMBIGUOUS: \"\" & contactResultCount.ToString() & \"\" contacts found for '\"\" & InFullName & \"\"' — flagging OutIsAmbiguous=True for Action Center review\"]",
      "fallbackUsed": false,
      "finalValueHash": "80da7f9a7b57a4e66cda8825363c15c24818f072de70eab9155845a048e017e6"
    },
    {
      "workflowFile": "BGYY_ResolveRecipient.xaml",
      "activityType": "LogMessage",
      "propertyName": "Level",
      "originalRawValue": "Warn",
      "parsedIntentType": "pre-assembly:literal",
      "normalizedOutput": "\"Warn\"",
      "fallbackUsed": false,
      "finalValueHash": "0817e2b865151b33aa686f0551fce818a034cb723e0044e433cd8100810ed280"
    },
    {
      "workflowFile": "BGYY_ResolveRecipient.xaml",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "originalRawValue": "\"[BGYY_ResolveRecipient][Info] RunId=\" & InRunId & \" | Single contact matched for '\" & InFullName & \"', ContactId='\" & resolvedContactId & \"' — extracting labeled emails\"",
      "parsedIntentType": "pre-assembly:literal",
      "normalizedOutput": "[\"[BGYY_ResolveRecipient][Info] RunId=\"\" & InRunId & \"\" | Single contact matched for '\"\" & InFullName & \"\"', ContactId='\"\" & resolvedContactId & \"\"' — extracting labeled emails\"]",
      "fallbackUsed": false,
      "finalValueHash": "18c76e4f581f4ae7dbbac3a3d9dfcc1972ac34642438e4b0ff09de98219110e4"
    },
    {
      "workflowFile": "BGYY_ResolveRecipient.xaml",
      "activityType": "LogMessage",
      "propertyName": "Level",
      "originalRawValue": "Info",
      "parsedIntentType": "pre-assembly:literal",
      "normalizedOutput": "\"Info\"",
      "fallbackUsed": false,
      "finalValueHash": "6e68b62d2aa611a44f3e7a4cb7e23da9ad1cab1b6abb592bb2795b12fe63e51c"
    },
    {
      "workflowFile": "BGYY_ResolveRecipient.xaml",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "originalRawValue": "\"[BGYY_ResolveRecipient][Decision] RunId=\" & InRunId & \" | No 'personal' email label for '\" & InFullName & \"' — using 'home' email as fallback\"",
      "parsedIntentType": "pre-assembly:literal",
      "normalizedOutput": "[\"[BGYY_ResolveRecipient][Decision] RunId=\"\" & InRunId & \"\" | No 'personal' email label for '\"\" & InFullName & \"\"' — using 'home' email as fallback\"]",
      "fallbackUsed": false,
      "finalValueHash": "cafd88b99b69246d0868261225b064a913dd8e3a6e6391169e394c5cd9b6ad12"
    },
    {
      "workflowFile": "BGYY_ResolveRecipient.xaml",
      "activityType": "LogMessage",
      "propertyName": "Level",
      "originalRawValue": "Warn",
      "parsedIntentType": "pre-assembly:literal",
      "normalizedOutput": "\"Warn\"",
      "fallbackUsed": false,
      "finalValueHash": "0817e2b865151b33aa686f0551fce818a034cb723e0044e433cd8100810ed280"
    },
    {
      "workflowFile": "BGYY_ResolveRecipient.xaml",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "originalRawValue": "\"[BGYY_ResolveRecipient][Decision] RunId=\" & InRunId & \" | No 'personal' or 'home' email label found for '\" & InFullName & \"', ContactId='\" & resolvedContactId & \"' — OutSelectedEmail=Nothing (SkippedNoEmail)\"",
      "parsedIntentType": "pre-assembly:literal",
      "normalizedOutput": "[\"[BGYY_ResolveRecipient][Decision] RunId=\"\" & InRunId & \"\" | No 'personal' or 'home' email label found for '\"\" & InFullName & \"\"', ContactId='\"\" & resolvedContactId & \"\"' — OutSelectedEmail=Nothing (SkippedNoEmail)\"]",
      "fallbackUsed": false,
      "finalValueHash": "3365ee22f99fec09a206a1097a4b609b949a9315d3020595785313f8b5b765aa"
    },
    {
      "workflowFile": "BGYY_ResolveRecipient.xaml",
      "activityType": "LogMessage",
      "propertyName": "Level",
      "originalRawValue": "Warn",
      "parsedIntentType": "pre-assembly:literal",
      "normalizedOutput": "\"Warn\"",
      "fallbackUsed": false,
      "finalValueHash": "0817e2b865151b33aa686f0551fce818a034cb723e0044e433cd8100810ed280"
    },
    {
      "workflowFile": "BGYY_ResolveRecipient.xaml",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "originalRawValue": "\"[BGYY_ResolveRecipient][Success] RunId=\" & InRunId & \" | Resolved email for '\" & InFullName & \"': ContactId='\" & resolvedContactId & \"' — email selected (label: \" & If(personalEmail <> \"\", \"personal\", \"home\") & \")\"",
      "parsedIntentType": "pre-assembly:literal",
      "normalizedOutput": "[\"[BGYY_ResolveRecipient][Success] RunId=\"\" & InRunId & \"\" | Resolved email for '\"\" & InFullName & \"\"': ContactId='\"\" & resolvedContactId & \"\"' — email selected (label: \"\" & If(personalEmail <> \"\", \"\"personal\"\", \"\"home\"\") & \"\")\"]",
      "fallbackUsed": false,
      "finalValueHash": "bb6c20ca39515ebcc254631de74e7c17f201d64ba2d801d06ab3e4000982e88f"
    },
    {
      "workflowFile": "BGYY_ResolveRecipient.xaml",
      "activityType": "LogMessage",
      "propertyName": "Level",
      "originalRawValue": "Info",
      "parsedIntentType": "pre-assembly:literal",
      "normalizedOutput": "\"Info\"",
      "fallbackUsed": false,
      "finalValueHash": "6e68b62d2aa611a44f3e7a4cb7e23da9ad1cab1b6abb592bb2795b12fe63e51c"
    },
    {
      "workflowFile": "BGYY_ResolveRecipient.xaml",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "originalRawValue": "\"[BGYY_ResolveRecipient][Exit] RunId=\" & InRunId & \" | FullName='\" & InFullName & \"' | OutIsAmbiguous=\" & OutIsAmbiguous.ToString() & \" | EmailResolved=\" & (OutSelectedEmail IsNot Nothing AndAlso OutSelectedEmail <> \"\").ToString()",
      "parsedIntentType": "pre-assembly:literal",
      "normalizedOutput": "[\"\"\"[BGYY_ResolveRecipient][Exit] RunId=\"\" & InRunId & \"\" | FullName='\"\" & InFullName & \"\"' | OutIsAmbiguous=\"\" & OutIsAmbiguous.ToString() & \"\" | EmailResolved=\"\" & (OutSelectedEmail IsNot Nothing AndAlso OutSelectedEmail <> \"\"\"\").ToString()\"]",
      "fallbackUsed": false,
      "finalValueHash": "741d084553bbdd78909e1f12505422b7a5e628ad2f4f8d0ae8ddb7f6b4fdb6a3"
    },
    {
      "workflowFile": "BGYY_ResolveRecipient.xaml",
      "activityType": "LogMessage",
      "propertyName": "Level",
      "originalRawValue": "Info",
      "parsedIntentType": "pre-assembly:literal",
      "normalizedOutput": "\"Info\"",
      "fallbackUsed": false,
      "finalValueHash": "6e68b62d2aa611a44f3e7a4cb7e23da9ad1cab1b6abb592bb2795b12fe63e51c"
    },
    {
      "workflowFile": "unknown",
      "activityType": "GoogleContactsSearchContacts",
      "propertyName": "Query",
      "originalRawValue": "{\"type\":\"variable\",\"name\":\"InFullName\"}",
      "parsedIntentType": "variable",
      "normalizedOutput": "[InFullName]",
      "fallbackUsed": false,
      "finalValueHash": "c714685f3545fdb48b129401b9663aee50be9f2f1594fceae2d80056827f8fde"
    },
    {
      "workflowFile": "unknown",
      "activityType": "GoogleContactsGetContact",
      "propertyName": "ResourceName",
      "originalRawValue": "{\"type\":\"variable\",\"name\":\"resolvedContactId\"}",
      "parsedIntentType": "variable",
      "normalizedOutput": "[resolvedContactId]",
      "fallbackUsed": false,
      "finalValueHash": "4ae0e4d37df83fa0949cb247a98abe8f831a83a03b2c9758487fb1bfcf139ed6"
    },
    {
      "workflowFile": "BGYY_CheckDedupe.xaml",
      "activityType": "LogMessage",
      "propertyName": "Level",
      "originalRawValue": "Info",
      "parsedIntentType": "pre-assembly:literal",
      "normalizedOutput": "\"Info\"",
      "fallbackUsed": false,
      "finalValueHash": "6e68b62d2aa611a44f3e7a4cb7e23da9ad1cab1b6abb592bb2795b12fe63e51c"
    },
    {
      "workflowFile": "BGYY_CheckDedupe.xaml",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "originalRawValue": "\"[BGYY_CheckDedupe] Starting dedupe check — PersonKey='\" & InPersonKey & \"', SendYear=\" & InSendYear.ToString()",
      "parsedIntentType": "pre-assembly:literal",
      "normalizedOutput": "[\"\"\"[BGYY_CheckDedupe] Starting dedupe check — PersonKey='\"\" & InPersonKey & \"\"', SendYear=\"\" & InSendYear.ToString()\"]",
      "fallbackUsed": false,
      "finalValueHash": "be23fcf8a556393b4c65e129f71c7de378fc83e1787e715d90633fe0aabe18b1"
    },
    {
      "workflowFile": "BGYY_CheckDedupe.xaml",
      "activityType": "LogMessage",
      "propertyName": "Level",
      "originalRawValue": "Warn",
      "parsedIntentType": "pre-assembly:literal",
      "normalizedOutput": "\"Warn\"",
      "fallbackUsed": false,
      "finalValueHash": "0817e2b865151b33aa686f0551fce818a034cb723e0044e433cd8100810ed280"
    },
    {
      "workflowFile": "BGYY_CheckDedupe.xaml",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "originalRawValue": "[BGYY_CheckDedupe] PersonKey argument is null or empty. Cannot perform dedupe query. Returning OutAlreadySent=False to allow caller to decide handling.",
      "parsedIntentType": "pre-assembly:literal",
      "normalizedOutput": "\"[BGYY_CheckDedupe] PersonKey argument is null or empty. Cannot perform dedupe query. Returning OutAlreadySent=False to allow caller to decide handling.\"",
      "fallbackUsed": false,
      "finalValueHash": "9b45dc38d901867b722fab8ef689c115bdc0acd8ad8153efbf38961bc0eb8bed"
    },
    {
      "workflowFile": "BGYY_CheckDedupe.xaml",
      "activityType": "LogMessage",
      "propertyName": "Level",
      "originalRawValue": "Info",
      "parsedIntentType": "pre-assembly:literal",
      "normalizedOutput": "\"Info\"",
      "fallbackUsed": false,
      "finalValueHash": "6e68b62d2aa611a44f3e7a4cb7e23da9ad1cab1b6abb592bb2795b12fe63e51c"
    },
    {
      "workflowFile": "BGYY_CheckDedupe.xaml",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "originalRawValue": "\"[BGYY_CheckDedupe] Querying BGYY_BirthdaySendLog — filter: \" & str_FilterExpression",
      "parsedIntentType": "pre-assembly:literal",
      "normalizedOutput": "[\"\"\"[BGYY_CheckDedupe] Querying BGYY_BirthdaySendLog — filter: \"\" & str_FilterExpression\"]",
      "fallbackUsed": false,
      "finalValueHash": "0fd600db74ac6ae6175d1c918420582bc1ae52f13ada6acf06249a5ebc45aef3"
    },
    {
      "workflowFile": "BGYY_CheckDedupe.xaml",
      "activityType": "QueryEntity",
      "propertyName": "EntityType",
      "originalRawValue": "BGYY_BirthdaySendLog",
      "parsedIntentType": "pre-assembly:literal",
      "normalizedOutput": "\"BGYY_BirthdaySendLog\"",
      "fallbackUsed": false,
      "finalValueHash": "b004731817a34b4b0811c2cd720f3a3479712719e123cd47f1a76b71faf3049f"
    },
    {
      "workflowFile": "BGYY_CheckDedupe.xaml",
      "activityType": "LogMessage",
      "propertyName": "Level",
      "originalRawValue": "Error",
      "parsedIntentType": "pre-assembly:literal",
      "normalizedOutput": "\"Error\"",
      "fallbackUsed": false,
      "finalValueHash": "fc4ac19649f0ee8f37c71d2e2030a3743038bb96c0c27359ba115dd8657565cc"
    },
    {
      "workflowFile": "BGYY_CheckDedupe.xaml",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "originalRawValue": "\"[BGYY_CheckDedupe] Data Service QueryEntity failed for PersonKey='\" & InPersonKey & \"', SendYear=\" & InSendYear.ToString() & \". Exception: \" & ex_DedupeQuery.Message",
      "parsedIntentType": "pre-assembly:literal",
      "normalizedOutput": "[\"\"\"[BGYY_CheckDedupe] Data Service QueryEntity failed for PersonKey='\"\" & InPersonKey & \"\"', SendYear=\"\" & InSendYear.ToString() & \"\". Exception: \"\" & ex_DedupeQuery.Message\"]",
      "fallbackUsed": false,
      "finalValueHash": "ee413d21a6f89ee0b98e55c4c9362261cc0fee5dc558a2cf1eea6f26d6ae6ea0"
    },
    {
      "workflowFile": "BGYY_CheckDedupe.xaml",
      "activityType": "LogMessage",
      "propertyName": "Level",
      "originalRawValue": "Info",
      "parsedIntentType": "pre-assembly:literal",
      "normalizedOutput": "\"Info\"",
      "fallbackUsed": false,
      "finalValueHash": "6e68b62d2aa611a44f3e7a4cb7e23da9ad1cab1b6abb592bb2795b12fe63e51c"
    },
    {
      "workflowFile": "BGYY_CheckDedupe.xaml",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "originalRawValue": "\"[BGYY_CheckDedupe] Dedupe record FOUND for PersonKey='\" & InPersonKey & \"', SendYear=\" & InSendYear.ToString() & \". OutAlreadySent=True. Email will be skipped.\"",
      "parsedIntentType": "pre-assembly:literal",
      "normalizedOutput": "[\"[BGYY_CheckDedupe] Dedupe record FOUND for PersonKey='\"\" & InPersonKey & \"\"', SendYear=\"\" & InSendYear.ToString() & \"\". OutAlreadySent=True. Email will be skipped.\"]",
      "fallbackUsed": false,
      "finalValueHash": "61b141dc591dd812d6b5b529281f4276e975253c5029e0e96c982d758435800d"
    },
    {
      "workflowFile": "BGYY_CheckDedupe.xaml",
      "activityType": "LogMessage",
      "propertyName": "Level",
      "originalRawValue": "Info",
      "parsedIntentType": "pre-assembly:literal",
      "normalizedOutput": "\"Info\"",
      "fallbackUsed": false,
      "finalValueHash": "6e68b62d2aa611a44f3e7a4cb7e23da9ad1cab1b6abb592bb2795b12fe63e51c"
    },
    {
      "workflowFile": "BGYY_CheckDedupe.xaml",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "originalRawValue": "\"[BGYY_CheckDedupe] No dedupe record found for PersonKey='\" & InPersonKey & \"', SendYear=\" & InSendYear.ToString() & \". OutAlreadySent=False. Proceeding to draft and send.\"",
      "parsedIntentType": "pre-assembly:literal",
      "normalizedOutput": "[\"[BGYY_CheckDedupe] No dedupe record found for PersonKey='\"\" & InPersonKey & \"\"', SendYear=\"\" & InSendYear.ToString() & \"\". OutAlreadySent=False. Proceeding to draft and send.\"]",
      "fallbackUsed": false,
      "finalValueHash": "f327012c666ae6818b91aecdbe84319fee5855ea12b4a3a700eff47638dec953"
    },
    {
      "workflowFile": "BGYY_CheckDedupe.xaml",
      "activityType": "LogMessage",
      "propertyName": "Level",
      "originalRawValue": "Info",
      "parsedIntentType": "pre-assembly:literal",
      "normalizedOutput": "\"Info\"",
      "fallbackUsed": false,
      "finalValueHash": "6e68b62d2aa611a44f3e7a4cb7e23da9ad1cab1b6abb592bb2795b12fe63e51c"
    },
    {
      "workflowFile": "BGYY_CheckDedupe.xaml",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "originalRawValue": "\"[BGYY_CheckDedupe] Completed — PersonKey='\" & InPersonKey & \"', SendYear=\" & InSendYear.ToString() & \", OutAlreadySent=\" & OutAlreadySent.ToString()",
      "parsedIntentType": "pre-assembly:literal",
      "normalizedOutput": "[\"\"\"[BGYY_CheckDedupe] Completed — PersonKey='\"\" & InPersonKey & \"\"', SendYear=\"\" & InSendYear.ToString() & \"\", OutAlreadySent=\"\" & OutAlreadySent.ToString()\"]",
      "fallbackUsed": false,
      "finalValueHash": "bbed8de48a554b01739f4021d225b33dbd4e90057addca09f46d4781f253e962"
    },
    {
      "workflowFile": "unknown",
      "activityType": "QueryEntity",
      "propertyName": "EntityType",
      "originalRawValue": "{\"type\":\"literal\",\"value\":\"BGYY_BirthdaySendLog\"}",
      "parsedIntentType": "literal",
      "normalizedOutput": "\"BGYY_BirthdaySendLog\"",
      "fallbackUsed": false,
      "finalValueHash": "b004731817a34b4b0811c2cd720f3a3479712719e123cd47f1a76b71faf3049f"
    },
    {
      "workflowFile": "unknown",
      "activityType": "QueryEntity",
      "propertyName": "Filter",
      "originalRawValue": "{\"type\":\"variable\",\"name\":\"str_FilterExpression\",\"confidence\":0.8}",
      "parsedIntentType": "variable",
      "normalizedOutput": "[str_FilterExpression]",
      "fallbackUsed": false,
      "finalValueHash": "1358abc6d568705644b2728b50120c6baf7ee0a3c82de7c0106a8914165e4965"
    },
    {
      "workflowFile": "unknown",
      "activityType": "QueryEntity",
      "propertyName": "Top",
      "originalRawValue": "{\"type\":\"literal\",\"value\":\"1\",\"confidence\":0.9}",
      "parsedIntentType": "literal",
      "normalizedOutput": "\"1\"",
      "fallbackUsed": false,
      "finalValueHash": "391552c099c101b131feaf24c5795a6a15bc8ec82015424e0d2b4274a369a0bf"
    },
    {
      "workflowFile": "unknown",
      "activityType": "QueryEntity",
      "propertyName": "Result",
      "originalRawValue": "{\"type\":\"variable\",\"name\":\"obj_QueryResults\",\"confidence\":0.8}",
      "parsedIntentType": "variable",
      "normalizedOutput": "[obj_QueryResults]",
      "fallbackUsed": false,
      "finalValueHash": "7b1fe20f88c3fa4a23f4cc0c5aa13d92da0b97fee83737f5565014dc929d01b9"
    },
    {
      "workflowFile": "BGYY_GenerateAndValidateDraft.xaml",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "originalRawValue": "\"[BGYY_GenerateAndValidateDraft] START — FullName='\" & InFullName & \"' RunId='\" & InRunId & \"'\"",
      "parsedIntentType": "pre-assembly:literal",
      "normalizedOutput": "[\"[BGYY_GenerateAndValidateDraft] START — FullName='\"\" & InFullName & \"\"' RunId='\"\" & InRunId & \"\"'\"]",
      "fallbackUsed": false,
      "finalValueHash": "6ba0d9b89f331aabb0d483739197004d1f0ae6706966f84988bc4df18f0bec56"
    },
    {
      "workflowFile": "BGYY_GenerateAndValidateDraft.xaml",
      "activityType": "LogMessage",
      "propertyName": "Level",
      "originalRawValue": "Info",
      "parsedIntentType": "pre-assembly:literal",
      "normalizedOutput": "\"Info\"",
      "fallbackUsed": false,
      "finalValueHash": "6e68b62d2aa611a44f3e7a4cb7e23da9ad1cab1b6abb592bb2795b12fe63e51c"
    },
    {
      "workflowFile": "BGYY_GenerateAndValidateDraft.xaml",
      "activityType": "QueryEntity",
      "propertyName": "EntityType",
      "originalRawValue": "BGYY_VoiceProfile",
      "parsedIntentType": "pre-assembly:literal",
      "normalizedOutput": "\"BGYY_VoiceProfile\"",
      "fallbackUsed": false,
      "finalValueHash": "cea3f80968d76bbaf6f6684ed95afd8320682b388c3b2c575d9f804fc5867b61"
    },
    {
      "workflowFile": "BGYY_GenerateAndValidateDraft.xaml",
      "activityType": "LogMessage",
      "propertyName": "Level",
      "originalRawValue": "Error",
      "parsedIntentType": "pre-assembly:literal",
      "normalizedOutput": "\"Error\"",
      "fallbackUsed": false,
      "finalValueHash": "fc4ac19649f0ee8f37c71d2e2030a3743038bb96c0c27359ba115dd8657565cc"
    },
    {
      "workflowFile": "BGYY_GenerateAndValidateDraft.xaml",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "originalRawValue": "\"Error in Query BGYY_VoiceProfile Data Service entity for Default profile: \" & exception.Message",
      "parsedIntentType": "pre-assembly:literal",
      "normalizedOutput": "[\"\"\"Error in Query BGYY_VoiceProfile Data Service entity for Default profile: \"\" & exception.Message\"]",
      "fallbackUsed": false,
      "finalValueHash": "37aca5f653586b1fc91b168b8ea2c45362c6179f5f45fde02e93e6b3c301a690"
    },
    {
      "workflowFile": "BGYY_GenerateAndValidateDraft.xaml",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "originalRawValue": "\"[BGYY_GenerateAndValidateDraft] VoiceProfile loaded=\" & voiceProfileLoaded.ToString() & \" ToneTags='\" & voiceProfileToneTags & \"'\"",
      "parsedIntentType": "pre-assembly:literal",
      "normalizedOutput": "[\"[BGYY_GenerateAndValidateDraft] VoiceProfile loaded=\"\" & voiceProfileLoaded.ToString() & \"\" ToneTags='\"\" & voiceProfileToneTags & \"\"'\"]",
      "fallbackUsed": false,
      "finalValueHash": "cbbd67d8773aec820aad2fad5a3f06d843f7382d913e71acc60b0d38e52bcd87"
    },
    {
      "workflowFile": "BGYY_GenerateAndValidateDraft.xaml",
      "activityType": "LogMessage",
      "propertyName": "Level",
      "originalRawValue": "Info",
      "parsedIntentType": "pre-assembly:literal",
      "normalizedOutput": "\"Info\"",
      "fallbackUsed": false,
      "finalValueHash": "6e68b62d2aa611a44f3e7a4cb7e23da9ad1cab1b6abb592bb2795b12fe63e51c"
    },
    {
      "workflowFile": "BGYY_GenerateAndValidateDraft.xaml",
      "activityType": "ReadStorageText",
      "propertyName": "Path",
      "originalRawValue": "guardrails/banned_phrases.txt",
      "parsedIntentType": "pre-assembly:literal",
      "normalizedOutput": "\"guardrails/banned_phrases.txt\"",
      "fallbackUsed": false,
      "finalValueHash": "7c5964a7f82a42faae10ed451f500f1fbe043022744a0d327982d889e4078bb0"
    },
    {
      "workflowFile": "BGYY_GenerateAndValidateDraft.xaml",
      "activityType": "LogMessage",
      "propertyName": "Level",
      "originalRawValue": "Error",
      "parsedIntentType": "pre-assembly:literal",
      "normalizedOutput": "\"Error\"",
      "fallbackUsed": false,
      "finalValueHash": "fc4ac19649f0ee8f37c71d2e2030a3743038bb96c0c27359ba115dd8657565cc"
    },
    {
      "workflowFile": "BGYY_GenerateAndValidateDraft.xaml",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "originalRawValue": "\"Error in Download banned phrases list from Storage Bucket guardrails/banned_phrases.txt: \" & exception.Message",
      "parsedIntentType": "pre-assembly:literal",
      "normalizedOutput": "[\"\"\"Error in Download banned phrases list from Storage Bucket guardrails/banned_phrases.txt: \"\" & exception.Message\"]",
      "fallbackUsed": false,
      "finalValueHash": "074d653bcada71680f7cd3243c6c381768d25ecf2c2cf3a889d39f440c34ea72"
    },
    {
      "workflowFile": "BGYY_GenerateAndValidateDraft.xaml",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "originalRawValue": "\"[BGYY_GenerateAndValidateDraft] GenAI prompt constructed for FullName='\" & InFullName & \"' PromptLength=\" & constructedPrompt.Length.ToString() & \" chars\"",
      "parsedIntentType": "pre-assembly:literal",
      "normalizedOutput": "[\"[BGYY_GenerateAndValidateDraft] GenAI prompt constructed for FullName='\"\" & InFullName & \"\"' PromptLength=\"\" & constructedPrompt.Length.ToString() & \"\" chars\"]",
      "fallbackUsed": false,
      "finalValueHash": "15d34b28d191944c029b289e127451dc30fcc0516b374ca04d24228e62126951"
    },
    {
      "workflowFile": "BGYY_GenerateAndValidateDraft.xaml",
      "activityType": "LogMessage",
      "propertyName": "Level",
      "originalRawValue": "Trace",
      "parsedIntentType": "pre-assembly:literal",
      "normalizedOutput": "\"Trace\"",
      "fallbackUsed": false,
      "finalValueHash": "1226cd1a1d0a4358431b82e8b3117b8efc74c0c5bc3a74e0d5c55e1b29b108e7"
    },
    {
      "workflowFile": "BGYY_GenerateAndValidateDraft.xaml",
      "activityType": "LogMessage",
      "propertyName": "Level",
      "originalRawValue": "Error",
      "parsedIntentType": "pre-assembly:literal",
      "normalizedOutput": "\"Error\"",
      "fallbackUsed": false,
      "finalValueHash": "fc4ac19649f0ee8f37c71d2e2030a3743038bb96c0c27359ba115dd8657565cc"
    },
    {
      "workflowFile": "BGYY_GenerateAndValidateDraft.xaml",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "originalRawValue": "\"Error in Invoke UiPath GenAI GenerateTextCompletion to produce subject and body JSON: \" & exception.Message",
      "parsedIntentType": "pre-assembly:literal",
      "normalizedOutput": "[\"\"\"Error in Invoke UiPath GenAI GenerateTextCompletion to produce subject and body JSON: \"\" & exception.Message\"]",
      "fallbackUsed": false,
      "finalValueHash": "c7c8617b3bba569e95d84f52c53e79ea1ed29fdfb269ac2462606baf5eac61a0"
    },
    {
      "workflowFile": "BGYY_GenerateAndValidateDraft.xaml",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "originalRawValue": "\"[BGYY_GenerateAndValidateDraft] GenAI response received — OutputLength=\" & If(genAiRawOutput IsNot Nothing, genAiRawOutput.Length.ToString(), \"0\") & \" chars\"",
      "parsedIntentType": "pre-assembly:literal",
      "normalizedOutput": "[\"[BGYY_GenerateAndValidateDraft] GenAI response received — OutputLength=\"\" & If(genAiRawOutput IsNot Nothing, genAiRawOutput.Length.ToString(), \"\"0\"\") & \"\" chars\"]",
      "fallbackUsed": false,
      "finalValueHash": "3b2c9b9797d8635c6280d2bdba1f2168076db08ffa9f4afe68b8558a445180fa"
    },
    {
      "workflowFile": "BGYY_GenerateAndValidateDraft.xaml",
      "activityType": "LogMessage",
      "propertyName": "Level",
      "originalRawValue": "Info",
      "parsedIntentType": "pre-assembly:literal",
      "normalizedOutput": "\"Info\"",
      "fallbackUsed": false,
      "finalValueHash": "6e68b62d2aa611a44f3e7a4cb7e23da9ad1cab1b6abb592bb2795b12fe63e51c"
    },
    {
      "workflowFile": "BGYY_GenerateAndValidateDraft.xaml",
      "activityType": "LogMessage",
      "propertyName": "Level",
      "originalRawValue": "Error",
      "parsedIntentType": "pre-assembly:literal",
      "normalizedOutput": "\"Error\"",
      "fallbackUsed": false,
      "finalValueHash": "fc4ac19649f0ee8f37c71d2e2030a3743038bb96c0c27359ba115dd8657565cc"
    },
    {
      "workflowFile": "BGYY_GenerateAndValidateDraft.xaml",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "originalRawValue": "\"Error in Attempt to parse JSON output — extract Subject field: \" & exception.Message",
      "parsedIntentType": "pre-assembly:literal",
      "normalizedOutput": "[\"\"\"Error in Attempt to parse JSON output — extract Subject field: \"\" & exception.Message\"]",
      "fallbackUsed": false,
      "finalValueHash": "0203299bcdb384be6f09dbf805228054ab87bdd9960504f520a3f570652c0386"
    },
    {
      "workflowFile": "BGYY_GenerateAndValidateDraft.xaml",
      "activityType": "LogMessage",
      "propertyName": "Level",
      "originalRawValue": "Error",
      "parsedIntentType": "pre-assembly:literal",
      "normalizedOutput": "\"Error\"",
      "fallbackUsed": false,
      "finalValueHash": "fc4ac19649f0ee8f37c71d2e2030a3743038bb96c0c27359ba115dd8657565cc"
    },
    {
      "workflowFile": "BGYY_GenerateAndValidateDraft.xaml",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "originalRawValue": "\"Error in Attempt to parse JSON output — extract Body field: \" & exception.Message",
      "parsedIntentType": "pre-assembly:literal",
      "normalizedOutput": "[\"\"\"Error in Attempt to parse JSON output — extract Body field: \"\" & exception.Message\"]",
      "fallbackUsed": false,
      "finalValueHash": "8a803cfa30256e38269fde2596e245d6d57356c4f45505be435a954b82454649"
    },
    {
      "workflowFile": "BGYY_GenerateAndValidateDraft.xaml",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "originalRawValue": "\"[BGYY_GenerateAndValidateDraft] JSON parse success=\" & jsonParseSuccess.ToString() & \" SubjectLen=\" & parsedSubject.Length.ToString() & \" BodyLen=\" & parsedBody.Length.ToString()",
      "parsedIntentType": "pre-assembly:literal",
      "normalizedOutput": "[\"\"\"[BGYY_GenerateAndValidateDraft] JSON parse success=\"\" & jsonParseSuccess.ToString() & \"\" SubjectLen=\"\" & parsedSubject.Length.ToString() & \"\" BodyLen=\"\" & parsedBody.Length.ToString()\"]",
      "fallbackUsed": false,
      "finalValueHash": "84d832268622c88d3f8a6f6734663a4a1184a46a762a80b97b0547c8d2aea0fc"
    },
    {
      "workflowFile": "BGYY_GenerateAndValidateDraft.xaml",
      "activityType": "LogMessage",
      "propertyName": "Level",
      "originalRawValue": "Info",
      "parsedIntentType": "pre-assembly:literal",
      "normalizedOutput": "\"Info\"",
      "fallbackUsed": false,
      "finalValueHash": "6e68b62d2aa611a44f3e7a4cb7e23da9ad1cab1b6abb592bb2795b12fe63e51c"
    },
    {
      "workflowFile": "BGYY_GenerateAndValidateDraft.xaml",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "originalRawValue": "\"[BGYY_GenerateAndValidateDraft] ValidationPassed=\" & validationPassed.ToString() & \" Reason='\" & If(validationPassed, \"AllGatesPassed\", validationFailReason) & \"' WordCount=\" & wordCount.ToString() & \" BannedPhraseFound=\" & bannedPhraseFound.ToString()",
      "parsedIntentType": "pre-assembly:literal",
      "normalizedOutput": "[\"\"\"[BGYY_GenerateAndValidateDraft] ValidationPassed=\"\" & validationPassed.ToString() & \"\" Reason='\"\" & If(validationPassed, \"\"AllGatesPassed\"\", validationFailReason) & \"\"' WordCount=\"\" & wordCount.ToString() & \"\" BannedPhraseFound=\"\" & bannedPhraseFound.ToString()\"]",
      "fallbackUsed": false,
      "finalValueHash": "7bf57c62ff149ff0f30be1111794dd18f67af9ebfd681713234439a60f170a3b"
    },
    {
      "workflowFile": "BGYY_GenerateAndValidateDraft.xaml",
      "activityType": "LogMessage",
      "propertyName": "Level",
      "originalRawValue": "Warn",
      "parsedIntentType": "pre-assembly:literal",
      "normalizedOutput": "\"Warn\"",
      "fallbackUsed": false,
      "finalValueHash": "0817e2b865151b33aa686f0551fce818a034cb723e0044e433cd8100810ed280"
    },
    {
      "workflowFile": "unknown",
      "activityType": "QueryEntity",
      "propertyName": "EntityType",
      "originalRawValue": "{\"type\":\"literal\",\"value\":\"BGYY_VoiceProfile\"}",
      "parsedIntentType": "literal",
      "normalizedOutput": "\"BGYY_VoiceProfile\"",
      "fallbackUsed": false,
      "finalValueHash": "cea3f80968d76bbaf6f6684ed95afd8320682b388c3b2c575d9f804fc5867b61"
    },
    {
      "workflowFile": "unknown",
      "activityType": "QueryEntity",
      "propertyName": "Result",
      "originalRawValue": "{\"type\":\"variable\",\"name\":\"voiceProfileQueryResult\"}",
      "parsedIntentType": "variable",
      "normalizedOutput": "[voiceProfileQueryResult]",
      "fallbackUsed": false,
      "finalValueHash": "2289e4211385e5ed374efd0b796f7b62546055c02040a3813023ac262b1f8b84"
    },
    {
      "workflowFile": "unknown",
      "activityType": "ReadStorageText",
      "propertyName": "Path",
      "originalRawValue": "{\"type\":\"literal\",\"value\":\"guardrails/banned_phrases.txt\"}",
      "parsedIntentType": "literal",
      "normalizedOutput": "\"guardrails/banned_phrases.txt\"",
      "fallbackUsed": false,
      "finalValueHash": "7c5964a7f82a42faae10ed451f500f1fbe043022744a0d327982d889e4078bb0"
    },
    {
      "workflowFile": "unknown",
      "activityType": "ReadStorageText",
      "propertyName": "StorageBucketName",
      "originalRawValue": "{\"type\":\"variable\",\"name\":\"storageBucketName\"}",
      "parsedIntentType": "variable",
      "normalizedOutput": "[storageBucketName]",
      "fallbackUsed": false,
      "finalValueHash": "64c7d4c3b3a0b4d04c476a3cc7c76d90a8ffbc8a4013d3bab3cb2ec1d7ba3798"
    },
    {
      "workflowFile": "unknown",
      "activityType": "IsMatch",
      "propertyName": "Input",
      "originalRawValue": "{\"type\":\"vb_expression\",\"value\":\"parsedSubject & \\\" \\\" & parsedBody\"}",
      "parsedIntentType": "vb_expression",
      "normalizedOutput": "[parsedSubject &amp; \" \" &amp; parsedBody]",
      "fallbackUsed": false,
      "finalValueHash": "641a55a8187fdb0f1eab63a5b8301965e1c0e52f8457f2084348eb613bc0f6aa"
    },
    {
      "workflowFile": "unknown",
      "activityType": "IsMatch",
      "propertyName": "Pattern",
      "originalRawValue": "{\"type\":\"variable\",\"name\":\"placeholderPattern\"}",
      "parsedIntentType": "variable",
      "normalizedOutput": "[placeholderPattern]",
      "fallbackUsed": false,
      "finalValueHash": "15290f75b098d9d0d294392fd0d89e524e1b96b66285c0eac8e926f22d22754b"
    },
    {
      "workflowFile": "BGYY_SendGmail.xaml",
      "activityType": "LogMessage",
      "propertyName": "Level",
      "originalRawValue": "Info",
      "parsedIntentType": "pre-assembly:literal",
      "normalizedOutput": "\"Info\"",
      "fallbackUsed": false,
      "finalValueHash": "6e68b62d2aa611a44f3e7a4cb7e23da9ad1cab1b6abb592bb2795b12fe63e51c"
    },
    {
      "workflowFile": "BGYY_SendGmail.xaml",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "originalRawValue": "\"[BGYY_SendGmail] START | RunId=\" & InRunId & \" | Recipient=\" & InRecipientEmail & \" | Subject=\" & InSubject",
      "parsedIntentType": "pre-assembly:literal",
      "normalizedOutput": "[\"\"\"[BGYY_SendGmail] START | RunId=\"\" & InRunId & \"\" | Recipient=\"\" & InRecipientEmail & \"\" | Subject=\"\" & InSubject\"]",
      "fallbackUsed": false,
      "finalValueHash": "db7884deb726b1553ed7d3fbd342cebe79de7f5259bcf022710202938965aa08"
    },
    {
      "workflowFile": "BGYY_SendGmail.xaml",
      "activityType": "GetAsset",
      "propertyName": "AssetName",
      "originalRawValue": "BGYY_DryRun",
      "parsedIntentType": "pre-assembly:literal",
      "normalizedOutput": "\"BGYY_DryRun\"",
      "fallbackUsed": false,
      "finalValueHash": "beb5b97a17d99ba63c78b7dfb2431e875c688a90f25961b9435af2b41f091b01"
    },
    {
      "workflowFile": "BGYY_SendGmail.xaml",
      "activityType": "LogMessage",
      "propertyName": "Level",
      "originalRawValue": "Error",
      "parsedIntentType": "pre-assembly:literal",
      "normalizedOutput": "\"Error\"",
      "fallbackUsed": false,
      "finalValueHash": "fc4ac19649f0ee8f37c71d2e2030a3743038bb96c0c27359ba115dd8657565cc"
    },
    {
      "workflowFile": "BGYY_SendGmail.xaml",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "originalRawValue": "\"Error in Read BGYY_DryRun asset to determine mock mode: \" & exception.Message",
      "parsedIntentType": "pre-assembly:literal",
      "normalizedOutput": "[\"\"\"Error in Read BGYY_DryRun asset to determine mock mode: \"\" & exception.Message\"]",
      "fallbackUsed": false,
      "finalValueHash": "dd1df02526baeebd526f54899edc7f9c515b62fe5bf04c2dfb6d180921d1d0d2"
    },
    {
      "workflowFile": "BGYY_SendGmail.xaml",
      "activityType": "LogMessage",
      "propertyName": "Level",
      "originalRawValue": "Error",
      "parsedIntentType": "pre-assembly:literal",
      "normalizedOutput": "\"Error\"",
      "fallbackUsed": false,
      "finalValueHash": "fc4ac19649f0ee8f37c71d2e2030a3743038bb96c0c27359ba115dd8657565cc"
    },
    {
      "workflowFile": "BGYY_SendGmail.xaml",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "originalRawValue": "\"Error in Parse dry-run asset string to Boolean: \" & exception.Message",
      "parsedIntentType": "pre-assembly:literal",
      "normalizedOutput": "[\"\"\"Error in Parse dry-run asset string to Boolean: \"\" & exception.Message\"]",
      "fallbackUsed": false,
      "finalValueHash": "561029059a6f3d77b98a142e62aebc92500b1cf24c4924e631edb8d82cefeb29"
    },
    {
      "workflowFile": "BGYY_SendGmail.xaml",
      "activityType": "LogMessage",
      "propertyName": "Level",
      "originalRawValue": "Warn",
      "parsedIntentType": "pre-assembly:literal",
      "normalizedOutput": "\"Warn\"",
      "fallbackUsed": false,
      "finalValueHash": "0817e2b865151b33aa686f0551fce818a034cb723e0044e433cd8100810ed280"
    },
    {
      "workflowFile": "BGYY_SendGmail.xaml",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "originalRawValue": "\"[BGYY_SendGmail] DRY-RUN active — email NOT sent | RunId=\" & InRunId & \" | Recipient=\" & InRecipientEmail & \" | Subject=\" & InSubject",
      "parsedIntentType": "pre-assembly:literal",
      "normalizedOutput": "[\"\"\"[BGYY_SendGmail] DRY-RUN active — email NOT sent | RunId=\"\" & InRunId & \"\" | Recipient=\"\" & InRecipientEmail & \"\" | Subject=\"\" & InSubject\"]",
      "fallbackUsed": false,
      "finalValueHash": "d957a27cb5e1d93c5e0ae129879c17e297af6eb4e4fb638daffc33dd56b78a5f"
    },
    {
      "workflowFile": "BGYY_SendGmail.xaml",
      "activityType": "LogMessage",
      "propertyName": "Level",
      "originalRawValue": "Error",
      "parsedIntentType": "pre-assembly:literal",
      "normalizedOutput": "\"Error\"",
      "fallbackUsed": false,
      "finalValueHash": "fc4ac19649f0ee8f37c71d2e2030a3743038bb96c0c27359ba115dd8657565cc"
    },
    {
      "workflowFile": "BGYY_SendGmail.xaml",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "originalRawValue": "\"[BGYY_SendGmail] VALIDATION FAILED — one or more required send inputs are null/empty | RunId=\" & InRunId & \" | RecipientEmailEmpty=\" & String.IsNullOrWhiteSpace(InRecipientEmail).ToString() & \" | SubjectEmpty=\" & String.IsNullOrWhiteSpace(InSubject).ToString() & \" | BodyEmpty=\" & String.IsNullOrWhiteSpace(InBody).ToString()",
      "parsedIntentType": "pre-assembly:literal",
      "normalizedOutput": "[\"\"\"[BGYY_SendGmail] VALIDATION FAILED — one or more required send inputs are null/empty | RunId=\"\" & InRunId & \"\" | RecipientEmailEmpty=\"\" & String.IsNullOrWhiteSpace(InRecipientEmail).ToString() & \"\" | SubjectEmpty=\"\" & String.IsNullOrWhiteSpace(InSubject).ToString() & \"\" | BodyEmpty=\"\" & String.IsNullOrWhiteSpace(InBody).ToString()\"]",
      "fallbackUsed": false,
      "finalValueHash": "c7e69b36e8aec7e0905958a75eabc106139bbbbc93b973e606c97e6e1822725e"
    },
    {
      "workflowFile": "BGYY_SendGmail.xaml",
      "activityType": "LogMessage",
      "propertyName": "Level",
      "originalRawValue": "Info",
      "parsedIntentType": "pre-assembly:literal",
      "normalizedOutput": "\"Info\"",
      "fallbackUsed": false,
      "finalValueHash": "6e68b62d2aa611a44f3e7a4cb7e23da9ad1cab1b6abb592bb2795b12fe63e51c"
    },
    {
      "workflowFile": "BGYY_SendGmail.xaml",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "originalRawValue": "\"[BGYY_SendGmail] Entering RetryScope for Gmail send | RunId=\" & InRunId & \" | Recipient=\" & InRecipientEmail & \" | MaxAttempts=3\"",
      "parsedIntentType": "pre-assembly:literal",
      "normalizedOutput": "[\"[BGYY_SendGmail] Entering RetryScope for Gmail send | RunId=\"\" & InRunId & \"\" | Recipient=\"\" & InRecipientEmail & \"\" | MaxAttempts=3\"]",
      "fallbackUsed": false,
      "finalValueHash": "c1ccc69e06832c6f522101747e2334cd74b236dee75ff35acaa340c1f7adc8f2"
    },
    {
      "workflowFile": "BGYY_SendGmail.xaml",
      "activityType": "LogMessage",
      "propertyName": "Level",
      "originalRawValue": "Info",
      "parsedIntentType": "pre-assembly:literal",
      "normalizedOutput": "\"Info\"",
      "fallbackUsed": false,
      "finalValueHash": "6e68b62d2aa611a44f3e7a4cb7e23da9ad1cab1b6abb592bb2795b12fe63e51c"
    },
    {
      "workflowFile": "BGYY_SendGmail.xaml",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "originalRawValue": "\"[BGYY_SendGmail] Gmail send attempt \" & attemptNumber.ToString() & \" of 3 | RunId=\" & InRunId & \" | Recipient=\" & InRecipientEmail",
      "parsedIntentType": "pre-assembly:literal",
      "normalizedOutput": "[\"\"\"[BGYY_SendGmail] Gmail send attempt \"\" & attemptNumber.ToString() & \"\" of 3 | RunId=\"\" & InRunId & \"\" | Recipient=\"\" & InRecipientEmail\"]",
      "fallbackUsed": false,
      "finalValueHash": "43d80e2c7ab39557bc7d3569d9f7edc0af16407f955dbc76308553a6381ef5cc"
    },
    {
      "workflowFile": "BGYY_SendGmail.xaml",
      "activityType": "Comment",
      "propertyName": "Text",
      "originalRawValue": "[HANDOFF] This activity replaces \"Send birthday greeting email via Gmail Integration Service connector\" (UiPath.GSuite.Activities.GmailSendMessage). Missing required properties: Body. Developer must implement the actual UiPath.GSuite.Activities.GmailSendMessage activity with the correct property values.",
      "parsedIntentType": "pre-assembly:literal",
      "normalizedOutput": "[\"[HANDOFF] This activity replaces \"\"Send birthday greeting email via Gmail Integration Service connector\"\" (UiPath.GSuite.Activities.GmailSendMessage). Missing required properties: Body. Developer must implement the actual UiPath.GSuite.Activities.GmailSendMessage activity with the correct property values.\"]",
      "fallbackUsed": false,
      "finalValueHash": "3a46277f66affb4e8f28443f778fb70a3e6d376d0fdfebe4e42ccad8812977c0"
    },
    {
      "workflowFile": "BGYY_SendGmail.xaml",
      "activityType": "LogMessage",
      "propertyName": "Level",
      "originalRawValue": "Warn",
      "parsedIntentType": "pre-assembly:literal",
      "normalizedOutput": "\"Warn\"",
      "fallbackUsed": false,
      "finalValueHash": "0817e2b865151b33aa686f0551fce818a034cb723e0044e433cd8100810ed280"
    },
    {
      "workflowFile": "BGYY_SendGmail.xaml",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "originalRawValue": "\"[HANDOFF] Activity 'Send birthday greeting email via Gmail Integration Service connector' (UiPath.GSuite.Activities.GmailSendMessage) requires developer implementation — missing: Body\"",
      "parsedIntentType": "pre-assembly:literal",
      "normalizedOutput": "[\"[HANDOFF] Activity 'Send birthday greeting email via Gmail Integration Service connector' (UiPath.GSuite.Activities.GmailSendMessage) requires developer implementation — missing: Body\"]",
      "fallbackUsed": false,
      "finalValueHash": "d22f665fe2da7a5eead383207d332e6f0daef28c2459f3b3bb1195b6ab4060c0"
    },
    {
      "workflowFile": "BGYY_SendGmail.xaml",
      "activityType": "LogMessage",
      "propertyName": "Level",
      "originalRawValue": "Info",
      "parsedIntentType": "pre-assembly:literal",
      "normalizedOutput": "\"Info\"",
      "fallbackUsed": false,
      "finalValueHash": "6e68b62d2aa611a44f3e7a4cb7e23da9ad1cab1b6abb592bb2795b12fe63e51c"
    },
    {
      "workflowFile": "BGYY_SendGmail.xaml",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "originalRawValue": "\"[BGYY_SendGmail] Email sent successfully | RunId=\" & InRunId & \" | Recipient=\" & InRecipientEmail & \" | MessageId=\" & gmailMessageId & \" | Attempt=\" & attemptNumber.ToString()",
      "parsedIntentType": "pre-assembly:literal",
      "normalizedOutput": "[\"\"\"[BGYY_SendGmail] Email sent successfully | RunId=\"\" & InRunId & \"\" | Recipient=\"\" & InRecipientEmail & \"\" | MessageId=\"\" & gmailMessageId & \"\" | Attempt=\"\" & attemptNumber.ToString()\"]",
      "fallbackUsed": false,
      "finalValueHash": "0469b3cd4ce558c348b4021843fb73d0217ba4359caca801f2307f7b6efdc0ab"
    },
    {
      "workflowFile": "BGYY_SendGmail.xaml",
      "activityType": "LogMessage",
      "propertyName": "Level",
      "originalRawValue": "Error",
      "parsedIntentType": "pre-assembly:literal",
      "normalizedOutput": "\"Error\"",
      "fallbackUsed": false,
      "finalValueHash": "fc4ac19649f0ee8f37c71d2e2030a3743038bb96c0c27359ba115dd8657565cc"
    },
    {
      "workflowFile": "BGYY_SendGmail.xaml",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "originalRawValue": "\"[BGYY_SendGmail] PERSISTENT FAILURE — Gmail send failed after 3 attempts | RunId=\" & InRunId & \" | Recipient=\" & InRecipientEmail & \" | LastException=\" & lastSendException",
      "parsedIntentType": "pre-assembly:literal",
      "normalizedOutput": "[\"\"\"[BGYY_SendGmail] PERSISTENT FAILURE — Gmail send failed after 3 attempts | RunId=\"\" & InRunId & \"\" | Recipient=\"\" & InRecipientEmail & \"\" | LastException=\"\" & lastSendException\"]",
      "fallbackUsed": false,
      "finalValueHash": "75b071064f13930066a84181369e92f7c0c25c6c5d4ee0a7dd30eec18ebf35c3"
    },
    {
      "workflowFile": "BGYY_SendGmail.xaml",
      "activityType": "LogMessage",
      "propertyName": "Level",
      "originalRawValue": "Error",
      "parsedIntentType": "pre-assembly:literal",
      "normalizedOutput": "\"Error\"",
      "fallbackUsed": false,
      "finalValueHash": "fc4ac19649f0ee8f37c71d2e2030a3743038bb96c0c27359ba115dd8657565cc"
    },
    {
      "workflowFile": "BGYY_SendGmail.xaml",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "originalRawValue": "\"Error in Capture desktop screenshot as failure evidence: \" & exception.Message",
      "parsedIntentType": "pre-assembly:literal",
      "normalizedOutput": "[\"\"\"Error in Capture desktop screenshot as failure evidence: \"\" & exception.Message\"]",
      "fallbackUsed": false,
      "finalValueHash": "ee4151ae3639eb2b9e5cb84a36153c8a44cf9115a929f718d7835e66214f0709"
    },
    {
      "workflowFile": "BGYY_SendGmail.xaml",
      "activityType": "UploadStorageFile",
      "propertyName": "Path",
      "originalRawValue": "screenshotBucketPath",
      "parsedIntentType": "pre-assembly:literal",
      "normalizedOutput": "\"screenshotBucketPath\"",
      "fallbackUsed": false,
      "finalValueHash": "641c5576b050f83aa2c551c6c48392080357d734a7edd0c7014a4556de851c1e"
    },
    {
      "workflowFile": "BGYY_SendGmail.xaml",
      "activityType": "LogMessage",
      "propertyName": "Level",
      "originalRawValue": "Error",
      "parsedIntentType": "pre-assembly:literal",
      "normalizedOutput": "\"Error\"",
      "fallbackUsed": false,
      "finalValueHash": "fc4ac19649f0ee8f37c71d2e2030a3743038bb96c0c27359ba115dd8657565cc"
    },
    {
      "workflowFile": "BGYY_SendGmail.xaml",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "originalRawValue": "\"Error in Upload failure screenshot to BGYY_RunArtifacts Storage Bucket: \" & exception.Message",
      "parsedIntentType": "pre-assembly:literal",
      "normalizedOutput": "[\"\"\"Error in Upload failure screenshot to BGYY_RunArtifacts Storage Bucket: \"\" & exception.Message\"]",
      "fallbackUsed": false,
      "finalValueHash": "f2780563721375d476a5440dc7512c77a91fc530cfec116f93ccae12bee16ad0"
    },
    {
      "workflowFile": "BGYY_SendGmail.xaml",
      "activityType": "LogMessage",
      "propertyName": "Level",
      "originalRawValue": "Info",
      "parsedIntentType": "pre-assembly:literal",
      "normalizedOutput": "\"Info\"",
      "fallbackUsed": false,
      "finalValueHash": "6e68b62d2aa611a44f3e7a4cb7e23da9ad1cab1b6abb592bb2795b12fe63e51c"
    },
    {
      "workflowFile": "BGYY_SendGmail.xaml",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "originalRawValue": "\"[BGYY_SendGmail] END | RunId=\" & InRunId & \" | Recipient=\" & InRecipientEmail & \" | Succeeded=\" & OutSendSucceeded.ToString() & \" | MessageId=\" & If(String.IsNullOrEmpty(OutGmailMessageId), \"(none)\", OutGmailMessageId)",
      "parsedIntentType": "pre-assembly:literal",
      "normalizedOutput": "[\"\"\"[BGYY_SendGmail] END | RunId=\"\" & InRunId & \"\" | Recipient=\"\" & InRecipientEmail & \"\" | Succeeded=\"\" & OutSendSucceeded.ToString() & \"\" | MessageId=\"\" & If(String.IsNullOrEmpty(OutGmailMessageId), \"\"(none)\"\", OutGmailMessageId)\"]",
      "fallbackUsed": false,
      "finalValueHash": "bd96409e744a1dd272e209057510ed33185ebfedbd034bbf91fa872ff11394b4"
    },
    {
      "workflowFile": "unknown",
      "activityType": "UploadStorageFile",
      "propertyName": "StorageBucketName",
      "originalRawValue": "{\"type\":\"literal\",\"value\":\"BGYY_RunArtifacts\"}",
      "parsedIntentType": "literal",
      "normalizedOutput": "\"BGYY_RunArtifacts\"",
      "fallbackUsed": false,
      "finalValueHash": "33ba51cda6204d629b13659583987f07350bd4896764a2a53b10faab956ba518"
    },
    {
      "workflowFile": "unknown",
      "activityType": "UploadStorageFile",
      "propertyName": "Path",
      "originalRawValue": "{\"type\":\"literal\",\"value\":\"screenshotBucketPath\"}",
      "parsedIntentType": "literal",
      "normalizedOutput": "\"screenshotBucketPath\"",
      "fallbackUsed": false,
      "finalValueHash": "641c5576b050f83aa2c551c6c48392080357d734a7edd0c7014a4556de851c1e"
    },
    {
      "workflowFile": "unknown",
      "activityType": "UploadStorageFile",
      "propertyName": "Destination",
      "originalRawValue": "{\"type\":\"variable\",\"name\":\"screenshotBucketPath\"}",
      "parsedIntentType": "variable",
      "normalizedOutput": "[screenshotBucketPath]",
      "fallbackUsed": false,
      "finalValueHash": "98edad88efce6fdedac8e6b1061130715ca66278ec9fbeffe03c94eb7784efd4"
    },
    {
      "workflowFile": "unknown",
      "activityType": "UploadStorageFile",
      "propertyName": "FileResource",
      "originalRawValue": "{\"type\":\"variable\",\"name\":\"tempScreenshotFile\"}",
      "parsedIntentType": "variable",
      "normalizedOutput": "[tempScreenshotFile]",
      "fallbackUsed": false,
      "finalValueHash": "cedfb366552f0825bffe43c2d3edd9f8b326499ed31ed781aec1531fcc5b7523"
    },
    {
      "workflowFile": "BGYY_WriteDedupe.xaml",
      "activityType": "LogMessage",
      "propertyName": "Level",
      "originalRawValue": "Info",
      "parsedIntentType": "pre-assembly:literal",
      "normalizedOutput": "\"Info\"",
      "fallbackUsed": false,
      "finalValueHash": "6e68b62d2aa611a44f3e7a4cb7e23da9ad1cab1b6abb592bb2795b12fe63e51c"
    },
    {
      "workflowFile": "BGYY_WriteDedupe.xaml",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "originalRawValue": "[BGYY_WriteDedupe][Entry] RunId=\" & InRunId & \" | PersonKey=\" & InPersonKey & \" | SendYear=\" & InSendYear.ToString() & \" | Status=\" & InStatus & \" | Email=\" & InSelectedEmail",
      "parsedIntentType": "pre-assembly:literal",
      "normalizedOutput": "[\"[BGYY_WriteDedupe][Entry] RunId=\"\" & InRunId & \"\" | PersonKey=\"\" & InPersonKey & \"\" | SendYear=\"\" & InSendYear.ToString() & \"\" | Status=\"\" & InStatus & \"\" | Email=\"\" & InSelectedEmail\"]",
      "fallbackUsed": false,
      "finalValueHash": "f058fb08cd5477eb6ea0c5763fefcfc8ff82617ed1c5d3023ecd6d593b63d86c"
    },
    {
      "workflowFile": "BGYY_WriteDedupe.xaml",
      "activityType": "Assign",
      "propertyName": "Value",
      "originalRawValue": "InPersonKey.Trim().ToLowerInvariant()",
      "parsedIntentType": "pre-assembly:variable",
      "normalizedOutput": "[InPersonKey.Trim().ToLowerInvariant()]",
      "fallbackUsed": false,
      "finalValueHash": "b714ddc05fd6bbbf2f548375e5d0a9f5f53f22873b8c6894f52693d0a64ed680"
    },
    {
      "workflowFile": "BGYY_WriteDedupe.xaml",
      "activityType": "QueryEntity",
      "propertyName": "EntityType",
      "originalRawValue": "BGYY_BirthdaySendLog",
      "parsedIntentType": "pre-assembly:literal",
      "normalizedOutput": "\"BGYY_BirthdaySendLog\"",
      "fallbackUsed": false,
      "finalValueHash": "b004731817a34b4b0811c2cd720f3a3479712719e123cd47f1a76b71faf3049f"
    },
    {
      "workflowFile": "BGYY_WriteDedupe.xaml",
      "activityType": "QueryEntity",
      "propertyName": "Filter",
      "originalRawValue": "\"PersonKey eq '\" & str_PersonKeyNormalized & \"' and SendYear eq \" & InSendYear.ToString()",
      "parsedIntentType": "pre-assembly:literal",
      "normalizedOutput": "[\"\"\"PersonKey eq '\"\" & str_PersonKeyNormalized & \"\"' and SendYear eq \"\" & InSendYear.ToString()\"]",
      "fallbackUsed": false,
      "finalValueHash": "1ec79720bb5ad6373d1f91165f22d53ac00a13a29a307fa8f376d11166b49fca"
    },
    {
      "workflowFile": "BGYY_WriteDedupe.xaml",
      "activityType": "LogMessage",
      "propertyName": "Level",
      "originalRawValue": "Info",
      "parsedIntentType": "pre-assembly:literal",
      "normalizedOutput": "\"Info\"",
      "fallbackUsed": false,
      "finalValueHash": "6e68b62d2aa611a44f3e7a4cb7e23da9ad1cab1b6abb592bb2795b12fe63e51c"
    },
    {
      "workflowFile": "BGYY_WriteDedupe.xaml",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "originalRawValue": "[BGYY_WriteDedupe][QueryResult] PersonKey=\" & str_PersonKeyNormalized & \" | SendYear=\" & InSendYear.ToString() & \" | RecordFound=\" & (obj_QueryResults IsNot Nothing).ToString()",
      "parsedIntentType": "pre-assembly:literal",
      "normalizedOutput": "[\"[BGYY_WriteDedupe][QueryResult] PersonKey=\"\" & str_PersonKeyNormalized & \"\" | SendYear=\"\" & InSendYear.ToString() & \"\" | RecordFound=\"\" & (obj_QueryResults IsNot Nothing).ToString()\"]",
      "fallbackUsed": false,
      "finalValueHash": "056a6d71bf2b39928e7ee6a43479807187531d98bc42fae9feb831db1be2e0d5"
    },
    {
      "workflowFile": "BGYY_WriteDedupe.xaml",
      "activityType": "Assign",
      "propertyName": "Value",
      "originalRawValue": "obj_QueryResults IsNot Nothing",
      "parsedIntentType": "pre-assembly:literal",
      "normalizedOutput": "\"obj_QueryResults IsNot Nothing\"",
      "fallbackUsed": false,
      "finalValueHash": "6c7052e64b415cc0263a965512606f9b33a560e61bad8d656c6ad2b8277e1516"
    },
    {
      "workflowFile": "BGYY_WriteDedupe.xaml",
      "activityType": "LogMessage",
      "propertyName": "Level",
      "originalRawValue": "Info",
      "parsedIntentType": "pre-assembly:literal",
      "normalizedOutput": "\"Info\"",
      "fallbackUsed": false,
      "finalValueHash": "6e68b62d2aa611a44f3e7a4cb7e23da9ad1cab1b6abb592bb2795b12fe63e51c"
    },
    {
      "workflowFile": "BGYY_WriteDedupe.xaml",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "originalRawValue": "[BGYY_WriteDedupe][Branch] Existing record found for PersonKey=\" & str_PersonKeyNormalized & \" — executing UPDATE with Status=\" & InStatus",
      "parsedIntentType": "pre-assembly:literal",
      "normalizedOutput": "[\"[BGYY_WriteDedupe][Branch] Existing record found for PersonKey=\"\" & str_PersonKeyNormalized & \"\" — executing UPDATE with Status=\"\" & InStatus\"]",
      "fallbackUsed": false,
      "finalValueHash": "0dea50ce601b9a20435eda2aac951d2a9376a64d0fedee5aa0e326d684b2057d"
    },
    {
      "workflowFile": "BGYY_WriteDedupe.xaml",
      "activityType": "Comment",
      "propertyName": "Text",
      "originalRawValue": "[HANDOFF] This activity replaces \"Update Existing BGYY_BirthdaySendLog Record with Latest Status and Audit Fields\" (UiPath.DataService.Activities.UpdateEntity). Missing required properties: EntityObject. Developer must implement the actual UiPath.DataService.Activities.UpdateEntity activity with the correct property values.",
      "parsedIntentType": "pre-assembly:literal",
      "normalizedOutput": "[\"[HANDOFF] This activity replaces \"\"Update Existing BGYY_BirthdaySendLog Record with Latest Status and Audit Fields\"\" (UiPath.DataService.Activities.UpdateEntity). Missing required properties: EntityObject. Developer must implement the actual UiPath.DataService.Activities.UpdateEntity activity with the correct property values.\"]",
      "fallbackUsed": false,
      "finalValueHash": "1d9aeef8fcd20627f884198ef0b4a17fa69bfd093d27a5be00ad4784d6691176"
    },
    {
      "workflowFile": "BGYY_WriteDedupe.xaml",
      "activityType": "LogMessage",
      "propertyName": "Level",
      "originalRawValue": "Warn",
      "parsedIntentType": "pre-assembly:literal",
      "normalizedOutput": "\"Warn\"",
      "fallbackUsed": false,
      "finalValueHash": "0817e2b865151b33aa686f0551fce818a034cb723e0044e433cd8100810ed280"
    },
    {
      "workflowFile": "BGYY_WriteDedupe.xaml",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "originalRawValue": "\"[HANDOFF] Activity 'Update Existing BGYY_BirthdaySendLog Record with Latest Status and Audit Fields' (UiPath.DataService.Activities.UpdateEntity) requires developer implementation — missing: EntityObject\"",
      "parsedIntentType": "pre-assembly:literal",
      "normalizedOutput": "[\"[HANDOFF] Activity 'Update Existing BGYY_BirthdaySendLog Record with Latest Status and Audit Fields' (UiPath.DataService.Activities.UpdateEntity) requires developer implementation — missing: EntityObject\"]",
      "fallbackUsed": false,
      "finalValueHash": "b41a74d40ea8f80f2e699ff57628d0014ab76b18841d67f0820a57571824c0ca"
    },
    {
      "workflowFile": "BGYY_WriteDedupe.xaml",
      "activityType": "Assign",
      "propertyName": "Value",
      "originalRawValue": "ex_UpdateException",
      "parsedIntentType": "pre-assembly:literal",
      "normalizedOutput": "\"ex_UpdateException\"",
      "fallbackUsed": false,
      "finalValueHash": "9fc2bf7450c5eae5a049f03529d4177ce383880b2be8413455533203c8a01bd1"
    },
    {
      "workflowFile": "BGYY_WriteDedupe.xaml",
      "activityType": "LogMessage",
      "propertyName": "Level",
      "originalRawValue": "Error",
      "parsedIntentType": "pre-assembly:literal",
      "normalizedOutput": "\"Error\"",
      "fallbackUsed": false,
      "finalValueHash": "fc4ac19649f0ee8f37c71d2e2030a3743038bb96c0c27359ba115dd8657565cc"
    },
    {
      "workflowFile": "BGYY_WriteDedupe.xaml",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "originalRawValue": "[BGYY_WriteDedupe][UpdateError] PersonKey=\" & str_PersonKeyNormalized & \" | Status=\" & InStatus & \" | Error=\" & ex_UpdateException.Message",
      "parsedIntentType": "pre-assembly:literal",
      "normalizedOutput": "[\"[BGYY_WriteDedupe][UpdateError] PersonKey=\"\" & str_PersonKeyNormalized & \"\" | Status=\"\" & InStatus & \"\" | Error=\"\" & ex_UpdateException.Message\"]",
      "fallbackUsed": false,
      "finalValueHash": "4e1eac47cb93a6e3e797bf558575d48e4ce8bf7b0b7bfd6ee172a71d346aff69"
    },
    {
      "workflowFile": "BGYY_WriteDedupe.xaml",
      "activityType": "LogMessage",
      "propertyName": "Level",
      "originalRawValue": "Info",
      "parsedIntentType": "pre-assembly:literal",
      "normalizedOutput": "\"Info\"",
      "fallbackUsed": false,
      "finalValueHash": "6e68b62d2aa611a44f3e7a4cb7e23da9ad1cab1b6abb592bb2795b12fe63e51c"
    },
    {
      "workflowFile": "BGYY_WriteDedupe.xaml",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "originalRawValue": "[BGYY_WriteDedupe][UpdateSuccess] PersonKey=\" & str_PersonKeyNormalized & \" | Status=\" & InStatus & \" | RunId=\" & InRunId",
      "parsedIntentType": "pre-assembly:literal",
      "normalizedOutput": "[\"[BGYY_WriteDedupe][UpdateSuccess] PersonKey=\"\" & str_PersonKeyNormalized & \"\" | Status=\"\" & InStatus & \"\" | RunId=\"\" & InRunId\"]",
      "fallbackUsed": false,
      "finalValueHash": "ee08db5ec4df574e70667bc172bea32832a3cdad3e7bf5e5882247b585546448"
    },
    {
      "workflowFile": "BGYY_WriteDedupe.xaml",
      "activityType": "LogMessage",
      "propertyName": "Level",
      "originalRawValue": "Info",
      "parsedIntentType": "pre-assembly:literal",
      "normalizedOutput": "\"Info\"",
      "fallbackUsed": false,
      "finalValueHash": "6e68b62d2aa611a44f3e7a4cb7e23da9ad1cab1b6abb592bb2795b12fe63e51c"
    },
    {
      "workflowFile": "BGYY_WriteDedupe.xaml",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "originalRawValue": "[BGYY_WriteDedupe][Branch] No existing record for PersonKey=\" & str_PersonKeyNormalized & \" SendYear=\" & InSendYear.ToString() & \" — executing CREATE with Status=\" & InStatus",
      "parsedIntentType": "pre-assembly:literal",
      "normalizedOutput": "[\"[BGYY_WriteDedupe][Branch] No existing record for PersonKey=\"\" & str_PersonKeyNormalized & \"\" SendYear=\"\" & InSendYear.ToString() & \"\" — executing CREATE with Status=\"\" & InStatus\"]",
      "fallbackUsed": false,
      "finalValueHash": "52e0e2e27a1d1bdf92306a6b3d73bdcf988998d380c0f17a0baae4c3bce878ce"
    },
    {
      "workflowFile": "BGYY_WriteDedupe.xaml",
      "activityType": "Assign",
      "propertyName": "Value",
      "originalRawValue": "New Dictionary(Of String, Object) From {{\"PersonName\", InPersonName}, {\"PersonKey\", str_PersonKeyNormalized}, {\"SelectedEmail\", InSelectedEmail}, {\"SendYear\", InSendYear}, {\"Status\", InStatus}, {\"CalendarEventId\", InCalendarEventId}, {\"GmailMessageId\", InGmailMessageId}, {\"SentTimestamp\", InSentTimestamp}, {\"FailureReason\", InFailureReason}, {\"RunId\", InRunId}}",
      "parsedIntentType": "pre-assembly:literal",
      "normalizedOutput": "[\"New Dictionary(Of String, Object) From {{\"\"PersonName\"\", InPersonName}, {\"\"PersonKey\"\", str_PersonKeyNormalized}, {\"\"SelectedEmail\"\", InSelectedEmail}, {\"\"SendYear\"\", InSendYear}, {\"\"Status\"\", InStatus}, {\"\"CalendarEventId\"\", InCalendarEventId}, {\"\"GmailMessageId\"\", InGmailMessageId}, {\"\"SentTimestamp\"\", InSentTimestamp}, {\"\"FailureReason\"\", InFailureReason}, {\"\"RunId\"\", InRunId}}\"]",
      "fallbackUsed": false,
      "finalValueHash": "baab0907792f38bb932d4bd902c798d35eb6ee320022af578229192ce1d9411d"
    },
    {
      "workflowFile": "BGYY_WriteDedupe.xaml",
      "activityType": "Comment",
      "propertyName": "Text",
      "originalRawValue": "[HANDOFF] This activity replaces \"Create New BGYY_BirthdaySendLog Record with All Audit Fields\" (UiPath.DataService.Activities.CreateEntity). Missing required properties: EntityObject. Developer must implement the actual UiPath.DataService.Activities.CreateEntity activity with the correct property values.",
      "parsedIntentType": "pre-assembly:literal",
      "normalizedOutput": "[\"[HANDOFF] This activity replaces \"\"Create New BGYY_BirthdaySendLog Record with All Audit Fields\"\" (UiPath.DataService.Activities.CreateEntity). Missing required properties: EntityObject. Developer must implement the actual UiPath.DataService.Activities.CreateEntity activity with the correct property values.\"]",
      "fallbackUsed": false,
      "finalValueHash": "2a956384d3788647fc2ad840ad7b6c69c754f9abb0ae5dc0ba9089d2acea5100"
    },
    {
      "workflowFile": "BGYY_WriteDedupe.xaml",
      "activityType": "LogMessage",
      "propertyName": "Level",
      "originalRawValue": "Warn",
      "parsedIntentType": "pre-assembly:literal",
      "normalizedOutput": "\"Warn\"",
      "fallbackUsed": false,
      "finalValueHash": "0817e2b865151b33aa686f0551fce818a034cb723e0044e433cd8100810ed280"
    },
    {
      "workflowFile": "BGYY_WriteDedupe.xaml",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "originalRawValue": "\"[HANDOFF] Activity 'Create New BGYY_BirthdaySendLog Record with All Audit Fields' (UiPath.DataService.Activities.CreateEntity) requires developer implementation — missing: EntityObject\"",
      "parsedIntentType": "pre-assembly:literal",
      "normalizedOutput": "[\"[HANDOFF] Activity 'Create New BGYY_BirthdaySendLog Record with All Audit Fields' (UiPath.DataService.Activities.CreateEntity) requires developer implementation — missing: EntityObject\"]",
      "fallbackUsed": false,
      "finalValueHash": "a726230bda71a1db7e3605d1b2447c021e97fb16d41f1ceba0d743fbc3930d10"
    },
    {
      "workflowFile": "BGYY_WriteDedupe.xaml",
      "activityType": "Assign",
      "propertyName": "Value",
      "originalRawValue": "ex_CreateException",
      "parsedIntentType": "pre-assembly:literal",
      "normalizedOutput": "\"ex_CreateException\"",
      "fallbackUsed": false,
      "finalValueHash": "db6bef5c61cba2d8a4547e07ba5e7597a529958fa4dde19f308aa3d5a6883426"
    },
    {
      "workflowFile": "BGYY_WriteDedupe.xaml",
      "activityType": "LogMessage",
      "propertyName": "Level",
      "originalRawValue": "Error",
      "parsedIntentType": "pre-assembly:literal",
      "normalizedOutput": "\"Error\"",
      "fallbackUsed": false,
      "finalValueHash": "fc4ac19649f0ee8f37c71d2e2030a3743038bb96c0c27359ba115dd8657565cc"
    },
    {
      "workflowFile": "BGYY_WriteDedupe.xaml",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "originalRawValue": "[BGYY_WriteDedupe][CreateError] PersonKey=\" & str_PersonKeyNormalized & \" | Status=\" & InStatus & \" | CalendarEventId=\" & InCalendarEventId & \" | Error=\" & ex_CreateException.Message",
      "parsedIntentType": "pre-assembly:literal",
      "normalizedOutput": "[\"[BGYY_WriteDedupe][CreateError] PersonKey=\"\" & str_PersonKeyNormalized & \"\" | Status=\"\" & InStatus & \"\" | CalendarEventId=\"\" & InCalendarEventId & \"\" | Error=\"\" & ex_CreateException.Message\"]",
      "fallbackUsed": false,
      "finalValueHash": "cfaf08e779b2d4bca913964058c8f6b863c110178057093edb96a6d17592a219"
    },
    {
      "workflowFile": "BGYY_WriteDedupe.xaml",
      "activityType": "LogMessage",
      "propertyName": "Level",
      "originalRawValue": "Info",
      "parsedIntentType": "pre-assembly:literal",
      "normalizedOutput": "\"Info\"",
      "fallbackUsed": false,
      "finalValueHash": "6e68b62d2aa611a44f3e7a4cb7e23da9ad1cab1b6abb592bb2795b12fe63e51c"
    },
    {
      "workflowFile": "BGYY_WriteDedupe.xaml",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "originalRawValue": "[BGYY_WriteDedupe][CreateSuccess] PersonKey=\" & str_PersonKeyNormalized & \" | Status=\" & InStatus & \" | CalendarEventId=\" & InCalendarEventId & \" | GmailMessageId=\" & InGmailMessageId & \" | RunId=\" & InRunId",
      "parsedIntentType": "pre-assembly:literal",
      "normalizedOutput": "[\"[BGYY_WriteDedupe][CreateSuccess] PersonKey=\"\" & str_PersonKeyNormalized & \"\" | Status=\"\" & InStatus & \"\" | CalendarEventId=\"\" & InCalendarEventId & \"\" | GmailMessageId=\"\" & InGmailMessageId & \"\" | RunId=\"\" & InRunId\"]",
      "fallbackUsed": false,
      "finalValueHash": "92f34e83d61e6ecf48f5a61c788cbfeb4a1a9b2c21f7b317009f7e76df93d9b6"
    },
    {
      "workflowFile": "BGYY_WriteDedupe.xaml",
      "activityType": "LogMessage",
      "propertyName": "Level",
      "originalRawValue": "Info",
      "parsedIntentType": "pre-assembly:literal",
      "normalizedOutput": "\"Info\"",
      "fallbackUsed": false,
      "finalValueHash": "6e68b62d2aa611a44f3e7a4cb7e23da9ad1cab1b6abb592bb2795b12fe63e51c"
    },
    {
      "workflowFile": "BGYY_WriteDedupe.xaml",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "originalRawValue": "[BGYY_WriteDedupe][Exit] Completed for PersonKey=\" & str_PersonKeyNormalized & \" | SendYear=\" & InSendYear.ToString() & \" | FinalStatus=\" & InStatus",
      "parsedIntentType": "pre-assembly:literal",
      "normalizedOutput": "[\"[BGYY_WriteDedupe][Exit] Completed for PersonKey=\"\" & str_PersonKeyNormalized & \"\" | SendYear=\"\" & InSendYear.ToString() & \"\" | FinalStatus=\"\" & InStatus\"]",
      "fallbackUsed": false,
      "finalValueHash": "3aa8e9569202e68e2006510bb4440439edbbaa7feb3dbc1484fb01896617bac3"
    },
    {
      "workflowFile": "unknown",
      "activityType": "QueryEntity",
      "propertyName": "EntityType",
      "originalRawValue": "{\"type\":\"literal\",\"value\":\"BGYY_BirthdaySendLog\"}",
      "parsedIntentType": "literal",
      "normalizedOutput": "\"BGYY_BirthdaySendLog\"",
      "fallbackUsed": false,
      "finalValueHash": "b004731817a34b4b0811c2cd720f3a3479712719e123cd47f1a76b71faf3049f"
    },
    {
      "workflowFile": "unknown",
      "activityType": "QueryEntity",
      "propertyName": "Filter",
      "originalRawValue": "{\"type\":\"literal\",\"value\":\"\\\"PersonKey eq '\\\" & str_PersonKeyNormalized & \\\"' and SendYear eq \\\" & InSendYear.ToString()\"}",
      "parsedIntentType": "literal",
      "normalizedOutput": "[\"\"\"PersonKey eq '\"\" & str_PersonKeyNormalized & \"\"' and SendYear eq \"\" & InSendYear.ToString()\"]",
      "fallbackUsed": false,
      "finalValueHash": "1ec79720bb5ad6373d1f91165f22d53ac00a13a29a307fa8f376d11166b49fca"
    },
    {
      "workflowFile": "BGYY_CreateReviewTask.xaml",
      "activityType": "LogMessage",
      "propertyName": "Level",
      "originalRawValue": "Info",
      "parsedIntentType": "pre-assembly:literal",
      "normalizedOutput": "\"Info\"",
      "fallbackUsed": false,
      "finalValueHash": "6e68b62d2aa611a44f3e7a4cb7e23da9ad1cab1b6abb592bb2795b12fe63e51c"
    },
    {
      "workflowFile": "BGYY_CreateReviewTask.xaml",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "originalRawValue": "\"[BGYY_CreateReviewTask] START — RunId=\" & InRunId & \" | FullName=\" & InFullName & \" | EventId=\" & InEventId & \" | PersonKey=\" & InPersonKey & \" | SendYear=\" & InSendYear.ToString()",
      "parsedIntentType": "pre-assembly:literal",
      "normalizedOutput": "[\"\"\"[BGYY_CreateReviewTask] START — RunId=\"\" & InRunId & \"\" | FullName=\"\" & InFullName & \"\" | EventId=\"\" & InEventId & \"\" | PersonKey=\"\" & InPersonKey & \"\" | SendYear=\"\" & InSendYear.ToString()\"]",
      "fallbackUsed": false,
      "finalValueHash": "a9f933723760360e62169c44e3c92ed874c3979b3d989db084fee221d8466c7f"
    },
    {
      "workflowFile": "BGYY_CreateReviewTask.xaml",
      "activityType": "InvokeWorkflowFile",
      "propertyName": "WorkflowFileName",
      "originalRawValue": "BGYY_WriteDedupe.xaml",
      "parsedIntentType": "pre-assembly:literal",
      "normalizedOutput": "\"BGYY_WriteDedupe.xaml\"",
      "fallbackUsed": false,
      "finalValueHash": "969cd2edb1325f7d74a291ec201d30efb201fc82e6470784c097fcd48a65f1ba"
    },
    {
      "workflowFile": "BGYY_CreateReviewTask.xaml",
      "activityType": "LogMessage",
      "propertyName": "Level",
      "originalRawValue": "Error",
      "parsedIntentType": "pre-assembly:literal",
      "normalizedOutput": "\"Error\"",
      "fallbackUsed": false,
      "finalValueHash": "fc4ac19649f0ee8f37c71d2e2030a3743038bb96c0c27359ba115dd8657565cc"
    },
    {
      "workflowFile": "BGYY_CreateReviewTask.xaml",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "originalRawValue": "\"Error in Write PendingReview status to Data Service via BGYY_WriteDedupe before task creation: \" & exception.Message",
      "parsedIntentType": "pre-assembly:literal",
      "normalizedOutput": "[\"\"\"Error in Write PendingReview status to Data Service via BGYY_WriteDedupe before task creation: \"\" & exception.Message\"]",
      "fallbackUsed": false,
      "finalValueHash": "f37c6a6898b6826fa713751fe890a9dcc0ee21ff95df73eafb3858cc64bb8f9a"
    },
    {
      "workflowFile": "BGYY_CreateReviewTask.xaml",
      "activityType": "LogMessage",
      "propertyName": "Level",
      "originalRawValue": "Info",
      "parsedIntentType": "pre-assembly:literal",
      "normalizedOutput": "\"Info\"",
      "fallbackUsed": false,
      "finalValueHash": "6e68b62d2aa611a44f3e7a4cb7e23da9ad1cab1b6abb592bb2795b12fe63e51c"
    },
    {
      "workflowFile": "BGYY_CreateReviewTask.xaml",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "originalRawValue": "\"[BGYY_CreateReviewTask] PendingReview dedupe record written — PersonKey=\" & InPersonKey & \" | Year=\" & InSendYear.ToString()",
      "parsedIntentType": "pre-assembly:literal",
      "normalizedOutput": "[\"\"\"[BGYY_CreateReviewTask] PendingReview dedupe record written — PersonKey=\"\" & InPersonKey & \"\" | Year=\"\" & InSendYear.ToString()\"]",
      "fallbackUsed": false,
      "finalValueHash": "d21f55846c7f6ea50ab2a35431b937c3cc70280903a12cb44aa4bf76f3633766"
    },
    {
      "workflowFile": "BGYY_CreateReviewTask.xaml",
      "activityType": "LogMessage",
      "propertyName": "Level",
      "originalRawValue": "Info",
      "parsedIntentType": "pre-assembly:literal",
      "normalizedOutput": "\"Info\"",
      "fallbackUsed": false,
      "finalValueHash": "6e68b62d2aa611a44f3e7a4cb7e23da9ad1cab1b6abb592bb2795b12fe63e51c"
    },
    {
      "workflowFile": "BGYY_CreateReviewTask.xaml",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "originalRawValue": "\"[BGYY_CreateReviewTask] Creating Action Center form task — Title=\" & taskTitle & \" | DueBy=\" & dueByTimestamp.ToString(\"yyyy-MM-ddTHH:mm:ssZ\")",
      "parsedIntentType": "pre-assembly:literal",
      "normalizedOutput": "[\"\"\"[BGYY_CreateReviewTask] Creating Action Center form task — Title=\"\" & taskTitle & \"\" | DueBy=\"\" & dueByTimestamp.ToString(\"\"yyyy-MM-ddTHH:mm:ssZ\"\")\"]",
      "fallbackUsed": false,
      "finalValueHash": "65a207a23074a4edbbd884693697d04d77f570a1459295784fb964abbaaf88f8"
    },
    {
      "workflowFile": "BGYY_CreateReviewTask.xaml",
      "activityType": "Comment",
      "propertyName": "Text",
      "originalRawValue": "[HANDOFF] This activity replaces \"Create BGYY_DraftReview Action Center form task with all required fields\" (UiPath.Persistence.Activities.CreateFormTask). Missing required properties: TaskTitle. Developer must implement the actual UiPath.Persistence.Activities.CreateFormTask activity with the correct property values.",
      "parsedIntentType": "pre-assembly:literal",
      "normalizedOutput": "[\"[HANDOFF] This activity replaces \"\"Create BGYY_DraftReview Action Center form task with all required fields\"\" (UiPath.Persistence.Activities.CreateFormTask). Missing required properties: TaskTitle. Developer must implement the actual UiPath.Persistence.Activities.CreateFormTask activity with the correct property values.\"]",
      "fallbackUsed": false,
      "finalValueHash": "80c0c1ed4322ce1165978c04239c72118dedeea53462da2321858a1f3ef2fcc6"
    },
    {
      "workflowFile": "BGYY_CreateReviewTask.xaml",
      "activityType": "LogMessage",
      "propertyName": "Level",
      "originalRawValue": "Warn",
      "parsedIntentType": "pre-assembly:literal",
      "normalizedOutput": "\"Warn\"",
      "fallbackUsed": false,
      "finalValueHash": "0817e2b865151b33aa686f0551fce818a034cb723e0044e433cd8100810ed280"
    },
    {
      "workflowFile": "BGYY_CreateReviewTask.xaml",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "originalRawValue": "\"[HANDOFF] Activity 'Create BGYY_DraftReview Action Center form task with all required fields' (UiPath.Persistence.Activities.CreateFormTask) requires developer implementation — missing: TaskTitle\"",
      "parsedIntentType": "pre-assembly:literal",
      "normalizedOutput": "[\"[HANDOFF] Activity 'Create BGYY_DraftReview Action Center form task with all required fields' (UiPath.Persistence.Activities.CreateFormTask) requires developer implementation — missing: TaskTitle\"]",
      "fallbackUsed": false,
      "finalValueHash": "71023b5225021e7d42707f89251982ad3a1e29bc2ef829b473d1f6d95771458b"
    },
    {
      "workflowFile": "BGYY_CreateReviewTask.xaml",
      "activityType": "LogMessage",
      "propertyName": "Level",
      "originalRawValue": "Error",
      "parsedIntentType": "pre-assembly:literal",
      "normalizedOutput": "\"Error\"",
      "fallbackUsed": false,
      "finalValueHash": "fc4ac19649f0ee8f37c71d2e2030a3743038bb96c0c27359ba115dd8657565cc"
    },
    {
      "workflowFile": "BGYY_CreateReviewTask.xaml",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "originalRawValue": "\"Error in Create BGYY_DraftReview Action Center form task with all required fields: \" & exception.Message",
      "parsedIntentType": "pre-assembly:literal",
      "normalizedOutput": "[\"\"\"Error in Create BGYY_DraftReview Action Center form task with all required fields: \"\" & exception.Message\"]",
      "fallbackUsed": false,
      "finalValueHash": "acdf1b7a7d6392455749507f39578ee4e470667e5798c0c31cb150221b18bc8a"
    },
    {
      "workflowFile": "BGYY_CreateReviewTask.xaml",
      "activityType": "LogMessage",
      "propertyName": "Level",
      "originalRawValue": "Info",
      "parsedIntentType": "pre-assembly:literal",
      "normalizedOutput": "\"Info\"",
      "fallbackUsed": false,
      "finalValueHash": "6e68b62d2aa611a44f3e7a4cb7e23da9ad1cab1b6abb592bb2795b12fe63e51c"
    },
    {
      "workflowFile": "BGYY_CreateReviewTask.xaml",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "originalRawValue": "\"[BGYY_CreateReviewTask] Action Center task created successfully — Title=\" & taskTitle & \" | DueBy=\" & dueByTimestamp.ToString(\"yyyy-MM-ddTHH:mm:ssZ\") & \" | PersonKey=\" & InPersonKey",
      "parsedIntentType": "pre-assembly:literal",
      "normalizedOutput": "[\"\"\"[BGYY_CreateReviewTask] Action Center task created successfully — Title=\"\" & taskTitle & \"\" | DueBy=\"\" & dueByTimestamp.ToString(\"\"yyyy-MM-ddTHH:mm:ssZ\"\") & \"\" | PersonKey=\"\" & InPersonKey\"]",
      "fallbackUsed": false,
      "finalValueHash": "11f3e1e360c23f36abc3a55230ff62589fef95e371890c26c9b9a7c970c31594"
    },
    {
      "workflowFile": "BGYY_CreateReviewTask.xaml",
      "activityType": "LogMessage",
      "propertyName": "Level",
      "originalRawValue": "Error",
      "parsedIntentType": "pre-assembly:literal",
      "normalizedOutput": "\"Error\"",
      "fallbackUsed": false,
      "finalValueHash": "fc4ac19649f0ee8f37c71d2e2030a3743038bb96c0c27359ba115dd8657565cc"
    },
    {
      "workflowFile": "BGYY_CreateReviewTask.xaml",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "originalRawValue": "\"[BGYY_CreateReviewTask] ESCALATION — Action Center task creation FAILED for PersonKey=\" & InPersonKey & \" | RunId=\" & InRunId & \" | FullName=\" & InFullName & \" | EventId=\" & InEventId & \". Item remains in PendingReview status in Data Service. Manual intervention required. DraftBody preserved in InDraftBody argument. Error=\" & actionCenterException",
      "parsedIntentType": "pre-assembly:literal",
      "normalizedOutput": "[\"\"\"[BGYY_CreateReviewTask] ESCALATION — Action Center task creation FAILED for PersonKey=\"\" & InPersonKey & \"\" | RunId=\"\" & InRunId & \"\" | FullName=\"\" & InFullName & \"\" | EventId=\"\" & InEventId & \"\". Item remains in PendingReview status in Data Service. Manual intervention required. DraftBody preserved in InDraftBody argument. Error=\"\" & actionCenterException\"]",
      "fallbackUsed": false,
      "finalValueHash": "272bfa31c1ec26a316b8e2315929660865d95c45e0592f29068adfefcee8e40f"
    },
    {
      "workflowFile": "BGYY_CreateReviewTask.xaml",
      "activityType": "LogMessage",
      "propertyName": "Level",
      "originalRawValue": "Info",
      "parsedIntentType": "pre-assembly:literal",
      "normalizedOutput": "\"Info\"",
      "fallbackUsed": false,
      "finalValueHash": "6e68b62d2aa611a44f3e7a4cb7e23da9ad1cab1b6abb592bb2795b12fe63e51c"
    },
    {
      "workflowFile": "BGYY_CreateReviewTask.xaml",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "originalRawValue": "\"[BGYY_CreateReviewTask] END — RunId=\" & InRunId & \" | PersonKey=\" & InPersonKey & \" | TaskCreated=\" & taskCreationSucceeded.ToString()",
      "parsedIntentType": "pre-assembly:literal",
      "normalizedOutput": "[\"\"\"[BGYY_CreateReviewTask] END — RunId=\"\" & InRunId & \"\" | PersonKey=\"\" & InPersonKey & \"\" | TaskCreated=\"\" & taskCreationSucceeded.ToString()\"]",
      "fallbackUsed": false,
      "finalValueHash": "8b58256ea52538884560ea014c7c1bf1ba4c058adb7d346ff889bca74fbcd048"
    },
    {
      "workflowFile": "BGYY_Main.xaml",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "originalRawValue": "[BGYY_Main] Workflow started. Initializing run context.",
      "parsedIntentType": "pre-assembly:literal",
      "normalizedOutput": "\"[BGYY_Main] Workflow started. Initializing run context.\"",
      "fallbackUsed": false,
      "finalValueHash": "a12a60cde9f015cae9ef8125fb365b94ffcc23c846bf12e576a7ef79aff36302"
    },
    {
      "workflowFile": "BGYY_Main.xaml",
      "activityType": "LogMessage",
      "propertyName": "Level",
      "originalRawValue": "Info",
      "parsedIntentType": "pre-assembly:literal",
      "normalizedOutput": "\"Info\"",
      "fallbackUsed": false,
      "finalValueHash": "6e68b62d2aa611a44f3e7a4cb7e23da9ad1cab1b6abb592bb2795b12fe63e51c"
    },
    {
      "workflowFile": "BGYY_Main.xaml",
      "activityType": "LogMessage",
      "propertyName": "Level",
      "originalRawValue": "Error",
      "parsedIntentType": "pre-assembly:literal",
      "normalizedOutput": "\"Error\"",
      "fallbackUsed": false,
      "finalValueHash": "fc4ac19649f0ee8f37c71d2e2030a3743038bb96c0c27359ba115dd8657565cc"
    },
    {
      "workflowFile": "BGYY_Main.xaml",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "originalRawValue": "\"Error in Resolve Eastern TimeZone info object: \" & exception.Message",
      "parsedIntentType": "pre-assembly:literal",
      "normalizedOutput": "[\"\"\"Error in Resolve Eastern TimeZone info object: \"\" & exception.Message\"]",
      "fallbackUsed": false,
      "finalValueHash": "c7df1aaf42e314c52c834740d202d02cc2ab0a40100b50c90f1167a20a3f9ff4"
    },
    {
      "workflowFile": "BGYY_Main.xaml",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "originalRawValue": "\"[BGYY_Main] RunId=\" & runId & \" | TodayEastern=\" & todayEastern.ToString(\"yyyy-MM-dd\") & \" | SendYear=\" & sendYear.ToString()",
      "parsedIntentType": "pre-assembly:literal",
      "normalizedOutput": "[\"\"\"[BGYY_Main] RunId=\"\" & runId & \"\" | TodayEastern=\"\" & todayEastern.ToString(\"\"yyyy-MM-dd\"\") & \"\" | SendYear=\"\" & sendYear.ToString()\"]",
      "fallbackUsed": false,
      "finalValueHash": "7a2262a963202cd91bc51b07edc7f489da1822ef2e5a4ed499d2fa5f8a5e40dc"
    },
    {
      "workflowFile": "BGYY_Main.xaml",
      "activityType": "LogMessage",
      "propertyName": "Level",
      "originalRawValue": "Info",
      "parsedIntentType": "pre-assembly:literal",
      "normalizedOutput": "\"Info\"",
      "fallbackUsed": false,
      "finalValueHash": "6e68b62d2aa611a44f3e7a4cb7e23da9ad1cab1b6abb592bb2795b12fe63e51c"
    },
    {
      "workflowFile": "BGYY_Main.xaml",
      "activityType": "GetAsset",
      "propertyName": "AssetName",
      "originalRawValue": "BGYY_DryRun",
      "parsedIntentType": "pre-assembly:literal",
      "normalizedOutput": "\"BGYY_DryRun\"",
      "fallbackUsed": false,
      "finalValueHash": "beb5b97a17d99ba63c78b7dfb2431e875c688a90f25961b9435af2b41f091b01"
    },
    {
      "workflowFile": "BGYY_Main.xaml",
      "activityType": "LogMessage",
      "propertyName": "Level",
      "originalRawValue": "Error",
      "parsedIntentType": "pre-assembly:literal",
      "normalizedOutput": "\"Error\"",
      "fallbackUsed": false,
      "finalValueHash": "fc4ac19649f0ee8f37c71d2e2030a3743038bb96c0c27359ba115dd8657565cc"
    },
    {
      "workflowFile": "BGYY_Main.xaml",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "originalRawValue": "\"Error in Read BGYY_DryRun Orchestrator asset: \" & exception.Message",
      "parsedIntentType": "pre-assembly:literal",
      "normalizedOutput": "[\"\"\"Error in Read BGYY_DryRun Orchestrator asset: \"\" & exception.Message\"]",
      "fallbackUsed": false,
      "finalValueHash": "27551934e6a0496193030459e63d4067bec3c15cb512df263752842307dafeae"
    },
    {
      "workflowFile": "BGYY_Main.xaml",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "originalRawValue": "\"[BGYY_Main] DryRun mode=\" & isDryRun.ToString() & \". Emails will\" & If(isDryRun, \" NOT\", \"\") & \" be sent.\"",
      "parsedIntentType": "pre-assembly:literal",
      "normalizedOutput": "[\"[BGYY_Main] DryRun mode=\"\" & isDryRun.ToString() & \"\". Emails will\"\" & If(isDryRun, \"\" NOT\"\", \"\") & \"\" be sent.\"]",
      "fallbackUsed": false,
      "finalValueHash": "cef47db626c6379a0fa97114484c8b81ef6d46de801be14a4320cda328426955"
    },
    {
      "workflowFile": "BGYY_Main.xaml",
      "activityType": "LogMessage",
      "propertyName": "Level",
      "originalRawValue": "Info",
      "parsedIntentType": "pre-assembly:literal",
      "normalizedOutput": "\"Info\"",
      "fallbackUsed": false,
      "finalValueHash": "6e68b62d2aa611a44f3e7a4cb7e23da9ad1cab1b6abb592bb2795b12fe63e51c"
    },
    {
      "workflowFile": "BGYY_Main.xaml",
      "activityType": "InvokeWorkflowFile",
      "propertyName": "WorkflowFileName",
      "originalRawValue": "BGYY_GetTodaysBirthdays.xaml",
      "parsedIntentType": "pre-assembly:literal",
      "normalizedOutput": "\"BGYY_GetTodaysBirthdays.xaml\"",
      "fallbackUsed": false,
      "finalValueHash": "9ed994ce22116c1c822fc7439ec25681df50a1ab4084caeeb45efc5ae8a72226"
    },
    {
      "workflowFile": "BGYY_Main.xaml",
      "activityType": "LogMessage",
      "propertyName": "Level",
      "originalRawValue": "Error",
      "parsedIntentType": "pre-assembly:literal",
      "normalizedOutput": "\"Error\"",
      "fallbackUsed": false,
      "finalValueHash": "fc4ac19649f0ee8f37c71d2e2030a3743038bb96c0c27359ba115dd8657565cc"
    },
    {
      "workflowFile": "BGYY_Main.xaml",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "originalRawValue": "\"Error in Invoke BGYY_GetTodaysBirthdays to retrieve today's events: \" & exception.Message",
      "parsedIntentType": "pre-assembly:literal",
      "normalizedOutput": "[\"\"\"Error in Invoke BGYY_GetTodaysBirthdays to retrieve today's events: \"\" & exception.Message\"]",
      "fallbackUsed": false,
      "finalValueHash": "3ef676dd2bf188e45670823cd324e5613e15ab78e24e450dc4b83f04dc7bcdb9"
    },
    {
      "workflowFile": "BGYY_Main.xaml",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "originalRawValue": "\"[BGYY_Main] Total birthday events retrieved for \" & todayEastern.ToString(\"yyyy-MM-dd\") & \": \" & totalEvents.ToString()",
      "parsedIntentType": "pre-assembly:literal",
      "normalizedOutput": "[\"\"\"[BGYY_Main] Total birthday events retrieved for \"\" & todayEastern.ToString(\"\"yyyy-MM-dd\"\") & \"\": \"\" & totalEvents.ToString()\"]",
      "fallbackUsed": false,
      "finalValueHash": "c417c8e7495eebd73e1820eef41c8cab130b44fbca9c4476953f22d10f0cbf6e"
    },
    {
      "workflowFile": "BGYY_Main.xaml",
      "activityType": "LogMessage",
      "propertyName": "Level",
      "originalRawValue": "Info",
      "parsedIntentType": "pre-assembly:literal",
      "normalizedOutput": "\"Info\"",
      "fallbackUsed": false,
      "finalValueHash": "6e68b62d2aa611a44f3e7a4cb7e23da9ad1cab1b6abb592bb2795b12fe63e51c"
    },
    {
      "workflowFile": "BGYY_Main.xaml",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "originalRawValue": "\"[BGYY_Main] No birthday events found for \" & todayEastern.ToString(\"yyyy-MM-dd\") & \". Run \" & runId & \" completed cleanly with no action.\"",
      "parsedIntentType": "pre-assembly:literal",
      "normalizedOutput": "[\"[BGYY_Main] No birthday events found for \"\" & todayEastern.ToString(\"\"yyyy-MM-dd\"\") & \"\". Run \"\" & runId & \"\" completed cleanly with no action.\"]",
      "fallbackUsed": false,
      "finalValueHash": "ca3d553b73569dfa115b16528a34b733f5080a3a3f61d03239913477c53af80b"
    },
    {
      "workflowFile": "BGYY_Main.xaml",
      "activityType": "LogMessage",
      "propertyName": "Level",
      "originalRawValue": "Info",
      "parsedIntentType": "pre-assembly:literal",
      "normalizedOutput": "\"Info\"",
      "fallbackUsed": false,
      "finalValueHash": "6e68b62d2aa611a44f3e7a4cb7e23da9ad1cab1b6abb592bb2795b12fe63e51c"
    },
    {
      "workflowFile": "BGYY_Main.xaml",
      "activityType": "LogMessage",
      "propertyName": "Level",
      "originalRawValue": "Error",
      "parsedIntentType": "pre-assembly:literal",
      "normalizedOutput": "\"Error\"",
      "fallbackUsed": false,
      "finalValueHash": "fc4ac19649f0ee8f37c71d2e2030a3743038bb96c0c27359ba115dd8657565cc"
    },
    {
      "workflowFile": "BGYY_Main.xaml",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "originalRawValue": "\"Error in Extract FullName and EventId from current event object: \" & exception.Message",
      "parsedIntentType": "pre-assembly:literal",
      "normalizedOutput": "[\"\"\"Error in Extract FullName and EventId from current event object: \"\" & exception.Message\"]",
      "fallbackUsed": false,
      "finalValueHash": "612de8c4f08cdfe238c77ae8177d3bb925ac49d8c4c1bf5e5f416efac35672a7"
    },
    {
      "workflowFile": "BGYY_Main.xaml",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "originalRawValue": "\"[BGYY_Main] Processing event \" & currentEventId & \" | FullName='\" & currentFullName & \"' | OccurrenceStart=\" & currentOccurrenceStart.ToString(\"yyyy-MM-dd\")",
      "parsedIntentType": "pre-assembly:literal",
      "normalizedOutput": "[\"\"\"[BGYY_Main] Processing event \"\" & currentEventId & \"\" | FullName='\"\" & currentFullName & \"\"' | OccurrenceStart=\"\" & currentOccurrenceStart.ToString(\"\"yyyy-MM-dd\"\")\"]",
      "fallbackUsed": false,
      "finalValueHash": "c259ce980912d406ff09f420549cafca024808072b671622dee4a6e990b65bee"
    },
    {
      "workflowFile": "BGYY_Main.xaml",
      "activityType": "LogMessage",
      "propertyName": "Level",
      "originalRawValue": "Info",
      "parsedIntentType": "pre-assembly:literal",
      "normalizedOutput": "\"Info\"",
      "fallbackUsed": false,
      "finalValueHash": "6e68b62d2aa611a44f3e7a4cb7e23da9ad1cab1b6abb592bb2795b12fe63e51c"
    },
    {
      "workflowFile": "BGYY_Main.xaml",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "originalRawValue": "\"[BGYY_Main] WARN: Skipping EventId=\" & currentEventId & \" — FullName could not be extracted from event payload. Incrementing countFailed.\"",
      "parsedIntentType": "pre-assembly:literal",
      "normalizedOutput": "[\"[BGYY_Main] WARN: Skipping EventId=\"\" & currentEventId & \"\" — FullName could not be extracted from event payload. Incrementing countFailed.\"]",
      "fallbackUsed": false,
      "finalValueHash": "057cb0bea6cb21a69f5b45b893f0f1238f8342c08b2827cebe969e6f421519d6"
    },
    {
      "workflowFile": "BGYY_Main.xaml",
      "activityType": "LogMessage",
      "propertyName": "Level",
      "originalRawValue": "Warn",
      "parsedIntentType": "pre-assembly:literal",
      "normalizedOutput": "\"Warn\"",
      "fallbackUsed": false,
      "finalValueHash": "0817e2b865151b33aa686f0551fce818a034cb723e0044e433cd8100810ed280"
    },
    {
      "workflowFile": "BGYY_Main.xaml",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "originalRawValue": "\"[BGYY_Main] PersonKey='\" & personKey & \"' derived for FullName='\" & currentFullName & \"'\"",
      "parsedIntentType": "pre-assembly:literal",
      "normalizedOutput": "[\"[BGYY_Main] PersonKey='\"\" & personKey & \"\"' derived for FullName='\"\" & currentFullName & \"\"'\"]",
      "fallbackUsed": false,
      "finalValueHash": "e38a82a746ab28f48750e53a596f2f9948658149559755778ac9cc692a56bd5f"
    },
    {
      "workflowFile": "BGYY_Main.xaml",
      "activityType": "LogMessage",
      "propertyName": "Level",
      "originalRawValue": "Info",
      "parsedIntentType": "pre-assembly:literal",
      "normalizedOutput": "\"Info\"",
      "fallbackUsed": false,
      "finalValueHash": "6e68b62d2aa611a44f3e7a4cb7e23da9ad1cab1b6abb592bb2795b12fe63e51c"
    },
    {
      "workflowFile": "BGYY_Main.xaml",
      "activityType": "InvokeWorkflowFile",
      "propertyName": "WorkflowFileName",
      "originalRawValue": "BGYY_ResolveRecipient.xaml",
      "parsedIntentType": "pre-assembly:literal",
      "normalizedOutput": "\"BGYY_ResolveRecipient.xaml\"",
      "fallbackUsed": false,
      "finalValueHash": "5f1c6e4e33469cd7da4f4ac074891b182fa6de81bab620ccb978f8c15977338d"
    },
    {
      "workflowFile": "BGYY_Main.xaml",
      "activityType": "LogMessage",
      "propertyName": "Level",
      "originalRawValue": "Error",
      "parsedIntentType": "pre-assembly:literal",
      "normalizedOutput": "\"Error\"",
      "fallbackUsed": false,
      "finalValueHash": "fc4ac19649f0ee8f37c71d2e2030a3743038bb96c0c27359ba115dd8657565cc"
    },
    {
      "workflowFile": "BGYY_Main.xaml",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "originalRawValue": "\"Error in Invoke BGYY_ResolveRecipient to find contact email: \" & exception.Message",
      "parsedIntentType": "pre-assembly:literal",
      "normalizedOutput": "[\"\"\"Error in Invoke BGYY_ResolveRecipient to find contact email: \"\" & exception.Message\"]",
      "fallbackUsed": false,
      "finalValueHash": "7a2d0e38e94a957b7f54320f072eaf96f41ef2be4755c547fa962c86a3cbfe38"
    },
    {
      "workflowFile": "BGYY_Main.xaml",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "originalRawValue": "\"[BGYY_Main] WARN: Ambiguous contact match for FullName='\" & currentFullName & \"' EventId=\" & currentEventId & \". Creating Action Center review task.\"",
      "parsedIntentType": "pre-assembly:literal",
      "normalizedOutput": "[\"[BGYY_Main] WARN: Ambiguous contact match for FullName='\"\" & currentFullName & \"\"' EventId=\"\" & currentEventId & \"\". Creating Action Center review task.\"]",
      "fallbackUsed": false,
      "finalValueHash": "0474712b4152d28db0b22003f04cac1b18000cc301d953afe3d1e398fe49016c"
    },
    {
      "workflowFile": "BGYY_Main.xaml",
      "activityType": "LogMessage",
      "propertyName": "Level",
      "originalRawValue": "Warn",
      "parsedIntentType": "pre-assembly:literal",
      "normalizedOutput": "\"Warn\"",
      "fallbackUsed": false,
      "finalValueHash": "0817e2b865151b33aa686f0551fce818a034cb723e0044e433cd8100810ed280"
    },
    {
      "workflowFile": "BGYY_Main.xaml",
      "activityType": "InvokeWorkflowFile",
      "propertyName": "WorkflowFileName",
      "originalRawValue": "BGYY_CreateReviewTask.xaml",
      "parsedIntentType": "pre-assembly:literal",
      "normalizedOutput": "\"BGYY_CreateReviewTask.xaml\"",
      "fallbackUsed": false,
      "finalValueHash": "eaa3e57ad376f877fd503769d07f422ec8b6dea0fe341aff56f12b6b6fae4893"
    },
    {
      "workflowFile": "BGYY_Main.xaml",
      "activityType": "LogMessage",
      "propertyName": "Level",
      "originalRawValue": "Error",
      "parsedIntentType": "pre-assembly:literal",
      "normalizedOutput": "\"Error\"",
      "fallbackUsed": false,
      "finalValueHash": "fc4ac19649f0ee8f37c71d2e2030a3743038bb96c0c27359ba115dd8657565cc"
    },
    {
      "workflowFile": "BGYY_Main.xaml",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "originalRawValue": "\"Error in Invoke BGYY_CreateReviewTask for ambiguous contact match: \" & exception.Message",
      "parsedIntentType": "pre-assembly:literal",
      "normalizedOutput": "[\"\"\"Error in Invoke BGYY_CreateReviewTask for ambiguous contact match: \"\" & exception.Message\"]",
      "fallbackUsed": false,
      "finalValueHash": "abd802f3bcff0c3429f7edefdc53a5a9ff691d2cbd9f9abd85c8b34eed56af6f"
    },
    {
      "workflowFile": "BGYY_Main.xaml",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "originalRawValue": "\"[BGYY_Main] INFO: No personal/home email found for FullName='\" & currentFullName & \"' PersonKey='\" & personKey & \"'. Skipping — SkippedNoEmail.\"",
      "parsedIntentType": "pre-assembly:literal",
      "normalizedOutput": "[\"[BGYY_Main] INFO: No personal/home email found for FullName='\"\" & currentFullName & \"\"' PersonKey='\"\" & personKey & \"\"'. Skipping — SkippedNoEmail.\"]",
      "fallbackUsed": false,
      "finalValueHash": "75e74b6667b02337f4039e827b9bb51a46ec681931b24e5bc06603ffeab7d05b"
    },
    {
      "workflowFile": "BGYY_Main.xaml",
      "activityType": "LogMessage",
      "propertyName": "Level",
      "originalRawValue": "Info",
      "parsedIntentType": "pre-assembly:literal",
      "normalizedOutput": "\"Info\"",
      "fallbackUsed": false,
      "finalValueHash": "6e68b62d2aa611a44f3e7a4cb7e23da9ad1cab1b6abb592bb2795b12fe63e51c"
    },
    {
      "workflowFile": "BGYY_Main.xaml",
      "activityType": "InvokeWorkflowFile",
      "propertyName": "WorkflowFileName",
      "originalRawValue": "BGYY_WriteDedupe.xaml",
      "parsedIntentType": "pre-assembly:literal",
      "normalizedOutput": "\"BGYY_WriteDedupe.xaml\"",
      "fallbackUsed": false,
      "finalValueHash": "969cd2edb1325f7d74a291ec201d30efb201fc82e6470784c097fcd48a65f1ba"
    },
    {
      "workflowFile": "BGYY_Main.xaml",
      "activityType": "LogMessage",
      "propertyName": "Level",
      "originalRawValue": "Error",
      "parsedIntentType": "pre-assembly:literal",
      "normalizedOutput": "\"Error\"",
      "fallbackUsed": false,
      "finalValueHash": "fc4ac19649f0ee8f37c71d2e2030a3743038bb96c0c27359ba115dd8657565cc"
    },
    {
      "workflowFile": "BGYY_Main.xaml",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "originalRawValue": "\"Error in Write SkippedNoEmail dedupe record via BGYY_WriteDedupe: \" & exception.Message",
      "parsedIntentType": "pre-assembly:literal",
      "normalizedOutput": "[\"\"\"Error in Write SkippedNoEmail dedupe record via BGYY_WriteDedupe: \"\" & exception.Message\"]",
      "fallbackUsed": false,
      "finalValueHash": "3420b6053b3273f4c0bd97f488b3f62176870ae1822e3ee367a06424b476c9bf"
    },
    {
      "workflowFile": "BGYY_Main.xaml",
      "activityType": "InvokeWorkflowFile",
      "propertyName": "WorkflowFileName",
      "originalRawValue": "BGYY_CheckDedupe.xaml",
      "parsedIntentType": "pre-assembly:literal",
      "normalizedOutput": "\"BGYY_CheckDedupe.xaml\"",
      "fallbackUsed": false,
      "finalValueHash": "70823a7460e3f6031912529edf5ffa389662372f1e441e74b34dd87df31e6a8f"
    },
    {
      "workflowFile": "unknown",
      "activityType": "InvokeCode",
      "propertyName": "Code",
      "originalRawValue": "{\"type\":\"vb_expression\",\"value\":\"Dim eventDict = CType(currentEvent, Dictionary(Of String, Object))\\ncurrentFullName = If(eventDict.ContainsKey(\\\"FullName\\\"), eventDict(\\\"FullName\\\").ToString().Trim(), \\\"\\\")\\ncurrentEventId = If(eventDict.ContainsKey(\\\"EventId\\\"), eventDict(\\\"EventId\\\").ToString(), \\\"\\\")\\nIf eventDict.ContainsKey(\\\"OccurrenceStart\\\") AndAlso eventDict(\\\"OccurrenceStart\\\") IsNot Nothing Then\\n  currentOccurrenceStart = CType(eventDict(\\\"OccurrenceStart\\\"), DateTime)\\nEnd If\"}",
      "parsedIntentType": "vb_expression",
      "normalizedOutput": "[Dim eventDict = CType(currentEvent, Dictionary(Of String, Object))\ncurrentFullName = If(eventDict.ContainsKey(\"FullName\"), eventDict(\"FullName\").ToString().Trim(), \"\")\ncurrentEventId = If(eventDict.ContainsKey(\"EventId\"), eventDict(\"EventId\").ToString(), \"\")\nIf eventDict.ContainsKey(\"OccurrenceStart\") AndAlso eventDict(\"OccurrenceStart\") IsNot Nothing Then\n  currentOccurrenceStart = CType(eventDict(\"OccurrenceStart\"), DateTime)\nEnd If]",
      "fallbackUsed": false,
      "finalValueHash": "7831abd6364d4cba1a24418f7f38d38f0f9c560c638315c637cb9ca501fbbcea"
    },
    {
      "workflowFile": "unknown",
      "activityType": "InvokeCode",
      "propertyName": "Arguments",
      "originalRawValue": "{\"type\":\"vb_expression\",\"value\":\"New Dictionary(Of String, Object) From {{\\\"currentEvent\\\", currentEvent}, {\\\"currentFullName\\\", currentFullName}, {\\\"currentEventId\\\", currentEventId}, {\\\"currentOccurrenceStart\\\", currentOccurrenceStart}}\"}",
      "parsedIntentType": "vb_expression",
      "normalizedOutput": "[New Dictionary(Of String, Object) From {{\"currentEvent\", currentEvent}, {\"currentFullName\", currentFullName}, {\"currentEventId\", currentEventId}, {\"currentOccurrenceStart\", currentOccurrenceStart}}]",
      "fallbackUsed": false,
      "finalValueHash": "266dffd610e9b055995ce695b14247d1520aed20ac1e33c1b1295bfe85a08fe7"
    }
  ],
  "invokeContractTrace": [
    {
      "callerWorkflow": "BGYY_CreateReviewTask",
      "targetWorkflow": "BGYY_WriteDedupe",
      "targetDeclaredArguments": [
        "InPersonName",
        "InPersonKey",
        "InSelectedEmail",
        "InSendYear",
        "InStatus",
        "InCalendarEventId",
        "InGmailMessageId",
        "InSentTimestamp",
        "InFailureReason",
        "InRunId",
        "type",
        "value"
      ],
      "providedBindings": {
        "type": "[vb_expression]",
        "value": "[New Dictionary(Of String, Object) From { {&quot;InPersonName&quot;, InFullName}, {&quot;InPersonKey&quot;, InPersonKey}, {&quot;InSelectedEmail&quot;, InSelectedEmail}, {&quot;InSendYear&quot;, InSen"
      },
      "unknownTargetArguments": [],
      "missingRequiredArguments": [
        "InPersonName",
        "InPersonKey",
        "InSelectedEmail",
        "InSendYear",
        "InStatus",
        "InCalendarEventId",
        "InGmailMessageId",
        "InSentTimestamp",
        "InFailureReason",
        "InRunId"
      ],
      "undeclaredSymbols": [
        "vb_expression"
      ]
    },
    {
      "callerWorkflow": "BGYY_Main",
      "targetWorkflow": "BGYY_GetTodaysBirthdays",
      "targetDeclaredArguments": [
        "OutBirthdayEvents",
        "InRunId",
        "InTodayDateEt",
        "type",
        "value"
      ],
      "providedBindings": {
        "OutBirthdayEvents": "[OutBirthdayEvents]",
        "InRunId": "[InRunId]",
        "InTodayDateEt": "[InTodayDateEt]"
      },
      "unknownTargetArguments": [],
      "missingRequiredArguments": [
        "type",
        "value"
      ],
      "undeclaredSymbols": []
    },
    {
      "callerWorkflow": "BGYY_Main",
      "targetWorkflow": "BGYY_ResolveRecipient",
      "targetDeclaredArguments": [
        "InFullName",
        "InRunId",
        "OutSelectedEmail",
        "OutIsAmbiguous",
        "OutContactId",
        "type",
        "value"
      ],
      "providedBindings": {
        "InFullName": "[InFullName]",
        "InRunId": "[InRunId]",
        "OutSelectedEmail": "[OutSelectedEmail]",
        "OutIsAmbiguous": "[OutIsAmbiguous]",
        "OutContactId": "[OutContactId]"
      },
      "unknownTargetArguments": [],
      "missingRequiredArguments": [
        "type",
        "value"
      ],
      "undeclaredSymbols": []
    },
    {
      "callerWorkflow": "BGYY_Main",
      "targetWorkflow": "BGYY_CheckDedupe",
      "targetDeclaredArguments": [
        "InPersonKey",
        "InSendYear",
        "OutAlreadySent"
      ],
      "providedBindings": {
        "InPersonKey": "[InPersonKey]",
        "InSendYear": "[InSendYear]",
        "OutAlreadySent": "[OutAlreadySent]"
      },
      "unknownTargetArguments": [],
      "missingRequiredArguments": [],
      "undeclaredSymbols": []
    },
    {
      "callerWorkflow": "BGYY_Main",
      "targetWorkflow": "BGYY_GenerateAndValidateDraft",
      "targetDeclaredArguments": [
        "InFullName",
        "InRunId",
        "OutSubject",
        "OutBody",
        "OutDraftValid",
        "OutValidationReason"
      ],
      "providedBindings": {
        "InFullName": "[InFullName]",
        "InRunId": "[InRunId]",
        "OutSubject": "[OutSubject]",
        "OutBody": "[OutBody]",
        "OutDraftValid": "[OutDraftValid]",
        "OutValidationReason": "[OutValidationReason]"
      },
      "unknownTargetArguments": [],
      "missingRequiredArguments": [],
      "undeclaredSymbols": []
    },
    {
      "callerWorkflow": "BGYY_Main",
      "targetWorkflow": "BGYY_SendGmail",
      "targetDeclaredArguments": [
        "InRecipientEmail",
        "InSubject",
        "InBody",
        "InRunId",
        "OutGmailMessageId",
        "OutSendSucceeded"
      ],
      "providedBindings": {
        "InRecipientEmail": "[InRecipientEmail]",
        "InSubject": "[InSubject]",
        "InBody": "[InBody]",
        "InRunId": "[InRunId]",
        "OutGmailMessageId": "[OutGmailMessageId]",
        "OutSendSucceeded": "[OutSendSucceeded]"
      },
      "unknownTargetArguments": [],
      "missingRequiredArguments": [],
      "undeclaredSymbols": []
    },
    {
      "callerWorkflow": "BGYY_Main",
      "targetWorkflow": "BGYY_WriteDedupe",
      "targetDeclaredArguments": [
        "InPersonName",
        "InPersonKey",
        "InSelectedEmail",
        "InSendYear",
        "InStatus",
        "InCalendarEventId",
        "InGmailMessageId",
        "InSentTimestamp",
        "InFailureReason",
        "InRunId",
        "type",
        "value"
      ],
      "providedBindings": {
        "InPersonName": "[InPersonName]",
        "InPersonKey": "[InPersonKey]",
        "InSelectedEmail": "[InSelectedEmail]",
        "InSendYear": "[InSendYear]",
        "InStatus": "[InStatus]",
        "InCalendarEventId": "[InCalendarEventId]",
        "InGmailMessageId": "[InGmailMessageId]",
        "InSentTimestamp": "[InSentTimestamp]",
        "InFailureReason": "[InFailureReason]",
        "InRunId": "[InRunId]"
      },
      "unknownTargetArguments": [],
      "missingRequiredArguments": [
        "type",
        "value"
      ],
      "undeclaredSymbols": []
    },
    {
      "callerWorkflow": "BGYY_Main",
      "targetWorkflow": "BGYY_CreateReviewTask",
      "targetDeclaredArguments": [
        "InRunId",
        "InEventId",
        "InFullName",
        "InSelectedEmail",
        "InSubject",
        "InDraftBody",
        "InPersonKey",
        "InSendYear",
        "type",
        "value"
      ],
      "providedBindings": {
        "InRunId": "[InRunId]",
        "InEventId": "[InEventId]",
        "InFullName": "[InFullName]",
        "InSelectedEmail": "[InSelectedEmail]",
        "InSubject": "[InSubject]",
        "InDraftBody": "[InDraftBody]",
        "InPersonKey": "[InPersonKey]",
        "InSendYear": "[InSendYear]"
      },
      "unknownTargetArguments": [],
      "missingRequiredArguments": [
        "type",
        "value"
      ],
      "undeclaredSymbols": []
    },
    {
      "callerWorkflow": "Main",
      "targetWorkflow": "Init",
      "targetDeclaredArguments": [
        "in_Config",
        "io_Config"
      ],
      "providedBindings": {
        "Nothing": "[dict_Config]"
      },
      "unknownTargetArguments": [
        "Nothing"
      ],
      "missingRequiredArguments": [
        "in_Config"
      ],
      "undeclaredSymbols": []
    },
    {
      "callerWorkflow": "Main",
      "targetWorkflow": "GetTransactionData",
      "targetDeclaredArguments": [
        "in_QueueName",
        "out_TransactionItem",
        "io_TransactionNumber"
      ],
      "providedBindings": {
        "Nothing": "[int_TransactionNumber]"
      },
      "unknownTargetArguments": [
        "Nothing"
      ],
      "missingRequiredArguments": [
        "in_QueueName"
      ],
      "undeclaredSymbols": []
    },
    {
      "callerWorkflow": "Main",
      "targetWorkflow": "Process",
      "targetDeclaredArguments": [
        "in_TransactionItem"
      ],
      "providedBindings": {
        "Nothing": "[qi_TransactionItem]"
      },
      "unknownTargetArguments": [
        "Nothing"
      ],
      "missingRequiredArguments": [
        "in_TransactionItem"
      ],
      "undeclaredSymbols": []
    },
    {
      "callerWorkflow": "Main",
      "targetWorkflow": "SetTransactionStatus",
      "targetDeclaredArguments": [
        "in_TransactionItem",
        "in_Status",
        "in_ErrorMessage"
      ],
      "providedBindings": {
        "Nothing": "\"Successful\""
      },
      "unknownTargetArguments": [
        "Nothing"
      ],
      "missingRequiredArguments": [
        "in_TransactionItem",
        "in_Status",
        "in_ErrorMessage"
      ],
      "undeclaredSymbols": []
    },
    {
      "callerWorkflow": "Main",
      "targetWorkflow": "SetTransactionStatus",
      "targetDeclaredArguments": [
        "in_TransactionItem",
        "in_Status",
        "in_ErrorMessage"
      ],
      "providedBindings": {
        "Nothing": "\"Failed\""
      },
      "unknownTargetArguments": [
        "Nothing"
      ],
      "missingRequiredArguments": [
        "in_TransactionItem",
        "in_Status",
        "in_ErrorMessage"
      ],
      "undeclaredSymbols": []
    },
    {
      "callerWorkflow": "Main",
      "targetWorkflow": "CloseAllApplications",
      "targetDeclaredArguments": [],
      "providedBindings": {},
      "unknownTargetArguments": [],
      "missingRequiredArguments": [],
      "undeclaredSymbols": []
    },
    {
      "callerWorkflow": "Main",
      "targetWorkflow": "CloseAllApplications",
      "targetDeclaredArguments": [],
      "providedBindings": {},
      "unknownTargetArguments": [],
      "missingRequiredArguments": [],
      "undeclaredSymbols": []
    },
    {
      "callerWorkflow": "CloseAllApplications",
      "targetWorkflow": "KillAllProcesses",
      "targetDeclaredArguments": [],
      "providedBindings": {},
      "unknownTargetArguments": [],
      "missingRequiredArguments": [],
      "undeclaredSymbols": []
    },
    {
      "callerWorkflow": "Init",
      "targetWorkflow": "InitAllSettings",
      "targetDeclaredArguments": [
        "out_Config"
      ],
      "providedBindings": {
        "Nothing": "[dict_Config]"
      },
      "unknownTargetArguments": [
        "Nothing"
      ],
      "missingRequiredArguments": [],
      "undeclaredSymbols": []
    },
    {
      "callerWorkflow": "Process",
      "targetWorkflow": "BGYY_Main",
      "targetDeclaredArguments": [],
      "providedBindings": {},
      "unknownTargetArguments": [],
      "missingRequiredArguments": [],
      "undeclaredSymbols": []
    },
    {
      "callerWorkflow": "BGYY_CreateReviewTask.xaml",
      "targetWorkflow": "BGYY_WriteDedupe",
      "targetDeclaredArguments": [
        "InPersonName",
        "InPersonKey",
        "InSelectedEmail",
        "InSendYear",
        "InStatus",
        "InCalendarEventId",
        "InGmailMessageId",
        "InSentTimestamp",
        "InFailureReason",
        "InRunId",
        "type",
        "value"
      ],
      "providedBindings": {
        "type": "[vb_expression]",
        "value": "[New Dictionary(Of String, Object) From { {&quot;InPersonName&quot;, InFullName}, {&quot;InPersonKey&quot;, InPersonKey}, {&quot;InSelectedEmail&quot;, InSelectedEmail}, {&quot;InSendYear&quot;, InSendYear}, {&quot;InStatus&quot;, &quot;PendingReview&quot;}, {&quot;InCalendarEventId&quot;, InEventId}, {&quot;InGmailMessageId&quot;, &quot;&quot;}, {&quot;InSentTimestamp&quot;, Nothing}, {&quot;InFailureReason&quot;, str_WriteDedupeFailureReason}, {&quot;InRunId&quot;, InRunId} }]"
      },
      "unknownTargetArguments": [],
      "missingRequiredArguments": [
        "InPersonName",
        "InPersonKey",
        "InSelectedEmail",
        "InSendYear",
        "InStatus",
        "InCalendarEventId",
        "InGmailMessageId",
        "InSentTimestamp",
        "InFailureReason",
        "InRunId"
      ],
      "undeclaredSymbols": [
        "vb_expression"
      ]
    },
    {
      "callerWorkflow": "BGYY_Main.xaml",
      "targetWorkflow": "BGYY_GetTodaysBirthdays",
      "targetDeclaredArguments": [
        "OutBirthdayEvents",
        "InRunId",
        "InTodayDateEt",
        "type",
        "value"
      ],
      "providedBindings": {
        "OutBirthdayEvents": "[OutBirthdayEvents]",
        "InRunId": "[InRunId]",
        "InTodayDateEt": "[InTodayDateEt]"
      },
      "unknownTargetArguments": [],
      "missingRequiredArguments": [
        "type",
        "value"
      ],
      "undeclaredSymbols": []
    },
    {
      "callerWorkflow": "BGYY_Main.xaml",
      "targetWorkflow": "BGYY_ResolveRecipient",
      "targetDeclaredArguments": [
        "InFullName",
        "InRunId",
        "OutSelectedEmail",
        "OutIsAmbiguous",
        "OutContactId",
        "type",
        "value"
      ],
      "providedBindings": {
        "InFullName": "[InFullName]",
        "InRunId": "[InRunId]",
        "OutSelectedEmail": "[OutSelectedEmail]",
        "OutIsAmbiguous": "[OutIsAmbiguous]",
        "OutContactId": "[OutContactId]"
      },
      "unknownTargetArguments": [],
      "missingRequiredArguments": [
        "type",
        "value"
      ],
      "undeclaredSymbols": []
    },
    {
      "callerWorkflow": "BGYY_Main.xaml",
      "targetWorkflow": "BGYY_CheckDedupe",
      "targetDeclaredArguments": [
        "InPersonKey",
        "InSendYear",
        "OutAlreadySent"
      ],
      "providedBindings": {
        "InPersonKey": "[InPersonKey]",
        "InSendYear": "[InSendYear]",
        "OutAlreadySent": "[OutAlreadySent]"
      },
      "unknownTargetArguments": [],
      "missingRequiredArguments": [],
      "undeclaredSymbols": []
    },
    {
      "callerWorkflow": "BGYY_Main.xaml",
      "targetWorkflow": "BGYY_GenerateAndValidateDraft",
      "targetDeclaredArguments": [
        "InFullName",
        "InRunId",
        "OutSubject",
        "OutBody",
        "OutDraftValid",
        "OutValidationReason"
      ],
      "providedBindings": {
        "InFullName": "[InFullName]",
        "InRunId": "[InRunId]",
        "OutSubject": "[OutSubject]",
        "OutBody": "[OutBody]",
        "OutDraftValid": "[OutDraftValid]",
        "OutValidationReason": "[OutValidationReason]"
      },
      "unknownTargetArguments": [],
      "missingRequiredArguments": [],
      "undeclaredSymbols": []
    },
    {
      "callerWorkflow": "BGYY_Main.xaml",
      "targetWorkflow": "BGYY_SendGmail",
      "targetDeclaredArguments": [
        "InRecipientEmail",
        "InSubject",
        "InBody",
        "InRunId",
        "OutGmailMessageId",
        "OutSendSucceeded"
      ],
      "providedBindings": {
        "InRecipientEmail": "[InRecipientEmail]",
        "InSubject": "[InSubject]",
        "InBody": "[InBody]",
        "InRunId": "[InRunId]",
        "OutGmailMessageId": "[OutGmailMessageId]",
        "OutSendSucceeded": "[OutSendSucceeded]"
      },
      "unknownTargetArguments": [],
      "missingRequiredArguments": [],
      "undeclaredSymbols": []
    },
    {
      "callerWorkflow": "BGYY_Main.xaml",
      "targetWorkflow": "BGYY_WriteDedupe",
      "targetDeclaredArguments": [
        "InPersonName",
        "InPersonKey",
        "InSelectedEmail",
        "InSendYear",
        "InStatus",
        "InCalendarEventId",
        "InGmailMessageId",
        "InSentTimestamp",
        "InFailureReason",
        "InRunId",
        "type",
        "value"
      ],
      "providedBindings": {
        "InPersonName": "[InPersonName]",
        "InPersonKey": "[InPersonKey]",
        "InSelectedEmail": "[InSelectedEmail]",
        "InSendYear": "[InSendYear]",
        "InStatus": "[InStatus]",
        "InCalendarEventId": "[InCalendarEventId]",
        "InGmailMessageId": "[InGmailMessageId]",
        "InSentTimestamp": "[InSentTimestamp]",
        "InFailureReason": "[InFailureReason]",
        "InRunId": "[InRunId]"
      },
      "unknownTargetArguments": [],
      "missingRequiredArguments": [
        "type",
        "value"
      ],
      "undeclaredSymbols": []
    },
    {
      "callerWorkflow": "BGYY_Main.xaml",
      "targetWorkflow": "BGYY_CreateReviewTask",
      "targetDeclaredArguments": [
        "InRunId",
        "InEventId",
        "InFullName",
        "InSelectedEmail",
        "InSubject",
        "InDraftBody",
        "InPersonKey",
        "InSendYear",
        "type",
        "value"
      ],
      "providedBindings": {
        "InRunId": "[InRunId]",
        "InEventId": "[InEventId]",
        "InFullName": "[InFullName]",
        "InSelectedEmail": "[InSelectedEmail]",
        "InSubject": "[InSubject]",
        "InDraftBody": "[InDraftBody]",
        "InPersonKey": "[InPersonKey]",
        "InSendYear": "[InSendYear]"
      },
      "unknownTargetArguments": [],
      "missingRequiredArguments": [
        "type",
        "value"
      ],
      "undeclaredSymbols": []
    },
    {
      "callerWorkflow": "Main.xaml",
      "targetWorkflow": "Init",
      "targetDeclaredArguments": [
        "in_Config",
        "io_Config"
      ],
      "providedBindings": {
        "Nothing": "[dict_Config]"
      },
      "unknownTargetArguments": [
        "Nothing"
      ],
      "missingRequiredArguments": [
        "in_Config"
      ],
      "undeclaredSymbols": []
    },
    {
      "callerWorkflow": "Main.xaml",
      "targetWorkflow": "GetTransactionData",
      "targetDeclaredArguments": [
        "in_QueueName",
        "out_TransactionItem",
        "io_TransactionNumber"
      ],
      "providedBindings": {
        "Nothing": "[int_TransactionNumber]"
      },
      "unknownTargetArguments": [
        "Nothing"
      ],
      "missingRequiredArguments": [
        "in_QueueName"
      ],
      "undeclaredSymbols": []
    },
    {
      "callerWorkflow": "Main.xaml",
      "targetWorkflow": "Process",
      "targetDeclaredArguments": [
        "in_TransactionItem"
      ],
      "providedBindings": {
        "Nothing": "[qi_TransactionItem]"
      },
      "unknownTargetArguments": [
        "Nothing"
      ],
      "missingRequiredArguments": [
        "in_TransactionItem"
      ],
      "undeclaredSymbols": []
    },
    {
      "callerWorkflow": "Main.xaml",
      "targetWorkflow": "SetTransactionStatus",
      "targetDeclaredArguments": [
        "in_TransactionItem",
        "in_Status",
        "in_ErrorMessage"
      ],
      "providedBindings": {
        "Nothing": "\"Successful\""
      },
      "unknownTargetArguments": [
        "Nothing",
        "Nothing"
      ],
      "missingRequiredArguments": [
        "in_TransactionItem",
        "in_Status",
        "in_ErrorMessage",
        "in_TransactionItem",
        "in_Status",
        "in_ErrorMessage"
      ],
      "undeclaredSymbols": []
    },
    {
      "callerWorkflow": "Main.xaml",
      "targetWorkflow": "SetTransactionStatus",
      "targetDeclaredArguments": [
        "in_TransactionItem",
        "in_Status",
        "in_ErrorMessage"
      ],
      "providedBindings": {
        "Nothing": "\"Failed\""
      },
      "unknownTargetArguments": [
        "Nothing",
        "Nothing"
      ],
      "missingRequiredArguments": [
        "in_TransactionItem",
        "in_Status",
        "in_ErrorMessage",
        "in_TransactionItem",
        "in_Status",
        "in_ErrorMessage"
      ],
      "undeclaredSymbols": []
    },
    {
      "callerWorkflow": "Main.xaml",
      "targetWorkflow": "CloseAllApplications",
      "targetDeclaredArguments": [],
      "providedBindings": {},
      "unknownTargetArguments": [],
      "missingRequiredArguments": [],
      "undeclaredSymbols": []
    },
    {
      "callerWorkflow": "Main.xaml",
      "targetWorkflow": "CloseAllApplications",
      "targetDeclaredArguments": [],
      "providedBindings": {},
      "unknownTargetArguments": [],
      "missingRequiredArguments": [],
      "undeclaredSymbols": []
    },
    {
      "callerWorkflow": "CloseAllApplications.xaml",
      "targetWorkflow": "KillAllProcesses",
      "targetDeclaredArguments": [],
      "providedBindings": {},
      "unknownTargetArguments": [],
      "missingRequiredArguments": [],
      "undeclaredSymbols": []
    },
    {
      "callerWorkflow": "Init.xaml",
      "targetWorkflow": "InitAllSettings",
      "targetDeclaredArguments": [
        "out_Config"
      ],
      "providedBindings": {
        "Nothing": "[dict_Config]"
      },
      "unknownTargetArguments": [
        "Nothing"
      ],
      "missingRequiredArguments": [],
      "undeclaredSymbols": []
    },
    {
      "callerWorkflow": "Process.xaml",
      "targetWorkflow": "BGYY_Main",
      "targetDeclaredArguments": [],
      "providedBindings": {},
      "unknownTargetArguments": [],
      "missingRequiredArguments": [],
      "undeclaredSymbols": []
    }
  ],
  "stageHashParity": [
    {
      "workflowFile": "BGYY_GetTodaysBirthdays.xaml",
      "postGeneration": "7b83a04978a0a26db931d3401bc69c2cf6bf9782983f36ceef4f83abf616e6a6",
      "postRepair": "7b83a04978a0a26db931d3401bc69c2cf6bf9782983f36ceef4f83abf616e6a6",
      "postNormalization": "75259f4bc89c89761428d10bef48d25625dc21bba8333134666d61bc192dd9d5",
      "preCanonicalization": "c2fa9c672f290699743fc75d4536d5cd1740b067179c568ae1228b06ee364976",
      "archivedFile": "c2fa9c672f290699743fc75d4536d5cd1740b067179c568ae1228b06ee364976",
      "postFinalValidationInput": "c2fa9c672f290699743fc75d4536d5cd1740b067179c568ae1228b06ee364976",
      "preArchive": "c2fa9c672f290699743fc75d4536d5cd1740b067179c568ae1228b06ee364976"
    },
    {
      "workflowFile": "BGYY_ResolveRecipient.xaml",
      "postGeneration": "9686a80311c874f6528f2172b0432686a61a1f1849ad3970e80360421a850c03",
      "postRepair": "9686a80311c874f6528f2172b0432686a61a1f1849ad3970e80360421a850c03",
      "postNormalization": "fdeb5db62949bb95f47b6996fade6a75fae98e6aff5a2e59710cee3fc1ee6ff9",
      "preCanonicalization": "fdeb5db62949bb95f47b6996fade6a75fae98e6aff5a2e59710cee3fc1ee6ff9",
      "archivedFile": "f6875838432262b287c91b36cf6e85aaa3d6d6a4d43f75a58a07667ce21b5343",
      "postFinalValidationInput": "f6875838432262b287c91b36cf6e85aaa3d6d6a4d43f75a58a07667ce21b5343",
      "preArchive": "f6875838432262b287c91b36cf6e85aaa3d6d6a4d43f75a58a07667ce21b5343"
    },
    {
      "workflowFile": "BGYY_CheckDedupe.xaml",
      "postGeneration": "b0b94103c60beaa61854f302d49b69056bdf2186915748d38bb40f37bbd32079",
      "postRepair": "b0b94103c60beaa61854f302d49b69056bdf2186915748d38bb40f37bbd32079",
      "postNormalization": "b0b94103c60beaa61854f302d49b69056bdf2186915748d38bb40f37bbd32079",
      "preCanonicalization": "6761aefe642c29aa137b613c275fba0afb983be16bbd47918148b8e6226a3e77",
      "archivedFile": "6761aefe642c29aa137b613c275fba0afb983be16bbd47918148b8e6226a3e77",
      "postFinalValidationInput": "6761aefe642c29aa137b613c275fba0afb983be16bbd47918148b8e6226a3e77",
      "preArchive": "6761aefe642c29aa137b613c275fba0afb983be16bbd47918148b8e6226a3e77"
    },
    {
      "workflowFile": "BGYY_GenerateAndValidateDraft.xaml",
      "postGeneration": "f4a1279a72a26971308fe58f4be3decfe72298127887b1d5f8326a75c1c1d81b",
      "postRepair": "f4a1279a72a26971308fe58f4be3decfe72298127887b1d5f8326a75c1c1d81b",
      "postNormalization": "37c1583345252a8c95a23973e96dc82cdfc9f366a644abb0366d243771887218",
      "preCanonicalization": "f1b4926bbff149f12fae70aa4c9a3f7c2677c189561ed6179dedcdab68097250",
      "archivedFile": "8ed2ec0b2239eb39b1238ba50fb1b7dfcecddc53c8b599688f942c6903faf0f1",
      "postFinalValidationInput": "8ed2ec0b2239eb39b1238ba50fb1b7dfcecddc53c8b599688f942c6903faf0f1",
      "preArchive": "8ed2ec0b2239eb39b1238ba50fb1b7dfcecddc53c8b599688f942c6903faf0f1"
    },
    {
      "workflowFile": "BGYY_SendGmail.xaml",
      "postGeneration": "78c2deb3afb5d94e89c41c410ef012146208addacac079011f9b145b4e78fafc",
      "postRepair": "78c2deb3afb5d94e89c41c410ef012146208addacac079011f9b145b4e78fafc",
      "postNormalization": "78c2deb3afb5d94e89c41c410ef012146208addacac079011f9b145b4e78fafc",
      "preCanonicalization": "7397ecacf0a14285fb952e9e088d17d9a251e8b0086a101a89be416de5fe541e",
      "archivedFile": "426c8e12697c8f0a08935dd353d94125878a6d71c8f1ff6dbfd3f509c8bf664d",
      "postFinalValidationInput": "426c8e12697c8f0a08935dd353d94125878a6d71c8f1ff6dbfd3f509c8bf664d",
      "preArchive": "426c8e12697c8f0a08935dd353d94125878a6d71c8f1ff6dbfd3f509c8bf664d"
    },
    {
      "workflowFile": "BGYY_WriteDedupe.xaml",
      "postGeneration": "bdc04032bb27001dbe4fd29aae1e10ddfd6e1d967562762c276e34ad332804f2",
      "postRepair": "bdc04032bb27001dbe4fd29aae1e10ddfd6e1d967562762c276e34ad332804f2",
      "postNormalization": "604d473e4974b43e179b51fa0f3b27dc923ed024bc32e80fbff7d845e50ac63f",
      "preCanonicalization": "34f085255c36b50ffc8f02e9d1b4dac9b57454fbb75b2353d3d40c0b8f83fd8b",
      "archivedFile": "089627e583fd66ff6462c2048e581d7baa35f9e81454ca1e475dd145887081bd",
      "postFinalValidationInput": "089627e583fd66ff6462c2048e581d7baa35f9e81454ca1e475dd145887081bd",
      "preArchive": "089627e583fd66ff6462c2048e581d7baa35f9e81454ca1e475dd145887081bd"
    },
    {
      "workflowFile": "BGYY_CreateReviewTask.xaml",
      "postGeneration": "271b1ee6c1fd4ce27c6580a21d5f1c5a20a3e4a00a9f409c21651395e65d586a",
      "postRepair": "271b1ee6c1fd4ce27c6580a21d5f1c5a20a3e4a00a9f409c21651395e65d586a",
      "postNormalization": "ed94494bb6ca44672850f9a68b1c8bb7a115793c662ac91f39a458d63ef1d467",
      "preCanonicalization": "11b2e8e6542a23ec44a864643b2cbfbd401d6217bd0f7c149d8c349690b843c1",
      "archivedFile": "d73682bac379ee6856d048821da19b088ae49e942af9a84cc54660475828abbb",
      "postFinalValidationInput": "d73682bac379ee6856d048821da19b088ae49e942af9a84cc54660475828abbb",
      "preArchive": "d73682bac379ee6856d048821da19b088ae49e942af9a84cc54660475828abbb"
    },
    {
      "workflowFile": "BGYY_Main.xaml",
      "postGeneration": "17bdaebab7b35faed02ea310e8a454e35c069dfd54cb1d64ead8723d08ec212b",
      "postRepair": "17bdaebab7b35faed02ea310e8a454e35c069dfd54cb1d64ead8723d08ec212b",
      "postNormalization": "8d6790392709479a09573762b7c4c26c12deefbf5fd45e98ccba6d06246ca096",
      "preCanonicalization": "0df9398124779d39aeb14642fe3b4c3e113d3b66cd683c34ce0571fa4fe1fcf8",
      "archivedFile": "0df9398124779d39aeb14642fe3b4c3e113d3b66cd683c34ce0571fa4fe1fcf8",
      "postFinalValidationInput": "0df9398124779d39aeb14642fe3b4c3e113d3b66cd683c34ce0571fa4fe1fcf8",
      "preArchive": "0df9398124779d39aeb14642fe3b4c3e113d3b66cd683c34ce0571fa4fe1fcf8"
    },
    {
      "workflowFile": "InitAllSettings.xaml",
      "postGeneration": "6b48121106e1c9ac31dd6244c3205da00643feb4fa3a5d56d9567f996fd50a64",
      "postRepair": "6b48121106e1c9ac31dd6244c3205da00643feb4fa3a5d56d9567f996fd50a64",
      "postNormalization": "6087a678442506f7d5c4605df3fd7e596bc7877cc9ad933776c707b4725d1b75",
      "preCanonicalization": "e7bee23e7319943b5f7902ad849c8bfa210ad9f6340a9d0ccda071df6d65a490",
      "archivedFile": "e7bee23e7319943b5f7902ad849c8bfa210ad9f6340a9d0ccda071df6d65a490",
      "postFinalValidationInput": "e7bee23e7319943b5f7902ad849c8bfa210ad9f6340a9d0ccda071df6d65a490",
      "preArchive": "e7bee23e7319943b5f7902ad849c8bfa210ad9f6340a9d0ccda071df6d65a490"
    },
    {
      "workflowFile": "Main.xaml",
      "postGeneration": "1a6dd9d3fc80874a3d9a791f81c7596d340417bfd52f9b4c671a19aac48d9a4b",
      "postRepair": "1a6dd9d3fc80874a3d9a791f81c7596d340417bfd52f9b4c671a19aac48d9a4b",
      "postNormalization": "1a6dd9d3fc80874a3d9a791f81c7596d340417bfd52f9b4c671a19aac48d9a4b",
      "preCanonicalization": "1a6dd9d3fc80874a3d9a791f81c7596d340417bfd52f9b4c671a19aac48d9a4b",
      "archivedFile": "d4f3449872b830d3831785c8438ad72db99f567c8ecf58444dd18e17bedc869e",
      "postFinalValidationInput": "d4f3449872b830d3831785c8438ad72db99f567c8ecf58444dd18e17bedc869e",
      "preArchive": "d4f3449872b830d3831785c8438ad72db99f567c8ecf58444dd18e17bedc869e"
    },
    {
      "workflowFile": "GetTransactionData.xaml",
      "postGeneration": "ae9e65c2c93e179def93525794245989e6a716804435e9d8fe7eae93aba667d4",
      "postRepair": "ae9e65c2c93e179def93525794245989e6a716804435e9d8fe7eae93aba667d4",
      "postNormalization": "9fc0b0934e80d781cd088b0381229cf92545d8ffd5a4e713b793a0d7ba36c005",
      "preCanonicalization": "9fc0b0934e80d781cd088b0381229cf92545d8ffd5a4e713b793a0d7ba36c005",
      "archivedFile": "9fc0b0934e80d781cd088b0381229cf92545d8ffd5a4e713b793a0d7ba36c005",
      "postFinalValidationInput": "9fc0b0934e80d781cd088b0381229cf92545d8ffd5a4e713b793a0d7ba36c005",
      "preArchive": "9fc0b0934e80d781cd088b0381229cf92545d8ffd5a4e713b793a0d7ba36c005"
    },
    {
      "workflowFile": "Init.xaml",
      "postGeneration": "59937d8b7a8ccb91771dafe3273b012e5a2a6cbc0c3850c53980d22d718afc7a",
      "postRepair": "59937d8b7a8ccb91771dafe3273b012e5a2a6cbc0c3850c53980d22d718afc7a",
      "postNormalization": "59937d8b7a8ccb91771dafe3273b012e5a2a6cbc0c3850c53980d22d718afc7a",
      "preCanonicalization": "59937d8b7a8ccb91771dafe3273b012e5a2a6cbc0c3850c53980d22d718afc7a",
      "archivedFile": "f44213c3e46b46c17650f45dfdfe51edffafbd18cc4a5294d890a3dd0b9b38bf",
      "postFinalValidationInput": "f44213c3e46b46c17650f45dfdfe51edffafbd18cc4a5294d890a3dd0b9b38bf",
      "preArchive": "f44213c3e46b46c17650f45dfdfe51edffafbd18cc4a5294d890a3dd0b9b38bf"
    },
    {
      "workflowFile": "InitAllApplications.xaml",
      "postGeneration": "5f36dc6bc4b5d25fedaca0bffd9163b903302540d7dc7b4a36a287115312a16f",
      "postRepair": "5f36dc6bc4b5d25fedaca0bffd9163b903302540d7dc7b4a36a287115312a16f",
      "postNormalization": "5f36dc6bc4b5d25fedaca0bffd9163b903302540d7dc7b4a36a287115312a16f",
      "preCanonicalization": "5f36dc6bc4b5d25fedaca0bffd9163b903302540d7dc7b4a36a287115312a16f",
      "archivedFile": "5f36dc6bc4b5d25fedaca0bffd9163b903302540d7dc7b4a36a287115312a16f",
      "postFinalValidationInput": "5f36dc6bc4b5d25fedaca0bffd9163b903302540d7dc7b4a36a287115312a16f",
      "preArchive": "5f36dc6bc4b5d25fedaca0bffd9163b903302540d7dc7b4a36a287115312a16f"
    },
    {
      "workflowFile": "RetryCurrentTransaction.xaml",
      "postGeneration": "39a5fb546f369dfb49d80e1c32a3f49c55cfd1ac6baf5cf5ae440dae5ddd36b9",
      "postRepair": "39a5fb546f369dfb49d80e1c32a3f49c55cfd1ac6baf5cf5ae440dae5ddd36b9",
      "postNormalization": "39a5fb546f369dfb49d80e1c32a3f49c55cfd1ac6baf5cf5ae440dae5ddd36b9",
      "preCanonicalization": "39a5fb546f369dfb49d80e1c32a3f49c55cfd1ac6baf5cf5ae440dae5ddd36b9",
      "archivedFile": "39a5fb546f369dfb49d80e1c32a3f49c55cfd1ac6baf5cf5ae440dae5ddd36b9",
      "postFinalValidationInput": "39a5fb546f369dfb49d80e1c32a3f49c55cfd1ac6baf5cf5ae440dae5ddd36b9",
      "preArchive": "39a5fb546f369dfb49d80e1c32a3f49c55cfd1ac6baf5cf5ae440dae5ddd36b9"
    },
    {
      "workflowFile": "RetryInit.xaml",
      "postGeneration": "694f0ead7ed225e69d2248e8534176858cc1c159c406597e10e1a08bd8d7fa4b",
      "postRepair": "694f0ead7ed225e69d2248e8534176858cc1c159c406597e10e1a08bd8d7fa4b",
      "postNormalization": "694f0ead7ed225e69d2248e8534176858cc1c159c406597e10e1a08bd8d7fa4b",
      "preCanonicalization": "694f0ead7ed225e69d2248e8534176858cc1c159c406597e10e1a08bd8d7fa4b",
      "archivedFile": "694f0ead7ed225e69d2248e8534176858cc1c159c406597e10e1a08bd8d7fa4b",
      "postFinalValidationInput": "694f0ead7ed225e69d2248e8534176858cc1c159c406597e10e1a08bd8d7fa4b",
      "preArchive": "694f0ead7ed225e69d2248e8534176858cc1c159c406597e10e1a08bd8d7fa4b"
    }
  ],
  "preEmissionValidation": {
    "totalActivities": 190,
    "validActivities": 190,
    "unknownActivities": 0,
    "deprecatedActivities": 0,
    "nonEmissionApprovedActivities": 0,
    "targetIncompatibleActivities": 0,
    "strippedProperties": 41,
    "enumCorrections": 0,
    "missingRequiredFilled": 0,
    "commentConversions": 0,
    "issueCount": 26
  },
  "invokeSerializationFixes": [],
  "expressionCanonicalizationFixes": [],
  "symbolScopeDefects": [
    {
      "file": "lib/net45/BGYY_ResolveRecipient.xaml",
      "workflow": "BGYY_ResolveRecipient",
      "activityType": "If",
      "propertyName": "Condition",
      "referencedSymbol": "personal",
      "offendingExpression": "[str_CurrentEmailLabel = personal]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "False",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"personal\" referenced in Condition but not declared in workflow \"BGYY_ResolveRecipient\" — expression replaced with \"False\""
    },
    {
      "file": "lib/net45/BGYY_ResolveRecipient.xaml",
      "workflow": "BGYY_ResolveRecipient",
      "activityType": "If",
      "propertyName": "Condition",
      "referencedSymbol": "home",
      "offendingExpression": "[str_CurrentEmailLabel = home]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "False",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"home\" referenced in Condition but not declared in workflow \"BGYY_ResolveRecipient\" — expression replaced with \"False\""
    },
    {
      "file": "lib/net45/BGYY_GenerateAndValidateDraft.xaml",
      "workflow": "BGYY_GenerateAndValidateDraft",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "referencedSymbol": "BGYY_GenerateAndValidateDraft",
      "offendingExpression": "[BGYY_GenerateAndValidateDraft] VoiceProfile loaded=&quot; &amp; bool_VoiceProfileLoaded.ToString() &amp; &quot; ToneTags=&apos;&quot; &amp; voiceProfileToneTags &amp; &quot;&apos;",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"BGYY_GenerateAndValidateDraft\" referenced in Message but not declared in workflow \"BGYY_GenerateAndValidateDraft\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/BGYY_GenerateAndValidateDraft.xaml",
      "workflow": "BGYY_GenerateAndValidateDraft",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "referencedSymbol": "VoiceProfile",
      "offendingExpression": "[BGYY_GenerateAndValidateDraft] VoiceProfile loaded=&quot; &amp; bool_VoiceProfileLoaded.ToString() &amp; &quot; ToneTags=&apos;&quot; &amp; voiceProfileToneTags &amp; &quot;&apos;",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"VoiceProfile\" referenced in Message but not declared in workflow \"BGYY_GenerateAndValidateDraft\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/BGYY_GenerateAndValidateDraft.xaml",
      "workflow": "BGYY_GenerateAndValidateDraft",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "referencedSymbol": "loaded",
      "offendingExpression": "[BGYY_GenerateAndValidateDraft] VoiceProfile loaded=&quot; &amp; bool_VoiceProfileLoaded.ToString() &amp; &quot; ToneTags=&apos;&quot; &amp; voiceProfileToneTags &amp; &quot;&apos;",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"loaded\" referenced in Message but not declared in workflow \"BGYY_GenerateAndValidateDraft\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/BGYY_GenerateAndValidateDraft.xaml",
      "workflow": "BGYY_GenerateAndValidateDraft",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "referencedSymbol": "ToneTags",
      "offendingExpression": "[BGYY_GenerateAndValidateDraft] VoiceProfile loaded=&quot; &amp; bool_VoiceProfileLoaded.ToString() &amp; &quot; ToneTags=&apos;&quot; &amp; voiceProfileToneTags &amp; &quot;&apos;",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"ToneTags\" referenced in Message but not declared in workflow \"BGYY_GenerateAndValidateDraft\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/BGYY_GenerateAndValidateDraft.xaml",
      "workflow": "BGYY_GenerateAndValidateDraft",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "referencedSymbol": "parsedSubject",
      "offendingExpression": "&quot;[BGYY_GenerateAndValidateDraft] JSON parse success=&quot; &amp; bool_JsonParseSuccess.ToString() &amp; &quot; SubjectLen=&quot; &amp; parsedSubject.Length.ToString() &amp; &quot; BodyLen=&quot; ",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"parsedSubject\" referenced in Message but not declared in workflow \"BGYY_GenerateAndValidateDraft\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/BGYY_GenerateAndValidateDraft.xaml",
      "workflow": "BGYY_GenerateAndValidateDraft",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "referencedSymbol": "parsedBody",
      "offendingExpression": "&quot;[BGYY_GenerateAndValidateDraft] JSON parse success=&quot; &amp; bool_JsonParseSuccess.ToString() &amp; &quot; SubjectLen=&quot; &amp; parsedSubject.Length.ToString() &amp; &quot; BodyLen=&quot; ",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"parsedBody\" referenced in Message but not declared in workflow \"BGYY_GenerateAndValidateDraft\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/BGYY_GenerateAndValidateDraft.xaml",
      "workflow": "BGYY_GenerateAndValidateDraft",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "referencedSymbol": "validationPassed",
      "offendingExpression": "&quot;[BGYY_GenerateAndValidateDraft] ValidationPassed=&quot; &amp; bool_ValidationPassed.ToString() &amp; &quot; Reason=&apos;&quot; &amp; If(validationPassed, &quot;AllGatesPassed&quot;, validationF",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"validationPassed\" referenced in Message but not declared in workflow \"BGYY_GenerateAndValidateDraft\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/BGYY_GenerateAndValidateDraft.xaml",
      "workflow": "BGYY_GenerateAndValidateDraft",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "referencedSymbol": "validationFailReason",
      "offendingExpression": "&quot;[BGYY_GenerateAndValidateDraft] ValidationPassed=&quot; &amp; bool_ValidationPassed.ToString() &amp; &quot; Reason=&apos;&quot; &amp; If(validationPassed, &quot;AllGatesPassed&quot;, validationF",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"validationFailReason\" referenced in Message but not declared in workflow \"BGYY_GenerateAndValidateDraft\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/BGYY_SendGmail.xaml",
      "workflow": "BGYY_SendGmail",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "referencedSymbol": "gmailMessageId",
      "offendingExpression": "&quot;[BGYY_SendGmail] Email sent successfully | RunId=&quot; &amp; InRunId &amp; &quot; | Recipient=&quot; &amp; InRecipientEmail &amp; &quot; | MessageId=&quot; &amp; gmailMessageId &amp; &quot; | A",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"gmailMessageId\" referenced in Message but not declared in workflow \"BGYY_SendGmail\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/BGYY_WriteDedupe.xaml",
      "workflow": "BGYY_WriteDedupe",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "referencedSymbol": "BGYY_WriteDedupe",
      "offendingExpression": "[BGYY_WriteDedupe][QueryResult] PersonKey=&quot; &amp; str_PersonKeyNormalized &amp; &quot; | SendYear=&quot; &amp; InSendYear.ToString() &amp; &quot; | RecordFound=&quot; &amp; (obj_QueryResults IsNo",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"BGYY_WriteDedupe\" referenced in Message but not declared in workflow \"BGYY_WriteDedupe\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/BGYY_WriteDedupe.xaml",
      "workflow": "BGYY_WriteDedupe",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "referencedSymbol": "QueryResult",
      "offendingExpression": "[BGYY_WriteDedupe][QueryResult] PersonKey=&quot; &amp; str_PersonKeyNormalized &amp; &quot; | SendYear=&quot; &amp; InSendYear.ToString() &amp; &quot; | RecordFound=&quot; &amp; (obj_QueryResults IsNo",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"QueryResult\" referenced in Message but not declared in workflow \"BGYY_WriteDedupe\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/BGYY_WriteDedupe.xaml",
      "workflow": "BGYY_WriteDedupe",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "referencedSymbol": "PersonKey",
      "offendingExpression": "[BGYY_WriteDedupe][QueryResult] PersonKey=&quot; &amp; str_PersonKeyNormalized &amp; &quot; | SendYear=&quot; &amp; InSendYear.ToString() &amp; &quot; | RecordFound=&quot; &amp; (obj_QueryResults IsNo",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"PersonKey\" referenced in Message but not declared in workflow \"BGYY_WriteDedupe\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/BGYY_WriteDedupe.xaml",
      "workflow": "BGYY_WriteDedupe",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "referencedSymbol": "RecordFound",
      "offendingExpression": "[BGYY_WriteDedupe][QueryResult] PersonKey=&quot; &amp; str_PersonKeyNormalized &amp; &quot; | SendYear=&quot; &amp; InSendYear.ToString() &amp; &quot; | RecordFound=&quot; &amp; (obj_QueryResults IsNo",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"RecordFound\" referenced in Message but not declared in workflow \"BGYY_WriteDedupe\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/BGYY_WriteDedupe.xaml",
      "workflow": "BGYY_WriteDedupe",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "referencedSymbol": "BGYY_WriteDedupe",
      "offendingExpression": "[BGYY_WriteDedupe][UpdateError] PersonKey=&quot; &amp; str_PersonKeyNormalized &amp; &quot; | Status=&quot; &amp; InStatus &amp; &quot; | Error=&quot; &amp; ex_UpdateException.Message",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"BGYY_WriteDedupe\" referenced in Message but not declared in workflow \"BGYY_WriteDedupe\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/BGYY_WriteDedupe.xaml",
      "workflow": "BGYY_WriteDedupe",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "referencedSymbol": "UpdateError",
      "offendingExpression": "[BGYY_WriteDedupe][UpdateError] PersonKey=&quot; &amp; str_PersonKeyNormalized &amp; &quot; | Status=&quot; &amp; InStatus &amp; &quot; | Error=&quot; &amp; ex_UpdateException.Message",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"UpdateError\" referenced in Message but not declared in workflow \"BGYY_WriteDedupe\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/BGYY_WriteDedupe.xaml",
      "workflow": "BGYY_WriteDedupe",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "referencedSymbol": "PersonKey",
      "offendingExpression": "[BGYY_WriteDedupe][UpdateError] PersonKey=&quot; &amp; str_PersonKeyNormalized &amp; &quot; | Status=&quot; &amp; InStatus &amp; &quot; | Error=&quot; &amp; ex_UpdateException.Message",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"PersonKey\" referenced in Message but not declared in workflow \"BGYY_WriteDedupe\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/BGYY_WriteDedupe.xaml",
      "workflow": "BGYY_WriteDedupe",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "referencedSymbol": "Status",
      "offendingExpression": "[BGYY_WriteDedupe][UpdateError] PersonKey=&quot; &amp; str_PersonKeyNormalized &amp; &quot; | Status=&quot; &amp; InStatus &amp; &quot; | Error=&quot; &amp; ex_UpdateException.Message",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"Status\" referenced in Message but not declared in workflow \"BGYY_WriteDedupe\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/BGYY_WriteDedupe.xaml",
      "workflow": "BGYY_WriteDedupe",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "referencedSymbol": "BGYY_WriteDedupe",
      "offendingExpression": "[BGYY_WriteDedupe][UpdateSuccess] PersonKey=&quot; &amp; str_PersonKeyNormalized &amp; &quot; | Status=&quot; &amp; InStatus &amp; &quot; | RunId=&quot; &amp; InRunId",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"BGYY_WriteDedupe\" referenced in Message but not declared in workflow \"BGYY_WriteDedupe\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/BGYY_WriteDedupe.xaml",
      "workflow": "BGYY_WriteDedupe",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "referencedSymbol": "UpdateSuccess",
      "offendingExpression": "[BGYY_WriteDedupe][UpdateSuccess] PersonKey=&quot; &amp; str_PersonKeyNormalized &amp; &quot; | Status=&quot; &amp; InStatus &amp; &quot; | RunId=&quot; &amp; InRunId",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"UpdateSuccess\" referenced in Message but not declared in workflow \"BGYY_WriteDedupe\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/BGYY_WriteDedupe.xaml",
      "workflow": "BGYY_WriteDedupe",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "referencedSymbol": "PersonKey",
      "offendingExpression": "[BGYY_WriteDedupe][UpdateSuccess] PersonKey=&quot; &amp; str_PersonKeyNormalized &amp; &quot; | Status=&quot; &amp; InStatus &amp; &quot; | RunId=&quot; &amp; InRunId",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"PersonKey\" referenced in Message but not declared in workflow \"BGYY_WriteDedupe\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/BGYY_WriteDedupe.xaml",
      "workflow": "BGYY_WriteDedupe",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "referencedSymbol": "Status",
      "offendingExpression": "[BGYY_WriteDedupe][UpdateSuccess] PersonKey=&quot; &amp; str_PersonKeyNormalized &amp; &quot; | Status=&quot; &amp; InStatus &amp; &quot; | RunId=&quot; &amp; InRunId",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"Status\" referenced in Message but not declared in workflow \"BGYY_WriteDedupe\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/BGYY_WriteDedupe.xaml",
      "workflow": "BGYY_WriteDedupe",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "referencedSymbol": "RunId",
      "offendingExpression": "[BGYY_WriteDedupe][UpdateSuccess] PersonKey=&quot; &amp; str_PersonKeyNormalized &amp; &quot; | Status=&quot; &amp; InStatus &amp; &quot; | RunId=&quot; &amp; InRunId",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"RunId\" referenced in Message but not declared in workflow \"BGYY_WriteDedupe\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/BGYY_WriteDedupe.xaml",
      "workflow": "BGYY_WriteDedupe",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "referencedSymbol": "BGYY_WriteDedupe",
      "offendingExpression": "[BGYY_WriteDedupe][CreateError] PersonKey=&quot; &amp; str_PersonKeyNormalized &amp; &quot; | Status=&quot; &amp; InStatus &amp; &quot; | CalendarEventId=&quot; &amp; InCalendarEventId &amp; &quot; | ",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"BGYY_WriteDedupe\" referenced in Message but not declared in workflow \"BGYY_WriteDedupe\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/BGYY_WriteDedupe.xaml",
      "workflow": "BGYY_WriteDedupe",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "referencedSymbol": "CreateError",
      "offendingExpression": "[BGYY_WriteDedupe][CreateError] PersonKey=&quot; &amp; str_PersonKeyNormalized &amp; &quot; | Status=&quot; &amp; InStatus &amp; &quot; | CalendarEventId=&quot; &amp; InCalendarEventId &amp; &quot; | ",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"CreateError\" referenced in Message but not declared in workflow \"BGYY_WriteDedupe\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/BGYY_WriteDedupe.xaml",
      "workflow": "BGYY_WriteDedupe",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "referencedSymbol": "PersonKey",
      "offendingExpression": "[BGYY_WriteDedupe][CreateError] PersonKey=&quot; &amp; str_PersonKeyNormalized &amp; &quot; | Status=&quot; &amp; InStatus &amp; &quot; | CalendarEventId=&quot; &amp; InCalendarEventId &amp; &quot; | ",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"PersonKey\" referenced in Message but not declared in workflow \"BGYY_WriteDedupe\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/BGYY_WriteDedupe.xaml",
      "workflow": "BGYY_WriteDedupe",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "referencedSymbol": "Status",
      "offendingExpression": "[BGYY_WriteDedupe][CreateError] PersonKey=&quot; &amp; str_PersonKeyNormalized &amp; &quot; | Status=&quot; &amp; InStatus &amp; &quot; | CalendarEventId=&quot; &amp; InCalendarEventId &amp; &quot; | ",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"Status\" referenced in Message but not declared in workflow \"BGYY_WriteDedupe\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/BGYY_WriteDedupe.xaml",
      "workflow": "BGYY_WriteDedupe",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "referencedSymbol": "CalendarEventId",
      "offendingExpression": "[BGYY_WriteDedupe][CreateError] PersonKey=&quot; &amp; str_PersonKeyNormalized &amp; &quot; | Status=&quot; &amp; InStatus &amp; &quot; | CalendarEventId=&quot; &amp; InCalendarEventId &amp; &quot; | ",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"CalendarEventId\" referenced in Message but not declared in workflow \"BGYY_WriteDedupe\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/BGYY_WriteDedupe.xaml",
      "workflow": "BGYY_WriteDedupe",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "referencedSymbol": "BGYY_WriteDedupe",
      "offendingExpression": "[BGYY_WriteDedupe][CreateSuccess] PersonKey=&quot; &amp; str_PersonKeyNormalized &amp; &quot; | Status=&quot; &amp; InStatus &amp; &quot; | CalendarEventId=&quot; &amp; InCalendarEventId &amp; &quot; ",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"BGYY_WriteDedupe\" referenced in Message but not declared in workflow \"BGYY_WriteDedupe\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/BGYY_WriteDedupe.xaml",
      "workflow": "BGYY_WriteDedupe",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "referencedSymbol": "CreateSuccess",
      "offendingExpression": "[BGYY_WriteDedupe][CreateSuccess] PersonKey=&quot; &amp; str_PersonKeyNormalized &amp; &quot; | Status=&quot; &amp; InStatus &amp; &quot; | CalendarEventId=&quot; &amp; InCalendarEventId &amp; &quot; ",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"CreateSuccess\" referenced in Message but not declared in workflow \"BGYY_WriteDedupe\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/BGYY_WriteDedupe.xaml",
      "workflow": "BGYY_WriteDedupe",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "referencedSymbol": "PersonKey",
      "offendingExpression": "[BGYY_WriteDedupe][CreateSuccess] PersonKey=&quot; &amp; str_PersonKeyNormalized &amp; &quot; | Status=&quot; &amp; InStatus &amp; &quot; | CalendarEventId=&quot; &amp; InCalendarEventId &amp; &quot; ",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"PersonKey\" referenced in Message but not declared in workflow \"BGYY_WriteDedupe\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/BGYY_WriteDedupe.xaml",
      "workflow": "BGYY_WriteDedupe",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "referencedSymbol": "Status",
      "offendingExpression": "[BGYY_WriteDedupe][CreateSuccess] PersonKey=&quot; &amp; str_PersonKeyNormalized &amp; &quot; | Status=&quot; &amp; InStatus &amp; &quot; | CalendarEventId=&quot; &amp; InCalendarEventId &amp; &quot; ",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"Status\" referenced in Message but not declared in workflow \"BGYY_WriteDedupe\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/BGYY_WriteDedupe.xaml",
      "workflow": "BGYY_WriteDedupe",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "referencedSymbol": "CalendarEventId",
      "offendingExpression": "[BGYY_WriteDedupe][CreateSuccess] PersonKey=&quot; &amp; str_PersonKeyNormalized &amp; &quot; | Status=&quot; &amp; InStatus &amp; &quot; | CalendarEventId=&quot; &amp; InCalendarEventId &amp; &quot; ",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"CalendarEventId\" referenced in Message but not declared in workflow \"BGYY_WriteDedupe\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/BGYY_WriteDedupe.xaml",
      "workflow": "BGYY_WriteDedupe",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "referencedSymbol": "GmailMessageId",
      "offendingExpression": "[BGYY_WriteDedupe][CreateSuccess] PersonKey=&quot; &amp; str_PersonKeyNormalized &amp; &quot; | Status=&quot; &amp; InStatus &amp; &quot; | CalendarEventId=&quot; &amp; InCalendarEventId &amp; &quot; ",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"GmailMessageId\" referenced in Message but not declared in workflow \"BGYY_WriteDedupe\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/BGYY_WriteDedupe.xaml",
      "workflow": "BGYY_WriteDedupe",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "referencedSymbol": "RunId",
      "offendingExpression": "[BGYY_WriteDedupe][CreateSuccess] PersonKey=&quot; &amp; str_PersonKeyNormalized &amp; &quot; | Status=&quot; &amp; InStatus &amp; &quot; | CalendarEventId=&quot; &amp; InCalendarEventId &amp; &quot; ",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"RunId\" referenced in Message but not declared in workflow \"BGYY_WriteDedupe\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/BGYY_WriteDedupe.xaml",
      "workflow": "BGYY_WriteDedupe",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "referencedSymbol": "BGYY_WriteDedupe",
      "offendingExpression": "[BGYY_WriteDedupe][Exit] Completed for PersonKey=&quot; &amp; str_PersonKeyNormalized &amp; &quot; | SendYear=&quot; &amp; InSendYear.ToString() &amp; &quot; | FinalStatus=&quot; &amp; InStatus",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"BGYY_WriteDedupe\" referenced in Message but not declared in workflow \"BGYY_WriteDedupe\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/BGYY_WriteDedupe.xaml",
      "workflow": "BGYY_WriteDedupe",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "referencedSymbol": "Completed",
      "offendingExpression": "[BGYY_WriteDedupe][Exit] Completed for PersonKey=&quot; &amp; str_PersonKeyNormalized &amp; &quot; | SendYear=&quot; &amp; InSendYear.ToString() &amp; &quot; | FinalStatus=&quot; &amp; InStatus",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"Completed\" referenced in Message but not declared in workflow \"BGYY_WriteDedupe\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/BGYY_WriteDedupe.xaml",
      "workflow": "BGYY_WriteDedupe",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "referencedSymbol": "PersonKey",
      "offendingExpression": "[BGYY_WriteDedupe][Exit] Completed for PersonKey=&quot; &amp; str_PersonKeyNormalized &amp; &quot; | SendYear=&quot; &amp; InSendYear.ToString() &amp; &quot; | FinalStatus=&quot; &amp; InStatus",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"PersonKey\" referenced in Message but not declared in workflow \"BGYY_WriteDedupe\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/BGYY_WriteDedupe.xaml",
      "workflow": "BGYY_WriteDedupe",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "referencedSymbol": "FinalStatus",
      "offendingExpression": "[BGYY_WriteDedupe][Exit] Completed for PersonKey=&quot; &amp; str_PersonKeyNormalized &amp; &quot; | SendYear=&quot; &amp; InSendYear.ToString() &amp; &quot; | FinalStatus=&quot; &amp; InStatus",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"FinalStatus\" referenced in Message but not declared in workflow \"BGYY_WriteDedupe\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/BGYY_CreateReviewTask.xaml",
      "workflow": "BGYY_CreateReviewTask",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "referencedSymbol": "taskTitle",
      "offendingExpression": "&quot;[BGYY_CreateReviewTask] Creating Action Center form task — Title=&quot; &amp; taskTitle &amp; &quot; | DueBy=&quot; &amp; dt_DueByTimestamp.ToString(&quot;yyyy-MM-ddTHH:mm:ssZ&quot;)",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"taskTitle\" referenced in Message but not declared in workflow \"BGYY_CreateReviewTask\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/BGYY_CreateReviewTask.xaml",
      "workflow": "BGYY_CreateReviewTask",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "referencedSymbol": "taskTitle",
      "offendingExpression": "&quot;[BGYY_CreateReviewTask] Action Center task created successfully — Title=&quot; &amp; taskTitle &amp; &quot; | DueBy=&quot; &amp; dt_DueByTimestamp.ToString(&quot;yyyy-MM-ddTHH:mm:ssZ&quot;) &amp",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"taskTitle\" referenced in Message but not declared in workflow \"BGYY_CreateReviewTask\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/Main.xaml",
      "workflow": "Main",
      "activityType": "InOutArgument",
      "propertyName": "Key",
      "referencedSymbol": "io_Config",
      "offendingExpression": "io_Config",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "undeclared_argument_reference",
      "severity": "handoff_required",
      "rationale": "Argument \"io_Config\" referenced in Key but not declared in workflow \"Main\" — expression replaced with \"Nothing\""
    },
    {
      "file": "lib/net45/Main.xaml",
      "workflow": "Main",
      "activityType": "InArgument",
      "propertyName": "Key",
      "referencedSymbol": "in_QueueName",
      "offendingExpression": "in_QueueName",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "undeclared_argument_reference",
      "severity": "handoff_required",
      "rationale": "Argument \"in_QueueName\" referenced in Key but not declared in workflow \"Main\" — expression replaced with \"Nothing\""
    },
    {
      "file": "lib/net45/Main.xaml",
      "workflow": "Main",
      "activityType": "OutArgument",
      "propertyName": "Key",
      "referencedSymbol": "out_TransactionItem",
      "offendingExpression": "out_TransactionItem",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "undeclared_argument_reference",
      "severity": "handoff_required",
      "rationale": "Argument \"out_TransactionItem\" referenced in Key but not declared in workflow \"Main\" — expression replaced with \"Nothing\""
    },
    {
      "file": "lib/net45/Main.xaml",
      "workflow": "Main",
      "activityType": "InOutArgument",
      "propertyName": "Key",
      "referencedSymbol": "io_TransactionNumber",
      "offendingExpression": "io_TransactionNumber",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "undeclared_argument_reference",
      "severity": "handoff_required",
      "rationale": "Argument \"io_TransactionNumber\" referenced in Key but not declared in workflow \"Main\" — expression replaced with \"Nothing\""
    },
    {
      "file": "lib/net45/Main.xaml",
      "workflow": "Main",
      "activityType": "InArgument",
      "propertyName": "Key",
      "referencedSymbol": "in_TransactionItem",
      "offendingExpression": "in_TransactionItem",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "undeclared_argument_reference",
      "severity": "handoff_required",
      "rationale": "Argument \"in_TransactionItem\" referenced in Key but not declared in workflow \"Main\" — expression replaced with \"Nothing\""
    },
    {
      "file": "lib/net45/Main.xaml",
      "workflow": "Main",
      "activityType": "InArgument",
      "propertyName": "Key",
      "referencedSymbol": "in_TransactionItem",
      "offendingExpression": "in_TransactionItem",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "undeclared_argument_reference",
      "severity": "handoff_required",
      "rationale": "Argument \"in_TransactionItem\" referenced in Key but not declared in workflow \"Main\" — expression replaced with \"Nothing\""
    },
    {
      "file": "lib/net45/Main.xaml",
      "workflow": "Main",
      "activityType": "InArgument",
      "propertyName": "Key",
      "referencedSymbol": "in_Status",
      "offendingExpression": "in_Status",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "undeclared_argument_reference",
      "severity": "handoff_required",
      "rationale": "Argument \"in_Status\" referenced in Key but not declared in workflow \"Main\" — expression replaced with \"Nothing\""
    },
    {
      "file": "lib/net45/Main.xaml",
      "workflow": "Main",
      "activityType": "InArgument",
      "propertyName": "Key",
      "referencedSymbol": "in_TransactionItem",
      "offendingExpression": "in_TransactionItem",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "undeclared_argument_reference",
      "severity": "handoff_required",
      "rationale": "Argument \"in_TransactionItem\" referenced in Key but not declared in workflow \"Main\" — expression replaced with \"Nothing\""
    },
    {
      "file": "lib/net45/Main.xaml",
      "workflow": "Main",
      "activityType": "InArgument",
      "propertyName": "Key",
      "referencedSymbol": "in_Status",
      "offendingExpression": "in_Status",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "undeclared_argument_reference",
      "severity": "handoff_required",
      "rationale": "Argument \"in_Status\" referenced in Key but not declared in workflow \"Main\" — expression replaced with \"Nothing\""
    },
    {
      "file": "lib/net45/Init.xaml",
      "workflow": "Init",
      "activityType": "OutArgument",
      "propertyName": "Key",
      "referencedSymbol": "out_Config",
      "offendingExpression": "out_Config",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "undeclared_argument_reference",
      "severity": "handoff_required",
      "rationale": "Argument \"out_Config\" referenced in Key but not declared in workflow \"Init\" — expression replaced with \"Nothing\""
    }
  ],
  "targetValueCanonicalizationSummary": "Target/value canonicalization: 0 expression fix(es), 52 symbol scope defect(s), 0 sentinel replacement(s), 0 unresolvable JSON defect(s)",
  "residualExpressionSerializationDefects": [
    {
      "file": "lib/net45/BGYY_ResolveRecipient.xaml",
      "workflow": "BGYY_ResolveRecipient",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "originalValue": "[&quot;Placeholder — RetryScope body has no activities yet&quot;]",
      "defectType": "placeholder_in_executable",
      "severity": "handoff_required",
      "rationale": "Placeholder sentinel in executable property Message — requires business value"
    },
    {
      "file": "lib/net45/BGYY_ResolveRecipient.xaml",
      "workflow": "BGYY_ResolveRecipient",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "originalValue": "[&quot;Placeholder — Then branch has no activities yet&quot;]",
      "defectType": "placeholder_in_executable",
      "severity": "handoff_required",
      "rationale": "Placeholder sentinel in executable property Message — requires business value"
    },
    {
      "file": "lib/net45/BGYY_ResolveRecipient.xaml",
      "workflow": "BGYY_ResolveRecipient",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "originalValue": "[&quot;Placeholder — Then branch has no activities yet&quot;]",
      "defectType": "placeholder_in_executable",
      "severity": "handoff_required",
      "rationale": "Placeholder sentinel in executable property Message — requires business value"
    },
    {
      "file": "lib/net45/BGYY_ResolveRecipient.xaml",
      "workflow": "BGYY_ResolveRecipient",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "originalValue": "[&quot;Placeholder — ForEach body has no activities yet&quot;]",
      "defectType": "placeholder_in_executable",
      "severity": "handoff_required",
      "rationale": "Placeholder sentinel in executable property Message — requires business value"
    },
    {
      "file": "lib/net45/BGYY_ResolveRecipient.xaml",
      "workflow": "BGYY_ResolveRecipient",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "originalValue": "[&quot;Placeholder — Then branch has no activities yet&quot;]",
      "defectType": "placeholder_in_executable",
      "severity": "handoff_required",
      "rationale": "Placeholder sentinel in executable property Message — requires business value"
    },
    {
      "file": "lib/net45/BGYY_ResolveRecipient.xaml",
      "workflow": "BGYY_ResolveRecipient",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "originalValue": "[&quot;Placeholder — Then branch has no activities yet&quot;]",
      "defectType": "placeholder_in_executable",
      "severity": "handoff_required",
      "rationale": "Placeholder sentinel in executable property Message — requires business value"
    },
    {
      "file": "lib/net45/BGYY_ResolveRecipient.xaml",
      "workflow": "BGYY_ResolveRecipient",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "originalValue": "[&quot;Placeholder — Then branch has no activities yet&quot;]",
      "defectType": "placeholder_in_executable",
      "severity": "handoff_required",
      "rationale": "Placeholder sentinel in executable property Message — requires business value"
    },
    {
      "file": "lib/net45/BGYY_ResolveRecipient.xaml",
      "workflow": "BGYY_ResolveRecipient",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "originalValue": "[&quot;Placeholder — Then branch has no activities yet&quot;]",
      "defectType": "placeholder_in_executable",
      "severity": "handoff_required",
      "rationale": "Placeholder sentinel in executable property Message — requires business value"
    },
    {
      "file": "lib/net45/BGYY_ResolveRecipient.xaml",
      "workflow": "BGYY_ResolveRecipient",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "originalValue": "[&quot;Placeholder — Then branch has no activities yet&quot;]",
      "defectType": "placeholder_in_executable",
      "severity": "handoff_required",
      "rationale": "Placeholder sentinel in executable property Message — requires business value"
    },
    {
      "file": "lib/net45/BGYY_GenerateAndValidateDraft.xaml",
      "workflow": "BGYY_GenerateAndValidateDraft",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "originalValue": "[&quot;Placeholder — Then branch has no activities yet&quot;]",
      "defectType": "placeholder_in_executable",
      "severity": "handoff_required",
      "rationale": "Placeholder sentinel in executable property Message — requires business value"
    },
    {
      "file": "lib/net45/BGYY_GenerateAndValidateDraft.xaml",
      "workflow": "BGYY_GenerateAndValidateDraft",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "originalValue": "[&quot;Placeholder — Then branch has no activities yet&quot;]",
      "defectType": "placeholder_in_executable",
      "severity": "handoff_required",
      "rationale": "Placeholder sentinel in executable property Message — requires business value"
    },
    {
      "file": "lib/net45/BGYY_GenerateAndValidateDraft.xaml",
      "workflow": "BGYY_GenerateAndValidateDraft",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "originalValue": "[&quot;Placeholder — Then branch has no activities yet&quot;]",
      "defectType": "placeholder_in_executable",
      "severity": "handoff_required",
      "rationale": "Placeholder sentinel in executable property Message — requires business value"
    },
    {
      "file": "lib/net45/BGYY_GenerateAndValidateDraft.xaml",
      "workflow": "BGYY_GenerateAndValidateDraft",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "originalValue": "[&quot;Placeholder — Then branch has no activities yet&quot;]",
      "defectType": "placeholder_in_executable",
      "severity": "handoff_required",
      "rationale": "Placeholder sentinel in executable property Message — requires business value"
    },
    {
      "file": "lib/net45/BGYY_GenerateAndValidateDraft.xaml",
      "workflow": "BGYY_GenerateAndValidateDraft",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "originalValue": "[&quot;Placeholder — Then branch has no activities yet&quot;]",
      "defectType": "placeholder_in_executable",
      "severity": "handoff_required",
      "rationale": "Placeholder sentinel in executable property Message — requires business value"
    },
    {
      "file": "lib/net45/BGYY_GenerateAndValidateDraft.xaml",
      "workflow": "BGYY_GenerateAndValidateDraft",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "originalValue": "[&quot;Placeholder — ForEach body has no activities yet&quot;]",
      "defectType": "placeholder_in_executable",
      "severity": "handoff_required",
      "rationale": "Placeholder sentinel in executable property Message — requires business value"
    },
    {
      "file": "lib/net45/BGYY_SendGmail.xaml",
      "workflow": "BGYY_SendGmail",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "originalValue": "[&quot;Placeholder — Then branch has no activities yet&quot;]",
      "defectType": "placeholder_in_executable",
      "severity": "handoff_required",
      "rationale": "Placeholder sentinel in executable property Message — requires business value"
    },
    {
      "file": "lib/net45/BGYY_SendGmail.xaml",
      "workflow": "BGYY_SendGmail",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "originalValue": "[&quot;Placeholder — Then branch has no activities yet&quot;]",
      "defectType": "placeholder_in_executable",
      "severity": "handoff_required",
      "rationale": "Placeholder sentinel in executable property Message — requires business value"
    },
    {
      "file": "lib/net45/BGYY_SendGmail.xaml",
      "workflow": "BGYY_SendGmail",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "originalValue": "[&quot;Placeholder — RetryScope body has no activities yet&quot;]",
      "defectType": "placeholder_in_executable",
      "severity": "handoff_required",
      "rationale": "Placeholder sentinel in executable property Message — requires business value"
    },
    {
      "file": "lib/net45/BGYY_CreateReviewTask.xaml",
      "workflow": "BGYY_CreateReviewTask",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "originalValue": "[&quot;Placeholder — Then branch has no activities yet&quot;]",
      "defectType": "placeholder_in_executable",
      "severity": "handoff_required",
      "rationale": "Placeholder sentinel in executable property Message — requires business value"
    }
  ],
  "sentinelReplacements": [],
  "unresolvableJsonDefects": [],
  "requiredPropertyBindings": [
    {
      "file": "BGYY_GetTodaysBirthdays.xaml",
      "workflow": "BGYY_GetTodaysBirthdays",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;STUB: BGYY_GetTodaysBirthdays — Final validation remediation — original XAML had well-formedness violations. Implement the actual logic here.&quot;]",
      "resolvedValue": "[&quot;STUB: BGYY_GetTodaysBirthdays — Final validation remediation — original XAML had well-formedness violations. Implement the actual logic here.&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;STUB: BGYY_GetTodaysBirthdays — Final validation remediation — original X",
        "precedenceTier": 4
      }
    },
    {
      "file": "BGYY_GetTodaysBirthdays.xaml",
      "workflow": "BGYY_GetTodaysBirthdays",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;=== Completed: BGYY_GetTodaysBirthdays ===&quot;]",
      "resolvedValue": "[&quot;=== Completed: BGYY_GetTodaysBirthdays ===&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 1,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;=== Completed: BGYY_GetTodaysBirthdays ===&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "BGYY_ResolveRecipient.xaml",
      "workflow": "BGYY_ResolveRecipient",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[BGYY_ResolveRecipient][Init] RunId=&quot; &amp; InRunId &amp; &quot; | Resolving contact for FullName=&apos;&quot; &amp; InFullName &amp; &quot;&apos;",
      "resolvedValue": "[BGYY_ResolveRecipient][Init] RunId=&quot; &amp; InRunId &amp; &quot; | Resolving contact for FullName=&apos;&quot; &amp; InFullName &amp; &quot;&apos;",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[BGYY_ResolveRecipient][Init] RunId=&quot; &amp; InRunId &amp; &quot; | Resolvin",
        "precedenceTier": 4
      }
    },
    {
      "file": "BGYY_ResolveRecipient.xaml",
      "workflow": "BGYY_ResolveRecipient",
      "activityType": "Assign",
      "propertyName": "To",
      "sourceBinding": "variable",
      "originalValue": "[str_NormalizedFullName]",
      "resolvedValue": "[str_NormalizedFullName]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "variable",
        "sourceName": "str_NormalizedFullName",
        "sourceWorkflow": "BGYY_ResolveRecipient",
        "precedenceTier": 2
      }
    },
    {
      "file": "BGYY_ResolveRecipient.xaml",
      "workflow": "BGYY_ResolveRecipient",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "[InFullName.Trim().ToLower()]",
      "resolvedValue": "[InFullName.Trim().ToLower()]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[InFullName.Trim().ToLower()]",
        "precedenceTier": 4
      }
    },
    {
      "file": "BGYY_ResolveRecipient.xaml",
      "workflow": "BGYY_ResolveRecipient",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Placeholder — RetryScope body has no activities yet&quot;]",
      "resolvedValue": "[&quot;Placeholder — RetryScope body has no activities yet&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 1,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Placeholder — RetryScope body has no activities yet&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "BGYY_ResolveRecipient.xaml",
      "workflow": "BGYY_ResolveRecipient",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Error in Search Google Contacts for matching contact by display name (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "resolvedValue": "[&quot;Error in Search Google Contacts for matching contact by display name (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 2,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Error in Search Google Contacts for matching contact by display name (&qu",
        "precedenceTier": 4
      }
    },
    {
      "file": "BGYY_ResolveRecipient.xaml",
      "workflow": "BGYY_ResolveRecipient",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "&quot;Error in Search Google Contacts for matching contact by display name: &quot; &amp; exception.Message",
      "resolvedValue": "&quot;Error in Search Google Contacts for matching contact by display name: &quot; &amp; exception.Message",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 3,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "&quot;Error in Search Google Contacts for matching contact by display name: &quo",
        "precedenceTier": 4
      }
    },
    {
      "file": "BGYY_ResolveRecipient.xaml",
      "workflow": "BGYY_ResolveRecipient",
      "activityType": "Assign",
      "propertyName": "To",
      "sourceBinding": "variable",
      "originalValue": "[bool_ContactsQuerySucceeded]",
      "resolvedValue": "[bool_ContactsQuerySucceeded]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 1,
      "provenance": {
        "sourceKind": "variable",
        "sourceName": "bool_ContactsQuerySucceeded",
        "sourceWorkflow": "BGYY_ResolveRecipient",
        "precedenceTier": 2
      }
    },
    {
      "file": "BGYY_ResolveRecipient.xaml",
      "workflow": "BGYY_ResolveRecipient",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "True",
      "resolvedValue": "True",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 1,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "True",
        "precedenceTier": 4
      }
    },
    {
      "file": "BGYY_ResolveRecipient.xaml",
      "workflow": "BGYY_ResolveRecipient",
      "activityType": "If",
      "propertyName": "Condition",
      "sourceBinding": "attribute-value",
      "originalValue": "[obj_ContactSearchResults Is Nothing]",
      "resolvedValue": "[obj_ContactSearchResults Is Nothing]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[obj_ContactSearchResults Is Nothing]",
        "precedenceTier": 4
      }
    },
    {
      "file": "BGYY_ResolveRecipient.xaml",
      "workflow": "BGYY_ResolveRecipient",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Placeholder — Then branch has no activities yet&quot;]",
      "resolvedValue": "[&quot;Placeholder — Then branch has no activities yet&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 4,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Placeholder — Then branch has no activities yet&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "BGYY_ResolveRecipient.xaml",
      "workflow": "BGYY_ResolveRecipient",
      "activityType": "Assign",
      "propertyName": "To",
      "sourceBinding": "variable",
      "originalValue": "[int_ContactResultCount]",
      "resolvedValue": "[int_ContactResultCount]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 2,
      "provenance": {
        "sourceKind": "variable",
        "sourceName": "int_ContactResultCount",
        "sourceWorkflow": "BGYY_ResolveRecipient",
        "precedenceTier": 2
      }
    },
    {
      "file": "BGYY_ResolveRecipient.xaml",
      "workflow": "BGYY_ResolveRecipient",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "&quot;0&quot;",
      "resolvedValue": "&quot;0&quot;",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 2,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "&quot;0&quot;",
        "precedenceTier": 4
      }
    },
    {
      "file": "BGYY_ResolveRecipient.xaml",
      "workflow": "BGYY_ResolveRecipient",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[BGYY_ResolveRecipient][Decision] RunId=&quot; &amp; InRunId &amp; &quot; | No Google Contacts result for &apos;&quot; &amp; InFullName &amp; &quot;&apos; — will SkippedNoEmail",
      "resolvedValue": "[BGYY_ResolveRecipient][Decision] RunId=&quot; &amp; InRunId &amp; &quot; | No Google Contacts result for &apos;&quot; &amp; InFullName &amp; &quot;&apos; — will SkippedNoEmail",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 5,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[BGYY_ResolveRecipient][Decision] RunId=&quot; &amp; InRunId &amp; &quot; | No G",
        "precedenceTier": 4
      }
    },
    {
      "file": "BGYY_ResolveRecipient.xaml",
      "workflow": "BGYY_ResolveRecipient",
      "activityType": "If",
      "propertyName": "Condition",
      "sourceBinding": "attribute-value",
      "originalValue": "[int_ContactResultCount &gt; 1]",
      "resolvedValue": "[int_ContactResultCount &gt; 1]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 1,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[int_ContactResultCount &gt; 1]",
        "precedenceTier": 4
      }
    },
    {
      "file": "BGYY_ResolveRecipient.xaml",
      "workflow": "BGYY_ResolveRecipient",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Placeholder — Then branch has no activities yet&quot;]",
      "resolvedValue": "[&quot;Placeholder — Then branch has no activities yet&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 6,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Placeholder — Then branch has no activities yet&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "BGYY_ResolveRecipient.xaml",
      "workflow": "BGYY_ResolveRecipient",
      "activityType": "Assign",
      "propertyName": "To",
      "sourceBinding": "variable",
      "originalValue": "[bool_IsAmbiguous]",
      "resolvedValue": "[bool_IsAmbiguous]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 3,
      "provenance": {
        "sourceKind": "variable",
        "sourceName": "bool_IsAmbiguous",
        "sourceWorkflow": "BGYY_ResolveRecipient",
        "precedenceTier": 2
      }
    },
    {
      "file": "BGYY_ResolveRecipient.xaml",
      "workflow": "BGYY_ResolveRecipient",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "True",
      "resolvedValue": "True",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 3,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "True",
        "precedenceTier": 4
      }
    },
    {
      "file": "BGYY_ResolveRecipient.xaml",
      "workflow": "BGYY_ResolveRecipient",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[BGYY_ResolveRecipient][Decision] RunId=&quot; &amp; InRunId &amp; &quot; | AMBIGUOUS: &quot; &amp; int_ContactResultCount.ToString() &amp; &quot; contacts found for &apos;&quot; &amp; InFullName &amp; &quot;&apos; — flagging OutIsAmbiguous=True for Action Center review",
      "resolvedValue": "[BGYY_ResolveRecipient][Decision] RunId=&quot; &amp; InRunId &amp; &quot; | AMBIGUOUS: &quot; &amp; int_ContactResultCount.ToString() &amp; &quot; contacts found for &apos;&quot; &amp; InFullName &amp; &quot;&apos; — flagging OutIsAmbiguous=True for Action Center review",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 7,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[BGYY_ResolveRecipient][Decision] RunId=&quot; &amp; InRunId &amp; &quot; | AMBI",
        "precedenceTier": 4
      }
    },
    {
      "file": "BGYY_ResolveRecipient.xaml",
      "workflow": "BGYY_ResolveRecipient",
      "activityType": "GoogleContactsGetContact",
      "propertyName": "ResourceName",
      "sourceBinding": "variable",
      "originalValue": "[str_ResolvedContactId]",
      "resolvedValue": "[str_ResolvedContactId]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "variable",
        "sourceName": "str_ResolvedContactId",
        "sourceWorkflow": "BGYY_ResolveRecipient",
        "precedenceTier": 2
      }
    },
    {
      "file": "BGYY_ResolveRecipient.xaml",
      "workflow": "BGYY_ResolveRecipient",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[BGYY_ResolveRecipient][Info] RunId=&quot; &amp; InRunId &amp; &quot; | Single contact matched for &apos;&quot; &amp; InFullName &amp; &quot;&apos;, ContactId=&apos;&quot; &amp; resolvedContactId &amp; &quot;&apos; — extracting labeled emails",
      "resolvedValue": "[BGYY_ResolveRecipient][Info] RunId=&quot; &amp; InRunId &amp; &quot; | Single contact matched for &apos;&quot; &amp; InFullName &amp; &quot;&apos;, ContactId=&apos;&quot; &amp; resolvedContactId &amp; &quot;&apos; — extracting labeled emails",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 8,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[BGYY_ResolveRecipient][Info] RunId=&quot; &amp; InRunId &amp; &quot; | Single c",
        "precedenceTier": 4
      }
    },
    {
      "file": "BGYY_ResolveRecipient.xaml",
      "workflow": "BGYY_ResolveRecipient",
      "activityType": "ForEach",
      "propertyName": "Values",
      "sourceBinding": "variable",
      "originalValue": "[obj_EmailAddresses]",
      "resolvedValue": "[obj_EmailAddresses]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "variable",
        "sourceName": "obj_EmailAddresses",
        "sourceWorkflow": "BGYY_ResolveRecipient",
        "precedenceTier": 2
      }
    },
    {
      "file": "BGYY_ResolveRecipient.xaml",
      "workflow": "BGYY_ResolveRecipient",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Placeholder — ForEach body has no activities yet&quot;]",
      "resolvedValue": "[&quot;Placeholder — ForEach body has no activities yet&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 9,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Placeholder — ForEach body has no activities yet&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "BGYY_ResolveRecipient.xaml",
      "workflow": "BGYY_ResolveRecipient",
      "activityType": "Assign",
      "propertyName": "To",
      "sourceBinding": "variable",
      "originalValue": "[str_CurrentEmailLabel]",
      "resolvedValue": "[str_CurrentEmailLabel]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 4,
      "provenance": {
        "sourceKind": "variable",
        "sourceName": "str_CurrentEmailLabel",
        "sourceWorkflow": "BGYY_ResolveRecipient",
        "precedenceTier": 2
      }
    },
    {
      "file": "BGYY_ResolveRecipient.xaml",
      "workflow": "BGYY_ResolveRecipient",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "[obj_CurrentEmailItem.ToString().ToLower()]",
      "resolvedValue": "[obj_CurrentEmailItem.ToString().ToLower()]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 4,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[obj_CurrentEmailItem.ToString().ToLower()]",
        "precedenceTier": 4
      }
    },
    {
      "file": "BGYY_ResolveRecipient.xaml",
      "workflow": "BGYY_ResolveRecipient",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Placeholder — Then branch has no activities yet&quot;]",
      "resolvedValue": "[&quot;Placeholder — Then branch has no activities yet&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 10,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Placeholder — Then branch has no activities yet&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "BGYY_ResolveRecipient.xaml",
      "workflow": "BGYY_ResolveRecipient",
      "activityType": "Assign",
      "propertyName": "To",
      "sourceBinding": "variable",
      "originalValue": "[str_PersonalEmail]",
      "resolvedValue": "[str_PersonalEmail]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 5,
      "provenance": {
        "sourceKind": "variable",
        "sourceName": "str_PersonalEmail",
        "sourceWorkflow": "BGYY_ResolveRecipient",
        "precedenceTier": 2
      }
    },
    {
      "file": "BGYY_ResolveRecipient.xaml",
      "workflow": "BGYY_ResolveRecipient",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "variable",
      "originalValue": "[str_CurrentEmailValue]",
      "resolvedValue": "[str_CurrentEmailValue]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 5,
      "provenance": {
        "sourceKind": "variable",
        "sourceName": "str_CurrentEmailValue",
        "sourceWorkflow": "BGYY_ResolveRecipient",
        "precedenceTier": 2
      }
    },
    {
      "file": "BGYY_ResolveRecipient.xaml",
      "workflow": "BGYY_ResolveRecipient",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Placeholder — Then branch has no activities yet&quot;]",
      "resolvedValue": "[&quot;Placeholder — Then branch has no activities yet&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 11,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Placeholder — Then branch has no activities yet&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "BGYY_ResolveRecipient.xaml",
      "workflow": "BGYY_ResolveRecipient",
      "activityType": "Assign",
      "propertyName": "To",
      "sourceBinding": "variable",
      "originalValue": "[str_HomeEmail]",
      "resolvedValue": "[str_HomeEmail]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 6,
      "provenance": {
        "sourceKind": "variable",
        "sourceName": "str_HomeEmail",
        "sourceWorkflow": "BGYY_ResolveRecipient",
        "precedenceTier": 2
      }
    },
    {
      "file": "BGYY_ResolveRecipient.xaml",
      "workflow": "BGYY_ResolveRecipient",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "variable",
      "originalValue": "[str_CurrentEmailValue]",
      "resolvedValue": "[str_CurrentEmailValue]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 6,
      "provenance": {
        "sourceKind": "variable",
        "sourceName": "str_CurrentEmailValue",
        "sourceWorkflow": "BGYY_ResolveRecipient",
        "precedenceTier": 2
      }
    },
    {
      "file": "BGYY_ResolveRecipient.xaml",
      "workflow": "BGYY_ResolveRecipient",
      "activityType": "If",
      "propertyName": "Condition",
      "sourceBinding": "attribute-value",
      "originalValue": "[str_PersonalEmail &lt;&gt; Nothing]",
      "resolvedValue": "[str_PersonalEmail &lt;&gt; Nothing]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 4,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[str_PersonalEmail &lt;&gt; Nothing]",
        "precedenceTier": 4
      }
    },
    {
      "file": "BGYY_ResolveRecipient.xaml",
      "workflow": "BGYY_ResolveRecipient",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Placeholder — Then branch has no activities yet&quot;]",
      "resolvedValue": "[&quot;Placeholder — Then branch has no activities yet&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 12,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Placeholder — Then branch has no activities yet&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "BGYY_ResolveRecipient.xaml",
      "workflow": "BGYY_ResolveRecipient",
      "activityType": "Assign",
      "propertyName": "To",
      "sourceBinding": "variable",
      "originalValue": "[str_SelectedEmail]",
      "resolvedValue": "[str_SelectedEmail]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 7,
      "provenance": {
        "sourceKind": "variable",
        "sourceName": "str_SelectedEmail",
        "sourceWorkflow": "BGYY_ResolveRecipient",
        "precedenceTier": 2
      }
    },
    {
      "file": "BGYY_ResolveRecipient.xaml",
      "workflow": "BGYY_ResolveRecipient",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "variable",
      "originalValue": "[str_PersonalEmail]",
      "resolvedValue": "[str_PersonalEmail]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 7,
      "provenance": {
        "sourceKind": "variable",
        "sourceName": "str_PersonalEmail",
        "sourceWorkflow": "BGYY_ResolveRecipient",
        "precedenceTier": 2
      }
    },
    {
      "file": "BGYY_ResolveRecipient.xaml",
      "workflow": "BGYY_ResolveRecipient",
      "activityType": "If",
      "propertyName": "Condition",
      "sourceBinding": "attribute-value",
      "originalValue": "[str_HomeEmail &lt;&gt; Nothing]",
      "resolvedValue": "[str_HomeEmail &lt;&gt; Nothing]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 5,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[str_HomeEmail &lt;&gt; Nothing]",
        "precedenceTier": 4
      }
    },
    {
      "file": "BGYY_ResolveRecipient.xaml",
      "workflow": "BGYY_ResolveRecipient",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Placeholder — Then branch has no activities yet&quot;]",
      "resolvedValue": "[&quot;Placeholder — Then branch has no activities yet&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 13,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Placeholder — Then branch has no activities yet&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "BGYY_ResolveRecipient.xaml",
      "workflow": "BGYY_ResolveRecipient",
      "activityType": "Assign",
      "propertyName": "To",
      "sourceBinding": "variable",
      "originalValue": "[str_SelectedEmail]",
      "resolvedValue": "[str_SelectedEmail]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 8,
      "provenance": {
        "sourceKind": "variable",
        "sourceName": "str_SelectedEmail",
        "sourceWorkflow": "BGYY_ResolveRecipient",
        "precedenceTier": 2
      }
    },
    {
      "file": "BGYY_ResolveRecipient.xaml",
      "workflow": "BGYY_ResolveRecipient",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "variable",
      "originalValue": "[str_HomeEmail]",
      "resolvedValue": "[str_HomeEmail]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 8,
      "provenance": {
        "sourceKind": "variable",
        "sourceName": "str_HomeEmail",
        "sourceWorkflow": "BGYY_ResolveRecipient",
        "precedenceTier": 2
      }
    },
    {
      "file": "BGYY_ResolveRecipient.xaml",
      "workflow": "BGYY_ResolveRecipient",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[BGYY_ResolveRecipient][Decision] RunId=&quot; &amp; InRunId &amp; &quot; | No &apos;personal&apos; email label for &apos;&quot; &amp; InFullName &amp; &quot;&apos; — using &apos;home&apos; email as fallback",
      "resolvedValue": "[BGYY_ResolveRecipient][Decision] RunId=&quot; &amp; InRunId &amp; &quot; | No &apos;personal&apos; email label for &apos;&quot; &amp; InFullName &amp; &quot;&apos; — using &apos;home&apos; email as fallback",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 14,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[BGYY_ResolveRecipient][Decision] RunId=&quot; &amp; InRunId &amp; &quot; | No &",
        "precedenceTier": 4
      }
    },
    {
      "file": "BGYY_ResolveRecipient.xaml",
      "workflow": "BGYY_ResolveRecipient",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[BGYY_ResolveRecipient][Decision] RunId=&quot; &amp; InRunId &amp; &quot; | No &apos;personal&apos; or &apos;home&apos; email label found for &apos;&quot; &amp; InFullName &amp; &quot;&apos;, ContactId=&apos;&quot; &amp; resolvedContactId &amp; &quot;&apos; — OutSelectedEmail=Nothing (SkippedNoEmail)",
      "resolvedValue": "[BGYY_ResolveRecipient][Decision] RunId=&quot; &amp; InRunId &amp; &quot; | No &apos;personal&apos; or &apos;home&apos; email label found for &apos;&quot; &amp; InFullName &amp; &quot;&apos;, ContactId=&apos;&quot; &amp; resolvedContactId &amp; &quot;&apos; — OutSelectedEmail=Nothing (SkippedNoEmail)",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 15,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[BGYY_ResolveRecipient][Decision] RunId=&quot; &amp; InRunId &amp; &quot; | No &",
        "precedenceTier": 4
      }
    },
    {
      "file": "BGYY_ResolveRecipient.xaml",
      "workflow": "BGYY_ResolveRecipient",
      "activityType": "If",
      "propertyName": "Condition",
      "sourceBinding": "attribute-value",
      "originalValue": "[str_SelectedEmail &lt;&gt; Nothing]",
      "resolvedValue": "[str_SelectedEmail &lt;&gt; Nothing]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 6,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[str_SelectedEmail &lt;&gt; Nothing]",
        "precedenceTier": 4
      }
    },
    {
      "file": "BGYY_ResolveRecipient.xaml",
      "workflow": "BGYY_ResolveRecipient",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Placeholder — Then branch has no activities yet&quot;]",
      "resolvedValue": "[&quot;Placeholder — Then branch has no activities yet&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 16,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Placeholder — Then branch has no activities yet&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "BGYY_ResolveRecipient.xaml",
      "workflow": "BGYY_ResolveRecipient",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[BGYY_ResolveRecipient][Success] RunId=&quot; &amp; InRunId &amp; &quot; | Resolved email for &apos;&quot; &amp; InFullName &amp; &quot;&apos;: ContactId=&apos;&quot; &amp; resolvedContactId &amp; &quot;&apos; — email selected (label: &quot; &amp; If(personalEmail &lt;&gt; &quot;, &quot;personal&quot;, &quot;home&quot;) &amp; &quot;)",
      "resolvedValue": "[BGYY_ResolveRecipient][Success] RunId=&quot; &amp; InRunId &amp; &quot; | Resolved email for &apos;&quot; &amp; InFullName &amp; &quot;&apos;: ContactId=&apos;&quot; &amp; resolvedContactId &amp; &quot;&apos; — email selected (label: &quot; &amp; If(personalEmail &lt;&gt; &quot;, &quot;personal&quot;, &quot;home&quot;) &amp; &quot;)",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 17,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[BGYY_ResolveRecipient][Success] RunId=&quot; &amp; InRunId &amp; &quot; | Resol",
        "precedenceTier": 4
      }
    },
    {
      "file": "BGYY_ResolveRecipient.xaml",
      "workflow": "BGYY_ResolveRecipient",
      "activityType": "Assign",
      "propertyName": "To",
      "sourceBinding": "variable",
      "originalValue": "[str_SelectedEmail]",
      "resolvedValue": "[str_SelectedEmail]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 9,
      "provenance": {
        "sourceKind": "variable",
        "sourceName": "str_SelectedEmail",
        "sourceWorkflow": "BGYY_ResolveRecipient",
        "precedenceTier": 2
      }
    },
    {
      "file": "BGYY_ResolveRecipient.xaml",
      "workflow": "BGYY_ResolveRecipient",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "&quot;&quot;",
      "resolvedValue": "&quot;&quot;",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 9,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "&quot;&quot;",
        "precedenceTier": 4
      }
    },
    {
      "file": "BGYY_ResolveRecipient.xaml",
      "workflow": "BGYY_ResolveRecipient",
      "activityType": "Assign",
      "propertyName": "To",
      "sourceBinding": "workflowArgument",
      "originalValue": "[OutSelectedEmail]",
      "resolvedValue": "[OutSelectedEmail]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 10,
      "provenance": {
        "sourceKind": "workflowArgument",
        "sourceName": "OutSelectedEmail",
        "sourceWorkflow": "BGYY_ResolveRecipient",
        "precedenceTier": 1
      }
    },
    {
      "file": "BGYY_ResolveRecipient.xaml",
      "workflow": "BGYY_ResolveRecipient",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Nothing&quot;]",
      "resolvedValue": "[&quot;Nothing&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 10,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Nothing&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "BGYY_ResolveRecipient.xaml",
      "workflow": "BGYY_ResolveRecipient",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "&quot;[BGYY_ResolveRecipient][Exit] RunId=&quot; &amp; InRunId &amp; &quot; | FullName=&apos;&quot; &amp; InFullName &amp; &quot;&apos; | OutIsAmbiguous=&quot; &amp; OutIsAmbiguous.ToString() &amp; &quot; | EmailResolved=&quot; &amp; (OutSelectedEmail IsNot Nothing AndAlso OutSelectedEmail &lt;&gt; &quot;&quot;).ToString()",
      "resolvedValue": "&quot;[BGYY_ResolveRecipient][Exit] RunId=&quot; &amp; InRunId &amp; &quot; | FullName=&apos;&quot; &amp; InFullName &amp; &quot;&apos; | OutIsAmbiguous=&quot; &amp; OutIsAmbiguous.ToString() &amp; &quot; | EmailResolved=&quot; &amp; (OutSelectedEmail IsNot Nothing AndAlso OutSelectedEmail &lt;&gt; &quot;&quot;).ToString()",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 18,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "&quot;[BGYY_ResolveRecipient][Exit] RunId=&quot; &amp; InRunId &amp; &quot; | Fu",
        "precedenceTier": 4
      }
    },
    {
      "file": "BGYY_ResolveRecipient.xaml",
      "workflow": "BGYY_ResolveRecipient",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;=== Completed: BGYY_ResolveRecipient ===&quot;]",
      "resolvedValue": "[&quot;=== Completed: BGYY_ResolveRecipient ===&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 19,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;=== Completed: BGYY_ResolveRecipient ===&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "BGYY_CheckDedupe.xaml",
      "workflow": "BGYY_CheckDedupe",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "&quot;[BGYY_CheckDedupe] Starting dedupe check — PersonKey=&apos;&quot; &amp; InPersonKey &amp; &quot;&apos;, SendYear=&quot; &amp; InSendYear.ToString()",
      "resolvedValue": "&quot;[BGYY_CheckDedupe] Starting dedupe check — PersonKey=&apos;&quot; &amp; InPersonKey &amp; &quot;&apos;, SendYear=&quot; &amp; InSendYear.ToString()",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "&quot;[BGYY_CheckDedupe] Starting dedupe check — PersonKey=&apos;&quot; &amp; In",
        "precedenceTier": 4
      }
    },
    {
      "file": "BGYY_CheckDedupe.xaml",
      "workflow": "BGYY_CheckDedupe",
      "activityType": "If",
      "propertyName": "Condition",
      "sourceBinding": "attribute-value",
      "originalValue": "[String.IsNullOrWhiteSpace(InPersonKey)]",
      "resolvedValue": "[String.IsNullOrWhiteSpace(InPersonKey)]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[String.IsNullOrWhiteSpace(InPersonKey)]",
        "precedenceTier": 4
      }
    },
    {
      "file": "BGYY_CheckDedupe.xaml",
      "workflow": "BGYY_CheckDedupe",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[BGYY_CheckDedupe] PersonKey argument is null or empty. Cannot perform dedupe query. Returning OutAlreadySent=False to allow caller to decide handling.",
      "resolvedValue": "[BGYY_CheckDedupe] PersonKey argument is null or empty. Cannot perform dedupe query. Returning OutAlreadySent=False to allow caller to decide handling.",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 1,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[BGYY_CheckDedupe] PersonKey argument is null or empty. Cannot perform dedupe qu",
        "precedenceTier": 4
      }
    },
    {
      "file": "BGYY_CheckDedupe.xaml",
      "workflow": "BGYY_CheckDedupe",
      "activityType": "Assign",
      "propertyName": "To",
      "sourceBinding": "workflowArgument",
      "originalValue": "[OutAlreadySent]",
      "resolvedValue": "[OutAlreadySent]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "workflowArgument",
        "sourceName": "OutAlreadySent",
        "sourceWorkflow": "BGYY_CheckDedupe",
        "precedenceTier": 1
      }
    },
    {
      "file": "BGYY_CheckDedupe.xaml",
      "workflow": "BGYY_CheckDedupe",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;False&quot;]",
      "resolvedValue": "[&quot;False&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;False&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "BGYY_CheckDedupe.xaml",
      "workflow": "BGYY_CheckDedupe",
      "activityType": "Assign",
      "propertyName": "To",
      "sourceBinding": "variable",
      "originalValue": "[str_FilterExpression]",
      "resolvedValue": "[str_FilterExpression]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 1,
      "provenance": {
        "sourceKind": "variable",
        "sourceName": "str_FilterExpression",
        "sourceWorkflow": "BGYY_CheckDedupe",
        "precedenceTier": 2
      }
    },
    {
      "file": "BGYY_CheckDedupe.xaml",
      "workflow": "BGYY_CheckDedupe",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;PersonKey eq &apos;&quot; &amp; InPersonKey &amp; &quot;&apos; and SendYear eq &quot; &amp; InSendYear.ToString()]",
      "resolvedValue": "[&quot;PersonKey eq &apos;&quot; &amp; InPersonKey &amp; &quot;&apos; and SendYear eq &quot; &amp; InSendYear.ToString()]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 1,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;PersonKey eq &apos;&quot; &amp; InPersonKey &amp; &quot;&apos; and SendYe",
        "precedenceTier": 4
      }
    },
    {
      "file": "BGYY_CheckDedupe.xaml",
      "workflow": "BGYY_CheckDedupe",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "&quot;[BGYY_CheckDedupe] Querying BGYY_BirthdaySendLog — filter: &quot; &amp; str_FilterExpression",
      "resolvedValue": "&quot;[BGYY_CheckDedupe] Querying BGYY_BirthdaySendLog — filter: &quot; &amp; str_FilterExpression",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 2,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "&quot;[BGYY_CheckDedupe] Querying BGYY_BirthdaySendLog — filter: &quot; &amp; st",
        "precedenceTier": 4
      }
    },
    {
      "file": "BGYY_CheckDedupe.xaml",
      "workflow": "BGYY_CheckDedupe",
      "activityType": "QueryEntity",
      "propertyName": "EntityType",
      "sourceBinding": "attribute-value",
      "originalValue": "&quot;BGYY_BirthdaySendLog&quot;",
      "resolvedValue": "&quot;BGYY_BirthdaySendLog&quot;",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "&quot;BGYY_BirthdaySendLog&quot;",
        "precedenceTier": 4
      }
    },
    {
      "file": "BGYY_CheckDedupe.xaml",
      "workflow": "BGYY_CheckDedupe",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Error in Query BGYY_BirthdaySendLog — PersonKey and SendYear (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "resolvedValue": "[&quot;Error in Query BGYY_BirthdaySendLog — PersonKey and SendYear (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 3,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Error in Query BGYY_BirthdaySendLog — PersonKey and SendYear (&quot; &amp",
        "precedenceTier": 4
      }
    },
    {
      "file": "BGYY_CheckDedupe.xaml",
      "workflow": "BGYY_CheckDedupe",
      "activityType": "Assign",
      "propertyName": "To",
      "sourceBinding": "variable",
      "originalValue": "[bool_DedupeCheckSucceeded]",
      "resolvedValue": "[bool_DedupeCheckSucceeded]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 2,
      "provenance": {
        "sourceKind": "variable",
        "sourceName": "bool_DedupeCheckSucceeded",
        "sourceWorkflow": "BGYY_CheckDedupe",
        "precedenceTier": 2
      }
    },
    {
      "file": "BGYY_CheckDedupe.xaml",
      "workflow": "BGYY_CheckDedupe",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "True",
      "resolvedValue": "True",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 2,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "True",
        "precedenceTier": 4
      }
    },
    {
      "file": "BGYY_CheckDedupe.xaml",
      "workflow": "BGYY_CheckDedupe",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "&quot;[BGYY_CheckDedupe] Data Service QueryEntity failed for PersonKey=&apos;&quot; &amp; InPersonKey &amp; &quot;&apos;, SendYear=&quot; &amp; InSendYear.ToString() &amp; &quot;. Exception: &quot; &amp; ex_DedupeQuery.Message",
      "resolvedValue": "&quot;[BGYY_CheckDedupe] Data Service QueryEntity failed for PersonKey=&apos;&quot; &amp; InPersonKey &amp; &quot;&apos;, SendYear=&quot; &amp; InSendYear.ToString() &amp; &quot;. Exception: &quot; &amp; ex_DedupeQuery.Message",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 4,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "&quot;[BGYY_CheckDedupe] Data Service QueryEntity failed for PersonKey=&apos;&qu",
        "precedenceTier": 4
      }
    },
    {
      "file": "BGYY_CheckDedupe.xaml",
      "workflow": "BGYY_CheckDedupe",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Error in Rethrow — Propagate Data Service Query Exception to Caller (&quot; &amp; InSendYear.GetType().Name &amp; &quot;): &quot; &amp; InSendYear.Message]",
      "resolvedValue": "[&quot;Error in Rethrow — Propagate Data Service Query Exception to Caller (&quot; &amp; InSendYear.GetType().Name &amp; &quot;): &quot; &amp; InSendYear.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 5,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Error in Rethrow — Propagate Data Service Query Exception to Caller (&quo",
        "precedenceTier": 4
      }
    },
    {
      "file": "BGYY_CheckDedupe.xaml",
      "workflow": "BGYY_CheckDedupe",
      "activityType": "Assign",
      "propertyName": "To",
      "sourceBinding": "variable",
      "originalValue": "[int_RecordCount]",
      "resolvedValue": "[int_RecordCount]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 3,
      "provenance": {
        "sourceKind": "variable",
        "sourceName": "int_RecordCount",
        "sourceWorkflow": "BGYY_CheckDedupe",
        "precedenceTier": 2
      }
    },
    {
      "file": "BGYY_CheckDedupe.xaml",
      "workflow": "BGYY_CheckDedupe",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "[If(obj_QueryResults IsNot Nothing, DirectCast(obj_QueryResults, System.Collections.ICollection).Count, 0)]",
      "resolvedValue": "[If(obj_QueryResults IsNot Nothing, DirectCast(obj_QueryResults, System.Collections.ICollection).Count, 0)]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 3,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[If(obj_QueryResults IsNot Nothing, DirectCast(obj_QueryResults, System.Collecti",
        "precedenceTier": 4
      }
    },
    {
      "file": "BGYY_CheckDedupe.xaml",
      "workflow": "BGYY_CheckDedupe",
      "activityType": "If",
      "propertyName": "Condition",
      "sourceBinding": "attribute-value",
      "originalValue": "[int_RecordCount &gt; 0]",
      "resolvedValue": "[int_RecordCount &gt; 0]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 1,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[int_RecordCount &gt; 0]",
        "precedenceTier": 4
      }
    },
    {
      "file": "BGYY_CheckDedupe.xaml",
      "workflow": "BGYY_CheckDedupe",
      "activityType": "Assign",
      "propertyName": "To",
      "sourceBinding": "workflowArgument",
      "originalValue": "[OutAlreadySent]",
      "resolvedValue": "[OutAlreadySent]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 4,
      "provenance": {
        "sourceKind": "workflowArgument",
        "sourceName": "OutAlreadySent",
        "sourceWorkflow": "BGYY_CheckDedupe",
        "precedenceTier": 1
      }
    },
    {
      "file": "BGYY_CheckDedupe.xaml",
      "workflow": "BGYY_CheckDedupe",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;True&quot;]",
      "resolvedValue": "[&quot;True&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 4,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;True&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "BGYY_CheckDedupe.xaml",
      "workflow": "BGYY_CheckDedupe",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[BGYY_CheckDedupe] Dedupe record FOUND for PersonKey=&apos;&quot; &amp; InPersonKey &amp; &quot;&apos;, SendYear=&quot; &amp; InSendYear.ToString() &amp; &quot;. OutAlreadySent=True. Email will be skipped.",
      "resolvedValue": "[BGYY_CheckDedupe] Dedupe record FOUND for PersonKey=&apos;&quot; &amp; InPersonKey &amp; &quot;&apos;, SendYear=&quot; &amp; InSendYear.ToString() &amp; &quot;. OutAlreadySent=True. Email will be skipped.",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 6,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[BGYY_CheckDedupe] Dedupe record FOUND for PersonKey=&apos;&quot; &amp; InPerson",
        "precedenceTier": 4
      }
    },
    {
      "file": "BGYY_CheckDedupe.xaml",
      "workflow": "BGYY_CheckDedupe",
      "activityType": "Assign",
      "propertyName": "To",
      "sourceBinding": "workflowArgument",
      "originalValue": "[OutAlreadySent]",
      "resolvedValue": "[OutAlreadySent]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 5,
      "provenance": {
        "sourceKind": "workflowArgument",
        "sourceName": "OutAlreadySent",
        "sourceWorkflow": "BGYY_CheckDedupe",
        "precedenceTier": 1
      }
    },
    {
      "file": "BGYY_CheckDedupe.xaml",
      "workflow": "BGYY_CheckDedupe",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;False&quot;]",
      "resolvedValue": "[&quot;False&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 5,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;False&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "BGYY_CheckDedupe.xaml",
      "workflow": "BGYY_CheckDedupe",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[BGYY_CheckDedupe] No dedupe record found for PersonKey=&apos;&quot; &amp; InPersonKey &amp; &quot;&apos;, SendYear=&quot; &amp; InSendYear.ToString() &amp; &quot;. OutAlreadySent=False. Proceeding to draft and send.",
      "resolvedValue": "[BGYY_CheckDedupe] No dedupe record found for PersonKey=&apos;&quot; &amp; InPersonKey &amp; &quot;&apos;, SendYear=&quot; &amp; InSendYear.ToString() &amp; &quot;. OutAlreadySent=False. Proceeding to draft and send.",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 7,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[BGYY_CheckDedupe] No dedupe record found for PersonKey=&apos;&quot; &amp; InPer",
        "precedenceTier": 4
      }
    },
    {
      "file": "BGYY_CheckDedupe.xaml",
      "workflow": "BGYY_CheckDedupe",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "&quot;[BGYY_CheckDedupe] Completed — PersonKey=&apos;&quot; &amp; InPersonKey &amp; &quot;&apos;, SendYear=&quot; &amp; InSendYear.ToString() &amp; &quot;, OutAlreadySent=&quot; &amp; OutAlreadySent.ToString()",
      "resolvedValue": "&quot;[BGYY_CheckDedupe] Completed — PersonKey=&apos;&quot; &amp; InPersonKey &amp; &quot;&apos;, SendYear=&quot; &amp; InSendYear.ToString() &amp; &quot;, OutAlreadySent=&quot; &amp; OutAlreadySent.ToString()",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 8,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "&quot;[BGYY_CheckDedupe] Completed — PersonKey=&apos;&quot; &amp; InPersonKey &a",
        "precedenceTier": 4
      }
    },
    {
      "file": "BGYY_GenerateAndValidateDraft.xaml",
      "workflow": "BGYY_GenerateAndValidateDraft",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[BGYY_GenerateAndValidateDraft] START — FullName=&apos;&quot; &amp; InFullName &amp; &quot;&apos; RunId=&apos;&quot; &amp; InRunId &amp; &quot;&apos;",
      "resolvedValue": "[BGYY_GenerateAndValidateDraft] START — FullName=&apos;&quot; &amp; InFullName &amp; &quot;&apos; RunId=&apos;&quot; &amp; InRunId &amp; &quot;&apos;",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[BGYY_GenerateAndValidateDraft] START — FullName=&apos;&quot; &amp; InFullName &",
        "precedenceTier": 4
      }
    },
    {
      "file": "BGYY_GenerateAndValidateDraft.xaml",
      "workflow": "BGYY_GenerateAndValidateDraft",
      "activityType": "QueryEntity",
      "propertyName": "EntityType",
      "sourceBinding": "attribute-value",
      "originalValue": "&quot;BGYY_VoiceProfile&quot;",
      "resolvedValue": "&quot;BGYY_VoiceProfile&quot;",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "&quot;BGYY_VoiceProfile&quot;",
        "precedenceTier": 4
      }
    },
    {
      "file": "BGYY_GenerateAndValidateDraft.xaml",
      "workflow": "BGYY_GenerateAndValidateDraft",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Error in Query BGYY_VoiceProfile Data Service entity for Default profile (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "resolvedValue": "[&quot;Error in Query BGYY_VoiceProfile Data Service entity for Default profile (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 1,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Error in Query BGYY_VoiceProfile Data Service entity for Default profile ",
        "precedenceTier": 4
      }
    },
    {
      "file": "BGYY_GenerateAndValidateDraft.xaml",
      "workflow": "BGYY_GenerateAndValidateDraft",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "&quot;Error in Query BGYY_VoiceProfile Data Service entity for Default profile: &quot; &amp; exception.Message",
      "resolvedValue": "&quot;Error in Query BGYY_VoiceProfile Data Service entity for Default profile: &quot; &amp; exception.Message",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 2,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "&quot;Error in Query BGYY_VoiceProfile Data Service entity for Default profile: ",
        "precedenceTier": 4
      }
    },
    {
      "file": "BGYY_GenerateAndValidateDraft.xaml",
      "workflow": "BGYY_GenerateAndValidateDraft",
      "activityType": "If",
      "propertyName": "Condition",
      "sourceBinding": "attribute-value",
      "originalValue": "[dt_VoiceProfileQueryResult IsNot Nothing]",
      "resolvedValue": "[dt_VoiceProfileQueryResult IsNot Nothing]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[dt_VoiceProfileQueryResult IsNot Nothing]",
        "precedenceTier": 4
      }
    },
    {
      "file": "BGYY_GenerateAndValidateDraft.xaml",
      "workflow": "BGYY_GenerateAndValidateDraft",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Placeholder — Then branch has no activities yet&quot;]",
      "resolvedValue": "[&quot;Placeholder — Then branch has no activities yet&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 3,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Placeholder — Then branch has no activities yet&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "BGYY_GenerateAndValidateDraft.xaml",
      "workflow": "BGYY_GenerateAndValidateDraft",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "variable",
      "originalValue": "",
      "resolvedValue": "[str_LogMessage]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 4,
      "provenance": {
        "sourceKind": "variable",
        "sourceName": "str_LogMessage",
        "sourceWorkflow": "BGYY_GenerateAndValidateDraft",
        "precedenceTier": 2
      }
    },
    {
      "file": "BGYY_GenerateAndValidateDraft.xaml",
      "workflow": "BGYY_GenerateAndValidateDraft",
      "activityType": "ReadStorageText",
      "propertyName": "Path",
      "sourceBinding": "attribute-value",
      "originalValue": "&quot;guardrails/banned_phrases.txt&quot;",
      "resolvedValue": "&quot;guardrails/banned_phrases.txt&quot;",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "&quot;guardrails/banned_phrases.txt&quot;",
        "precedenceTier": 4
      }
    },
    {
      "file": "BGYY_GenerateAndValidateDraft.xaml",
      "workflow": "BGYY_GenerateAndValidateDraft",
      "activityType": "ReadStorageText",
      "propertyName": "StorageBucketName",
      "sourceBinding": "variable",
      "originalValue": "[str_StorageBucketName]",
      "resolvedValue": "[str_StorageBucketName]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "variable",
        "sourceName": "str_StorageBucketName",
        "sourceWorkflow": "BGYY_GenerateAndValidateDraft",
        "precedenceTier": 2
      }
    },
    {
      "file": "BGYY_GenerateAndValidateDraft.xaml",
      "workflow": "BGYY_GenerateAndValidateDraft",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Error in Download banned phrases list from Storage Bucket guardrails/banned_phrases.txt (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "resolvedValue": "[&quot;Error in Download banned phrases list from Storage Bucket guardrails/banned_phrases.txt (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 5,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Error in Download banned phrases list from Storage Bucket guardrails/bann",
        "precedenceTier": 4
      }
    },
    {
      "file": "BGYY_GenerateAndValidateDraft.xaml",
      "workflow": "BGYY_GenerateAndValidateDraft",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "&quot;Error in Download banned phrases list from Storage Bucket guardrails/banned_phrases.txt: &quot; &amp; exception.Message",
      "resolvedValue": "&quot;Error in Download banned phrases list from Storage Bucket guardrails/banned_phrases.txt: &quot; &amp; exception.Message",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 6,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "&quot;Error in Download banned phrases list from Storage Bucket guardrails/banne",
        "precedenceTier": 4
      }
    },
    {
      "file": "BGYY_GenerateAndValidateDraft.xaml",
      "workflow": "BGYY_GenerateAndValidateDraft",
      "activityType": "Assign",
      "propertyName": "To",
      "sourceBinding": "variable",
      "originalValue": "[BannedPhrasesList]",
      "resolvedValue": "[BannedPhrasesList]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "variable",
        "sourceName": "BannedPhrasesList",
        "sourceWorkflow": "BGYY_GenerateAndValidateDraft",
        "precedenceTier": 2
      }
    },
    {
      "file": "BGYY_GenerateAndValidateDraft.xaml",
      "workflow": "BGYY_GenerateAndValidateDraft",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "[If(String.IsNullOrWhiteSpace(str_BannedPhrasesRaw), New String(){}, str_BannedPhrasesRaw.Split({Environment.NewLine, &quot;\n&quot;, &quot;\n&quot;}, StringSplitOptions.RemoveEmptyEntries) |&gt; Function(Arr) Array.ConvertAll(Arr, Function(s) s.Trim()) |&gt; Function(Arr) Arr.Where(Function(s) Not String.IsNullOrWhiteSpace(s)).ToArray())]",
      "resolvedValue": "[If(String.IsNullOrWhiteSpace(str_BannedPhrasesRaw), New String(){}, str_BannedPhrasesRaw.Split({Environment.NewLine, &quot;\n&quot;, &quot;\n&quot;}, StringSplitOptions.RemoveEmptyEntries) |&gt; Function(Arr) Array.ConvertAll(Arr, Function(s) s.Trim()) |&gt; Function(Arr) Arr.Where(Function(s) Not String.IsNullOrWhiteSpace(s)).ToArray())]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[If(String.IsNullOrWhiteSpace(str_BannedPhrasesRaw), New String(){}, str_BannedP",
        "precedenceTier": 4
      }
    },
    {
      "file": "BGYY_GenerateAndValidateDraft.xaml",
      "workflow": "BGYY_GenerateAndValidateDraft",
      "activityType": "Assign",
      "propertyName": "To",
      "sourceBinding": "variable",
      "originalValue": "[str_ConstructedPrompt]",
      "resolvedValue": "[str_ConstructedPrompt]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 1,
      "provenance": {
        "sourceKind": "variable",
        "sourceName": "str_ConstructedPrompt",
        "sourceWorkflow": "BGYY_GenerateAndValidateDraft",
        "precedenceTier": 2
      }
    },
    {
      "file": "BGYY_GenerateAndValidateDraft.xaml",
      "workflow": "BGYY_GenerateAndValidateDraft",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;You are writing a birthday email on behalf of YY.&quot; &amp; Environment.NewLine &amp; &quot;Recipient full name (use exactly as written): &quot; &amp; InFullName &amp; Environment.NewLine &amp; &quot;Tone: &quot; &amp; str_VoiceProfileToneTags &amp; Environment.NewLine &amp; &quot;Do: &quot; &amp; str_VoiceProfileDoList &amp; Environment.NewLine &amp; &quot;Do NOT: &quot; &amp; str_VoiceProfileDontList &amp; Environment.NewLine &amp; If(Not String.IsNullOrWhiteSpace(str_VoiceProfileExampleSnippets), &quot;Example style snippets:&quot; &amp; Environment.NewLine &amp; str_VoiceProfileExampleSnippets &amp; Environment.NewLine, &quot;&quot;) &amp; &quot;Output ONLY valid JSON with exactly two keys: &apos;Subject&apos; (string) and &apos;Body&apos; (string). No markdown fences. No extra keys. Word count of Body must be between 60 and 150 words.&quot;]",
      "resolvedValue": "[&quot;You are writing a birthday email on behalf of YY.&quot; &amp; Environment.NewLine &amp; &quot;Recipient full name (use exactly as written): &quot; &amp; InFullName &amp; Environment.NewLine &amp; &quot;Tone: &quot; &amp; str_VoiceProfileToneTags &amp; Environment.NewLine &amp; &quot;Do: &quot; &amp; str_VoiceProfileDoList &amp; Environment.NewLine &amp; &quot;Do NOT: &quot; &amp; str_VoiceProfileDontList &amp; Environment.NewLine &amp; If(Not String.IsNullOrWhiteSpace(str_VoiceProfileExampleSnippets), &quot;Example style snippets:&quot; &amp; Environment.NewLine &amp; str_VoiceProfileExampleSnippets &amp; Environment.NewLine, &quot;&quot;) &amp; &quot;Output ONLY valid JSON with exactly two keys: &apos;Subject&apos; (string) and &apos;Body&apos; (string). No markdown fences. No extra keys. Word count of Body must be between 60 and 150 words.&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 1,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;You are writing a birthday email on behalf of YY.&quot; &amp; Environment",
        "precedenceTier": 4
      }
    },
    {
      "file": "BGYY_GenerateAndValidateDraft.xaml",
      "workflow": "BGYY_GenerateAndValidateDraft",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[BGYY_GenerateAndValidateDraft] GenAI prompt constructed for FullName=&apos;&quot; &amp; InFullName &amp; &quot;&apos; PromptLength=&quot; &amp; constructedPrompt.Length.ToString() &amp; &quot; chars",
      "resolvedValue": "[BGYY_GenerateAndValidateDraft] GenAI prompt constructed for FullName=&apos;&quot; &amp; InFullName &amp; &quot;&apos; PromptLength=&quot; &amp; constructedPrompt.Length.ToString() &amp; &quot; chars",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 7,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[BGYY_GenerateAndValidateDraft] GenAI prompt constructed for FullName=&apos;&quo",
        "precedenceTier": 4
      }
    },
    {
      "file": "BGYY_GenerateAndValidateDraft.xaml",
      "workflow": "BGYY_GenerateAndValidateDraft",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Error in Invoke UiPath GenAI GenerateTextCompletion to produce subject and body JSON (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "resolvedValue": "[&quot;Error in Invoke UiPath GenAI GenerateTextCompletion to produce subject and body JSON (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 8,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Error in Invoke UiPath GenAI GenerateTextCompletion to produce subject an",
        "precedenceTier": 4
      }
    },
    {
      "file": "BGYY_GenerateAndValidateDraft.xaml",
      "workflow": "BGYY_GenerateAndValidateDraft",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "&quot;Error in Invoke UiPath GenAI GenerateTextCompletion to produce subject and body JSON: &quot; &amp; exception.Message",
      "resolvedValue": "&quot;Error in Invoke UiPath GenAI GenerateTextCompletion to produce subject and body JSON: &quot; &amp; exception.Message",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 9,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "&quot;Error in Invoke UiPath GenAI GenerateTextCompletion to produce subject and",
        "precedenceTier": 4
      }
    },
    {
      "file": "BGYY_GenerateAndValidateDraft.xaml",
      "workflow": "BGYY_GenerateAndValidateDraft",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[BGYY_GenerateAndValidateDraft] GenAI response received — OutputLength=&quot; &amp; If(genAiRawOutput IsNot Nothing, genAiRawOutput.Length.ToString(), &quot;0&quot;) &amp; &quot; chars",
      "resolvedValue": "[BGYY_GenerateAndValidateDraft] GenAI response received — OutputLength=&quot; &amp; If(genAiRawOutput IsNot Nothing, genAiRawOutput.Length.ToString(), &quot;0&quot;) &amp; &quot; chars",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 10,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[BGYY_GenerateAndValidateDraft] GenAI response received — OutputLength=&quot; &a",
        "precedenceTier": 4
      }
    },
    {
      "file": "BGYY_GenerateAndValidateDraft.xaml",
      "workflow": "BGYY_GenerateAndValidateDraft",
      "activityType": "If",
      "propertyName": "Condition",
      "sourceBinding": "attribute-value",
      "originalValue": "[String.IsNullOrWhiteSpace(str_GenAiRawOutput) = True]",
      "resolvedValue": "[String.IsNullOrWhiteSpace(str_GenAiRawOutput) = True]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 1,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[String.IsNullOrWhiteSpace(str_GenAiRawOutput) = True]",
        "precedenceTier": 4
      }
    },
    {
      "file": "BGYY_GenerateAndValidateDraft.xaml",
      "workflow": "BGYY_GenerateAndValidateDraft",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Placeholder — Then branch has no activities yet&quot;]",
      "resolvedValue": "[&quot;Placeholder — Then branch has no activities yet&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 11,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Placeholder — Then branch has no activities yet&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "BGYY_GenerateAndValidateDraft.xaml",
      "workflow": "BGYY_GenerateAndValidateDraft",
      "activityType": "Assign",
      "propertyName": "To",
      "sourceBinding": "variable",
      "originalValue": "[str_ParsedSubject]",
      "resolvedValue": "[str_ParsedSubject]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 2,
      "provenance": {
        "sourceKind": "variable",
        "sourceName": "str_ParsedSubject",
        "sourceWorkflow": "BGYY_GenerateAndValidateDraft",
        "precedenceTier": 2
      }
    },
    {
      "file": "BGYY_GenerateAndValidateDraft.xaml",
      "workflow": "BGYY_GenerateAndValidateDraft",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "[Newtonsoft.Json.Linq.JObject.Parse(str_GenAiRawOutput)(&quot;Subject&quot;).ToString()]",
      "resolvedValue": "[Newtonsoft.Json.Linq.JObject.Parse(str_GenAiRawOutput)(&quot;Subject&quot;).ToString()]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 2,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[Newtonsoft.Json.Linq.JObject.Parse(str_GenAiRawOutput)(&quot;Subject&quot;).ToS",
        "precedenceTier": 4
      }
    },
    {
      "file": "BGYY_GenerateAndValidateDraft.xaml",
      "workflow": "BGYY_GenerateAndValidateDraft",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Error in Attempt to parse JSON output — extract Subject field (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "resolvedValue": "[&quot;Error in Attempt to parse JSON output — extract Subject field (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 12,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Error in Attempt to parse JSON output — extract Subject field (&quot; &am",
        "precedenceTier": 4
      }
    },
    {
      "file": "BGYY_GenerateAndValidateDraft.xaml",
      "workflow": "BGYY_GenerateAndValidateDraft",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "&quot;Error in Attempt to parse JSON output — extract Subject field: &quot; &amp; exception.Message",
      "resolvedValue": "&quot;Error in Attempt to parse JSON output — extract Subject field: &quot; &amp; exception.Message",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 13,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "&quot;Error in Attempt to parse JSON output — extract Subject field: &quot; &amp",
        "precedenceTier": 4
      }
    },
    {
      "file": "BGYY_GenerateAndValidateDraft.xaml",
      "workflow": "BGYY_GenerateAndValidateDraft",
      "activityType": "Assign",
      "propertyName": "To",
      "sourceBinding": "variable",
      "originalValue": "[str_ParsedBody]",
      "resolvedValue": "[str_ParsedBody]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 3,
      "provenance": {
        "sourceKind": "variable",
        "sourceName": "str_ParsedBody",
        "sourceWorkflow": "BGYY_GenerateAndValidateDraft",
        "precedenceTier": 2
      }
    },
    {
      "file": "BGYY_GenerateAndValidateDraft.xaml",
      "workflow": "BGYY_GenerateAndValidateDraft",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "[Newtonsoft.Json.Linq.JObject.Parse(str_GenAiRawOutput)(&quot;Body&quot;).ToString()]",
      "resolvedValue": "[Newtonsoft.Json.Linq.JObject.Parse(str_GenAiRawOutput)(&quot;Body&quot;).ToString()]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 3,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[Newtonsoft.Json.Linq.JObject.Parse(str_GenAiRawOutput)(&quot;Body&quot;).ToStri",
        "precedenceTier": 4
      }
    },
    {
      "file": "BGYY_GenerateAndValidateDraft.xaml",
      "workflow": "BGYY_GenerateAndValidateDraft",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Error in Attempt to parse JSON output — extract Body field (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "resolvedValue": "[&quot;Error in Attempt to parse JSON output — extract Body field (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 14,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Error in Attempt to parse JSON output — extract Body field (&quot; &amp; ",
        "precedenceTier": 4
      }
    },
    {
      "file": "BGYY_GenerateAndValidateDraft.xaml",
      "workflow": "BGYY_GenerateAndValidateDraft",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "&quot;Error in Attempt to parse JSON output — extract Body field: &quot; &amp; exception.Message",
      "resolvedValue": "&quot;Error in Attempt to parse JSON output — extract Body field: &quot; &amp; exception.Message",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 15,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "&quot;Error in Attempt to parse JSON output — extract Body field: &quot; &amp; e",
        "precedenceTier": 4
      }
    },
    {
      "file": "BGYY_GenerateAndValidateDraft.xaml",
      "workflow": "BGYY_GenerateAndValidateDraft",
      "activityType": "Assign",
      "propertyName": "To",
      "sourceBinding": "variable",
      "originalValue": "[bool_JsonParseSuccess]",
      "resolvedValue": "[bool_JsonParseSuccess]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 4,
      "provenance": {
        "sourceKind": "variable",
        "sourceName": "bool_JsonParseSuccess",
        "sourceWorkflow": "BGYY_GenerateAndValidateDraft",
        "precedenceTier": 2
      }
    },
    {
      "file": "BGYY_GenerateAndValidateDraft.xaml",
      "workflow": "BGYY_GenerateAndValidateDraft",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "[Not String.IsNullOrWhiteSpace(str_ParsedSubject) AndAlso Not String.IsNullOrWhiteSpace(str_ParsedBody)]",
      "resolvedValue": "[Not String.IsNullOrWhiteSpace(str_ParsedSubject) AndAlso Not String.IsNullOrWhiteSpace(str_ParsedBody)]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 4,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[Not String.IsNullOrWhiteSpace(str_ParsedSubject) AndAlso Not String.IsNullOrWhi",
        "precedenceTier": 4
      }
    },
    {
      "file": "BGYY_GenerateAndValidateDraft.xaml",
      "workflow": "BGYY_GenerateAndValidateDraft",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "variable",
      "originalValue": "",
      "resolvedValue": "[str_LogMessage]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 16,
      "provenance": {
        "sourceKind": "variable",
        "sourceName": "str_LogMessage",
        "sourceWorkflow": "BGYY_GenerateAndValidateDraft",
        "precedenceTier": 2
      }
    },
    {
      "file": "BGYY_GenerateAndValidateDraft.xaml",
      "workflow": "BGYY_GenerateAndValidateDraft",
      "activityType": "If",
      "propertyName": "Condition",
      "sourceBinding": "attribute-value",
      "originalValue": "[bool_JsonParseSuccess = True]",
      "resolvedValue": "[bool_JsonParseSuccess = True]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 2,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[bool_JsonParseSuccess = True]",
        "precedenceTier": 4
      }
    },
    {
      "file": "BGYY_GenerateAndValidateDraft.xaml",
      "workflow": "BGYY_GenerateAndValidateDraft",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Placeholder — Then branch has no activities yet&quot;]",
      "resolvedValue": "[&quot;Placeholder — Then branch has no activities yet&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 17,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Placeholder — Then branch has no activities yet&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "BGYY_GenerateAndValidateDraft.xaml",
      "workflow": "BGYY_GenerateAndValidateDraft",
      "activityType": "If",
      "propertyName": "Condition",
      "sourceBinding": "attribute-value",
      "originalValue": "[str_ParsedBody.ToLowerInvariant().Contains(InFullName.ToLowerInvariant()) = False]",
      "resolvedValue": "[str_ParsedBody.ToLowerInvariant().Contains(InFullName.ToLowerInvariant()) = False]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 3,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[str_ParsedBody.ToLowerInvariant().Contains(InFullName.ToLowerInvariant()) = Fal",
        "precedenceTier": 4
      }
    },
    {
      "file": "BGYY_GenerateAndValidateDraft.xaml",
      "workflow": "BGYY_GenerateAndValidateDraft",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Placeholder — Then branch has no activities yet&quot;]",
      "resolvedValue": "[&quot;Placeholder — Then branch has no activities yet&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 18,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Placeholder — Then branch has no activities yet&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "BGYY_GenerateAndValidateDraft.xaml",
      "workflow": "BGYY_GenerateAndValidateDraft",
      "activityType": "IsMatch",
      "propertyName": "Input",
      "sourceBinding": "attribute-value",
      "originalValue": "[str_ParsedSubject &amp; &quot; &quot; &amp; str_ParsedBody]",
      "resolvedValue": "[str_ParsedSubject &amp; &quot; &quot; &amp; str_ParsedBody]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[str_ParsedSubject &amp; &quot; &quot; &amp; str_ParsedBody]",
        "precedenceTier": 4
      }
    },
    {
      "file": "BGYY_GenerateAndValidateDraft.xaml",
      "workflow": "BGYY_GenerateAndValidateDraft",
      "activityType": "IsMatch",
      "propertyName": "Pattern",
      "sourceBinding": "variable",
      "originalValue": "[str_PlaceholderPattern]",
      "resolvedValue": "[str_PlaceholderPattern]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "variable",
        "sourceName": "str_PlaceholderPattern",
        "sourceWorkflow": "BGYY_GenerateAndValidateDraft",
        "precedenceTier": 2
      }
    },
    {
      "file": "BGYY_GenerateAndValidateDraft.xaml",
      "workflow": "BGYY_GenerateAndValidateDraft",
      "activityType": "Assign",
      "propertyName": "To",
      "sourceBinding": "variable",
      "originalValue": "[int_WordCount]",
      "resolvedValue": "[int_WordCount]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 5,
      "provenance": {
        "sourceKind": "variable",
        "sourceName": "int_WordCount",
        "sourceWorkflow": "BGYY_GenerateAndValidateDraft",
        "precedenceTier": 2
      }
    },
    {
      "file": "BGYY_GenerateAndValidateDraft.xaml",
      "workflow": "BGYY_GenerateAndValidateDraft",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "[str_ParsedBody.Split(New Char(){&quot; &quot;c, &quot;.&quot;c, &quot;,&quot;c, Environment.NewLine(0)}, StringSplitOptions.RemoveEmptyEntries).Length]",
      "resolvedValue": "[str_ParsedBody.Split(New Char(){&quot; &quot;c, &quot;.&quot;c, &quot;,&quot;c, Environment.NewLine(0)}, StringSplitOptions.RemoveEmptyEntries).Length]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 5,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[str_ParsedBody.Split(New Char(){&quot; &quot;c, &quot;.&quot;c, &quot;,&quot;c,",
        "precedenceTier": 4
      }
    },
    {
      "file": "BGYY_GenerateAndValidateDraft.xaml",
      "workflow": "BGYY_GenerateAndValidateDraft",
      "activityType": "If",
      "propertyName": "Condition",
      "sourceBinding": "attribute-value",
      "originalValue": "[int_WordCount &lt; 60 OrElse int_WordCount &gt; 150 = True]",
      "resolvedValue": "[int_WordCount &lt; 60 OrElse int_WordCount &gt; 150 = True]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 4,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[int_WordCount &lt; 60 OrElse int_WordCount &gt; 150 = True]",
        "precedenceTier": 4
      }
    },
    {
      "file": "BGYY_GenerateAndValidateDraft.xaml",
      "workflow": "BGYY_GenerateAndValidateDraft",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Placeholder — Then branch has no activities yet&quot;]",
      "resolvedValue": "[&quot;Placeholder — Then branch has no activities yet&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 19,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Placeholder — Then branch has no activities yet&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "BGYY_GenerateAndValidateDraft.xaml",
      "workflow": "BGYY_GenerateAndValidateDraft",
      "activityType": "ForEach",
      "propertyName": "Values",
      "sourceBinding": "variable",
      "originalValue": "[BannedPhrasesList]",
      "resolvedValue": "[BannedPhrasesList]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "variable",
        "sourceName": "BannedPhrasesList",
        "sourceWorkflow": "BGYY_GenerateAndValidateDraft",
        "precedenceTier": 2
      }
    },
    {
      "file": "BGYY_GenerateAndValidateDraft.xaml",
      "workflow": "BGYY_GenerateAndValidateDraft",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Placeholder — ForEach body has no activities yet&quot;]",
      "resolvedValue": "[&quot;Placeholder — ForEach body has no activities yet&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 20,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Placeholder — ForEach body has no activities yet&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "BGYY_GenerateAndValidateDraft.xaml",
      "workflow": "BGYY_GenerateAndValidateDraft",
      "activityType": "Assign",
      "propertyName": "To",
      "sourceBinding": "variable",
      "originalValue": "[bool_ValidationPassed]",
      "resolvedValue": "[bool_ValidationPassed]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 6,
      "provenance": {
        "sourceKind": "variable",
        "sourceName": "bool_ValidationPassed",
        "sourceWorkflow": "BGYY_GenerateAndValidateDraft",
        "precedenceTier": 2
      }
    },
    {
      "file": "BGYY_GenerateAndValidateDraft.xaml",
      "workflow": "BGYY_GenerateAndValidateDraft",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "[bool_JsonParseSuccess AndAlso Not String.IsNullOrWhiteSpace(str_ParsedBody) AndAlso str_ParsedBody.ToLowerInvariant().Contains(InFullName.ToLowerInvariant()) AndAlso Not bool_IsPlaceholderFound AndAlso int_WordCount &gt;= 60 AndAlso int_WordCount &lt;= 150 AndAlso Not bool_BannedPhraseFound]",
      "resolvedValue": "[bool_JsonParseSuccess AndAlso Not String.IsNullOrWhiteSpace(str_ParsedBody) AndAlso str_ParsedBody.ToLowerInvariant().Contains(InFullName.ToLowerInvariant()) AndAlso Not bool_IsPlaceholderFound AndAlso int_WordCount &gt;= 60 AndAlso int_WordCount &lt;= 150 AndAlso Not bool_BannedPhraseFound]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 6,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[bool_JsonParseSuccess AndAlso Not String.IsNullOrWhiteSpace(str_ParsedBody) And",
        "precedenceTier": 4
      }
    },
    {
      "file": "BGYY_GenerateAndValidateDraft.xaml",
      "workflow": "BGYY_GenerateAndValidateDraft",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "variable",
      "originalValue": "",
      "resolvedValue": "[str_LogMessage]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 21,
      "provenance": {
        "sourceKind": "variable",
        "sourceName": "str_LogMessage",
        "sourceWorkflow": "BGYY_GenerateAndValidateDraft",
        "precedenceTier": 2
      }
    },
    {
      "file": "BGYY_GenerateAndValidateDraft.xaml",
      "workflow": "BGYY_GenerateAndValidateDraft",
      "activityType": "Assign",
      "propertyName": "To",
      "sourceBinding": "variable",
      "originalValue": "[str_DraftArtifactJson]",
      "resolvedValue": "[str_DraftArtifactJson]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 7,
      "provenance": {
        "sourceKind": "variable",
        "sourceName": "str_DraftArtifactJson",
        "sourceWorkflow": "BGYY_GenerateAndValidateDraft",
        "precedenceTier": 2
      }
    },
    {
      "file": "BGYY_GenerateAndValidateDraft.xaml",
      "workflow": "BGYY_GenerateAndValidateDraft",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "[Newtonsoft.Json.JsonConvert.SerializeObject(New With {.RunId = InRunId, .FullName = InFullName, .Subject = str_ParsedSubject, .Body = str_ParsedBody, .ValidationPassed = bool_ValidationPassed, .ValidationReason = If(bool_ValidationPassed, &quot;AllGatesPassed&quot;, str_ValidationFailReason), .WordCount = int_WordCount, .BannedPhraseFound = bool_BannedPhraseFound, .VoiceProfileLoaded = bool_VoiceProfileLoaded, .GeneratedAt = DateTime.UtcNow.ToString(&quot;o&quot;)})]",
      "resolvedValue": "[Newtonsoft.Json.JsonConvert.SerializeObject(New With {.RunId = InRunId, .FullName = InFullName, .Subject = str_ParsedSubject, .Body = str_ParsedBody, .ValidationPassed = bool_ValidationPassed, .ValidationReason = If(bool_ValidationPassed, &quot;AllGatesPassed&quot;, str_ValidationFailReason), .WordCount = int_WordCount, .BannedPhraseFound = bool_BannedPhraseFound, .VoiceProfileLoaded = bool_VoiceProfileLoaded, .GeneratedAt = DateTime.UtcNow.ToString(&quot;o&quot;)})]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 7,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[Newtonsoft.Json.JsonConvert.SerializeObject(New With {.RunId = InRunId, .FullNa",
        "precedenceTier": 4
      }
    },
    {
      "file": "BGYY_GenerateAndValidateDraft.xaml",
      "workflow": "BGYY_GenerateAndValidateDraft",
      "activityType": "Assign",
      "propertyName": "To",
      "sourceBinding": "variable",
      "originalValue": "[str_DraftArtifactPath]",
      "resolvedValue": "[str_DraftArtifactPath]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 8,
      "provenance": {
        "sourceKind": "variable",
        "sourceName": "str_DraftArtifactPath",
        "sourceWorkflow": "BGYY_GenerateAndValidateDraft",
        "precedenceTier": 2
      }
    },
    {
      "file": "BGYY_GenerateAndValidateDraft.xaml",
      "workflow": "BGYY_GenerateAndValidateDraft",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;runs/&quot; &amp; InRunId &amp; &quot;/drafts/&quot; &amp; System.Text.RegularExpressions.Regex.Replace(InFullName, &quot;[^a-zA-Z0-9_-]&quot;, &quot;_&quot;) &amp; &quot;.json&quot;]",
      "resolvedValue": "[&quot;runs/&quot; &amp; InRunId &amp; &quot;/drafts/&quot; &amp; System.Text.RegularExpressions.Regex.Replace(InFullName, &quot;[^a-zA-Z0-9_-]&quot;, &quot;_&quot;) &amp; &quot;.json&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 8,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;runs/&quot; &amp; InRunId &amp; &quot;/drafts/&quot; &amp; System.Text.Re",
        "precedenceTier": 4
      }
    },
    {
      "file": "BGYY_GenerateAndValidateDraft.xaml",
      "workflow": "BGYY_GenerateAndValidateDraft",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;=== Completed: BGYY_GenerateAndValidateDraft ===&quot;]",
      "resolvedValue": "[&quot;=== Completed: BGYY_GenerateAndValidateDraft ===&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 22,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;=== Completed: BGYY_GenerateAndValidateDraft ===&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "BGYY_SendGmail.xaml",
      "workflow": "BGYY_SendGmail",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "&quot;[BGYY_SendGmail] START | RunId=&quot; &amp; InRunId &amp; &quot; | Recipient=&quot; &amp; InRecipientEmail &amp; &quot; | Subject=&quot; &amp; InSubject",
      "resolvedValue": "&quot;[BGYY_SendGmail] START | RunId=&quot; &amp; InRunId &amp; &quot; | Recipient=&quot; &amp; InRecipientEmail &amp; &quot; | Subject=&quot; &amp; InSubject",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "&quot;[BGYY_SendGmail] START | RunId=&quot; &amp; InRunId &amp; &quot; | Recipie",
        "precedenceTier": 4
      }
    },
    {
      "file": "BGYY_SendGmail.xaml",
      "workflow": "BGYY_SendGmail",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Error in Read BGYY_DryRun asset to determine mock mode (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "resolvedValue": "[&quot;Error in Read BGYY_DryRun asset to determine mock mode (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 1,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Error in Read BGYY_DryRun asset to determine mock mode (&quot; &amp; exce",
        "precedenceTier": 4
      }
    },
    {
      "file": "BGYY_SendGmail.xaml",
      "workflow": "BGYY_SendGmail",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "&quot;Error in Read BGYY_DryRun asset to determine mock mode: &quot; &amp; exception.Message",
      "resolvedValue": "&quot;Error in Read BGYY_DryRun asset to determine mock mode: &quot; &amp; exception.Message",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 2,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "&quot;Error in Read BGYY_DryRun asset to determine mock mode: &quot; &amp; excep",
        "precedenceTier": 4
      }
    },
    {
      "file": "BGYY_SendGmail.xaml",
      "workflow": "BGYY_SendGmail",
      "activityType": "Assign",
      "propertyName": "To",
      "sourceBinding": "variable",
      "originalValue": "[bool_DryRunEnabled]",
      "resolvedValue": "[bool_DryRunEnabled]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "variable",
        "sourceName": "bool_DryRunEnabled",
        "sourceWorkflow": "BGYY_SendGmail",
        "precedenceTier": 2
      }
    },
    {
      "file": "BGYY_SendGmail.xaml",
      "workflow": "BGYY_SendGmail",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "[Boolean.Parse(If(String.IsNullOrWhiteSpace(str_DryRunAssetValue), &quot;False&quot;, str_DryRunAssetValue))]",
      "resolvedValue": "[Boolean.Parse(If(String.IsNullOrWhiteSpace(str_DryRunAssetValue), &quot;False&quot;, str_DryRunAssetValue))]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[Boolean.Parse(If(String.IsNullOrWhiteSpace(str_DryRunAssetValue), &quot;False&q",
        "precedenceTier": 4
      }
    },
    {
      "file": "BGYY_SendGmail.xaml",
      "workflow": "BGYY_SendGmail",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Error in Parse dry-run asset string to Boolean (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "resolvedValue": "[&quot;Error in Parse dry-run asset string to Boolean (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 3,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Error in Parse dry-run asset string to Boolean (&quot; &amp; exception.Ge",
        "precedenceTier": 4
      }
    },
    {
      "file": "BGYY_SendGmail.xaml",
      "workflow": "BGYY_SendGmail",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "&quot;Error in Parse dry-run asset string to Boolean: &quot; &amp; exception.Message",
      "resolvedValue": "&quot;Error in Parse dry-run asset string to Boolean: &quot; &amp; exception.Message",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 4,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "&quot;Error in Parse dry-run asset string to Boolean: &quot; &amp; exception.Mes",
        "precedenceTier": 4
      }
    },
    {
      "file": "BGYY_SendGmail.xaml",
      "workflow": "BGYY_SendGmail",
      "activityType": "If",
      "propertyName": "Condition",
      "sourceBinding": "attribute-value",
      "originalValue": "[bool_DryRunEnabled = True]",
      "resolvedValue": "[bool_DryRunEnabled = True]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[bool_DryRunEnabled = True]",
        "precedenceTier": 4
      }
    },
    {
      "file": "BGYY_SendGmail.xaml",
      "workflow": "BGYY_SendGmail",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Placeholder — Then branch has no activities yet&quot;]",
      "resolvedValue": "[&quot;Placeholder — Then branch has no activities yet&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 5,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Placeholder — Then branch has no activities yet&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "BGYY_SendGmail.xaml",
      "workflow": "BGYY_SendGmail",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "&quot;[BGYY_SendGmail] DRY-RUN active — email NOT sent | RunId=&quot; &amp; InRunId &amp; &quot; | Recipient=&quot; &amp; InRecipientEmail &amp; &quot; | Subject=&quot; &amp; InSubject",
      "resolvedValue": "&quot;[BGYY_SendGmail] DRY-RUN active — email NOT sent | RunId=&quot; &amp; InRunId &amp; &quot; | Recipient=&quot; &amp; InRecipientEmail &amp; &quot; | Subject=&quot; &amp; InSubject",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 6,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "&quot;[BGYY_SendGmail] DRY-RUN active — email NOT sent | RunId=&quot; &amp; InRu",
        "precedenceTier": 4
      }
    },
    {
      "file": "BGYY_SendGmail.xaml",
      "workflow": "BGYY_SendGmail",
      "activityType": "If",
      "propertyName": "Condition",
      "sourceBinding": "attribute-value",
      "originalValue": "[String.IsNullOrWhiteSpace(InRecipientEmail) OrElse String.IsNullOrWhiteSpace(InSubject) OrElse String.IsNullOrWhiteSpace(InBody)]",
      "resolvedValue": "[String.IsNullOrWhiteSpace(InRecipientEmail) OrElse String.IsNullOrWhiteSpace(InSubject) OrElse String.IsNullOrWhiteSpace(InBody)]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 1,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[String.IsNullOrWhiteSpace(InRecipientEmail) OrElse String.IsNullOrWhiteSpace(In",
        "precedenceTier": 4
      }
    },
    {
      "file": "BGYY_SendGmail.xaml",
      "workflow": "BGYY_SendGmail",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Placeholder — Then branch has no activities yet&quot;]",
      "resolvedValue": "[&quot;Placeholder — Then branch has no activities yet&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 7,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Placeholder — Then branch has no activities yet&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "BGYY_SendGmail.xaml",
      "workflow": "BGYY_SendGmail",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "&quot;[BGYY_SendGmail] VALIDATION FAILED — one or more required send inputs are null/empty | RunId=&quot; &amp; InRunId &amp; &quot; | RecipientEmailEmpty=&quot; &amp; String.IsNullOrWhiteSpace(InRecipientEmail).ToString() &amp; &quot; | SubjectEmpty=&quot; &amp; String.IsNullOrWhiteSpace(InSubject).ToString() &amp; &quot; | BodyEmpty=&quot; &amp; String.IsNullOrWhiteSpace(InBody).ToString()",
      "resolvedValue": "&quot;[BGYY_SendGmail] VALIDATION FAILED — one or more required send inputs are null/empty | RunId=&quot; &amp; InRunId &amp; &quot; | RecipientEmailEmpty=&quot; &amp; String.IsNullOrWhiteSpace(InRecipientEmail).ToString() &amp; &quot; | SubjectEmpty=&quot; &amp; String.IsNullOrWhiteSpace(InSubject).ToString() &amp; &quot; | BodyEmpty=&quot; &amp; String.IsNullOrWhiteSpace(InBody).ToString()",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 8,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "&quot;[BGYY_SendGmail] VALIDATION FAILED — one or more required send inputs are ",
        "precedenceTier": 4
      }
    },
    {
      "file": "BGYY_SendGmail.xaml",
      "workflow": "BGYY_SendGmail",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[BGYY_SendGmail] Entering RetryScope for Gmail send | RunId=&quot; &amp; InRunId &amp; &quot; | Recipient=&quot; &amp; InRecipientEmail &amp; &quot; | MaxAttempts=3",
      "resolvedValue": "[BGYY_SendGmail] Entering RetryScope for Gmail send | RunId=&quot; &amp; InRunId &amp; &quot; | Recipient=&quot; &amp; InRecipientEmail &amp; &quot; | MaxAttempts=3",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 9,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[BGYY_SendGmail] Entering RetryScope for Gmail send | RunId=&quot; &amp; InRunId",
        "precedenceTier": 4
      }
    },
    {
      "file": "BGYY_SendGmail.xaml",
      "workflow": "BGYY_SendGmail",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Placeholder — RetryScope body has no activities yet&quot;]",
      "resolvedValue": "[&quot;Placeholder — RetryScope body has no activities yet&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 10,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Placeholder — RetryScope body has no activities yet&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "BGYY_SendGmail.xaml",
      "workflow": "BGYY_SendGmail",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "&quot;[BGYY_SendGmail] Gmail send attempt &quot; &amp; int_AttemptNumber.ToString() &amp; &quot; of 3 | RunId=&quot; &amp; InRunId &amp; &quot; | Recipient=&quot; &amp; InRecipientEmail",
      "resolvedValue": "&quot;[BGYY_SendGmail] Gmail send attempt &quot; &amp; int_AttemptNumber.ToString() &amp; &quot; of 3 | RunId=&quot; &amp; InRunId &amp; &quot; | Recipient=&quot; &amp; InRecipientEmail",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 11,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "&quot;[BGYY_SendGmail] Gmail send attempt &quot; &amp; int_AttemptNumber.ToStrin",
        "precedenceTier": 4
      }
    },
    {
      "file": "BGYY_SendGmail.xaml",
      "workflow": "BGYY_SendGmail",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[HANDOFF] Activity &apos;Send birthday greeting email via Gmail Integration Service connector&apos; (UiPath.GSuite.Activities.GmailSendMessage) requires developer implementation — missing: Body",
      "resolvedValue": "[HANDOFF] Activity &apos;Send birthday greeting email via Gmail Integration Service connector&apos; (UiPath.GSuite.Activities.GmailSendMessage) requires developer implementation — missing: Body",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 12,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[HANDOFF] Activity &apos;Send birthday greeting email via Gmail Integration Serv",
        "precedenceTier": 4
      }
    },
    {
      "file": "BGYY_SendGmail.xaml",
      "workflow": "BGYY_SendGmail",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "workflowArgument",
      "originalValue": "",
      "resolvedValue": "[OutGmailMessageId]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 13,
      "provenance": {
        "sourceKind": "workflowArgument",
        "sourceName": "OutGmailMessageId",
        "sourceWorkflow": "BGYY_SendGmail",
        "precedenceTier": 1
      },
      "rejectedCandidates": [
        {
          "sourceKind": "variable",
          "sourceName": "str_GmailMessageId",
          "sourceWorkflow": "BGYY_SendGmail",
          "precedenceTier": 2,
          "rejectionReason": "lowerPrecedence"
        },
        {
          "sourceKind": "variable",
          "sourceName": "str_LogMessage",
          "sourceWorkflow": "BGYY_SendGmail",
          "precedenceTier": 2,
          "rejectionReason": "lowerPrecedence"
        }
      ]
    },
    {
      "file": "BGYY_SendGmail.xaml",
      "workflow": "BGYY_SendGmail",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "&quot;[BGYY_SendGmail] PERSISTENT FAILURE — Gmail send failed after 3 attempts | RunId=&quot; &amp; InRunId &amp; &quot; | Recipient=&quot; &amp; InRecipientEmail &amp; &quot; | LastException=&quot; &amp; lastSendException",
      "resolvedValue": "&quot;[BGYY_SendGmail] PERSISTENT FAILURE — Gmail send failed after 3 attempts | RunId=&quot; &amp; InRunId &amp; &quot; | Recipient=&quot; &amp; InRecipientEmail &amp; &quot; | LastException=&quot; &amp; lastSendException",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 14,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "&quot;[BGYY_SendGmail] PERSISTENT FAILURE — Gmail send failed after 3 attempts |",
        "precedenceTier": 4
      }
    },
    {
      "file": "BGYY_SendGmail.xaml",
      "workflow": "BGYY_SendGmail",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Error in Capture desktop screenshot as failure evidence (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "resolvedValue": "[&quot;Error in Capture desktop screenshot as failure evidence (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 15,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Error in Capture desktop screenshot as failure evidence (&quot; &amp; exc",
        "precedenceTier": 4
      }
    },
    {
      "file": "BGYY_SendGmail.xaml",
      "workflow": "BGYY_SendGmail",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "&quot;Error in Capture desktop screenshot as failure evidence: &quot; &amp; exception.Message",
      "resolvedValue": "&quot;Error in Capture desktop screenshot as failure evidence: &quot; &amp; exception.Message",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 16,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "&quot;Error in Capture desktop screenshot as failure evidence: &quot; &amp; exce",
        "precedenceTier": 4
      }
    },
    {
      "file": "BGYY_SendGmail.xaml",
      "workflow": "BGYY_SendGmail",
      "activityType": "Assign",
      "propertyName": "To",
      "sourceBinding": "variable",
      "originalValue": "[str_TempScreenshotFile]",
      "resolvedValue": "[str_TempScreenshotFile]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 1,
      "provenance": {
        "sourceKind": "variable",
        "sourceName": "str_TempScreenshotFile",
        "sourceWorkflow": "BGYY_SendGmail",
        "precedenceTier": 2
      }
    },
    {
      "file": "BGYY_SendGmail.xaml",
      "workflow": "BGYY_SendGmail",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "[System.IO.Path.Combine(System.IO.Path.GetTempPath(), &quot;BGYY_SendGmail_&quot; &amp; InRunId &amp; &quot;_&quot; &amp; DateTime.UtcNow.ToString(&quot;yyyyMMddHHmmss&quot;) &amp; &quot;.png&quot;)]",
      "resolvedValue": "[System.IO.Path.Combine(System.IO.Path.GetTempPath(), &quot;BGYY_SendGmail_&quot; &amp; InRunId &amp; &quot;_&quot; &amp; DateTime.UtcNow.ToString(&quot;yyyyMMddHHmmss&quot;) &amp; &quot;.png&quot;)]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 1,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[System.IO.Path.Combine(System.IO.Path.GetTempPath(), &quot;BGYY_SendGmail_&quot",
        "precedenceTier": 4
      }
    },
    {
      "file": "BGYY_SendGmail.xaml",
      "workflow": "BGYY_SendGmail",
      "activityType": "Assign",
      "propertyName": "To",
      "sourceBinding": "variable",
      "originalValue": "[str_ScreenshotBucketPath]",
      "resolvedValue": "[str_ScreenshotBucketPath]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 2,
      "provenance": {
        "sourceKind": "variable",
        "sourceName": "str_ScreenshotBucketPath",
        "sourceWorkflow": "BGYY_SendGmail",
        "precedenceTier": 2
      }
    },
    {
      "file": "BGYY_SendGmail.xaml",
      "workflow": "BGYY_SendGmail",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;runs/&quot; &amp; InRunId &amp; &quot;/error/BGYY_SendGmail_&quot; &amp; InRecipientEmail.GetHashCode().ToString(&quot;X8&quot;) &amp; &quot;_&quot; &amp; DateTime.UtcNow.ToString(&quot;yyyyMMddHHmmss&quot;) &amp; &quot;.png&quot;]",
      "resolvedValue": "[&quot;runs/&quot; &amp; InRunId &amp; &quot;/error/BGYY_SendGmail_&quot; &amp; InRecipientEmail.GetHashCode().ToString(&quot;X8&quot;) &amp; &quot;_&quot; &amp; DateTime.UtcNow.ToString(&quot;yyyyMMddHHmmss&quot;) &amp; &quot;.png&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 2,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;runs/&quot; &amp; InRunId &amp; &quot;/error/BGYY_SendGmail_&quot; &amp; ",
        "precedenceTier": 4
      }
    },
    {
      "file": "BGYY_SendGmail.xaml",
      "workflow": "BGYY_SendGmail",
      "activityType": "UploadStorageFile",
      "propertyName": "Destination",
      "sourceBinding": "variable",
      "originalValue": "[str_ScreenshotBucketPath]",
      "resolvedValue": "[str_ScreenshotBucketPath]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "variable",
        "sourceName": "str_ScreenshotBucketPath",
        "sourceWorkflow": "BGYY_SendGmail",
        "precedenceTier": 2
      }
    },
    {
      "file": "BGYY_SendGmail.xaml",
      "workflow": "BGYY_SendGmail",
      "activityType": "UploadStorageFile",
      "propertyName": "FileResource",
      "sourceBinding": "variable",
      "originalValue": "[str_TempScreenshotFile]",
      "resolvedValue": "[str_TempScreenshotFile]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "variable",
        "sourceName": "str_TempScreenshotFile",
        "sourceWorkflow": "BGYY_SendGmail",
        "precedenceTier": 2
      }
    },
    {
      "file": "BGYY_SendGmail.xaml",
      "workflow": "BGYY_SendGmail",
      "activityType": "UploadStorageFile",
      "propertyName": "Path",
      "sourceBinding": "attribute-value",
      "originalValue": "&quot;screenshotBucketPath&quot;",
      "resolvedValue": "&quot;screenshotBucketPath&quot;",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "&quot;screenshotBucketPath&quot;",
        "precedenceTier": 4
      }
    },
    {
      "file": "BGYY_SendGmail.xaml",
      "workflow": "BGYY_SendGmail",
      "activityType": "UploadStorageFile",
      "propertyName": "StorageBucketName",
      "sourceBinding": "attribute-value",
      "originalValue": "&quot;BGYY_RunArtifacts&quot;",
      "resolvedValue": "&quot;BGYY_RunArtifacts&quot;",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "&quot;BGYY_RunArtifacts&quot;",
        "precedenceTier": 4
      }
    },
    {
      "file": "BGYY_SendGmail.xaml",
      "workflow": "BGYY_SendGmail",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Error in Upload failure screenshot to BGYY_RunArtifacts Storage Bucket (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "resolvedValue": "[&quot;Error in Upload failure screenshot to BGYY_RunArtifacts Storage Bucket (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 17,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Error in Upload failure screenshot to BGYY_RunArtifacts Storage Bucket (&",
        "precedenceTier": 4
      }
    },
    {
      "file": "BGYY_SendGmail.xaml",
      "workflow": "BGYY_SendGmail",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "&quot;Error in Upload failure screenshot to BGYY_RunArtifacts Storage Bucket: &quot; &amp; exception.Message",
      "resolvedValue": "&quot;Error in Upload failure screenshot to BGYY_RunArtifacts Storage Bucket: &quot; &amp; exception.Message",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 18,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "&quot;Error in Upload failure screenshot to BGYY_RunArtifacts Storage Bucket: &q",
        "precedenceTier": 4
      }
    },
    {
      "file": "BGYY_SendGmail.xaml",
      "workflow": "BGYY_SendGmail",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "&quot;[BGYY_SendGmail] END | RunId=&quot; &amp; InRunId &amp; &quot; | Recipient=&quot; &amp; InRecipientEmail &amp; &quot; | Succeeded=&quot; &amp; OutSendSucceeded.ToString() &amp; &quot; | MessageId=&quot; &amp; If(String.IsNullOrEmpty(OutGmailMessageId), &quot;(none)&quot;, OutGmailMessageId)",
      "resolvedValue": "&quot;[BGYY_SendGmail] END | RunId=&quot; &amp; InRunId &amp; &quot; | Recipient=&quot; &amp; InRecipientEmail &amp; &quot; | Succeeded=&quot; &amp; OutSendSucceeded.ToString() &amp; &quot; | MessageId=&quot; &amp; If(String.IsNullOrEmpty(OutGmailMessageId), &quot;(none)&quot;, OutGmailMessageId)",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 19,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "&quot;[BGYY_SendGmail] END | RunId=&quot; &amp; InRunId &amp; &quot; | Recipient",
        "precedenceTier": 4
      }
    },
    {
      "file": "BGYY_SendGmail.xaml",
      "workflow": "BGYY_SendGmail",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;=== Completed: BGYY_SendGmail ===&quot;]",
      "resolvedValue": "[&quot;=== Completed: BGYY_SendGmail ===&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 20,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;=== Completed: BGYY_SendGmail ===&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "BGYY_WriteDedupe.xaml",
      "workflow": "BGYY_WriteDedupe",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[BGYY_WriteDedupe][Entry] RunId=&quot; &amp; InRunId &amp; &quot; | PersonKey=&quot; &amp; InPersonKey &amp; &quot; | SendYear=&quot; &amp; InSendYear.ToString() &amp; &quot; | Status=&quot; &amp; InStatus &amp; &quot; | Email=&quot; &amp; InSelectedEmail",
      "resolvedValue": "[BGYY_WriteDedupe][Entry] RunId=&quot; &amp; InRunId &amp; &quot; | PersonKey=&quot; &amp; InPersonKey &amp; &quot; | SendYear=&quot; &amp; InSendYear.ToString() &amp; &quot; | Status=&quot; &amp; InStatus &amp; &quot; | Email=&quot; &amp; InSelectedEmail",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[BGYY_WriteDedupe][Entry] RunId=&quot; &amp; InRunId &amp; &quot; | PersonKey=&q",
        "precedenceTier": 4
      }
    },
    {
      "file": "BGYY_WriteDedupe.xaml",
      "workflow": "BGYY_WriteDedupe",
      "activityType": "Assign",
      "propertyName": "To",
      "sourceBinding": "variable",
      "originalValue": "[str_PersonKeyNormalized]",
      "resolvedValue": "[str_PersonKeyNormalized]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "variable",
        "sourceName": "str_PersonKeyNormalized",
        "sourceWorkflow": "BGYY_WriteDedupe",
        "precedenceTier": 2
      }
    },
    {
      "file": "BGYY_WriteDedupe.xaml",
      "workflow": "BGYY_WriteDedupe",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "[InPersonKey.Trim().ToLowerInvariant()]",
      "resolvedValue": "[InPersonKey.Trim().ToLowerInvariant()]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[InPersonKey.Trim().ToLowerInvariant()]",
        "precedenceTier": 4
      }
    },
    {
      "file": "BGYY_WriteDedupe.xaml",
      "workflow": "BGYY_WriteDedupe",
      "activityType": "QueryEntity",
      "propertyName": "EntityType",
      "sourceBinding": "attribute-value",
      "originalValue": "&quot;BGYY_BirthdaySendLog&quot;",
      "resolvedValue": "&quot;BGYY_BirthdaySendLog&quot;",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "&quot;BGYY_BirthdaySendLog&quot;",
        "precedenceTier": 4
      }
    },
    {
      "file": "BGYY_WriteDedupe.xaml",
      "workflow": "BGYY_WriteDedupe",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "workflowArgument",
      "originalValue": "",
      "resolvedValue": "[InGmailMessageId]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 1,
      "provenance": {
        "sourceKind": "workflowArgument",
        "sourceName": "InGmailMessageId",
        "sourceWorkflow": "BGYY_WriteDedupe",
        "precedenceTier": 1
      },
      "rejectedCandidates": [
        {
          "sourceKind": "variable",
          "sourceName": "str_LogMessage",
          "sourceWorkflow": "BGYY_WriteDedupe",
          "precedenceTier": 2,
          "rejectionReason": "lowerPrecedence"
        }
      ]
    },
    {
      "file": "BGYY_WriteDedupe.xaml",
      "workflow": "BGYY_WriteDedupe",
      "activityType": "Assign",
      "propertyName": "To",
      "sourceBinding": "variable",
      "originalValue": "[bool_RecordExists]",
      "resolvedValue": "[bool_RecordExists]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 1,
      "provenance": {
        "sourceKind": "variable",
        "sourceName": "bool_RecordExists",
        "sourceWorkflow": "BGYY_WriteDedupe",
        "precedenceTier": 2
      }
    },
    {
      "file": "BGYY_WriteDedupe.xaml",
      "workflow": "BGYY_WriteDedupe",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "&quot;obj_QueryResults IsNot Nothing&quot;",
      "resolvedValue": "&quot;obj_QueryResults IsNot Nothing&quot;",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 1,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "&quot;obj_QueryResults IsNot Nothing&quot;",
        "precedenceTier": 4
      }
    },
    {
      "file": "BGYY_WriteDedupe.xaml",
      "workflow": "BGYY_WriteDedupe",
      "activityType": "If",
      "propertyName": "Condition",
      "sourceBinding": "attribute-value",
      "originalValue": "[bool_RecordExists = True]",
      "resolvedValue": "[bool_RecordExists = True]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[bool_RecordExists = True]",
        "precedenceTier": 4
      }
    },
    {
      "file": "BGYY_WriteDedupe.xaml",
      "workflow": "BGYY_WriteDedupe",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[BGYY_WriteDedupe][Branch] Existing record found for PersonKey=&quot; &amp; str_PersonKeyNormalized &amp; &quot; — executing UPDATE with Status=&quot; &amp; InStatus",
      "resolvedValue": "[BGYY_WriteDedupe][Branch] Existing record found for PersonKey=&quot; &amp; str_PersonKeyNormalized &amp; &quot; — executing UPDATE with Status=&quot; &amp; InStatus",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 2,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[BGYY_WriteDedupe][Branch] Existing record found for PersonKey=&quot; &amp; str_",
        "precedenceTier": 4
      }
    },
    {
      "file": "BGYY_WriteDedupe.xaml",
      "workflow": "BGYY_WriteDedupe",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[HANDOFF] Activity &apos;Update Existing BGYY_BirthdaySendLog Record with Latest Status and Audit Fields&apos; (UiPath.DataService.Activities.UpdateEntity) requires developer implementation — missing: EntityObject",
      "resolvedValue": "[HANDOFF] Activity &apos;Update Existing BGYY_BirthdaySendLog Record with Latest Status and Audit Fields&apos; (UiPath.DataService.Activities.UpdateEntity) requires developer implementation — missing: EntityObject",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 3,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[HANDOFF] Activity &apos;Update Existing BGYY_BirthdaySendLog Record with Latest",
        "precedenceTier": 4
      }
    },
    {
      "file": "BGYY_WriteDedupe.xaml",
      "workflow": "BGYY_WriteDedupe",
      "activityType": "Assign",
      "propertyName": "To",
      "sourceBinding": "variable",
      "originalValue": "[obj_DataServiceException]",
      "resolvedValue": "[obj_DataServiceException]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 2,
      "provenance": {
        "sourceKind": "variable",
        "sourceName": "obj_DataServiceException",
        "sourceWorkflow": "BGYY_WriteDedupe",
        "precedenceTier": 2
      }
    },
    {
      "file": "BGYY_WriteDedupe.xaml",
      "workflow": "BGYY_WriteDedupe",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;ex_UpdateException&quot;]",
      "resolvedValue": "[&quot;ex_UpdateException&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 2,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;ex_UpdateException&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "BGYY_WriteDedupe.xaml",
      "workflow": "BGYY_WriteDedupe",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "workflowArgument",
      "originalValue": "",
      "resolvedValue": "[InGmailMessageId]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 4,
      "provenance": {
        "sourceKind": "workflowArgument",
        "sourceName": "InGmailMessageId",
        "sourceWorkflow": "BGYY_WriteDedupe",
        "precedenceTier": 1
      },
      "rejectedCandidates": [
        {
          "sourceKind": "variable",
          "sourceName": "str_LogMessage",
          "sourceWorkflow": "BGYY_WriteDedupe",
          "precedenceTier": 2,
          "rejectionReason": "lowerPrecedence"
        }
      ]
    },
    {
      "file": "BGYY_WriteDedupe.xaml",
      "workflow": "BGYY_WriteDedupe",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "workflowArgument",
      "originalValue": "",
      "resolvedValue": "[InGmailMessageId]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 5,
      "provenance": {
        "sourceKind": "workflowArgument",
        "sourceName": "InGmailMessageId",
        "sourceWorkflow": "BGYY_WriteDedupe",
        "precedenceTier": 1
      },
      "rejectedCandidates": [
        {
          "sourceKind": "variable",
          "sourceName": "str_LogMessage",
          "sourceWorkflow": "BGYY_WriteDedupe",
          "precedenceTier": 2,
          "rejectionReason": "lowerPrecedence"
        }
      ]
    },
    {
      "file": "BGYY_WriteDedupe.xaml",
      "workflow": "BGYY_WriteDedupe",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[BGYY_WriteDedupe][Branch] No existing record for PersonKey=&quot; &amp; str_PersonKeyNormalized &amp; &quot; SendYear=&quot; &amp; InSendYear.ToString() &amp; &quot; — executing CREATE with Status=&quot; &amp; InStatus",
      "resolvedValue": "[BGYY_WriteDedupe][Branch] No existing record for PersonKey=&quot; &amp; str_PersonKeyNormalized &amp; &quot; SendYear=&quot; &amp; InSendYear.ToString() &amp; &quot; — executing CREATE with Status=&quot; &amp; InStatus",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 6,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[BGYY_WriteDedupe][Branch] No existing record for PersonKey=&quot; &amp; str_Per",
        "precedenceTier": 4
      }
    },
    {
      "file": "BGYY_WriteDedupe.xaml",
      "workflow": "BGYY_WriteDedupe",
      "activityType": "Assign",
      "propertyName": "To",
      "sourceBinding": "variable",
      "originalValue": "[obj_EntityObject]",
      "resolvedValue": "[obj_EntityObject]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 3,
      "provenance": {
        "sourceKind": "variable",
        "sourceName": "obj_EntityObject",
        "sourceWorkflow": "BGYY_WriteDedupe",
        "precedenceTier": 2
      }
    },
    {
      "file": "BGYY_WriteDedupe.xaml",
      "workflow": "BGYY_WriteDedupe",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;New Dictionary(Of String, Object) From {{&quot;&quot;PersonName&quot;&quot;, InPersonName}, {&quot;&quot;PersonKey&quot;&quot;, str_PersonKeyNormalized}, {&quot;&quot;SelectedEmail&quot;&quot;, InSelectedEmail}, {&quot;&quot;SendYear&quot;&quot;, InSendYear}, {&quot;&quot;Status&quot;&quot;, InStatus}, {&quot;&quot;CalendarEventId&quot;&quot;, InCalendarEventId}, {&quot;&quot;GmailMessageId&quot;&quot;, InGmailMessageId}, {&quot;&quot;SentTimestamp&quot;&quot;, InSentTimestamp}, {&quot;&quot;FailureReason&quot;&quot;, InFailureReason}, {&quot;&quot;RunId&quot;&quot;, InRunId}}&quot;]",
      "resolvedValue": "[&quot;New Dictionary(Of String, Object) From {{&quot;&quot;PersonName&quot;&quot;, InPersonName}, {&quot;&quot;PersonKey&quot;&quot;, str_PersonKeyNormalized}, {&quot;&quot;SelectedEmail&quot;&quot;, InSelectedEmail}, {&quot;&quot;SendYear&quot;&quot;, InSendYear}, {&quot;&quot;Status&quot;&quot;, InStatus}, {&quot;&quot;CalendarEventId&quot;&quot;, InCalendarEventId}, {&quot;&quot;GmailMessageId&quot;&quot;, InGmailMessageId}, {&quot;&quot;SentTimestamp&quot;&quot;, InSentTimestamp}, {&quot;&quot;FailureReason&quot;&quot;, InFailureReason}, {&quot;&quot;RunId&quot;&quot;, InRunId}}&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 3,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;New Dictionary(Of String, Object) From {{&quot;&quot;PersonName&quot;&quo",
        "precedenceTier": 4
      }
    },
    {
      "file": "BGYY_WriteDedupe.xaml",
      "workflow": "BGYY_WriteDedupe",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[HANDOFF] Activity &apos;Create New BGYY_BirthdaySendLog Record with All Audit Fields&apos; (UiPath.DataService.Activities.CreateEntity) requires developer implementation — missing: EntityObject",
      "resolvedValue": "[HANDOFF] Activity &apos;Create New BGYY_BirthdaySendLog Record with All Audit Fields&apos; (UiPath.DataService.Activities.CreateEntity) requires developer implementation — missing: EntityObject",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 7,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[HANDOFF] Activity &apos;Create New BGYY_BirthdaySendLog Record with All Audit F",
        "precedenceTier": 4
      }
    },
    {
      "file": "BGYY_WriteDedupe.xaml",
      "workflow": "BGYY_WriteDedupe",
      "activityType": "Assign",
      "propertyName": "To",
      "sourceBinding": "variable",
      "originalValue": "[obj_DataServiceException]",
      "resolvedValue": "[obj_DataServiceException]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 4,
      "provenance": {
        "sourceKind": "variable",
        "sourceName": "obj_DataServiceException",
        "sourceWorkflow": "BGYY_WriteDedupe",
        "precedenceTier": 2
      }
    },
    {
      "file": "BGYY_WriteDedupe.xaml",
      "workflow": "BGYY_WriteDedupe",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;ex_CreateException&quot;]",
      "resolvedValue": "[&quot;ex_CreateException&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 4,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;ex_CreateException&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "BGYY_WriteDedupe.xaml",
      "workflow": "BGYY_WriteDedupe",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "workflowArgument",
      "originalValue": "",
      "resolvedValue": "[InGmailMessageId]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 8,
      "provenance": {
        "sourceKind": "workflowArgument",
        "sourceName": "InGmailMessageId",
        "sourceWorkflow": "BGYY_WriteDedupe",
        "precedenceTier": 1
      },
      "rejectedCandidates": [
        {
          "sourceKind": "variable",
          "sourceName": "str_LogMessage",
          "sourceWorkflow": "BGYY_WriteDedupe",
          "precedenceTier": 2,
          "rejectionReason": "lowerPrecedence"
        }
      ]
    },
    {
      "file": "BGYY_WriteDedupe.xaml",
      "workflow": "BGYY_WriteDedupe",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "workflowArgument",
      "originalValue": "",
      "resolvedValue": "[InGmailMessageId]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 9,
      "provenance": {
        "sourceKind": "workflowArgument",
        "sourceName": "InGmailMessageId",
        "sourceWorkflow": "BGYY_WriteDedupe",
        "precedenceTier": 1
      },
      "rejectedCandidates": [
        {
          "sourceKind": "variable",
          "sourceName": "str_LogMessage",
          "sourceWorkflow": "BGYY_WriteDedupe",
          "precedenceTier": 2,
          "rejectionReason": "lowerPrecedence"
        }
      ]
    },
    {
      "file": "BGYY_WriteDedupe.xaml",
      "workflow": "BGYY_WriteDedupe",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "workflowArgument",
      "originalValue": "",
      "resolvedValue": "[InGmailMessageId]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 10,
      "provenance": {
        "sourceKind": "workflowArgument",
        "sourceName": "InGmailMessageId",
        "sourceWorkflow": "BGYY_WriteDedupe",
        "precedenceTier": 1
      },
      "rejectedCandidates": [
        {
          "sourceKind": "variable",
          "sourceName": "str_LogMessage",
          "sourceWorkflow": "BGYY_WriteDedupe",
          "precedenceTier": 2,
          "rejectionReason": "lowerPrecedence"
        }
      ]
    },
    {
      "file": "BGYY_CreateReviewTask.xaml",
      "workflow": "BGYY_CreateReviewTask",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "&quot;[BGYY_CreateReviewTask] START — RunId=&quot; &amp; InRunId &amp; &quot; | FullName=&quot; &amp; InFullName &amp; &quot; | EventId=&quot; &amp; InEventId &amp; &quot; | PersonKey=&quot; &amp; InPersonKey &amp; &quot; | SendYear=&quot; &amp; InSendYear.ToString()",
      "resolvedValue": "&quot;[BGYY_CreateReviewTask] START — RunId=&quot; &amp; InRunId &amp; &quot; | FullName=&quot; &amp; InFullName &amp; &quot; | EventId=&quot; &amp; InEventId &amp; &quot; | PersonKey=&quot; &amp; InPersonKey &amp; &quot; | SendYear=&quot; &amp; InSendYear.ToString()",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "&quot;[BGYY_CreateReviewTask] START — RunId=&quot; &amp; InRunId &amp; &quot; | ",
        "precedenceTier": 4
      }
    },
    {
      "file": "BGYY_CreateReviewTask.xaml",
      "workflow": "BGYY_CreateReviewTask",
      "activityType": "Assign",
      "propertyName": "To",
      "sourceBinding": "variable",
      "originalValue": "[dt_DueByTimestamp]",
      "resolvedValue": "[dt_DueByTimestamp]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "variable",
        "sourceName": "dt_DueByTimestamp",
        "sourceWorkflow": "BGYY_CreateReviewTask",
        "precedenceTier": 2
      }
    },
    {
      "file": "BGYY_CreateReviewTask.xaml",
      "workflow": "BGYY_CreateReviewTask",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "[DateTime.UtcNow.AddHours(2)]",
      "resolvedValue": "[DateTime.UtcNow.AddHours(2)]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[DateTime.UtcNow.AddHours(2)]",
        "precedenceTier": 4
      }
    },
    {
      "file": "BGYY_CreateReviewTask.xaml",
      "workflow": "BGYY_CreateReviewTask",
      "activityType": "Assign",
      "propertyName": "To",
      "sourceBinding": "variable",
      "originalValue": "[str_TaskTitle]",
      "resolvedValue": "[str_TaskTitle]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 1,
      "provenance": {
        "sourceKind": "variable",
        "sourceName": "str_TaskTitle",
        "sourceWorkflow": "BGYY_CreateReviewTask",
        "precedenceTier": 2
      }
    },
    {
      "file": "BGYY_CreateReviewTask.xaml",
      "workflow": "BGYY_CreateReviewTask",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "[\"BGYY Draft Review — \" &amp; InFullName &amp; \" (\" &amp; InRunId &amp; \")\"]",
      "resolvedValue": "[\"BGYY Draft Review — \" &amp; InFullName &amp; \" (\" &amp; InRunId &amp; \")\"]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 1,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[\"BGYY Draft Review — \" &amp; InFullName &amp; \" (\" &amp; InRunId &amp; \")\"]",
        "precedenceTier": 4
      }
    },
    {
      "file": "BGYY_CreateReviewTask.xaml",
      "workflow": "BGYY_CreateReviewTask",
      "activityType": "Assign",
      "propertyName": "To",
      "sourceBinding": "variable",
      "originalValue": "[str_WriteDedupeFailureReason]",
      "resolvedValue": "[str_WriteDedupeFailureReason]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 2,
      "provenance": {
        "sourceKind": "variable",
        "sourceName": "str_WriteDedupeFailureReason",
        "sourceWorkflow": "BGYY_CreateReviewTask",
        "precedenceTier": 2
      }
    },
    {
      "file": "BGYY_CreateReviewTask.xaml",
      "workflow": "BGYY_CreateReviewTask",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "[\"Action Center review task created at \" &amp; DateTime.UtcNow.ToString(\"yyyy-MM-ddTHH:mm:ssZ\") &amp; \" | DueBy=\" &amp; dt_DueByTimestamp.ToString(&quot;yyyy-MM-ddTHH:mm:ssZ\")]",
      "resolvedValue": "[\"Action Center review task created at \" &amp; DateTime.UtcNow.ToString(\"yyyy-MM-ddTHH:mm:ssZ\") &amp; \" | DueBy=\" &amp; dt_DueByTimestamp.ToString(&quot;yyyy-MM-ddTHH:mm:ssZ\")]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 2,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[\"Action Center review task created at \" &amp; DateTime.UtcNow.ToString(\"yyyy-MM",
        "precedenceTier": 4
      }
    },
    {
      "file": "BGYY_CreateReviewTask.xaml",
      "workflow": "BGYY_CreateReviewTask",
      "activityType": "InvokeWorkflowFile",
      "propertyName": "WorkflowFileName",
      "sourceBinding": "attribute-value",
      "originalValue": "BGYY_WriteDedupe.xaml",
      "resolvedValue": "BGYY_WriteDedupe.xaml",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "BGYY_WriteDedupe.xaml",
        "precedenceTier": 4
      }
    },
    {
      "file": "BGYY_CreateReviewTask.xaml",
      "workflow": "BGYY_CreateReviewTask",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Error in Write PendingReview status to Data Service via BGYY_WriteDedupe before task creation (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "resolvedValue": "[&quot;Error in Write PendingReview status to Data Service via BGYY_WriteDedupe before task creation (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 1,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Error in Write PendingReview status to Data Service via BGYY_WriteDedupe ",
        "precedenceTier": 4
      }
    },
    {
      "file": "BGYY_CreateReviewTask.xaml",
      "workflow": "BGYY_CreateReviewTask",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "&quot;Error in Write PendingReview status to Data Service via BGYY_WriteDedupe before task creation: &quot; &amp; exception.Message",
      "resolvedValue": "&quot;Error in Write PendingReview status to Data Service via BGYY_WriteDedupe before task creation: &quot; &amp; exception.Message",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 2,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "&quot;Error in Write PendingReview status to Data Service via BGYY_WriteDedupe b",
        "precedenceTier": 4
      }
    },
    {
      "file": "BGYY_CreateReviewTask.xaml",
      "workflow": "BGYY_CreateReviewTask",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "&quot;[BGYY_CreateReviewTask] PendingReview dedupe record written — PersonKey=&quot; &amp; InPersonKey &amp; &quot; | Year=&quot; &amp; InSendYear.ToString()",
      "resolvedValue": "&quot;[BGYY_CreateReviewTask] PendingReview dedupe record written — PersonKey=&quot; &amp; InPersonKey &amp; &quot; | Year=&quot; &amp; InSendYear.ToString()",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 3,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "&quot;[BGYY_CreateReviewTask] PendingReview dedupe record written — PersonKey=&q",
        "precedenceTier": 4
      }
    },
    {
      "file": "BGYY_CreateReviewTask.xaml",
      "workflow": "BGYY_CreateReviewTask",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "variable",
      "originalValue": "",
      "resolvedValue": "[str_LogMessage]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 4,
      "provenance": {
        "sourceKind": "variable",
        "sourceName": "str_LogMessage",
        "sourceWorkflow": "BGYY_CreateReviewTask",
        "precedenceTier": 2
      }
    },
    {
      "file": "BGYY_CreateReviewTask.xaml",
      "workflow": "BGYY_CreateReviewTask",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[HANDOFF] Activity &apos;Create BGYY_DraftReview Action Center form task with all required fields&apos; (UiPath.Persistence.Activities.CreateFormTask) requires developer implementation — missing: TaskTitle",
      "resolvedValue": "[HANDOFF] Activity &apos;Create BGYY_DraftReview Action Center form task with all required fields&apos; (UiPath.Persistence.Activities.CreateFormTask) requires developer implementation — missing: TaskTitle",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 5,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[HANDOFF] Activity &apos;Create BGYY_DraftReview Action Center form task with al",
        "precedenceTier": 4
      }
    },
    {
      "file": "BGYY_CreateReviewTask.xaml",
      "workflow": "BGYY_CreateReviewTask",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "&quot;Error in Create BGYY_DraftReview Action Center form task with all required fields: &quot; &amp; exception.Message",
      "resolvedValue": "&quot;Error in Create BGYY_DraftReview Action Center form task with all required fields: &quot; &amp; exception.Message",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 6,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "&quot;Error in Create BGYY_DraftReview Action Center form task with all required",
        "precedenceTier": 4
      }
    },
    {
      "file": "BGYY_CreateReviewTask.xaml",
      "workflow": "BGYY_CreateReviewTask",
      "activityType": "Assign",
      "propertyName": "To",
      "sourceBinding": "variable",
      "originalValue": "[bool_TaskCreationSucceeded]",
      "resolvedValue": "[bool_TaskCreationSucceeded]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 3,
      "provenance": {
        "sourceKind": "variable",
        "sourceName": "bool_TaskCreationSucceeded",
        "sourceWorkflow": "BGYY_CreateReviewTask",
        "precedenceTier": 2
      }
    },
    {
      "file": "BGYY_CreateReviewTask.xaml",
      "workflow": "BGYY_CreateReviewTask",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "True",
      "resolvedValue": "True",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 3,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "True",
        "precedenceTier": 4
      }
    },
    {
      "file": "BGYY_CreateReviewTask.xaml",
      "workflow": "BGYY_CreateReviewTask",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "variable",
      "originalValue": "",
      "resolvedValue": "[str_LogMessage]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 7,
      "provenance": {
        "sourceKind": "variable",
        "sourceName": "str_LogMessage",
        "sourceWorkflow": "BGYY_CreateReviewTask",
        "precedenceTier": 2
      }
    },
    {
      "file": "BGYY_CreateReviewTask.xaml",
      "workflow": "BGYY_CreateReviewTask",
      "activityType": "If",
      "propertyName": "Condition",
      "sourceBinding": "attribute-value",
      "originalValue": "[bool_TaskCreationSucceeded = False]",
      "resolvedValue": "[bool_TaskCreationSucceeded = False]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[bool_TaskCreationSucceeded = False]",
        "precedenceTier": 4
      }
    },
    {
      "file": "BGYY_CreateReviewTask.xaml",
      "workflow": "BGYY_CreateReviewTask",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Placeholder — Then branch has no activities yet&quot;]",
      "resolvedValue": "[&quot;Placeholder — Then branch has no activities yet&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 8,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Placeholder — Then branch has no activities yet&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "BGYY_CreateReviewTask.xaml",
      "workflow": "BGYY_CreateReviewTask",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "&quot;[BGYY_CreateReviewTask] ESCALATION — Action Center task creation FAILED for PersonKey=&quot; &amp; InPersonKey &amp; &quot; | RunId=&quot; &amp; InRunId &amp; &quot; | FullName=&quot; &amp; InFullName &amp; &quot; | EventId=&quot; &amp; InEventId &amp; &quot;. Item remains in PendingReview status in Data Service. Manual intervention required. DraftBody preserved in InDraftBody argument. Error=&quot; &amp; actionCenterException",
      "resolvedValue": "&quot;[BGYY_CreateReviewTask] ESCALATION — Action Center task creation FAILED for PersonKey=&quot; &amp; InPersonKey &amp; &quot; | RunId=&quot; &amp; InRunId &amp; &quot; | FullName=&quot; &amp; InFullName &amp; &quot; | EventId=&quot; &amp; InEventId &amp; &quot;. Item remains in PendingReview status in Data Service. Manual intervention required. DraftBody preserved in InDraftBody argument. Error=&quot; &amp; actionCenterException",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 9,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "&quot;[BGYY_CreateReviewTask] ESCALATION — Action Center task creation FAILED fo",
        "precedenceTier": 4
      }
    },
    {
      "file": "BGYY_CreateReviewTask.xaml",
      "workflow": "BGYY_CreateReviewTask",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "&quot;[BGYY_CreateReviewTask] END — RunId=&quot; &amp; InRunId &amp; &quot; | PersonKey=&quot; &amp; InPersonKey &amp; &quot; | TaskCreated=&quot; &amp; bool_TaskCreationSucceeded.ToString()",
      "resolvedValue": "&quot;[BGYY_CreateReviewTask] END — RunId=&quot; &amp; InRunId &amp; &quot; | PersonKey=&quot; &amp; InPersonKey &amp; &quot; | TaskCreated=&quot; &amp; bool_TaskCreationSucceeded.ToString()",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 10,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "&quot;[BGYY_CreateReviewTask] END — RunId=&quot; &amp; InRunId &amp; &quot; | Pe",
        "precedenceTier": 4
      }
    },
    {
      "file": "BGYY_Main.xaml",
      "workflow": "BGYY_Main",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;STUB: BGYY_Main — Final validation remediation — original XAML had well-formedness violations. Implement the actual logic here.&quot;]",
      "resolvedValue": "[&quot;STUB: BGYY_Main — Final validation remediation — original XAML had well-formedness violations. Implement the actual logic here.&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;STUB: BGYY_Main — Final validation remediation — original XAML had well-f",
        "precedenceTier": 4
      }
    },
    {
      "file": "BGYY_Main.xaml",
      "workflow": "BGYY_Main",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;=== Completed: BGYY_Main ===&quot;]",
      "resolvedValue": "[&quot;=== Completed: BGYY_Main ===&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 1,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;=== Completed: BGYY_Main ===&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "BGYY_Main.xaml",
      "workflow": "BGYY_Main",
      "activityType": "InvokeWorkflowFile",
      "propertyName": "WorkflowFileName",
      "sourceBinding": "attribute-value",
      "originalValue": "BGYY_GetTodaysBirthdays.xaml",
      "resolvedValue": "BGYY_GetTodaysBirthdays.xaml",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "BGYY_GetTodaysBirthdays.xaml",
        "precedenceTier": 4
      }
    },
    {
      "file": "BGYY_Main.xaml",
      "workflow": "BGYY_Main",
      "activityType": "InvokeWorkflowFile",
      "propertyName": "WorkflowFileName",
      "sourceBinding": "attribute-value",
      "originalValue": "BGYY_ResolveRecipient.xaml",
      "resolvedValue": "BGYY_ResolveRecipient.xaml",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 1,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "BGYY_ResolveRecipient.xaml",
        "precedenceTier": 4
      }
    },
    {
      "file": "BGYY_Main.xaml",
      "workflow": "BGYY_Main",
      "activityType": "InvokeWorkflowFile",
      "propertyName": "WorkflowFileName",
      "sourceBinding": "attribute-value",
      "originalValue": "BGYY_CheckDedupe.xaml",
      "resolvedValue": "BGYY_CheckDedupe.xaml",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 2,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "BGYY_CheckDedupe.xaml",
        "precedenceTier": 4
      }
    },
    {
      "file": "BGYY_Main.xaml",
      "workflow": "BGYY_Main",
      "activityType": "InvokeWorkflowFile",
      "propertyName": "WorkflowFileName",
      "sourceBinding": "attribute-value",
      "originalValue": "BGYY_GenerateAndValidateDraft.xaml",
      "resolvedValue": "BGYY_GenerateAndValidateDraft.xaml",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 3,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "BGYY_GenerateAndValidateDraft.xaml",
        "precedenceTier": 4
      }
    },
    {
      "file": "BGYY_Main.xaml",
      "workflow": "BGYY_Main",
      "activityType": "InvokeWorkflowFile",
      "propertyName": "WorkflowFileName",
      "sourceBinding": "attribute-value",
      "originalValue": "BGYY_SendGmail.xaml",
      "resolvedValue": "BGYY_SendGmail.xaml",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 4,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "BGYY_SendGmail.xaml",
        "precedenceTier": 4
      }
    },
    {
      "file": "BGYY_Main.xaml",
      "workflow": "BGYY_Main",
      "activityType": "InvokeWorkflowFile",
      "propertyName": "WorkflowFileName",
      "sourceBinding": "attribute-value",
      "originalValue": "BGYY_WriteDedupe.xaml",
      "resolvedValue": "BGYY_WriteDedupe.xaml",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 5,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "BGYY_WriteDedupe.xaml",
        "precedenceTier": 4
      }
    },
    {
      "file": "BGYY_Main.xaml",
      "workflow": "BGYY_Main",
      "activityType": "InvokeWorkflowFile",
      "propertyName": "WorkflowFileName",
      "sourceBinding": "attribute-value",
      "originalValue": "BGYY_CreateReviewTask.xaml",
      "resolvedValue": "BGYY_CreateReviewTask.xaml",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 6,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "BGYY_CreateReviewTask.xaml",
        "precedenceTier": 4
      }
    },
    {
      "file": "InitAllSettings.xaml",
      "workflow": "InitAllSettings",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Reading configuration from Config.xlsx...&quot;]",
      "resolvedValue": "[&quot;Reading configuration from Config.xlsx...&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Reading configuration from Config.xlsx...&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "InitAllSettings.xaml",
      "workflow": "InitAllSettings",
      "activityType": "ForEach",
      "propertyName": "Values",
      "sourceBinding": "attribute-value",
      "originalValue": "[dt_Settings.Rows]",
      "resolvedValue": "[dt_Settings.Rows]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[dt_Settings.Rows]",
        "precedenceTier": 4
      }
    },
    {
      "file": "InitAllSettings.xaml",
      "workflow": "InitAllSettings",
      "activityType": "Assign",
      "propertyName": "To",
      "sourceBinding": "attribute-value",
      "originalValue": "[dict_Config(row(&quot;Name&quot;).ToString)]",
      "resolvedValue": "[dict_Config(row(&quot;Name&quot;).ToString)]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[dict_Config(row(&quot;Name&quot;).ToString)]",
        "precedenceTier": 4
      }
    },
    {
      "file": "InitAllSettings.xaml",
      "workflow": "InitAllSettings",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "[row(&quot;Value&quot;)]",
      "resolvedValue": "[row(&quot;Value&quot;)]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[row(&quot;Value&quot;)]",
        "precedenceTier": 4
      }
    },
    {
      "file": "InitAllSettings.xaml",
      "workflow": "InitAllSettings",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Processing setting: &quot; &amp; row(&quot;Name&quot;).ToString]",
      "resolvedValue": "[&quot;Processing setting: &quot; &amp; row(&quot;Name&quot;).ToString]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 1,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Processing setting: &quot; &amp; row(&quot;Name&quot;).ToString]",
        "precedenceTier": 4
      }
    },
    {
      "file": "InitAllSettings.xaml",
      "workflow": "InitAllSettings",
      "activityType": "Assign",
      "propertyName": "To",
      "sourceBinding": "attribute-value",
      "originalValue": "[dict_Config(&quot;BGYY_DryRun&quot;)]",
      "resolvedValue": "[dict_Config(&quot;BGYY_DryRun&quot;)]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 1,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[dict_Config(&quot;BGYY_DryRun&quot;)]",
        "precedenceTier": 4
      }
    },
    {
      "file": "InitAllSettings.xaml",
      "workflow": "InitAllSettings",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "variable",
      "originalValue": "[str_AssetValue]",
      "resolvedValue": "[str_AssetValue]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 1,
      "provenance": {
        "sourceKind": "variable",
        "sourceName": "str_AssetValue",
        "sourceWorkflow": "InitAllSettings",
        "precedenceTier": 2
      }
    },
    {
      "file": "InitAllSettings.xaml",
      "workflow": "InitAllSettings",
      "activityType": "ForEach",
      "propertyName": "Values",
      "sourceBinding": "attribute-value",
      "originalValue": "[dt_Constants.Rows]",
      "resolvedValue": "[dt_Constants.Rows]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 1,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[dt_Constants.Rows]",
        "precedenceTier": 4
      }
    },
    {
      "file": "InitAllSettings.xaml",
      "workflow": "InitAllSettings",
      "activityType": "Assign",
      "propertyName": "To",
      "sourceBinding": "attribute-value",
      "originalValue": "[dict_Config(constRow(&quot;Name&quot;).ToString)]",
      "resolvedValue": "[dict_Config(constRow(&quot;Name&quot;).ToString)]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 2,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[dict_Config(constRow(&quot;Name&quot;).ToString)]",
        "precedenceTier": 4
      }
    },
    {
      "file": "InitAllSettings.xaml",
      "workflow": "InitAllSettings",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "[constRow(&quot;Value&quot;)]",
      "resolvedValue": "[constRow(&quot;Value&quot;)]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 2,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[constRow(&quot;Value&quot;)]",
        "precedenceTier": 4
      }
    },
    {
      "file": "InitAllSettings.xaml",
      "workflow": "InitAllSettings",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Loaded constant: &quot; &amp; constRow(&quot;Name&quot;).ToString]",
      "resolvedValue": "[&quot;Loaded constant: &quot; &amp; constRow(&quot;Name&quot;).ToString]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 2,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Loaded constant: &quot; &amp; constRow(&quot;Name&quot;).ToString]",
        "precedenceTier": 4
      }
    },
    {
      "file": "InitAllSettings.xaml",
      "workflow": "InitAllSettings",
      "activityType": "Assign",
      "propertyName": "To",
      "sourceBinding": "workflowArgument",
      "originalValue": "[out_Config]",
      "resolvedValue": "[out_Config]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 3,
      "provenance": {
        "sourceKind": "workflowArgument",
        "sourceName": "out_Config",
        "sourceWorkflow": "InitAllSettings",
        "precedenceTier": 1
      }
    },
    {
      "file": "InitAllSettings.xaml",
      "workflow": "InitAllSettings",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "variable",
      "originalValue": "[dict_Config]",
      "resolvedValue": "[dict_Config]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 3,
      "provenance": {
        "sourceKind": "variable",
        "sourceName": "dict_Config",
        "sourceWorkflow": "InitAllSettings",
        "precedenceTier": 2
      }
    },
    {
      "file": "InitAllSettings.xaml",
      "workflow": "InitAllSettings",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Configuration loaded successfully&quot;]",
      "resolvedValue": "[&quot;Configuration loaded successfully&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 3,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Configuration loaded successfully&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "InitAllSettings.xaml",
      "workflow": "InitAllSettings",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;=== Completed: InitAllSettings ===&quot;]",
      "resolvedValue": "[&quot;=== Completed: InitAllSettings ===&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 4,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;=== Completed: InitAllSettings ===&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "Main.xaml",
      "workflow": "Main",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;=== Initializing BirthdayGreetingsYY ===&quot;]",
      "resolvedValue": "[&quot;=== Initializing BirthdayGreetingsYY ===&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;=== Initializing BirthdayGreetingsYY ===&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "Main.xaml",
      "workflow": "Main",
      "activityType": "InvokeWorkflowFile",
      "propertyName": "WorkflowFileName",
      "sourceBinding": "attribute-value",
      "originalValue": "Init.xaml",
      "resolvedValue": "Init.xaml",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "Init.xaml",
        "precedenceTier": 4
      }
    },
    {
      "file": "Main.xaml",
      "workflow": "Main",
      "activityType": "Assign",
      "propertyName": "To",
      "sourceBinding": "variable",
      "originalValue": "[bool_SystemReady]",
      "resolvedValue": "[bool_SystemReady]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "variable",
        "sourceName": "bool_SystemReady",
        "sourceWorkflow": "Main",
        "precedenceTier": 2
      }
    },
    {
      "file": "Main.xaml",
      "workflow": "Main",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "True",
      "resolvedValue": "True",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "True",
        "precedenceTier": 4
      }
    },
    {
      "file": "Main.xaml",
      "workflow": "Main",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Initialization complete&quot;]",
      "resolvedValue": "[&quot;Initialization complete&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 1,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Initialization complete&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "Main.xaml",
      "workflow": "Main",
      "activityType": "InvokeWorkflowFile",
      "propertyName": "WorkflowFileName",
      "sourceBinding": "attribute-value",
      "originalValue": "GetTransactionData.xaml",
      "resolvedValue": "GetTransactionData.xaml",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 1,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "GetTransactionData.xaml",
        "precedenceTier": 4
      }
    },
    {
      "file": "Main.xaml",
      "workflow": "Main",
      "activityType": "InvokeWorkflowFile",
      "propertyName": "WorkflowFileName",
      "sourceBinding": "attribute-value",
      "originalValue": "Process.xaml",
      "resolvedValue": "Process.xaml",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 2,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "Process.xaml",
        "precedenceTier": 4
      }
    },
    {
      "file": "Main.xaml",
      "workflow": "Main",
      "activityType": "InvokeWorkflowFile",
      "propertyName": "WorkflowFileName",
      "sourceBinding": "attribute-value",
      "originalValue": "SetTransactionStatus.xaml",
      "resolvedValue": "SetTransactionStatus.xaml",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 3,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "SetTransactionStatus.xaml",
        "precedenceTier": 4
      }
    },
    {
      "file": "Main.xaml",
      "workflow": "Main",
      "activityType": "Assign",
      "propertyName": "To",
      "sourceBinding": "variable",
      "originalValue": "[int_RetryNumber]",
      "resolvedValue": "[int_RetryNumber]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 1,
      "provenance": {
        "sourceKind": "variable",
        "sourceName": "int_RetryNumber",
        "sourceWorkflow": "Main",
        "precedenceTier": 2
      }
    },
    {
      "file": "Main.xaml",
      "workflow": "Main",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "0",
      "resolvedValue": "0",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 1,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "0",
        "precedenceTier": 4
      }
    },
    {
      "file": "Main.xaml",
      "workflow": "Main",
      "activityType": "Assign",
      "propertyName": "To",
      "sourceBinding": "variable",
      "originalValue": "[str_ErrorScreenshotPath]",
      "resolvedValue": "[str_ErrorScreenshotPath]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 2,
      "provenance": {
        "sourceKind": "variable",
        "sourceName": "str_ErrorScreenshotPath",
        "sourceWorkflow": "Main",
        "precedenceTier": 2
      }
    },
    {
      "file": "Main.xaml",
      "workflow": "Main",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "[\"screenshots/error_tx_\" &amp; int_TransactionNumber.ToString &amp; \"_\" &amp; DateTime.Now.ToString(\"yyyyMMdd_HHmmss\") &amp; \".png\"]",
      "resolvedValue": "[\"screenshots/error_tx_\" &amp; int_TransactionNumber.ToString &amp; \"_\" &amp; DateTime.Now.ToString(\"yyyyMMdd_HHmmss\") &amp; \".png\"]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 2,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[\"screenshots/error_tx_\" &amp; int_TransactionNumber.ToString &amp; \"_\" &amp; Da",
        "precedenceTier": 4
      }
    },
    {
      "file": "Main.xaml",
      "workflow": "Main",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot capture failed: &quot; &amp; ssEx.Message]",
      "resolvedValue": "[&quot;Screenshot capture failed: &quot; &amp; ssEx.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 2,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot capture failed: &quot; &amp; ssEx.Message]",
        "precedenceTier": 4
      }
    },
    {
      "file": "Main.xaml",
      "workflow": "Main",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Transaction #&quot; &amp; int_TransactionNumber.ToString &amp; &quot; failed: &quot; &amp; exception.Message &amp; &quot; | Screenshot: &quot; &amp; str_ErrorScreenshotPath]",
      "resolvedValue": "[&quot;Transaction #&quot; &amp; int_TransactionNumber.ToString &amp; &quot; failed: &quot; &amp; exception.Message &amp; &quot; | Screenshot: &quot; &amp; str_ErrorScreenshotPath]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 3,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Transaction #&quot; &amp; int_TransactionNumber.ToString &amp; &quot; fai",
        "precedenceTier": 4
      }
    },
    {
      "file": "Main.xaml",
      "workflow": "Main",
      "activityType": "InvokeWorkflowFile",
      "propertyName": "WorkflowFileName",
      "sourceBinding": "attribute-value",
      "originalValue": "SetTransactionStatus.xaml",
      "resolvedValue": "SetTransactionStatus.xaml",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 4,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "SetTransactionStatus.xaml",
        "precedenceTier": 4
      }
    },
    {
      "file": "Main.xaml",
      "workflow": "Main",
      "activityType": "InvokeWorkflowFile",
      "propertyName": "WorkflowFileName",
      "sourceBinding": "attribute-value",
      "originalValue": "CloseAllApplications.xaml",
      "resolvedValue": "CloseAllApplications.xaml",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 5,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "CloseAllApplications.xaml",
        "precedenceTier": 4
      }
    },
    {
      "file": "Main.xaml",
      "workflow": "Main",
      "activityType": "InvokeWorkflowFile",
      "propertyName": "WorkflowFileName",
      "sourceBinding": "attribute-value",
      "originalValue": "CloseAllApplications.xaml",
      "resolvedValue": "CloseAllApplications.xaml",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 6,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "CloseAllApplications.xaml",
        "precedenceTier": 4
      }
    },
    {
      "file": "Main.xaml",
      "workflow": "Main",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;=== BirthdayGreetingsYY Complete. Transactions processed: &quot; &amp; int_TransactionNumber.ToString]",
      "resolvedValue": "[&quot;=== BirthdayGreetingsYY Complete. Transactions processed: &quot; &amp; int_TransactionNumber.ToString]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 4,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;=== BirthdayGreetingsYY Complete. Transactions processed: &quot; &amp; in",
        "precedenceTier": 4
      }
    },
    {
      "file": "GetTransactionData.xaml",
      "workflow": "GetTransactionData",
      "activityType": "If",
      "propertyName": "Condition",
      "sourceBinding": "attribute-value",
      "originalValue": "[out_TransactionItem IsNot Nothing]",
      "resolvedValue": "[out_TransactionItem IsNot Nothing]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[out_TransactionItem IsNot Nothing]",
        "precedenceTier": 4
      }
    },
    {
      "file": "GetTransactionData.xaml",
      "workflow": "GetTransactionData",
      "activityType": "Assign",
      "propertyName": "To",
      "sourceBinding": "workflowArgument",
      "originalValue": "[io_TransactionNumber]",
      "resolvedValue": "[io_TransactionNumber]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "workflowArgument",
        "sourceName": "io_TransactionNumber",
        "sourceWorkflow": "GetTransactionData",
        "precedenceTier": 1
      }
    },
    {
      "file": "GetTransactionData.xaml",
      "workflow": "GetTransactionData",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "[io_TransactionNumber + 1]",
      "resolvedValue": "[io_TransactionNumber + 1]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[io_TransactionNumber + 1]",
        "precedenceTier": 4
      }
    },
    {
      "file": "GetTransactionData.xaml",
      "workflow": "GetTransactionData",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Processing transaction #&quot; &amp; io_TransactionNumber.ToString &amp; &quot; - Ref: &quot; &amp; out_TransactionItem.Reference]",
      "resolvedValue": "[&quot;Processing transaction #&quot; &amp; io_TransactionNumber.ToString &amp; &quot; - Ref: &quot; &amp; out_TransactionItem.Reference]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Processing transaction #&quot; &amp; io_TransactionNumber.ToString &amp; ",
        "precedenceTier": 4
      }
    },
    {
      "file": "GetTransactionData.xaml",
      "workflow": "GetTransactionData",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;No more transactions in queue&quot;]",
      "resolvedValue": "[&quot;No more transactions in queue&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 1,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;No more transactions in queue&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "GetTransactionData.xaml",
      "workflow": "GetTransactionData",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;=== Completed: GetTransactionData ===&quot;]",
      "resolvedValue": "[&quot;=== Completed: GetTransactionData ===&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 2,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;=== Completed: GetTransactionData ===&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "SetTransactionStatus.xaml",
      "workflow": "SetTransactionStatus",
      "activityType": "If",
      "propertyName": "Condition",
      "sourceBinding": "attribute-value",
      "originalValue": "[in_Status = &quot;Successful&quot;]",
      "resolvedValue": "[in_Status = &quot;Successful&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[in_Status = &quot;Successful&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "SetTransactionStatus.xaml",
      "workflow": "SetTransactionStatus",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Transaction failure screenshot: &quot; &amp; str_ScreenshotPath]",
      "resolvedValue": "[&quot;Transaction failure screenshot: &quot; &amp; str_ScreenshotPath]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Transaction failure screenshot: &quot; &amp; str_ScreenshotPath]",
        "precedenceTier": 4
      }
    },
    {
      "file": "SetTransactionStatus.xaml",
      "workflow": "SetTransactionStatus",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot capture failed: &quot; &amp; ssEx.Message]",
      "resolvedValue": "[&quot;Screenshot capture failed: &quot; &amp; ssEx.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 1,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot capture failed: &quot; &amp; ssEx.Message]",
        "precedenceTier": 4
      }
    },
    {
      "file": "SetTransactionStatus.xaml",
      "workflow": "SetTransactionStatus",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Transaction failed: &quot; &amp; in_ErrorMessage]",
      "resolvedValue": "[&quot;Transaction failed: &quot; &amp; in_ErrorMessage]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 2,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Transaction failed: &quot; &amp; in_ErrorMessage]",
        "precedenceTier": 4
      }
    },
    {
      "file": "SetTransactionStatus.xaml",
      "workflow": "SetTransactionStatus",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;=== Completed: SetTransactionStatus ===&quot;]",
      "resolvedValue": "[&quot;=== Completed: SetTransactionStatus ===&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 3,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;=== Completed: SetTransactionStatus ===&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "CloseAllApplications.xaml",
      "workflow": "CloseAllApplications",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Closing all applications...&quot;]",
      "resolvedValue": "[&quot;Closing all applications...&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Closing all applications...&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "CloseAllApplications.xaml",
      "workflow": "CloseAllApplications",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;All applications closed&quot;]",
      "resolvedValue": "[&quot;All applications closed&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 1,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;All applications closed&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "CloseAllApplications.xaml",
      "workflow": "CloseAllApplications",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Error during cleanup: &quot; &amp; closeEx.Message]",
      "resolvedValue": "[&quot;Error during cleanup: &quot; &amp; closeEx.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 2,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Error during cleanup: &quot; &amp; closeEx.Message]",
        "precedenceTier": 4
      }
    },
    {
      "file": "CloseAllApplications.xaml",
      "workflow": "CloseAllApplications",
      "activityType": "InvokeWorkflowFile",
      "propertyName": "WorkflowFileName",
      "sourceBinding": "attribute-value",
      "originalValue": "KillAllProcesses.xaml",
      "resolvedValue": "KillAllProcesses.xaml",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "KillAllProcesses.xaml",
        "precedenceTier": 4
      }
    },
    {
      "file": "CloseAllApplications.xaml",
      "workflow": "CloseAllApplications",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Kill processes failed: &quot; &amp; killEx.Message]",
      "resolvedValue": "[&quot;Kill processes failed: &quot; &amp; killEx.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 3,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Kill processes failed: &quot; &amp; killEx.Message]",
        "precedenceTier": 4
      }
    },
    {
      "file": "CloseAllApplications.xaml",
      "workflow": "CloseAllApplications",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;=== Completed: CloseAllApplications ===&quot;]",
      "resolvedValue": "[&quot;=== Completed: CloseAllApplications ===&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 4,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;=== Completed: CloseAllApplications ===&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "KillAllProcesses.xaml",
      "workflow": "KillAllProcesses",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Force killing all application processes...&quot;]",
      "resolvedValue": "[&quot;Force killing all application processes...&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Force killing all application processes...&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "KillAllProcesses.xaml",
      "workflow": "KillAllProcesses",
      "activityType": "KillProcess",
      "propertyName": "ProcessName",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;chrome&quot;]",
      "resolvedValue": "[&quot;chrome&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;chrome&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "KillAllProcesses.xaml",
      "workflow": "KillAllProcesses",
      "activityType": "KillProcess",
      "propertyName": "ProcessName",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;iexplore&quot;]",
      "resolvedValue": "[&quot;iexplore&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 1,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;iexplore&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "KillAllProcesses.xaml",
      "workflow": "KillAllProcesses",
      "activityType": "KillProcess",
      "propertyName": "ProcessName",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;EXCEL&quot;]",
      "resolvedValue": "[&quot;EXCEL&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 2,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;EXCEL&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "KillAllProcesses.xaml",
      "workflow": "KillAllProcesses",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;All processes terminated&quot;]",
      "resolvedValue": "[&quot;All processes terminated&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 1,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;All processes terminated&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "KillAllProcesses.xaml",
      "workflow": "KillAllProcesses",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;=== Completed: KillAllProcesses ===&quot;]",
      "resolvedValue": "[&quot;=== Completed: KillAllProcesses ===&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 2,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;=== Completed: KillAllProcesses ===&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "Init.xaml",
      "workflow": "Init",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;=== Initialization Started ===&quot;]",
      "resolvedValue": "[&quot;=== Initialization Started ===&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;=== Initialization Started ===&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "Init.xaml",
      "workflow": "Init",
      "activityType": "InvokeWorkflowFile",
      "propertyName": "WorkflowFileName",
      "sourceBinding": "attribute-value",
      "originalValue": "InitAllSettings.xaml",
      "resolvedValue": "InitAllSettings.xaml",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "InitAllSettings.xaml",
        "precedenceTier": 4
      }
    },
    {
      "file": "Init.xaml",
      "workflow": "Init",
      "activityType": "Assign",
      "propertyName": "To",
      "sourceBinding": "workflowArgument",
      "originalValue": "[io_Config]",
      "resolvedValue": "[io_Config]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "workflowArgument",
        "sourceName": "io_Config",
        "sourceWorkflow": "Init",
        "precedenceTier": 1
      }
    },
    {
      "file": "Init.xaml",
      "workflow": "Init",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "variable",
      "originalValue": "[dict_Config]",
      "resolvedValue": "[dict_Config]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "variable",
        "sourceName": "dict_Config",
        "sourceWorkflow": "Init",
        "precedenceTier": 2
      }
    },
    {
      "file": "Init.xaml",
      "workflow": "Init",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Configuration loaded successfully&quot;]",
      "resolvedValue": "[&quot;Configuration loaded successfully&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 1,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Configuration loaded successfully&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "Init.xaml",
      "workflow": "Init",
      "activityType": "Assign",
      "propertyName": "To",
      "sourceBinding": "variable",
      "originalValue": "[bool_InitSuccess]",
      "resolvedValue": "[bool_InitSuccess]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 1,
      "provenance": {
        "sourceKind": "variable",
        "sourceName": "bool_InitSuccess",
        "sourceWorkflow": "Init",
        "precedenceTier": 2
      }
    },
    {
      "file": "Init.xaml",
      "workflow": "Init",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "True",
      "resolvedValue": "True",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 1,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "True",
        "precedenceTier": 4
      }
    },
    {
      "file": "Init.xaml",
      "workflow": "Init",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Initialization failed: &quot; &amp; exception.Message]",
      "resolvedValue": "[&quot;Initialization failed: &quot; &amp; exception.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 2,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Initialization failed: &quot; &amp; exception.Message]",
        "precedenceTier": 4
      }
    },
    {
      "file": "Init.xaml",
      "workflow": "Init",
      "activityType": "Assign",
      "propertyName": "To",
      "sourceBinding": "variable",
      "originalValue": "[bool_InitSuccess]",
      "resolvedValue": "[bool_InitSuccess]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 2,
      "provenance": {
        "sourceKind": "variable",
        "sourceName": "bool_InitSuccess",
        "sourceWorkflow": "Init",
        "precedenceTier": 2
      }
    },
    {
      "file": "Init.xaml",
      "workflow": "Init",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "False",
      "resolvedValue": "False",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 2,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "False",
        "precedenceTier": 4
      }
    },
    {
      "file": "Init.xaml",
      "workflow": "Init",
      "activityType": "If",
      "propertyName": "Condition",
      "sourceBinding": "variable",
      "originalValue": "[bool_InitSuccess]",
      "resolvedValue": "[bool_InitSuccess]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "variable",
        "sourceName": "bool_InitSuccess",
        "sourceWorkflow": "Init",
        "precedenceTier": 2
      }
    },
    {
      "file": "Init.xaml",
      "workflow": "Init",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;=== Initialization Complete ===&quot;]",
      "resolvedValue": "[&quot;=== Initialization Complete ===&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 3,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;=== Initialization Complete ===&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "Init.xaml",
      "workflow": "Init",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;=== Initialization FAILED — process cannot continue ===&quot;]",
      "resolvedValue": "[&quot;=== Initialization FAILED — process cannot continue ===&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 4,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;=== Initialization FAILED — process cannot continue ===&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "InitAllApplications.xaml",
      "workflow": "InitAllApplications",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Initializing all applications...&quot;]",
      "resolvedValue": "[&quot;Initializing all applications...&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Initializing all applications...&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "InitAllApplications.xaml",
      "workflow": "InitAllApplications",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;TODO: Add application initialization steps (e.g., open browsers, launch desktop apps)&quot;]",
      "resolvedValue": "[&quot;TODO: Add application initialization steps (e.g., open browsers, launch desktop apps)&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 1,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;TODO: Add application initialization steps (e.g., open browsers, launch d",
        "precedenceTier": 4
      }
    },
    {
      "file": "InitAllApplications.xaml",
      "workflow": "InitAllApplications",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Application initialization failed: &quot; &amp; initEx.Message]",
      "resolvedValue": "[&quot;Application initialization failed: &quot; &amp; initEx.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 2,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Application initialization failed: &quot; &amp; initEx.Message]",
        "precedenceTier": 4
      }
    },
    {
      "file": "InitAllApplications.xaml",
      "workflow": "InitAllApplications",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;All applications initialized successfully&quot;]",
      "resolvedValue": "[&quot;All applications initialized successfully&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 3,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;All applications initialized successfully&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "InitAllApplications.xaml",
      "workflow": "InitAllApplications",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;=== Completed: Initialize_Applications ===&quot;]",
      "resolvedValue": "[&quot;=== Completed: Initialize_Applications ===&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 4,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;=== Completed: Initialize_Applications ===&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "RetryCurrentTransaction.xaml",
      "workflow": "RetryCurrentTransaction",
      "activityType": "If",
      "propertyName": "Condition",
      "sourceBinding": "attribute-value",
      "originalValue": "[in_QueueRetry]",
      "resolvedValue": "[in_QueueRetry]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[in_QueueRetry]",
        "precedenceTier": 4
      }
    },
    {
      "file": "RetryCurrentTransaction.xaml",
      "workflow": "RetryCurrentTransaction",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Retry managed by Orchestrator Queue — skipping local retry counter&quot;]",
      "resolvedValue": "[&quot;Retry managed by Orchestrator Queue — skipping local retry counter&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Retry managed by Orchestrator Queue — skipping local retry counter&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "RetryCurrentTransaction.xaml",
      "workflow": "RetryCurrentTransaction",
      "activityType": "Assign",
      "propertyName": "To",
      "sourceBinding": "workflowArgument",
      "originalValue": "[out_MaxRetryReached]",
      "resolvedValue": "[out_MaxRetryReached]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "workflowArgument",
        "sourceName": "out_MaxRetryReached",
        "sourceWorkflow": "RetryCurrentTransaction",
        "precedenceTier": 1
      }
    },
    {
      "file": "RetryCurrentTransaction.xaml",
      "workflow": "RetryCurrentTransaction",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "[False]",
      "resolvedValue": "[False]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[False]",
        "precedenceTier": 4
      }
    },
    {
      "file": "RetryCurrentTransaction.xaml",
      "workflow": "RetryCurrentTransaction",
      "activityType": "Assign",
      "propertyName": "To",
      "sourceBinding": "attribute-value",
      "originalValue": "[io_RetryNumber]",
      "resolvedValue": "[io_RetryNumber]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 1,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[io_RetryNumber]",
        "precedenceTier": 4
      }
    },
    {
      "file": "RetryCurrentTransaction.xaml",
      "workflow": "RetryCurrentTransaction",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "[io_RetryNumber + 1]",
      "resolvedValue": "[io_RetryNumber + 1]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 1,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[io_RetryNumber + 1]",
        "precedenceTier": 4
      }
    },
    {
      "file": "RetryCurrentTransaction.xaml",
      "workflow": "RetryCurrentTransaction",
      "activityType": "If",
      "propertyName": "Condition",
      "sourceBinding": "attribute-value",
      "originalValue": "[io_RetryNumber &gt;= int_MaxRetries]",
      "resolvedValue": "[io_RetryNumber &gt;= int_MaxRetries]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 1,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[io_RetryNumber &gt;= int_MaxRetries]",
        "precedenceTier": 4
      }
    },
    {
      "file": "RetryCurrentTransaction.xaml",
      "workflow": "RetryCurrentTransaction",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Maximum retry count reached (&quot; &amp; io_RetryNumber.ToString() &amp; &quot;/&quot; &amp; int_MaxRetries.ToString() &amp; &quot;)&quot;]",
      "resolvedValue": "[&quot;Maximum retry count reached (&quot; &amp; io_RetryNumber.ToString() &amp; &quot;/&quot; &amp; int_MaxRetries.ToString() &amp; &quot;)&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 1,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Maximum retry count reached (&quot; &amp; io_RetryNumber.ToString() &amp;",
        "precedenceTier": 4
      }
    },
    {
      "file": "RetryCurrentTransaction.xaml",
      "workflow": "RetryCurrentTransaction",
      "activityType": "Assign",
      "propertyName": "To",
      "sourceBinding": "workflowArgument",
      "originalValue": "[out_MaxRetryReached]",
      "resolvedValue": "[out_MaxRetryReached]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 2,
      "provenance": {
        "sourceKind": "workflowArgument",
        "sourceName": "out_MaxRetryReached",
        "sourceWorkflow": "RetryCurrentTransaction",
        "precedenceTier": 1
      }
    },
    {
      "file": "RetryCurrentTransaction.xaml",
      "workflow": "RetryCurrentTransaction",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "[True]",
      "resolvedValue": "[True]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 2,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[True]",
        "precedenceTier": 4
      }
    },
    {
      "file": "RetryCurrentTransaction.xaml",
      "workflow": "RetryCurrentTransaction",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Retrying transaction (&quot; &amp; io_RetryNumber.ToString() &amp; &quot;/&quot; &amp; int_MaxRetries.ToString() &amp; &quot;)&quot;]",
      "resolvedValue": "[&quot;Retrying transaction (&quot; &amp; io_RetryNumber.ToString() &amp; &quot;/&quot; &amp; int_MaxRetries.ToString() &amp; &quot;)&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 2,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Retrying transaction (&quot; &amp; io_RetryNumber.ToString() &amp; &quot;",
        "precedenceTier": 4
      }
    },
    {
      "file": "RetryCurrentTransaction.xaml",
      "workflow": "RetryCurrentTransaction",
      "activityType": "Assign",
      "propertyName": "To",
      "sourceBinding": "attribute-value",
      "originalValue": "[io_TransactionNumber]",
      "resolvedValue": "[io_TransactionNumber]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 3,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[io_TransactionNumber]",
        "precedenceTier": 4
      }
    },
    {
      "file": "RetryCurrentTransaction.xaml",
      "workflow": "RetryCurrentTransaction",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "[io_TransactionNumber - 1]",
      "resolvedValue": "[io_TransactionNumber - 1]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 3,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[io_TransactionNumber - 1]",
        "precedenceTier": 4
      }
    },
    {
      "file": "RetryCurrentTransaction.xaml",
      "workflow": "RetryCurrentTransaction",
      "activityType": "Assign",
      "propertyName": "To",
      "sourceBinding": "workflowArgument",
      "originalValue": "[out_MaxRetryReached]",
      "resolvedValue": "[out_MaxRetryReached]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 4,
      "provenance": {
        "sourceKind": "workflowArgument",
        "sourceName": "out_MaxRetryReached",
        "sourceWorkflow": "RetryCurrentTransaction",
        "precedenceTier": 1
      }
    },
    {
      "file": "RetryCurrentTransaction.xaml",
      "workflow": "RetryCurrentTransaction",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "[False]",
      "resolvedValue": "[False]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 4,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[False]",
        "precedenceTier": 4
      }
    },
    {
      "file": "RetryCurrentTransaction.xaml",
      "workflow": "RetryCurrentTransaction",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;=== Completed: RetryCurrentTransaction ===&quot;]",
      "resolvedValue": "[&quot;=== Completed: RetryCurrentTransaction ===&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 3,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;=== Completed: RetryCurrentTransaction ===&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "RetryInit.xaml",
      "workflow": "RetryInit",
      "activityType": "Assign",
      "propertyName": "To",
      "sourceBinding": "workflowArgument",
      "originalValue": "[io_InitRetryCounter]",
      "resolvedValue": "[io_InitRetryCounter]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "workflowArgument",
        "sourceName": "io_InitRetryCounter",
        "sourceWorkflow": "RetryInit",
        "precedenceTier": 1
      }
    },
    {
      "file": "RetryInit.xaml",
      "workflow": "RetryInit",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "[io_InitRetryCounter + 1]",
      "resolvedValue": "[io_InitRetryCounter + 1]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[io_InitRetryCounter + 1]",
        "precedenceTier": 4
      }
    },
    {
      "file": "RetryInit.xaml",
      "workflow": "RetryInit",
      "activityType": "If",
      "propertyName": "Condition",
      "sourceBinding": "attribute-value",
      "originalValue": "[io_InitRetryCounter &lt; int_MaxInitRetries]",
      "resolvedValue": "[io_InitRetryCounter &lt; int_MaxInitRetries]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[io_InitRetryCounter &lt; int_MaxInitRetries]",
        "precedenceTier": 4
      }
    },
    {
      "file": "RetryInit.xaml",
      "workflow": "RetryInit",
      "activityType": "Assign",
      "propertyName": "To",
      "sourceBinding": "workflowArgument",
      "originalValue": "[io_RetryInit]",
      "resolvedValue": "[io_RetryInit]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 1,
      "provenance": {
        "sourceKind": "workflowArgument",
        "sourceName": "io_RetryInit",
        "sourceWorkflow": "RetryInit",
        "precedenceTier": 1
      }
    },
    {
      "file": "RetryInit.xaml",
      "workflow": "RetryInit",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "[True]",
      "resolvedValue": "[True]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 1,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[True]",
        "precedenceTier": 4
      }
    },
    {
      "file": "RetryInit.xaml",
      "workflow": "RetryInit",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Init retry allowed — attempt &quot; &amp; io_InitRetryCounter.ToString() &amp; &quot; of &quot; &amp; int_MaxInitRetries.ToString()]",
      "resolvedValue": "[&quot;Init retry allowed — attempt &quot; &amp; io_InitRetryCounter.ToString() &amp; &quot; of &quot; &amp; int_MaxInitRetries.ToString()]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Init retry allowed — attempt &quot; &amp; io_InitRetryCounter.ToString() ",
        "precedenceTier": 4
      }
    },
    {
      "file": "RetryInit.xaml",
      "workflow": "RetryInit",
      "activityType": "Assign",
      "propertyName": "To",
      "sourceBinding": "workflowArgument",
      "originalValue": "[io_RetryInit]",
      "resolvedValue": "[io_RetryInit]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 2,
      "provenance": {
        "sourceKind": "workflowArgument",
        "sourceName": "io_RetryInit",
        "sourceWorkflow": "RetryInit",
        "precedenceTier": 1
      }
    },
    {
      "file": "RetryInit.xaml",
      "workflow": "RetryInit",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "[False]",
      "resolvedValue": "[False]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 2,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[False]",
        "precedenceTier": 4
      }
    },
    {
      "file": "RetryInit.xaml",
      "workflow": "RetryInit",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Init retries exhausted — max (&quot; &amp; int_MaxInitRetries.ToString() &amp; &quot;) reached&quot;]",
      "resolvedValue": "[&quot;Init retries exhausted — max (&quot; &amp; int_MaxInitRetries.ToString() &amp; &quot;) reached&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 1,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Init retries exhausted — max (&quot; &amp; int_MaxInitRetries.ToString() ",
        "precedenceTier": 4
      }
    },
    {
      "file": "RetryInit.xaml",
      "workflow": "RetryInit",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;=== Completed: RetryInit ===&quot;]",
      "resolvedValue": "[&quot;=== Completed: RetryInit ===&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 2,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;=== Completed: RetryInit ===&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "Process.xaml",
      "workflow": "Process",
      "activityType": "InvokeWorkflowFile",
      "propertyName": "WorkflowFileName",
      "sourceBinding": "attribute-value",
      "originalValue": "BGYY_Main.xaml",
      "resolvedValue": "BGYY_Main.xaml",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "BGYY_Main.xaml",
        "precedenceTier": 4
      }
    },
    {
      "file": "Process.xaml",
      "workflow": "Process",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;=== Completed: Process ===&quot;]",
      "resolvedValue": "[&quot;=== Completed: Process ===&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;=== Completed: Process ===&quot;]",
        "precedenceTier": 4
      }
    }
  ],
  "unresolvedRequiredPropertyDefects": [
    {
      "file": "BGYY_ResolveRecipient.xaml",
      "workflow": "BGYY_ResolveRecipient",
      "activityType": "If",
      "propertyName": "Condition",
      "failureReason": "If.Condition is generator-owned — the XAML generator or spec decomposer must emit this value. Found empty at enforcer stage.",
      "originalValue": "False",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "BGYY_ResolveRecipient.xaml",
      "workflow": "BGYY_ResolveRecipient",
      "activityType": "If",
      "propertyName": "Condition",
      "failureReason": "If.Condition is generator-owned — the XAML generator or spec decomposer must emit this value. Found empty at enforcer stage.",
      "originalValue": "False",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    }
  ],
  "expressionLoweringFixes": [],
  "expressionLoweringFailures": [],
  "requiredPropertyEnforcementSummary": "315 required property binding(s) resolved; 2 unresolved required property defect(s); 2 classification diagnostic(s)",
  "classificationDiagnostics": [
    {
      "file": "BGYY_ResolveRecipient.xaml",
      "workflow": "BGYY_ResolveRecipient",
      "activityType": "If",
      "propertyName": "Condition",
      "classification": "generator-owned",
      "approvedEnforcerRecovery": false,
      "message": "If.Condition is generator-owned — the XAML generator or spec decomposer must emit this value. Found empty at enforcer stage.",
      "resolved": false,
      "resolvedValue": null
    },
    {
      "file": "BGYY_ResolveRecipient.xaml",
      "workflow": "BGYY_ResolveRecipient",
      "activityType": "If",
      "propertyName": "Condition",
      "classification": "generator-owned",
      "approvedEnforcerRecovery": false,
      "message": "If.Condition is generator-owned — the XAML generator or spec decomposer must emit this value. Found empty at enforcer stage.",
      "resolved": false,
      "resolvedValue": null
    }
  ],
  "preComplianceGuardPassed": true,
  "preComplianceGuardViolationCount": 0,
  "canonicalizationArchiveParity": [
    {
      "file": "BGYY_GetTodaysBirthdays.xaml",
      "preCanonicalizationHash": "c2fa9c672f290699743fc75d4536d5cd1740b067179c568ae1228b06ee364976",
      "canonicalizedHash": "c2fa9c672f290699743fc75d4536d5cd1740b067179c568ae1228b06ee364976",
      "archivedHash": "c2fa9c672f290699743fc75d4536d5cd1740b067179c568ae1228b06ee364976",
      "identical": true,
      "mutated": false
    },
    {
      "file": "BGYY_ResolveRecipient.xaml",
      "preCanonicalizationHash": "fdeb5db62949bb95f47b6996fade6a75fae98e6aff5a2e59710cee3fc1ee6ff9",
      "canonicalizedHash": "f6875838432262b287c91b36cf6e85aaa3d6d6a4d43f75a58a07667ce21b5343",
      "archivedHash": "f6875838432262b287c91b36cf6e85aaa3d6d6a4d43f75a58a07667ce21b5343",
      "identical": true,
      "mutated": true
    },
    {
      "file": "BGYY_CheckDedupe.xaml",
      "preCanonicalizationHash": "6761aefe642c29aa137b613c275fba0afb983be16bbd47918148b8e6226a3e77",
      "canonicalizedHash": "6761aefe642c29aa137b613c275fba0afb983be16bbd47918148b8e6226a3e77",
      "archivedHash": "6761aefe642c29aa137b613c275fba0afb983be16bbd47918148b8e6226a3e77",
      "identical": true,
      "mutated": false
    },
    {
      "file": "BGYY_GenerateAndValidateDraft.xaml",
      "preCanonicalizationHash": "f1b4926bbff149f12fae70aa4c9a3f7c2677c189561ed6179dedcdab68097250",
      "canonicalizedHash": "8ed2ec0b2239eb39b1238ba50fb1b7dfcecddc53c8b599688f942c6903faf0f1",
      "archivedHash": "8ed2ec0b2239eb39b1238ba50fb1b7dfcecddc53c8b599688f942c6903faf0f1",
      "identical": true,
      "mutated": true
    },
    {
      "file": "BGYY_SendGmail.xaml",
      "preCanonicalizationHash": "7397ecacf0a14285fb952e9e088d17d9a251e8b0086a101a89be416de5fe541e",
      "canonicalizedHash": "426c8e12697c8f0a08935dd353d94125878a6d71c8f1ff6dbfd3f509c8bf664d",
      "archivedHash": "426c8e12697c8f0a08935dd353d94125878a6d71c8f1ff6dbfd3f509c8bf664d",
      "identical": true,
      "mutated": true
    },
    {
      "file": "BGYY_WriteDedupe.xaml",
      "preCanonicalizationHash": "34f085255c36b50ffc8f02e9d1b4dac9b57454fbb75b2353d3d40c0b8f83fd8b",
      "canonicalizedHash": "089627e583fd66ff6462c2048e581d7baa35f9e81454ca1e475dd145887081bd",
      "archivedHash": "089627e583fd66ff6462c2048e581d7baa35f9e81454ca1e475dd145887081bd",
      "identical": true,
      "mutated": true
    },
    {
      "file": "BGYY_CreateReviewTask.xaml",
      "preCanonicalizationHash": "11b2e8e6542a23ec44a864643b2cbfbd401d6217bd0f7c149d8c349690b843c1",
      "canonicalizedHash": "d73682bac379ee6856d048821da19b088ae49e942af9a84cc54660475828abbb",
      "archivedHash": "d73682bac379ee6856d048821da19b088ae49e942af9a84cc54660475828abbb",
      "identical": true,
      "mutated": true
    },
    {
      "file": "BGYY_Main.xaml",
      "preCanonicalizationHash": "0df9398124779d39aeb14642fe3b4c3e113d3b66cd683c34ce0571fa4fe1fcf8",
      "canonicalizedHash": "0df9398124779d39aeb14642fe3b4c3e113d3b66cd683c34ce0571fa4fe1fcf8",
      "archivedHash": "0df9398124779d39aeb14642fe3b4c3e113d3b66cd683c34ce0571fa4fe1fcf8",
      "identical": true,
      "mutated": false
    },
    {
      "file": "InitAllSettings.xaml",
      "preCanonicalizationHash": "e7bee23e7319943b5f7902ad849c8bfa210ad9f6340a9d0ccda071df6d65a490",
      "canonicalizedHash": "e7bee23e7319943b5f7902ad849c8bfa210ad9f6340a9d0ccda071df6d65a490",
      "archivedHash": "e7bee23e7319943b5f7902ad849c8bfa210ad9f6340a9d0ccda071df6d65a490",
      "identical": true,
      "mutated": false
    },
    {
      "file": "Main.xaml",
      "preCanonicalizationHash": "1a6dd9d3fc80874a3d9a791f81c7596d340417bfd52f9b4c671a19aac48d9a4b",
      "canonicalizedHash": "d4f3449872b830d3831785c8438ad72db99f567c8ecf58444dd18e17bedc869e",
      "archivedHash": "d4f3449872b830d3831785c8438ad72db99f567c8ecf58444dd18e17bedc869e",
      "identical": true,
      "mutated": true
    },
    {
      "file": "GetTransactionData.xaml",
      "preCanonicalizationHash": "9fc0b0934e80d781cd088b0381229cf92545d8ffd5a4e713b793a0d7ba36c005",
      "canonicalizedHash": "9fc0b0934e80d781cd088b0381229cf92545d8ffd5a4e713b793a0d7ba36c005",
      "archivedHash": "9fc0b0934e80d781cd088b0381229cf92545d8ffd5a4e713b793a0d7ba36c005",
      "identical": true,
      "mutated": false
    },
    {
      "file": "SetTransactionStatus.xaml",
      "preCanonicalizationHash": "c87cbd3f5316c54df356f2d2a569a58df6669e6af60ed6e199f37eaaf9a8624b",
      "canonicalizedHash": "c87cbd3f5316c54df356f2d2a569a58df6669e6af60ed6e199f37eaaf9a8624b",
      "archivedHash": "c87cbd3f5316c54df356f2d2a569a58df6669e6af60ed6e199f37eaaf9a8624b",
      "identical": true,
      "mutated": false
    },
    {
      "file": "CloseAllApplications.xaml",
      "preCanonicalizationHash": "b1422460d64ed0a4961f1b32e46524dd7e9a62db7898fba1568518e973bca67d",
      "canonicalizedHash": "b1422460d64ed0a4961f1b32e46524dd7e9a62db7898fba1568518e973bca67d",
      "archivedHash": "b1422460d64ed0a4961f1b32e46524dd7e9a62db7898fba1568518e973bca67d",
      "identical": true,
      "mutated": false
    },
    {
      "file": "KillAllProcesses.xaml",
      "preCanonicalizationHash": "9c6ff76dd44c4e2dad41088dc1b0d396920b62d7269b65cd42d270d0aac760cb",
      "canonicalizedHash": "9c6ff76dd44c4e2dad41088dc1b0d396920b62d7269b65cd42d270d0aac760cb",
      "archivedHash": "9c6ff76dd44c4e2dad41088dc1b0d396920b62d7269b65cd42d270d0aac760cb",
      "identical": true,
      "mutated": false
    },
    {
      "file": "Init.xaml",
      "preCanonicalizationHash": "59937d8b7a8ccb91771dafe3273b012e5a2a6cbc0c3850c53980d22d718afc7a",
      "canonicalizedHash": "f44213c3e46b46c17650f45dfdfe51edffafbd18cc4a5294d890a3dd0b9b38bf",
      "archivedHash": "f44213c3e46b46c17650f45dfdfe51edffafbd18cc4a5294d890a3dd0b9b38bf",
      "identical": true,
      "mutated": true
    },
    {
      "file": "InitAllApplications.xaml",
      "preCanonicalizationHash": "5f36dc6bc4b5d25fedaca0bffd9163b903302540d7dc7b4a36a287115312a16f",
      "canonicalizedHash": "5f36dc6bc4b5d25fedaca0bffd9163b903302540d7dc7b4a36a287115312a16f",
      "archivedHash": "5f36dc6bc4b5d25fedaca0bffd9163b903302540d7dc7b4a36a287115312a16f",
      "identical": true,
      "mutated": false
    },
    {
      "file": "RetryCurrentTransaction.xaml",
      "preCanonicalizationHash": "39a5fb546f369dfb49d80e1c32a3f49c55cfd1ac6baf5cf5ae440dae5ddd36b9",
      "canonicalizedHash": "39a5fb546f369dfb49d80e1c32a3f49c55cfd1ac6baf5cf5ae440dae5ddd36b9",
      "archivedHash": "39a5fb546f369dfb49d80e1c32a3f49c55cfd1ac6baf5cf5ae440dae5ddd36b9",
      "identical": true,
      "mutated": false
    },
    {
      "file": "RetryInit.xaml",
      "preCanonicalizationHash": "694f0ead7ed225e69d2248e8534176858cc1c159c406597e10e1a08bd8d7fa4b",
      "canonicalizedHash": "694f0ead7ed225e69d2248e8534176858cc1c159c406597e10e1a08bd8d7fa4b",
      "archivedHash": "694f0ead7ed225e69d2248e8534176858cc1c159c406597e10e1a08bd8d7fa4b",
      "identical": true,
      "mutated": false
    },
    {
      "file": "Process.xaml",
      "preCanonicalizationHash": "121fa3d7ad75a57ff6de9e731c5d9522020a03c67e6d65f1f30264bca799c33b",
      "canonicalizedHash": "121fa3d7ad75a57ff6de9e731c5d9522020a03c67e6d65f1f30264bca799c33b",
      "archivedHash": "121fa3d7ad75a57ff6de9e731c5d9522020a03c67e6d65f1f30264bca799c33b",
      "identical": true,
      "mutated": false
    }
  ],
  "postClassifierMutationTrace": {
    "entries": [
      {
        "stage": "pre-freeze-snapshot",
        "function": "freezeArchiveWorkflows",
        "file": "BGYY_CheckDedupe.xaml",
        "mutationType": "xaml_bytes",
        "preHash": "N/A",
        "postHash": "6761aefe642c29aa137b613c275fba0afb983be16bbd47918148b8e6226a3e77",
        "allowed": true,
        "reason": "Workflow \"BGYY_CheckDedupe.xaml\" content captured at freeze point (status=non-stub)",
        "changedBytes": false,
        "changedStatus": false,
        "enforcementAction": "none"
      },
      {
        "stage": "pre-freeze-snapshot",
        "function": "freezeArchiveWorkflows",
        "file": "BGYY_CreateReviewTask.xaml",
        "mutationType": "xaml_bytes",
        "preHash": "N/A",
        "postHash": "d73682bac379ee6856d048821da19b088ae49e942af9a84cc54660475828abbb",
        "allowed": true,
        "reason": "Workflow \"BGYY_CreateReviewTask.xaml\" content captured at freeze point (status=non-stub)",
        "changedBytes": false,
        "changedStatus": false,
        "enforcementAction": "none"
      },
      {
        "stage": "pre-freeze-snapshot",
        "function": "freezeArchiveWorkflows",
        "file": "BGYY_GenerateAndValidateDraft.xaml",
        "mutationType": "xaml_bytes",
        "preHash": "N/A",
        "postHash": "8ed2ec0b2239eb39b1238ba50fb1b7dfcecddc53c8b599688f942c6903faf0f1",
        "allowed": true,
        "reason": "Workflow \"BGYY_GenerateAndValidateDraft.xaml\" content captured at freeze point (status=non-stub)",
        "changedBytes": false,
        "changedStatus": false,
        "enforcementAction": "none"
      },
      {
        "stage": "pre-freeze-snapshot",
        "function": "freezeArchiveWorkflows",
        "file": "BGYY_GetTodaysBirthdays.xaml",
        "mutationType": "xaml_bytes",
        "preHash": "N/A",
        "postHash": "c2fa9c672f290699743fc75d4536d5cd1740b067179c568ae1228b06ee364976",
        "allowed": true,
        "reason": "Workflow \"BGYY_GetTodaysBirthdays.xaml\" content captured at freeze point (status=stub)",
        "changedBytes": false,
        "changedStatus": false,
        "enforcementAction": "none"
      },
      {
        "stage": "pre-freeze-snapshot",
        "function": "freezeArchiveWorkflows",
        "file": "BGYY_Main.xaml",
        "mutationType": "xaml_bytes",
        "preHash": "N/A",
        "postHash": "0df9398124779d39aeb14642fe3b4c3e113d3b66cd683c34ce0571fa4fe1fcf8",
        "allowed": true,
        "reason": "Workflow \"BGYY_Main.xaml\" content captured at freeze point (status=stub)",
        "changedBytes": false,
        "changedStatus": false,
        "enforcementAction": "none"
      },
      {
        "stage": "pre-freeze-snapshot",
        "function": "freezeArchiveWorkflows",
        "file": "BGYY_ResolveRecipient.xaml",
        "mutationType": "xaml_bytes",
        "preHash": "N/A",
        "postHash": "f6875838432262b287c91b36cf6e85aaa3d6d6a4d43f75a58a07667ce21b5343",
        "allowed": true,
        "reason": "Workflow \"BGYY_ResolveRecipient.xaml\" content captured at freeze point (status=non-stub)",
        "changedBytes": false,
        "changedStatus": false,
        "enforcementAction": "none"
      },
      {
        "stage": "pre-freeze-snapshot",
        "function": "freezeArchiveWorkflows",
        "file": "BGYY_SendGmail.xaml",
        "mutationType": "xaml_bytes",
        "preHash": "N/A",
        "postHash": "426c8e12697c8f0a08935dd353d94125878a6d71c8f1ff6dbfd3f509c8bf664d",
        "allowed": true,
        "reason": "Workflow \"BGYY_SendGmail.xaml\" content captured at freeze point (status=non-stub)",
        "changedBytes": false,
        "changedStatus": false,
        "enforcementAction": "none"
      },
      {
        "stage": "pre-freeze-snapshot",
        "function": "freezeArchiveWorkflows",
        "file": "BGYY_WriteDedupe.xaml",
        "mutationType": "xaml_bytes",
        "preHash": "N/A",
        "postHash": "089627e583fd66ff6462c2048e581d7baa35f9e81454ca1e475dd145887081bd",
        "allowed": true,
        "reason": "Workflow \"BGYY_WriteDedupe.xaml\" content captured at freeze point (status=non-stub)",
        "changedBytes": false,
        "changedStatus": false,
        "enforcementAction": "none"
      },
      {
        "stage": "pre-freeze-snapshot",
        "function": "freezeArchiveWorkflows",
        "file": "CloseAllApplications.xaml",
        "mutationType": "xaml_bytes",
        "preHash": "N/A",
        "postHash": "b1422460d64ed0a4961f1b32e46524dd7e9a62db7898fba1568518e973bca67d",
        "allowed": true,
        "reason": "Workflow \"CloseAllApplications.xaml\" content captured at freeze point (status=non-stub)",
        "changedBytes": false,
        "changedStatus": false,
        "enforcementAction": "none"
      },
      {
        "stage": "pre-freeze-snapshot",
        "function": "freezeArchiveWorkflows",
        "file": "GetTransactionData.xaml",
        "mutationType": "xaml_bytes",
        "preHash": "N/A",
        "postHash": "9fc0b0934e80d781cd088b0381229cf92545d8ffd5a4e713b793a0d7ba36c005",
        "allowed": true,
        "reason": "Workflow \"GetTransactionData.xaml\" content captured at freeze point (status=non-stub)",
        "changedBytes": false,
        "changedStatus": false,
        "enforcementAction": "none"
      },
      {
        "stage": "pre-freeze-snapshot",
        "function": "freezeArchiveWorkflows",
        "file": "Init.xaml",
        "mutationType": "xaml_bytes",
        "preHash": "N/A",
        "postHash": "f44213c3e46b46c17650f45dfdfe51edffafbd18cc4a5294d890a3dd0b9b38bf",
        "allowed": true,
        "reason": "Workflow \"Init.xaml\" content captured at freeze point (status=non-stub)",
        "changedBytes": false,
        "changedStatus": false,
        "enforcementAction": "none"
      },
      {
        "stage": "pre-freeze-snapshot",
        "function": "freezeArchiveWorkflows",
        "file": "InitAllApplications.xaml",
        "mutationType": "xaml_bytes",
        "preHash": "N/A",
        "postHash": "5f36dc6bc4b5d25fedaca0bffd9163b903302540d7dc7b4a36a287115312a16f",
        "allowed": true,
        "reason": "Workflow \"InitAllApplications.xaml\" content captured at freeze point (status=non-stub)",
        "changedBytes": false,
        "changedStatus": false,
        "enforcementAction": "none"
      },
      {
        "stage": "pre-freeze-snapshot",
        "function": "freezeArchiveWorkflows",
        "file": "InitAllSettings.xaml",
        "mutationType": "xaml_bytes",
        "preHash": "N/A",
        "postHash": "e7bee23e7319943b5f7902ad849c8bfa210ad9f6340a9d0ccda071df6d65a490",
        "allowed": true,
        "reason": "Workflow \"InitAllSettings.xaml\" content captured at freeze point (status=non-stub)",
        "changedBytes": false,
        "changedStatus": false,
        "enforcementAction": "none"
      },
      {
        "stage": "pre-freeze-snapshot",
        "function": "freezeArchiveWorkflows",
        "file": "KillAllProcesses.xaml",
        "mutationType": "xaml_bytes",
        "preHash": "N/A",
        "postHash": "9c6ff76dd44c4e2dad41088dc1b0d396920b62d7269b65cd42d270d0aac760cb",
        "allowed": true,
        "reason": "Workflow \"KillAllProcesses.xaml\" content captured at freeze point (status=non-stub)",
        "changedBytes": false,
        "changedStatus": false,
        "enforcementAction": "none"
      },
      {
        "stage": "pre-freeze-snapshot",
        "function": "freezeArchiveWorkflows",
        "file": "Main.xaml",
        "mutationType": "xaml_bytes",
        "preHash": "N/A",
        "postHash": "d4f3449872b830d3831785c8438ad72db99f567c8ecf58444dd18e17bedc869e",
        "allowed": true,
        "reason": "Workflow \"Main.xaml\" content captured at freeze point (status=non-stub)",
        "changedBytes": false,
        "changedStatus": false,
        "enforcementAction": "none"
      },
      {
        "stage": "pre-freeze-snapshot",
        "function": "freezeArchiveWorkflows",
        "file": "Process.xaml",
        "mutationType": "xaml_bytes",
        "preHash": "N/A",
        "postHash": "121fa3d7ad75a57ff6de9e731c5d9522020a03c67e6d65f1f30264bca799c33b",
        "allowed": true,
        "reason": "Workflow \"Process.xaml\" content captured at freeze point (status=non-stub)",
        "changedBytes": false,
        "changedStatus": false,
        "enforcementAction": "none"
      },
      {
        "stage": "pre-freeze-snapshot",
        "function": "freezeArchiveWorkflows",
        "file": "RetryCurrentTransaction.xaml",
        "mutationType": "xaml_bytes",
        "preHash": "N/A",
        "postHash": "39a5fb546f369dfb49d80e1c32a3f49c55cfd1ac6baf5cf5ae440dae5ddd36b9",
        "allowed": true,
        "reason": "Workflow \"RetryCurrentTransaction.xaml\" content captured at freeze point (status=non-stub)",
        "changedBytes": false,
        "changedStatus": false,
        "enforcementAction": "none"
      },
      {
        "stage": "pre-freeze-snapshot",
        "function": "freezeArchiveWorkflows",
        "file": "RetryInit.xaml",
        "mutationType": "xaml_bytes",
        "preHash": "N/A",
        "postHash": "694f0ead7ed225e69d2248e8534176858cc1c159c406597e10e1a08bd8d7fa4b",
        "allowed": true,
        "reason": "Workflow \"RetryInit.xaml\" content captured at freeze point (status=non-stub)",
        "changedBytes": false,
        "changedStatus": false,
        "enforcementAction": "none"
      },
      {
        "stage": "pre-freeze-snapshot",
        "function": "freezeArchiveWorkflows",
        "file": "SetTransactionStatus.xaml",
        "mutationType": "xaml_bytes",
        "preHash": "N/A",
        "postHash": "c87cbd3f5316c54df356f2d2a569a58df6669e6af60ed6e199f37eaaf9a8624b",
        "allowed": true,
        "reason": "Workflow \"SetTransactionStatus.xaml\" content captured at freeze point (status=non-stub)",
        "changedBytes": false,
        "changedStatus": false,
        "enforcementAction": "none"
      }
    ],
    "perFileMutationCounts": {
      "BGYY_CheckDedupe.xaml": 1,
      "BGYY_CreateReviewTask.xaml": 1,
      "BGYY_GenerateAndValidateDraft.xaml": 1,
      "BGYY_GetTodaysBirthdays.xaml": 1,
      "BGYY_Main.xaml": 1,
      "BGYY_ResolveRecipient.xaml": 1,
      "BGYY_SendGmail.xaml": 1,
      "BGYY_WriteDedupe.xaml": 1,
      "CloseAllApplications.xaml": 1,
      "GetTransactionData.xaml": 1,
      "Init.xaml": 1,
      "InitAllApplications.xaml": 1,
      "InitAllSettings.xaml": 1,
      "KillAllProcesses.xaml": 1,
      "Main.xaml": 1,
      "Process.xaml": 1,
      "RetryCurrentTransaction.xaml": 1,
      "RetryInit.xaml": 1,
      "SetTransactionStatus.xaml": 1
    },
    "filesChangedAfterFreeze": [],
    "summary": {
      "totalAttemptedMutations": 19,
      "totalBlockedMutations": 0,
      "totalAllowedPreFreezeMutations": 19,
      "totalPostFreezeViolations": 0,
      "totalUnexpectedPostFreezeMutations": 0,
      "filesChangedAfterFreeze": 0
    }
  },
  "postFreezeMutationTrace": {
    "entries": [
      {
        "stage": "pre-freeze-snapshot",
        "function": "freezeArchiveWorkflows",
        "file": "BGYY_CheckDedupe.xaml",
        "mutationType": "xaml_bytes",
        "preHash": "N/A",
        "postHash": "6761aefe642c29aa137b613c275fba0afb983be16bbd47918148b8e6226a3e77",
        "allowed": true,
        "reason": "Workflow \"BGYY_CheckDedupe.xaml\" content captured at freeze point (status=non-stub)",
        "changedBytes": false,
        "changedStatus": false,
        "enforcementAction": "none"
      },
      {
        "stage": "pre-freeze-snapshot",
        "function": "freezeArchiveWorkflows",
        "file": "BGYY_CreateReviewTask.xaml",
        "mutationType": "xaml_bytes",
        "preHash": "N/A",
        "postHash": "d73682bac379ee6856d048821da19b088ae49e942af9a84cc54660475828abbb",
        "allowed": true,
        "reason": "Workflow \"BGYY_CreateReviewTask.xaml\" content captured at freeze point (status=non-stub)",
        "changedBytes": false,
        "changedStatus": false,
        "enforcementAction": "none"
      },
      {
        "stage": "pre-freeze-snapshot",
        "function": "freezeArchiveWorkflows",
        "file": "BGYY_GenerateAndValidateDraft.xaml",
        "mutationType": "xaml_bytes",
        "preHash": "N/A",
        "postHash": "8ed2ec0b2239eb39b1238ba50fb1b7dfcecddc53c8b599688f942c6903faf0f1",
        "allowed": true,
        "reason": "Workflow \"BGYY_GenerateAndValidateDraft.xaml\" content captured at freeze point (status=non-stub)",
        "changedBytes": false,
        "changedStatus": false,
        "enforcementAction": "none"
      },
      {
        "stage": "pre-freeze-snapshot",
        "function": "freezeArchiveWorkflows",
        "file": "BGYY_GetTodaysBirthdays.xaml",
        "mutationType": "xaml_bytes",
        "preHash": "N/A",
        "postHash": "c2fa9c672f290699743fc75d4536d5cd1740b067179c568ae1228b06ee364976",
        "allowed": true,
        "reason": "Workflow \"BGYY_GetTodaysBirthdays.xaml\" content captured at freeze point (status=stub)",
        "changedBytes": false,
        "changedStatus": false,
        "enforcementAction": "none"
      },
      {
        "stage": "pre-freeze-snapshot",
        "function": "freezeArchiveWorkflows",
        "file": "BGYY_Main.xaml",
        "mutationType": "xaml_bytes",
        "preHash": "N/A",
        "postHash": "0df9398124779d39aeb14642fe3b4c3e113d3b66cd683c34ce0571fa4fe1fcf8",
        "allowed": true,
        "reason": "Workflow \"BGYY_Main.xaml\" content captured at freeze point (status=stub)",
        "changedBytes": false,
        "changedStatus": false,
        "enforcementAction": "none"
      },
      {
        "stage": "pre-freeze-snapshot",
        "function": "freezeArchiveWorkflows",
        "file": "BGYY_ResolveRecipient.xaml",
        "mutationType": "xaml_bytes",
        "preHash": "N/A",
        "postHash": "f6875838432262b287c91b36cf6e85aaa3d6d6a4d43f75a58a07667ce21b5343",
        "allowed": true,
        "reason": "Workflow \"BGYY_ResolveRecipient.xaml\" content captured at freeze point (status=non-stub)",
        "changedBytes": false,
        "changedStatus": false,
        "enforcementAction": "none"
      },
      {
        "stage": "pre-freeze-snapshot",
        "function": "freezeArchiveWorkflows",
        "file": "BGYY_SendGmail.xaml",
        "mutationType": "xaml_bytes",
        "preHash": "N/A",
        "postHash": "426c8e12697c8f0a08935dd353d94125878a6d71c8f1ff6dbfd3f509c8bf664d",
        "allowed": true,
        "reason": "Workflow \"BGYY_SendGmail.xaml\" content captured at freeze point (status=non-stub)",
        "changedBytes": false,
        "changedStatus": false,
        "enforcementAction": "none"
      },
      {
        "stage": "pre-freeze-snapshot",
        "function": "freezeArchiveWorkflows",
        "file": "BGYY_WriteDedupe.xaml",
        "mutationType": "xaml_bytes",
        "preHash": "N/A",
        "postHash": "089627e583fd66ff6462c2048e581d7baa35f9e81454ca1e475dd145887081bd",
        "allowed": true,
        "reason": "Workflow \"BGYY_WriteDedupe.xaml\" content captured at freeze point (status=non-stub)",
        "changedBytes": false,
        "changedStatus": false,
        "enforcementAction": "none"
      },
      {
        "stage": "pre-freeze-snapshot",
        "function": "freezeArchiveWorkflows",
        "file": "CloseAllApplications.xaml",
        "mutationType": "xaml_bytes",
        "preHash": "N/A",
        "postHash": "b1422460d64ed0a4961f1b32e46524dd7e9a62db7898fba1568518e973bca67d",
        "allowed": true,
        "reason": "Workflow \"CloseAllApplications.xaml\" content captured at freeze point (status=non-stub)",
        "changedBytes": false,
        "changedStatus": false,
        "enforcementAction": "none"
      },
      {
        "stage": "pre-freeze-snapshot",
        "function": "freezeArchiveWorkflows",
        "file": "GetTransactionData.xaml",
        "mutationType": "xaml_bytes",
        "preHash": "N/A",
        "postHash": "9fc0b0934e80d781cd088b0381229cf92545d8ffd5a4e713b793a0d7ba36c005",
        "allowed": true,
        "reason": "Workflow \"GetTransactionData.xaml\" content captured at freeze point (status=non-stub)",
        "changedBytes": false,
        "changedStatus": false,
        "enforcementAction": "none"
      },
      {
        "stage": "pre-freeze-snapshot",
        "function": "freezeArchiveWorkflows",
        "file": "Init.xaml",
        "mutationType": "xaml_bytes",
        "preHash": "N/A",
        "postHash": "f44213c3e46b46c17650f45dfdfe51edffafbd18cc4a5294d890a3dd0b9b38bf",
        "allowed": true,
        "reason": "Workflow \"Init.xaml\" content captured at freeze point (status=non-stub)",
        "changedBytes": false,
        "changedStatus": false,
        "enforcementAction": "none"
      },
      {
        "stage": "pre-freeze-snapshot",
        "function": "freezeArchiveWorkflows",
        "file": "InitAllApplications.xaml",
        "mutationType": "xaml_bytes",
        "preHash": "N/A",
        "postHash": "5f36dc6bc4b5d25fedaca0bffd9163b903302540d7dc7b4a36a287115312a16f",
        "allowed": true,
        "reason": "Workflow \"InitAllApplications.xaml\" content captured at freeze point (status=non-stub)",
        "changedBytes": false,
        "changedStatus": false,
        "enforcementAction": "none"
      },
      {
        "stage": "pre-freeze-snapshot",
        "function": "freezeArchiveWorkflows",
        "file": "InitAllSettings.xaml",
        "mutationType": "xaml_bytes",
        "preHash": "N/A",
        "postHash": "e7bee23e7319943b5f7902ad849c8bfa210ad9f6340a9d0ccda071df6d65a490",
        "allowed": true,
        "reason": "Workflow \"InitAllSettings.xaml\" content captured at freeze point (status=non-stub)",
        "changedBytes": false,
        "changedStatus": false,
        "enforcementAction": "none"
      },
      {
        "stage": "pre-freeze-snapshot",
        "function": "freezeArchiveWorkflows",
        "file": "KillAllProcesses.xaml",
        "mutationType": "xaml_bytes",
        "preHash": "N/A",
        "postHash": "9c6ff76dd44c4e2dad41088dc1b0d396920b62d7269b65cd42d270d0aac760cb",
        "allowed": true,
        "reason": "Workflow \"KillAllProcesses.xaml\" content captured at freeze point (status=non-stub)",
        "changedBytes": false,
        "changedStatus": false,
        "enforcementAction": "none"
      },
      {
        "stage": "pre-freeze-snapshot",
        "function": "freezeArchiveWorkflows",
        "file": "Main.xaml",
        "mutationType": "xaml_bytes",
        "preHash": "N/A",
        "postHash": "d4f3449872b830d3831785c8438ad72db99f567c8ecf58444dd18e17bedc869e",
        "allowed": true,
        "reason": "Workflow \"Main.xaml\" content captured at freeze point (status=non-stub)",
        "changedBytes": false,
        "changedStatus": false,
        "enforcementAction": "none"
      },
      {
        "stage": "pre-freeze-snapshot",
        "function": "freezeArchiveWorkflows",
        "file": "Process.xaml",
        "mutationType": "xaml_bytes",
        "preHash": "N/A",
        "postHash": "121fa3d7ad75a57ff6de9e731c5d9522020a03c67e6d65f1f30264bca799c33b",
        "allowed": true,
        "reason": "Workflow \"Process.xaml\" content captured at freeze point (status=non-stub)",
        "changedBytes": false,
        "changedStatus": false,
        "enforcementAction": "none"
      },
      {
        "stage": "pre-freeze-snapshot",
        "function": "freezeArchiveWorkflows",
        "file": "RetryCurrentTransaction.xaml",
        "mutationType": "xaml_bytes",
        "preHash": "N/A",
        "postHash": "39a5fb546f369dfb49d80e1c32a3f49c55cfd1ac6baf5cf5ae440dae5ddd36b9",
        "allowed": true,
        "reason": "Workflow \"RetryCurrentTransaction.xaml\" content captured at freeze point (status=non-stub)",
        "changedBytes": false,
        "changedStatus": false,
        "enforcementAction": "none"
      },
      {
        "stage": "pre-freeze-snapshot",
        "function": "freezeArchiveWorkflows",
        "file": "RetryInit.xaml",
        "mutationType": "xaml_bytes",
        "preHash": "N/A",
        "postHash": "694f0ead7ed225e69d2248e8534176858cc1c159c406597e10e1a08bd8d7fa4b",
        "allowed": true,
        "reason": "Workflow \"RetryInit.xaml\" content captured at freeze point (status=non-stub)",
        "changedBytes": false,
        "changedStatus": false,
        "enforcementAction": "none"
      },
      {
        "stage": "pre-freeze-snapshot",
        "function": "freezeArchiveWorkflows",
        "file": "SetTransactionStatus.xaml",
        "mutationType": "xaml_bytes",
        "preHash": "N/A",
        "postHash": "c87cbd3f5316c54df356f2d2a569a58df6669e6af60ed6e199f37eaaf9a8624b",
        "allowed": true,
        "reason": "Workflow \"SetTransactionStatus.xaml\" content captured at freeze point (status=non-stub)",
        "changedBytes": false,
        "changedStatus": false,
        "enforcementAction": "none"
      }
    ],
    "perFileMutationCounts": {
      "BGYY_CheckDedupe.xaml": 1,
      "BGYY_CreateReviewTask.xaml": 1,
      "BGYY_GenerateAndValidateDraft.xaml": 1,
      "BGYY_GetTodaysBirthdays.xaml": 1,
      "BGYY_Main.xaml": 1,
      "BGYY_ResolveRecipient.xaml": 1,
      "BGYY_SendGmail.xaml": 1,
      "BGYY_WriteDedupe.xaml": 1,
      "CloseAllApplications.xaml": 1,
      "GetTransactionData.xaml": 1,
      "Init.xaml": 1,
      "InitAllApplications.xaml": 1,
      "InitAllSettings.xaml": 1,
      "KillAllProcesses.xaml": 1,
      "Main.xaml": 1,
      "Process.xaml": 1,
      "RetryCurrentTransaction.xaml": 1,
      "RetryInit.xaml": 1,
      "SetTransactionStatus.xaml": 1
    },
    "filesChangedAfterFreeze": [],
    "summary": {
      "totalAttemptedMutations": 19,
      "totalBlockedMutations": 0,
      "totalAllowedPreFreezeMutations": 19,
      "totalPostFreezeViolations": 0,
      "totalUnexpectedPostFreezeMutations": 0,
      "filesChangedAfterFreeze": 0
    }
  },
  "workflowAutoWiringDiagnostics": {
    "entries": [
      {
        "file": "BGYY_GetTodaysBirthdays.xaml",
        "generated": true,
        "required": true,
        "workflowRole": "decomposed_child",
        "classificationSourceRule": "generated_by_spec_decomposition",
        "requiredByPath": "Main.xaml → BGYY_GetTodaysBirthdays.xaml → spec-decomposition:BGYY_GetTodaysBirthdays",
        "expectedCaller": "BGYY_GetTodaysBirthdays.xaml",
        "callerCandidates": [
          "BGYY_GetTodaysBirthdays.xaml",
          "BGYY_Main.xaml",
          "Process.xaml",
          "Main.xaml"
        ],
        "invokeAttempted": true,
        "invokeSucceeded": true,
        "invokeSkippedReason": null,
        "invokeRejectedReason": null,
        "actualCallers": [
          "BGYY_GetTodaysBirthdays.xaml",
          "BGYY_Main.xaml"
        ],
        "reachableFromMain": true,
        "finalWiringStatus": "wired_and_reachable",
        "rootCauseCategory": "none",
        "remediationHint": null,
        "unwiredSeverity": "none"
      },
      {
        "file": "BGYY_ResolveRecipient.xaml",
        "generated": true,
        "required": true,
        "workflowRole": "decomposed_child",
        "classificationSourceRule": "generated_by_spec_decomposition",
        "requiredByPath": "Main.xaml → BGYY_GetTodaysBirthdays.xaml → spec-decomposition:BGYY_ResolveRecipient",
        "expectedCaller": "BGYY_GetTodaysBirthdays.xaml",
        "callerCandidates": [
          "BGYY_GetTodaysBirthdays.xaml",
          "BGYY_Main.xaml",
          "Process.xaml",
          "Main.xaml"
        ],
        "invokeAttempted": true,
        "invokeSucceeded": true,
        "invokeSkippedReason": null,
        "invokeRejectedReason": null,
        "actualCallers": [
          "BGYY_GetTodaysBirthdays.xaml",
          "BGYY_Main.xaml"
        ],
        "reachableFromMain": true,
        "finalWiringStatus": "wired_and_reachable",
        "rootCauseCategory": "none",
        "remediationHint": null,
        "unwiredSeverity": "none"
      },
      {
        "file": "BGYY_CheckDedupe.xaml",
        "generated": true,
        "required": true,
        "workflowRole": "decomposed_child",
        "classificationSourceRule": "generated_by_spec_decomposition",
        "requiredByPath": "Main.xaml → BGYY_GetTodaysBirthdays.xaml → spec-decomposition:BGYY_CheckDedupe",
        "expectedCaller": "BGYY_GetTodaysBirthdays.xaml",
        "callerCandidates": [
          "BGYY_GetTodaysBirthdays.xaml",
          "BGYY_Main.xaml",
          "Process.xaml",
          "Main.xaml"
        ],
        "invokeAttempted": true,
        "invokeSucceeded": true,
        "invokeSkippedReason": null,
        "invokeRejectedReason": null,
        "actualCallers": [
          "BGYY_GetTodaysBirthdays.xaml",
          "BGYY_Main.xaml"
        ],
        "reachableFromMain": true,
        "finalWiringStatus": "wired_and_reachable",
        "rootCauseCategory": "none",
        "remediationHint": null,
        "unwiredSeverity": "none"
      },
      {
        "file": "BGYY_GenerateAndValidateDraft.xaml",
        "generated": true,
        "required": true,
        "workflowRole": "decomposed_child",
        "classificationSourceRule": "generated_by_spec_decomposition",
        "requiredByPath": "Main.xaml → BGYY_GetTodaysBirthdays.xaml → spec-decomposition:BGYY_GenerateAndValidateDraft",
        "expectedCaller": "BGYY_GetTodaysBirthdays.xaml",
        "callerCandidates": [
          "BGYY_GetTodaysBirthdays.xaml",
          "Process.xaml",
          "Main.xaml"
        ],
        "invokeAttempted": true,
        "invokeSucceeded": true,
        "invokeSkippedReason": null,
        "invokeRejectedReason": null,
        "actualCallers": [
          "BGYY_GetTodaysBirthdays.xaml"
        ],
        "reachableFromMain": true,
        "finalWiringStatus": "wired_and_reachable",
        "rootCauseCategory": "none",
        "remediationHint": null,
        "unwiredSeverity": "none"
      },
      {
        "file": "BGYY_SendGmail.xaml",
        "generated": true,
        "required": true,
        "workflowRole": "decomposed_child",
        "classificationSourceRule": "generated_by_spec_decomposition",
        "requiredByPath": "Main.xaml → BGYY_GetTodaysBirthdays.xaml → spec-decomposition:BGYY_SendGmail",
        "expectedCaller": "BGYY_GetTodaysBirthdays.xaml",
        "callerCandidates": [
          "BGYY_GetTodaysBirthdays.xaml",
          "Process.xaml",
          "Main.xaml"
        ],
        "invokeAttempted": true,
        "invokeSucceeded": true,
        "invokeSkippedReason": null,
        "invokeRejectedReason": null,
        "actualCallers": [
          "BGYY_GetTodaysBirthdays.xaml"
        ],
        "reachableFromMain": true,
        "finalWiringStatus": "wired_and_reachable",
        "rootCauseCategory": "none",
        "remediationHint": null,
        "unwiredSeverity": "none"
      },
      {
        "file": "BGYY_WriteDedupe.xaml",
        "generated": true,
        "required": true,
        "workflowRole": "decomposed_child",
        "classificationSourceRule": "generated_by_spec_decomposition",
        "requiredByPath": "Main.xaml → BGYY_GetTodaysBirthdays.xaml → spec-decomposition:BGYY_WriteDedupe",
        "expectedCaller": "BGYY_GetTodaysBirthdays.xaml",
        "callerCandidates": [
          "BGYY_GetTodaysBirthdays.xaml",
          "BGYY_CreateReviewTask.xaml",
          "BGYY_Main.xaml",
          "Process.xaml",
          "Main.xaml"
        ],
        "invokeAttempted": true,
        "invokeSucceeded": true,
        "invokeSkippedReason": null,
        "invokeRejectedReason": null,
        "actualCallers": [
          "BGYY_GetTodaysBirthdays.xaml",
          "BGYY_CreateReviewTask.xaml",
          "BGYY_Main.xaml"
        ],
        "reachableFromMain": true,
        "finalWiringStatus": "wired_and_reachable",
        "rootCauseCategory": "none",
        "remediationHint": null,
        "unwiredSeverity": "none"
      },
      {
        "file": "BGYY_CreateReviewTask.xaml",
        "generated": true,
        "required": true,
        "workflowRole": "decomposed_child",
        "classificationSourceRule": "generated_by_spec_decomposition",
        "requiredByPath": "Main.xaml → BGYY_GetTodaysBirthdays.xaml → spec-decomposition:BGYY_CreateReviewTask",
        "expectedCaller": "BGYY_GetTodaysBirthdays.xaml",
        "callerCandidates": [
          "BGYY_GetTodaysBirthdays.xaml",
          "BGYY_Main.xaml",
          "Process.xaml",
          "Main.xaml"
        ],
        "invokeAttempted": true,
        "invokeSucceeded": true,
        "invokeSkippedReason": null,
        "invokeRejectedReason": null,
        "actualCallers": [
          "BGYY_GetTodaysBirthdays.xaml",
          "BGYY_Main.xaml"
        ],
        "reachableFromMain": true,
        "finalWiringStatus": "wired_and_reachable",
        "rootCauseCategory": "none",
        "remediationHint": null,
        "unwiredSeverity": "none"
      },
      {
        "file": "BGYY_Main.xaml",
        "generated": true,
        "required": true,
        "workflowRole": "decomposed_child",
        "classificationSourceRule": "generated_by_spec_decomposition",
        "requiredByPath": "Main.xaml → BGYY_GetTodaysBirthdays.xaml → spec-decomposition:BGYY_Main",
        "expectedCaller": "BGYY_GetTodaysBirthdays.xaml",
        "callerCandidates": [
          "BGYY_GetTodaysBirthdays.xaml",
          "Process.xaml",
          "Main.xaml"
        ],
        "invokeAttempted": true,
        "invokeSucceeded": true,
        "invokeSkippedReason": null,
        "invokeRejectedReason": null,
        "actualCallers": [
          "BGYY_GetTodaysBirthdays.xaml",
          "Process.xaml"
        ],
        "reachableFromMain": true,
        "finalWiringStatus": "wired_and_reachable",
        "rootCauseCategory": "none",
        "remediationHint": null,
        "unwiredSeverity": "none"
      },
      {
        "file": "InitAllSettings.xaml",
        "generated": false,
        "required": false,
        "workflowRole": "helper",
        "classificationSourceRule": "infrastructure_basename_match:initallsettings",
        "unwiredSeverity": "none",
        "requiredByPath": "infrastructure utility",
        "expectedCaller": "Main.xaml",
        "callerCandidates": [
          "Main.xaml"
        ],
        "invokeAttempted": false,
        "invokeSucceeded": false,
        "invokeSkippedReason": "infrastructure file — always included",
        "invokeRejectedReason": null,
        "actualCallers": [
          "BGYY_GetTodaysBirthdays.xaml",
          "Init.xaml"
        ],
        "reachableFromMain": true,
        "finalWiringStatus": "skipped_infrastructure",
        "rootCauseCategory": "none",
        "remediationHint": null
      },
      {
        "file": "Main.xaml",
        "generated": false,
        "required": true,
        "workflowRole": "entrypoint",
        "classificationSourceRule": "basename_match:Main",
        "requiredByPath": "Main.xaml (entry point)",
        "expectedCaller": null,
        "callerCandidates": [],
        "invokeAttempted": false,
        "invokeSucceeded": false,
        "invokeSkippedReason": "entrypoint workflow — wired by framework structure",
        "invokeRejectedReason": null,
        "actualCallers": [],
        "reachableFromMain": true,
        "finalWiringStatus": "wired_and_reachable",
        "rootCauseCategory": "none",
        "remediationHint": null,
        "unwiredSeverity": "none"
      },
      {
        "file": "GetTransactionData.xaml",
        "generated": false,
        "required": true,
        "workflowRole": "transaction_handler",
        "classificationSourceRule": "transaction_pattern_match:GetTransactionData",
        "requiredByPath": "Main.xaml → state-machine transition",
        "expectedCaller": "Main.xaml",
        "callerCandidates": [
          "Main.xaml"
        ],
        "invokeAttempted": true,
        "invokeSucceeded": true,
        "invokeSkippedReason": null,
        "invokeRejectedReason": null,
        "actualCallers": [
          "Main.xaml"
        ],
        "reachableFromMain": true,
        "finalWiringStatus": "wired_and_reachable",
        "rootCauseCategory": "none",
        "remediationHint": null,
        "unwiredSeverity": "none"
      },
      {
        "file": "SetTransactionStatus.xaml",
        "generated": false,
        "required": true,
        "workflowRole": "transaction_handler",
        "classificationSourceRule": "transaction_pattern_match:SetTransactionStatus",
        "requiredByPath": "Main.xaml → state-machine transition",
        "expectedCaller": "Main.xaml",
        "callerCandidates": [
          "Main.xaml"
        ],
        "invokeAttempted": true,
        "invokeSucceeded": true,
        "invokeSkippedReason": null,
        "invokeRejectedReason": null,
        "actualCallers": [
          "Main.xaml",
          "Main.xaml"
        ],
        "reachableFromMain": true,
        "finalWiringStatus": "wired_and_reachable",
        "rootCauseCategory": "none",
        "remediationHint": null,
        "unwiredSeverity": "none"
      },
      {
        "file": "CloseAllApplications.xaml",
        "generated": false,
        "required": false,
        "workflowRole": "helper",
        "classificationSourceRule": "infrastructure_basename_match:closeallapplications",
        "unwiredSeverity": "none",
        "requiredByPath": "infrastructure utility",
        "expectedCaller": "Main.xaml",
        "callerCandidates": [
          "Main.xaml"
        ],
        "invokeAttempted": false,
        "invokeSucceeded": false,
        "invokeSkippedReason": "infrastructure file — always included",
        "invokeRejectedReason": null,
        "actualCallers": [
          "Main.xaml",
          "Main.xaml"
        ],
        "reachableFromMain": true,
        "finalWiringStatus": "skipped_infrastructure",
        "rootCauseCategory": "none",
        "remediationHint": null
      },
      {
        "file": "KillAllProcesses.xaml",
        "generated": false,
        "required": false,
        "workflowRole": "helper",
        "classificationSourceRule": "infrastructure_basename_match:killallprocesses",
        "unwiredSeverity": "none",
        "requiredByPath": "infrastructure utility",
        "expectedCaller": "Main.xaml",
        "callerCandidates": [
          "Main.xaml"
        ],
        "invokeAttempted": false,
        "invokeSucceeded": false,
        "invokeSkippedReason": "infrastructure file — always included",
        "invokeRejectedReason": null,
        "actualCallers": [
          "CloseAllApplications.xaml"
        ],
        "reachableFromMain": true,
        "finalWiringStatus": "skipped_infrastructure",
        "rootCauseCategory": "none",
        "remediationHint": null
      },
      {
        "file": "Init.xaml",
        "generated": false,
        "required": false,
        "workflowRole": "helper",
        "classificationSourceRule": "non_generated_non_entrypoint",
        "requiredByPath": "Main.xaml → Main.xaml → spec-decomposition:Init",
        "expectedCaller": "Main.xaml",
        "callerCandidates": [
          "Main.xaml",
          "Process.xaml"
        ],
        "invokeAttempted": true,
        "invokeSucceeded": true,
        "invokeSkippedReason": null,
        "invokeRejectedReason": null,
        "actualCallers": [
          "Main.xaml"
        ],
        "reachableFromMain": true,
        "finalWiringStatus": "wired_and_reachable",
        "rootCauseCategory": "none",
        "remediationHint": null,
        "unwiredSeverity": "none"
      },
      {
        "file": "InitAllApplications.xaml",
        "generated": false,
        "required": false,
        "workflowRole": "helper",
        "classificationSourceRule": "non_generated_non_entrypoint",
        "requiredByPath": "Main.xaml → Process.xaml → spec-decomposition:InitAllApplications",
        "expectedCaller": "Process.xaml",
        "callerCandidates": [
          "Process.xaml",
          "Main.xaml"
        ],
        "invokeAttempted": false,
        "invokeSucceeded": false,
        "invokeSkippedReason": "non-generated optional workflow — not a wiring target",
        "invokeRejectedReason": null,
        "actualCallers": [],
        "reachableFromMain": false,
        "finalWiringStatus": "unwired_but_retained",
        "rootCauseCategory": "none",
        "remediationHint": null,
        "unwiredSeverity": "info"
      },
      {
        "file": "RetryCurrentTransaction.xaml",
        "generated": false,
        "required": false,
        "workflowRole": "helper",
        "classificationSourceRule": "non_generated_non_entrypoint",
        "requiredByPath": "Main.xaml → Process.xaml → spec-decomposition:RetryCurrentTransaction",
        "expectedCaller": "Process.xaml",
        "callerCandidates": [
          "Process.xaml",
          "Main.xaml"
        ],
        "invokeAttempted": false,
        "invokeSucceeded": false,
        "invokeSkippedReason": "non-generated optional workflow — not a wiring target",
        "invokeRejectedReason": null,
        "actualCallers": [],
        "reachableFromMain": false,
        "finalWiringStatus": "unwired_but_retained",
        "rootCauseCategory": "none",
        "remediationHint": null,
        "unwiredSeverity": "info"
      },
      {
        "file": "RetryInit.xaml",
        "generated": false,
        "required": false,
        "workflowRole": "helper",
        "classificationSourceRule": "non_generated_non_entrypoint",
        "requiredByPath": "Main.xaml → Process.xaml → spec-decomposition:RetryInit",
        "expectedCaller": "Process.xaml",
        "callerCandidates": [
          "Process.xaml",
          "Main.xaml"
        ],
        "invokeAttempted": false,
        "invokeSucceeded": false,
        "invokeSkippedReason": "non-generated optional workflow — not a wiring target",
        "invokeRejectedReason": null,
        "actualCallers": [],
        "reachableFromMain": false,
        "finalWiringStatus": "unwired_but_retained",
        "rootCauseCategory": "none",
        "remediationHint": null,
        "unwiredSeverity": "info"
      },
      {
        "file": "Process.xaml",
        "generated": false,
        "required": true,
        "workflowRole": "entrypoint",
        "classificationSourceRule": "basename_match:Process",
        "requiredByPath": "Main.xaml (entry point)",
        "expectedCaller": "Main.xaml",
        "callerCandidates": [
          "Main.xaml"
        ],
        "invokeAttempted": false,
        "invokeSucceeded": false,
        "invokeSkippedReason": "entrypoint workflow — wired by framework structure",
        "invokeRejectedReason": null,
        "actualCallers": [
          "Main.xaml"
        ],
        "reachableFromMain": true,
        "finalWiringStatus": "wired_and_reachable",
        "rootCauseCategory": "none",
        "remediationHint": null,
        "unwiredSeverity": "none"
      }
    ],
    "summary": {
      "totalGeneratedWorkflows": 8,
      "totalRequiredWorkflows": 12,
      "totalRequiredWorkflowsWired": 12,
      "totalGeneratedButUnwired": 0,
      "totalUnreachableFromMain": 3,
      "totalMissingInvokeEdges": 0,
      "totalCallerMismatchDefects": 2,
      "totalInvokeEmissionFailures": 0
    },
    "activePathProof": {
      "reachabilityComputedOnFinalizedSet": true,
      "reachabilityPruningSkipped": false,
      "wiringComputedOnFinalizedSet": true,
      "workflowSetHashAtWiringTime": "ee8e1be8247016f5",
      "workflowSetHashAtReachabilityTime": "1e0e03aafc517a5c",
      "consistent": false
    }
  },
  "symbolDiscoveryDiagnostics": [
    {
      "symbol": "Is",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: excluded symbol token (keyword/CLR type/XML entity)"
    },
    {
      "symbol": "Nothing",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: excluded symbol token (keyword/CLR type/XML entity)"
    },
    {
      "symbol": "New",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: excluded symbol token (keyword/CLR type/XML entity)"
    },
    {
      "symbol": "InvalidOperationException",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: identifier used as function call"
    },
    {
      "symbol": "If",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: excluded symbol token (keyword/CLR type/XML entity)"
    },
    {
      "symbol": "IsNot",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: excluded symbol token (keyword/CLR type/XML entity)"
    },
    {
      "symbol": "Nothing",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: excluded symbol token (keyword/CLR type/XML entity)"
    },
    {
      "symbol": "AndAlso",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: excluded symbol token (keyword/CLR type/XML entity)"
    },
    {
      "symbol": "GetType",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: excluded symbol token (keyword/CLR type/XML entity)"
    },
    {
      "symbol": "GetProperty",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: identifier used as function call"
    },
    {
      "symbol": "CStr",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: excluded symbol token (keyword/CLR type/XML entity)"
    },
    {
      "symbol": "GetValue",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: identifier used as function call"
    },
    {
      "symbol": "If",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: excluded symbol token (keyword/CLR type/XML entity)"
    },
    {
      "symbol": "IsNot",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: excluded symbol token (keyword/CLR type/XML entity)"
    },
    {
      "symbol": "Nothing",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: excluded symbol token (keyword/CLR type/XML entity)"
    },
    {
      "symbol": "AndAlso",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: excluded symbol token (keyword/CLR type/XML entity)"
    },
    {
      "symbol": "GetType",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: excluded symbol token (keyword/CLR type/XML entity)"
    },
    {
      "symbol": "GetProperty",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: identifier used as function call"
    },
    {
      "symbol": "CStr",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: excluded symbol token (keyword/CLR type/XML entity)"
    },
    {
      "symbol": "GetValue",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: identifier used as function call"
    },
    {
      "symbol": "If",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: excluded symbol token (keyword/CLR type/XML entity)"
    },
    {
      "symbol": "IsNot",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: excluded symbol token (keyword/CLR type/XML entity)"
    },
    {
      "symbol": "Nothing",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: excluded symbol token (keyword/CLR type/XML entity)"
    },
    {
      "symbol": "AndAlso",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: excluded symbol token (keyword/CLR type/XML entity)"
    },
    {
      "symbol": "GetType",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: excluded symbol token (keyword/CLR type/XML entity)"
    },
    {
      "symbol": "GetProperty",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: identifier used as function call"
    },
    {
      "symbol": "CStr",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: excluded symbol token (keyword/CLR type/XML entity)"
    },
    {
      "symbol": "GetValue",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: identifier used as function call"
    },
    {
      "symbol": "ToString",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: identifier used as function call"
    },
    {
      "symbol": "String",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: excluded symbol token (keyword/CLR type/XML entity)"
    },
    {
      "symbol": "IsNullOrWhiteSpace",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: identifier used as function call"
    },
    {
      "symbol": "OrElse",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: excluded symbol token (keyword/CLR type/XML entity)"
    },
    {
      "symbol": "True",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: excluded symbol token (keyword/CLR type/XML entity)"
    },
    {
      "symbol": "System",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: excluded symbol token (keyword/CLR type/XML entity)"
    },
    {
      "symbol": "Text",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: excluded symbol token (keyword/CLR type/XML entity)"
    },
    {
      "symbol": "RegularExpressions",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: PascalCase identifier followed by dot (member access)"
    },
    {
      "symbol": "Regex",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: excluded symbol token (keyword/CLR type/XML entity)"
    },
    {
      "symbol": "Replace",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: excluded symbol token (keyword/CLR type/XML entity)"
    },
    {
      "symbol": "Trim",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: excluded symbol token (keyword/CLR type/XML entity)"
    },
    {
      "symbol": "If",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: excluded symbol token (keyword/CLR type/XML entity)"
    },
    {
      "symbol": "DateTime",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: excluded symbol token (keyword/CLR type/XML entity)"
    },
    {
      "symbol": "TryParse",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: identifier used as function call"
    },
    {
      "symbol": "Nothing",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: excluded symbol token (keyword/CLR type/XML entity)"
    },
    {
      "symbol": "System",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: excluded symbol token (keyword/CLR type/XML entity)"
    },
    {
      "symbol": "Globalization",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: excluded symbol token (keyword/CLR type/XML entity)"
    },
    {
      "symbol": "DateTimeStyles",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: PascalCase identifier followed by dot (member access)"
    },
    {
      "symbol": "RoundtripKind",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: identifier accessed as member"
    },
    {
      "symbol": "Parse",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: identifier used as function call"
    },
    {
      "symbol": "New",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: excluded symbol token (keyword/CLR type/XML entity)"
    },
    {
      "symbol": "Object",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: excluded symbol token (keyword/CLR type/XML entity)"
    },
    {
      "symbol": "Rows",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: PascalCase identifier followed by dot (member access)"
    },
    {
      "symbol": "Count",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: identifier accessed as member"
    },
    {
      "symbol": "Trim",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: excluded symbol token (keyword/CLR type/XML entity)"
    },
    {
      "symbol": "ToLower",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: identifier used as function call"
    },
    {
      "symbol": "Is",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: excluded symbol token (keyword/CLR type/XML entity)"
    },
    {
      "symbol": "Nothing",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: excluded symbol token (keyword/CLR type/XML entity)"
    },
    {
      "symbol": "ToString",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: identifier used as function call"
    },
    {
      "symbol": "ToLower",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: identifier used as function call"
    },
    {
      "symbol": "personal",
      "category": "variable",
      "inferredType": "unknown",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "No prefix and no expression context evidence — declaration blocked to avoid generic placeholder"
    },
    {
      "symbol": "home",
      "category": "variable",
      "inferredType": "unknown",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "No prefix and no expression context evidence — declaration blocked to avoid generic placeholder"
    },
    {
      "symbol": "Nothing",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: excluded symbol token (keyword/CLR type/XML entity)"
    },
    {
      "symbol": "Nothing",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: excluded symbol token (keyword/CLR type/XML entity)"
    },
    {
      "symbol": "Nothing",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: excluded symbol token (keyword/CLR type/XML entity)"
    },
    {
      "symbol": "String",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: excluded symbol token (keyword/CLR type/XML entity)"
    },
    {
      "symbol": "IsNullOrWhiteSpace",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: identifier used as function call"
    },
    {
      "symbol": "ToString",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: identifier used as function call"
    },
    {
      "symbol": "If",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: excluded symbol token (keyword/CLR type/XML entity)"
    },
    {
      "symbol": "IsNot",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: excluded symbol token (keyword/CLR type/XML entity)"
    },
    {
      "symbol": "Nothing",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: excluded symbol token (keyword/CLR type/XML entity)"
    },
    {
      "symbol": "DirectCast",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: excluded symbol token (keyword/CLR type/XML entity)"
    },
    {
      "symbol": "System",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: excluded symbol token (keyword/CLR type/XML entity)"
    },
    {
      "symbol": "Collections",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: excluded symbol token (keyword/CLR type/XML entity)"
    },
    {
      "symbol": "ICollection",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: identifier accessed as member"
    },
    {
      "symbol": "Count",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: identifier accessed as member"
    },
    {
      "symbol": "IsNot",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: excluded symbol token (keyword/CLR type/XML entity)"
    },
    {
      "symbol": "Nothing",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: excluded symbol token (keyword/CLR type/XML entity)"
    },
    {
      "symbol": "arr",
      "category": "variable",
      "inferredType": "Array<String>",
      "declarationEmitted": true,
      "scope": "workflow",
      "source": "discovered-reference",
      "expressionContext": {
        "activityType": "Assign",
        "propertyName": "Value",
        "expectedType": "Array<String>",
        "evidenceStrength": "strong"
      }
    },
    {
      "symbol": "If",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: excluded symbol token (keyword/CLR type/XML entity)"
    },
    {
      "symbol": "String",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: excluded symbol token (keyword/CLR type/XML entity)"
    },
    {
      "symbol": "IsNullOrWhiteSpace",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: identifier used as function call"
    },
    {
      "symbol": "New",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: excluded symbol token (keyword/CLR type/XML entity)"
    },
    {
      "symbol": "Split",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: excluded symbol token (keyword/CLR type/XML entity)"
    },
    {
      "symbol": "Environment",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: excluded symbol token (keyword/CLR type/XML entity)"
    },
    {
      "symbol": "NewLine",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: identifier accessed as member"
    },
    {
      "symbol": "StringSplitOptions",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: PascalCase identifier followed by dot (member access)"
    },
    {
      "symbol": "RemoveEmptyEntries",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: identifier accessed as member"
    },
    {
      "symbol": "Function",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: VB.NET reserved word"
    },
    {
      "symbol": "Array",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: excluded symbol token (keyword/CLR type/XML entity)"
    },
    {
      "symbol": "ConvertAll",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: identifier used as function call"
    },
    {
      "symbol": "s",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: identifier too short"
    },
    {
      "symbol": "Trim",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: excluded symbol token (keyword/CLR type/XML entity)"
    },
    {
      "symbol": "Where",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: identifier used as function call"
    },
    {
      "symbol": "Not",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: excluded symbol token (keyword/CLR type/XML entity)"
    },
    {
      "symbol": "ToArray",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: identifier used as function call"
    },
    {
      "symbol": "Environment",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: excluded symbol token (keyword/CLR type/XML entity)"
    },
    {
      "symbol": "NewLine",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: identifier accessed as member"
    },
    {
      "symbol": "If",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: excluded symbol token (keyword/CLR type/XML entity)"
    },
    {
      "symbol": "Not",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: excluded symbol token (keyword/CLR type/XML entity)"
    },
    {
      "symbol": "String",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: excluded symbol token (keyword/CLR type/XML entity)"
    },
    {
      "symbol": "IsNullOrWhiteSpace",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: identifier used as function call"
    },
    {
      "symbol": "String",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: excluded symbol token (keyword/CLR type/XML entity)"
    },
    {
      "symbol": "IsNullOrWhiteSpace",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: identifier used as function call"
    },
    {
      "symbol": "True",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: excluded symbol token (keyword/CLR type/XML entity)"
    },
    {
      "symbol": "Newtonsoft",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: excluded symbol token (keyword/CLR type/XML entity)"
    },
    {
      "symbol": "Json",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: excluded symbol token (keyword/CLR type/XML entity)"
    },
    {
      "symbol": "Linq",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: excluded symbol token (keyword/CLR type/XML entity)"
    },
    {
      "symbol": "JObject",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: excluded symbol token (keyword/CLR type/XML entity)"
    },
    {
      "symbol": "Parse",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: identifier used as function call"
    },
    {
      "symbol": "ToString",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: identifier used as function call"
    },
    {
      "symbol": "Newtonsoft",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: excluded symbol token (keyword/CLR type/XML entity)"
    },
    {
      "symbol": "Json",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: excluded symbol token (keyword/CLR type/XML entity)"
    },
    {
      "symbol": "Linq",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: excluded symbol token (keyword/CLR type/XML entity)"
    },
    {
      "symbol": "JObject",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: excluded symbol token (keyword/CLR type/XML entity)"
    },
    {
      "symbol": "Parse",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: identifier used as function call"
    },
    {
      "symbol": "ToString",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: identifier used as function call"
    },
    {
      "symbol": "Not",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: excluded symbol token (keyword/CLR type/XML entity)"
    },
    {
      "symbol": "String",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: excluded symbol token (keyword/CLR type/XML entity)"
    },
    {
      "symbol": "IsNullOrWhiteSpace",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: identifier used as function call"
    },
    {
      "symbol": "AndAlso",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: excluded symbol token (keyword/CLR type/XML entity)"
    },
    {
      "symbol": "True",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: excluded symbol token (keyword/CLR type/XML entity)"
    },
    {
      "symbol": "ToLowerInvariant",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: identifier used as function call"
    },
    {
      "symbol": "Contains",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: identifier used as function call"
    },
    {
      "symbol": "False",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: excluded symbol token (keyword/CLR type/XML entity)"
    },
    {
      "symbol": "Split",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: excluded symbol token (keyword/CLR type/XML entity)"
    },
    {
      "symbol": "New",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: excluded symbol token (keyword/CLR type/XML entity)"
    },
    {
      "symbol": "Char",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: excluded symbol token (keyword/CLR type/XML entity)"
    },
    {
      "symbol": "c",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: identifier too short"
    },
    {
      "symbol": "Environment",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: excluded symbol token (keyword/CLR type/XML entity)"
    },
    {
      "symbol": "NewLine",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: identifier used as function call"
    },
    {
      "symbol": "StringSplitOptions",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: PascalCase identifier followed by dot (member access)"
    },
    {
      "symbol": "RemoveEmptyEntries",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: identifier accessed as member"
    },
    {
      "symbol": "Length",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: identifier accessed as member"
    },
    {
      "symbol": "OrElse",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: excluded symbol token (keyword/CLR type/XML entity)"
    },
    {
      "symbol": "True",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: excluded symbol token (keyword/CLR type/XML entity)"
    },
    {
      "symbol": "AndAlso",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: excluded symbol token (keyword/CLR type/XML entity)"
    },
    {
      "symbol": "Not",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: excluded symbol token (keyword/CLR type/XML entity)"
    },
    {
      "symbol": "String",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: excluded symbol token (keyword/CLR type/XML entity)"
    },
    {
      "symbol": "IsNullOrWhiteSpace",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: identifier used as function call"
    },
    {
      "symbol": "ToLowerInvariant",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: identifier used as function call"
    },
    {
      "symbol": "Contains",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: identifier used as function call"
    },
    {
      "symbol": "Newtonsoft",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: excluded symbol token (keyword/CLR type/XML entity)"
    },
    {
      "symbol": "Json",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: excluded symbol token (keyword/CLR type/XML entity)"
    },
    {
      "symbol": "JsonConvert",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: excluded symbol token (keyword/CLR type/XML entity)"
    },
    {
      "symbol": "SerializeObject",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: identifier used as function call"
    },
    {
      "symbol": "New",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: excluded symbol token (keyword/CLR type/XML entity)"
    },
    {
      "symbol": "With",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: excluded symbol token (keyword/CLR type/XML entity)"
    },
    {
      "symbol": "RunId",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: identifier accessed as member"
    },
    {
      "symbol": "FullName",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: identifier accessed as member"
    },
    {
      "symbol": "Subject",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: identifier accessed as member"
    },
    {
      "symbol": "Body",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: identifier accessed as member"
    },
    {
      "symbol": "ValidationPassed",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: identifier accessed as member"
    },
    {
      "symbol": "ValidationReason",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: identifier accessed as member"
    },
    {
      "symbol": "If",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: excluded symbol token (keyword/CLR type/XML entity)"
    },
    {
      "symbol": "WordCount",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: identifier accessed as member"
    },
    {
      "symbol": "BannedPhraseFound",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: identifier accessed as member"
    },
    {
      "symbol": "VoiceProfileLoaded",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: identifier accessed as member"
    },
    {
      "symbol": "GeneratedAt",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: identifier accessed as member"
    },
    {
      "symbol": "DateTime",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: excluded symbol token (keyword/CLR type/XML entity)"
    },
    {
      "symbol": "UtcNow",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: PascalCase identifier followed by dot (member access)"
    },
    {
      "symbol": "ToString",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: identifier used as function call"
    },
    {
      "symbol": "System",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: excluded symbol token (keyword/CLR type/XML entity)"
    },
    {
      "symbol": "Text",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: excluded symbol token (keyword/CLR type/XML entity)"
    },
    {
      "symbol": "RegularExpressions",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: PascalCase identifier followed by dot (member access)"
    },
    {
      "symbol": "Regex",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: excluded symbol token (keyword/CLR type/XML entity)"
    },
    {
      "symbol": "Replace",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: excluded symbol token (keyword/CLR type/XML entity)"
    },
    {
      "symbol": "Boolean",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: excluded symbol token (keyword/CLR type/XML entity)"
    },
    {
      "symbol": "Parse",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: identifier used as function call"
    },
    {
      "symbol": "If",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: excluded symbol token (keyword/CLR type/XML entity)"
    },
    {
      "symbol": "String",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: excluded symbol token (keyword/CLR type/XML entity)"
    },
    {
      "symbol": "IsNullOrWhiteSpace",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: identifier used as function call"
    },
    {
      "symbol": "True",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: excluded symbol token (keyword/CLR type/XML entity)"
    },
    {
      "symbol": "String",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: excluded symbol token (keyword/CLR type/XML entity)"
    },
    {
      "symbol": "IsNullOrWhiteSpace",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: identifier used as function call"
    },
    {
      "symbol": "OrElse",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: excluded symbol token (keyword/CLR type/XML entity)"
    },
    {
      "symbol": "New",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: excluded symbol token (keyword/CLR type/XML entity)"
    },
    {
      "symbol": "System",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: excluded symbol token (keyword/CLR type/XML entity)"
    },
    {
      "symbol": "ArgumentException",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: identifier used as function call"
    },
    {
      "symbol": "System",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: excluded symbol token (keyword/CLR type/XML entity)"
    },
    {
      "symbol": "IO",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: excluded symbol token (keyword/CLR type/XML entity)"
    },
    {
      "symbol": "Path",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: excluded symbol token (keyword/CLR type/XML entity)"
    },
    {
      "symbol": "Combine",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: identifier used as function call"
    },
    {
      "symbol": "GetTempPath",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: identifier used as function call"
    },
    {
      "symbol": "DateTime",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: excluded symbol token (keyword/CLR type/XML entity)"
    },
    {
      "symbol": "UtcNow",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: PascalCase identifier followed by dot (member access)"
    },
    {
      "symbol": "ToString",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: identifier used as function call"
    },
    {
      "symbol": "GetHashCode",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: identifier used as function call"
    },
    {
      "symbol": "ToString",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: identifier used as function call"
    },
    {
      "symbol": "DateTime",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: excluded symbol token (keyword/CLR type/XML entity)"
    },
    {
      "symbol": "UtcNow",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: PascalCase identifier followed by dot (member access)"
    },
    {
      "symbol": "Trim",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: excluded symbol token (keyword/CLR type/XML entity)"
    },
    {
      "symbol": "ToLowerInvariant",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: identifier used as function call"
    },
    {
      "symbol": "True",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: excluded symbol token (keyword/CLR type/XML entity)"
    },
    {
      "symbol": "DateTime",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: excluded symbol token (keyword/CLR type/XML entity)"
    },
    {
      "symbol": "UtcNow",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: PascalCase identifier followed by dot (member access)"
    },
    {
      "symbol": "AddHours",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: identifier used as function call"
    },
    {
      "symbol": "DateTime",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: excluded symbol token (keyword/CLR type/XML entity)"
    },
    {
      "symbol": "UtcNow",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: PascalCase identifier followed by dot (member access)"
    },
    {
      "symbol": "ToString",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: identifier used as function call"
    },
    {
      "symbol": "InArgument",
      "category": "variable",
      "inferredType": "unknown",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "No prefix and no expression context evidence — declaration blocked to avoid generic placeholder",
      "expressionContext": {
        "activityType": "InvokeWorkflowFile",
        "propertyName": "Arguments",
        "expectedType": "unknown",
        "evidenceStrength": "weak"
      }
    },
    {
      "symbol": "x",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: identifier too short"
    },
    {
      "symbol": "Object",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: excluded symbol token (keyword/CLR type/XML entity)"
    },
    {
      "symbol": "vb_expression",
      "category": "variable",
      "inferredType": "unknown",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "No prefix and no expression context evidence — declaration blocked to avoid generic placeholder",
      "expressionContext": {
        "activityType": "InvokeWorkflowFile",
        "propertyName": "Arguments",
        "expectedType": "unknown",
        "evidenceStrength": "weak"
      }
    },
    {
      "symbol": "InArgument",
      "category": "variable",
      "inferredType": "unknown",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "No prefix and no expression context evidence — declaration blocked to avoid generic placeholder",
      "expressionContext": {
        "activityType": "InvokeWorkflowFile",
        "propertyName": "Arguments",
        "expectedType": "unknown",
        "evidenceStrength": "weak"
      }
    },
    {
      "symbol": "x",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: identifier too short"
    },
    {
      "symbol": "Object",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: excluded symbol token (keyword/CLR type/XML entity)"
    },
    {
      "symbol": "From",
      "category": "variable",
      "inferredType": "unknown",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "No prefix and no expression context evidence — declaration blocked to avoid generic placeholder",
      "expressionContext": {
        "activityType": "InvokeWorkflowFile",
        "propertyName": "Arguments",
        "expectedType": "unknown",
        "evidenceStrength": "weak"
      }
    },
    {
      "symbol": "New",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: excluded symbol token (keyword/CLR type/XML entity)"
    },
    {
      "symbol": "Dictionary",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: excluded symbol token (keyword/CLR type/XML entity)"
    },
    {
      "symbol": "Of",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: excluded symbol token (keyword/CLR type/XML entity)"
    },
    {
      "symbol": "String",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: excluded symbol token (keyword/CLR type/XML entity)"
    },
    {
      "symbol": "Object",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: excluded symbol token (keyword/CLR type/XML entity)"
    },
    {
      "symbol": "Nothing",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: excluded symbol token (keyword/CLR type/XML entity)"
    },
    {
      "symbol": "False",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: excluded symbol token (keyword/CLR type/XML entity)"
    },
    {
      "symbol": "Guid",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: excluded symbol token (keyword/CLR type/XML entity)"
    },
    {
      "symbol": "NewGuid",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: identifier used as function call"
    },
    {
      "symbol": "ToString",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: identifier used as function call"
    },
    {
      "symbol": "Substring",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: identifier used as function call"
    },
    {
      "symbol": "ToUpper",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: identifier used as function call"
    },
    {
      "symbol": "TimeZoneInfo",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: excluded symbol token (keyword/CLR type/XML entity)"
    },
    {
      "symbol": "FindSystemTimeZoneById",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: identifier used as function call"
    },
    {
      "symbol": "TimeZoneInfo",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: excluded symbol token (keyword/CLR type/XML entity)"
    },
    {
      "symbol": "ConvertTimeFromUtc",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: identifier used as function call"
    },
    {
      "symbol": "DateTime",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: excluded symbol token (keyword/CLR type/XML entity)"
    },
    {
      "symbol": "UtcNow",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: identifier accessed as member"
    },
    {
      "symbol": "CType",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: excluded symbol token (keyword/CLR type/XML entity)"
    },
    {
      "symbol": "Date",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: excluded symbol token (keyword/CLR type/XML entity)"
    },
    {
      "symbol": "Year",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: excluded symbol token (keyword/CLR type/XML entity)"
    },
    {
      "symbol": "String",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: excluded symbol token (keyword/CLR type/XML entity)"
    },
    {
      "symbol": "Equals",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: identifier used as function call"
    },
    {
      "symbol": "StringComparison",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: PascalCase identifier followed by dot (member access)"
    },
    {
      "symbol": "OrdinalIgnoreCase",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: identifier accessed as member"
    },
    {
      "symbol": "InArgument",
      "category": "variable",
      "inferredType": "unknown",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "No prefix and no expression context evidence — declaration blocked to avoid generic placeholder",
      "expressionContext": {
        "activityType": "InvokeWorkflowFile",
        "propertyName": "Arguments",
        "expectedType": "unknown",
        "evidenceStrength": "weak"
      }
    },
    {
      "symbol": "x",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: identifier too short"
    },
    {
      "symbol": "Object",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: excluded symbol token (keyword/CLR type/XML entity)"
    },
    {
      "symbol": "vb_expression",
      "category": "variable",
      "inferredType": "unknown",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "No prefix and no expression context evidence — declaration blocked to avoid generic placeholder",
      "expressionContext": {
        "activityType": "InvokeWorkflowFile",
        "propertyName": "Arguments",
        "expectedType": "unknown",
        "evidenceStrength": "weak"
      }
    },
    {
      "symbol": "InArgument",
      "category": "variable",
      "inferredType": "unknown",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "No prefix and no expression context evidence — declaration blocked to avoid generic placeholder",
      "expressionContext": {
        "activityType": "InvokeWorkflowFile",
        "propertyName": "Arguments",
        "expectedType": "unknown",
        "evidenceStrength": "weak"
      }
    },
    {
      "symbol": "x",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: identifier too short"
    },
    {
      "symbol": "Object",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: excluded symbol token (keyword/CLR type/XML entity)"
    },
    {
      "symbol": "in_TodayEastern",
      "category": "argument",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "No type evidence from prefix for argument \"in_TodayEastern\""
    },
    {
      "symbol": "in_RunId",
      "category": "argument",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "No type evidence from prefix for argument \"in_RunId\""
    },
    {
      "symbol": "out_BirthdayEvents",
      "category": "argument",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "No type evidence from prefix for argument \"out_BirthdayEvents\""
    },
    {
      "symbol": "From",
      "category": "variable",
      "inferredType": "unknown",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "No prefix and no expression context evidence — declaration blocked to avoid generic placeholder",
      "expressionContext": {
        "activityType": "InvokeWorkflowFile",
        "propertyName": "Arguments",
        "expectedType": "unknown",
        "evidenceStrength": "weak"
      }
    },
    {
      "symbol": "New",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: excluded symbol token (keyword/CLR type/XML entity)"
    },
    {
      "symbol": "Dictionary",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: excluded symbol token (keyword/CLR type/XML entity)"
    },
    {
      "symbol": "Of",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: excluded symbol token (keyword/CLR type/XML entity)"
    },
    {
      "symbol": "String",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: excluded symbol token (keyword/CLR type/XML entity)"
    },
    {
      "symbol": "Object",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: excluded symbol token (keyword/CLR type/XML entity)"
    },
    {
      "symbol": "If",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: excluded symbol token (keyword/CLR type/XML entity)"
    },
    {
      "symbol": "IsNot",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: excluded symbol token (keyword/CLR type/XML entity)"
    },
    {
      "symbol": "Nothing",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: excluded symbol token (keyword/CLR type/XML entity)"
    },
    {
      "symbol": "Length",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: identifier accessed as member"
    },
    {
      "symbol": "Dim",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: excluded symbol token (keyword/CLR type/XML entity)"
    },
    {
      "symbol": "eventDict",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: identifier used as function call"
    },
    {
      "symbol": "CType",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: excluded symbol token (keyword/CLR type/XML entity)"
    },
    {
      "symbol": "Dictionary",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: excluded symbol token (keyword/CLR type/XML entity)"
    },
    {
      "symbol": "Of",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: excluded symbol token (keyword/CLR type/XML entity)"
    },
    {
      "symbol": "String",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: excluded symbol token (keyword/CLR type/XML entity)"
    },
    {
      "symbol": "Object",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: excluded symbol token (keyword/CLR type/XML entity)"
    },
    {
      "symbol": "If",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: excluded symbol token (keyword/CLR type/XML entity)"
    },
    {
      "symbol": "ContainsKey",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: identifier used as function call"
    },
    {
      "symbol": "ToString",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: identifier used as function call"
    },
    {
      "symbol": "Trim",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: excluded symbol token (keyword/CLR type/XML entity)"
    },
    {
      "symbol": "AndAlso",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: excluded symbol token (keyword/CLR type/XML entity)"
    },
    {
      "symbol": "IsNot",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: excluded symbol token (keyword/CLR type/XML entity)"
    },
    {
      "symbol": "Nothing",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: excluded symbol token (keyword/CLR type/XML entity)"
    },
    {
      "symbol": "Then",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: excluded symbol token (keyword/CLR type/XML entity)"
    },
    {
      "symbol": "DateTime",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: excluded symbol token (keyword/CLR type/XML entity)"
    },
    {
      "symbol": "End",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: excluded symbol token (keyword/CLR type/XML entity)"
    },
    {
      "symbol": "From",
      "category": "variable",
      "inferredType": "unknown",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "No prefix and no expression context evidence — declaration blocked to avoid generic placeholder",
      "expressionContext": {
        "activityType": "InvokeCode",
        "propertyName": "Arguments",
        "expectedType": "unknown",
        "evidenceStrength": "weak"
      }
    },
    {
      "symbol": "New",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: excluded symbol token (keyword/CLR type/XML entity)"
    },
    {
      "symbol": "Dictionary",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: excluded symbol token (keyword/CLR type/XML entity)"
    },
    {
      "symbol": "Of",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: excluded symbol token (keyword/CLR type/XML entity)"
    },
    {
      "symbol": "String",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: excluded symbol token (keyword/CLR type/XML entity)"
    },
    {
      "symbol": "Object",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: excluded symbol token (keyword/CLR type/XML entity)"
    },
    {
      "symbol": "System",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: excluded symbol token (keyword/CLR type/XML entity)"
    },
    {
      "symbol": "Text",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: excluded symbol token (keyword/CLR type/XML entity)"
    },
    {
      "symbol": "RegularExpressions",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: PascalCase identifier followed by dot (member access)"
    },
    {
      "symbol": "Regex",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: excluded symbol token (keyword/CLR type/XML entity)"
    },
    {
      "symbol": "Replace",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: excluded symbol token (keyword/CLR type/XML entity)"
    },
    {
      "symbol": "Trim",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: excluded symbol token (keyword/CLR type/XML entity)"
    },
    {
      "symbol": "ToLowerInvariant",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: identifier used as function call"
    },
    {
      "symbol": "InArgument",
      "category": "variable",
      "inferredType": "unknown",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "No prefix and no expression context evidence — declaration blocked to avoid generic placeholder",
      "expressionContext": {
        "activityType": "InvokeWorkflowFile",
        "propertyName": "Arguments",
        "expectedType": "unknown",
        "evidenceStrength": "weak"
      }
    },
    {
      "symbol": "x",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: identifier too short"
    },
    {
      "symbol": "Object",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: excluded symbol token (keyword/CLR type/XML entity)"
    },
    {
      "symbol": "vb_expression",
      "category": "variable",
      "inferredType": "unknown",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "No prefix and no expression context evidence — declaration blocked to avoid generic placeholder",
      "expressionContext": {
        "activityType": "InvokeWorkflowFile",
        "propertyName": "Arguments",
        "expectedType": "unknown",
        "evidenceStrength": "weak"
      }
    },
    {
      "symbol": "InArgument",
      "category": "variable",
      "inferredType": "unknown",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "No prefix and no expression context evidence — declaration blocked to avoid generic placeholder",
      "expressionContext": {
        "activityType": "InvokeWorkflowFile",
        "propertyName": "Arguments",
        "expectedType": "unknown",
        "evidenceStrength": "weak"
      }
    },
    {
      "symbol": "x",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: identifier too short"
    },
    {
      "symbol": "Object",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: excluded symbol token (keyword/CLR type/XML entity)"
    },
    {
      "symbol": "in_FullName",
      "category": "argument",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "No type evidence from prefix for argument \"in_FullName\""
    },
    {
      "symbol": "in_RunId",
      "category": "argument",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "No type evidence from prefix for argument \"in_RunId\""
    },
    {
      "symbol": "in_EventId",
      "category": "argument",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "No type evidence from prefix for argument \"in_EventId\""
    },
    {
      "symbol": "out_ResolvedEmail",
      "category": "argument",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "No type evidence from prefix for argument \"out_ResolvedEmail\""
    },
    {
      "symbol": "out_IsAmbiguousMatch",
      "category": "argument",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "No type evidence from prefix for argument \"out_IsAmbiguousMatch\""
    },
    {
      "symbol": "From",
      "category": "variable",
      "inferredType": "unknown",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "No prefix and no expression context evidence — declaration blocked to avoid generic placeholder",
      "expressionContext": {
        "activityType": "InvokeWorkflowFile",
        "propertyName": "Arguments",
        "expectedType": "unknown",
        "evidenceStrength": "weak"
      }
    },
    {
      "symbol": "New",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: excluded symbol token (keyword/CLR type/XML entity)"
    },
    {
      "symbol": "Dictionary",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: excluded symbol token (keyword/CLR type/XML entity)"
    },
    {
      "symbol": "Of",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: excluded symbol token (keyword/CLR type/XML entity)"
    },
    {
      "symbol": "String",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: excluded symbol token (keyword/CLR type/XML entity)"
    },
    {
      "symbol": "Object",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: excluded symbol token (keyword/CLR type/XML entity)"
    },
    {
      "symbol": "True",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: excluded symbol token (keyword/CLR type/XML entity)"
    },
    {
      "symbol": "InArgument",
      "category": "variable",
      "inferredType": "unknown",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "No prefix and no expression context evidence — declaration blocked to avoid generic placeholder",
      "expressionContext": {
        "activityType": "InvokeWorkflowFile",
        "propertyName": "Arguments",
        "expectedType": "unknown",
        "evidenceStrength": "weak"
      }
    },
    {
      "symbol": "x",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: identifier too short"
    },
    {
      "symbol": "Object",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: excluded symbol token (keyword/CLR type/XML entity)"
    },
    {
      "symbol": "vb_expression",
      "category": "variable",
      "inferredType": "unknown",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "No prefix and no expression context evidence — declaration blocked to avoid generic placeholder",
      "expressionContext": {
        "activityType": "InvokeWorkflowFile",
        "propertyName": "Arguments",
        "expectedType": "unknown",
        "evidenceStrength": "weak"
      }
    },
    {
      "symbol": "InArgument",
      "category": "variable",
      "inferredType": "unknown",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "No prefix and no expression context evidence — declaration blocked to avoid generic placeholder",
      "expressionContext": {
        "activityType": "InvokeWorkflowFile",
        "propertyName": "Arguments",
        "expectedType": "unknown",
        "evidenceStrength": "weak"
      }
    },
    {
      "symbol": "x",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: identifier too short"
    },
    {
      "symbol": "Object",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: excluded symbol token (keyword/CLR type/XML entity)"
    },
    {
      "symbol": "in_RunId",
      "category": "argument",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "No type evidence from prefix for argument \"in_RunId\""
    },
    {
      "symbol": "in_EventId",
      "category": "argument",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "No type evidence from prefix for argument \"in_EventId\""
    },
    {
      "symbol": "in_FullName",
      "category": "argument",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "No type evidence from prefix for argument \"in_FullName\""
    },
    {
      "symbol": "in_PersonKey",
      "category": "argument",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "No type evidence from prefix for argument \"in_PersonKey\""
    },
    {
      "symbol": "in_SelectedEmail",
      "category": "argument",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "No type evidence from prefix for argument \"in_SelectedEmail\""
    },
    {
      "symbol": "in_Subject",
      "category": "argument",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "No type evidence from prefix for argument \"in_Subject\""
    },
    {
      "symbol": "in_DraftBody",
      "category": "argument",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "No type evidence from prefix for argument \"in_DraftBody\""
    },
    {
      "symbol": "in_ReviewReason",
      "category": "argument",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "No type evidence from prefix for argument \"in_ReviewReason\""
    },
    {
      "symbol": "in_SendYear",
      "category": "argument",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "No type evidence from prefix for argument \"in_SendYear\""
    },
    {
      "symbol": "in_CalendarOccurrenceStart",
      "category": "argument",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "No type evidence from prefix for argument \"in_CalendarOccurrenceStart\""
    },
    {
      "symbol": "From",
      "category": "variable",
      "inferredType": "unknown",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "No prefix and no expression context evidence — declaration blocked to avoid generic placeholder",
      "expressionContext": {
        "activityType": "InvokeWorkflowFile",
        "propertyName": "Arguments",
        "expectedType": "unknown",
        "evidenceStrength": "weak"
      }
    },
    {
      "symbol": "New",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: excluded symbol token (keyword/CLR type/XML entity)"
    },
    {
      "symbol": "Dictionary",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: excluded symbol token (keyword/CLR type/XML entity)"
    },
    {
      "symbol": "Of",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: excluded symbol token (keyword/CLR type/XML entity)"
    },
    {
      "symbol": "String",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: excluded symbol token (keyword/CLR type/XML entity)"
    },
    {
      "symbol": "Object",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: excluded symbol token (keyword/CLR type/XML entity)"
    },
    {
      "symbol": "InArgument",
      "category": "variable",
      "inferredType": "unknown",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "No prefix and no expression context evidence — declaration blocked to avoid generic placeholder",
      "expressionContext": {
        "activityType": "InvokeWorkflowFile",
        "propertyName": "Arguments",
        "expectedType": "unknown",
        "evidenceStrength": "weak"
      }
    },
    {
      "symbol": "x",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: identifier too short"
    },
    {
      "symbol": "Object",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: excluded symbol token (keyword/CLR type/XML entity)"
    },
    {
      "symbol": "vb_expression",
      "category": "variable",
      "inferredType": "unknown",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "No prefix and no expression context evidence — declaration blocked to avoid generic placeholder",
      "expressionContext": {
        "activityType": "InvokeWorkflowFile",
        "propertyName": "Arguments",
        "expectedType": "unknown",
        "evidenceStrength": "weak"
      }
    },
    {
      "symbol": "InArgument",
      "category": "variable",
      "inferredType": "unknown",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "No prefix and no expression context evidence — declaration blocked to avoid generic placeholder",
      "expressionContext": {
        "activityType": "InvokeWorkflowFile",
        "propertyName": "Arguments",
        "expectedType": "unknown",
        "evidenceStrength": "weak"
      }
    },
    {
      "symbol": "x",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: identifier too short"
    },
    {
      "symbol": "Object",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: excluded symbol token (keyword/CLR type/XML entity)"
    },
    {
      "symbol": "in_PersonName",
      "category": "argument",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "No type evidence from prefix for argument \"in_PersonName\""
    },
    {
      "symbol": "in_PersonKey",
      "category": "argument",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "No type evidence from prefix for argument \"in_PersonKey\""
    },
    {
      "symbol": "in_SelectedEmail",
      "category": "argument",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "No type evidence from prefix for argument \"in_SelectedEmail\""
    },
    {
      "symbol": "in_SendYear",
      "category": "argument",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "No type evidence from prefix for argument \"in_SendYear\""
    },
    {
      "symbol": "in_Status",
      "category": "argument",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "No type evidence from prefix for argument \"in_Status\""
    },
    {
      "symbol": "in_CalendarEventId",
      "category": "argument",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "No type evidence from prefix for argument \"in_CalendarEventId\""
    },
    {
      "symbol": "in_CalendarOccurrenceStart",
      "category": "argument",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "No type evidence from prefix for argument \"in_CalendarOccurrenceStart\""
    },
    {
      "symbol": "in_GmailMessageId",
      "category": "argument",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "No type evidence from prefix for argument \"in_GmailMessageId\""
    },
    {
      "symbol": "in_SentTimestamp",
      "category": "argument",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "No type evidence from prefix for argument \"in_SentTimestamp\""
    },
    {
      "symbol": "in_FailureReason",
      "category": "argument",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "No type evidence from prefix for argument \"in_FailureReason\""
    },
    {
      "symbol": "in_RunId",
      "category": "argument",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "No type evidence from prefix for argument \"in_RunId\""
    },
    {
      "symbol": "From",
      "category": "variable",
      "inferredType": "unknown",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "No prefix and no expression context evidence — declaration blocked to avoid generic placeholder",
      "expressionContext": {
        "activityType": "InvokeWorkflowFile",
        "propertyName": "Arguments",
        "expectedType": "unknown",
        "evidenceStrength": "weak"
      }
    },
    {
      "symbol": "New",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: excluded symbol token (keyword/CLR type/XML entity)"
    },
    {
      "symbol": "Dictionary",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: excluded symbol token (keyword/CLR type/XML entity)"
    },
    {
      "symbol": "Of",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: excluded symbol token (keyword/CLR type/XML entity)"
    },
    {
      "symbol": "String",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: excluded symbol token (keyword/CLR type/XML entity)"
    },
    {
      "symbol": "Object",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: excluded symbol token (keyword/CLR type/XML entity)"
    },
    {
      "symbol": "CType",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: excluded symbol token (keyword/CLR type/XML entity)"
    },
    {
      "symbol": "Nothing",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: excluded symbol token (keyword/CLR type/XML entity)"
    },
    {
      "symbol": "DateTime",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: excluded symbol token (keyword/CLR type/XML entity)"
    }
  ],
  "cliValidationMode": "cli_skipped_incompatible_agent",
  "cliProjectType": "Windows",
  "cliValidationSummary": "CLI Validation Mode: cli_skipped_incompatible_agent\nProject Type: Windows\nRequired CLI: UiPath.CLI.Windows\nCurrent Runner: linux\nCompatible: false\n.NET 8 Available: false\nCLI Available: false\nDuration: 0ms",
  "catalogFilterAdoption": [
    {
      "stage": "quality-gate",
      "adopted": true,
      "lookups": {
        "total": 560,
        "approved": 560,
        "deprecated": 0,
        "nonEmissionApproved": 0,
        "targetIncompatible": 0,
        "unknown": 0
      }
    },
    {
      "stage": "deterministic-validators",
      "adopted": true,
      "lookups": {
        "total": 0,
        "approved": 0,
        "deprecated": 0,
        "nonEmissionApproved": 0,
        "targetIncompatible": 0,
        "unknown": 0
      }
    },
    {
      "stage": "iterative-llm-corrector",
      "adopted": true,
      "lookups": {
        "total": 0,
        "approved": 0,
        "deprecated": 0,
        "nonEmissionApproved": 0,
        "targetIncompatible": 0,
        "unknown": 0
      }
    },
    {
      "stage": "workflow-tree-assembler",
      "adopted": true,
      "lookups": {
        "total": 109,
        "approved": 109,
        "deprecated": 0,
        "nonEmissionApproved": 0,
        "targetIncompatible": 0,
        "unknown": 0
      }
    },
    {
      "stage": "xaml-compliance",
      "adopted": true,
      "lookups": {
        "total": 192326,
        "approved": 167408,
        "deprecated": 0,
        "nonEmissionApproved": 23473,
        "targetIncompatible": 0,
        "unknown": 1445
      }
    },
    {
      "stage": "executable-path-validator",
      "adopted": true,
      "lookups": {
        "total": 428,
        "approved": 362,
        "deprecated": 0,
        "nonEmissionApproved": 0,
        "targetIncompatible": 0,
        "unknown": 66
      }
    },
    {
      "stage": "post-emission-dependency-analyzer",
      "adopted": true,
      "lookups": {
        "total": 9,
        "approved": 9,
        "deprecated": 0,
        "nonEmissionApproved": 0,
        "targetIncompatible": 0,
        "unknown": 0
      }
    }
  ]
}
```
