# Developer Handoff Guide

**Project:** BirthdayGreetingsYY
**Generated:** 2026-04-13
**Generation Mode:** Full Implementation
**Deployment Readiness:** Mostly Ready (66%)

**20 workflows: 14 fully generated, 3 with handoff blocks, 3 workflow-level stubs**
**Total Estimated Effort: ~870 minutes (14.5 hours)**
**Remediations:** 66 total (0 property, 11 activity, 0 sequence, 0 structural-leaf, 3 workflow)
**Auto-Repairs:** 19
**Quality Warnings:** 64

---

### Per-Workflow Preservation Summary

| # | Workflow | Tier | Business Steps (SDD) | Preserved | Degraded (Handoff) | Manual | Bind Points |
|---|----------|------|-------------|-----------|-------------------|--------|-------------|
| 1 | `BGYY_GetTodaysBirthdays.xaml` | Generated | 1 | 1 | 0 | 0 | 0 |
| 2 | `BGYY_ResolveRecipient.xaml` | Generated | 1 | 1 | 0 | 0 | 0 |
| 3 | `BGYY_CheckDedupe.xaml` | Generated | 1 | 1 | 0 | 0 | 0 |
| 4 | `BGYY_GenerateDraft.xaml` | Stub | 1 | 0 | 0 | 1 | 0 |
| 5 | `BGYY_ValidateDraft.xaml` | Generated | 1 | 1 | 0 | 0 | 0 |
| 6 | `BGYY_SendGmail.xaml` | Handoff | 1 | 0 | 2 | 2 | 0 |
| 7 | `BGYY_WriteSendLog.xaml` | Handoff | 1 | 0 | 2 | 2 | 0 |
| 8 | `BGYY_CreateReviewTask.xaml` | Handoff | 1 | 0 | 1 | 1 | 0 |
| 9 | `BGYY_Main.xaml` | Stub | 1 | 0 | 4 | 1 | 0 |
| 10 | `InitAllSettings.xaml` | Stub | 1 | 0 | 0 | 1 | 0 |
| 11 | `Main.xaml` | Generated | 1 | 1 | 0 | 0 | 0 |
| 12 | `GetTransactionData.xaml` | Generated | 1 | 1 | 0 | 0 | 0 |
| 13 | `SetTransactionStatus.xaml` | Generated | 1 | 1 | 0 | 0 | 0 |
| 14 | `CloseAllApplications.xaml` | Generated | 1 | 1 | 0 | 0 | 0 |
| 15 | `KillAllProcesses.xaml` | Generated | 1 | 1 | 0 | 0 | 0 |
| 16 | `Init.xaml` | Generated | 1 | 1 | 0 | 0 | 0 |
| 17 | `InitAllApplications.xaml` | Generated | 1 | 1 | 0 | 0 | 0 |
| 18 | `RetryCurrentTransaction.xaml` | Generated | 1 | 1 | 0 | 0 | 0 |
| 19 | `RetryInit.xaml` | Generated | 1 | 1 | 0 | 0 | 0 |
| 20 | `Process.xaml` | Generated | 1 | 1 | 0 | 0 | 0 |

## 1. Generated Logic (ready to use)

Generated XAML that is Studio-openable and does not contain handoff blocks or workflow-level stubs. May include auto-resolved property remediations or placeholders for fine-tuning.

The following 14 workflow(s) were fully generated and are ready to use:

| # | Workflow | Status | Studio Compatibility |
|---|----------|--------|---------------------|
| 1 | `BGYY_GetTodaysBirthdays.xaml` | Generated with Placeholders | Openable with warnings |
| 2 | `BGYY_ResolveRecipient.xaml` | Generated with Placeholders | Openable with warnings |
| 3 | `BGYY_CheckDedupe.xaml` | Generated with Remediations | Studio-openable |
| 4 | `BGYY_ValidateDraft.xaml` | Generated with Placeholders | Openable with warnings |
| 5 | `Main.xaml` | Generated with Remediations | Openable with warnings |
| 6 | `GetTransactionData.xaml` | Generated with Remediations | Studio-openable |
| 7 | `SetTransactionStatus.xaml` | Fully Generated | Studio-openable |
| 8 | `CloseAllApplications.xaml` | Fully Generated | Studio-openable |
| 9 | `KillAllProcesses.xaml` | Fully Generated | Studio-openable |
| 10 | `Init.xaml` | Generated with Remediations | Openable with warnings |
| 11 | `InitAllApplications.xaml` | Generated with Placeholders | Openable with warnings |
| 12 | `RetryCurrentTransaction.xaml` | Generated with Remediations | Studio-openable |
| 13 | `RetryInit.xaml` | Generated with Remediations | Studio-openable |
| 14 | `Process.xaml` | Fully Generated | Studio-openable |

### AI-Resolved with Smart Defaults (19)

The following issue(s) were automatically corrected during the build pipeline. **No developer action required.**

| # | Code | File | Description | Est. Minutes Saved |
|---|------|------|-------------|-------------------|
| 1 | `REPAIR_PLACEHOLDER_CLEANUP` | `BGYY_GetTodaysBirthdays.xaml` | Stripped 3 placeholder token(s) from BGYY_GetTodaysBirthdays.xaml | 5 |
| 2 | `REPAIR_PLACEHOLDER_CLEANUP` | `BGYY_ResolveRecipient.xaml` | Stripped 5 placeholder token(s) from BGYY_ResolveRecipient.xaml | 5 |
| 3 | `REPAIR_PLACEHOLDER_CLEANUP` | `BGYY_GenerateDraft.xaml` | Stripped 4 placeholder token(s) from BGYY_GenerateDraft.xaml | 5 |
| 4 | `REPAIR_PLACEHOLDER_CLEANUP` | `BGYY_ValidateDraft.xaml` | Stripped 9 placeholder token(s) from BGYY_ValidateDraft.xaml | 5 |
| 5 | `REPAIR_PLACEHOLDER_CLEANUP` | `BGYY_SendGmail.xaml` | Stripped 5 placeholder token(s) from BGYY_SendGmail.xaml | 5 |
| 6 | `REPAIR_PLACEHOLDER_CLEANUP` | `BGYY_WriteSendLog.xaml` | Stripped 2 placeholder token(s) from BGYY_WriteSendLog.xaml | 5 |
| 7 | `REPAIR_PLACEHOLDER_CLEANUP` | `BGYY_Main.xaml` | Stripped 6 placeholder token(s) from BGYY_Main.xaml | 5 |
| 8 | `REPAIR_PLACEHOLDER_CLEANUP` | `InitAllApplications.xaml` | Stripped 1 placeholder token(s) from InitAllApplications.xaml | 5 |
| 9 | `REPAIR_GENERIC` | `BGYY_Main.xaml` | Catalog (DOM): move-to-child-element ForEach.Values in BGYY_Main.xaml | undefined |
| 10 | `REPAIR_GENERIC` | `InitAllSettings.xaml` | Catalog (DOM): move-to-child-element ForEach.Values in InitAllSettings.xaml | undefined |
| 11 | `REPAIR_GENERIC` | `InitAllSettings.xaml` | Catalog (DOM): move-to-child-element ForEach.Values in InitAllSettings.xaml | undefined |
| 12 | `REPAIR_GENERIC` | `GetTransactionData.xaml` | Catalog (DOM): move-to-child-element ui:GetTransactionItem.QueueName in GetTransactionData.xaml | undefined |
| 13 | `REPAIR_MIXED_EXPRESSION_SYNTAX` | `BGYY_Main.xaml` | Mixed-expression: [BGYY_Main] Workflow started. Initializing run. → [BGYY_Main &amp; &quot; Workf... | undefined |
| 14 | `REPAIR_TYPE_MISMATCH` | `BGYY_GenerateDraft.xaml` | No known conversion from System.String to UiPath.Platform.ResourceHandling.IResource — review the... | undefined |
| 15 | `REPAIR_TYPE_MISMATCH` | `BGYY_SendGmail.xaml` | No known conversion from System.String to UiPath.Platform.ResourceHandling.IResource — review the... | undefined |
| 16 | `REPAIR_TYPE_MISMATCH` | `BGYY_WriteSendLog.xaml` | — | undefined |
| 17 | `REPAIR_TYPE_MISMATCH` | `Main.xaml` | No known conversion from scg:Dictionary(x:String, x:Object) to System.Collections.Generic.Diction... | undefined |
| 18 | `REPAIR_TYPE_MISMATCH` | `Main.xaml` | No known conversion from UiPath.Core.QueueItem to System.Collections.Generic.Dictionary`<System.S... | undefined |
| 19 | `REPAIR_TYPE_MISMATCH` | `Init.xaml` | No known conversion from scg:Dictionary(x:String, x:Object) to System.Collections.Generic.Diction... | undefined |

### Studio Compatibility

| # | Workflow | Compatibility | Failure Category | Blockers |
|---|----------|--------------|-----------------|----------|
| 1 | `BGYY_GetTodaysBirthdays.xaml` | Openable with warnings | Unclassified | — |
| 2 | `BGYY_ResolveRecipient.xaml` | Openable with warnings | Unclassified | — |
| 3 | `BGYY_CheckDedupe.xaml` | Studio-openable | — | — |
| 4 | `BGYY_GenerateDraft.xaml` | Openable with warnings | Unclassified | — |
| 5 | `BGYY_ValidateDraft.xaml` | Openable with warnings | Unclassified | — |
| 6 | `BGYY_SendGmail.xaml` | Openable with warnings | Unclassified | — |
| 7 | `BGYY_WriteSendLog.xaml` | Openable with warnings | Unclassified | — |
| 8 | `BGYY_CreateReviewTask.xaml` | Studio-openable | — | — |
| 9 | `BGYY_Main.xaml` | Studio-openable | — | — |
| 10 | `InitAllSettings.xaml` | Studio-openable | — | — |
| 11 | `Main.xaml` | Openable with warnings | Unclassified | — |
| 12 | `GetTransactionData.xaml` | Studio-openable | — | — |
| 13 | `SetTransactionStatus.xaml` | Studio-openable | — | — |
| 14 | `CloseAllApplications.xaml` | Studio-openable | — | — |
| 15 | `KillAllProcesses.xaml` | Studio-openable | — | — |
| 16 | `Init.xaml` | Openable with warnings | Unclassified | — |
| 17 | `InitAllApplications.xaml` | Openable with warnings | Unclassified | — |
| 18 | `RetryCurrentTransaction.xaml` | Studio-openable | — | — |
| 19 | `RetryInit.xaml` | Studio-openable | — | — |
| 20 | `Process.xaml` | Studio-openable | — | — |

**Summary:** 11 Studio-loadable, 9 with warnings, 0 not Studio-loadable

### Symbol Discovery Diagnostics

**Auto-declared:** 3 symbol(s) | **Withheld:** 347 symbol(s)

| Symbol | Category | Reason |
|--------|----------|--------|
| `Is` | variable | Withheld: excluded symbol token (keyword/CLR type/XML entity) |
| `Nothing` | variable | Withheld: excluded symbol token (keyword/CLR type/XML entity) |
| `expected` | variable | No prefix and no expression context evidence — declaration blocked to avoid generic placeholder |
| `be` | variable | No prefix and no expression context evidence — declaration blocked to avoid generic placeholder |
| `from` | variable | No prefix and no expression context evidence — declaration blocked to avoid generic placeholder |
| `the` | variable | No prefix and no expression context evidence — declaration blocked to avoid generic placeholder |
| `connector` | variable | No prefix and no expression context evidence — declaration blocked to avoid generic placeholder |
| `Attempt` | variable | No prefix and no expression context evidence — declaration blocked to avoid generic placeholder |
| `cast` | variable | No prefix and no expression context evidence — declaration blocked to avoid generic placeholder |
| `iterate` | variable | No prefix and no expression context evidence — declaration blocked to avoid generic placeholder |
| `events` | variable | No prefix and no expression context evidence — declaration blocked to avoid generic placeholder |
| `treating` | variable | No prefix and no expression context evidence — declaration blocked to avoid generic placeholder |
| `item` | variable | No prefix and no expression context evidence — declaration blocked to avoid generic placeholder |
| `wrapper` | variable | No prefix and no expression context evidence — declaration blocked to avoid generic placeholder |
| `Items` | variable | No prefix and no expression context evidence — declaration blocked to avoid generic placeholder |
| `Value` | variable | No prefix and no expression context evidence — declaration blocked to avoid generic placeholder |
| `prop` | variable | No prefix and no expression context evidence — declaration blocked to avoid generic placeholder |
| `evt` | variable | No prefix and no expression context evidence — declaration blocked to avoid generic placeholder |
| `evtType` | variable | No prefix and no expression context evidence — declaration blocked to avoid generic placeholder |
| `idProp` | variable | No prefix and no expression context evidence — declaration blocked to avoid generic placeholder |
| `summaryProp` | variable | No prefix and no expression context evidence — declaration blocked to avoid generic placeholder |
| `startProp` | variable | No prefix and no expression context evidence — declaration blocked to avoid generic placeholder |
| `eventId` | variable | No prefix and no expression context evidence — declaration blocked to avoid generic placeholder |
| `summary` | variable | No prefix and no expression context evidence — declaration blocked to avoid generic placeholder |
| `occStart` | variable | No prefix and no expression context evidence — declaration blocked to avoid generic placeholder |
| `startObj` | variable | No prefix and no expression context evidence — declaration blocked to avoid generic placeholder |
| `dateProp` | variable | No prefix and no expression context evidence — declaration blocked to avoid generic placeholder |
| `dateTimeProp` | variable | No prefix and no expression context evidence — declaration blocked to avoid generic placeholder |
| `Normalize` | variable | No prefix and no expression context evidence — declaration blocked to avoid generic placeholder |
| `FullName` | variable | No prefix and no expression context evidence — declaration blocked to avoid generic placeholder |
| `whitespace` | variable | No prefix and no expression context evidence — declaration blocked to avoid generic placeholder |
| `fullName` | variable | No prefix and no expression context evidence — declaration blocked to avoid generic placeholder |
| `is` | variable | Withheld: excluded symbol token (keyword/CLR type/XML entity) |
| `to` | variable | Withheld: excluded symbol token (keyword/CLR type/XML entity) |
| `IEnumerable` | variable | Withheld: identifier used as function call |
| `or` | variable | Withheld: excluded symbol token (keyword/CLR type/XML entity) |
| `a` | variable | Withheld: identifier too short |
| `JArray` | variable | Withheld: excluded symbol token (keyword/CLR type/XML entity) |
| `List` | variable | Withheld: excluded symbol token (keyword/CLR type/XML entity) |
| `Of` | variable | Withheld: excluded symbol token (keyword/CLR type/XML entity) |
| `Object` | variable | Withheld: excluded symbol token (keyword/CLR type/XML entity) |
| `and` | variable | Withheld: excluded symbol token (keyword/CLR type/XML entity) |
| `Dim` | variable | Withheld: excluded symbol token (keyword/CLR type/XML entity) |
| `As` | variable | Withheld: excluded symbol token (keyword/CLR type/XML entity) |
| `System` | variable | Withheld: excluded symbol token (keyword/CLR type/XML entity) |
| `Collections` | variable | Withheld: excluded symbol token (keyword/CLR type/XML entity) |
| `TryCast` | variable | Withheld: excluded symbol token (keyword/CLR type/XML entity) |
| `If` | variable | Withheld: excluded symbol token (keyword/CLR type/XML entity) |
| `Is` | variable | Withheld: excluded symbol token (keyword/CLR type/XML entity) |
| `Nothing` | variable | Withheld: excluded symbol token (keyword/CLR type/XML entity) |
| `Then` | variable | Withheld: excluded symbol token (keyword/CLR type/XML entity) |
| `Try` | variable | Withheld: excluded symbol token (keyword/CLR type/XML entity) |
| `as` | variable | Withheld: excluded symbol token (keyword/CLR type/XML entity) |
| `single` | variable | Withheld: excluded symbol token (keyword/CLR type/XML entity) |
| `with` | variable | Withheld: excluded symbol token (keyword/CLR type/XML entity) |
| `property` | variable | Withheld: VB.NET reserved word |
| `t` | variable | Withheld: identifier too short |
| `Type` | variable | Withheld: excluded symbol token (keyword/CLR type/XML entity) |
| `GetType` | variable | Withheld: excluded symbol token (keyword/CLR type/XML entity) |
| `Reflection` | variable | Withheld: PascalCase identifier followed by dot (member access) |
| `PropertyInfo` | variable | Withheld: identifier accessed as member |
| `GetProperty` | variable | Withheld: identifier used as function call |
| `IsNot` | variable | Withheld: excluded symbol token (keyword/CLR type/XML entity) |
| `GetValue` | variable | Withheld: identifier used as function call |
| `End` | variable | Withheld: excluded symbol token (keyword/CLR type/XML entity) |
| `New` | variable | Withheld: excluded symbol token (keyword/CLR type/XML entity) |
| `For` | variable | Withheld: excluded symbol token (keyword/CLR type/XML entity) |
| `Each` | variable | Withheld: excluded symbol token (keyword/CLR type/XML entity) |
| `In` | variable | Withheld: excluded symbol token (keyword/CLR type/XML entity) |
| `String` | variable | Withheld: excluded symbol token (keyword/CLR type/XML entity) |
| `CStr` | variable | Withheld: excluded symbol token (keyword/CLR type/XML entity) |
| `DateTime` | variable | Withheld: excluded symbol token (keyword/CLR type/XML entity) |
| `Today` | variable | Withheld: excluded symbol token (keyword/CLR type/XML entity) |
| `AndAlso` | variable | Withheld: excluded symbol token (keyword/CLR type/XML entity) |
| `CDate` | variable | Withheld: excluded symbol token (keyword/CLR type/XML entity) |
| `ElseIf` | variable | Withheld: excluded symbol token (keyword/CLR type/XML entity) |
| `trim` | variable | Withheld: excluded symbol token (keyword/CLR type/XML entity) |
| `Trim` | variable | Withheld: excluded symbol token (keyword/CLR type/XML entity) |
| `IsNullOrWhiteSpace` | variable | Withheld: identifier used as function call |
| `row` | variable | Withheld: identifier used as function call |
| `DataRow` | variable | Withheld: excluded symbol token (keyword/CLR type/XML entity) |
| `NewRow` | variable | Withheld: identifier used as function call |
| `Rows` | variable | Withheld: PascalCase identifier followed by dot (member access) |
| `Add` | variable | Withheld: identifier used as function call |
| `Next` | variable | Withheld: excluded symbol token (keyword/CLR type/XML entity) |
| `Count` | variable | Withheld: identifier accessed as member |
| `OutBirthdayEvents` | variable | No prefix and no expression context evidence — declaration blocked to avoid generic placeholder |
| `InFullName` | variable | Withheld: PascalCase identifier followed by dot (member access) |
| `Trim` | variable | Withheld: excluded symbol token (keyword/CLR type/XML entity) |
| `ToLower` | variable | Withheld: identifier used as function call |
| `Replace` | variable | Withheld: excluded symbol token (keyword/CLR type/XML entity) |
| `InFullName` | variable | No prefix and no expression context evidence — declaration blocked to avoid generic placeholder |
| `If` | variable | Withheld: excluded symbol token (keyword/CLR type/XML entity) |
| `IsNot` | variable | Withheld: excluded symbol token (keyword/CLR type/XML entity) |
| `Nothing` | variable | Withheld: excluded symbol token (keyword/CLR type/XML entity) |
| `Rows` | variable | Withheld: PascalCase identifier followed by dot (member access) |
| `Count` | variable | Withheld: identifier accessed as member |
| `Rows` | variable | Withheld: identifier used as function call |
| `If` | variable | Withheld: excluded symbol token (keyword/CLR type/XML entity) |
| `Columns` | variable | Withheld: PascalCase identifier followed by dot (member access) |
| `Contains` | variable | Withheld: identifier used as function call |
| `AndAlso` | variable | Withheld: excluded symbol token (keyword/CLR type/XML entity) |
| `Rows` | variable | Withheld: identifier used as function call |
| `IsNot` | variable | Withheld: excluded symbol token (keyword/CLR type/XML entity) |
| `Value` | variable | Withheld: identifier accessed as member |
| `ToString` | variable | Withheld: identifier used as function call |
| `Trim` | variable | Withheld: excluded symbol token (keyword/CLR type/XML entity) |
| `If` | variable | Withheld: excluded symbol token (keyword/CLR type/XML entity) |
| `Columns` | variable | Withheld: PascalCase identifier followed by dot (member access) |
| `Contains` | variable | Withheld: identifier used as function call |
| `AndAlso` | variable | Withheld: excluded symbol token (keyword/CLR type/XML entity) |
| `Rows` | variable | Withheld: identifier used as function call |
| `IsNot` | variable | Withheld: excluded symbol token (keyword/CLR type/XML entity) |
| `Value` | variable | Withheld: identifier accessed as member |
| `ToString` | variable | Withheld: identifier used as function call |
| `Trim` | variable | Withheld: excluded symbol token (keyword/CLR type/XML entity) |
| `in_PersonKey` | argument | No type evidence from prefix for argument "in_PersonKey" |
| `in_SendYear` | argument | No type evidence from prefix for argument "in_SendYear" |
| `in_PersonKey` | argument | No type evidence from prefix for argument "in_PersonKey" |
| `String` | variable | Withheld: excluded symbol token (keyword/CLR type/XML entity) |
| `IsNullOrWhiteSpace` | variable | Withheld: identifier used as function call |
| `in_PersonKey` | argument | No type evidence from prefix for argument "in_PersonKey" |
| `in_PersonKey` | argument | No type evidence from prefix for argument "in_PersonKey" |
| `in_SendYear` | argument | No type evidence from prefix for argument "in_SendYear" |
| `in_PersonKey` | argument | No type evidence from prefix for argument "in_PersonKey" |
| `in_SendYear` | argument | No type evidence from prefix for argument "in_SendYear" |
| `If` | variable | Withheld: excluded symbol token (keyword/CLR type/XML entity) |
| `IsNot` | variable | Withheld: excluded symbol token (keyword/CLR type/XML entity) |
| `Nothing` | variable | Withheld: excluded symbol token (keyword/CLR type/XML entity) |
| `New` | variable | Withheld: excluded symbol token (keyword/CLR type/XML entity) |
| `List` | variable | Withheld: excluded symbol token (keyword/CLR type/XML entity) |
| `Of` | variable | Withheld: excluded symbol token (keyword/CLR type/XML entity) |
| `Object` | variable | Withheld: excluded symbol token (keyword/CLR type/XML entity) |
| `If` | variable | Withheld: excluded symbol token (keyword/CLR type/XML entity) |
| `IsNot` | variable | Withheld: excluded symbol token (keyword/CLR type/XML entity) |
| `Nothing` | variable | Withheld: excluded symbol token (keyword/CLR type/XML entity) |
| `DirectCast` | variable | Withheld: excluded symbol token (keyword/CLR type/XML entity) |
| `System` | variable | Withheld: excluded symbol token (keyword/CLR type/XML entity) |
| `Collections` | variable | Withheld: excluded symbol token (keyword/CLR type/XML entity) |
| `IList` | variable | Withheld: identifier accessed as member |
| `Count` | variable | Withheld: identifier accessed as member |
| `DirectCast` | variable | Withheld: excluded symbol token (keyword/CLR type/XML entity) |
| `System` | variable | Withheld: excluded symbol token (keyword/CLR type/XML entity) |
| `Collections` | variable | Withheld: excluded symbol token (keyword/CLR type/XML entity) |
| `IList` | variable | Withheld: identifier accessed as member |
| `UiPath` | variable | Withheld: PascalCase identifier followed by dot (member access) |
| `DataService` | variable | Withheld: PascalCase identifier followed by dot (member access) |
| `ApiClient` | variable | Withheld: PascalCase identifier followed by dot (member access) |
| `Models` | variable | Withheld: PascalCase identifier followed by dot (member access) |
| `EntityRecord` | variable | Withheld: identifier accessed as member |
| `ToString` | variable | Withheld: identifier used as function call |
| `in_PersonKey` | argument | No type evidence from prefix for argument "in_PersonKey" |
| `in_SendYear` | argument | No type evidence from prefix for argument "in_SendYear" |
| `in_PersonKey` | argument | No type evidence from prefix for argument "in_PersonKey" |
| `in_SendYear` | argument | No type evidence from prefix for argument "in_SendYear" |
| `out_AlreadySent` | argument | No type evidence from prefix for argument "out_AlreadySent" |
| `out_ExistingRecordId` | argument | No type evidence from prefix for argument "out_ExistingRecordId" |
| `in_PersonKey` | argument | No type evidence from prefix for argument "in_PersonKey" |
| `in_SendYear` | argument | No type evidence from prefix for argument "in_SendYear" |
| `out_AlreadySent` | argument | No type evidence from prefix for argument "out_AlreadySent" |
| `out_ExistingRecordId` | argument | No type evidence from prefix for argument "out_ExistingRecordId" |
| `in_PersonKey` | argument | No type evidence from prefix for argument "in_PersonKey" |
| `in_SendYear` | argument | No type evidence from prefix for argument "in_SendYear" |
| `IsNot` | variable | Withheld: excluded symbol token (keyword/CLR type/XML entity) |
| `Nothing` | variable | Withheld: excluded symbol token (keyword/CLR type/XML entity) |
| `True` | variable | Withheld: excluded symbol token (keyword/CLR type/XML entity) |
| `rawJson` | variable | No prefix and no expression context evidence — declaration blocked to avoid generic placeholder |
| `cleaned` | variable | No prefix and no expression context evidence — declaration blocked to avoid generic placeholder |
| `ex` | variable | No prefix and no expression context evidence — declaration blocked to avoid generic placeholder |
| `Dim` | variable | Withheld: excluded symbol token (keyword/CLR type/XML entity) |
| `As` | variable | Withheld: excluded symbol token (keyword/CLR type/XML entity) |
| `String` | variable | Withheld: excluded symbol token (keyword/CLR type/XML entity) |
| `Trim` | variable | Withheld: excluded symbol token (keyword/CLR type/XML entity) |
| `If` | variable | Withheld: excluded symbol token (keyword/CLR type/XML entity) |
| `StartsWith` | variable | Withheld: identifier used as function call |
| `Then` | variable | Withheld: excluded symbol token (keyword/CLR type/XML entity) |
| `Substring` | variable | Withheld: identifier used as function call |
| `EndsWith` | variable | Withheld: identifier used as function call |
| `Length` | variable | Withheld: identifier accessed as member |
| `parsed` | variable | Withheld: identifier used as function call |
| `System` | variable | Withheld: excluded symbol token (keyword/CLR type/XML entity) |
| `Collections` | variable | Withheld: excluded symbol token (keyword/CLR type/XML entity) |
| `Generic` | variable | Withheld: excluded symbol token (keyword/CLR type/XML entity) |
| `Dictionary` | variable | Withheld: excluded symbol token (keyword/CLR type/XML entity) |
| `Of` | variable | Withheld: excluded symbol token (keyword/CLR type/XML entity) |
| `Object` | variable | Withheld: excluded symbol token (keyword/CLR type/XML entity) |
| `Try` | variable | Withheld: excluded symbol token (keyword/CLR type/XML entity) |
| `Newtonsoft` | variable | Withheld: excluded symbol token (keyword/CLR type/XML entity) |
| `Json` | variable | Withheld: excluded symbol token (keyword/CLR type/XML entity) |
| `JsonConvert` | variable | Withheld: excluded symbol token (keyword/CLR type/XML entity) |
| `DeserializeObject` | variable | Withheld: identifier used as function call |
| `ContainsKey` | variable | Withheld: identifier used as function call |
| `AndAlso` | variable | Withheld: excluded symbol token (keyword/CLR type/XML entity) |
| `ToString` | variable | Withheld: identifier used as function call |
| `True` | variable | Withheld: excluded symbol token (keyword/CLR type/XML entity) |
| `Else` | variable | Withheld: excluded symbol token (keyword/CLR type/XML entity) |
| `False` | variable | Withheld: excluded symbol token (keyword/CLR type/XML entity) |
| `End` | variable | Withheld: excluded symbol token (keyword/CLR type/XML entity) |
| `Catch` | variable | Withheld: excluded symbol token (keyword/CLR type/XML entity) |
| `Exception` | variable | Withheld: excluded symbol token (keyword/CLR type/XML entity) |
| `From` | variable | No prefix and no expression context evidence — declaration blocked to avoid generic placeholder |
| `New` | variable | Withheld: excluded symbol token (keyword/CLR type/XML entity) |
| `Dictionary` | variable | Withheld: excluded symbol token (keyword/CLR type/XML entity) |
| `Of` | variable | Withheld: excluded symbol token (keyword/CLR type/XML entity) |
| `String` | variable | Withheld: excluded symbol token (keyword/CLR type/XML entity) |
| `Object` | variable | Withheld: excluded symbol token (keyword/CLR type/XML entity) |
| `False` | variable | Withheld: excluded symbol token (keyword/CLR type/XML entity) |
| `InFullName` | variable | No prefix and no expression context evidence — declaration blocked to avoid generic placeholder |
| `InSubject` | variable | No prefix and no expression context evidence — declaration blocked to avoid generic placeholder |
| `InBody` | variable | No prefix and no expression context evidence — declaration blocked to avoid generic placeholder |
| `String` | variable | Withheld: excluded symbol token (keyword/CLR type/XML entity) |
| `IsNullOrWhiteSpace` | variable | Withheld: identifier used as function call |
| `OrElse` | variable | Withheld: excluded symbol token (keyword/CLR type/XML entity) |
| `Contains` | variable | Withheld: identifier used as function call |
| `Contains` | variable | Withheld: identifier used as function call |
| `False` | variable | Withheld: excluded symbol token (keyword/CLR type/XML entity) |
| `False` | variable | Withheld: excluded symbol token (keyword/CLR type/XML entity) |
| `InBody` | variable | No prefix and no expression context evidence — declaration blocked to avoid generic placeholder |
| `InSubject` | variable | No prefix and no expression context evidence — declaration blocked to avoid generic placeholder |
| `True` | variable | Withheld: excluded symbol token (keyword/CLR type/XML entity) |
| `True` | variable | Withheld: excluded symbol token (keyword/CLR type/XML entity) |
| `InBody` | variable | Withheld: PascalCase identifier followed by dot (member access) |
| `Trim` | variable | Withheld: excluded symbol token (keyword/CLR type/XML entity) |
| `Split` | variable | Withheld: excluded symbol token (keyword/CLR type/XML entity) |
| `New` | variable | Withheld: excluded symbol token (keyword/CLR type/XML entity) |
| `Char` | variable | Withheld: excluded symbol token (keyword/CLR type/XML entity) |
| `c` | variable | Withheld: identifier too short |
| `Chr` | variable | Withheld: excluded symbol token (keyword/CLR type/XML entity) |
| `StringSplitOptions` | variable | Withheld: PascalCase identifier followed by dot (member access) |
| `RemoveEmptyEntries` | variable | Withheld: identifier accessed as member |
| `Length` | variable | Withheld: identifier accessed as member |
| `True` | variable | Withheld: excluded symbol token (keyword/CLR type/XML entity) |
| `Split` | variable | Withheld: excluded symbol token (keyword/CLR type/XML entity) |
| `New` | variable | Withheld: excluded symbol token (keyword/CLR type/XML entity) |
| `Char` | variable | Withheld: excluded symbol token (keyword/CLR type/XML entity) |
| `Chr` | variable | Withheld: excluded symbol token (keyword/CLR type/XML entity) |
| `StringSplitOptions` | variable | Withheld: PascalCase identifier followed by dot (member access) |
| `RemoveEmptyEntries` | variable | Withheld: identifier accessed as member |
| `InDryRun` | variable | No prefix and no expression context evidence — declaration blocked to avoid generic placeholder |
| `True` | variable | Withheld: excluded symbol token (keyword/CLR type/XML entity) |
| `DateTime` | variable | Withheld: excluded symbol token (keyword/CLR type/XML entity) |
| `UtcNow` | variable | Withheld: PascalCase identifier followed by dot (member access) |
| `ToString` | variable | Withheld: identifier used as function call |
| `OutGmailMessageId` | variable | No prefix and no expression context evidence — declaration blocked to avoid generic placeholder |
| `If` | variable | Withheld: excluded symbol token (keyword/CLR type/XML entity) |
| `TimeSpan` | variable | Withheld: excluded symbol token (keyword/CLR type/XML entity) |
| `FromSeconds` | variable | Withheld: identifier used as function call |
| `Nothing` | variable | Withheld: excluded symbol token (keyword/CLR type/XML entity) |
| `DateTime` | variable | Withheld: excluded symbol token (keyword/CLR type/XML entity) |
| `UtcNow` | variable | Withheld: PascalCase identifier followed by dot (member access) |
| `ToString` | variable | Withheld: identifier used as function call |
| `OutGmailMessageId` | variable | No prefix and no expression context evidence — declaration blocked to avoid generic placeholder |
| `System` | variable | Withheld: excluded symbol token (keyword/CLR type/XML entity) |
| `IO` | variable | Withheld: excluded symbol token (keyword/CLR type/XML entity) |
| `Path` | variable | Withheld: excluded symbol token (keyword/CLR type/XML entity) |
| `Combine` | variable | Withheld: identifier used as function call |
| `GetTempPath` | variable | Withheld: identifier used as function call |
| `DateTime` | variable | Withheld: excluded symbol token (keyword/CLR type/XML entity) |
| `UtcNow` | variable | Withheld: PascalCase identifier followed by dot (member access) |
| `ToString` | variable | Withheld: identifier used as function call |
| `DateTime` | variable | Withheld: excluded symbol token (keyword/CLR type/XML entity) |
| `UtcNow` | variable | Withheld: PascalCase identifier followed by dot (member access) |
| `ToString` | variable | Withheld: identifier used as function call |
| `OutGmailMessageId` | variable | No prefix and no expression context evidence — declaration blocked to avoid generic placeholder |
| `InPersonKey` | variable | Withheld: PascalCase identifier followed by dot (member access) |
| `Trim` | variable | Withheld: excluded symbol token (keyword/CLR type/XML entity) |
| `ToLower` | variable | Withheld: identifier used as function call |
| `InSendYear` | variable | Withheld: PascalCase identifier followed by dot (member access) |
| `ToString` | variable | Withheld: identifier used as function call |
| `IsNot` | variable | Withheld: excluded symbol token (keyword/CLR type/XML entity) |
| `Nothing` | variable | Withheld: excluded symbol token (keyword/CLR type/XML entity) |
| `If` | variable | Withheld: excluded symbol token (keyword/CLR type/XML entity) |
| `IsNot` | variable | Withheld: excluded symbol token (keyword/CLR type/XML entity) |
| `Nothing` | variable | Withheld: excluded symbol token (keyword/CLR type/XML entity) |
| `CStr` | variable | Withheld: excluded symbol token (keyword/CLR type/XML entity) |
| `CallByName` | variable | Withheld: identifier used as function call |
| `CallType` | variable | Withheld: PascalCase identifier followed by dot (member access) |
| `Get` | variable | Withheld: VB.NET reserved word |
| `in_RunId` | argument | No type evidence from prefix for argument "in_RunId" |
| `in_EventId` | argument | No type evidence from prefix for argument "in_EventId" |
| `in_FullName` | argument | No type evidence from prefix for argument "in_FullName" |
| `in_FailReason` | argument | No type evidence from prefix for argument "in_FailReason" |
| `DateTime` | variable | Withheld: excluded symbol token (keyword/CLR type/XML entity) |
| `UtcNow` | variable | Withheld: PascalCase identifier followed by dot (member access) |
| `AddHours` | variable | Withheld: identifier used as function call |
| `in_FullName` | argument | No type evidence from prefix for argument "in_FullName" |
| `in_RunId` | argument | No type evidence from prefix for argument "in_RunId" |
| `If` | variable | Withheld: excluded symbol token (keyword/CLR type/XML entity) |
| `IsNot` | variable | Withheld: excluded symbol token (keyword/CLR type/XML entity) |
| `Nothing` | variable | Withheld: excluded symbol token (keyword/CLR type/XML entity) |
| `ToString` | variable | Withheld: identifier used as function call |
| `in_FullName` | argument | No type evidence from prefix for argument "in_FullName" |
| `in_RunId` | argument | No type evidence from prefix for argument "in_RunId" |
| `in_FullName` | argument | No type evidence from prefix for argument "in_FullName" |
| `in_RunId` | argument | No type evidence from prefix for argument "in_RunId" |
| `out_TaskId` | argument | No type evidence from prefix for argument "out_TaskId" |
| `out_TaskId` | argument | No type evidence from prefix for argument "out_TaskId" |
| `out_TaskId` | argument | No type evidence from prefix for argument "out_TaskId" |
| `in_FullName` | argument | No type evidence from prefix for argument "in_FullName" |
| `in_RunId` | argument | No type evidence from prefix for argument "in_RunId" |
| `System` | variable | Withheld: excluded symbol token (keyword/CLR type/XML entity) |
| `Guid` | variable | Withheld: excluded symbol token (keyword/CLR type/XML entity) |
| `NewGuid` | variable | Withheld: identifier used as function call |
| `ToString` | variable | Withheld: identifier used as function call |
| `DateTime` | variable | Withheld: excluded symbol token (keyword/CLR type/XML entity) |
| `Now` | variable | Withheld: excluded symbol token (keyword/CLR type/XML entity) |
| `Year` | variable | Withheld: excluded symbol token (keyword/CLR type/XML entity) |
| `Boolean` | variable | Withheld: excluded symbol token (keyword/CLR type/XML entity) |
| `Parse` | variable | Withheld: identifier used as function call |
| `If` | variable | Withheld: excluded symbol token (keyword/CLR type/XML entity) |
| `String` | variable | Withheld: excluded symbol token (keyword/CLR type/XML entity) |
| `IsNullOrWhiteSpace` | variable | Withheld: identifier used as function call |
| `InArgument` | variable | No prefix and no expression context evidence — declaration blocked to avoid generic placeholder |
| `x` | variable | Withheld: identifier too short |
| `Object` | variable | Withheld: excluded symbol token (keyword/CLR type/XML entity) |
| `vb_expression` | variable | No prefix and no expression context evidence — declaration blocked to avoid generic placeholder |
| `InArgument` | variable | No prefix and no expression context evidence — declaration blocked to avoid generic placeholder |
| `x` | variable | Withheld: identifier too short |
| `Object` | variable | Withheld: excluded symbol token (keyword/CLR type/XML entity) |
| `in_RunId` | argument | No type evidence from prefix for argument "in_RunId" |
| `out_BirthdayEvents` | argument | No type evidence from prefix for argument "out_BirthdayEvents" |
| `From` | variable | No prefix and no expression context evidence — declaration blocked to avoid generic placeholder |
| `New` | variable | Withheld: excluded symbol token (keyword/CLR type/XML entity) |
| `Dictionary` | variable | Withheld: excluded symbol token (keyword/CLR type/XML entity) |
| `Of` | variable | Withheld: excluded symbol token (keyword/CLR type/XML entity) |
| `String` | variable | Withheld: excluded symbol token (keyword/CLR type/XML entity) |
| `Object` | variable | Withheld: excluded symbol token (keyword/CLR type/XML entity) |
| `Nothing` | variable | Withheld: excluded symbol token (keyword/CLR type/XML entity) |
| `Is` | variable | Withheld: excluded symbol token (keyword/CLR type/XML entity) |
| `Nothing` | variable | Withheld: excluded symbol token (keyword/CLR type/XML entity) |
| `OrElse` | variable | Withheld: excluded symbol token (keyword/CLR type/XML entity) |
| `Length` | variable | Withheld: identifier accessed as member |
| `Length` | variable | Withheld: identifier accessed as member |
| `System` | variable | Withheld: excluded symbol token (keyword/CLR type/XML entity) |
| `Text` | variable | Withheld: excluded symbol token (keyword/CLR type/XML entity) |
| `RegularExpressions` | variable | Withheld: PascalCase identifier followed by dot (member access) |
| `Regex` | variable | Withheld: excluded symbol token (keyword/CLR type/XML entity) |
| `Replace` | variable | Withheld: excluded symbol token (keyword/CLR type/XML entity) |
| `ToLowerInvariant` | variable | Withheld: identifier used as function call |
| `Trim` | variable | Withheld: excluded symbol token (keyword/CLR type/XML entity) |
| `True` | variable | Withheld: excluded symbol token (keyword/CLR type/XML entity) |
| `DateTime` | variable | Withheld: excluded symbol token (keyword/CLR type/XML entity) |
| `MinValue` | variable | Withheld: identifier accessed as member |
| `False` | variable | Withheld: excluded symbol token (keyword/CLR type/XML entity) |
| `DateTime` | variable | Withheld: excluded symbol token (keyword/CLR type/XML entity) |
| `MinValue` | variable | Withheld: identifier accessed as member |
| `True` | variable | Withheld: excluded symbol token (keyword/CLR type/XML entity) |

## 2. Handoff Blocks (business logic preserved, implementation required)

Blocks where business logic is preserved as documentation but implementation requires manual Studio work. Each entry includes the workflow file, block type, business description from the SDD (when available), expected inputs/outputs, and the developer action required.

**11 handoff block(s) requiring manual implementation**

#### 1. `BGYY_SendGmail.xaml` — — (activity)

- **Workflow File:** `BGYY_SendGmail.xaml`
- **Block Type:** activity
- **Business Description (SDD):** —
- **Business Rule:** —
- **Expected Inputs:** —
- **Expected Outputs:** —
- **Contained Activities:** —
- **Remediation Code:** `DEGRADED_ACTIVITY_MISSING_PROPERTY`
- **Developer Action:** Provide the missing properties for "UiPath.GSuite.Activities.GmailSendMessage": Body
- **Estimated Effort:** 5 minutes

#### 2. `BGYY_WriteSendLog.xaml` — — (activity)

- **Workflow File:** `BGYY_WriteSendLog.xaml`
- **Block Type:** activity
- **Business Description (SDD):** —
- **Business Rule:** —
- **Expected Inputs:** —
- **Expected Outputs:** —
- **Contained Activities:** —
- **Remediation Code:** `DEGRADED_ACTIVITY_MISSING_PROPERTY`
- **Developer Action:** Provide the missing properties for "UiPath.DataService.Activities.UpdateEntity": EntityObject
- **Estimated Effort:** 5 minutes

#### 3. `BGYY_WriteSendLog.xaml` — — (activity)

- **Workflow File:** `BGYY_WriteSendLog.xaml`
- **Block Type:** activity
- **Business Description (SDD):** —
- **Business Rule:** —
- **Expected Inputs:** —
- **Expected Outputs:** —
- **Contained Activities:** —
- **Remediation Code:** `DEGRADED_ACTIVITY_MISSING_PROPERTY`
- **Developer Action:** Provide the missing properties for "UiPath.DataService.Activities.CreateEntity": EntityObject
- **Estimated Effort:** 5 minutes

#### 4. `BGYY_CreateReviewTask.xaml` — — (activity)

- **Workflow File:** `BGYY_CreateReviewTask.xaml`
- **Block Type:** activity
- **Business Description (SDD):** —
- **Business Rule:** —
- **Expected Inputs:** —
- **Expected Outputs:** —
- **Contained Activities:** —
- **Remediation Code:** `DEGRADED_ACTIVITY_MISSING_PROPERTY`
- **Developer Action:** Provide the missing properties for "UiPath.Persistence.Activities.CreateFormTask": TaskTitle
- **Estimated Effort:** 5 minutes

#### 5. `BGYY_SendGmail.xaml` — — (activity)

- **Workflow File:** `BGYY_SendGmail.xaml`
- **Block Type:** activity
- **Business Description (SDD):** —
- **Business Rule:** —
- **Expected Inputs:** —
- **Expected Outputs:** —
- **Contained Activities:** —
- **Remediation Code:** `DEGRADED_ACTIVITY_MISSING_PROPERTY`
- **Developer Action:** Provide the missing properties for mail activity "UiPath.GSuite.Activities.GmailSendMessage": Body
- **Estimated Effort:** 5 minutes

#### 6. `BGYY_Main.xaml` — — (activity)

- **Workflow File:** `BGYY_Main.xaml`
- **Block Type:** activity
- **Business Description (SDD):** —
- **Business Rule:** —
- **Expected Inputs:** —
- **Expected Outputs:** —
- **Contained Activities:** —
- **Remediation Code:** `UNDECLARED_VARIABLE_MANUAL`
- **Developer Action:** Declare variable "str_AssetValue" in BGYY_Main.xaml with the appropriate type. Expression context: Line 330: variable "str_AssetValue" is used in expression but not declared in this workflow
- **Estimated Effort:** 5 minutes

#### 7. `BGYY_Main.xaml` — — (activity)

- **Workflow File:** `BGYY_Main.xaml`
- **Block Type:** activity
- **Business Description (SDD):** —
- **Business Rule:** —
- **Expected Inputs:** —
- **Expected Outputs:** —
- **Contained Activities:** —
- **Remediation Code:** `UNDECLARED_VARIABLE_MANUAL`
- **Developer Action:** Declare variable "BGYY_Main" in BGYY_Main.xaml with the appropriate type. Expression context: BGYY_Main &amp; &quot; Workflow started. Initializing run.&q...
- **Estimated Effort:** 5 minutes

#### 8. `BGYY_Main.xaml` — — (activity)

- **Workflow File:** `BGYY_Main.xaml`
- **Block Type:** activity
- **Business Description (SDD):** —
- **Business Rule:** —
- **Expected Inputs:** —
- **Expected Outputs:** —
- **Contained Activities:** —
- **Remediation Code:** `UNDECLARED_VARIABLE_MANUAL`
- **Developer Action:** Declare variable "str_AssetValue" in BGYY_Main.xaml with the appropriate type. Expression context: str_AssetValue
- **Estimated Effort:** 5 minutes

#### 9. `BGYY_Main.xaml` — — (activity)

- **Workflow File:** `BGYY_Main.xaml`
- **Block Type:** activity
- **Business Description (SDD):** —
- **Business Rule:** —
- **Expected Inputs:** —
- **Expected Outputs:** —
- **Contained Activities:** —
- **Remediation Code:** `UNDECLARED_VARIABLE_MANUAL`
- **Developer Action:** Declare variable "vb_expression" in BGYY_Main.xaml with the appropriate type. Expression context: vb_expression
- **Estimated Effort:** 5 minutes

#### 10. `` — — (activity)

- **Workflow File:** ``
- **Block Type:** activity
- **Business Description (SDD):** —
- **Business Rule:** —
- **Expected Inputs:** —
- **Expected Outputs:** —
- **Contained Activities:** —
- **Remediation Code:** `POST_ASSEMBLY_REPAIR`
- **Developer Action:** ui:BuildDataTable.TableInfo has no valid source binding and no contract-valid fallback — structured defect, property left absent
- **Estimated Effort:** 5 minutes

#### 11. `` — — (activity)

- **Workflow File:** ``
- **Block Type:** activity
- **Business Description (SDD):** —
- **Business Rule:** —
- **Expected Inputs:** —
- **Expected Outputs:** —
- **Contained Activities:** —
- **Remediation Code:** `POST_ASSEMBLY_REPAIR`
- **Developer Action:** uexcel:ExcelApplicationScope.ExistingWorkbook has no valid source binding and no contract-valid fallback — structured defect, property left absent
- **Estimated Effort:** 5 minutes

## 3. Manual Work Remaining

Consolidated developer TODO list organized by workflow, with estimated effort per item.

**130 items remaining — ~1510 minutes (25.2 hours) total estimated effort**

### BGYY_GenerateDraft.xaml (16 items, ~200 min)

| # | Priority | Category | Description | Developer Action | Est. Minutes |
|---|----------|----------|-------------|-----------------|-------------|
| 1 | High | Workflow Stub | Entire workflow `BGYY_GenerateDraft.xaml` replaced with Studio-openable stub | Resolve malformed_attribute_quoting in BGYY_GenerateDraft.xaml | 10 |
| 2 | Low | Validation Finding | Quality gate finding: `CATALOG_STRUCTURAL_VIOLATION` | Fix property syntax for activity in BGYY_GenerateDraft.xaml — move attribute ... | 15 |
| 3 | Low | Validation Finding | Quality gate finding: `CATALOG_STRUCTURAL_VIOLATION` | Fix property syntax for activity in BGYY_GenerateDraft.xaml — move attribute ... | 15 |
| 4 | Low | Validation Finding | Quality gate finding: `CATALOG_STRUCTURAL_VIOLATION` | Fix property syntax for activity in BGYY_GenerateDraft.xaml — move attribute ... | 15 |
| 5 | Low | Validation Finding | Quality gate finding: `CATALOG_STRUCTURAL_VIOLATION` | Fix property syntax for activity in BGYY_GenerateDraft.xaml — move attribute ... | 15 |
| 6 | Low | Validation Finding | Quality gate finding: `CATALOG_STRUCTURAL_VIOLATION` | Fix property syntax for activity in BGYY_GenerateDraft.xaml — move attribute ... | 15 |
| 7 | Low | Validation Finding | Quality gate finding: `CATALOG_STRUCTURAL_VIOLATION` | Fix property syntax for activity in BGYY_GenerateDraft.xaml — move attribute ... | 15 |
| 8 | Low | Validation Finding | Quality gate finding: `CATALOG_STRUCTURAL_VIOLATION` | Fix property syntax for activity in BGYY_GenerateDraft.xaml — move attribute ... | 15 |
| 9 | Low | Validation Finding | Quality gate finding: `CATALOG_STRUCTURAL_VIOLATION` | Fix property syntax for activity in BGYY_GenerateDraft.xaml — move attribute ... | 15 |
| 10 | Low | Implementation Required | Contains 4 placeholder value(s) matching "\bTODO\b" [Developer Implementation... | Implement in Studio | 10 |
| 11 | Low | Implementation Required | Contains 4 placeholder value(s) matching "\bPLACEHOLDER\b" [Developer Impleme... | Implement in Studio | 10 |
| 12 | Low | Quality Warning | hardcoded-retry-count: Line 246: retry count hardcoded as 3 — consider extern... | Review and address | 10 |
| 13 | Low | Quality Warning | hardcoded-retry-interval: Line 246: retry interval hardcoded as "00:00:10" — ... | Review and address | 10 |
| 14 | Low | Quality Warning | TYPE_MISMATCH: Line 303: Type mismatch — variable "str_ErrorScreenshotPath" (... | Review and address | 10 |
| 15 | Low | Quality Warning | BARE_TOKEN_QUOTED: Auto-quoted bare token "logMessage" for ui:LogMessage.Mess... | Review and address | 10 |
| 16 | Low | Quality Warning | BARE_TOKEN_QUOTED: Auto-quoted bare token "logMessage" for ui:LogMessage.Mess... | Review and address | 10 |

### BGYY_Main.xaml (15 items, ~160 min)

| # | Priority | Category | Description | Developer Action | Est. Minutes |
|---|----------|----------|-------------|-----------------|-------------|
| 17 | High | Workflow Stub | Entire workflow `BGYY_Main.xaml` replaced with Studio-openable stub | Fix XML structure in BGYY_Main.xaml — [xml-wellformedness] XML parse error at... | 15 |
| 18 | Medium | Activity Stub | Activity "unknown" stubbed | Declare variable "str_AssetValue" in BGYY_Main.xaml with the appropriate type... | 5 |
| 19 | Medium | Activity Stub | Activity "unknown" stubbed | Declare variable "BGYY_Main" in BGYY_Main.xaml with the appropriate type. Exp... | 5 |
| 20 | Medium | Activity Stub | Activity "unknown" stubbed | Declare variable "str_AssetValue" in BGYY_Main.xaml with the appropriate type... | 5 |
| 21 | Medium | Activity Stub | Activity "unknown" stubbed | Declare variable "vb_expression" in BGYY_Main.xaml with the appropriate type.... | 5 |
| 22 | Low | Validation Finding | Quality gate finding: `UNDECLARED_VARIABLE` | Manually implement activity in BGYY_Main.xaml — estimated 15 min | 15 |
| 23 | Low | Validation Finding | Quality gate finding: `UNDECLARED_VARIABLE` | Manually implement activity in BGYY_Main.xaml — estimated 15 min | 15 |
| 24 | Low | Validation Finding | Quality gate finding: `UNDECLARED_VARIABLE` | Manually implement activity in BGYY_Main.xaml — estimated 15 min | 15 |
| 25 | Low | Validation Finding | Quality gate finding: `CATALOG_STRUCTURAL_VIOLATION` | Fix property syntax for activity in BGYY_Main.xaml — move attribute to child-... | 15 |
| 26 | Low | Validation Finding | Quality gate finding: `CATALOG_STRUCTURAL_VIOLATION` | Fix property syntax for activity in BGYY_Main.xaml — move attribute to child-... | 15 |
| 27 | Low | Implementation Required | Contains 6 placeholder value(s) matching "\bTODO\b" [Developer Implementation... | Implement in Studio | 10 |
| 28 | Low | Implementation Required | Contains 5 placeholder value(s) matching "\bPLACEHOLDER\b" [Developer Impleme... | Implement in Studio | 10 |
| 29 | Low | Quality Warning | hardcoded-asset-name: Line 324: asset name "BGYY_DryRun" is hardcoded — consi... | Review and address | 10 |
| 30 | Low | Quality Warning | EXPRESSION_SYNTAX: Line 863: C# '+' for string concatenation should be VB.NET... | Review and address | 10 |
| 31 | Low | Quality Warning | BARE_TOKEN_QUOTED: Auto-quoted bare token "BGYY_DryRun" for ui:GetAsset.Asset... | Review and address | 10 |

### InitAllSettings.xaml (9 items, ~110 min)

| # | Priority | Category | Description | Developer Action | Est. Minutes |
|---|----------|----------|-------------|-----------------|-------------|
| 32 | High | Workflow Stub | Entire workflow `InitAllSettings.xaml` replaced with Studio-openable stub | Resolve malformed_attribute_quoting in InitAllSettings.xaml | 10 |
| 33 | Low | Validation Finding | Quality gate finding: `MISSING_REQUIRED_ACTIVITY_PROPERTY` | Manually implement activity in InitAllSettings.xaml — estimated 15 min | 15 |
| 34 | Low | Validation Finding | Quality gate finding: `CATALOG_STRUCTURAL_VIOLATION` | Fix property syntax for activity in InitAllSettings.xaml — move attribute to ... | 15 |
| 35 | Low | Validation Finding | Quality gate finding: `CATALOG_STRUCTURAL_VIOLATION` | Fix property syntax for activity in InitAllSettings.xaml — move attribute to ... | 15 |
| 36 | Low | Validation Finding | Quality gate finding: `CATALOG_STRUCTURAL_VIOLATION` | Fix property syntax for activity in InitAllSettings.xaml — move attribute to ... | 15 |
| 37 | Low | Quality Warning | hardcoded-asset-name: Line 266: asset name "BGYY_DryRun" is hardcoded — consi... | Review and address | 10 |
| 38 | Low | Quality Warning | BARE_TOKEN_QUOTED: Auto-quoted bare token "Settings" for uexcel:ExcelReadRang... | Review and address | 10 |
| 39 | Low | Quality Warning | BARE_TOKEN_QUOTED: Auto-quoted bare token "Constants" for uexcel:ExcelReadRan... | Review and address | 10 |
| 40 | Low | Quality Warning | BARE_TOKEN_QUOTED: Auto-quoted bare token "BGYY_DryRun" for ui:GetAsset.Asset... | Review and address | 10 |

### BGYY_CreateReviewTask.xaml (3 items, ~35 min)

| # | Priority | Category | Description | Developer Action | Est. Minutes |
|---|----------|----------|-------------|-----------------|-------------|
| 41 | Medium | Activity Stub | Activity "unknown" stubbed | Provide the missing properties for "UiPath.Persistence.Activities.CreateFormT... | 5 |
| 42 | Low | Validation Finding | Quality gate finding: `CATALOG_STRUCTURAL_VIOLATION` | Fix property syntax for activity in BGYY_CreateReviewTask.xaml — move attribu... | 15 |
| 43 | Low | Validation Finding | Quality gate finding: `CATALOG_STRUCTURAL_VIOLATION` | Fix property syntax for activity in BGYY_CreateReviewTask.xaml — move attribu... | 15 |

### BGYY_SendGmail.xaml (15 items, ~170 min)

| # | Priority | Category | Description | Developer Action | Est. Minutes |
|---|----------|----------|-------------|-----------------|-------------|
| 44 | Medium | Activity Stub | Activity "unknown" stubbed | Provide the missing properties for "UiPath.GSuite.Activities.GmailSendMessage... | 5 |
| 45 | Medium | Activity Stub | Activity "unknown" stubbed | Provide the missing properties for mail activity "UiPath.GSuite.Activities.Gm... | 5 |
| 46 | Low | Validation Finding | Quality gate finding: `CATALOG_STRUCTURAL_VIOLATION` | Fix property syntax for activity in BGYY_SendGmail.xaml — move attribute to c... | 15 |
| 47 | Low | Validation Finding | Quality gate finding: `CATALOG_STRUCTURAL_VIOLATION` | Fix property syntax for activity in BGYY_SendGmail.xaml — move attribute to c... | 15 |
| 48 | Low | Validation Finding | Quality gate finding: `CATALOG_STRUCTURAL_VIOLATION` | Fix property syntax for activity in BGYY_SendGmail.xaml — move attribute to c... | 15 |
| 49 | Low | Validation Finding | Quality gate finding: `CATALOG_STRUCTURAL_VIOLATION` | Fix property syntax for activity in BGYY_SendGmail.xaml — move attribute to c... | 15 |
| 50 | Low | Validation Finding | Quality gate finding: `CATALOG_STRUCTURAL_VIOLATION` | Fix property syntax for activity in BGYY_SendGmail.xaml — move attribute to c... | 15 |
| 51 | Low | Validation Finding | Quality gate finding: `CATALOG_STRUCTURAL_VIOLATION` | Fix property syntax for activity in BGYY_SendGmail.xaml — move attribute to c... | 15 |
| 52 | Low | Implementation Required | Contains 5 placeholder value(s) matching "\bTODO\b" [Developer Implementation... | Implement in Studio | 10 |
| 53 | Low | Implementation Required | Contains 4 placeholder value(s) matching "\bPLACEHOLDER\b" [Developer Impleme... | Implement in Studio | 10 |
| 54 | Low | Quality Warning | hardcoded-retry-count: Line 104: retry count hardcoded as 3 — consider extern... | Review and address | 10 |
| 55 | Low | Quality Warning | hardcoded-retry-interval: Line 104: retry interval hardcoded as "00:00:05" — ... | Review and address | 10 |
| 56 | Low | Quality Warning | COMPLEX_EXPRESSION_PASSTHROUGH: Line 219: Complex expression (lambdas, LINQ, ... | Review and address | 10 |
| 57 | Low | Quality Warning | TYPE_MISMATCH: Line 237: Type mismatch — variable "str_ScreenshotPath" (Syste... | Review and address | 10 |
| 58 | Low | Quality Warning | RETRY_INTERVAL_DEFAULTED: Post-repair: RetryInterval defaulted to "00:00:05" ... | Review and address | 10 |

### BGYY_WriteSendLog.xaml (6 items, ~60 min)

| # | Priority | Category | Description | Developer Action | Est. Minutes |
|---|----------|----------|-------------|-----------------|-------------|
| 59 | Medium | Activity Stub | Activity "unknown" stubbed | Provide the missing properties for "UiPath.DataService.Activities.UpdateEntit... | 5 |
| 60 | Medium | Activity Stub | Activity "unknown" stubbed | Provide the missing properties for "UiPath.DataService.Activities.CreateEntit... | 5 |
| 61 | Low | Validation Finding | Quality gate finding: `CATALOG_STRUCTURAL_VIOLATION` | Fix property syntax for activity in BGYY_WriteSendLog.xaml — move attribute t... | 15 |
| 62 | Low | Validation Finding | Quality gate finding: `CATALOG_STRUCTURAL_VIOLATION` | Fix property syntax for activity in BGYY_WriteSendLog.xaml — move attribute t... | 15 |
| 63 | Low | Implementation Required | Contains 2 placeholder value(s) matching "\bTODO\b" [Developer Implementation... | Implement in Studio | 10 |
| 64 | Low | Implementation Required | Contains 2 placeholder value(s) matching "\bPLACEHOLDER\b" [Developer Impleme... | Implement in Studio | 10 |

### Unknown.xaml (2 items, ~10 min)

| # | Priority | Category | Description | Developer Action | Est. Minutes |
|---|----------|----------|-------------|-----------------|-------------|
| 65 | Medium | Activity Stub | Activity "unknown" stubbed | ui:BuildDataTable.TableInfo has no valid source binding and no contract-valid... | 5 |
| 66 | Medium | Activity Stub | Activity "unknown" stubbed | uexcel:ExcelApplicationScope.ExistingWorkbook has no valid source binding and... | 5 |

### BGYY_CheckDedupe.xaml (7 items, ~85 min)

| # | Priority | Category | Description | Developer Action | Est. Minutes |
|---|----------|----------|-------------|-----------------|-------------|
| 67 | Low | Validation Finding | Quality gate finding: `CATALOG_STRUCTURAL_VIOLATION` | Fix property syntax for activity in BGYY_CheckDedupe.xaml — move attribute to... | 15 |
| 68 | Low | Validation Finding | Quality gate finding: `CATALOG_STRUCTURAL_VIOLATION` | Fix property syntax for activity in BGYY_CheckDedupe.xaml — move attribute to... | 15 |
| 69 | Low | Validation Finding | Quality gate finding: `CATALOG_STRUCTURAL_VIOLATION` | Fix property syntax for activity in BGYY_CheckDedupe.xaml — move attribute to... | 15 |
| 70 | Low | Quality Warning | hardcoded-retry-count: Line 106: retry count hardcoded as 2 — consider extern... | Review and address | 10 |
| 71 | Low | Quality Warning | hardcoded-retry-interval: Line 106: retry interval hardcoded as "00:00:05" — ... | Review and address | 10 |
| 72 | Low | Quality Warning | EXPRESSION_SYNTAX: Line 88: C# 'null' should be VB.NET 'Nothing' in expressio... | Review and address | 10 |
| 73 | Low | Quality Warning | RETRY_INTERVAL_DEFAULTED: Post-repair: RetryInterval defaulted to "00:00:05" ... | Review and address | 10 |

### BGYY_GetTodaysBirthdays.xaml (14 items, ~155 min)

| # | Priority | Category | Description | Developer Action | Est. Minutes |
|---|----------|----------|-------------|-----------------|-------------|
| 74 | Low | Validation Finding | Quality gate finding: `MISSING_REQUIRED_ACTIVITY_PROPERTY` | Manually implement activity in BGYY_GetTodaysBirthdays.xaml — estimated 15 min | 15 |
| 75 | Low | Validation Finding | Quality gate finding: `CATALOG_STRUCTURAL_VIOLATION` | Fix property syntax for activity in BGYY_GetTodaysBirthdays.xaml — move attri... | 15 |
| 76 | Low | Validation Finding | Quality gate finding: `CATALOG_STRUCTURAL_VIOLATION` | Fix property syntax for activity in BGYY_GetTodaysBirthdays.xaml — move attri... | 15 |
| 77 | Low | Implementation Required | Contains 3 placeholder value(s) matching "\bTODO\b" [Developer Implementation... | Implement in Studio | 10 |
| 78 | Low | Implementation Required | Contains 3 placeholder value(s) matching "\bPLACEHOLDER\b" [Developer Impleme... | Implement in Studio | 10 |
| 79 | Low | Quality Warning | hardcoded-retry-count: Line 164: retry count hardcoded as 3 — consider extern... | Review and address | 10 |
| 80 | Low | Quality Warning | hardcoded-retry-count: Line 172: retry count hardcoded as 3 — consider extern... | Review and address | 10 |
| 81 | Low | Quality Warning | hardcoded-retry-count: Line 177: retry count hardcoded as 3 — consider extern... | Review and address | 10 |
| 82 | Low | Quality Warning | hardcoded-retry-interval: Line 164: retry interval hardcoded as "00:00:05" — ... | Review and address | 10 |
| 83 | Low | Quality Warning | hardcoded-retry-interval: Line 172: retry interval hardcoded as "00:00:05" — ... | Review and address | 10 |
| 84 | Low | Quality Warning | hardcoded-retry-interval: Line 177: retry interval hardcoded as "00:00:05" — ... | Review and address | 10 |
| 85 | Low | Quality Warning | RETRY_INTERVAL_DEFAULTED: Post-repair: RetryInterval defaulted to "00:00:05" ... | Review and address | 10 |
| 86 | Low | Quality Warning | RETRY_INTERVAL_DEFAULTED: Post-repair: RetryInterval defaulted to "00:00:05" ... | Review and address | 10 |
| 87 | Low | Quality Warning | RETRY_INTERVAL_DEFAULTED: Post-repair: RetryInterval defaulted to "00:00:05" ... | Review and address | 10 |

### BGYY_ResolveRecipient.xaml (16 items, ~170 min)

| # | Priority | Category | Description | Developer Action | Est. Minutes |
|---|----------|----------|-------------|-----------------|-------------|
| 88 | Low | Validation Finding | Quality gate finding: `CATALOG_STRUCTURAL_VIOLATION` | Fix property syntax for activity in BGYY_ResolveRecipient.xaml — move attribu... | 15 |
| 89 | Low | Validation Finding | Quality gate finding: `CATALOG_STRUCTURAL_VIOLATION` | Fix property syntax for activity in BGYY_ResolveRecipient.xaml — move attribu... | 15 |
| 90 | Low | Implementation Required | Contains 5 placeholder value(s) matching "\bTODO\b" [Developer Implementation... | Implement in Studio | 10 |
| 91 | Low | Implementation Required | Contains 5 placeholder value(s) matching "\bPLACEHOLDER\b" [Developer Impleme... | Implement in Studio | 10 |
| 92 | Low | Quality Warning | unguarded-array-index: Line 158: array indexing ".Rows(N)" without a precedin... | Review and address | 10 |
| 93 | Low | Quality Warning | unguarded-array-index: Line 204: array indexing ".Rows(N)" without a precedin... | Review and address | 10 |
| 94 | Low | Quality Warning | unguarded-array-index: Line 249: array indexing ".Rows(N)" without a precedin... | Review and address | 10 |
| 95 | Low | Quality Warning | hardcoded-retry-count: Line 97: retry count hardcoded as 3 — consider externa... | Review and address | 10 |
| 96 | Low | Quality Warning | hardcoded-retry-count: Line 105: retry count hardcoded as 3 — consider extern... | Review and address | 10 |
| 97 | Low | Quality Warning | hardcoded-retry-count: Line 110: retry count hardcoded as 3 — consider extern... | Review and address | 10 |
| 98 | Low | Quality Warning | hardcoded-retry-interval: Line 97: retry interval hardcoded as "00:00:05" — c... | Review and address | 10 |
| 99 | Low | Quality Warning | hardcoded-retry-interval: Line 105: retry interval hardcoded as "00:00:05" — ... | Review and address | 10 |
| 100 | Low | Quality Warning | hardcoded-retry-interval: Line 110: retry interval hardcoded as "00:00:05" — ... | Review and address | 10 |
| 101 | Low | Quality Warning | RETRY_INTERVAL_DEFAULTED: Post-repair: RetryInterval defaulted to "00:00:05" ... | Review and address | 10 |
| 102 | Low | Quality Warning | RETRY_INTERVAL_DEFAULTED: Post-repair: RetryInterval defaulted to "00:00:05" ... | Review and address | 10 |
| 103 | Low | Quality Warning | RETRY_INTERVAL_DEFAULTED: Post-repair: RetryInterval defaulted to "00:00:05" ... | Review and address | 10 |

### BGYY_ValidateDraft.xaml (8 items, ~110 min)

| # | Priority | Category | Description | Developer Action | Est. Minutes |
|---|----------|----------|-------------|-----------------|-------------|
| 104 | Low | Validation Finding | Quality gate finding: `CATALOG_STRUCTURAL_VIOLATION` | Fix property syntax for activity in BGYY_ValidateDraft.xaml — move attribute ... | 15 |
| 105 | Low | Validation Finding | Quality gate finding: `CATALOG_STRUCTURAL_VIOLATION` | Fix property syntax for activity in BGYY_ValidateDraft.xaml — move attribute ... | 15 |
| 106 | Low | Validation Finding | Quality gate finding: `CATALOG_STRUCTURAL_VIOLATION` | Fix property syntax for activity in BGYY_ValidateDraft.xaml — move attribute ... | 15 |
| 107 | Low | Validation Finding | Quality gate finding: `CATALOG_STRUCTURAL_VIOLATION` | Fix property syntax for activity in BGYY_ValidateDraft.xaml — move attribute ... | 15 |
| 108 | Low | Validation Finding | Quality gate finding: `CATALOG_STRUCTURAL_VIOLATION` | Fix property syntax for activity in BGYY_ValidateDraft.xaml — move attribute ... | 15 |
| 109 | Low | Validation Finding | Quality gate finding: `CATALOG_STRUCTURAL_VIOLATION` | Fix property syntax for activity in BGYY_ValidateDraft.xaml — move attribute ... | 15 |
| 110 | Low | Implementation Required | Contains 8 placeholder value(s) matching "\bTODO\b" [Developer Implementation... | Implement in Studio | 10 |
| 111 | Low | Implementation Required | Contains 19 placeholder value(s) matching "\bPLACEHOLDER\b" [Developer Implem... | Implement in Studio | 10 |

### GetTransactionData.xaml (2 items, ~30 min)

| # | Priority | Category | Description | Developer Action | Est. Minutes |
|---|----------|----------|-------------|-----------------|-------------|
| 112 | Low | Validation Finding | Quality gate finding: `CATALOG_STRUCTURAL_VIOLATION` | Fix property syntax for activity in GetTransactionData.xaml — move attribute ... | 15 |
| 113 | Low | Validation Finding | Quality gate finding: `CATALOG_STRUCTURAL_VIOLATION` | Fix property syntax for activity in GetTransactionData.xaml — move attribute ... | 15 |

### Init.xaml (4 items, ~55 min)

| # | Priority | Category | Description | Developer Action | Est. Minutes |
|---|----------|----------|-------------|-----------------|-------------|
| 114 | Low | Validation Finding | Quality gate finding: `CATALOG_STRUCTURAL_VIOLATION` | Fix property syntax for activity in Init.xaml — move attribute to child-eleme... | 15 |
| 115 | Low | Validation Finding | Quality gate finding: `CATALOG_STRUCTURAL_VIOLATION` | Fix property syntax for activity in Init.xaml — move attribute to child-eleme... | 15 |
| 116 | Low | Validation Finding | Quality gate finding: `CATALOG_STRUCTURAL_VIOLATION` | Fix property syntax for activity in Init.xaml — move attribute to child-eleme... | 15 |
| 117 | Low | Quality Warning | TYPE_MISMATCH: Line 68: Type mismatch — variable "dict_Config" (scg:Dictionar... | Review and address | 10 |

### InitAllApplications.xaml (2 items, ~20 min)

| # | Priority | Category | Description | Developer Action | Est. Minutes |
|---|----------|----------|-------------|-----------------|-------------|
| 118 | Low | Implementation Required | Contains 1 placeholder value(s) matching "\bTODO\b" [Developer Implementation... | Implement in Studio | 10 |
| 119 | Low | Implementation Required | Contains 1 placeholder value(s) matching "\bPLACEHOLDER\b" [Developer Impleme... | Implement in Studio | 10 |

### Main.xaml (4 items, ~50 min)

| # | Priority | Category | Description | Developer Action | Est. Minutes |
|---|----------|----------|-------------|-----------------|-------------|
| 120 | Low | Validation Finding | Quality gate finding: `CATALOG_STRUCTURAL_VIOLATION` | Fix property syntax for activity in Main.xaml — move attribute to child-eleme... | 15 |
| 121 | Low | Validation Finding | Quality gate finding: `CATALOG_STRUCTURAL_VIOLATION` | Fix property syntax for activity in Main.xaml — move attribute to child-eleme... | 15 |
| 122 | Low | Quality Warning | TYPE_MISMATCH: Line 81: Type mismatch — variable "dict_Config" (scg:Dictionar... | Review and address | 10 |
| 123 | Low | Quality Warning | TYPE_MISMATCH: Line 134: Type mismatch — variable "qi_TransactionItem" (UiPat... | Review and address | 10 |

### RetryCurrentTransaction.xaml (2 items, ~30 min)

| # | Priority | Category | Description | Developer Action | Est. Minutes |
|---|----------|----------|-------------|-----------------|-------------|
| 124 | Low | Validation Finding | Quality gate finding: `CATALOG_STRUCTURAL_VIOLATION` | Fix property syntax for activity in RetryCurrentTransaction.xaml — move attri... | 15 |
| 125 | Low | Validation Finding | Quality gate finding: `CATALOG_STRUCTURAL_VIOLATION` | Fix property syntax for activity in RetryCurrentTransaction.xaml — move attri... | 15 |

### RetryInit.xaml (2 items, ~30 min)

| # | Priority | Category | Description | Developer Action | Est. Minutes |
|---|----------|----------|-------------|-----------------|-------------|
| 126 | Low | Validation Finding | Quality gate finding: `CATALOG_STRUCTURAL_VIOLATION` | Fix property syntax for activity in RetryInit.xaml — move attribute to child-... | 15 |
| 127 | Low | Validation Finding | Quality gate finding: `CATALOG_STRUCTURAL_VIOLATION` | Fix property syntax for activity in RetryInit.xaml — move attribute to child-... | 15 |

### KillAllProcesses.xaml (3 items, ~30 min)

| # | Priority | Category | Description | Developer Action | Est. Minutes |
|---|----------|----------|-------------|-----------------|-------------|
| 128 | Low | Quality Warning | BARE_TOKEN_QUOTED: Auto-quoted bare token "chrome" for ui:KillProcess.Process... | Review and address | 10 |
| 129 | Low | Quality Warning | BARE_TOKEN_QUOTED: Auto-quoted bare token "iexplore" for ui:KillProcess.Proce... | Review and address | 10 |
| 130 | Low | Quality Warning | BARE_TOKEN_QUOTED: Auto-quoted bare token "EXCEL" for ui:KillProcess.ProcessN... | Review and address | 10 |

## 4. Process Context (from Pipeline)

### Idea Description

birthday message

### PDD Summary

## 1. Executive Summary
The “Birthday Greetings YY” automation will send personalized birthday greeting emails on your behalf each morning at 8:00 AM **America/New_York** time. Today, you manually check a dedicated Google Calendar named **“Birthdays”**, look up the person in Google Contacts to find an email address, draft a message in your warm/funny/sarcastic voice, and send it from Gmail—sometimes forgetting to do so. The future-state solution will run fully autonomously on unattended robots, read today’s recurring yearly birthday events from the **“Birthdays”** calendar, select the correct recipient email from Google Contacts (preferring **personal** over **home**), generate a personalized message using **UiPath native GenAI capabilities** (no OpenAI), send via the **Gmail connector (ninemush@gmail.com)**, and record a dedupe entry in **UiPath Data Service** to ensure only one email per person per year even if rerun.

## 2. Process Scope
The process scope begins with a scheduled trigger at 8:00 AM America/New_York and ends when all birthday events for that day have either been sent a greeting email or explicitly skipped due to missing email data or dedupe rules.

In scope are: reading events from the Google Calendar calendar named **“Birthdays”**; extracting the full name from each event (events may be all-day or timed); searching Google Contacts for a matching contact; selecting an email address labeled **personal** or **home** with a preference for **personal** when both exist; generating a personalized email draft in your voice; sending the message from **ninemush@gmail.com** using UiPath Integration Service’s Gmail connector; and writing a “sent this year” record to UiPath Data Service for deduplication.

Out of scope for this iteration are: using Google Drive (explicitly excluded); using photos from Google Photos (explicitly deferred to a later iteration); sending notifications through Slack/Teams/Twilio (explicitly excluded); and enriching content with rela...

### SDD Summary

## 1. Automation Architecture Overview

### 1.1 Chosen automation approach (with rationale)
**Pattern:** *Schedule-driven unattended orchestration with deterministic RPA + GenAI drafting + persistent dedupe state*.

**[AUTOMATION_TYPE: Hybrid (Deterministic RPA + UiPath native GenAI)]**

- **Why not “pure RPA”:** drafting a “warm / funny / sarcastic” message in your voice is non-deterministic and benefits from controlled GenAI generation + guardrails.
- **Why not “Agent-only”:** the process is primarily rules-based (calendar query, contact lookup, dedupe, send email). A full agent adds unpredictability and operational risk without clear benefit.
- **Why Hybrid is optimal:** RPA handles the repeatable integrations and business rules; UiPath native GenAI is invoked only for message generation and (optionally) self-checking.

### 1.2 Execution model and topology
- **Execution:** 100% **unattended** (11 unattended slots available). No human participation is required for normal flow.
- **Triggering:** **Orchestrator time trigger** daily at **08:00 America/New_York**.
- **Robot type:** background execution (no UI dependency). Prefer Integration Service activities over UI automation.

### 1.3 Platform services used (and why)
- **Orchestrator:** schedules, assets, logging, job control, alerts via failed jobs, and artifact deployment.
- **Integration Service:** for Google integrations and Gmail send using the existing connection **“ninemush@gmail.com”** (no custom HTTP).
- **Data Service:** persistent dedupe (“one email per person per year”), plus optional “voice profile” storage.
- **Storage Buckets:** store prompt templates, safe phrase lists, and run artifacts (e.g., generated drafts JSON) for audit/traceability.
- **Action Center (exceptional only):** used only if governance requires human approval for flagged drafts (content safety) or ambiguous contact match. Default is fully autonomous.
- **Test Manager:** automated regression suite to validate dedupe, email selection...

**Automation Type:** hybrid
**Rationale:** Calendar/event retrieval and Gmail sending are deterministic and best as RPA via Integration Service, while “write in my voice” message generation is judgment/linguistic and best handled by a UiPath Agent/GenAI step with guardrails.
**Feasibility Complexity:** medium
**Effort Estimate:** 1-2 weeks

## 5. Business Process Overview

### Process Steps

| # | Step | Role | System | Type | Pain Point |
|---|------|------|--------|------|------------|
| 1 | 8am Daily Trigger (America/New_York) | System | Orchestrator Triggers | start | — |
| 2 | Read Today's Events from "Birthdays" Calendar | System | Google Calendar | task | — |
| 3 | Any Birthday Events Today? | System | Google Calendar | decision | — |
| 4 | End (No Birthdays Today) | System | Orchestrator | end | — |
| 5 | For Each Birthday Event: Extract Full Name | System | Google Calendar | task | — |
| 6 | Find Contact by Full Name | System | Google Contacts | task | — |
| 7 | Personal/Home Email Available? | System | Google Contacts | decision | — |
| 8 | Skip Person (No Personal/Home Email) | System | Orchestrator | task | — |
| 9 | Select Recipient Email (Prefer Personal over Home) | System | Google Contacts | task | — |
| 10 | Dedupe Check: Already Sent This Year? | System | UiPath Data Service | decision | — |
| 11 | Skip Person (Already Sent This Year) | System | UiPath Data Service | task | — |
| 12 | Retrieve Style Context (If Available) | System | Data Service | decision | — |
| 13 | Load "Voice Profile" + Optional Examples | System | UiPath Data Service | task | — |
| 14 | Use Default Voice Prompt (Warm/Funny/Sarcastic) | System | Orchestrator Assets | task | — |
| 15 | Generate Personalized Birthday Email Draft (Your Voice) | System | UiPath Agents / GenAI Activities | agent-task | — |
| 16 | Draft Acceptable (No PII leakage/offensive content)? | System | UiPath Agents | agent-decision | — |
| 17 | Create Human Review Task (Edge Cases Only) | You | Action Center | task | — |
| 18 | Send Birthday Email via Gmail ("ninemush@gmail.com") | System | Gmail (Integration Service) | task | — |
| 19 | Write Dedupe Record (Name, Email, Year, CalendarEventId, MessageId) | System | UiPath Data Service | task | — |
| 20 | End (Run Completed) | System | Orchestrator | end | — |
| 21 | End (Some Recipients Skipped) | System | Orchestrator | end | — |
| 22 | End (Pending Human Review) | System | Action Center | end | — |

### Target Applications / Systems

The following applications were identified from the process map and must be accessible from the robot machine:

- Orchestrator Triggers
- Google Calendar
- Orchestrator
- Google Contacts
- UiPath Data Service
- Data Service
- Orchestrator Assets
- UiPath Agents / GenAI Activities
- UiPath Agents
- Action Center
- Gmail (Integration Service)

### User Roles Involved

- System
- You

### Decision Points (Process Map Topology)

**Any Birthday Events Today?**
  - [No] → End (No Birthdays Today)
  - [Yes] → For Each Birthday Event: Extract Full Name

**Personal/Home Email Available?**
  - [No] → Skip Person (No Personal/Home Email)
  - [Yes] → Select Recipient Email (Prefer Personal over Home)

**Dedupe Check: Already Sent This Year?**
  - [Yes] → Skip Person (Already Sent This Year)
  - [No] → Retrieve Style Context (If Available)

**Retrieve Style Context (If Available)**
  - [Available] → Load "Voice Profile" + Optional Examples
  - [Not Available] → Use Default Voice Prompt (Warm/Funny/Sarcastic)

## 6. Environment Setup

| Requirement | Value |
|---|---|
| Target Framework | Windows (required) |
| Robot Type | Unattended |
| Modern Activities | No |
| Studio Version | 25.10.7 |
| Orchestrator Connection | Required |
| Machine Template | Standard |
| Action Center | Required |
| Data Service | Required |

### Machine Template

**Recommended:** Standard
Standard unattended machine template

### Orchestrator Folder Structure

Create a Modern Folder with unattended robot pool (2+ robots recommended for queue-based processing). Enable Auto-scaling if available.

### NuGet Dependencies

| # | Package |
|---|--------|
| 1 | `UiPath.System.Activities` |
| 2 | `UiPath.IntegrationService.Activities` |
| 3 | `UiPath.ComplexScenarios.Activities` |
| 4 | `UiPath.WebAPI.Activities` |
| 5 | `Newtonsoft.Json` |
| 6 | `UiPath.UIAutomation.Activities` |
| 7 | `UiPath.GSuite.Activities` |
| 8 | `UiPath.DataService.Activities` |
| 9 | `UiPath.GoogleVertex.IntegrationService.Activities` |
| 10 | `UiPath.Excel.Activities` |

### Target Applications (from Process Map)

The following applications were identified from the business process map. Ensure network connectivity and access credentials are configured on the robot machine:

- Orchestrator Triggers
- Google Calendar
- Orchestrator
- Google Contacts
- UiPath Data Service
- Data Service
- Orchestrator Assets
- UiPath Agents / GenAI Activities
- UiPath Agents
- Action Center
- Gmail (Integration Service)

## 7. Credential & Asset Inventory

**Total:** 2 activities (0 hardcoded, 2 variable-driven)

### Orchestrator Assets to Provision

| # | Asset Name | Value Type | Consuming Activity | File | Action |
|---|-----------|-----------|-------------------|------|--------|
| 1 | `[BGYY_DryRun]` | Unknown | — | `InitAllSettings.xaml` | Verify exists in target environment |

### Detailed Usage Map

| File | Line | Activity | Asset/Credential | Type | Variable | Hardcoded |
|------|------|----------|-----------------|------|----------|----------|
| `InitAllSettings.xaml` | 266 | GetAsset | `[BGYY_DryRun]` | Unknown | — | No |
| `InitAllSettings.xaml` | 269 | GetAsset | `UNKNOWN` | Unknown | — | No |

## 8. SDD × XAML Artifact Reconciliation

**Summary:** 0 aligned, 1 SDD-only, 1 XAML-only

> **Warning:** 1 artifact(s) declared in the SDD were not found in the generated XAML. These must be provisioned in Orchestrator but are not referenced in code — verify the SDD spec or add the corresponding activities.

> **Warning:** 1 artifact(s) found in XAML are not declared in the SDD. Update the SDD orchestrator_artifacts block to include these, or the deployment manifest will be incomplete.

| # | Name | Type | Status | SDD Config | XAML File | XAML Line |
|---|------|------|--------|-----------|----------|----------|
| 1 | `BGYY_DryRun` | asset | **SDD Only** | type: Bool, value: , description: Mock mode. true = generate drafts and write artifacts, do not send emails. | — | — |
| 2 | `[BGYY_DryRun]` | asset | **XAML Only** | — | `InitAllSettings.xaml` | 266 |

## 9. Queue Management

**Pattern:** Transactional (Dispatcher/Performer)

### Queue Activity Summary

| Capability | Present |
|---|---|
| Add Queue Item | No |
| Get Transaction Item | Yes |
| Set Transaction Status | Yes |

### Retry Policy

Transactional pattern detected — configure Auto Retry (recommended: 3 retries) in Orchestrator Queue settings

### SLA Guidance

Configure SLA in Orchestrator: set Maximum Execution Time per transaction item and monitor Queue SLA reports. Recommended: base SLA on observed P95 processing time + 20% buffer.

### Dead-Letter / Failed Items Handling

Items exceeding max retries are marked as Failed. Review failed items in Orchestrator Queues dashboard. Consider: (1) Create a separate cleanup/reprocessing workflow for DLQ items, (2) Set up email alerts for failed transaction counts exceeding threshold, (3) Log detailed failure context in SetTransactionStatus output for troubleshooting.

> **Note:** This is a Performer process — a separate Dispatcher process is needed to populate the queue.

## 10. Exception Handling Coverage

**Coverage:** 0/7 high-risk activities inside TryCatch (0%)

### Files Without TryCatch

- `BGYY_Main.xaml`
- `InitAllSettings.xaml`
- `GetTransactionData.xaml`
- `KillAllProcesses.xaml`
- `RetryCurrentTransaction.xaml`
- `RetryInit.xaml`
- `Process.xaml`

### Uncovered High-Risk Activities

| # | Location | Activity |
|---|----------|----------|
| 1 | `InitAllSettings.xaml:266` | Get BGYY_DryRun |
| 2 | `InitAllSettings.xaml:269` | ui:GetAsset |
| 3 | `GetTransactionData.xaml:158` | Get Queue Item |
| 4 | `GetTransactionData.xaml:160` | ui:GetTransactionItem |
| 5 | `GetTransactionData.xaml:169` | ui:GetTransactionItem |
| 6 | `SetTransactionStatus.xaml:68` | Set Success |
| 7 | `SetTransactionStatus.xaml:90` | Set Failed |

> **Recommendation:** Wrap these activities in TryCatch blocks with appropriate exception types (BusinessRuleException for data errors, System.Exception for general failures).

## 11. Trigger Configuration

Based on the process analysis, the following trigger configuration is recommended:

| # | Trigger Type | Reason | Configuration |
|---|-------------|--------|---------------|
| 1 | **Schedule** | Defined in SDD orchestrator_artifacts: BGYY_Daily_0800_ET | SDD-specified: BGYY_Daily_0800_ET | Cron: 0 8 * * * | Daily time trigger to start the process at 08:00 America/New_York. |

## 12. Upstream Quality Findings

The following quality warnings were produced by upstream pipeline stages (selector scoring, type validation, expression linting, etc.) and should be addressed during development:

| Code | Severity | Count | Sample Message |
|------|----------|-------|----------------|
| placeholder-value | warning | 16 | Contains 3 placeholder value(s) matching "\bTODO\b" [Developer Implementation Required] |
| unguarded-array-index | warning | 3 | Line 158: array indexing ".Rows(N)" without a preceding row count check — may throw IndexOutOfRangeException at runtime |
| hardcoded-retry-count | warning | 9 | Line 164: retry count hardcoded as 3 — consider externalizing to Config.xlsx (e.g., in_Config("MaxRetryNumber")) |
| hardcoded-retry-interval | warning | 9 | Line 164: retry interval hardcoded as "00:00:05" — consider externalizing to Config.xlsx |
| hardcoded-asset-name | warning | 2 | Line 324: asset name "BGYY_DryRun" is hardcoded — consider using a Config.xlsx entry or workflow argument |
| EXPRESSION_SYNTAX | warning | 2 | Line 88: C# 'null' should be VB.NET 'Nothing' in expression: New ArgumentException(&quot;[BGYY_CheckDedupe] in_PersonKey... |
| COMPLEX_EXPRESSION_PASSTHROUGH | warning | 1 | Line 219: Complex expression (lambdas, LINQ, nested calls, or 3+ operators) — emitting as-is to avoid regex corruption i... |
| TYPE_MISMATCH | warning | 5 | Line 303: Type mismatch — variable "str_ErrorScreenshotPath" (System.String) bound to ucas:UploadStorageFile.FileResourc... |
| BARE_TOKEN_QUOTED | warning | 9 | Auto-quoted bare token "logMessage" for ui:LogMessage.Message (expected String type) — wrapped in VB string quotes |
| RETRY_INTERVAL_DEFAULTED | warning | 8 | Post-repair: RetryInterval defaulted to "00:00:05" — verify this is appropriate for the workflow context |

## 13. Pre-Deployment Checklist

| # | Category | Task | Required |
|---|----------|------|----------|
| 1 | Deployment | Publish package to Orchestrator feed | Yes |
| 2 | Deployment | Create Process in target folder | Yes |
| 3 | Environment | Verify Orchestrator connection from robot | Yes |
| 4 | Assets | Provision asset: `[BGYY_DryRun]` | Yes |
| 5 | Trigger | Configure trigger (schedule/queue/API) | Yes |
| 6 | Testing | Run smoke test in target environment | Yes |
| 7 | Monitoring | Verify logging output in Orchestrator | Recommended |
| 8 | Governance | UAT test execution completed and sign-off obtained | Yes |
| 9 | Governance | Peer code review completed | Yes |
| 10 | Governance | All quality gate warnings addressed or risk-accepted | Yes |
| 11 | Governance | Business process owner validation obtained | Yes |
| 12 | Governance | CoE approval obtained | Yes |
| 13 | Governance | Production readiness assessment completed (monitoring, alerting, rollback plan documented) | Yes |

## 14. Deployment Readiness Score

**Overall: Mostly Ready — 33/50 (66%)**

| Section | Score | Notes |
|---------|-------|-------|
| Credentials & Assets | 10/10 | All credentials/assets properly configured |
| Exception Handling | 2/10 | Only 0% of high-risk activities covered by TryCatch; 7 file(s) with no TryCatch blocks |
| Queue Management | 10/10 | Queue configuration looks good |
| Build Quality | 1/10 | 64 quality warnings — significant remediation needed; 66 remediations — stub replacements need developer attention |
| Environment Setup | 10/10 | Environment requirements are straightforward |

> **Almost There:** A few items need attention before production deployment.

## 15. Pre-emission Spec Validation

Validation was performed on the WorkflowSpec tree before XAML assembly. Issues caught at this stage are cheaper to fix than post-emission quality gate findings.

| Metric | Count |
|---|---|
| Total activities checked | 214 |
| Valid activities | 214 |
| Unknown → Comment stubs | 0 |
| Non-catalog properties stripped | 106 |
| Enum values auto-corrected | 0 |
| Missing required props filled | 0 |
| Total issues | 40 |

### Pre-emission vs Post-emission

| Stage | Issues Caught/Fixed |
|---|---|
| Pre-emission (spec validation) | 106 auto-fixed, 40 total issues |
| Post-emission (quality gate) | 130 warnings/remediations |

## 16. Catalog Filter Adoption Report

Shows which pipeline stages use the filtered activity catalog (deprecated, non-emission-approved, and target-incompatible activities are excluded).

| Stage | Adopted | Total Lookups | Approved | Deprecated | Non-Approved | Target-Incompatible | Unknown |
|---|---|---|---|---|---|---|---|
| quality-gate | Yes | 712 | 712 | 0 | 0 | 0 | 0 |
| deterministic-validators | Yes | 0 | 0 | 0 | 0 | 0 | 0 |
| iterative-llm-corrector | Yes | 0 | 0 | 0 | 0 | 0 | 0 |
| workflow-tree-assembler | Yes | 144 | 144 | 0 | 0 | 0 | 0 |
| xaml-compliance | Yes | 203292 | 177137 | 0 | 24645 | 0 | 1510 |
| executable-path-validator | Yes | 520 | 445 | 0 | 0 | 0 | 75 |
| post-emission-dependency-analyzer | Yes | 14 | 14 | 0 | 0 | 0 | 0 |

---

## 17. Structured Report (JSON)

The following JSON appendix contains the full pipeline outcome report for programmatic consumption:

```json
{
  "fullyGeneratedFiles": [
    "SetTransactionStatus.xaml",
    "CloseAllApplications.xaml",
    "KillAllProcesses.xaml",
    "InitAllApplications.xaml",
    "Process.xaml"
  ],
  "autoRepairs": [
    {
      "repairCode": "REPAIR_PLACEHOLDER_CLEANUP",
      "file": "BGYY_GetTodaysBirthdays.xaml",
      "description": "Stripped 3 placeholder token(s) from BGYY_GetTodaysBirthdays.xaml",
      "developerAction": "Review BGYY_GetTodaysBirthdays.xaml for Comment elements marking where placeholder activities were removed",
      "estimatedEffortMinutes": 5
    },
    {
      "repairCode": "REPAIR_PLACEHOLDER_CLEANUP",
      "file": "BGYY_ResolveRecipient.xaml",
      "description": "Stripped 5 placeholder token(s) from BGYY_ResolveRecipient.xaml",
      "developerAction": "Review BGYY_ResolveRecipient.xaml for Comment elements marking where placeholder activities were removed",
      "estimatedEffortMinutes": 5
    },
    {
      "repairCode": "REPAIR_PLACEHOLDER_CLEANUP",
      "file": "BGYY_GenerateDraft.xaml",
      "description": "Stripped 4 placeholder token(s) from BGYY_GenerateDraft.xaml",
      "developerAction": "Review BGYY_GenerateDraft.xaml for Comment elements marking where placeholder activities were removed",
      "estimatedEffortMinutes": 5
    },
    {
      "repairCode": "REPAIR_PLACEHOLDER_CLEANUP",
      "file": "BGYY_ValidateDraft.xaml",
      "description": "Stripped 9 placeholder token(s) from BGYY_ValidateDraft.xaml",
      "developerAction": "Review BGYY_ValidateDraft.xaml for Comment elements marking where placeholder activities were removed",
      "estimatedEffortMinutes": 5
    },
    {
      "repairCode": "REPAIR_PLACEHOLDER_CLEANUP",
      "file": "BGYY_SendGmail.xaml",
      "description": "Stripped 5 placeholder token(s) from BGYY_SendGmail.xaml",
      "developerAction": "Review BGYY_SendGmail.xaml for Comment elements marking where placeholder activities were removed",
      "estimatedEffortMinutes": 5
    },
    {
      "repairCode": "REPAIR_PLACEHOLDER_CLEANUP",
      "file": "BGYY_WriteSendLog.xaml",
      "description": "Stripped 2 placeholder token(s) from BGYY_WriteSendLog.xaml",
      "developerAction": "Review BGYY_WriteSendLog.xaml for Comment elements marking where placeholder activities were removed",
      "estimatedEffortMinutes": 5
    },
    {
      "repairCode": "REPAIR_PLACEHOLDER_CLEANUP",
      "file": "BGYY_Main.xaml",
      "description": "Stripped 6 placeholder token(s) from BGYY_Main.xaml",
      "developerAction": "Review BGYY_Main.xaml for Comment elements marking where placeholder activities were removed",
      "estimatedEffortMinutes": 5
    },
    {
      "repairCode": "REPAIR_PLACEHOLDER_CLEANUP",
      "file": "InitAllApplications.xaml",
      "description": "Stripped 1 placeholder token(s) from InitAllApplications.xaml",
      "developerAction": "Review InitAllApplications.xaml for Comment elements marking where placeholder activities were removed",
      "estimatedEffortMinutes": 5
    },
    {
      "repairCode": "REPAIR_GENERIC",
      "file": "BGYY_Main.xaml",
      "description": "Catalog (DOM): move-to-child-element ForEach.Values in BGYY_Main.xaml"
    },
    {
      "repairCode": "REPAIR_GENERIC",
      "file": "InitAllSettings.xaml",
      "description": "Catalog (DOM): move-to-child-element ForEach.Values in InitAllSettings.xaml"
    },
    {
      "repairCode": "REPAIR_GENERIC",
      "file": "InitAllSettings.xaml",
      "description": "Catalog (DOM): move-to-child-element ForEach.Values in InitAllSettings.xaml"
    },
    {
      "repairCode": "REPAIR_GENERIC",
      "file": "GetTransactionData.xaml",
      "description": "Catalog (DOM): move-to-child-element ui:GetTransactionItem.QueueName in GetTransactionData.xaml"
    },
    {
      "repairCode": "REPAIR_MIXED_EXPRESSION_SYNTAX",
      "file": "BGYY_Main.xaml",
      "description": "Mixed-expression: [BGYY_Main] Workflow started. Initializing run. → [BGYY_Main &amp; &quot; Workflow started. Initializing run.&quot;] in BGYY_Main.xaml"
    },
    {
      "repairCode": "REPAIR_TYPE_MISMATCH",
      "file": "BGYY_GenerateDraft.xaml",
      "description": "No known conversion from System.String to UiPath.Platform.ResourceHandling.IResource — review the variable type or activity property"
    },
    {
      "repairCode": "REPAIR_TYPE_MISMATCH",
      "file": "BGYY_SendGmail.xaml",
      "description": "No known conversion from System.String to UiPath.Platform.ResourceHandling.IResource — review the variable type or activity property"
    },
    {
      "repairCode": "REPAIR_TYPE_MISMATCH",
      "file": "BGYY_WriteSendLog.xaml"
    },
    {
      "repairCode": "REPAIR_TYPE_MISMATCH",
      "file": "Main.xaml",
      "description": "No known conversion from scg:Dictionary(x:String, x:Object) to System.Collections.Generic.Dictionary`<System.String, System.Activities.Argument> — review the variable type or activity property"
    },
    {
      "repairCode": "REPAIR_TYPE_MISMATCH",
      "file": "Main.xaml",
      "description": "No known conversion from UiPath.Core.QueueItem to System.Collections.Generic.Dictionary`<System.String, System.Activities.Argument> — review the variable type or activity property"
    },
    {
      "repairCode": "REPAIR_TYPE_MISMATCH",
      "file": "Init.xaml",
      "description": "No known conversion from scg:Dictionary(x:String, x:Object) to System.Collections.Generic.Dictionary`<System.String, System.Activities.Argument> — review the variable type or activity property"
    }
  ],
  "remediations": [
    {
      "level": "activity",
      "file": "BGYY_SendGmail.xaml",
      "remediationCode": "DEGRADED_ACTIVITY_MISSING_PROPERTY",
      "reason": "Activity \"Send birthday email via Gmail Integration Service connector\" missing required properties: Body — degraded to handoff block",
      "classifiedCheck": "critical-activity-degradation",
      "developerAction": "Provide the missing properties for \"UiPath.GSuite.Activities.GmailSendMessage\": Body",
      "estimatedEffortMinutes": 5
    },
    {
      "level": "activity",
      "file": "BGYY_WriteSendLog.xaml",
      "remediationCode": "DEGRADED_ACTIVITY_MISSING_PROPERTY",
      "reason": "Activity \"Update existing BGYY_BirthdaySendLog record with latest outcome fields\" missing required properties: EntityObject — degraded to handoff block",
      "classifiedCheck": "critical-activity-degradation",
      "developerAction": "Provide the missing properties for \"UiPath.DataService.Activities.UpdateEntity\": EntityObject",
      "estimatedEffortMinutes": 5
    },
    {
      "level": "activity",
      "file": "BGYY_WriteSendLog.xaml",
      "remediationCode": "DEGRADED_ACTIVITY_MISSING_PROPERTY",
      "reason": "Activity \"Create new BGYY_BirthdaySendLog record with all audit fields\" missing required properties: EntityObject — degraded to handoff block",
      "classifiedCheck": "critical-activity-degradation",
      "developerAction": "Provide the missing properties for \"UiPath.DataService.Activities.CreateEntity\": EntityObject",
      "estimatedEffortMinutes": 5
    },
    {
      "level": "activity",
      "file": "BGYY_CreateReviewTask.xaml",
      "remediationCode": "DEGRADED_ACTIVITY_MISSING_PROPERTY",
      "reason": "Activity \"Create Action Center Form Task in BGYY_DraftReview Catalog\" missing required properties: TaskTitle — degraded to handoff block",
      "classifiedCheck": "critical-activity-degradation",
      "developerAction": "Provide the missing properties for \"UiPath.Persistence.Activities.CreateFormTask\": TaskTitle",
      "estimatedEffortMinutes": 5
    },
    {
      "level": "activity",
      "file": "BGYY_SendGmail.xaml",
      "remediationCode": "DEGRADED_ACTIVITY_MISSING_PROPERTY",
      "reason": "Mail activity in cluster \"BGYY_SendGmail.xaml:BGYY_SendGmail:mail-cluster-0\" missing required properties: Body — degraded to handoff block",
      "classifiedCheck": "critical-activity-degradation",
      "developerAction": "Provide the missing properties for mail activity \"UiPath.GSuite.Activities.GmailSendMessage\": Body",
      "estimatedEffortMinutes": 5
    },
    {
      "level": "validation-finding",
      "file": "BGYY_Main.xaml",
      "remediationCode": "STUB_ACTIVITY_UNKNOWN",
      "reason": "Line 255: Undeclared variable \"BGYY_Main\" in expression: BGYY_Main &amp; &quot; Workflow started. Initializing run.&q... — variable is not declared in any <Variable> block in scope",
      "classifiedCheck": "UNDECLARED_VARIABLE",
      "developerAction": "Manually implement activity in BGYY_Main.xaml — estimated 15 min",
      "estimatedEffortMinutes": 15
    },
    {
      "level": "validation-finding",
      "file": "BGYY_Main.xaml",
      "remediationCode": "STUB_ACTIVITY_UNKNOWN",
      "reason": "Line 330: Undeclared variable \"str_AssetValue\" in expression: str_AssetValue — variable is not declared in any <Variable> block in scope",
      "classifiedCheck": "UNDECLARED_VARIABLE",
      "developerAction": "Manually implement activity in BGYY_Main.xaml — estimated 15 min",
      "estimatedEffortMinutes": 15
    },
    {
      "level": "validation-finding",
      "file": "BGYY_Main.xaml",
      "remediationCode": "STUB_ACTIVITY_UNKNOWN",
      "reason": "Line 483: Undeclared variable \"vb_expression\" in expression: vb_expression — variable is not declared in any <Variable> block in scope",
      "classifiedCheck": "UNDECLARED_VARIABLE",
      "developerAction": "Manually implement activity in BGYY_Main.xaml — estimated 15 min",
      "estimatedEffortMinutes": 15
    },
    {
      "level": "validation-finding",
      "file": "BGYY_GetTodaysBirthdays.xaml",
      "remediationCode": "STUB_ACTIVITY_UNKNOWN",
      "reason": "Line 143: ui:BuildDataTable is missing required property \"TableInfo\"",
      "classifiedCheck": "MISSING_REQUIRED_ACTIVITY_PROPERTY",
      "developerAction": "Manually implement activity in BGYY_GetTodaysBirthdays.xaml — estimated 15 min",
      "estimatedEffortMinutes": 15
    },
    {
      "level": "validation-finding",
      "file": "InitAllSettings.xaml",
      "remediationCode": "STUB_ACTIVITY_UNKNOWN",
      "reason": "Line 173: uexcel:ExcelApplicationScope is missing required property \"ExistingWorkbook\"",
      "classifiedCheck": "MISSING_REQUIRED_ACTIVITY_PROPERTY",
      "developerAction": "Manually implement activity in InitAllSettings.xaml — estimated 15 min",
      "estimatedEffortMinutes": 15
    },
    {
      "level": "validation-finding",
      "file": "BGYY_GetTodaysBirthdays.xaml",
      "remediationCode": "STUB_ACTIVITY_CATALOG_VIOLATION",
      "reason": "Property \"To\" on Assign must be a child element, not an attribute",
      "classifiedCheck": "CATALOG_STRUCTURAL_VIOLATION",
      "developerAction": "Fix property syntax for activity in BGYY_GetTodaysBirthdays.xaml — move attribute to child-element or vice versa per UiPath catalog",
      "estimatedEffortMinutes": 15
    },
    {
      "level": "validation-finding",
      "file": "BGYY_GetTodaysBirthdays.xaml",
      "remediationCode": "STUB_ACTIVITY_CATALOG_VIOLATION",
      "reason": "Property \"Value\" on Assign must be a child element, not an attribute",
      "classifiedCheck": "CATALOG_STRUCTURAL_VIOLATION",
      "developerAction": "Fix property syntax for activity in BGYY_GetTodaysBirthdays.xaml — move attribute to child-element or vice versa per UiPath catalog",
      "estimatedEffortMinutes": 15
    },
    {
      "level": "validation-finding",
      "file": "BGYY_ResolveRecipient.xaml",
      "remediationCode": "STUB_ACTIVITY_CATALOG_VIOLATION",
      "reason": "Property \"To\" on Assign must be a child element, not an attribute",
      "classifiedCheck": "CATALOG_STRUCTURAL_VIOLATION",
      "developerAction": "Fix property syntax for activity in BGYY_ResolveRecipient.xaml — move attribute to child-element or vice versa per UiPath catalog",
      "estimatedEffortMinutes": 15
    },
    {
      "level": "validation-finding",
      "file": "BGYY_ResolveRecipient.xaml",
      "remediationCode": "STUB_ACTIVITY_CATALOG_VIOLATION",
      "reason": "Property \"Value\" on Assign must be a child element, not an attribute",
      "classifiedCheck": "CATALOG_STRUCTURAL_VIOLATION",
      "developerAction": "Fix property syntax for activity in BGYY_ResolveRecipient.xaml — move attribute to child-element or vice versa per UiPath catalog",
      "estimatedEffortMinutes": 15
    },
    {
      "level": "validation-finding",
      "file": "BGYY_CheckDedupe.xaml",
      "remediationCode": "STUB_ACTIVITY_CATALOG_VIOLATION",
      "reason": "Property \"Exception\" on Throw must be a child element, not an attribute",
      "classifiedCheck": "CATALOG_STRUCTURAL_VIOLATION",
      "developerAction": "Fix property syntax for activity in BGYY_CheckDedupe.xaml — move attribute to child-element or vice versa per UiPath catalog",
      "estimatedEffortMinutes": 15
    },
    {
      "level": "validation-finding",
      "file": "BGYY_CheckDedupe.xaml",
      "remediationCode": "STUB_ACTIVITY_CATALOG_VIOLATION",
      "reason": "Property \"To\" on Assign must be a child element, not an attribute",
      "classifiedCheck": "CATALOG_STRUCTURAL_VIOLATION",
      "developerAction": "Fix property syntax for activity in BGYY_CheckDedupe.xaml — move attribute to child-element or vice versa per UiPath catalog",
      "estimatedEffortMinutes": 15
    },
    {
      "level": "validation-finding",
      "file": "BGYY_CheckDedupe.xaml",
      "remediationCode": "STUB_ACTIVITY_CATALOG_VIOLATION",
      "reason": "Property \"Value\" on Assign must be a child element, not an attribute",
      "classifiedCheck": "CATALOG_STRUCTURAL_VIOLATION",
      "developerAction": "Fix property syntax for activity in BGYY_CheckDedupe.xaml — move attribute to child-element or vice versa per UiPath catalog",
      "estimatedEffortMinutes": 15
    },
    {
      "level": "validation-finding",
      "file": "BGYY_GenerateDraft.xaml",
      "remediationCode": "STUB_ACTIVITY_CATALOG_VIOLATION",
      "reason": "Property \"Path\" on ucas:ReadStorageText must be a child element, not an attribute",
      "classifiedCheck": "CATALOG_STRUCTURAL_VIOLATION",
      "developerAction": "Fix property syntax for activity in BGYY_GenerateDraft.xaml — move attribute to child-element or vice versa per UiPath catalog",
      "estimatedEffortMinutes": 15
    },
    {
      "level": "validation-finding",
      "file": "BGYY_GenerateDraft.xaml",
      "remediationCode": "STUB_ACTIVITY_CATALOG_VIOLATION",
      "reason": "Property \"StorageBucketName\" on ucas:ReadStorageText must be a child element, not an attribute",
      "classifiedCheck": "CATALOG_STRUCTURAL_VIOLATION",
      "developerAction": "Fix property syntax for activity in BGYY_GenerateDraft.xaml — move attribute to child-element or vice versa per UiPath catalog",
      "estimatedEffortMinutes": 15
    },
    {
      "level": "validation-finding",
      "file": "BGYY_GenerateDraft.xaml",
      "remediationCode": "STUB_ACTIVITY_CATALOG_VIOLATION",
      "reason": "Property \"Destination\" on ucas:UploadStorageFile must be a child element, not an attribute",
      "classifiedCheck": "CATALOG_STRUCTURAL_VIOLATION",
      "developerAction": "Fix property syntax for activity in BGYY_GenerateDraft.xaml — move attribute to child-element or vice versa per UiPath catalog",
      "estimatedEffortMinutes": 15
    },
    {
      "level": "validation-finding",
      "file": "BGYY_GenerateDraft.xaml",
      "remediationCode": "STUB_ACTIVITY_CATALOG_VIOLATION",
      "reason": "Property \"FileResource\" on ucas:UploadStorageFile must be a child element, not an attribute",
      "classifiedCheck": "CATALOG_STRUCTURAL_VIOLATION",
      "developerAction": "Fix property syntax for activity in BGYY_GenerateDraft.xaml — move attribute to child-element or vice versa per UiPath catalog",
      "estimatedEffortMinutes": 15
    },
    {
      "level": "validation-finding",
      "file": "BGYY_GenerateDraft.xaml",
      "remediationCode": "STUB_ACTIVITY_CATALOG_VIOLATION",
      "reason": "Property \"Path\" on ucas:UploadStorageFile must be a child element, not an attribute",
      "classifiedCheck": "CATALOG_STRUCTURAL_VIOLATION",
      "developerAction": "Fix property syntax for activity in BGYY_GenerateDraft.xaml — move attribute to child-element or vice versa per UiPath catalog",
      "estimatedEffortMinutes": 15
    },
    {
      "level": "validation-finding",
      "file": "BGYY_GenerateDraft.xaml",
      "remediationCode": "STUB_ACTIVITY_CATALOG_VIOLATION",
      "reason": "Property \"StorageBucketName\" on ucas:UploadStorageFile must be a child element, not an attribute",
      "classifiedCheck": "CATALOG_STRUCTURAL_VIOLATION",
      "developerAction": "Fix property syntax for activity in BGYY_GenerateDraft.xaml — move attribute to child-element or vice versa per UiPath catalog",
      "estimatedEffortMinutes": 15
    },
    {
      "level": "validation-finding",
      "file": "BGYY_GenerateDraft.xaml",
      "remediationCode": "STUB_ACTIVITY_CATALOG_VIOLATION",
      "reason": "Property \"To\" on Assign must be a child element, not an attribute",
      "classifiedCheck": "CATALOG_STRUCTURAL_VIOLATION",
      "developerAction": "Fix property syntax for activity in BGYY_GenerateDraft.xaml — move attribute to child-element or vice versa per UiPath catalog",
      "estimatedEffortMinutes": 15
    },
    {
      "level": "validation-finding",
      "file": "BGYY_GenerateDraft.xaml",
      "remediationCode": "STUB_ACTIVITY_CATALOG_VIOLATION",
      "reason": "Property \"Value\" on Assign must be a child element, not an attribute",
      "classifiedCheck": "CATALOG_STRUCTURAL_VIOLATION",
      "developerAction": "Fix property syntax for activity in BGYY_GenerateDraft.xaml — move attribute to child-element or vice versa per UiPath catalog",
      "estimatedEffortMinutes": 15
    },
    {
      "level": "validation-finding",
      "file": "BGYY_ValidateDraft.xaml",
      "remediationCode": "STUB_ACTIVITY_CATALOG_VIOLATION",
      "reason": "Property \"To\" on Assign must be a child element, not an attribute",
      "classifiedCheck": "CATALOG_STRUCTURAL_VIOLATION",
      "developerAction": "Fix property syntax for activity in BGYY_ValidateDraft.xaml — move attribute to child-element or vice versa per UiPath catalog",
      "estimatedEffortMinutes": 15
    },
    {
      "level": "validation-finding",
      "file": "BGYY_ValidateDraft.xaml",
      "remediationCode": "STUB_ACTIVITY_CATALOG_VIOLATION",
      "reason": "Property \"Value\" on Assign must be a child element, not an attribute",
      "classifiedCheck": "CATALOG_STRUCTURAL_VIOLATION",
      "developerAction": "Fix property syntax for activity in BGYY_ValidateDraft.xaml — move attribute to child-element or vice versa per UiPath catalog",
      "estimatedEffortMinutes": 15
    },
    {
      "level": "validation-finding",
      "file": "BGYY_ValidateDraft.xaml",
      "remediationCode": "STUB_ACTIVITY_CATALOG_VIOLATION",
      "reason": "Property \"Input\" on ui:IsMatch must be a child element, not an attribute",
      "classifiedCheck": "CATALOG_STRUCTURAL_VIOLATION",
      "developerAction": "Fix property syntax for activity in BGYY_ValidateDraft.xaml — move attribute to child-element or vice versa per UiPath catalog",
      "estimatedEffortMinutes": 15
    },
    {
      "level": "validation-finding",
      "file": "BGYY_ValidateDraft.xaml",
      "remediationCode": "STUB_ACTIVITY_CATALOG_VIOLATION",
      "reason": "Property \"Pattern\" on ui:IsMatch must be a child element, not an attribute",
      "classifiedCheck": "CATALOG_STRUCTURAL_VIOLATION",
      "developerAction": "Fix property syntax for activity in BGYY_ValidateDraft.xaml — move attribute to child-element or vice versa per UiPath catalog",
      "estimatedEffortMinutes": 15
    },
    {
      "level": "validation-finding",
      "file": "BGYY_ValidateDraft.xaml",
      "remediationCode": "STUB_ACTIVITY_CATALOG_VIOLATION",
      "reason": "Property \"Path\" on ucas:ReadStorageText must be a child element, not an attribute",
      "classifiedCheck": "CATALOG_STRUCTURAL_VIOLATION",
      "developerAction": "Fix property syntax for activity in BGYY_ValidateDraft.xaml — move attribute to child-element or vice versa per UiPath catalog",
      "estimatedEffortMinutes": 15
    },
    {
      "level": "validation-finding",
      "file": "BGYY_ValidateDraft.xaml",
      "remediationCode": "STUB_ACTIVITY_CATALOG_VIOLATION",
      "reason": "Property \"StorageBucketName\" on ucas:ReadStorageText must be a child element, not an attribute",
      "classifiedCheck": "CATALOG_STRUCTURAL_VIOLATION",
      "developerAction": "Fix property syntax for activity in BGYY_ValidateDraft.xaml — move attribute to child-element or vice versa per UiPath catalog",
      "estimatedEffortMinutes": 15
    },
    {
      "level": "validation-finding",
      "file": "BGYY_SendGmail.xaml",
      "remediationCode": "STUB_ACTIVITY_CATALOG_VIOLATION",
      "reason": "Property \"To\" on Assign must be a child element, not an attribute",
      "classifiedCheck": "CATALOG_STRUCTURAL_VIOLATION",
      "developerAction": "Fix property syntax for activity in BGYY_SendGmail.xaml — move attribute to child-element or vice versa per UiPath catalog",
      "estimatedEffortMinutes": 15
    },
    {
      "level": "validation-finding",
      "file": "BGYY_SendGmail.xaml",
      "remediationCode": "STUB_ACTIVITY_CATALOG_VIOLATION",
      "reason": "Property \"Value\" on Assign must be a child element, not an attribute",
      "classifiedCheck": "CATALOG_STRUCTURAL_VIOLATION",
      "developerAction": "Fix property syntax for activity in BGYY_SendGmail.xaml — move attribute to child-element or vice versa per UiPath catalog",
      "estimatedEffortMinutes": 15
    },
    {
      "level": "validation-finding",
      "file": "BGYY_SendGmail.xaml",
      "remediationCode": "STUB_ACTIVITY_CATALOG_VIOLATION",
      "reason": "Property \"Destination\" on ucas:UploadStorageFile must be a child element, not an attribute",
      "classifiedCheck": "CATALOG_STRUCTURAL_VIOLATION",
      "developerAction": "Fix property syntax for activity in BGYY_SendGmail.xaml — move attribute to child-element or vice versa per UiPath catalog",
      "estimatedEffortMinutes": 15
    },
    {
      "level": "validation-finding",
      "file": "BGYY_SendGmail.xaml",
      "remediationCode": "STUB_ACTIVITY_CATALOG_VIOLATION",
      "reason": "Property \"FileResource\" on ucas:UploadStorageFile must be a child element, not an attribute",
      "classifiedCheck": "CATALOG_STRUCTURAL_VIOLATION",
      "developerAction": "Fix property syntax for activity in BGYY_SendGmail.xaml — move attribute to child-element or vice versa per UiPath catalog",
      "estimatedEffortMinutes": 15
    },
    {
      "level": "validation-finding",
      "file": "BGYY_SendGmail.xaml",
      "remediationCode": "STUB_ACTIVITY_CATALOG_VIOLATION",
      "reason": "Property \"Path\" on ucas:UploadStorageFile must be a child element, not an attribute",
      "classifiedCheck": "CATALOG_STRUCTURAL_VIOLATION",
      "developerAction": "Fix property syntax for activity in BGYY_SendGmail.xaml — move attribute to child-element or vice versa per UiPath catalog",
      "estimatedEffortMinutes": 15
    },
    {
      "level": "validation-finding",
      "file": "BGYY_SendGmail.xaml",
      "remediationCode": "STUB_ACTIVITY_CATALOG_VIOLATION",
      "reason": "Property \"StorageBucketName\" on ucas:UploadStorageFile must be a child element, not an attribute",
      "classifiedCheck": "CATALOG_STRUCTURAL_VIOLATION",
      "developerAction": "Fix property syntax for activity in BGYY_SendGmail.xaml — move attribute to child-element or vice versa per UiPath catalog",
      "estimatedEffortMinutes": 15
    },
    {
      "level": "validation-finding",
      "file": "BGYY_WriteSendLog.xaml",
      "remediationCode": "STUB_ACTIVITY_CATALOG_VIOLATION",
      "reason": "Property \"To\" on Assign must be a child element, not an attribute",
      "classifiedCheck": "CATALOG_STRUCTURAL_VIOLATION",
      "developerAction": "Fix property syntax for activity in BGYY_WriteSendLog.xaml — move attribute to child-element or vice versa per UiPath catalog",
      "estimatedEffortMinutes": 15
    },
    {
      "level": "validation-finding",
      "file": "BGYY_WriteSendLog.xaml",
      "remediationCode": "STUB_ACTIVITY_CATALOG_VIOLATION",
      "reason": "Property \"Value\" on Assign must be a child element, not an attribute",
      "classifiedCheck": "CATALOG_STRUCTURAL_VIOLATION",
      "developerAction": "Fix property syntax for activity in BGYY_WriteSendLog.xaml — move attribute to child-element or vice versa per UiPath catalog",
      "estimatedEffortMinutes": 15
    },
    {
      "level": "validation-finding",
      "file": "BGYY_CreateReviewTask.xaml",
      "remediationCode": "STUB_ACTIVITY_CATALOG_VIOLATION",
      "reason": "Property \"To\" on Assign must be a child element, not an attribute",
      "classifiedCheck": "CATALOG_STRUCTURAL_VIOLATION",
      "developerAction": "Fix property syntax for activity in BGYY_CreateReviewTask.xaml — move attribute to child-element or vice versa per UiPath catalog",
      "estimatedEffortMinutes": 15
    },
    {
      "level": "validation-finding",
      "file": "BGYY_CreateReviewTask.xaml",
      "remediationCode": "STUB_ACTIVITY_CATALOG_VIOLATION",
      "reason": "Property \"Value\" on Assign must be a child element, not an attribute",
      "classifiedCheck": "CATALOG_STRUCTURAL_VIOLATION",
      "developerAction": "Fix property syntax for activity in BGYY_CreateReviewTask.xaml — move attribute to child-element or vice versa per UiPath catalog",
      "estimatedEffortMinutes": 15
    },
    {
      "level": "validation-finding",
      "file": "BGYY_Main.xaml",
      "remediationCode": "STUB_ACTIVITY_CATALOG_VIOLATION",
      "reason": "Property \"To\" on Assign must be a child element, not an attribute",
      "classifiedCheck": "CATALOG_STRUCTURAL_VIOLATION",
      "developerAction": "Fix property syntax for activity in BGYY_Main.xaml — move attribute to child-element or vice versa per UiPath catalog",
      "estimatedEffortMinutes": 15
    },
    {
      "level": "validation-finding",
      "file": "BGYY_Main.xaml",
      "remediationCode": "STUB_ACTIVITY_CATALOG_VIOLATION",
      "reason": "Property \"Value\" on Assign must be a child element, not an attribute",
      "classifiedCheck": "CATALOG_STRUCTURAL_VIOLATION",
      "developerAction": "Fix property syntax for activity in BGYY_Main.xaml — move attribute to child-element or vice versa per UiPath catalog",
      "estimatedEffortMinutes": 15
    },
    {
      "level": "validation-finding",
      "file": "InitAllSettings.xaml",
      "remediationCode": "STUB_ACTIVITY_CATALOG_VIOLATION",
      "reason": "Property \"ExistingWorkbook\" on uexcel:ExcelApplicationScope must be a child element, not an attribute",
      "classifiedCheck": "CATALOG_STRUCTURAL_VIOLATION",
      "developerAction": "Fix property syntax for activity in InitAllSettings.xaml — move attribute to child-element or vice versa per UiPath catalog",
      "estimatedEffortMinutes": 15
    },
    {
      "level": "validation-finding",
      "file": "InitAllSettings.xaml",
      "remediationCode": "STUB_ACTIVITY_CATALOG_VIOLATION",
      "reason": "Property \"To\" on Assign must be a child element, not an attribute",
      "classifiedCheck": "CATALOG_STRUCTURAL_VIOLATION",
      "developerAction": "Fix property syntax for activity in InitAllSettings.xaml — move attribute to child-element or vice versa per UiPath catalog",
      "estimatedEffortMinutes": 15
    },
    {
      "level": "validation-finding",
      "file": "InitAllSettings.xaml",
      "remediationCode": "STUB_ACTIVITY_CATALOG_VIOLATION",
      "reason": "Property \"Value\" on Assign must be a child element, not an attribute",
      "classifiedCheck": "CATALOG_STRUCTURAL_VIOLATION",
      "developerAction": "Fix property syntax for activity in InitAllSettings.xaml — move attribute to child-element or vice versa per UiPath catalog",
      "estimatedEffortMinutes": 15
    },
    {
      "level": "validation-finding",
      "file": "Main.xaml",
      "remediationCode": "STUB_ACTIVITY_CATALOG_VIOLATION",
      "reason": "Property \"To\" on Assign must be a child element, not an attribute",
      "classifiedCheck": "CATALOG_STRUCTURAL_VIOLATION",
      "developerAction": "Fix property syntax for activity in Main.xaml — move attribute to child-element or vice versa per UiPath catalog",
      "estimatedEffortMinutes": 15
    },
    {
      "level": "validation-finding",
      "file": "Main.xaml",
      "remediationCode": "STUB_ACTIVITY_CATALOG_VIOLATION",
      "reason": "Property \"Value\" on Assign must be a child element, not an attribute",
      "classifiedCheck": "CATALOG_STRUCTURAL_VIOLATION",
      "developerAction": "Fix property syntax for activity in Main.xaml — move attribute to child-element or vice versa per UiPath catalog",
      "estimatedEffortMinutes": 15
    },
    {
      "level": "validation-finding",
      "file": "GetTransactionData.xaml",
      "remediationCode": "STUB_ACTIVITY_CATALOG_VIOLATION",
      "reason": "Property \"To\" on Assign must be a child element, not an attribute",
      "classifiedCheck": "CATALOG_STRUCTURAL_VIOLATION",
      "developerAction": "Fix property syntax for activity in GetTransactionData.xaml — move attribute to child-element or vice versa per UiPath catalog",
      "estimatedEffortMinutes": 15
    },
    {
      "level": "validation-finding",
      "file": "GetTransactionData.xaml",
      "remediationCode": "STUB_ACTIVITY_CATALOG_VIOLATION",
      "reason": "Property \"Value\" on Assign must be a child element, not an attribute",
      "classifiedCheck": "CATALOG_STRUCTURAL_VIOLATION",
      "developerAction": "Fix property syntax for activity in GetTransactionData.xaml — move attribute to child-element or vice versa per UiPath catalog",
      "estimatedEffortMinutes": 15
    },
    {
      "level": "validation-finding",
      "file": "Init.xaml",
      "remediationCode": "STUB_ACTIVITY_CATALOG_VIOLATION",
      "reason": "Property \"To\" on Assign must be a child element, not an attribute",
      "classifiedCheck": "CATALOG_STRUCTURAL_VIOLATION",
      "developerAction": "Fix property syntax for activity in Init.xaml — move attribute to child-element or vice versa per UiPath catalog",
      "estimatedEffortMinutes": 15
    },
    {
      "level": "validation-finding",
      "file": "Init.xaml",
      "remediationCode": "STUB_ACTIVITY_CATALOG_VIOLATION",
      "reason": "Property \"Value\" on Assign must be a child element, not an attribute",
      "classifiedCheck": "CATALOG_STRUCTURAL_VIOLATION",
      "developerAction": "Fix property syntax for activity in Init.xaml — move attribute to child-element or vice versa per UiPath catalog",
      "estimatedEffortMinutes": 15
    },
    {
      "level": "validation-finding",
      "file": "Init.xaml",
      "remediationCode": "STUB_ACTIVITY_CATALOG_VIOLATION",
      "reason": "Property \"Exception\" on Throw must be a child element, not an attribute",
      "classifiedCheck": "CATALOG_STRUCTURAL_VIOLATION",
      "developerAction": "Fix property syntax for activity in Init.xaml — move attribute to child-element or vice versa per UiPath catalog",
      "estimatedEffortMinutes": 15
    },
    {
      "level": "validation-finding",
      "file": "RetryCurrentTransaction.xaml",
      "remediationCode": "STUB_ACTIVITY_CATALOG_VIOLATION",
      "reason": "Property \"To\" on Assign must be a child element, not an attribute",
      "classifiedCheck": "CATALOG_STRUCTURAL_VIOLATION",
      "developerAction": "Fix property syntax for activity in RetryCurrentTransaction.xaml — move attribute to child-element or vice versa per UiPath catalog",
      "estimatedEffortMinutes": 15
    },
    {
      "level": "validation-finding",
      "file": "RetryCurrentTransaction.xaml",
      "remediationCode": "STUB_ACTIVITY_CATALOG_VIOLATION",
      "reason": "Property \"Value\" on Assign must be a child element, not an attribute",
      "classifiedCheck": "CATALOG_STRUCTURAL_VIOLATION",
      "developerAction": "Fix property syntax for activity in RetryCurrentTransaction.xaml — move attribute to child-element or vice versa per UiPath catalog",
      "estimatedEffortMinutes": 15
    },
    {
      "level": "validation-finding",
      "file": "RetryInit.xaml",
      "remediationCode": "STUB_ACTIVITY_CATALOG_VIOLATION",
      "reason": "Property \"To\" on Assign must be a child element, not an attribute",
      "classifiedCheck": "CATALOG_STRUCTURAL_VIOLATION",
      "developerAction": "Fix property syntax for activity in RetryInit.xaml — move attribute to child-element or vice versa per UiPath catalog",
      "estimatedEffortMinutes": 15
    },
    {
      "level": "validation-finding",
      "file": "RetryInit.xaml",
      "remediationCode": "STUB_ACTIVITY_CATALOG_VIOLATION",
      "reason": "Property \"Value\" on Assign must be a child element, not an attribute",
      "classifiedCheck": "CATALOG_STRUCTURAL_VIOLATION",
      "developerAction": "Fix property syntax for activity in RetryInit.xaml — move attribute to child-element or vice versa per UiPath catalog",
      "estimatedEffortMinutes": 15
    },
    {
      "level": "workflow",
      "file": "BGYY_Main.xaml",
      "remediationCode": "STUB_WORKFLOW_BLOCKING",
      "reason": "Final validation: XAML well-formedness violations — replaced with stub. Details: [xml-wellformedness] XML parse error at line 863, col 150 (code: InvalidChar): char '&' is not expected.",
      "classifiedCheck": "xml-wellformedness",
      "developerAction": "Fix XML structure in BGYY_Main.xaml — [xml-wellformedness] XML parse error at line 863, col 150 (code: InvalidChar): char '&' is not expected.",
      "estimatedEffortMinutes": 15
    },
    {
      "level": "activity",
      "file": "BGYY_Main.xaml",
      "remediationCode": "UNDECLARED_VARIABLE_MANUAL",
      "reason": "Undeclared variable \"str_AssetValue\" — type cannot be auto-inferred (no recognized naming prefix)",
      "classifiedCheck": "UNDECLARED_VARIABLE",
      "developerAction": "Declare variable \"str_AssetValue\" in BGYY_Main.xaml with the appropriate type. Expression context: Line 330: variable \"str_AssetValue\" is used in expression but not declared in this workflow",
      "estimatedEffortMinutes": 5,
      "inferredType": "x:String"
    },
    {
      "level": "activity",
      "file": "BGYY_Main.xaml",
      "remediationCode": "UNDECLARED_VARIABLE_MANUAL",
      "reason": "Undeclared variable \"BGYY_Main\" — type cannot be auto-inferred (no recognized naming prefix)",
      "classifiedCheck": "UNDECLARED_VARIABLE",
      "developerAction": "Declare variable \"BGYY_Main\" in BGYY_Main.xaml with the appropriate type. Expression context: BGYY_Main &amp; &quot; Workflow started. Initializing run.&q...",
      "estimatedEffortMinutes": 5
    },
    {
      "level": "activity",
      "file": "BGYY_Main.xaml",
      "remediationCode": "UNDECLARED_VARIABLE_MANUAL",
      "reason": "Undeclared variable \"str_AssetValue\" — type cannot be auto-inferred (no recognized naming prefix)",
      "classifiedCheck": "UNDECLARED_VARIABLE",
      "developerAction": "Declare variable \"str_AssetValue\" in BGYY_Main.xaml with the appropriate type. Expression context: str_AssetValue",
      "estimatedEffortMinutes": 5,
      "inferredType": "x:String"
    },
    {
      "level": "activity",
      "file": "BGYY_Main.xaml",
      "remediationCode": "UNDECLARED_VARIABLE_MANUAL",
      "reason": "Undeclared variable \"vb_expression\" — type cannot be auto-inferred (no recognized naming prefix)",
      "classifiedCheck": "UNDECLARED_VARIABLE",
      "developerAction": "Declare variable \"vb_expression\" in BGYY_Main.xaml with the appropriate type. Expression context: vb_expression",
      "estimatedEffortMinutes": 5
    },
    {
      "level": "activity",
      "file": "",
      "remediationCode": "POST_ASSEMBLY_REPAIR",
      "reason": "[MISSING_REQUIRED_PROPERTY_DEFECT] ui:BuildDataTable.TableInfo has no valid source binding and no contract-valid fallback — structured defect, property left absent",
      "classifiedCheck": "post-assembly-repair",
      "developerAction": "ui:BuildDataTable.TableInfo has no valid source binding and no contract-valid fallback — structured defect, property left absent",
      "estimatedEffortMinutes": 5
    },
    {
      "level": "activity",
      "file": "",
      "remediationCode": "POST_ASSEMBLY_REPAIR",
      "reason": "[MISSING_REQUIRED_PROPERTY_DEFECT] uexcel:ExcelApplicationScope.ExistingWorkbook has no valid source binding and no contract-valid fallback — structured defect, property left absent",
      "classifiedCheck": "post-assembly-repair",
      "developerAction": "uexcel:ExcelApplicationScope.ExistingWorkbook has no valid source binding and no contract-valid fallback — structured defect, property left absent",
      "estimatedEffortMinutes": 5
    },
    {
      "level": "workflow",
      "file": "BGYY_GenerateDraft.xaml",
      "remediationCode": "STUB_WORKFLOW_BLOCKING",
      "reason": "Pre-archive assertion: malformed_attribute_quoting — Malformed attribute quoting detected: Message=\"[&quot;logMessage&quot;]",
      "classifiedCheck": "pre-archive-canonicalization",
      "developerAction": "Resolve malformed_attribute_quoting in BGYY_GenerateDraft.xaml",
      "estimatedEffortMinutes": 10
    },
    {
      "level": "workflow",
      "file": "InitAllSettings.xaml",
      "remediationCode": "STUB_WORKFLOW_BLOCKING",
      "reason": "Pre-archive assertion: malformed_attribute_quoting — Malformed attribute quoting detected: AssetName=\"[&quot;BGYY_DryRun&quot;]",
      "classifiedCheck": "pre-archive-canonicalization",
      "developerAction": "Resolve malformed_attribute_quoting in InitAllSettings.xaml",
      "estimatedEffortMinutes": 10
    }
  ],
  "propertyRemediations": [],
  "downgradeEvents": [],
  "qualityWarnings": [
    {
      "check": "placeholder-value",
      "file": "BGYY_GetTodaysBirthdays.xaml",
      "detail": "Contains 3 placeholder value(s) matching \"\\bTODO\\b\" [Developer Implementation Required]",
      "severity": "warning",
      "stubCategory": "handoff"
    },
    {
      "check": "placeholder-value",
      "file": "BGYY_GetTodaysBirthdays.xaml",
      "detail": "Contains 3 placeholder value(s) matching \"\\bPLACEHOLDER\\b\" [Developer Implementation Required]",
      "severity": "warning",
      "stubCategory": "handoff"
    },
    {
      "check": "placeholder-value",
      "file": "BGYY_ResolveRecipient.xaml",
      "detail": "Contains 5 placeholder value(s) matching \"\\bTODO\\b\" [Developer Implementation Required]",
      "severity": "warning",
      "stubCategory": "handoff"
    },
    {
      "check": "placeholder-value",
      "file": "BGYY_ResolveRecipient.xaml",
      "detail": "Contains 5 placeholder value(s) matching \"\\bPLACEHOLDER\\b\" [Developer Implementation Required]",
      "severity": "warning",
      "stubCategory": "handoff"
    },
    {
      "check": "placeholder-value",
      "file": "BGYY_GenerateDraft.xaml",
      "detail": "Contains 4 placeholder value(s) matching \"\\bTODO\\b\" [Developer Implementation Required]",
      "severity": "warning",
      "stubCategory": "handoff"
    },
    {
      "check": "placeholder-value",
      "file": "BGYY_GenerateDraft.xaml",
      "detail": "Contains 4 placeholder value(s) matching \"\\bPLACEHOLDER\\b\" [Developer Implementation Required]",
      "severity": "warning",
      "stubCategory": "handoff"
    },
    {
      "check": "placeholder-value",
      "file": "BGYY_ValidateDraft.xaml",
      "detail": "Contains 8 placeholder value(s) matching \"\\bTODO\\b\" [Developer Implementation Required]",
      "severity": "warning",
      "stubCategory": "handoff"
    },
    {
      "check": "placeholder-value",
      "file": "BGYY_ValidateDraft.xaml",
      "detail": "Contains 19 placeholder value(s) matching \"\\bPLACEHOLDER\\b\" [Developer Implementation Required]",
      "severity": "warning",
      "stubCategory": "handoff"
    },
    {
      "check": "placeholder-value",
      "file": "BGYY_SendGmail.xaml",
      "detail": "Contains 5 placeholder value(s) matching \"\\bTODO\\b\" [Developer Implementation Required]",
      "severity": "warning",
      "stubCategory": "handoff"
    },
    {
      "check": "placeholder-value",
      "file": "BGYY_SendGmail.xaml",
      "detail": "Contains 4 placeholder value(s) matching \"\\bPLACEHOLDER\\b\" [Developer Implementation Required]",
      "severity": "warning",
      "stubCategory": "handoff"
    },
    {
      "check": "placeholder-value",
      "file": "BGYY_WriteSendLog.xaml",
      "detail": "Contains 2 placeholder value(s) matching \"\\bTODO\\b\" [Developer Implementation Required]",
      "severity": "warning",
      "stubCategory": "handoff"
    },
    {
      "check": "placeholder-value",
      "file": "BGYY_WriteSendLog.xaml",
      "detail": "Contains 2 placeholder value(s) matching \"\\bPLACEHOLDER\\b\" [Developer Implementation Required]",
      "severity": "warning",
      "stubCategory": "handoff"
    },
    {
      "check": "placeholder-value",
      "file": "BGYY_Main.xaml",
      "detail": "Contains 6 placeholder value(s) matching \"\\bTODO\\b\" [Developer Implementation Required]",
      "severity": "warning",
      "stubCategory": "handoff"
    },
    {
      "check": "placeholder-value",
      "file": "BGYY_Main.xaml",
      "detail": "Contains 5 placeholder value(s) matching \"\\bPLACEHOLDER\\b\" [Developer Implementation Required]",
      "severity": "warning",
      "stubCategory": "handoff"
    },
    {
      "check": "placeholder-value",
      "file": "InitAllApplications.xaml",
      "detail": "Contains 1 placeholder value(s) matching \"\\bTODO\\b\" [Developer Implementation Required]",
      "severity": "warning",
      "stubCategory": "handoff"
    },
    {
      "check": "placeholder-value",
      "file": "InitAllApplications.xaml",
      "detail": "Contains 1 placeholder value(s) matching \"\\bPLACEHOLDER\\b\" [Developer Implementation Required]",
      "severity": "warning",
      "stubCategory": "handoff"
    },
    {
      "check": "unguarded-array-index",
      "file": "BGYY_ResolveRecipient.xaml",
      "detail": "Line 158: array indexing \".Rows(N)\" without a preceding row count check — may throw IndexOutOfRangeException at runtime",
      "severity": "warning"
    },
    {
      "check": "unguarded-array-index",
      "file": "BGYY_ResolveRecipient.xaml",
      "detail": "Line 204: array indexing \".Rows(N)\" without a preceding row count check — may throw IndexOutOfRangeException at runtime",
      "severity": "warning"
    },
    {
      "check": "unguarded-array-index",
      "file": "BGYY_ResolveRecipient.xaml",
      "detail": "Line 249: array indexing \".Rows(N)\" without a preceding row count check — may throw IndexOutOfRangeException at runtime",
      "severity": "warning"
    },
    {
      "check": "hardcoded-retry-count",
      "file": "BGYY_GetTodaysBirthdays.xaml",
      "detail": "Line 164: retry count hardcoded as 3 — consider externalizing to Config.xlsx (e.g., in_Config(\"MaxRetryNumber\"))",
      "severity": "warning"
    },
    {
      "check": "hardcoded-retry-count",
      "file": "BGYY_GetTodaysBirthdays.xaml",
      "detail": "Line 172: retry count hardcoded as 3 — consider externalizing to Config.xlsx (e.g., in_Config(\"MaxRetryNumber\"))",
      "severity": "warning"
    },
    {
      "check": "hardcoded-retry-count",
      "file": "BGYY_GetTodaysBirthdays.xaml",
      "detail": "Line 177: retry count hardcoded as 3 — consider externalizing to Config.xlsx (e.g., in_Config(\"MaxRetryNumber\"))",
      "severity": "warning"
    },
    {
      "check": "hardcoded-retry-interval",
      "file": "BGYY_GetTodaysBirthdays.xaml",
      "detail": "Line 164: retry interval hardcoded as \"00:00:05\" — consider externalizing to Config.xlsx",
      "severity": "warning"
    },
    {
      "check": "hardcoded-retry-interval",
      "file": "BGYY_GetTodaysBirthdays.xaml",
      "detail": "Line 172: retry interval hardcoded as \"00:00:05\" — consider externalizing to Config.xlsx",
      "severity": "warning"
    },
    {
      "check": "hardcoded-retry-interval",
      "file": "BGYY_GetTodaysBirthdays.xaml",
      "detail": "Line 177: retry interval hardcoded as \"00:00:05\" — consider externalizing to Config.xlsx",
      "severity": "warning"
    },
    {
      "check": "hardcoded-retry-count",
      "file": "BGYY_ResolveRecipient.xaml",
      "detail": "Line 97: retry count hardcoded as 3 — consider externalizing to Config.xlsx (e.g., in_Config(\"MaxRetryNumber\"))",
      "severity": "warning"
    },
    {
      "check": "hardcoded-retry-count",
      "file": "BGYY_ResolveRecipient.xaml",
      "detail": "Line 105: retry count hardcoded as 3 — consider externalizing to Config.xlsx (e.g., in_Config(\"MaxRetryNumber\"))",
      "severity": "warning"
    },
    {
      "check": "hardcoded-retry-count",
      "file": "BGYY_ResolveRecipient.xaml",
      "detail": "Line 110: retry count hardcoded as 3 — consider externalizing to Config.xlsx (e.g., in_Config(\"MaxRetryNumber\"))",
      "severity": "warning"
    },
    {
      "check": "hardcoded-retry-interval",
      "file": "BGYY_ResolveRecipient.xaml",
      "detail": "Line 97: retry interval hardcoded as \"00:00:05\" — consider externalizing to Config.xlsx",
      "severity": "warning"
    },
    {
      "check": "hardcoded-retry-interval",
      "file": "BGYY_ResolveRecipient.xaml",
      "detail": "Line 105: retry interval hardcoded as \"00:00:05\" — consider externalizing to Config.xlsx",
      "severity": "warning"
    },
    {
      "check": "hardcoded-retry-interval",
      "file": "BGYY_ResolveRecipient.xaml",
      "detail": "Line 110: retry interval hardcoded as \"00:00:05\" — consider externalizing to Config.xlsx",
      "severity": "warning"
    },
    {
      "check": "hardcoded-retry-count",
      "file": "BGYY_CheckDedupe.xaml",
      "detail": "Line 106: retry count hardcoded as 2 — consider externalizing to Config.xlsx (e.g., in_Config(\"MaxRetryNumber\"))",
      "severity": "warning"
    },
    {
      "check": "hardcoded-retry-interval",
      "file": "BGYY_CheckDedupe.xaml",
      "detail": "Line 106: retry interval hardcoded as \"00:00:05\" — consider externalizing to Config.xlsx",
      "severity": "warning"
    },
    {
      "check": "hardcoded-retry-count",
      "file": "BGYY_GenerateDraft.xaml",
      "detail": "Line 246: retry count hardcoded as 3 — consider externalizing to Config.xlsx (e.g., in_Config(\"MaxRetryNumber\"))",
      "severity": "warning"
    },
    {
      "check": "hardcoded-retry-interval",
      "file": "BGYY_GenerateDraft.xaml",
      "detail": "Line 246: retry interval hardcoded as \"00:00:10\" — consider externalizing to Config.xlsx",
      "severity": "warning"
    },
    {
      "check": "hardcoded-retry-count",
      "file": "BGYY_SendGmail.xaml",
      "detail": "Line 104: retry count hardcoded as 3 — consider externalizing to Config.xlsx (e.g., in_Config(\"MaxRetryNumber\"))",
      "severity": "warning"
    },
    {
      "check": "hardcoded-retry-interval",
      "file": "BGYY_SendGmail.xaml",
      "detail": "Line 104: retry interval hardcoded as \"00:00:05\" — consider externalizing to Config.xlsx",
      "severity": "warning"
    },
    {
      "check": "hardcoded-asset-name",
      "file": "BGYY_Main.xaml",
      "detail": "Line 324: asset name \"BGYY_DryRun\" is hardcoded — consider using a Config.xlsx entry or workflow argument",
      "severity": "warning"
    },
    {
      "check": "hardcoded-asset-name",
      "file": "InitAllSettings.xaml",
      "detail": "Line 266: asset name \"BGYY_DryRun\" is hardcoded — consider using a Config.xlsx entry or workflow argument",
      "severity": "warning"
    },
    {
      "check": "EXPRESSION_SYNTAX",
      "file": "BGYY_CheckDedupe.xaml",
      "detail": "Line 88: C# 'null' should be VB.NET 'Nothing' in expression: New ArgumentException(&quot;[BGYY_CheckDedupe] in_PersonKey is null or empty — c...",
      "severity": "warning"
    },
    {
      "check": "COMPLEX_EXPRESSION_PASSTHROUGH",
      "file": "BGYY_SendGmail.xaml",
      "detail": "Line 219: Complex expression (lambdas, LINQ, nested calls, or 3+ operators) — emitting as-is to avoid regex corruption in expression: System.IO.Path.Combine(System.IO.Path.GetTempPath(), \"BGYY_SendGmail_\" &amp; str...",
      "severity": "warning"
    },
    {
      "check": "EXPRESSION_SYNTAX",
      "file": "BGYY_Main.xaml",
      "detail": "Line 863: C# '+' for string concatenation should be VB.NET '&' in expression: System.Text.RegularExpressions.Regex.Replace(str_CurrentFullName.ToLowerInvarian...",
      "severity": "warning"
    },
    {
      "check": "TYPE_MISMATCH",
      "file": "BGYY_GenerateDraft.xaml",
      "detail": "Line 303: Type mismatch — variable \"str_ErrorScreenshotPath\" (System.String) bound to ucas:UploadStorageFile.FileResource (expects UiPath.Platform.ResourceHandling.IResource). No known conversion from System.String to UiPath.Platform.ResourceHandling.IResource — review the variable type or activity property",
      "severity": "warning"
    },
    {
      "check": "BARE_TOKEN_QUOTED",
      "file": "BGYY_GenerateDraft.xaml",
      "detail": "Auto-quoted bare token \"logMessage\" for ui:LogMessage.Message (expected String type) — wrapped in VB string quotes",
      "severity": "warning"
    },
    {
      "check": "BARE_TOKEN_QUOTED",
      "file": "BGYY_GenerateDraft.xaml",
      "detail": "Auto-quoted bare token \"logMessage\" for ui:LogMessage.Message (expected String type) — wrapped in VB string quotes",
      "severity": "warning"
    },
    {
      "check": "TYPE_MISMATCH",
      "file": "BGYY_SendGmail.xaml",
      "detail": "Line 237: Type mismatch — variable \"str_ScreenshotPath\" (System.String) bound to ucas:UploadStorageFile.FileResource (expects UiPath.Platform.ResourceHandling.IResource). No known conversion from System.String to UiPath.Platform.ResourceHandling.IResource — review the variable type or activity property",
      "severity": "warning"
    },
    {
      "check": "BARE_TOKEN_QUOTED",
      "file": "BGYY_Main.xaml",
      "detail": "Auto-quoted bare token \"BGYY_DryRun\" for ui:GetAsset.AssetName (expected String type) — wrapped in VB string quotes",
      "severity": "warning"
    },
    {
      "check": "BARE_TOKEN_QUOTED",
      "file": "InitAllSettings.xaml",
      "detail": "Auto-quoted bare token \"Settings\" for uexcel:ExcelReadRange.SheetName (expected String type) — wrapped in VB string quotes",
      "severity": "warning"
    },
    {
      "check": "BARE_TOKEN_QUOTED",
      "file": "InitAllSettings.xaml",
      "detail": "Auto-quoted bare token \"Constants\" for uexcel:ExcelReadRange.SheetName (expected String type) — wrapped in VB string quotes",
      "severity": "warning"
    },
    {
      "check": "BARE_TOKEN_QUOTED",
      "file": "InitAllSettings.xaml",
      "detail": "Auto-quoted bare token \"BGYY_DryRun\" for ui:GetAsset.AssetName (expected String type) — wrapped in VB string quotes",
      "severity": "warning"
    },
    {
      "check": "TYPE_MISMATCH",
      "file": "Main.xaml",
      "detail": "Line 81: Type mismatch — variable \"dict_Config\" (scg:Dictionary(x:String, x:Object)) bound to ui:InvokeWorkflowFile.Arguments (expects System.Collections.Generic.Dictionary`<System.String, System.Activities.Argument>). No known conversion from scg:Dictionary(x:String, x:Object) to System.Collections.Generic.Dictionary`<System.String, System.Activities.Argument> — review the variable type or activity property",
      "severity": "warning"
    },
    {
      "check": "TYPE_MISMATCH",
      "file": "Main.xaml",
      "detail": "Line 134: Type mismatch — variable \"qi_TransactionItem\" (UiPath.Core.QueueItem) bound to ui:InvokeWorkflowFile.Arguments (expects System.Collections.Generic.Dictionary`<System.String, System.Activities.Argument>). No known conversion from UiPath.Core.QueueItem to System.Collections.Generic.Dictionary`<System.String, System.Activities.Argument> — review the variable type or activity property",
      "severity": "warning"
    },
    {
      "check": "BARE_TOKEN_QUOTED",
      "file": "KillAllProcesses.xaml",
      "detail": "Auto-quoted bare token \"chrome\" for ui:KillProcess.ProcessName (expected String type) — wrapped in VB string quotes",
      "severity": "warning"
    },
    {
      "check": "BARE_TOKEN_QUOTED",
      "file": "KillAllProcesses.xaml",
      "detail": "Auto-quoted bare token \"iexplore\" for ui:KillProcess.ProcessName (expected String type) — wrapped in VB string quotes",
      "severity": "warning"
    },
    {
      "check": "BARE_TOKEN_QUOTED",
      "file": "KillAllProcesses.xaml",
      "detail": "Auto-quoted bare token \"EXCEL\" for ui:KillProcess.ProcessName (expected String type) — wrapped in VB string quotes",
      "severity": "warning"
    },
    {
      "check": "TYPE_MISMATCH",
      "file": "Init.xaml",
      "detail": "Line 68: Type mismatch — variable \"dict_Config\" (scg:Dictionary(x:String, x:Object)) bound to ui:InvokeWorkflowFile.Arguments (expects System.Collections.Generic.Dictionary`<System.String, System.Activities.Argument>). No known conversion from scg:Dictionary(x:String, x:Object) to System.Collections.Generic.Dictionary`<System.String, System.Activities.Argument> — review the variable type or activity property",
      "severity": "warning"
    },
    {
      "check": "RETRY_INTERVAL_DEFAULTED",
      "file": "BGYY_GetTodaysBirthdays.xaml",
      "detail": "Post-repair: RetryInterval defaulted to \"00:00:05\" — verify this is appropriate for the workflow context",
      "severity": "warning"
    },
    {
      "check": "RETRY_INTERVAL_DEFAULTED",
      "file": "BGYY_GetTodaysBirthdays.xaml",
      "detail": "Post-repair: RetryInterval defaulted to \"00:00:05\" — verify this is appropriate for the workflow context",
      "severity": "warning"
    },
    {
      "check": "RETRY_INTERVAL_DEFAULTED",
      "file": "BGYY_GetTodaysBirthdays.xaml",
      "detail": "Post-repair: RetryInterval defaulted to \"00:00:05\" — verify this is appropriate for the workflow context",
      "severity": "warning"
    },
    {
      "check": "RETRY_INTERVAL_DEFAULTED",
      "file": "BGYY_ResolveRecipient.xaml",
      "detail": "Post-repair: RetryInterval defaulted to \"00:00:05\" — verify this is appropriate for the workflow context",
      "severity": "warning"
    },
    {
      "check": "RETRY_INTERVAL_DEFAULTED",
      "file": "BGYY_ResolveRecipient.xaml",
      "detail": "Post-repair: RetryInterval defaulted to \"00:00:05\" — verify this is appropriate for the workflow context",
      "severity": "warning"
    },
    {
      "check": "RETRY_INTERVAL_DEFAULTED",
      "file": "BGYY_ResolveRecipient.xaml",
      "detail": "Post-repair: RetryInterval defaulted to \"00:00:05\" — verify this is appropriate for the workflow context",
      "severity": "warning"
    },
    {
      "check": "RETRY_INTERVAL_DEFAULTED",
      "file": "BGYY_CheckDedupe.xaml",
      "detail": "Post-repair: RetryInterval defaulted to \"00:00:05\" — verify this is appropriate for the workflow context",
      "severity": "warning"
    },
    {
      "check": "RETRY_INTERVAL_DEFAULTED",
      "file": "BGYY_SendGmail.xaml",
      "detail": "Post-repair: RetryInterval defaulted to \"00:00:05\" — verify this is appropriate for the workflow context",
      "severity": "warning"
    }
  ],
  "totalEstimatedEffortMinutes": 870,
  "studioCompatibility": [
    {
      "file": "BGYY_GetTodaysBirthdays.xaml",
      "level": "studio-blocked",
      "blockers": [
        "[CATALOG_STRUCTURAL_VIOLATION] Property \"To\" on Assign must be a child element, not an attribute",
        "[CATALOG_STRUCTURAL_VIOLATION] Property \"Value\" on Assign must be a child element, not an attribute"
      ]
    },
    {
      "file": "BGYY_ResolveRecipient.xaml",
      "level": "studio-blocked",
      "blockers": [
        "[CATALOG_STRUCTURAL_VIOLATION] Property \"To\" on Assign must be a child element, not an attribute",
        "[CATALOG_STRUCTURAL_VIOLATION] Property \"Value\" on Assign must be a child element, not an attribute"
      ]
    },
    {
      "file": "BGYY_CheckDedupe.xaml",
      "level": "studio-blocked",
      "blockers": [
        "[CATALOG_STRUCTURAL_VIOLATION] Property \"Exception\" on Throw must be a child element, not an attribute",
        "[CATALOG_STRUCTURAL_VIOLATION] Property \"To\" on Assign must be a child element, not an attribute",
        "[CATALOG_STRUCTURAL_VIOLATION] Property \"Value\" on Assign must be a child element, not an attribute"
      ]
    },
    {
      "file": "BGYY_GenerateDraft.xaml",
      "level": "studio-blocked",
      "blockers": [
        "[COMPLIANCE-FAILURE] Compliance or quality gate failure requiring manual remediation"
      ],
      "failureCategory": "compliance-failure",
      "failureSummary": "Compliance or quality gate failure requiring manual remediation"
    },
    {
      "file": "BGYY_ValidateDraft.xaml",
      "level": "studio-blocked",
      "blockers": [
        "[CATALOG_STRUCTURAL_VIOLATION] Property \"To\" on Assign must be a child element, not an attribute",
        "[CATALOG_STRUCTURAL_VIOLATION] Property \"Value\" on Assign must be a child element, not an attribute",
        "[CATALOG_STRUCTURAL_VIOLATION] Property \"Input\" on ui:IsMatch must be a child element, not an attribute",
        "[CATALOG_STRUCTURAL_VIOLATION] Property \"Pattern\" on ui:IsMatch must be a child element, not an attribute",
        "[CATALOG_STRUCTURAL_VIOLATION] Property \"Path\" on ucas:ReadStorageText must be a child element, not an attribute",
        "[CATALOG_STRUCTURAL_VIOLATION] Property \"StorageBucketName\" on ucas:ReadStorageText must be a child element, not an attribute"
      ]
    },
    {
      "file": "BGYY_SendGmail.xaml",
      "level": "studio-blocked",
      "blockers": [
        "[CATALOG_STRUCTURAL_VIOLATION] Property \"To\" on Assign must be a child element, not an attribute",
        "[CATALOG_STRUCTURAL_VIOLATION] Property \"Value\" on Assign must be a child element, not an attribute",
        "[CATALOG_STRUCTURAL_VIOLATION] Property \"Destination\" on ucas:UploadStorageFile must be a child element, not an attribute",
        "[CATALOG_STRUCTURAL_VIOLATION] Property \"FileResource\" on ucas:UploadStorageFile must be a child element, not an attribute",
        "[CATALOG_STRUCTURAL_VIOLATION] Property \"Path\" on ucas:UploadStorageFile must be a child element, not an attribute",
        "[CATALOG_STRUCTURAL_VIOLATION] Property \"StorageBucketName\" on ucas:UploadStorageFile must be a child element, not an attribute"
      ]
    },
    {
      "file": "BGYY_WriteSendLog.xaml",
      "level": "studio-blocked",
      "blockers": [
        "[CATALOG_STRUCTURAL_VIOLATION] Property \"To\" on Assign must be a child element, not an attribute",
        "[CATALOG_STRUCTURAL_VIOLATION] Property \"Value\" on Assign must be a child element, not an attribute"
      ]
    },
    {
      "file": "BGYY_CreateReviewTask.xaml",
      "level": "studio-blocked",
      "blockers": [
        "[CATALOG_STRUCTURAL_VIOLATION] Property \"To\" on Assign must be a child element, not an attribute",
        "[CATALOG_STRUCTURAL_VIOLATION] Property \"Value\" on Assign must be a child element, not an attribute"
      ]
    },
    {
      "file": "BGYY_Main.xaml",
      "level": "studio-blocked",
      "blockers": [
        "[XML-WELLFORMEDNESS] XML well-formedness failure in tree assembler"
      ],
      "failureCategory": "xml-wellformedness",
      "failureSummary": "XML well-formedness failure in tree assembler"
    },
    {
      "file": "InitAllSettings.xaml",
      "level": "studio-blocked",
      "blockers": [
        "[COMPLIANCE-FAILURE] Compliance or quality gate failure requiring manual remediation"
      ],
      "failureCategory": "compliance-failure",
      "failureSummary": "Compliance or quality gate failure requiring manual remediation"
    },
    {
      "file": "Main.xaml",
      "level": "studio-blocked",
      "blockers": [
        "[CATALOG_STRUCTURAL_VIOLATION] Property \"To\" on Assign must be a child element, not an attribute",
        "[CATALOG_STRUCTURAL_VIOLATION] Property \"Value\" on Assign must be a child element, not an attribute"
      ]
    },
    {
      "file": "GetTransactionData.xaml",
      "level": "studio-blocked",
      "blockers": [
        "[CATALOG_STRUCTURAL_VIOLATION] Property \"To\" on Assign must be a child element, not an attribute",
        "[CATALOG_STRUCTURAL_VIOLATION] Property \"Value\" on Assign must be a child element, not an attribute"
      ]
    },
    {
      "file": "SetTransactionStatus.xaml",
      "level": "studio-clean",
      "blockers": []
    },
    {
      "file": "CloseAllApplications.xaml",
      "level": "studio-clean",
      "blockers": []
    },
    {
      "file": "KillAllProcesses.xaml",
      "level": "studio-clean",
      "blockers": []
    },
    {
      "file": "Init.xaml",
      "level": "studio-blocked",
      "blockers": [
        "[CATALOG_STRUCTURAL_VIOLATION] Property \"To\" on Assign must be a child element, not an attribute",
        "[CATALOG_STRUCTURAL_VIOLATION] Property \"Value\" on Assign must be a child element, not an attribute",
        "[CATALOG_STRUCTURAL_VIOLATION] Property \"Exception\" on Throw must be a child element, not an attribute"
      ]
    },
    {
      "file": "InitAllApplications.xaml",
      "level": "studio-warnings",
      "blockers": []
    },
    {
      "file": "RetryCurrentTransaction.xaml",
      "level": "studio-blocked",
      "blockers": [
        "[CATALOG_STRUCTURAL_VIOLATION] Property \"To\" on Assign must be a child element, not an attribute",
        "[CATALOG_STRUCTURAL_VIOLATION] Property \"Value\" on Assign must be a child element, not an attribute",
        "[UNDECLARED_ARGUMENT] Post-repair: Argument \"io_RetryNumber\" referenced but not declared in x:Members or Variables"
      ]
    },
    {
      "file": "RetryInit.xaml",
      "level": "studio-blocked",
      "blockers": [
        "[CATALOG_STRUCTURAL_VIOLATION] Property \"To\" on Assign must be a child element, not an attribute",
        "[CATALOG_STRUCTURAL_VIOLATION] Property \"Value\" on Assign must be a child element, not an attribute"
      ]
    },
    {
      "file": "Process.xaml",
      "level": "studio-clean",
      "blockers": []
    }
  ],
  "propertySerializationTrace": [
    {
      "workflowFile": "BGYY_GetTodaysBirthdays.xaml",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "originalRawValue": "\"[BGYY_GetTodaysBirthdays][Init] RunId=\" & InRunId & \" | Resolving today's date in America/New_York\"",
      "parsedIntentType": "pre-assembly:literal",
      "normalizedOutput": "[\"[BGYY_GetTodaysBirthdays][Init] RunId=\"\" & InRunId & \"\" | Resolving today's date in America/New_York\"]",
      "fallbackUsed": false,
      "finalValueHash": "c13bb1d49234b558dd3d9e8ce6e5c094b43a76df9e84e7706197f266ebc5f454"
    },
    {
      "workflowFile": "BGYY_GetTodaysBirthdays.xaml",
      "activityType": "LogMessage",
      "propertyName": "Level",
      "originalRawValue": "Info",
      "parsedIntentType": "pre-assembly:literal",
      "normalizedOutput": "\"Info\"",
      "fallbackUsed": false,
      "finalValueHash": "6e68b62d2aa611a44f3e7a4cb7e23da9ad1cab1b6abb592bb2795b12fe63e51c"
    },
    {
      "workflowFile": "BGYY_GetTodaysBirthdays.xaml",
      "activityType": "LogMessage",
      "propertyName": "Level",
      "originalRawValue": "Error",
      "parsedIntentType": "pre-assembly:literal",
      "normalizedOutput": "\"Error\"",
      "fallbackUsed": false,
      "finalValueHash": "fc4ac19649f0ee8f37c71d2e2030a3743038bb96c0c27359ba115dd8657565cc"
    },
    {
      "workflowFile": "BGYY_GetTodaysBirthdays.xaml",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "originalRawValue": "\"Error in Resolve current date/time in America/New_York via InvokeCode: \" & exception.Message",
      "parsedIntentType": "pre-assembly:literal",
      "normalizedOutput": "[\"\"\"Error in Resolve current date/time in America/New_York via InvokeCode: \"\" & exception.Message\"]",
      "fallbackUsed": false,
      "finalValueHash": "77401c65a9a9a702315b21d50bce1c7c8afd118204972d11565dd760a6c4ed16"
    },
    {
      "workflowFile": "BGYY_GetTodaysBirthdays.xaml",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "originalRawValue": "\"[BGYY_GetTodaysBirthdays][DateWindow] TodayEastern=\" & todayEastern.ToString(\"yyyy-MM-dd HH:mm:ss\") & \" | WindowStart=\" & todayStart.ToString(\"yyyy-MM-dd\") & \" | WindowEnd=\" & todayEnd.ToString(\"yyyy-MM-dd\")",
      "parsedIntentType": "pre-assembly:literal",
      "normalizedOutput": "[\"\"\"[BGYY_GetTodaysBirthdays][DateWindow] TodayEastern=\"\" & todayEastern.ToString(\"\"yyyy-MM-dd HH:mm:ss\"\") & \"\" | WindowStart=\"\" & todayStart.ToString(\"\"yyyy-MM-dd\"\") & \"\" | WindowEnd=\"\" & todayEnd.ToString(\"\"yyyy-MM-dd\"\")\"]",
      "fallbackUsed": false,
      "finalValueHash": "14ad47c78684276a85996e48799e5fe4785fe4b9ca2b76aefe29a64a7d69ddfa"
    },
    {
      "workflowFile": "BGYY_GetTodaysBirthdays.xaml",
      "activityType": "LogMessage",
      "propertyName": "Level",
      "originalRawValue": "Info",
      "parsedIntentType": "pre-assembly:literal",
      "normalizedOutput": "\"Info\"",
      "fallbackUsed": false,
      "finalValueHash": "6e68b62d2aa611a44f3e7a4cb7e23da9ad1cab1b6abb592bb2795b12fe63e51c"
    },
    {
      "workflowFile": "BGYY_GetTodaysBirthdays.xaml",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "originalRawValue": "\"[BGYY_GetTodaysBirthdays][CalendarQuery] Success | calendarQuerySuccess=\" & calendarQuerySuccess.ToString() & \" | RawResult type=\" & If(rawCalendarEvents IsNot Nothing, rawCalendarEvents.GetType().Name, \"Nothing\")",
      "parsedIntentType": "pre-assembly:literal",
      "normalizedOutput": "[\"\"\"[BGYY_GetTodaysBirthdays][CalendarQuery] Success | calendarQuerySuccess=\"\" & calendarQuerySuccess.ToString() & \"\" | RawResult type=\"\" & If(rawCalendarEvents IsNot Nothing, rawCalendarEvents.GetType().Name, \"\"Nothing\"\")\"]",
      "fallbackUsed": false,
      "finalValueHash": "6e9490b3c40b05bc3d7f40b49d42b40feaea28d1cdfd46485a6e1133ca76e715"
    },
    {
      "workflowFile": "BGYY_GetTodaysBirthdays.xaml",
      "activityType": "LogMessage",
      "propertyName": "Level",
      "originalRawValue": "Info",
      "parsedIntentType": "pre-assembly:literal",
      "normalizedOutput": "\"Info\"",
      "fallbackUsed": false,
      "finalValueHash": "6e68b62d2aa611a44f3e7a4cb7e23da9ad1cab1b6abb592bb2795b12fe63e51c"
    },
    {
      "workflowFile": "BGYY_GetTodaysBirthdays.xaml",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "originalRawValue": "\"[BGYY_GetTodaysBirthdays][Warn] Google Calendar connector returned Nothing for RunId=\" & InRunId & \" | Treating as zero birthday events today\"",
      "parsedIntentType": "pre-assembly:literal",
      "normalizedOutput": "[\"[BGYY_GetTodaysBirthdays][Warn] Google Calendar connector returned Nothing for RunId=\"\" & InRunId & \"\" | Treating as zero birthday events today\"]",
      "fallbackUsed": false,
      "finalValueHash": "dd366cf5c756f5f562febc39ddad467c523cd5f597ec3dc747d46c3d2ddeadcb"
    },
    {
      "workflowFile": "BGYY_GetTodaysBirthdays.xaml",
      "activityType": "LogMessage",
      "propertyName": "Level",
      "originalRawValue": "Warn",
      "parsedIntentType": "pre-assembly:literal",
      "normalizedOutput": "\"Warn\"",
      "fallbackUsed": false,
      "finalValueHash": "0817e2b865151b33aa686f0551fce818a034cb723e0044e433cd8100810ed280"
    },
    {
      "workflowFile": "BGYY_GetTodaysBirthdays.xaml",
      "activityType": "LogMessage",
      "propertyName": "Level",
      "originalRawValue": "Error",
      "parsedIntentType": "pre-assembly:literal",
      "normalizedOutput": "\"Error\"",
      "fallbackUsed": false,
      "finalValueHash": "fc4ac19649f0ee8f37c71d2e2030a3743038bb96c0c27359ba115dd8657565cc"
    },
    {
      "workflowFile": "BGYY_GetTodaysBirthdays.xaml",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "originalRawValue": "\"Error in Parse raw connector response into enumerable events via InvokeCode: \" & exception.Message",
      "parsedIntentType": "pre-assembly:literal",
      "normalizedOutput": "[\"\"\"Error in Parse raw connector response into enumerable events via InvokeCode: \"\" & exception.Message\"]",
      "fallbackUsed": false,
      "finalValueHash": "faebb02f3be8ee37b55c78aa25dcf3c2b22f94b8bc36f1ab40b9ccc587d3008e"
    },
    {
      "workflowFile": "BGYY_GetTodaysBirthdays.xaml",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "originalRawValue": "\"[BGYY_GetTodaysBirthdays][Parse] RunId=\" & InRunId & \" | BirthdayEventsFound=\" & eventCount.ToString() & \" | Date=\" & todayEastern.ToString(\"yyyy-MM-dd\")",
      "parsedIntentType": "pre-assembly:literal",
      "normalizedOutput": "[\"\"\"[BGYY_GetTodaysBirthdays][Parse] RunId=\"\" & InRunId & \"\" | BirthdayEventsFound=\"\" & eventCount.ToString() & \"\" | Date=\"\" & todayEastern.ToString(\"\"yyyy-MM-dd\"\")\"]",
      "fallbackUsed": false,
      "finalValueHash": "52e70adc26be8d54f2cb82e923fd3c9dcc551a1ec8cbf1cf440b6fb0ced84a04"
    },
    {
      "workflowFile": "BGYY_GetTodaysBirthdays.xaml",
      "activityType": "LogMessage",
      "propertyName": "Level",
      "originalRawValue": "Info",
      "parsedIntentType": "pre-assembly:literal",
      "normalizedOutput": "\"Info\"",
      "fallbackUsed": false,
      "finalValueHash": "6e68b62d2aa611a44f3e7a4cb7e23da9ad1cab1b6abb592bb2795b12fe63e51c"
    },
    {
      "workflowFile": "BGYY_GetTodaysBirthdays.xaml",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "originalRawValue": "\"[BGYY_GetTodaysBirthdays][NoBirthdays] RunId=\" & InRunId & \" | No birthday events in 'Birthdays' calendar for \" & todayEastern.ToString(\"yyyy-MM-dd\") & \" America/New_York — ending cleanly\"",
      "parsedIntentType": "pre-assembly:literal",
      "normalizedOutput": "[\"[BGYY_GetTodaysBirthdays][NoBirthdays] RunId=\"\" & InRunId & \"\" | No birthday events in 'Birthdays' calendar for \"\" & todayEastern.ToString(\"\"yyyy-MM-dd\"\") & \"\" America/New_York — ending cleanly\"]",
      "fallbackUsed": false,
      "finalValueHash": "43981700d0eea5c2587a7bd98fd62ece08129fd466df9a6bba512f5e18bb816e"
    },
    {
      "workflowFile": "BGYY_GetTodaysBirthdays.xaml",
      "activityType": "LogMessage",
      "propertyName": "Level",
      "originalRawValue": "Info",
      "parsedIntentType": "pre-assembly:literal",
      "normalizedOutput": "\"Info\"",
      "fallbackUsed": false,
      "finalValueHash": "6e68b62d2aa611a44f3e7a4cb7e23da9ad1cab1b6abb592bb2795b12fe63e51c"
    },
    {
      "workflowFile": "BGYY_GetTodaysBirthdays.xaml",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "originalRawValue": "\"[BGYY_GetTodaysBirthdays][Exit] RunId=\" & InRunId & \" | OutBirthdayEvents.Rows.Count=\" & birthdayEventsTable.Rows.Count.ToString() & \" | Status=Success\"",
      "parsedIntentType": "pre-assembly:literal",
      "normalizedOutput": "[\"[BGYY_GetTodaysBirthdays][Exit] RunId=\"\" & InRunId & \"\" | OutBirthdayEvents.Rows.Count=\"\" & birthdayEventsTable.Rows.Count.ToString() & \"\" | Status=Success\"]",
      "fallbackUsed": false,
      "finalValueHash": "a30002488671c170208699ee2bfb3a5a4de6dc9a8e3ea75064865b1f1bbac298"
    },
    {
      "workflowFile": "BGYY_GetTodaysBirthdays.xaml",
      "activityType": "LogMessage",
      "propertyName": "Level",
      "originalRawValue": "Info",
      "parsedIntentType": "pre-assembly:literal",
      "normalizedOutput": "\"Info\"",
      "fallbackUsed": false,
      "finalValueHash": "6e68b62d2aa611a44f3e7a4cb7e23da9ad1cab1b6abb592bb2795b12fe63e51c"
    },
    {
      "workflowFile": "unknown",
      "activityType": "InvokeCode",
      "propertyName": "Code",
      "originalRawValue": "{\"type\":\"literal\",\"value\":\"Dim tz As TimeZoneInfo = TimeZoneInfo.FindSystemTimeZoneById(\\\"Eastern Standard Time\\\")\\nDim utcNow As DateTime = DateTime.UtcNow\\nDim eastern As DateTime = TimeZoneInfo.ConvertTimeFromUtc(utcNow, tz)\\ntodayEastern = eastern\\ntodayStart = New DateTime(eastern.Year, eastern.Month, eastern.Day, 0, 0, 0, DateTimeKind.Unspecified)\\ntodayEnd = todayStart.AddDays(1).AddSeconds(-1)\"}",
      "parsedIntentType": "literal",
      "normalizedOutput": "[\"Dim tz As TimeZoneInfo = TimeZoneInfo.FindSystemTimeZoneById(\"\"Eastern Standard Time\"\")\nDim utcNow As DateTime = DateTime.UtcNow\nDim eastern As DateTime = TimeZoneInfo.ConvertTimeFromUtc(utcNow, tz)\ntodayEastern = eastern\ntodayStart = New DateTime(eastern.Year, eastern.Month, eastern.Day, 0, 0, 0, DateTimeKind.Unspecified)\ntodayEnd = todayStart.AddDays(1).AddSeconds(-1)\"]",
      "fallbackUsed": false,
      "finalValueHash": "a85fd104f3d0f10b593df1621e4a833bf839f609d0f1caa03e396f11a27e8246"
    },
    {
      "workflowFile": "unknown",
      "activityType": "ConnectorActivity",
      "propertyName": "ConnectionId",
      "originalRawValue": "{\"type\":\"literal\",\"value\":\"GoogleCalendar\"}",
      "parsedIntentType": "literal",
      "normalizedOutput": "\"GoogleCalendar\"",
      "fallbackUsed": false,
      "finalValueHash": "2f14144f9c45c513c594da776be48a8116b7e2f1e566dde5046affd7ba103200"
    },
    {
      "workflowFile": "unknown",
      "activityType": "InvokeCode",
      "propertyName": "Code",
      "originalRawValue": "{\"type\":\"vb_expression\",\"value\":\"' rawCalendarEvents is expected to be IEnumerable or a JArray/List from the connector\\n' Attempt to cast to IEnumerable(Of Object) and iterate\\nDim events As System.Collections.IEnumerable = TryCast(rawCalendarEvents, System.Collections.IEnumerable)\\nIf events Is Nothing Then\\n    ' Try treating as a single-item wrapper with Items/Value property\\n    Dim t As Type = rawCalendarEvents.GetType()\\n    Dim prop As System.Reflection.PropertyInfo = t.GetProperty(\\\"Item",
      "parsedIntentType": "vb_expression",
      "normalizedOutput": "[' rawCalendarEvents is expected to be IEnumerable or a JArray/List from the connector\n' Attempt to cast to IEnumerable(Of Object) and iterate\nDim events As System.Collections.IEnumerable = TryCast(rawCalendarEvents, System.Collections.IEnumerable)\nIf events Is Nothing Then\n    ' Try treating as a single-item wrapper with Items/Value property\n    Dim t As Type = rawCalendarEvents.GetType()\n    Dim prop As System.Reflection.PropertyInfo = t.GetProperty(\"Items\")\n    If prop IsNot Nothing Then\n    ",
      "fallbackUsed": false,
      "finalValueHash": "e0bbfc737d9b0b6efec23784debf3bfd777aeff5f3d5335a524c179b8afcc458"
    },
    {
      "workflowFile": "BGYY_ResolveRecipient.xaml",
      "activityType": "LogMessage",
      "propertyName": "Level",
      "originalRawValue": "Info",
      "parsedIntentType": "pre-assembly:literal",
      "normalizedOutput": "\"Info\"",
      "fallbackUsed": false,
      "finalValueHash": "6e68b62d2aa611a44f3e7a4cb7e23da9ad1cab1b6abb592bb2795b12fe63e51c"
    },
    {
      "workflowFile": "BGYY_ResolveRecipient.xaml",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "originalRawValue": "\"[BGYY_ResolveRecipient][START] RunId=\" & InRunId & \" | FullName='\" & InFullName & \"'\"",
      "parsedIntentType": "pre-assembly:literal",
      "normalizedOutput": "[\"[BGYY_ResolveRecipient][START] RunId=\"\" & InRunId & \"\" | FullName='\"\" & InFullName & \"\"'\"]",
      "fallbackUsed": false,
      "finalValueHash": "753e420f13dae6b511b309301394221149cecf006b599b6d54bcb9271133eff3"
    },
    {
      "workflowFile": "BGYY_ResolveRecipient.xaml",
      "activityType": "LogMessage",
      "propertyName": "Level",
      "originalRawValue": "Info",
      "parsedIntentType": "pre-assembly:literal",
      "normalizedOutput": "\"Info\"",
      "fallbackUsed": false,
      "finalValueHash": "6e68b62d2aa611a44f3e7a4cb7e23da9ad1cab1b6abb592bb2795b12fe63e51c"
    },
    {
      "workflowFile": "BGYY_ResolveRecipient.xaml",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "originalRawValue": "\"[BGYY_ResolveRecipient] GoogleContacts query complete. FullName='\" & InFullName & \"' | ResultRowCount=\" & If(contactsDataTable IsNot Nothing, contactsDataTable.Rows.Count.ToString(), \"NULL\")",
      "parsedIntentType": "pre-assembly:literal",
      "normalizedOutput": "[\"\"\"[BGYY_ResolveRecipient] GoogleContacts query complete. FullName='\"\" & InFullName & \"\"' | ResultRowCount=\"\" & If(contactsDataTable IsNot Nothing, contactsDataTable.Rows.Count.ToString(), \"\"NULL\"\")\"]",
      "fallbackUsed": false,
      "finalValueHash": "0bdca891910f2aeaf951da2cb951cca47eb25392bea12c1d9e55cc64d3fd02b3"
    },
    {
      "workflowFile": "BGYY_ResolveRecipient.xaml",
      "activityType": "LogMessage",
      "propertyName": "Level",
      "originalRawValue": "Warn",
      "parsedIntentType": "pre-assembly:literal",
      "normalizedOutput": "\"Warn\"",
      "fallbackUsed": false,
      "finalValueHash": "0817e2b865151b33aa686f0551fce818a034cb723e0044e433cd8100810ed280"
    },
    {
      "workflowFile": "BGYY_ResolveRecipient.xaml",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "originalRawValue": "\"[BGYY_ResolveRecipient][SKIP] No contact found in Google Contacts. RunId=\" & InRunId & \" | FullName='\" & InFullName & \"' | NormalizedKey='\" & normalizedName & \"'\"",
      "parsedIntentType": "pre-assembly:literal",
      "normalizedOutput": "[\"[BGYY_ResolveRecipient][SKIP] No contact found in Google Contacts. RunId=\"\" & InRunId & \"\" | FullName='\"\" & InFullName & \"\"' | NormalizedKey='\"\" & normalizedName & \"\"'\"]",
      "fallbackUsed": false,
      "finalValueHash": "d8f674d1a67a8a4a075cbecf4ce5b73856ee6dd1b4c24e2593a75de1116ea1b4"
    },
    {
      "workflowFile": "BGYY_ResolveRecipient.xaml",
      "activityType": "LogMessage",
      "propertyName": "Level",
      "originalRawValue": "Warn",
      "parsedIntentType": "pre-assembly:literal",
      "normalizedOutput": "\"Warn\"",
      "fallbackUsed": false,
      "finalValueHash": "0817e2b865151b33aa686f0551fce818a034cb723e0044e433cd8100810ed280"
    },
    {
      "workflowFile": "BGYY_ResolveRecipient.xaml",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "originalRawValue": "\"[BGYY_ResolveRecipient][AMBIGUOUS] Multiple contacts matched. RunId=\" & InRunId & \" | FullName='\" & InFullName & \"' | MatchCount=\" & contactCount.ToString()",
      "parsedIntentType": "pre-assembly:literal",
      "normalizedOutput": "[\"\"\"[BGYY_ResolveRecipient][AMBIGUOUS] Multiple contacts matched. RunId=\"\" & InRunId & \"\" | FullName='\"\" & InFullName & \"\"' | MatchCount=\"\" & contactCount.ToString()\"]",
      "fallbackUsed": false,
      "finalValueHash": "7796e2750dc56f9c902b32968407026d5bc1b961d6f06dafc7cc57f55b0976b8"
    },
    {
      "workflowFile": "BGYY_ResolveRecipient.xaml",
      "activityType": "LogMessage",
      "propertyName": "Level",
      "originalRawValue": "Error",
      "parsedIntentType": "pre-assembly:literal",
      "normalizedOutput": "\"Error\"",
      "fallbackUsed": false,
      "finalValueHash": "fc4ac19649f0ee8f37c71d2e2030a3743038bb96c0c27359ba115dd8657565cc"
    },
    {
      "workflowFile": "BGYY_ResolveRecipient.xaml",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "originalRawValue": "\"Error in Extract single matching contact row from DataTable: \" & exception.Message",
      "parsedIntentType": "pre-assembly:literal",
      "normalizedOutput": "[\"\"\"Error in Extract single matching contact row from DataTable: \"\" & exception.Message\"]",
      "fallbackUsed": false,
      "finalValueHash": "ff9c64e17d112bfcbd4daf7c0920094fa90e789e97d96ed0bba2e8290540714b"
    },
    {
      "workflowFile": "BGYY_ResolveRecipient.xaml",
      "activityType": "LogMessage",
      "propertyName": "Level",
      "originalRawValue": "Error",
      "parsedIntentType": "pre-assembly:literal",
      "normalizedOutput": "\"Error\"",
      "fallbackUsed": false,
      "finalValueHash": "fc4ac19649f0ee8f37c71d2e2030a3743038bb96c0c27359ba115dd8657565cc"
    },
    {
      "workflowFile": "BGYY_ResolveRecipient.xaml",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "originalRawValue": "\"Error in Extract email addresses collection from contact (try 'personal' column first): \" & exception.Message",
      "parsedIntentType": "pre-assembly:literal",
      "normalizedOutput": "[\"\"\"Error in Extract email addresses collection from contact (try 'personal' column first): \"\" & exception.Message\"]",
      "fallbackUsed": false,
      "finalValueHash": "c9ea2f499379131d4501cfa656c8fc4646387e91013ed9f33bf39cdd908c4e8a"
    },
    {
      "workflowFile": "BGYY_ResolveRecipient.xaml",
      "activityType": "LogMessage",
      "propertyName": "Level",
      "originalRawValue": "Error",
      "parsedIntentType": "pre-assembly:literal",
      "normalizedOutput": "\"Error\"",
      "fallbackUsed": false,
      "finalValueHash": "fc4ac19649f0ee8f37c71d2e2030a3743038bb96c0c27359ba115dd8657565cc"
    },
    {
      "workflowFile": "BGYY_ResolveRecipient.xaml",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "originalRawValue": "\"Error in Extract home email from contact row: \" & exception.Message",
      "parsedIntentType": "pre-assembly:literal",
      "normalizedOutput": "[\"\"\"Error in Extract home email from contact row: \"\" & exception.Message\"]",
      "fallbackUsed": false,
      "finalValueHash": "595f7da446e52f54cc8e6df7d3299a91c3201a637c3c94878282f894e61e0a0a"
    },
    {
      "workflowFile": "BGYY_ResolveRecipient.xaml",
      "activityType": "LogMessage",
      "propertyName": "Level",
      "originalRawValue": "Info",
      "parsedIntentType": "pre-assembly:literal",
      "normalizedOutput": "\"Info\"",
      "fallbackUsed": false,
      "finalValueHash": "6e68b62d2aa611a44f3e7a4cb7e23da9ad1cab1b6abb592bb2795b12fe63e51c"
    },
    {
      "workflowFile": "BGYY_ResolveRecipient.xaml",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "originalRawValue": "\"[BGYY_ResolveRecipient] Email label scan complete. RunId=\" & InRunId & \" | FullName='\" & InFullName & \"' | PersonalEmailFound=\" & (personalEmail <> \"\").ToString() & \" | HomeEmailFound=\" & (homeEmail <> \"\").ToString()",
      "parsedIntentType": "pre-assembly:literal",
      "normalizedOutput": "[\"\"\"[BGYY_ResolveRecipient] Email label scan complete. RunId=\"\" & InRunId & \"\" | FullName='\"\" & InFullName & \"\"' | PersonalEmailFound=\"\" & (personalEmail <> \"\"\"\").ToString() & \"\" | HomeEmailFound=\"\" & (homeEmail <> \"\"\"\").ToString()\"]",
      "fallbackUsed": false,
      "finalValueHash": "1140a26ca328cd6b920dd6b9135d9e065b8beda3ec6707307e991a0418f23e78"
    },
    {
      "workflowFile": "BGYY_ResolveRecipient.xaml",
      "activityType": "LogMessage",
      "propertyName": "Level",
      "originalRawValue": "Info",
      "parsedIntentType": "pre-assembly:literal",
      "normalizedOutput": "\"Info\"",
      "fallbackUsed": false,
      "finalValueHash": "6e68b62d2aa611a44f3e7a4cb7e23da9ad1cab1b6abb592bb2795b12fe63e51c"
    },
    {
      "workflowFile": "BGYY_ResolveRecipient.xaml",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "originalRawValue": "\"[BGYY_ResolveRecipient] Selected email label=personal. RunId=\" & InRunId & \" | FullName='\" & InFullName & \"'\"",
      "parsedIntentType": "pre-assembly:literal",
      "normalizedOutput": "[\"[BGYY_ResolveRecipient] Selected email label=personal. RunId=\"\" & InRunId & \"\" | FullName='\"\" & InFullName & \"\"'\"]",
      "fallbackUsed": false,
      "finalValueHash": "fabe08766704cd766bea0b8fdffde2f1243c2254593cafbb6091faec0e3294dc"
    },
    {
      "workflowFile": "BGYY_ResolveRecipient.xaml",
      "activityType": "LogMessage",
      "propertyName": "Level",
      "originalRawValue": "Info",
      "parsedIntentType": "pre-assembly:literal",
      "normalizedOutput": "\"Info\"",
      "fallbackUsed": false,
      "finalValueHash": "6e68b62d2aa611a44f3e7a4cb7e23da9ad1cab1b6abb592bb2795b12fe63e51c"
    },
    {
      "workflowFile": "BGYY_ResolveRecipient.xaml",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "originalRawValue": "\"[BGYY_ResolveRecipient] Selected email label=home (fallback, no personal found). RunId=\" & InRunId & \" | FullName='\" & InFullName & \"'\"",
      "parsedIntentType": "pre-assembly:literal",
      "normalizedOutput": "[\"[BGYY_ResolveRecipient] Selected email label=home (fallback, no personal found). RunId=\"\" & InRunId & \"\" | FullName='\"\" & InFullName & \"\"'\"]",
      "fallbackUsed": false,
      "finalValueHash": "f0fde3e55da68b3101376ea71e92faddc542ff45da712548571fea0e29d26ff6"
    },
    {
      "workflowFile": "BGYY_ResolveRecipient.xaml",
      "activityType": "LogMessage",
      "propertyName": "Level",
      "originalRawValue": "Warn",
      "parsedIntentType": "pre-assembly:literal",
      "normalizedOutput": "\"Warn\"",
      "fallbackUsed": false,
      "finalValueHash": "0817e2b865151b33aa686f0551fce818a034cb723e0044e433cd8100810ed280"
    },
    {
      "workflowFile": "BGYY_ResolveRecipient.xaml",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "originalRawValue": "\"[BGYY_ResolveRecipient][SKIP] Contact found but no personal/home email label present. RunId=\" & InRunId & \" | FullName='\" & InFullName & \"'\"",
      "parsedIntentType": "pre-assembly:literal",
      "normalizedOutput": "[\"[BGYY_ResolveRecipient][SKIP] Contact found but no personal/home email label present. RunId=\"\" & InRunId & \"\" | FullName='\"\" & InFullName & \"\"'\"]",
      "fallbackUsed": false,
      "finalValueHash": "366ffc6793e76e8b80901db83a684604e068445c3f87ae730985a2c5b7547c73"
    },
    {
      "workflowFile": "BGYY_ResolveRecipient.xaml",
      "activityType": "LogMessage",
      "propertyName": "Level",
      "originalRawValue": "Info",
      "parsedIntentType": "pre-assembly:literal",
      "normalizedOutput": "\"Info\"",
      "fallbackUsed": false,
      "finalValueHash": "6e68b62d2aa611a44f3e7a4cb7e23da9ad1cab1b6abb592bb2795b12fe63e51c"
    },
    {
      "workflowFile": "BGYY_ResolveRecipient.xaml",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "originalRawValue": "\"[BGYY_ResolveRecipient][END-SUCCESS] Recipient resolved. RunId=\" & InRunId & \" | FullName='\" & InFullName & \"' | EmailResolved=True\"",
      "parsedIntentType": "pre-assembly:literal",
      "normalizedOutput": "[\"[BGYY_ResolveRecipient][END-SUCCESS] Recipient resolved. RunId=\"\" & InRunId & \"\" | FullName='\"\" & InFullName & \"\"' | EmailResolved=True\"]",
      "fallbackUsed": false,
      "finalValueHash": "9c9f66abdb852b12976212d77925c010a33727d95a406068ba2cbe54ad3e8dd0"
    },
    {
      "workflowFile": "BGYY_ResolveRecipient.xaml",
      "activityType": "LogMessage",
      "propertyName": "Level",
      "originalRawValue": "Error",
      "parsedIntentType": "pre-assembly:literal",
      "normalizedOutput": "\"Error\"",
      "fallbackUsed": false,
      "finalValueHash": "fc4ac19649f0ee8f37c71d2e2030a3743038bb96c0c27359ba115dd8657565cc"
    },
    {
      "workflowFile": "BGYY_ResolveRecipient.xaml",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "originalRawValue": "\"[BGYY_ResolveRecipient][ERROR] Google Contacts connector failed after all retries. RunId=\" & InRunId & \" | FullName='\" & InFullName & \"' | ExceptionType=\" & connectorException.GetType().Name & \" | Message=\" & connectorException.Message",
      "parsedIntentType": "pre-assembly:literal",
      "normalizedOutput": "[\"\"\"[BGYY_ResolveRecipient][ERROR] Google Contacts connector failed after all retries. RunId=\"\" & InRunId & \"\" | FullName='\"\" & InFullName & \"\"' | ExceptionType=\"\" & connectorException.GetType().Name & \"\" | Message=\"\" & connectorException.Message\"]",
      "fallbackUsed": false,
      "finalValueHash": "da8ed4c090ff50a1e65a7c57bcbb07a09b3f7660a25174c527555f03fc141341"
    },
    {
      "workflowFile": "unknown",
      "activityType": "GoogleContactsSearchContacts",
      "propertyName": "Query",
      "originalRawValue": "{\"type\":\"variable\",\"name\":\"InFullName\"}",
      "parsedIntentType": "variable",
      "normalizedOutput": "[InFullName]",
      "fallbackUsed": false,
      "finalValueHash": "c714685f3545fdb48b129401b9663aee50be9f2f1594fceae2d80056827f8fde"
    },
    {
      "workflowFile": "BGYY_CheckDedupe.xaml",
      "activityType": "LogMessage",
      "propertyName": "Level",
      "originalRawValue": "Info",
      "parsedIntentType": "pre-assembly:literal",
      "normalizedOutput": "\"Info\"",
      "fallbackUsed": false,
      "finalValueHash": "6e68b62d2aa611a44f3e7a4cb7e23da9ad1cab1b6abb592bb2795b12fe63e51c"
    },
    {
      "workflowFile": "BGYY_CheckDedupe.xaml",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "originalRawValue": "[BGYY_CheckDedupe] Starting dedupe check — PersonKey='\" & in_PersonKey & \"', SendYear=\" & in_SendYear.ToString()",
      "parsedIntentType": "pre-assembly:literal",
      "normalizedOutput": "[\"[BGYY_CheckDedupe] Starting dedupe check — PersonKey='\"\" & in_PersonKey & \"\"', SendYear=\"\" & in_SendYear.ToString()\"]",
      "fallbackUsed": false,
      "finalValueHash": "461111f42eecac03f11b49f2cb47cfd00e96661bc1a8b36306d0d7b7edfaf822"
    },
    {
      "workflowFile": "BGYY_CheckDedupe.xaml",
      "activityType": "Throw",
      "propertyName": "Exception",
      "originalRawValue": "New ArgumentException(\"[BGYY_CheckDedupe] in_PersonKey is null or empty — cannot perform dedupe query. Caller must normalize and pass a valid PersonKey.\")",
      "parsedIntentType": "pre-assembly:literal",
      "normalizedOutput": "[\"New ArgumentException(\"\"[BGYY_CheckDedupe] in_PersonKey is null or empty — cannot perform dedupe query. Caller must normalize and pass a valid PersonKey.\"\")\"]",
      "fallbackUsed": false,
      "finalValueHash": "6acd6bdba837f768fa3e24305bbcb34c410853d9703edc5d10a264fc425c6ed3"
    },
    {
      "workflowFile": "BGYY_CheckDedupe.xaml",
      "activityType": "Assign",
      "propertyName": "Value",
      "originalRawValue": "\"PersonKey = '\" & in_PersonKey & \"' AND SendYear = \" & in_SendYear.ToString()",
      "parsedIntentType": "pre-assembly:literal",
      "normalizedOutput": "[\"\"\"PersonKey = '\"\" & in_PersonKey & \"\"' AND SendYear = \"\" & in_SendYear.ToString()\"]",
      "fallbackUsed": false,
      "finalValueHash": "d2d7b9c2b66cd4067eacd05273cbf2d4f91555ddc1db679a27816fff47bf7be5"
    },
    {
      "workflowFile": "BGYY_CheckDedupe.xaml",
      "activityType": "QueryEntity",
      "propertyName": "EntityType",
      "originalRawValue": "BGYY_BirthdaySendLog",
      "parsedIntentType": "pre-assembly:literal",
      "normalizedOutput": "\"BGYY_BirthdaySendLog\"",
      "fallbackUsed": false,
      "finalValueHash": "b004731817a34b4b0811c2cd720f3a3479712719e123cd47f1a76b71faf3049f"
    },
    {
      "workflowFile": "BGYY_CheckDedupe.xaml",
      "activityType": "QueryEntity",
      "propertyName": "Top",
      "originalRawValue": "1",
      "parsedIntentType": "pre-assembly:literal",
      "normalizedOutput": "\"1\"",
      "fallbackUsed": false,
      "finalValueHash": "391552c099c101b131feaf24c5795a6a15bc8ec82015424e0d2b4274a369a0bf"
    },
    {
      "workflowFile": "BGYY_CheckDedupe.xaml",
      "activityType": "LogMessage",
      "propertyName": "Level",
      "originalRawValue": "Info",
      "parsedIntentType": "pre-assembly:literal",
      "normalizedOutput": "\"Info\"",
      "fallbackUsed": false,
      "finalValueHash": "6e68b62d2aa611a44f3e7a4cb7e23da9ad1cab1b6abb592bb2795b12fe63e51c"
    },
    {
      "workflowFile": "BGYY_CheckDedupe.xaml",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "originalRawValue": "[BGYY_CheckDedupe] QueryEntity completed for PersonKey='\" & in_PersonKey & \"', SendYear=\" & in_SendYear.ToString() & \". Result is Nothing: \" & (obj_QueryResults Is Nothing).ToString()",
      "parsedIntentType": "pre-assembly:literal",
      "normalizedOutput": "[\"[BGYY_CheckDedupe] QueryEntity completed for PersonKey='\"\" & in_PersonKey & \"\"', SendYear=\"\" & in_SendYear.ToString() & \"\". Result is Nothing: \"\" & (obj_QueryResults Is Nothing).ToString()\"]",
      "fallbackUsed": false,
      "finalValueHash": "8117af36844a21efa4096c681a6ea9be4895bc64420d4815f7929884c6da8a1b"
    },
    {
      "workflowFile": "BGYY_CheckDedupe.xaml",
      "activityType": "Assign",
      "propertyName": "Value",
      "originalRawValue": "If(obj_QueryResults IsNot Nothing, obj_QueryResults, New List(Of Object))",
      "parsedIntentType": "pre-assembly:literal",
      "normalizedOutput": "\"[If(obj_QueryResults IsNot Nothing, obj_QueryResults, New List(Of Object))]\"",
      "fallbackUsed": false,
      "finalValueHash": "a42e80b626976d17f291e96193c030d413c3a0c94451f60efb438a7b420d93eb"
    },
    {
      "workflowFile": "BGYY_CheckDedupe.xaml",
      "activityType": "Assign",
      "propertyName": "Value",
      "originalRawValue": "If(obj_QueryResultList IsNot Nothing, DirectCast(obj_QueryResultList, System.Collections.IList).Count, 0)",
      "parsedIntentType": "pre-assembly:literal",
      "normalizedOutput": "\"[If(obj_QueryResultList IsNot Nothing, DirectCast(obj_QueryResultList, System.Collections.IList).Count, 0)]\"",
      "fallbackUsed": false,
      "finalValueHash": "e42c943717af2f4d22788c84a29ea6b0a179882ae3355c80e2173dc973643653"
    },
    {
      "workflowFile": "BGYY_CheckDedupe.xaml",
      "activityType": "Assign",
      "propertyName": "Value",
      "originalRawValue": "True",
      "parsedIntentType": "pre-assembly:literal",
      "normalizedOutput": "\"True\"",
      "fallbackUsed": false,
      "finalValueHash": "76c777b0ce3c35ba97c6cbdeea2a08cf31ebcd274fa0190aa83db5bc8742ae1e"
    },
    {
      "workflowFile": "BGYY_CheckDedupe.xaml",
      "activityType": "Assign",
      "propertyName": "Value",
      "originalRawValue": "DirectCast(DirectCast(obj_QueryResultList, System.Collections.IList)(0), UiPath.DataService.ApiClient.Models.EntityRecord)(\"Id\").ToString()",
      "parsedIntentType": "pre-assembly:literal",
      "normalizedOutput": "[\"[DirectCast(DirectCast(obj_QueryResultList, System.Collections.IList)(0), UiPath.DataService.ApiClient.Models.EntityRecord)(\"\"Id\"\").ToString()]\"]",
      "fallbackUsed": false,
      "finalValueHash": "f36c4466df4308e0b6537391066b68058a90265acbaa0d5f559bba3db4e5cd9f"
    },
    {
      "workflowFile": "BGYY_CheckDedupe.xaml",
      "activityType": "LogMessage",
      "propertyName": "Level",
      "originalRawValue": "Warn",
      "parsedIntentType": "pre-assembly:literal",
      "normalizedOutput": "\"Warn\"",
      "fallbackUsed": false,
      "finalValueHash": "0817e2b865151b33aa686f0551fce818a034cb723e0044e433cd8100810ed280"
    },
    {
      "workflowFile": "BGYY_CheckDedupe.xaml",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "originalRawValue": "[BGYY_CheckDedupe] Dedupe HIT — PersonKey='\" & in_PersonKey & \"', SendYear=\" & in_SendYear.ToString() & \", ExistingRecordId='\" & str_ExistingRecordId & \"'. Greeting already sent this year — skipping.",
      "parsedIntentType": "pre-assembly:literal",
      "normalizedOutput": "[\"[BGYY_CheckDedupe] Dedupe HIT — PersonKey='\"\" & in_PersonKey & \"\"', SendYear=\"\" & in_SendYear.ToString() & \"\", ExistingRecordId='\"\" & str_ExistingRecordId & \"\"'. Greeting already sent this year — skipping.\"]",
      "fallbackUsed": false,
      "finalValueHash": "b616b4867d6b5b90eefccf49fba36fac4ac7685f21c909286917dfa3c9cdd55b"
    },
    {
      "workflowFile": "BGYY_CheckDedupe.xaml",
      "activityType": "Assign",
      "propertyName": "Value",
      "originalRawValue": "False",
      "parsedIntentType": "pre-assembly:literal",
      "normalizedOutput": "\"False\"",
      "fallbackUsed": false,
      "finalValueHash": "cea17e0b05e3e6ace77ec2d13b5870803ef957ad160f289cca6a3a4a826d20af"
    },
    {
      "workflowFile": "BGYY_CheckDedupe.xaml",
      "activityType": "LogMessage",
      "propertyName": "Level",
      "originalRawValue": "Info",
      "parsedIntentType": "pre-assembly:literal",
      "normalizedOutput": "\"Info\"",
      "fallbackUsed": false,
      "finalValueHash": "6e68b62d2aa611a44f3e7a4cb7e23da9ad1cab1b6abb592bb2795b12fe63e51c"
    },
    {
      "workflowFile": "BGYY_CheckDedupe.xaml",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "originalRawValue": "[BGYY_CheckDedupe] Dedupe MISS — PersonKey='\" & in_PersonKey & \"', SendYear=\" & in_SendYear.ToString() & \". No prior send record found — safe to proceed.",
      "parsedIntentType": "pre-assembly:literal",
      "normalizedOutput": "[\"[BGYY_CheckDedupe] Dedupe MISS — PersonKey='\"\" & in_PersonKey & \"\"', SendYear=\"\" & in_SendYear.ToString() & \"\". No prior send record found — safe to proceed.\"]",
      "fallbackUsed": false,
      "finalValueHash": "2fca5f2fa468744a4bd2e745fb22a936868b43d7275fed20f59fd8f4bf4f66c4"
    },
    {
      "workflowFile": "BGYY_CheckDedupe.xaml",
      "activityType": "Assign",
      "propertyName": "To",
      "originalRawValue": "out_AlreadySent",
      "parsedIntentType": "pre-assembly:variable",
      "normalizedOutput": "[out_AlreadySent]",
      "fallbackUsed": false,
      "finalValueHash": "d8e93be45fc019953687098ee2905a63ca4a00c0fe5ff504f218663a2f76d7cb"
    },
    {
      "workflowFile": "BGYY_CheckDedupe.xaml",
      "activityType": "Assign",
      "propertyName": "To",
      "originalRawValue": "out_ExistingRecordId",
      "parsedIntentType": "pre-assembly:variable",
      "normalizedOutput": "[out_ExistingRecordId]",
      "fallbackUsed": false,
      "finalValueHash": "589403536b489816842942cd8e6c43bd07d29c1221267c4993b949cc8a9a4e87"
    },
    {
      "workflowFile": "BGYY_CheckDedupe.xaml",
      "activityType": "LogMessage",
      "propertyName": "Level",
      "originalRawValue": "Error",
      "parsedIntentType": "pre-assembly:literal",
      "normalizedOutput": "\"Error\"",
      "fallbackUsed": false,
      "finalValueHash": "fc4ac19649f0ee8f37c71d2e2030a3743038bb96c0c27359ba115dd8657565cc"
    },
    {
      "workflowFile": "BGYY_CheckDedupe.xaml",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "originalRawValue": "[BGYY_CheckDedupe] ERROR querying BGYY_BirthdaySendLog for PersonKey='\" & in_PersonKey & \"', SendYear=\" & in_SendYear.ToString() & \". Exception: \" & ex_DedupeQuery.Message",
      "parsedIntentType": "pre-assembly:literal",
      "normalizedOutput": "[\"[BGYY_CheckDedupe] ERROR querying BGYY_BirthdaySendLog for PersonKey='\"\" & in_PersonKey & \"\"', SendYear=\"\" & in_SendYear.ToString() & \"\". Exception: \"\" & ex_DedupeQuery.Message\"]",
      "fallbackUsed": false,
      "finalValueHash": "79febbc8ff4b5c57772ea49224fdd41ea26487db1f9dbe0bebfb61a563acaffb"
    },
    {
      "workflowFile": "BGYY_CheckDedupe.xaml",
      "activityType": "Assign",
      "propertyName": "Value",
      "originalRawValue": "False",
      "parsedIntentType": "pre-assembly:literal",
      "normalizedOutput": "\"False\"",
      "fallbackUsed": false,
      "finalValueHash": "cea17e0b05e3e6ace77ec2d13b5870803ef957ad160f289cca6a3a4a826d20af"
    },
    {
      "workflowFile": "BGYY_CheckDedupe.xaml",
      "activityType": "Assign",
      "propertyName": "To",
      "originalRawValue": "out_AlreadySent",
      "parsedIntentType": "pre-assembly:variable",
      "normalizedOutput": "[out_AlreadySent]",
      "fallbackUsed": false,
      "finalValueHash": "d8e93be45fc019953687098ee2905a63ca4a00c0fe5ff504f218663a2f76d7cb"
    },
    {
      "workflowFile": "BGYY_CheckDedupe.xaml",
      "activityType": "Assign",
      "propertyName": "Value",
      "originalRawValue": "False",
      "parsedIntentType": "pre-assembly:literal",
      "normalizedOutput": "\"False\"",
      "fallbackUsed": false,
      "finalValueHash": "cea17e0b05e3e6ace77ec2d13b5870803ef957ad160f289cca6a3a4a826d20af"
    },
    {
      "workflowFile": "BGYY_CheckDedupe.xaml",
      "activityType": "Assign",
      "propertyName": "To",
      "originalRawValue": "out_ExistingRecordId",
      "parsedIntentType": "pre-assembly:variable",
      "normalizedOutput": "[out_ExistingRecordId]",
      "fallbackUsed": false,
      "finalValueHash": "589403536b489816842942cd8e6c43bd07d29c1221267c4993b949cc8a9a4e87"
    },
    {
      "workflowFile": "BGYY_CheckDedupe.xaml",
      "activityType": "Assign",
      "propertyName": "Value",
      "originalRawValue": "\"\"",
      "parsedIntentType": "pre-assembly:literal",
      "normalizedOutput": "\"\"",
      "fallbackUsed": false,
      "finalValueHash": "12ae32cb1ec02d01eda3581b127c1fee3b0dc53572ed6baf239721a03d82e126"
    },
    {
      "workflowFile": "BGYY_CheckDedupe.xaml",
      "activityType": "LogMessage",
      "propertyName": "Level",
      "originalRawValue": "Info",
      "parsedIntentType": "pre-assembly:literal",
      "normalizedOutput": "\"Info\"",
      "fallbackUsed": false,
      "finalValueHash": "6e68b62d2aa611a44f3e7a4cb7e23da9ad1cab1b6abb592bb2795b12fe63e51c"
    },
    {
      "workflowFile": "BGYY_CheckDedupe.xaml",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "originalRawValue": "[BGYY_CheckDedupe] Dedupe check complete — PersonKey='\" & in_PersonKey & \"', SendYear=\" & in_SendYear.ToString() & \", AlreadySent=\" & bool_AlreadySent.ToString() & \", ExistingRecordId='\" & str_ExistingRecordId & \"'.",
      "parsedIntentType": "pre-assembly:literal",
      "normalizedOutput": "[\"[BGYY_CheckDedupe] Dedupe check complete — PersonKey='\"\" & in_PersonKey & \"\"', SendYear=\"\" & in_SendYear.ToString() & \"\", AlreadySent=\"\" & bool_AlreadySent.ToString() & \"\", ExistingRecordId='\"\" & str_ExistingRecordId & \"\"'.\"]",
      "fallbackUsed": false,
      "finalValueHash": "4c663b2f9491b8a546f74224c2d84dd28fe9c9d24073465308065b52f5dbe88a"
    },
    {
      "workflowFile": "unknown",
      "activityType": "QueryEntity",
      "propertyName": "EntityType",
      "originalRawValue": "{\"type\":\"literal\",\"value\":\"BGYY_BirthdaySendLog\"}",
      "parsedIntentType": "literal",
      "normalizedOutput": "\"BGYY_BirthdaySendLog\"",
      "fallbackUsed": false,
      "finalValueHash": "b004731817a34b4b0811c2cd720f3a3479712719e123cd47f1a76b71faf3049f"
    },
    {
      "workflowFile": "unknown",
      "activityType": "QueryEntity",
      "propertyName": "Top",
      "originalRawValue": "{\"type\":\"literal\",\"value\":\"1\"}",
      "parsedIntentType": "literal",
      "normalizedOutput": "\"1\"",
      "fallbackUsed": false,
      "finalValueHash": "391552c099c101b131feaf24c5795a6a15bc8ec82015424e0d2b4274a369a0bf"
    },
    {
      "workflowFile": "BGYY_GenerateDraft.xaml",
      "activityType": "LogMessage",
      "propertyName": "Level",
      "originalRawValue": "Info",
      "parsedIntentType": "pre-assembly:literal",
      "normalizedOutput": "\"Info\"",
      "fallbackUsed": false,
      "finalValueHash": "6e68b62d2aa611a44f3e7a4cb7e23da9ad1cab1b6abb592bb2795b12fe63e51c"
    },
    {
      "workflowFile": "BGYY_GenerateDraft.xaml",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "originalRawValue": "\"[BGYY_GenerateDraft] START | RunId=\" & InRunId & \" | FullName=\" & InFullName",
      "parsedIntentType": "pre-assembly:literal",
      "normalizedOutput": "[\"\"\"[BGYY_GenerateDraft] START | RunId=\"\" & InRunId & \"\" | FullName=\"\" & InFullName\"]",
      "fallbackUsed": false,
      "finalValueHash": "a0fe1be4d7ff81bf89cd764af7db885603333647c767638725fd071f54c7fef5"
    },
    {
      "workflowFile": "BGYY_GenerateDraft.xaml",
      "activityType": "QueryEntity",
      "propertyName": "EntityType",
      "originalRawValue": "BGYY_VoiceProfile",
      "parsedIntentType": "pre-assembly:literal",
      "normalizedOutput": "\"BGYY_VoiceProfile\"",
      "fallbackUsed": false,
      "finalValueHash": "cea3f80968d76bbaf6f6684ed95afd8320682b388c3b2c575d9f804fc5867b61"
    },
    {
      "workflowFile": "BGYY_GenerateDraft.xaml",
      "activityType": "LogMessage",
      "propertyName": "Level",
      "originalRawValue": "Error",
      "parsedIntentType": "pre-assembly:literal",
      "normalizedOutput": "\"Error\"",
      "fallbackUsed": false,
      "finalValueHash": "fc4ac19649f0ee8f37c71d2e2030a3743038bb96c0c27359ba115dd8657565cc"
    },
    {
      "workflowFile": "BGYY_GenerateDraft.xaml",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "originalRawValue": "\"Error in Query BGYY_VoiceProfile Data Service entity for Default profile: \" & exception.Message",
      "parsedIntentType": "pre-assembly:literal",
      "normalizedOutput": "[\"\"\"Error in Query BGYY_VoiceProfile Data Service entity for Default profile: \"\" & exception.Message\"]",
      "fallbackUsed": false,
      "finalValueHash": "37aca5f653586b1fc91b168b8ea2c45362c6179f5f45fde02e93e6b3c301a690"
    },
    {
      "workflowFile": "BGYY_GenerateDraft.xaml",
      "activityType": "LogMessage",
      "propertyName": "Level",
      "originalRawValue": "Warn",
      "parsedIntentType": "pre-assembly:literal",
      "normalizedOutput": "\"Warn\"",
      "fallbackUsed": false,
      "finalValueHash": "0817e2b865151b33aa686f0551fce818a034cb723e0044e433cd8100810ed280"
    },
    {
      "workflowFile": "BGYY_GenerateDraft.xaml",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "originalRawValue": "\"[BGYY_GenerateDraft] WARN | Data Service unavailable for BGYY_VoiceProfile query; using hardcoded defaults | RunId=\" & InRunId & \" | FullName=\" & InFullName",
      "parsedIntentType": "pre-assembly:literal",
      "normalizedOutput": "[\"\"\"[BGYY_GenerateDraft] WARN | Data Service unavailable for BGYY_VoiceProfile query; using hardcoded defaults | RunId=\"\" & InRunId & \"\" | FullName=\"\" & InFullName\"]",
      "fallbackUsed": false,
      "finalValueHash": "8d498fb5588d1f5e5b9fefbafccccd0962f9ae8edc75dd5bb658cf09c7d3c11e"
    },
    {
      "workflowFile": "BGYY_GenerateDraft.xaml",
      "activityType": "LogMessage",
      "propertyName": "Level",
      "originalRawValue": "Info",
      "parsedIntentType": "pre-assembly:literal",
      "normalizedOutput": "\"Info\"",
      "fallbackUsed": false,
      "finalValueHash": "6e68b62d2aa611a44f3e7a4cb7e23da9ad1cab1b6abb592bb2795b12fe63e51c"
    },
    {
      "workflowFile": "BGYY_GenerateDraft.xaml",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "originalRawValue": "\"[BGYY_GenerateDraft] INFO | Voice profile loaded from Data Service | RunId=\" & InRunId",
      "parsedIntentType": "pre-assembly:literal",
      "normalizedOutput": "[\"\"\"[BGYY_GenerateDraft] INFO | Voice profile loaded from Data Service | RunId=\"\" & InRunId\"]",
      "fallbackUsed": false,
      "finalValueHash": "5ffbb22e86b5fb6444319042533d3e5ca5b5a3176e4aba2242fa8e0aab42781f"
    },
    {
      "workflowFile": "BGYY_GenerateDraft.xaml",
      "activityType": "LogMessage",
      "propertyName": "Level",
      "originalRawValue": "Error",
      "parsedIntentType": "pre-assembly:literal",
      "normalizedOutput": "\"Error\"",
      "fallbackUsed": false,
      "finalValueHash": "fc4ac19649f0ee8f37c71d2e2030a3743038bb96c0c27359ba115dd8657565cc"
    },
    {
      "workflowFile": "BGYY_GenerateDraft.xaml",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "originalRawValue": "\"Error in Assign voice profile fields from Data Service record: \" & exception.Message",
      "parsedIntentType": "pre-assembly:literal",
      "normalizedOutput": "[\"\"\"Error in Assign voice profile fields from Data Service record: \"\" & exception.Message\"]",
      "fallbackUsed": false,
      "finalValueHash": "e9b2aa951d40fb4b5d1ad8fc8c535dbcb0f4308349c113e0774ba56e331e693e"
    },
    {
      "workflowFile": "BGYY_GenerateDraft.xaml",
      "activityType": "LogMessage",
      "propertyName": "Level",
      "originalRawValue": "Warn",
      "parsedIntentType": "pre-assembly:literal",
      "normalizedOutput": "\"Warn\"",
      "fallbackUsed": false,
      "finalValueHash": "0817e2b865151b33aa686f0551fce818a034cb723e0044e433cd8100810ed280"
    },
    {
      "workflowFile": "BGYY_GenerateDraft.xaml",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "originalRawValue": "\"[BGYY_GenerateDraft] WARN | No BGYY_VoiceProfile Default record found; using hardcoded defaults | RunId=\" & InRunId",
      "parsedIntentType": "pre-assembly:literal",
      "normalizedOutput": "[\"\"\"[BGYY_GenerateDraft] WARN | No BGYY_VoiceProfile Default record found; using hardcoded defaults | RunId=\"\" & InRunId\"]",
      "fallbackUsed": false,
      "finalValueHash": "f9f0ae983fce9d5de85e078b5ed20dceb99cfb09f70d63895b0052c20dc727a6"
    },
    {
      "workflowFile": "BGYY_GenerateDraft.xaml",
      "activityType": "ReadStorageText",
      "propertyName": "Path",
      "originalRawValue": "prompt_templates/voice_prompt.txt",
      "parsedIntentType": "pre-assembly:literal",
      "normalizedOutput": "\"prompt_templates/voice_prompt.txt\"",
      "fallbackUsed": false,
      "finalValueHash": "ea0ecf332b92d2f067f838d1fd58be310d51b59f0686856f85dc09334c193d4e"
    },
    {
      "workflowFile": "BGYY_GenerateDraft.xaml",
      "activityType": "LogMessage",
      "propertyName": "Level",
      "originalRawValue": "Error",
      "parsedIntentType": "pre-assembly:literal",
      "normalizedOutput": "\"Error\"",
      "fallbackUsed": false,
      "finalValueHash": "fc4ac19649f0ee8f37c71d2e2030a3743038bb96c0c27359ba115dd8657565cc"
    },
    {
      "workflowFile": "BGYY_GenerateDraft.xaml",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "originalRawValue": "\"Error in Read voice prompt template from BGYY_RunArtifacts Storage Bucket: \" & exception.Message",
      "parsedIntentType": "pre-assembly:literal",
      "normalizedOutput": "[\"\"\"Error in Read voice prompt template from BGYY_RunArtifacts Storage Bucket: \"\" & exception.Message\"]",
      "fallbackUsed": false,
      "finalValueHash": "3fd344a191024b672f41a991de47edbfb4234b13db289ef839f250f372ec3426"
    },
    {
      "workflowFile": "BGYY_GenerateDraft.xaml",
      "activityType": "LogMessage",
      "propertyName": "Level",
      "originalRawValue": "Warn",
      "parsedIntentType": "pre-assembly:literal",
      "normalizedOutput": "\"Warn\"",
      "fallbackUsed": false,
      "finalValueHash": "0817e2b865151b33aa686f0551fce818a034cb723e0044e433cd8100810ed280"
    },
    {
      "workflowFile": "BGYY_GenerateDraft.xaml",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "originalRawValue": "logMessage",
      "parsedIntentType": "pre-assembly:literal",
      "normalizedOutput": "\"logMessage\"",
      "fallbackUsed": false,
      "finalValueHash": "a271a261e6ab3b2316d3f7fc3f41488f7975fd73e55dcd7b27e914573b8915c0"
    },
    {
      "workflowFile": "BGYY_GenerateDraft.xaml",
      "activityType": "LogMessage",
      "propertyName": "Level",
      "originalRawValue": "Info",
      "parsedIntentType": "pre-assembly:literal",
      "normalizedOutput": "\"Info\"",
      "fallbackUsed": false,
      "finalValueHash": "6e68b62d2aa611a44f3e7a4cb7e23da9ad1cab1b6abb592bb2795b12fe63e51c"
    },
    {
      "workflowFile": "BGYY_GenerateDraft.xaml",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "originalRawValue": "\"[BGYY_GenerateDraft] INFO | Prompt composed | Length=\" & composedPrompt.Length.ToString() & \" chars | RunId=\" & InRunId & \" | FullName=\" & InFullName",
      "parsedIntentType": "pre-assembly:literal",
      "normalizedOutput": "[\"\"\"[BGYY_GenerateDraft] INFO | Prompt composed | Length=\"\" & composedPrompt.Length.ToString() & \"\" chars | RunId=\"\" & InRunId & \"\" | FullName=\"\" & InFullName\"]",
      "fallbackUsed": false,
      "finalValueHash": "fc9c31e45c668f33f1898c24b83fda8808f374aa26ce4f5976ad75a10d3edaa2"
    },
    {
      "workflowFile": "BGYY_GenerateDraft.xaml",
      "activityType": "LogMessage",
      "propertyName": "Level",
      "originalRawValue": "Error",
      "parsedIntentType": "pre-assembly:literal",
      "normalizedOutput": "\"Error\"",
      "fallbackUsed": false,
      "finalValueHash": "fc4ac19649f0ee8f37c71d2e2030a3743038bb96c0c27359ba115dd8657565cc"
    },
    {
      "workflowFile": "BGYY_GenerateDraft.xaml",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "originalRawValue": "\"Error in Generate personalized birthday email draft via UiPath GenAI GenerateTextCompletion: \" & exception.Message",
      "parsedIntentType": "pre-assembly:literal",
      "normalizedOutput": "[\"\"\"Error in Generate personalized birthday email draft via UiPath GenAI GenerateTextCompletion: \"\" & exception.Message\"]",
      "fallbackUsed": false,
      "finalValueHash": "9e33fff5e42e8ee6c10581ab830c5567e7ff603e807bde81a001cbb1a61ebc58"
    },
    {
      "workflowFile": "BGYY_GenerateDraft.xaml",
      "activityType": "LogMessage",
      "propertyName": "Level",
      "originalRawValue": "Error",
      "parsedIntentType": "pre-assembly:literal",
      "normalizedOutput": "\"Error\"",
      "fallbackUsed": false,
      "finalValueHash": "fc4ac19649f0ee8f37c71d2e2030a3743038bb96c0c27359ba115dd8657565cc"
    },
    {
      "workflowFile": "BGYY_GenerateDraft.xaml",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "originalRawValue": "logMessage",
      "parsedIntentType": "pre-assembly:literal",
      "normalizedOutput": "\"logMessage\"",
      "fallbackUsed": false,
      "finalValueHash": "a271a261e6ab3b2316d3f7fc3f41488f7975fd73e55dcd7b27e914573b8915c0"
    },
    {
      "workflowFile": "BGYY_GenerateDraft.xaml",
      "activityType": "UploadStorageFile",
      "propertyName": "Path",
      "originalRawValue": "errorScreenshotBucketPath",
      "parsedIntentType": "pre-assembly:literal",
      "normalizedOutput": "\"errorScreenshotBucketPath\"",
      "fallbackUsed": false,
      "finalValueHash": "484c7188cd9d9becf2070ed1bd7beeb601a16c13d0113f5af62ccd07548de285"
    },
    {
      "workflowFile": "BGYY_GenerateDraft.xaml",
      "activityType": "LogMessage",
      "propertyName": "Level",
      "originalRawValue": "Info",
      "parsedIntentType": "pre-assembly:literal",
      "normalizedOutput": "\"Info\"",
      "fallbackUsed": false,
      "finalValueHash": "6e68b62d2aa611a44f3e7a4cb7e23da9ad1cab1b6abb592bb2795b12fe63e51c"
    },
    {
      "workflowFile": "BGYY_GenerateDraft.xaml",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "originalRawValue": "\"[BGYY_GenerateDraft] INFO | GenAI raw output received | Length=\" & genAiRawOutput.Length.ToString() & \" chars | RunId=\" & InRunId & \" | FullName=\" & InFullName",
      "parsedIntentType": "pre-assembly:literal",
      "normalizedOutput": "[\"\"\"[BGYY_GenerateDraft] INFO | GenAI raw output received | Length=\"\" & genAiRawOutput.Length.ToString() & \"\" chars | RunId=\"\" & InRunId & \"\" | FullName=\"\" & InFullName\"]",
      "fallbackUsed": false,
      "finalValueHash": "acdc2374dc85c1875e92d008bcbf0f4c2b0e1073c055e333d9f84c7ce56ce75c"
    },
    {
      "workflowFile": "BGYY_GenerateDraft.xaml",
      "activityType": "LogMessage",
      "propertyName": "Level",
      "originalRawValue": "Error",
      "parsedIntentType": "pre-assembly:literal",
      "normalizedOutput": "\"Error\"",
      "fallbackUsed": false,
      "finalValueHash": "fc4ac19649f0ee8f37c71d2e2030a3743038bb96c0c27359ba115dd8657565cc"
    },
    {
      "workflowFile": "BGYY_GenerateDraft.xaml",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "originalRawValue": "\"Error in Parse Subject from GenAI JSON output using InvokeCode: \" & exception.Message",
      "parsedIntentType": "pre-assembly:literal",
      "normalizedOutput": "[\"\"\"Error in Parse Subject from GenAI JSON output using InvokeCode: \"\" & exception.Message\"]",
      "fallbackUsed": false,
      "finalValueHash": "95b6bc2ab92acfc8d7e693af9bc91300060b711bd359f06d79af66ba6a06ef45"
    },
    {
      "workflowFile": "BGYY_GenerateDraft.xaml",
      "activityType": "LogMessage",
      "propertyName": "Level",
      "originalRawValue": "Error",
      "parsedIntentType": "pre-assembly:literal",
      "normalizedOutput": "\"Error\"",
      "fallbackUsed": false,
      "finalValueHash": "fc4ac19649f0ee8f37c71d2e2030a3743038bb96c0c27359ba115dd8657565cc"
    },
    {
      "workflowFile": "BGYY_GenerateDraft.xaml",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "originalRawValue": "\"[BGYY_GenerateDraft] ERROR | Failed to parse Subject/Body from GenAI output JSON | RunId=\" & InRunId & \" | FullName=\" & InFullName & \" | RawOutputLength=\" & genAiRawOutput.Length.ToString()",
      "parsedIntentType": "pre-assembly:literal",
      "normalizedOutput": "[\"\"\"[BGYY_GenerateDraft] ERROR | Failed to parse Subject/Body from GenAI output JSON | RunId=\"\" & InRunId & \"\" | FullName=\"\" & InFullName & \"\" | RawOutputLength=\"\" & genAiRawOutput.Length.ToString()\"]",
      "fallbackUsed": false,
      "finalValueHash": "e4392c500ab06bd44e76f3120f252acfe4f5ee6beab9119e473c51f5cb2085dd"
    },
    {
      "workflowFile": "BGYY_GenerateDraft.xaml",
      "activityType": "UploadStorageFile",
      "propertyName": "Path",
      "originalRawValue": "errorScreenshotBucketPath",
      "parsedIntentType": "pre-assembly:literal",
      "normalizedOutput": "\"errorScreenshotBucketPath\"",
      "fallbackUsed": false,
      "finalValueHash": "484c7188cd9d9becf2070ed1bd7beeb601a16c13d0113f5af62ccd07548de285"
    },
    {
      "workflowFile": "BGYY_GenerateDraft.xaml",
      "activityType": "LogMessage",
      "propertyName": "Level",
      "originalRawValue": "Info",
      "parsedIntentType": "pre-assembly:literal",
      "normalizedOutput": "\"Info\"",
      "fallbackUsed": false,
      "finalValueHash": "6e68b62d2aa611a44f3e7a4cb7e23da9ad1cab1b6abb592bb2795b12fe63e51c"
    },
    {
      "workflowFile": "BGYY_GenerateDraft.xaml",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "originalRawValue": "\"[BGYY_GenerateDraft] INFO | GenAI draft parsed successfully | SubjectLength=\" & parsedSubject.Length.ToString() & \" | BodyLength=\" & parsedBody.Length.ToString() & \" | RunId=\" & InRunId & \" | FullName=\" & InFullName",
      "parsedIntentType": "pre-assembly:literal",
      "normalizedOutput": "[\"\"\"[BGYY_GenerateDraft] INFO | GenAI draft parsed successfully | SubjectLength=\"\" & parsedSubject.Length.ToString() & \"\" | BodyLength=\"\" & parsedBody.Length.ToString() & \"\" | RunId=\"\" & InRunId & \"\" | FullName=\"\" & InFullName\"]",
      "fallbackUsed": false,
      "finalValueHash": "71523e7981f2d909f9914ce263c9670cabc8f02d7d2a7bd45d1f1113f4231bfb"
    },
    {
      "workflowFile": "unknown",
      "activityType": "QueryEntity",
      "propertyName": "EntityType",
      "originalRawValue": "{\"type\":\"literal\",\"value\":\"BGYY_VoiceProfile\"}",
      "parsedIntentType": "literal",
      "normalizedOutput": "\"BGYY_VoiceProfile\"",
      "fallbackUsed": false,
      "finalValueHash": "cea3f80968d76bbaf6f6684ed95afd8320682b388c3b2c575d9f804fc5867b61"
    },
    {
      "workflowFile": "unknown",
      "activityType": "QueryEntity",
      "propertyName": "Result",
      "originalRawValue": "{\"type\":\"variable\",\"name\":\"voiceProfileRecords\"}",
      "parsedIntentType": "variable",
      "normalizedOutput": "[voiceProfileRecords]",
      "fallbackUsed": false,
      "finalValueHash": "4ccedd7cd8ddaf6d80678113e1758fe5aa0fb3ffc4e39634514b515228a9ef5a"
    },
    {
      "workflowFile": "unknown",
      "activityType": "ReadStorageText",
      "propertyName": "Path",
      "originalRawValue": "{\"type\":\"literal\",\"value\":\"prompt_templates/voice_prompt.txt\"}",
      "parsedIntentType": "literal",
      "normalizedOutput": "\"prompt_templates/voice_prompt.txt\"",
      "fallbackUsed": false,
      "finalValueHash": "ea0ecf332b92d2f067f838d1fd58be310d51b59f0686856f85dc09334c193d4e"
    },
    {
      "workflowFile": "unknown",
      "activityType": "ReadStorageText",
      "propertyName": "StorageBucketName",
      "originalRawValue": "{\"type\":\"literal\",\"value\":\"BGYY_RunArtifacts\"}",
      "parsedIntentType": "literal",
      "normalizedOutput": "\"BGYY_RunArtifacts\"",
      "fallbackUsed": false,
      "finalValueHash": "33ba51cda6204d629b13659583987f07350bd4896764a2a53b10faab956ba518"
    },
    {
      "workflowFile": "unknown",
      "activityType": "UploadStorageFile",
      "propertyName": "StorageBucketName",
      "originalRawValue": "{\"type\":\"literal\",\"value\":\"BGYY_RunArtifacts\"}",
      "parsedIntentType": "literal",
      "normalizedOutput": "\"BGYY_RunArtifacts\"",
      "fallbackUsed": false,
      "finalValueHash": "33ba51cda6204d629b13659583987f07350bd4896764a2a53b10faab956ba518"
    },
    {
      "workflowFile": "unknown",
      "activityType": "UploadStorageFile",
      "propertyName": "Path",
      "originalRawValue": "{\"type\":\"literal\",\"value\":\"errorScreenshotBucketPath\"}",
      "parsedIntentType": "literal",
      "normalizedOutput": "\"errorScreenshotBucketPath\"",
      "fallbackUsed": false,
      "finalValueHash": "484c7188cd9d9becf2070ed1bd7beeb601a16c13d0113f5af62ccd07548de285"
    },
    {
      "workflowFile": "unknown",
      "activityType": "UploadStorageFile",
      "propertyName": "FileResource",
      "originalRawValue": "{\"type\":\"variable\",\"name\":\"errorScreenshotPath\"}",
      "parsedIntentType": "variable",
      "normalizedOutput": "[errorScreenshotPath]",
      "fallbackUsed": false,
      "finalValueHash": "3bb866e97ef9f4bd25f5f3399ffd093f1148a7e0c0bfcb16de1745bbd23ce22d"
    },
    {
      "workflowFile": "unknown",
      "activityType": "UploadStorageFile",
      "propertyName": "Destination",
      "originalRawValue": "{\"type\":\"variable\",\"name\":\"errorScreenshotBucketPath\"}",
      "parsedIntentType": "variable",
      "normalizedOutput": "[errorScreenshotBucketPath]",
      "fallbackUsed": false,
      "finalValueHash": "f54cb776d54a568c0835cca57fb2d8f3fba7fe44877ddceb58edc416ba7fe94a"
    },
    {
      "workflowFile": "unknown",
      "activityType": "InvokeCode",
      "propertyName": "Code",
      "originalRawValue": "{\"type\":\"vb_expression\",\"value\":\"Dim rawJson As String = genAiRawOutput.Trim()\\nDim cleaned As String = rawJson\\nIf cleaned.StartsWith(\\\"```json\\\") Then cleaned = cleaned.Substring(7)\\nIf cleaned.StartsWith(\\\"```\\\") Then cleaned = cleaned.Substring(3)\\nIf cleaned.EndsWith(\\\"```\\\") Then cleaned = cleaned.Substring(0, cleaned.Length - 3)\\ncleaned = cleaned.Trim()\\nDim parsed As System.Collections.Generic.Dictionary(Of String, Object)\\nTry\\n    parsed = Newtonsoft.Json.JsonConvert.DeserializeObject",
      "parsedIntentType": "vb_expression",
      "normalizedOutput": "[Dim rawJson As String = genAiRawOutput.Trim()\nDim cleaned As String = rawJson\nIf cleaned.StartsWith(\"```json\") Then cleaned = cleaned.Substring(7)\nIf cleaned.StartsWith(\"```\") Then cleaned = cleaned.Substring(3)\nIf cleaned.EndsWith(\"```\") Then cleaned = cleaned.Substring(0, cleaned.Length - 3)\ncleaned = cleaned.Trim()\nDim parsed As System.Collections.Generic.Dictionary(Of String, Object)\nTry\n    parsed = Newtonsoft.Json.JsonConvert.DeserializeObject(Of System.Collections.Generic.Dictionary(Of S",
      "fallbackUsed": false,
      "finalValueHash": "88aeee8485b371932424015dc5e3c989bb211bd5c37929efae104139010c1b6e"
    },
    {
      "workflowFile": "unknown",
      "activityType": "InvokeCode",
      "propertyName": "Arguments",
      "originalRawValue": "{\"type\":\"vb_expression\",\"value\":\"New Dictionary(Of String, Object) From {{\\\"genAiRawOutput\\\", genAiRawOutput}, {\\\"parsedSubject\\\", parsedSubject}, {\\\"parsedBody\\\", parsedBody}, {\\\"parseSucceeded\\\", parseSucceeded}}\"}",
      "parsedIntentType": "vb_expression",
      "normalizedOutput": "[New Dictionary(Of String, Object) From {{\"genAiRawOutput\", genAiRawOutput}, {\"parsedSubject\", parsedSubject}, {\"parsedBody\", parsedBody}, {\"parseSucceeded\", parseSucceeded}}]",
      "fallbackUsed": false,
      "finalValueHash": "4272c833ad06a25512af39d1afacad4af797d102f01c29c54ec1ad52229b38c3"
    },
    {
      "workflowFile": "unknown",
      "activityType": "UploadStorageFile",
      "propertyName": "StorageBucketName",
      "originalRawValue": "{\"type\":\"literal\",\"value\":\"BGYY_RunArtifacts\"}",
      "parsedIntentType": "literal",
      "normalizedOutput": "\"BGYY_RunArtifacts\"",
      "fallbackUsed": false,
      "finalValueHash": "33ba51cda6204d629b13659583987f07350bd4896764a2a53b10faab956ba518"
    },
    {
      "workflowFile": "unknown",
      "activityType": "UploadStorageFile",
      "propertyName": "Path",
      "originalRawValue": "{\"type\":\"literal\",\"value\":\"errorScreenshotBucketPath\"}",
      "parsedIntentType": "literal",
      "normalizedOutput": "\"errorScreenshotBucketPath\"",
      "fallbackUsed": false,
      "finalValueHash": "484c7188cd9d9becf2070ed1bd7beeb601a16c13d0113f5af62ccd07548de285"
    },
    {
      "workflowFile": "unknown",
      "activityType": "UploadStorageFile",
      "propertyName": "FileResource",
      "originalRawValue": "{\"type\":\"variable\",\"name\":\"errorScreenshotPath\"}",
      "parsedIntentType": "variable",
      "normalizedOutput": "[errorScreenshotPath]",
      "fallbackUsed": false,
      "finalValueHash": "3bb866e97ef9f4bd25f5f3399ffd093f1148a7e0c0bfcb16de1745bbd23ce22d"
    },
    {
      "workflowFile": "unknown",
      "activityType": "UploadStorageFile",
      "propertyName": "Destination",
      "originalRawValue": "{\"type\":\"variable\",\"name\":\"errorScreenshotBucketPath\"}",
      "parsedIntentType": "variable",
      "normalizedOutput": "[errorScreenshotBucketPath]",
      "fallbackUsed": false,
      "finalValueHash": "f54cb776d54a568c0835cca57fb2d8f3fba7fe44877ddceb58edc416ba7fe94a"
    },
    {
      "workflowFile": "BGYY_ValidateDraft.xaml",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "originalRawValue": "\"[BGYY_ValidateDraft] START - RunId=\" & InRunId & \" | FullName=\" & InFullName & \" | SubjectLen=\" & InSubject.Length.ToString() & \" | BodyLen=\" & InBody.Length.ToString()",
      "parsedIntentType": "pre-assembly:literal",
      "normalizedOutput": "[\"\"\"[BGYY_ValidateDraft] START - RunId=\"\" & InRunId & \"\" | FullName=\"\" & InFullName & \"\" | SubjectLen=\"\" & InSubject.Length.ToString() & \"\" | BodyLen=\"\" & InBody.Length.ToString()\"]",
      "fallbackUsed": false,
      "finalValueHash": "9339d15fb6ff1343f76557fe514724dfe60037606ab6baf73d37da2cf4671a0d"
    },
    {
      "workflowFile": "BGYY_ValidateDraft.xaml",
      "activityType": "LogMessage",
      "propertyName": "Level",
      "originalRawValue": "Info",
      "parsedIntentType": "pre-assembly:literal",
      "normalizedOutput": "\"Info\"",
      "fallbackUsed": false,
      "finalValueHash": "6e68b62d2aa611a44f3e7a4cb7e23da9ad1cab1b6abb592bb2795b12fe63e51c"
    },
    {
      "workflowFile": "BGYY_ValidateDraft.xaml",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "originalRawValue": "\"[BGYY_ValidateDraft] GUARD FAIL - Empty input detected. RunId=\" & InRunId & \" | FullName='\" & InFullName & \"'\"",
      "parsedIntentType": "pre-assembly:literal",
      "normalizedOutput": "[\"[BGYY_ValidateDraft] GUARD FAIL - Empty input detected. RunId=\"\" & InRunId & \"\" | FullName='\"\" & InFullName & \"\"'\"]",
      "fallbackUsed": false,
      "finalValueHash": "1303ec263008b9aac0257f1ca416f4701314c9f458d70b9ad84eed3d886198e9"
    },
    {
      "workflowFile": "BGYY_ValidateDraft.xaml",
      "activityType": "LogMessage",
      "propertyName": "Level",
      "originalRawValue": "Warn",
      "parsedIntentType": "pre-assembly:literal",
      "normalizedOutput": "\"Warn\"",
      "fallbackUsed": false,
      "finalValueHash": "0817e2b865151b33aa686f0551fce818a034cb723e0044e433cd8100810ed280"
    },
    {
      "workflowFile": "BGYY_ValidateDraft.xaml",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "originalRawValue": "\"[BGYY_ValidateDraft] FAIL name-in-body - RunId=\" & InRunId & \" | FullName='\" & InFullName & \"'\"",
      "parsedIntentType": "pre-assembly:literal",
      "normalizedOutput": "[\"[BGYY_ValidateDraft] FAIL name-in-body - RunId=\"\" & InRunId & \"\" | FullName='\"\" & InFullName & \"\"'\"]",
      "fallbackUsed": false,
      "finalValueHash": "54637acb8e0c5f2f5f44aab13e087b09da4c1c1a52f6deb8a595efed76af01dc"
    },
    {
      "workflowFile": "BGYY_ValidateDraft.xaml",
      "activityType": "LogMessage",
      "propertyName": "Level",
      "originalRawValue": "Warn",
      "parsedIntentType": "pre-assembly:literal",
      "normalizedOutput": "\"Warn\"",
      "fallbackUsed": false,
      "finalValueHash": "0817e2b865151b33aa686f0551fce818a034cb723e0044e433cd8100810ed280"
    },
    {
      "workflowFile": "BGYY_ValidateDraft.xaml",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "originalRawValue": "\"[BGYY_ValidateDraft] FAIL name-in-subject - RunId=\" & InRunId & \" | FullName='\" & InFullName & \"'\"",
      "parsedIntentType": "pre-assembly:literal",
      "normalizedOutput": "[\"[BGYY_ValidateDraft] FAIL name-in-subject - RunId=\"\" & InRunId & \"\" | FullName='\"\" & InFullName & \"\"'\"]",
      "fallbackUsed": false,
      "finalValueHash": "9c818c72df8be4e40a49f1ce777846262a51ace6636b582b04c87b7c456db515"
    },
    {
      "workflowFile": "BGYY_ValidateDraft.xaml",
      "activityType": "LogMessage",
      "propertyName": "Level",
      "originalRawValue": "Warn",
      "parsedIntentType": "pre-assembly:literal",
      "normalizedOutput": "\"Warn\"",
      "fallbackUsed": false,
      "finalValueHash": "0817e2b865151b33aa686f0551fce818a034cb723e0044e433cd8100810ed280"
    },
    {
      "workflowFile": "BGYY_ValidateDraft.xaml",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "originalRawValue": "\"[BGYY_ValidateDraft] FAIL placeholder-in-body - RunId=\" & InRunId & \" | FullName='\" & InFullName & \"'\"",
      "parsedIntentType": "pre-assembly:literal",
      "normalizedOutput": "[\"[BGYY_ValidateDraft] FAIL placeholder-in-body - RunId=\"\" & InRunId & \"\" | FullName='\"\" & InFullName & \"\"'\"]",
      "fallbackUsed": false,
      "finalValueHash": "4b86ea068f153c5d1ad324b2fd18f96865c0e8c99200bf613d55d82feec5cd2f"
    },
    {
      "workflowFile": "BGYY_ValidateDraft.xaml",
      "activityType": "LogMessage",
      "propertyName": "Level",
      "originalRawValue": "Warn",
      "parsedIntentType": "pre-assembly:literal",
      "normalizedOutput": "\"Warn\"",
      "fallbackUsed": false,
      "finalValueHash": "0817e2b865151b33aa686f0551fce818a034cb723e0044e433cd8100810ed280"
    },
    {
      "workflowFile": "BGYY_ValidateDraft.xaml",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "originalRawValue": "\"[BGYY_ValidateDraft] FAIL placeholder-in-subject - RunId=\" & InRunId & \" | FullName='\" & InFullName & \"'\"",
      "parsedIntentType": "pre-assembly:literal",
      "normalizedOutput": "[\"[BGYY_ValidateDraft] FAIL placeholder-in-subject - RunId=\"\" & InRunId & \"\" | FullName='\"\" & InFullName & \"\"'\"]",
      "fallbackUsed": false,
      "finalValueHash": "fb0e336468b18bc0349836861b334523347451753d63b28b3a04498586cd760c"
    },
    {
      "workflowFile": "BGYY_ValidateDraft.xaml",
      "activityType": "LogMessage",
      "propertyName": "Level",
      "originalRawValue": "Warn",
      "parsedIntentType": "pre-assembly:literal",
      "normalizedOutput": "\"Warn\"",
      "fallbackUsed": false,
      "finalValueHash": "0817e2b865151b33aa686f0551fce818a034cb723e0044e433cd8100810ed280"
    },
    {
      "workflowFile": "BGYY_ValidateDraft.xaml",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "originalRawValue": "\"[BGYY_ValidateDraft] Word count check - RunId=\" & InRunId & \" | FullName='\" & InFullName & \"' | WordCount=\" & bodyWordCount.ToString()",
      "parsedIntentType": "pre-assembly:literal",
      "normalizedOutput": "[\"\"\"[BGYY_ValidateDraft] Word count check - RunId=\"\" & InRunId & \"\" | FullName='\"\" & InFullName & \"\"' | WordCount=\"\" & bodyWordCount.ToString()\"]",
      "fallbackUsed": false,
      "finalValueHash": "be59b8c85335f061a72d36d31badda021e28fe726c0ebf3dc0c668b8edaecfe0"
    },
    {
      "workflowFile": "BGYY_ValidateDraft.xaml",
      "activityType": "LogMessage",
      "propertyName": "Level",
      "originalRawValue": "Info",
      "parsedIntentType": "pre-assembly:literal",
      "normalizedOutput": "\"Info\"",
      "fallbackUsed": false,
      "finalValueHash": "6e68b62d2aa611a44f3e7a4cb7e23da9ad1cab1b6abb592bb2795b12fe63e51c"
    },
    {
      "workflowFile": "BGYY_ValidateDraft.xaml",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "originalRawValue": "\"[BGYY_ValidateDraft] FAIL word-count-min - RunId=\" & InRunId & \" | FullName='\" & InFullName & \"' | WordCount=\" & bodyWordCount.ToString()",
      "parsedIntentType": "pre-assembly:literal",
      "normalizedOutput": "[\"\"\"[BGYY_ValidateDraft] FAIL word-count-min - RunId=\"\" & InRunId & \"\" | FullName='\"\" & InFullName & \"\"' | WordCount=\"\" & bodyWordCount.ToString()\"]",
      "fallbackUsed": false,
      "finalValueHash": "7bf444bd1e94cf429745d19cb552c6e02cd0b999537cbfaaba1b0ac19bf7895a"
    },
    {
      "workflowFile": "BGYY_ValidateDraft.xaml",
      "activityType": "LogMessage",
      "propertyName": "Level",
      "originalRawValue": "Warn",
      "parsedIntentType": "pre-assembly:literal",
      "normalizedOutput": "\"Warn\"",
      "fallbackUsed": false,
      "finalValueHash": "0817e2b865151b33aa686f0551fce818a034cb723e0044e433cd8100810ed280"
    },
    {
      "workflowFile": "BGYY_ValidateDraft.xaml",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "originalRawValue": "\"[BGYY_ValidateDraft] FAIL word-count-max - RunId=\" & InRunId & \" | FullName='\" & InFullName & \"' | WordCount=\" & bodyWordCount.ToString()",
      "parsedIntentType": "pre-assembly:literal",
      "normalizedOutput": "[\"\"\"[BGYY_ValidateDraft] FAIL word-count-max - RunId=\"\" & InRunId & \"\" | FullName='\"\" & InFullName & \"\"' | WordCount=\"\" & bodyWordCount.ToString()\"]",
      "fallbackUsed": false,
      "finalValueHash": "a2abfeb9ff7151f4721a838d26e63b16c4ed72cccdf48cb00c5436b60086639c"
    },
    {
      "workflowFile": "BGYY_ValidateDraft.xaml",
      "activityType": "LogMessage",
      "propertyName": "Level",
      "originalRawValue": "Warn",
      "parsedIntentType": "pre-assembly:literal",
      "normalizedOutput": "\"Warn\"",
      "fallbackUsed": false,
      "finalValueHash": "0817e2b865151b33aa686f0551fce818a034cb723e0044e433cd8100810ed280"
    },
    {
      "workflowFile": "BGYY_ValidateDraft.xaml",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "originalRawValue": "\"[BGYY_ValidateDraft] Downloading banned phrases from BGYY_RunArtifacts/guardrails/banned_phrases.txt - RunId=\" & InRunId",
      "parsedIntentType": "pre-assembly:literal",
      "normalizedOutput": "[\"\"\"[BGYY_ValidateDraft] Downloading banned phrases from BGYY_RunArtifacts/guardrails/banned_phrases.txt - RunId=\"\" & InRunId\"]",
      "fallbackUsed": false,
      "finalValueHash": "1d783051d3228f608485ab6cfe61de8d119d5b7568ba17bb453538802cd4f606"
    },
    {
      "workflowFile": "BGYY_ValidateDraft.xaml",
      "activityType": "LogMessage",
      "propertyName": "Level",
      "originalRawValue": "Info",
      "parsedIntentType": "pre-assembly:literal",
      "normalizedOutput": "\"Info\"",
      "fallbackUsed": false,
      "finalValueHash": "6e68b62d2aa611a44f3e7a4cb7e23da9ad1cab1b6abb592bb2795b12fe63e51c"
    },
    {
      "workflowFile": "BGYY_ValidateDraft.xaml",
      "activityType": "ReadStorageText",
      "propertyName": "Path",
      "originalRawValue": "guardrails/banned_phrases.txt",
      "parsedIntentType": "pre-assembly:literal",
      "normalizedOutput": "\"guardrails/banned_phrases.txt\"",
      "fallbackUsed": false,
      "finalValueHash": "7c5964a7f82a42faae10ed451f500f1fbe043022744a0d327982d889e4078bb0"
    },
    {
      "workflowFile": "BGYY_ValidateDraft.xaml",
      "activityType": "LogMessage",
      "propertyName": "Level",
      "originalRawValue": "Error",
      "parsedIntentType": "pre-assembly:literal",
      "normalizedOutput": "\"Error\"",
      "fallbackUsed": false,
      "finalValueHash": "fc4ac19649f0ee8f37c71d2e2030a3743038bb96c0c27359ba115dd8657565cc"
    },
    {
      "workflowFile": "BGYY_ValidateDraft.xaml",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "originalRawValue": "\"Error in Download banned_phrases.txt from BGYY_RunArtifacts Storage Bucket: \" & exception.Message",
      "parsedIntentType": "pre-assembly:literal",
      "normalizedOutput": "[\"\"\"Error in Download banned_phrases.txt from BGYY_RunArtifacts Storage Bucket: \"\" & exception.Message\"]",
      "fallbackUsed": false,
      "finalValueHash": "f91ac5663a3c19f3bc04f9dc55d5bb10aa014c8b422cd30f38dcfede3fc7282f"
    },
    {
      "workflowFile": "BGYY_ValidateDraft.xaml",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "originalRawValue": "\"[BGYY_ValidateDraft] WARN banned-phrases file unavailable from Storage Bucket. Skipping banned-phrase checks. RunId=\" & InRunId",
      "parsedIntentType": "pre-assembly:literal",
      "normalizedOutput": "[\"\"\"[BGYY_ValidateDraft] WARN banned-phrases file unavailable from Storage Bucket. Skipping banned-phrase checks. RunId=\"\" & InRunId\"]",
      "fallbackUsed": false,
      "finalValueHash": "3ec1ff8cf03734a0cadf231efefb1fb2ed95c5468ff25125e54193630e80de38"
    },
    {
      "workflowFile": "BGYY_ValidateDraft.xaml",
      "activityType": "LogMessage",
      "propertyName": "Level",
      "originalRawValue": "Warn",
      "parsedIntentType": "pre-assembly:literal",
      "normalizedOutput": "\"Warn\"",
      "fallbackUsed": false,
      "finalValueHash": "0817e2b865151b33aa686f0551fce818a034cb723e0044e433cd8100810ed280"
    },
    {
      "workflowFile": "BGYY_ValidateDraft.xaml",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "originalRawValue": "\"[BGYY_ValidateDraft] Loaded \" & bannedPhrasesList.Length.ToString() & \" banned phrases. Checking body and subject. RunId=\" & InRunId",
      "parsedIntentType": "pre-assembly:literal",
      "normalizedOutput": "[\"\"\"[BGYY_ValidateDraft] Loaded \"\" & bannedPhrasesList.Length.ToString() & \"\" banned phrases. Checking body and subject. RunId=\"\" & InRunId\"]",
      "fallbackUsed": false,
      "finalValueHash": "2bf644126dda3f785ad6c0c3beae56935d59d016f9e1af501c3f2f282ddb0a6a"
    },
    {
      "workflowFile": "BGYY_ValidateDraft.xaml",
      "activityType": "LogMessage",
      "propertyName": "Level",
      "originalRawValue": "Info",
      "parsedIntentType": "pre-assembly:literal",
      "normalizedOutput": "\"Info\"",
      "fallbackUsed": false,
      "finalValueHash": "6e68b62d2aa611a44f3e7a4cb7e23da9ad1cab1b6abb592bb2795b12fe63e51c"
    },
    {
      "workflowFile": "unknown",
      "activityType": "IsMatch",
      "propertyName": "Input",
      "originalRawValue": "{\"type\":\"variable\",\"name\":\"InBody\"}",
      "parsedIntentType": "variable",
      "normalizedOutput": "[InBody]",
      "fallbackUsed": false,
      "finalValueHash": "58d5f033dc9f02822b4decf9a75b85c7b59637aa8ccf92b0bc053e5e18a05c28"
    },
    {
      "workflowFile": "unknown",
      "activityType": "IsMatch",
      "propertyName": "Pattern",
      "originalRawValue": "{\"type\":\"literal\",\"value\":\"(?i)(\\\\{\\\\{[^}]+\\\\}\\\\}|\\\\[[A-Z_]{2}\\\\]|<[A-Z_]{2}>|\\\\[INSERT[^\\\\]]*\\\\]|\\\\[YOUR[^\\\\]]*\\\\])\"}",
      "parsedIntentType": "literal",
      "normalizedOutput": "[\"(?i)(\\{\\{[^}]+\\}\\}|\\[[A-Z_]{2}\\]|&lt;[A-Z_]{2}&gt;|\\[INSERT[^\\]]*\\]|\\[YOUR[^\\]]*\\])\"]",
      "fallbackUsed": false,
      "finalValueHash": "a0f3dad7d35b52d711d12505c4d62a919d61d71f9418d15c4d0ae66cf010b63c"
    },
    {
      "workflowFile": "unknown",
      "activityType": "IsMatch",
      "propertyName": "Input",
      "originalRawValue": "{\"type\":\"variable\",\"name\":\"InSubject\"}",
      "parsedIntentType": "variable",
      "normalizedOutput": "[InSubject]",
      "fallbackUsed": false,
      "finalValueHash": "0129e2706f1122cd718991531d34eb44e5514f6fa3587a3be7b157b868ae99ba"
    },
    {
      "workflowFile": "unknown",
      "activityType": "IsMatch",
      "propertyName": "Pattern",
      "originalRawValue": "{\"type\":\"literal\",\"value\":\"(?i)(\\\\{\\\\{[^}]+\\\\}\\\\}|\\\\[[A-Z_]{2}\\\\]|<[A-Z_]{2}>|\\\\[INSERT[^\\\\]]*\\\\]|\\\\[YOUR[^\\\\]]*\\\\])\"}",
      "parsedIntentType": "literal",
      "normalizedOutput": "[\"(?i)(\\{\\{[^}]+\\}\\}|\\[[A-Z_]{2}\\]|&lt;[A-Z_]{2}&gt;|\\[INSERT[^\\]]*\\]|\\[YOUR[^\\]]*\\])\"]",
      "fallbackUsed": false,
      "finalValueHash": "a0f3dad7d35b52d711d12505c4d62a919d61d71f9418d15c4d0ae66cf010b63c"
    },
    {
      "workflowFile": "unknown",
      "activityType": "ReadStorageText",
      "propertyName": "Path",
      "originalRawValue": "{\"type\":\"literal\",\"value\":\"guardrails/banned_phrases.txt\"}",
      "parsedIntentType": "literal",
      "normalizedOutput": "\"guardrails/banned_phrases.txt\"",
      "fallbackUsed": false,
      "finalValueHash": "7c5964a7f82a42faae10ed451f500f1fbe043022744a0d327982d889e4078bb0"
    },
    {
      "workflowFile": "unknown",
      "activityType": "ReadStorageText",
      "propertyName": "StorageBucketName",
      "originalRawValue": "{\"type\":\"literal\",\"value\":\"BGYY_RunArtifacts\"}",
      "parsedIntentType": "literal",
      "normalizedOutput": "\"BGYY_RunArtifacts\"",
      "fallbackUsed": false,
      "finalValueHash": "33ba51cda6204d629b13659583987f07350bd4896764a2a53b10faab956ba518"
    },
    {
      "workflowFile": "BGYY_SendGmail.xaml",
      "activityType": "LogMessage",
      "propertyName": "Level",
      "originalRawValue": "Info",
      "parsedIntentType": "pre-assembly:literal",
      "normalizedOutput": "\"Info\"",
      "fallbackUsed": false,
      "finalValueHash": "6e68b62d2aa611a44f3e7a4cb7e23da9ad1cab1b6abb592bb2795b12fe63e51c"
    },
    {
      "workflowFile": "BGYY_SendGmail.xaml",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "originalRawValue": "\"[BGYY_SendGmail] START | RunId=\" & InRunId & \" | To=\" & InToEmail & \" | Subject=\" & InSubject & \" | DryRun=\" & InDryRun.ToString()",
      "parsedIntentType": "pre-assembly:literal",
      "normalizedOutput": "[\"\"\"[BGYY_SendGmail] START | RunId=\"\" & InRunId & \"\" | To=\"\" & InToEmail & \"\" | Subject=\"\" & InSubject & \"\" | DryRun=\"\" & InDryRun.ToString()\"]",
      "fallbackUsed": false,
      "finalValueHash": "2577742b12a31f6615850fb392e275685eca22e39025f92445a655f14b768bfb"
    },
    {
      "workflowFile": "BGYY_SendGmail.xaml",
      "activityType": "LogMessage",
      "propertyName": "Level",
      "originalRawValue": "Warn",
      "parsedIntentType": "pre-assembly:literal",
      "normalizedOutput": "\"Warn\"",
      "fallbackUsed": false,
      "finalValueHash": "0817e2b865151b33aa686f0551fce818a034cb723e0044e433cd8100810ed280"
    },
    {
      "workflowFile": "BGYY_SendGmail.xaml",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "originalRawValue": "\"[BGYY_SendGmail] DRY-RUN mode active — email NOT sent | RunId=\" & InRunId & \" | To=\" & InToEmail",
      "parsedIntentType": "pre-assembly:literal",
      "normalizedOutput": "[\"\"\"[BGYY_SendGmail] DRY-RUN mode active — email NOT sent | RunId=\"\" & InRunId & \"\" | To=\"\" & InToEmail\"]",
      "fallbackUsed": false,
      "finalValueHash": "a129afcaec19c4bb754d9748ba57b52386e93a52f57f1cc0acaf38d1afe324f5"
    },
    {
      "workflowFile": "BGYY_SendGmail.xaml",
      "activityType": "LogMessage",
      "propertyName": "Level",
      "originalRawValue": "Info",
      "parsedIntentType": "pre-assembly:literal",
      "normalizedOutput": "\"Info\"",
      "fallbackUsed": false,
      "finalValueHash": "6e68b62d2aa611a44f3e7a4cb7e23da9ad1cab1b6abb592bb2795b12fe63e51c"
    },
    {
      "workflowFile": "BGYY_SendGmail.xaml",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "originalRawValue": "\"[BGYY_SendGmail] Gmail send attempt \" & attemptNumber & \"/3 | RunId=\" & InRunId & \" | To=\" & InToEmail",
      "parsedIntentType": "pre-assembly:literal",
      "normalizedOutput": "[\"\"\"[BGYY_SendGmail] Gmail send attempt \"\" & attemptNumber & \"\"/3 | RunId=\"\" & InRunId & \"\" | To=\"\" & InToEmail\"]",
      "fallbackUsed": false,
      "finalValueHash": "f78828cf62890e198884021ec1d4c9d2944d4953015eed5da605b106c05ae149"
    },
    {
      "workflowFile": "BGYY_SendGmail.xaml",
      "activityType": "Comment",
      "propertyName": "Text",
      "originalRawValue": "[HANDOFF] This activity replaces \"Send birthday email via Gmail Integration Service connector\" (UiPath.GSuite.Activities.GmailSendMessage). Missing required properties: Body. Developer must implement the actual UiPath.GSuite.Activities.GmailSendMessage activity with the correct property values.",
      "parsedIntentType": "pre-assembly:literal",
      "normalizedOutput": "[\"[HANDOFF] This activity replaces \"\"Send birthday email via Gmail Integration Service connector\"\" (UiPath.GSuite.Activities.GmailSendMessage). Missing required properties: Body. Developer must implement the actual UiPath.GSuite.Activities.GmailSendMessage activity with the correct property values.\"]",
      "fallbackUsed": false,
      "finalValueHash": "83e41e04866372fffe464b4e454f206e9e3eadd10e1bacaca66201c8243f6ae1"
    },
    {
      "workflowFile": "BGYY_SendGmail.xaml",
      "activityType": "LogMessage",
      "propertyName": "Level",
      "originalRawValue": "Warn",
      "parsedIntentType": "pre-assembly:literal",
      "normalizedOutput": "\"Warn\"",
      "fallbackUsed": false,
      "finalValueHash": "0817e2b865151b33aa686f0551fce818a034cb723e0044e433cd8100810ed280"
    },
    {
      "workflowFile": "BGYY_SendGmail.xaml",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "originalRawValue": "\"[HANDOFF] Activity 'Send birthday email via Gmail Integration Service connector' (UiPath.GSuite.Activities.GmailSendMessage) requires developer implementation — missing: Body\"",
      "parsedIntentType": "pre-assembly:literal",
      "normalizedOutput": "[\"[HANDOFF] Activity 'Send birthday email via Gmail Integration Service connector' (UiPath.GSuite.Activities.GmailSendMessage) requires developer implementation — missing: Body\"]",
      "fallbackUsed": false,
      "finalValueHash": "c389a1b8f4519f6812ce206debd7a3790092aceb4d78805dc77218ae811d048f"
    },
    {
      "workflowFile": "BGYY_SendGmail.xaml",
      "activityType": "LogMessage",
      "propertyName": "Level",
      "originalRawValue": "Error",
      "parsedIntentType": "pre-assembly:literal",
      "normalizedOutput": "\"Error\"",
      "fallbackUsed": false,
      "finalValueHash": "fc4ac19649f0ee8f37c71d2e2030a3743038bb96c0c27359ba115dd8657565cc"
    },
    {
      "workflowFile": "BGYY_SendGmail.xaml",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "originalRawValue": "\"Error in Send birthday email via Gmail Integration Service connector: \" & exception.Message",
      "parsedIntentType": "pre-assembly:literal",
      "normalizedOutput": "[\"\"\"Error in Send birthday email via Gmail Integration Service connector: \"\" & exception.Message\"]",
      "fallbackUsed": false,
      "finalValueHash": "e3b61dac1b77d12522d9810864b4fa10bc85da1f66403442977929e51eabc28a"
    },
    {
      "workflowFile": "BGYY_SendGmail.xaml",
      "activityType": "LogMessage",
      "propertyName": "Level",
      "originalRawValue": "Info",
      "parsedIntentType": "pre-assembly:literal",
      "normalizedOutput": "\"Info\"",
      "fallbackUsed": false,
      "finalValueHash": "6e68b62d2aa611a44f3e7a4cb7e23da9ad1cab1b6abb592bb2795b12fe63e51c"
    },
    {
      "workflowFile": "BGYY_SendGmail.xaml",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "originalRawValue": "\"[BGYY_SendGmail] Email sent successfully on attempt \" & attemptNumber & \" | RunId=\" & InRunId & \" | To=\" & InToEmail",
      "parsedIntentType": "pre-assembly:literal",
      "normalizedOutput": "[\"\"\"[BGYY_SendGmail] Email sent successfully on attempt \"\" & attemptNumber & \"\" | RunId=\"\" & InRunId & \"\" | To=\"\" & InToEmail\"]",
      "fallbackUsed": false,
      "finalValueHash": "53e41fc37c0226bd627892c69b37b93ece4e4ccefcff9991a53695ea47768210"
    },
    {
      "workflowFile": "BGYY_SendGmail.xaml",
      "activityType": "LogMessage",
      "propertyName": "Level",
      "originalRawValue": "Info",
      "parsedIntentType": "pre-assembly:literal",
      "normalizedOutput": "\"Info\"",
      "fallbackUsed": false,
      "finalValueHash": "6e68b62d2aa611a44f3e7a4cb7e23da9ad1cab1b6abb592bb2795b12fe63e51c"
    },
    {
      "workflowFile": "BGYY_SendGmail.xaml",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "originalRawValue": "\"[BGYY_SendGmail] OutGmailMessageId=\" & OutGmailMessageId & \" | RunId=\" & InRunId",
      "parsedIntentType": "pre-assembly:literal",
      "normalizedOutput": "[\"\"\"[BGYY_SendGmail] OutGmailMessageId=\"\" & OutGmailMessageId & \"\" | RunId=\"\" & InRunId\"]",
      "fallbackUsed": false,
      "finalValueHash": "fa25352511c8c209ef4dc1b0a7f94ff474ce84cad6b7727eb09b934e59c2e852"
    },
    {
      "workflowFile": "BGYY_SendGmail.xaml",
      "activityType": "UploadStorageFile",
      "propertyName": "Path",
      "originalRawValue": "errorBucketPath",
      "parsedIntentType": "pre-assembly:literal",
      "normalizedOutput": "\"errorBucketPath\"",
      "fallbackUsed": false,
      "finalValueHash": "2ef4671e9e4da3157fe0762743c0a8a4d7b793ef3ba88e8a09dc76aacc170b53"
    },
    {
      "workflowFile": "BGYY_SendGmail.xaml",
      "activityType": "LogMessage",
      "propertyName": "Level",
      "originalRawValue": "Error",
      "parsedIntentType": "pre-assembly:literal",
      "normalizedOutput": "\"Error\"",
      "fallbackUsed": false,
      "finalValueHash": "fc4ac19649f0ee8f37c71d2e2030a3743038bb96c0c27359ba115dd8657565cc"
    },
    {
      "workflowFile": "BGYY_SendGmail.xaml",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "originalRawValue": "\"[BGYY_SendGmail] PERSISTENT FAILURE — all 3 send attempts failed | RunId=\" & InRunId & \" | To=\" & InToEmail & \" | Screenshot=\" & errorBucketPath",
      "parsedIntentType": "pre-assembly:literal",
      "normalizedOutput": "[\"\"\"[BGYY_SendGmail] PERSISTENT FAILURE — all 3 send attempts failed | RunId=\"\" & InRunId & \"\" | To=\"\" & InToEmail & \"\" | Screenshot=\"\" & errorBucketPath\"]",
      "fallbackUsed": false,
      "finalValueHash": "dcd5e5555836075845238fa896366f20a3b7507843d7dc90ce627c9d6a49cc96"
    },
    {
      "workflowFile": "BGYY_SendGmail.xaml",
      "activityType": "LogMessage",
      "propertyName": "Level",
      "originalRawValue": "Info",
      "parsedIntentType": "pre-assembly:literal",
      "normalizedOutput": "\"Info\"",
      "fallbackUsed": false,
      "finalValueHash": "6e68b62d2aa611a44f3e7a4cb7e23da9ad1cab1b6abb592bb2795b12fe63e51c"
    },
    {
      "workflowFile": "BGYY_SendGmail.xaml",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "originalRawValue": "\"[BGYY_SendGmail] END | RunId=\" & InRunId & \" | GmailMessageId=\" & OutGmailMessageId & \" | DryRun=\" & InDryRun.ToString()",
      "parsedIntentType": "pre-assembly:literal",
      "normalizedOutput": "[\"\"\"[BGYY_SendGmail] END | RunId=\"\" & InRunId & \"\" | GmailMessageId=\"\" & OutGmailMessageId & \"\" | DryRun=\"\" & InDryRun.ToString()\"]",
      "fallbackUsed": false,
      "finalValueHash": "e61fdba4ba655df4cba213ef0a541a19a89b2c49a6d31a7c38c889c8d47b0217"
    },
    {
      "workflowFile": "unknown",
      "activityType": "UploadStorageFile",
      "propertyName": "StorageBucketName",
      "originalRawValue": "{\"type\":\"literal\",\"value\":\"BGYY_RunArtifacts\"}",
      "parsedIntentType": "literal",
      "normalizedOutput": "\"BGYY_RunArtifacts\"",
      "fallbackUsed": false,
      "finalValueHash": "33ba51cda6204d629b13659583987f07350bd4896764a2a53b10faab956ba518"
    },
    {
      "workflowFile": "unknown",
      "activityType": "UploadStorageFile",
      "propertyName": "Path",
      "originalRawValue": "{\"type\":\"literal\",\"value\":\"errorBucketPath\"}",
      "parsedIntentType": "literal",
      "normalizedOutput": "\"errorBucketPath\"",
      "fallbackUsed": false,
      "finalValueHash": "2ef4671e9e4da3157fe0762743c0a8a4d7b793ef3ba88e8a09dc76aacc170b53"
    },
    {
      "workflowFile": "unknown",
      "activityType": "UploadStorageFile",
      "propertyName": "FileResource",
      "originalRawValue": "{\"type\":\"variable\",\"name\":\"screenshotPath\"}",
      "parsedIntentType": "variable",
      "normalizedOutput": "[screenshotPath]",
      "fallbackUsed": false,
      "finalValueHash": "592154e5c61c5c77adb80becdb45e0620bacc19eedd9cb71f9e4db05da727a54"
    },
    {
      "workflowFile": "unknown",
      "activityType": "UploadStorageFile",
      "propertyName": "Destination",
      "originalRawValue": "{\"type\":\"variable\",\"name\":\"errorBucketPath\"}",
      "parsedIntentType": "variable",
      "normalizedOutput": "[errorBucketPath]",
      "fallbackUsed": false,
      "finalValueHash": "62d9a3f6ef952ebb6f319322afa52724f7f259239fd498d14df61f9ab24f5560"
    },
    {
      "workflowFile": "BGYY_WriteSendLog.xaml",
      "activityType": "LogMessage",
      "propertyName": "Level",
      "originalRawValue": "Info",
      "parsedIntentType": "pre-assembly:literal",
      "normalizedOutput": "\"Info\"",
      "fallbackUsed": false,
      "finalValueHash": "6e68b62d2aa611a44f3e7a4cb7e23da9ad1cab1b6abb592bb2795b12fe63e51c"
    },
    {
      "workflowFile": "BGYY_WriteSendLog.xaml",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "originalRawValue": "\"[BGYY_WriteSendLog][START] RunId=\" & InRunId & \" | PersonKey=\" & InPersonKey & \" | Status=\" & InStatus & \" | SendYear=\" & InSendYear.ToString()",
      "parsedIntentType": "pre-assembly:literal",
      "normalizedOutput": "[\"\"\"[BGYY_WriteSendLog][START] RunId=\"\" & InRunId & \"\" | PersonKey=\"\" & InPersonKey & \"\" | Status=\"\" & InStatus & \"\" | SendYear=\"\" & InSendYear.ToString()\"]",
      "fallbackUsed": false,
      "finalValueHash": "801470f67963d5df77871002ada260d7d6537b20910b3966ac75f16cbea034ac"
    },
    {
      "workflowFile": "BGYY_WriteSendLog.xaml",
      "activityType": "LogMessage",
      "propertyName": "Level",
      "originalRawValue": "Warn",
      "parsedIntentType": "pre-assembly:literal",
      "normalizedOutput": "\"Warn\"",
      "fallbackUsed": false,
      "finalValueHash": "0817e2b865151b33aa686f0551fce818a034cb723e0044e433cd8100810ed280"
    },
    {
      "workflowFile": "BGYY_WriteSendLog.xaml",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "originalRawValue": "\"[BGYY_WriteSendLog][SKIP] PersonKey is blank — cannot write send log. RunId=\" & InRunId & \" | PersonName=\" & InPersonName & \" | Status=\" & InStatus",
      "parsedIntentType": "pre-assembly:literal",
      "normalizedOutput": "[\"\"\"[BGYY_WriteSendLog][SKIP] PersonKey is blank — cannot write send log. RunId=\"\" & InRunId & \"\" | PersonName=\"\" & InPersonName & \"\" | Status=\"\" & InStatus\"]",
      "fallbackUsed": false,
      "finalValueHash": "38d647b92eb3d7a425fc4959d45cdc150013a835f1bde43d131dd732cd614188"
    },
    {
      "workflowFile": "BGYY_WriteSendLog.xaml",
      "activityType": "QueryEntity",
      "propertyName": "EntityType",
      "originalRawValue": "BGYY_BirthdaySendLog",
      "parsedIntentType": "pre-assembly:literal",
      "normalizedOutput": "\"BGYY_BirthdaySendLog\"",
      "fallbackUsed": false,
      "finalValueHash": "b004731817a34b4b0811c2cd720f3a3479712719e123cd47f1a76b71faf3049f"
    },
    {
      "workflowFile": "BGYY_WriteSendLog.xaml",
      "activityType": "LogMessage",
      "propertyName": "Level",
      "originalRawValue": "Error",
      "parsedIntentType": "pre-assembly:literal",
      "normalizedOutput": "\"Error\"",
      "fallbackUsed": false,
      "finalValueHash": "fc4ac19649f0ee8f37c71d2e2030a3743038bb96c0c27359ba115dd8657565cc"
    },
    {
      "workflowFile": "BGYY_WriteSendLog.xaml",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "originalRawValue": "\"Error in Query BGYY_BirthdaySendLog for existing record matching PersonKey + SendYear: \" & exception.Message",
      "parsedIntentType": "pre-assembly:literal",
      "normalizedOutput": "[\"\"\"Error in Query BGYY_BirthdaySendLog for existing record matching PersonKey + SendYear: \"\" & exception.Message\"]",
      "fallbackUsed": false,
      "finalValueHash": "83fa0aff62a37a4854e10bcb37de21a561ae4c0d2a56ab3522a9dfd2bd04d403"
    },
    {
      "workflowFile": "BGYY_WriteSendLog.xaml",
      "activityType": "LogMessage",
      "propertyName": "Level",
      "originalRawValue": "Info",
      "parsedIntentType": "pre-assembly:literal",
      "normalizedOutput": "\"Info\"",
      "fallbackUsed": false,
      "finalValueHash": "6e68b62d2aa611a44f3e7a4cb7e23da9ad1cab1b6abb592bb2795b12fe63e51c"
    },
    {
      "workflowFile": "BGYY_WriteSendLog.xaml",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "originalRawValue": "\"[BGYY_WriteSendLog][QUERY] PersonKey=\" & personKeyNormalized & \" | SendYear=\" & InSendYear.ToString() & \" | QueryStatus=\" & If(existingRecords IsNot Nothing, \"RecordsReturned\", \"NullResult\")",
      "parsedIntentType": "pre-assembly:literal",
      "normalizedOutput": "[\"\"\"[BGYY_WriteSendLog][QUERY] PersonKey=\"\" & personKeyNormalized & \"\" | SendYear=\"\" & InSendYear.ToString() & \"\" | QueryStatus=\"\" & If(existingRecords IsNot Nothing, \"\"RecordsReturned\"\", \"\"NullResult\"\")\"]",
      "fallbackUsed": false,
      "finalValueHash": "8cb3a1de060cb9cd41b147f3842bbd333ad5311f25da1fc8dab22e06e550a41e"
    },
    {
      "workflowFile": "BGYY_WriteSendLog.xaml",
      "activityType": "LogMessage",
      "propertyName": "Level",
      "originalRawValue": "Info",
      "parsedIntentType": "pre-assembly:literal",
      "normalizedOutput": "\"Info\"",
      "fallbackUsed": false,
      "finalValueHash": "6e68b62d2aa611a44f3e7a4cb7e23da9ad1cab1b6abb592bb2795b12fe63e51c"
    },
    {
      "workflowFile": "BGYY_WriteSendLog.xaml",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "originalRawValue": "\"[BGYY_WriteSendLog][UPDATE] Existing record found. RecordId=\" & existingRecordId & \" | PersonKey=\" & personKeyNormalized & \" | NewStatus=\" & InStatus",
      "parsedIntentType": "pre-assembly:literal",
      "normalizedOutput": "[\"\"\"[BGYY_WriteSendLog][UPDATE] Existing record found. RecordId=\"\" & existingRecordId & \"\" | PersonKey=\"\" & personKeyNormalized & \"\" | NewStatus=\"\" & InStatus\"]",
      "fallbackUsed": false,
      "finalValueHash": "e9f6ca5bc3c1bdb144757bc01b4c0e5fb4e34c692f25f6fd14927cbd893616ae"
    },
    {
      "workflowFile": "BGYY_WriteSendLog.xaml",
      "activityType": "Comment",
      "propertyName": "Text",
      "originalRawValue": "[HANDOFF] This activity replaces \"Update existing BGYY_BirthdaySendLog record with latest outcome fields\" (UiPath.DataService.Activities.UpdateEntity). Missing required properties: EntityObject. Developer must implement the actual UiPath.DataService.Activities.UpdateEntity activity with the correct property values.",
      "parsedIntentType": "pre-assembly:literal",
      "normalizedOutput": "[\"[HANDOFF] This activity replaces \"\"Update existing BGYY_BirthdaySendLog record with latest outcome fields\"\" (UiPath.DataService.Activities.UpdateEntity). Missing required properties: EntityObject. Developer must implement the actual UiPath.DataService.Activities.UpdateEntity activity with the correct property values.\"]",
      "fallbackUsed": false,
      "finalValueHash": "1f0973a086ea666c6d8f304fc29c5fd50c87de00dba6cd14cc0241d98ffe11ce"
    },
    {
      "workflowFile": "BGYY_WriteSendLog.xaml",
      "activityType": "LogMessage",
      "propertyName": "Level",
      "originalRawValue": "Warn",
      "parsedIntentType": "pre-assembly:literal",
      "normalizedOutput": "\"Warn\"",
      "fallbackUsed": false,
      "finalValueHash": "0817e2b865151b33aa686f0551fce818a034cb723e0044e433cd8100810ed280"
    },
    {
      "workflowFile": "BGYY_WriteSendLog.xaml",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "originalRawValue": "\"[HANDOFF] Activity 'Update existing BGYY_BirthdaySendLog record with latest outcome fields' (UiPath.DataService.Activities.UpdateEntity) requires developer implementation — missing: EntityObject\"",
      "parsedIntentType": "pre-assembly:literal",
      "normalizedOutput": "[\"[HANDOFF] Activity 'Update existing BGYY_BirthdaySendLog record with latest outcome fields' (UiPath.DataService.Activities.UpdateEntity) requires developer implementation — missing: EntityObject\"]",
      "fallbackUsed": false,
      "finalValueHash": "77bc9948bb63351bc7c22dddf453843e71fe1116628973cb2194ca1403446b65"
    },
    {
      "workflowFile": "BGYY_WriteSendLog.xaml",
      "activityType": "LogMessage",
      "propertyName": "Level",
      "originalRawValue": "Error",
      "parsedIntentType": "pre-assembly:literal",
      "normalizedOutput": "\"Error\"",
      "fallbackUsed": false,
      "finalValueHash": "fc4ac19649f0ee8f37c71d2e2030a3743038bb96c0c27359ba115dd8657565cc"
    },
    {
      "workflowFile": "BGYY_WriteSendLog.xaml",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "originalRawValue": "\"Error in Update existing BGYY_BirthdaySendLog record with latest outcome fields: \" & exception.Message",
      "parsedIntentType": "pre-assembly:literal",
      "normalizedOutput": "[\"\"\"Error in Update existing BGYY_BirthdaySendLog record with latest outcome fields: \"\" & exception.Message\"]",
      "fallbackUsed": false,
      "finalValueHash": "e2e0bc5178eef165632e6394c0999f19cc150689a94e392928567356736c21d1"
    },
    {
      "workflowFile": "BGYY_WriteSendLog.xaml",
      "activityType": "LogMessage",
      "propertyName": "Level",
      "originalRawValue": "Info",
      "parsedIntentType": "pre-assembly:literal",
      "normalizedOutput": "\"Info\"",
      "fallbackUsed": false,
      "finalValueHash": "6e68b62d2aa611a44f3e7a4cb7e23da9ad1cab1b6abb592bb2795b12fe63e51c"
    },
    {
      "workflowFile": "BGYY_WriteSendLog.xaml",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "originalRawValue": "\"[BGYY_WriteSendLog][UPDATE-OK] RecordId=\" & existingRecordId & \" | Status=\" & InStatus & \" | PersonName=\" & InPersonName & \" | RunId=\" & InRunId",
      "parsedIntentType": "pre-assembly:literal",
      "normalizedOutput": "[\"\"\"[BGYY_WriteSendLog][UPDATE-OK] RecordId=\"\" & existingRecordId & \"\" | Status=\"\" & InStatus & \"\" | PersonName=\"\" & InPersonName & \"\" | RunId=\"\" & InRunId\"]",
      "fallbackUsed": false,
      "finalValueHash": "aa73c390842491c51079b424db9e55c503c6cb6e4e9659259d009e15820b0e66"
    },
    {
      "workflowFile": "BGYY_WriteSendLog.xaml",
      "activityType": "LogMessage",
      "propertyName": "Level",
      "originalRawValue": "Info",
      "parsedIntentType": "pre-assembly:literal",
      "normalizedOutput": "\"Info\"",
      "fallbackUsed": false,
      "finalValueHash": "6e68b62d2aa611a44f3e7a4cb7e23da9ad1cab1b6abb592bb2795b12fe63e51c"
    },
    {
      "workflowFile": "BGYY_WriteSendLog.xaml",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "originalRawValue": "\"[BGYY_WriteSendLog][CREATE] No existing record. PersonKey=\" & personKeyNormalized & \" | Status=\" & InStatus & \" | RunId=\" & InRunId",
      "parsedIntentType": "pre-assembly:literal",
      "normalizedOutput": "[\"\"\"[BGYY_WriteSendLog][CREATE] No existing record. PersonKey=\"\" & personKeyNormalized & \"\" | Status=\"\" & InStatus & \"\" | RunId=\"\" & InRunId\"]",
      "fallbackUsed": false,
      "finalValueHash": "2f30ec59a2275d88e5762635e84758c00bac09c0fdf9fc4b57e0d259b9e3e9b2"
    },
    {
      "workflowFile": "BGYY_WriteSendLog.xaml",
      "activityType": "Comment",
      "propertyName": "Text",
      "originalRawValue": "[HANDOFF] This activity replaces \"Create new BGYY_BirthdaySendLog record with all audit fields\" (UiPath.DataService.Activities.CreateEntity). Missing required properties: EntityObject. Developer must implement the actual UiPath.DataService.Activities.CreateEntity activity with the correct property values.",
      "parsedIntentType": "pre-assembly:literal",
      "normalizedOutput": "[\"[HANDOFF] This activity replaces \"\"Create new BGYY_BirthdaySendLog record with all audit fields\"\" (UiPath.DataService.Activities.CreateEntity). Missing required properties: EntityObject. Developer must implement the actual UiPath.DataService.Activities.CreateEntity activity with the correct property values.\"]",
      "fallbackUsed": false,
      "finalValueHash": "e52a4da2bf8e347d83eef8e25c9c098518294950c127f79f458a026d968a52ae"
    },
    {
      "workflowFile": "BGYY_WriteSendLog.xaml",
      "activityType": "LogMessage",
      "propertyName": "Level",
      "originalRawValue": "Warn",
      "parsedIntentType": "pre-assembly:literal",
      "normalizedOutput": "\"Warn\"",
      "fallbackUsed": false,
      "finalValueHash": "0817e2b865151b33aa686f0551fce818a034cb723e0044e433cd8100810ed280"
    },
    {
      "workflowFile": "BGYY_WriteSendLog.xaml",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "originalRawValue": "\"[HANDOFF] Activity 'Create new BGYY_BirthdaySendLog record with all audit fields' (UiPath.DataService.Activities.CreateEntity) requires developer implementation — missing: EntityObject\"",
      "parsedIntentType": "pre-assembly:literal",
      "normalizedOutput": "[\"[HANDOFF] Activity 'Create new BGYY_BirthdaySendLog record with all audit fields' (UiPath.DataService.Activities.CreateEntity) requires developer implementation — missing: EntityObject\"]",
      "fallbackUsed": false,
      "finalValueHash": "268991659d74caff275a2a525128510c9b69eef4efa4f16bbb3d30196fee50e2"
    },
    {
      "workflowFile": "BGYY_WriteSendLog.xaml",
      "activityType": "LogMessage",
      "propertyName": "Level",
      "originalRawValue": "Error",
      "parsedIntentType": "pre-assembly:literal",
      "normalizedOutput": "\"Error\"",
      "fallbackUsed": false,
      "finalValueHash": "fc4ac19649f0ee8f37c71d2e2030a3743038bb96c0c27359ba115dd8657565cc"
    },
    {
      "workflowFile": "BGYY_WriteSendLog.xaml",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "originalRawValue": "\"Error in Create new BGYY_BirthdaySendLog record with all audit fields: \" & exception.Message",
      "parsedIntentType": "pre-assembly:literal",
      "normalizedOutput": "[\"\"\"Error in Create new BGYY_BirthdaySendLog record with all audit fields: \"\" & exception.Message\"]",
      "fallbackUsed": false,
      "finalValueHash": "ce984b5673b546e852380647b0ae046010d9f43599fb2afd5746ab63e635297e"
    },
    {
      "workflowFile": "BGYY_WriteSendLog.xaml",
      "activityType": "LogMessage",
      "propertyName": "Level",
      "originalRawValue": "Info",
      "parsedIntentType": "pre-assembly:literal",
      "normalizedOutput": "\"Info\"",
      "fallbackUsed": false,
      "finalValueHash": "6e68b62d2aa611a44f3e7a4cb7e23da9ad1cab1b6abb592bb2795b12fe63e51c"
    },
    {
      "workflowFile": "BGYY_WriteSendLog.xaml",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "originalRawValue": "\"[BGYY_WriteSendLog][CREATE-OK] New record created. PersonKey=\" & personKeyNormalized & \" | Status=\" & InStatus & \" | PersonName=\" & InPersonName & \" | RunId=\" & InRunId",
      "parsedIntentType": "pre-assembly:literal",
      "normalizedOutput": "[\"\"\"[BGYY_WriteSendLog][CREATE-OK] New record created. PersonKey=\"\" & personKeyNormalized & \"\" | Status=\"\" & InStatus & \"\" | PersonName=\"\" & InPersonName & \"\" | RunId=\"\" & InRunId\"]",
      "fallbackUsed": false,
      "finalValueHash": "c381a5bc07d4961c89e12646ba3344227d893517de53609b1e1271660d933bbc"
    },
    {
      "workflowFile": "BGYY_WriteSendLog.xaml",
      "activityType": "LogMessage",
      "propertyName": "Level",
      "originalRawValue": "Error",
      "parsedIntentType": "pre-assembly:literal",
      "normalizedOutput": "\"Error\"",
      "fallbackUsed": false,
      "finalValueHash": "fc4ac19649f0ee8f37c71d2e2030a3743038bb96c0c27359ba115dd8657565cc"
    },
    {
      "workflowFile": "BGYY_WriteSendLog.xaml",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "originalRawValue": "\"[BGYY_WriteSendLog][ERROR] Data Service write failed — record NOT persisted. PersonKey=\" & personKeyNormalized & \" | Status=\" & InStatus & \" | RunId=\" & InRunId & \" | RecordExists=\" & recordExists.ToString() & \" | Exception=\" & errorMessage",
      "parsedIntentType": "pre-assembly:literal",
      "normalizedOutput": "[\"\"\"[BGYY_WriteSendLog][ERROR] Data Service write failed — record NOT persisted. PersonKey=\"\" & personKeyNormalized & \"\" | Status=\"\" & InStatus & \"\" | RunId=\"\" & InRunId & \"\" | RecordExists=\"\" & recordExists.ToString() & \"\" | Exception=\"\" & errorMessage\"]",
      "fallbackUsed": false,
      "finalValueHash": "10757d5010503ada513ceb3c1d9be0f8ca77dc4667f5adca129d6cc39ccc0bf1"
    },
    {
      "workflowFile": "BGYY_WriteSendLog.xaml",
      "activityType": "LogMessage",
      "propertyName": "Level",
      "originalRawValue": "Info",
      "parsedIntentType": "pre-assembly:literal",
      "normalizedOutput": "\"Info\"",
      "fallbackUsed": false,
      "finalValueHash": "6e68b62d2aa611a44f3e7a4cb7e23da9ad1cab1b6abb592bb2795b12fe63e51c"
    },
    {
      "workflowFile": "BGYY_WriteSendLog.xaml",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "originalRawValue": "\"[BGYY_WriteSendLog][END] PersonKey=\" & personKeyNormalized & \" | Status=\" & InStatus & \" | RecordExists=\" & recordExists.ToString() & \" | RunId=\" & InRunId",
      "parsedIntentType": "pre-assembly:literal",
      "normalizedOutput": "[\"\"\"[BGYY_WriteSendLog][END] PersonKey=\"\" & personKeyNormalized & \"\" | Status=\"\" & InStatus & \"\" | RecordExists=\"\" & recordExists.ToString() & \"\" | RunId=\"\" & InRunId\"]",
      "fallbackUsed": false,
      "finalValueHash": "b10af0d0d544624423038b5cfdfe7397c5cfd0889676295f279f17bba55c477e"
    },
    {
      "workflowFile": "unknown",
      "activityType": "QueryEntity",
      "propertyName": "EntityType",
      "originalRawValue": "{\"type\":\"literal\",\"value\":\"BGYY_BirthdaySendLog\"}",
      "parsedIntentType": "literal",
      "normalizedOutput": "\"BGYY_BirthdaySendLog\"",
      "fallbackUsed": false,
      "finalValueHash": "b004731817a34b4b0811c2cd720f3a3479712719e123cd47f1a76b71faf3049f"
    },
    {
      "workflowFile": "unknown",
      "activityType": "QueryEntity",
      "propertyName": "Result",
      "originalRawValue": "{\"type\":\"variable\",\"name\":\"existingRecords\"}",
      "parsedIntentType": "variable",
      "normalizedOutput": "[existingRecords]",
      "fallbackUsed": false,
      "finalValueHash": "37bd50ae1bf3a245b5141b79b04ceb1fb42e3a52dadd246a85e6b308b80ecc88"
    },
    {
      "workflowFile": "BGYY_CreateReviewTask.xaml",
      "activityType": "LogMessage",
      "propertyName": "Level",
      "originalRawValue": "Info",
      "parsedIntentType": "pre-assembly:literal",
      "normalizedOutput": "\"Info\"",
      "fallbackUsed": false,
      "finalValueHash": "6e68b62d2aa611a44f3e7a4cb7e23da9ad1cab1b6abb592bb2795b12fe63e51c"
    },
    {
      "workflowFile": "BGYY_CreateReviewTask.xaml",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "originalRawValue": "\"[BGYY_CreateReviewTask][INFO] Starting review task creation. RunId=\" & in_RunId & \" | EventId=\" & in_EventId & \" | FullName=\" & in_FullName & \" | FailReason=\" & in_FailReason",
      "parsedIntentType": "pre-assembly:literal",
      "normalizedOutput": "[\"\"\"[BGYY_CreateReviewTask][INFO] Starting review task creation. RunId=\"\" & in_RunId & \"\" | EventId=\"\" & in_EventId & \"\" | FullName=\"\" & in_FullName & \"\" | FailReason=\"\" & in_FailReason\"]",
      "fallbackUsed": false,
      "finalValueHash": "1f73d0ed221761260a74c8e1a6ad8a9067a3a9d6d8a0e252ba0ccdf8dea709e5"
    },
    {
      "workflowFile": "BGYY_CreateReviewTask.xaml",
      "activityType": "Assign",
      "propertyName": "Value",
      "originalRawValue": "DateTime.UtcNow.AddHours(2)",
      "parsedIntentType": "pre-assembly:variable",
      "normalizedOutput": "[DateTime.UtcNow.AddHours(2)]",
      "fallbackUsed": false,
      "finalValueHash": "39bb225deef9b7186c2f15835bf9175360d7e45392e86abc47f4e74fd71ed909"
    },
    {
      "workflowFile": "BGYY_CreateReviewTask.xaml",
      "activityType": "Assign",
      "propertyName": "Value",
      "originalRawValue": "\"[BGYY] Birthday Greeting Review – \" & in_FullName & \" (Run: \" & in_RunId & \")\"",
      "parsedIntentType": "pre-assembly:literal",
      "normalizedOutput": "[\"[BGYY] Birthday Greeting Review – \"\" & in_FullName & \"\" (Run: \"\" & in_RunId & \"\")\"]",
      "fallbackUsed": false,
      "finalValueHash": "2fa58c083e8c18e77edd43b46bf02c85e47b93bad6dc12e429cf321f39606969"
    },
    {
      "workflowFile": "BGYY_CreateReviewTask.xaml",
      "activityType": "Comment",
      "propertyName": "Text",
      "originalRawValue": "[HANDOFF] This activity replaces \"Create Action Center Form Task in BGYY_DraftReview Catalog\" (UiPath.Persistence.Activities.CreateFormTask). Missing required properties: TaskTitle. Developer must implement the actual UiPath.Persistence.Activities.CreateFormTask activity with the correct property values.",
      "parsedIntentType": "pre-assembly:literal",
      "normalizedOutput": "[\"[HANDOFF] This activity replaces \"\"Create Action Center Form Task in BGYY_DraftReview Catalog\"\" (UiPath.Persistence.Activities.CreateFormTask). Missing required properties: TaskTitle. Developer must implement the actual UiPath.Persistence.Activities.CreateFormTask activity with the correct property values.\"]",
      "fallbackUsed": false,
      "finalValueHash": "f0135eb189b3172d0629fd81273c5db0723e3b17b9239cc2966ed7d98d85f916"
    },
    {
      "workflowFile": "BGYY_CreateReviewTask.xaml",
      "activityType": "LogMessage",
      "propertyName": "Level",
      "originalRawValue": "Warn",
      "parsedIntentType": "pre-assembly:literal",
      "normalizedOutput": "\"Warn\"",
      "fallbackUsed": false,
      "finalValueHash": "0817e2b865151b33aa686f0551fce818a034cb723e0044e433cd8100810ed280"
    },
    {
      "workflowFile": "BGYY_CreateReviewTask.xaml",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "originalRawValue": "\"[HANDOFF] Activity 'Create Action Center Form Task in BGYY_DraftReview Catalog' (UiPath.Persistence.Activities.CreateFormTask) requires developer implementation — missing: TaskTitle\"",
      "parsedIntentType": "pre-assembly:literal",
      "normalizedOutput": "[\"[HANDOFF] Activity 'Create Action Center Form Task in BGYY_DraftReview Catalog' (UiPath.Persistence.Activities.CreateFormTask) requires developer implementation — missing: TaskTitle\"]",
      "fallbackUsed": false,
      "finalValueHash": "7b5c6d3e0738b5929e52d821abfad8524f3d1f14e41ba80edf31a674ab54e9cc"
    },
    {
      "workflowFile": "BGYY_CreateReviewTask.xaml",
      "activityType": "Assign",
      "propertyName": "Value",
      "originalRawValue": "If(obj_FormTaskObject IsNot Nothing, obj_FormTaskObject.ToString(), \"\")",
      "parsedIntentType": "pre-assembly:literal",
      "normalizedOutput": "[\"[If(obj_FormTaskObject IsNot Nothing, obj_FormTaskObject.ToString(), \"\"\"\")]\"]",
      "fallbackUsed": false,
      "finalValueHash": "151aba106cf28ae9361b74c6b780066e8a2da471cfcc40aa7643e4c1b9ad4b6f"
    },
    {
      "workflowFile": "BGYY_CreateReviewTask.xaml",
      "activityType": "LogMessage",
      "propertyName": "Level",
      "originalRawValue": "Info",
      "parsedIntentType": "pre-assembly:literal",
      "normalizedOutput": "\"Info\"",
      "fallbackUsed": false,
      "finalValueHash": "6e68b62d2aa611a44f3e7a4cb7e23da9ad1cab1b6abb592bb2795b12fe63e51c"
    },
    {
      "workflowFile": "BGYY_CreateReviewTask.xaml",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "originalRawValue": "\"[BGYY_CreateReviewTask][INFO] Action Center task created successfully. TaskId=\" & str_CreatedTaskId & \" | FullName=\" & in_FullName & \" | RunId=\" & in_RunId",
      "parsedIntentType": "pre-assembly:literal",
      "normalizedOutput": "[\"\"\"[BGYY_CreateReviewTask][INFO] Action Center task created successfully. TaskId=\"\" & str_CreatedTaskId & \"\" | FullName=\"\" & in_FullName & \"\" | RunId=\"\" & in_RunId\"]",
      "fallbackUsed": false,
      "finalValueHash": "b7d3f39efa1b96553d8052abb4a19ec3f557493185a3c6f968b729ee968723d5"
    },
    {
      "workflowFile": "BGYY_CreateReviewTask.xaml",
      "activityType": "Assign",
      "propertyName": "Value",
      "originalRawValue": "ex_TaskCreation",
      "parsedIntentType": "pre-assembly:literal",
      "normalizedOutput": "\"ex_TaskCreation\"",
      "fallbackUsed": false,
      "finalValueHash": "357c32ea2c781345b19fd60c1f7836d1d794d5ff93384fc5a6d959f6548d9541"
    },
    {
      "workflowFile": "BGYY_CreateReviewTask.xaml",
      "activityType": "LogMessage",
      "propertyName": "Level",
      "originalRawValue": "Error",
      "parsedIntentType": "pre-assembly:literal",
      "normalizedOutput": "\"Error\"",
      "fallbackUsed": false,
      "finalValueHash": "fc4ac19649f0ee8f37c71d2e2030a3743038bb96c0c27359ba115dd8657565cc"
    },
    {
      "workflowFile": "BGYY_CreateReviewTask.xaml",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "originalRawValue": "\"[BGYY_CreateReviewTask][ERROR] Failed to create Action Center task. FullName=\" & in_FullName & \" | RunId=\" & in_RunId & \" | Error=\" & ex_TaskCreation.Message",
      "parsedIntentType": "pre-assembly:literal",
      "normalizedOutput": "[\"\"\"[BGYY_CreateReviewTask][ERROR] Failed to create Action Center task. FullName=\"\" & in_FullName & \"\" | RunId=\"\" & in_RunId & \"\" | Error=\"\" & ex_TaskCreation.Message\"]",
      "fallbackUsed": false,
      "finalValueHash": "34306f954e359a9dff25e1adc8fb052cd216f14fb1da0068ef3352aa4efd5337"
    },
    {
      "workflowFile": "BGYY_CreateReviewTask.xaml",
      "activityType": "Assign",
      "propertyName": "Value",
      "originalRawValue": "\"\"",
      "parsedIntentType": "pre-assembly:literal",
      "normalizedOutput": "\"\"",
      "fallbackUsed": false,
      "finalValueHash": "12ae32cb1ec02d01eda3581b127c1fee3b0dc53572ed6baf239721a03d82e126"
    },
    {
      "workflowFile": "BGYY_CreateReviewTask.xaml",
      "activityType": "Assign",
      "propertyName": "To",
      "originalRawValue": "out_TaskId",
      "parsedIntentType": "pre-assembly:variable",
      "normalizedOutput": "[out_TaskId]",
      "fallbackUsed": false,
      "finalValueHash": "8cb08c836922ff9f63df52ad510f96215965bd2ee3d66fe19b8438ca697b3c82"
    },
    {
      "workflowFile": "BGYY_CreateReviewTask.xaml",
      "activityType": "LogMessage",
      "propertyName": "Level",
      "originalRawValue": "Info",
      "parsedIntentType": "pre-assembly:literal",
      "normalizedOutput": "\"Info\"",
      "fallbackUsed": false,
      "finalValueHash": "6e68b62d2aa611a44f3e7a4cb7e23da9ad1cab1b6abb592bb2795b12fe63e51c"
    },
    {
      "workflowFile": "BGYY_CreateReviewTask.xaml",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "originalRawValue": "\"[BGYY_CreateReviewTask][INFO] Review task workflow complete. out_TaskId=\" & out_TaskId & \" | FullName=\" & in_FullName & \" | RunId=\" & in_RunId",
      "parsedIntentType": "pre-assembly:literal",
      "normalizedOutput": "[\"\"\"[BGYY_CreateReviewTask][INFO] Review task workflow complete. out_TaskId=\"\" & out_TaskId & \"\" | FullName=\"\" & in_FullName & \"\" | RunId=\"\" & in_RunId\"]",
      "fallbackUsed": false,
      "finalValueHash": "5b9dae210839815cd540800b1717d5cd5fc0484581d4648ffa5c92c89dcefcd1"
    },
    {
      "workflowFile": "BGYY_Main.xaml",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "originalRawValue": "[BGYY_Main] Workflow started. Initializing run.",
      "parsedIntentType": "pre-assembly:literal",
      "normalizedOutput": "\"[BGYY_Main] Workflow started. Initializing run.\"",
      "fallbackUsed": false,
      "finalValueHash": "ec2735b52f7741bff4f40d6b6022f88028dcc2b69ba5d7578627b492ef4bc344"
    },
    {
      "workflowFile": "BGYY_Main.xaml",
      "activityType": "LogMessage",
      "propertyName": "Level",
      "originalRawValue": "Info",
      "parsedIntentType": "pre-assembly:literal",
      "normalizedOutput": "\"Info\"",
      "fallbackUsed": false,
      "finalValueHash": "6e68b62d2aa611a44f3e7a4cb7e23da9ad1cab1b6abb592bb2795b12fe63e51c"
    },
    {
      "workflowFile": "BGYY_Main.xaml",
      "activityType": "GetAsset",
      "propertyName": "AssetName",
      "originalRawValue": "BGYY_DryRun",
      "parsedIntentType": "pre-assembly:literal",
      "normalizedOutput": "\"BGYY_DryRun\"",
      "fallbackUsed": false,
      "finalValueHash": "beb5b97a17d99ba63c78b7dfb2431e875c688a90f25961b9435af2b41f091b01"
    },
    {
      "workflowFile": "BGYY_Main.xaml",
      "activityType": "LogMessage",
      "propertyName": "Level",
      "originalRawValue": "Error",
      "parsedIntentType": "pre-assembly:literal",
      "normalizedOutput": "\"Error\"",
      "fallbackUsed": false,
      "finalValueHash": "fc4ac19649f0ee8f37c71d2e2030a3743038bb96c0c27359ba115dd8657565cc"
    },
    {
      "workflowFile": "BGYY_Main.xaml",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "originalRawValue": "\"Error in Read BGYY_DryRun Orchestrator asset: \" & exception.Message",
      "parsedIntentType": "pre-assembly:literal",
      "normalizedOutput": "[\"\"\"Error in Read BGYY_DryRun Orchestrator asset: \"\" & exception.Message\"]",
      "fallbackUsed": false,
      "finalValueHash": "27551934e6a0496193030459e63d4067bec3c15cb512df263752842307dafeae"
    },
    {
      "workflowFile": "BGYY_Main.xaml",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "originalRawValue": "\"[BGYY_Main] RunId=\" & runId & \" | DryRun=\" & isDryRun.ToString() & \" | SendYear=\" & sendYear.ToString()",
      "parsedIntentType": "pre-assembly:literal",
      "normalizedOutput": "[\"\"\"[BGYY_Main] RunId=\"\" & runId & \"\" | DryRun=\"\" & isDryRun.ToString() & \"\" | SendYear=\"\" & sendYear.ToString()\"]",
      "fallbackUsed": false,
      "finalValueHash": "9aff6a014329bb40e853f1c405fba2dbd630ee47c56349893c1a441b78857cbf"
    },
    {
      "workflowFile": "BGYY_Main.xaml",
      "activityType": "LogMessage",
      "propertyName": "Level",
      "originalRawValue": "Info",
      "parsedIntentType": "pre-assembly:literal",
      "normalizedOutput": "\"Info\"",
      "fallbackUsed": false,
      "finalValueHash": "6e68b62d2aa611a44f3e7a4cb7e23da9ad1cab1b6abb592bb2795b12fe63e51c"
    },
    {
      "workflowFile": "BGYY_Main.xaml",
      "activityType": "InvokeWorkflowFile",
      "propertyName": "WorkflowFileName",
      "originalRawValue": "BGYY_GetTodaysBirthdays.xaml",
      "parsedIntentType": "pre-assembly:literal",
      "normalizedOutput": "\"BGYY_GetTodaysBirthdays.xaml\"",
      "fallbackUsed": false,
      "finalValueHash": "9ed994ce22116c1c822fc7439ec25681df50a1ab4084caeeb45efc5ae8a72226"
    },
    {
      "workflowFile": "BGYY_Main.xaml",
      "activityType": "LogMessage",
      "propertyName": "Level",
      "originalRawValue": "Error",
      "parsedIntentType": "pre-assembly:literal",
      "normalizedOutput": "\"Error\"",
      "fallbackUsed": false,
      "finalValueHash": "fc4ac19649f0ee8f37c71d2e2030a3743038bb96c0c27359ba115dd8657565cc"
    },
    {
      "workflowFile": "BGYY_Main.xaml",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "originalRawValue": "\"Error in Invoke BGYY_GetTodaysBirthdays to retrieve today's birthday events: \" & exception.Message",
      "parsedIntentType": "pre-assembly:literal",
      "normalizedOutput": "[\"\"\"Error in Invoke BGYY_GetTodaysBirthdays to retrieve today's birthday events: \"\" & exception.Message\"]",
      "fallbackUsed": false,
      "finalValueHash": "34e3f4f2b0cd491cefceaab0d6393046a31e09972650ac8e8da1118c654f1889"
    },
    {
      "workflowFile": "BGYY_Main.xaml",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "originalRawValue": "\"[BGYY_Main] RunId=\" & runId & \" | No birthday events found for today. Run complete with 0 items.\"",
      "parsedIntentType": "pre-assembly:literal",
      "normalizedOutput": "[\"[BGYY_Main] RunId=\"\" & runId & \"\" | No birthday events found for today. Run complete with 0 items.\"]",
      "fallbackUsed": false,
      "finalValueHash": "bfe243c92e30a655a63ffc02cde8b99701e9735378aea12e893a1049ced7393b"
    },
    {
      "workflowFile": "BGYY_Main.xaml",
      "activityType": "LogMessage",
      "propertyName": "Level",
      "originalRawValue": "Info",
      "parsedIntentType": "pre-assembly:literal",
      "normalizedOutput": "\"Info\"",
      "fallbackUsed": false,
      "finalValueHash": "6e68b62d2aa611a44f3e7a4cb7e23da9ad1cab1b6abb592bb2795b12fe63e51c"
    },
    {
      "workflowFile": "BGYY_Main.xaml",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "originalRawValue": "\"[BGYY_Main] RunId=\" & runId & \" | Birthday events to process: \" & totalEvents.ToString()",
      "parsedIntentType": "pre-assembly:literal",
      "normalizedOutput": "[\"\"\"[BGYY_Main] RunId=\"\" & runId & \"\" | Birthday events to process: \"\" & totalEvents.ToString()\"]",
      "fallbackUsed": false,
      "finalValueHash": "b29453d8b4bd7bc2aefee4bf5139a5d06d4791f96db9700486052cb790cfe323"
    },
    {
      "workflowFile": "BGYY_Main.xaml",
      "activityType": "LogMessage",
      "propertyName": "Level",
      "originalRawValue": "Info",
      "parsedIntentType": "pre-assembly:literal",
      "normalizedOutput": "\"Info\"",
      "fallbackUsed": false,
      "finalValueHash": "6e68b62d2aa611a44f3e7a4cb7e23da9ad1cab1b6abb592bb2795b12fe63e51c"
    },
    {
      "workflowFile": "BGYY_Main.xaml",
      "activityType": "LogMessage",
      "propertyName": "Level",
      "originalRawValue": "Error",
      "parsedIntentType": "pre-assembly:literal",
      "normalizedOutput": "\"Error\"",
      "fallbackUsed": false,
      "finalValueHash": "fc4ac19649f0ee8f37c71d2e2030a3743038bb96c0c27359ba115dd8657565cc"
    },
    {
      "workflowFile": "BGYY_Main.xaml",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "originalRawValue": "\"Error in Extract FullName, EventId, and OccurrenceStart from current event object: \" & exception.Message",
      "parsedIntentType": "pre-assembly:literal",
      "normalizedOutput": "[\"\"\"Error in Extract FullName, EventId, and OccurrenceStart from current event object: \"\" & exception.Message\"]",
      "fallbackUsed": false,
      "finalValueHash": "31cf3b5b3eab2a7cd1afb07c097b6508af8ad5d5a2471260b9912730bcced087"
    },
    {
      "workflowFile": "BGYY_Main.xaml",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "originalRawValue": "\"[BGYY_Main] RunId=\" & runId & \" | Processing event: FullName='\" & currentFullName & \"' | EventId=\" & currentEventId & \" | PersonKey=\" & personKey",
      "parsedIntentType": "pre-assembly:literal",
      "normalizedOutput": "[\"\"\"[BGYY_Main] RunId=\"\" & runId & \"\" | Processing event: FullName='\"\" & currentFullName & \"\"' | EventId=\"\" & currentEventId & \"\" | PersonKey=\"\" & personKey\"]",
      "fallbackUsed": false,
      "finalValueHash": "80e1382e14bf25d1502f561e377c36411d883adfff4550e113599223e815dc8a"
    },
    {
      "workflowFile": "BGYY_Main.xaml",
      "activityType": "LogMessage",
      "propertyName": "Level",
      "originalRawValue": "Info",
      "parsedIntentType": "pre-assembly:literal",
      "normalizedOutput": "\"Info\"",
      "fallbackUsed": false,
      "finalValueHash": "6e68b62d2aa611a44f3e7a4cb7e23da9ad1cab1b6abb592bb2795b12fe63e51c"
    },
    {
      "workflowFile": "BGYY_Main.xaml",
      "activityType": "InvokeWorkflowFile",
      "propertyName": "WorkflowFileName",
      "originalRawValue": "BGYY_ResolveRecipient.xaml",
      "parsedIntentType": "pre-assembly:literal",
      "normalizedOutput": "\"BGYY_ResolveRecipient.xaml\"",
      "fallbackUsed": false,
      "finalValueHash": "5f1c6e4e33469cd7da4f4ac074891b182fa6de81bab620ccb978f8c15977338d"
    },
    {
      "workflowFile": "BGYY_Main.xaml",
      "activityType": "LogMessage",
      "propertyName": "Level",
      "originalRawValue": "Error",
      "parsedIntentType": "pre-assembly:literal",
      "normalizedOutput": "\"Error\"",
      "fallbackUsed": false,
      "finalValueHash": "fc4ac19649f0ee8f37c71d2e2030a3743038bb96c0c27359ba115dd8657565cc"
    },
    {
      "workflowFile": "BGYY_Main.xaml",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "originalRawValue": "\"Error in Invoke BGYY_ResolveRecipient to look up contact email: \" & exception.Message",
      "parsedIntentType": "pre-assembly:literal",
      "normalizedOutput": "[\"\"\"Error in Invoke BGYY_ResolveRecipient to look up contact email: \"\" & exception.Message\"]",
      "fallbackUsed": false,
      "finalValueHash": "b5a3b37a9fce05249c4b78ae1a5366f30a2a624496aec5dccc76085ebc642a2f"
    },
    {
      "workflowFile": "BGYY_Main.xaml",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "originalRawValue": "\"[BGYY_Main] RunId=\" & runId & \" | WARN: Ambiguous contact match for FullName='\" & currentFullName & \"'. Creating Action Center review task.\"",
      "parsedIntentType": "pre-assembly:literal",
      "normalizedOutput": "[\"[BGYY_Main] RunId=\"\" & runId & \"\" | WARN: Ambiguous contact match for FullName='\"\" & currentFullName & \"\"'. Creating Action Center review task.\"]",
      "fallbackUsed": false,
      "finalValueHash": "99f8ee3fdd019bf131ab323a3a933fc8fff06f0dba75fc94e080a1a8a4cb1fcd"
    },
    {
      "workflowFile": "BGYY_Main.xaml",
      "activityType": "LogMessage",
      "propertyName": "Level",
      "originalRawValue": "Warn",
      "parsedIntentType": "pre-assembly:literal",
      "normalizedOutput": "\"Warn\"",
      "fallbackUsed": false,
      "finalValueHash": "0817e2b865151b33aa686f0551fce818a034cb723e0044e433cd8100810ed280"
    },
    {
      "workflowFile": "BGYY_Main.xaml",
      "activityType": "InvokeWorkflowFile",
      "propertyName": "WorkflowFileName",
      "originalRawValue": "BGYY_CreateReviewTask.xaml",
      "parsedIntentType": "pre-assembly:literal",
      "normalizedOutput": "\"BGYY_CreateReviewTask.xaml\"",
      "fallbackUsed": false,
      "finalValueHash": "eaa3e57ad376f877fd503769d07f422ec8b6dea0fe341aff56f12b6b6fae4893"
    },
    {
      "workflowFile": "BGYY_Main.xaml",
      "activityType": "LogMessage",
      "propertyName": "Level",
      "originalRawValue": "Error",
      "parsedIntentType": "pre-assembly:literal",
      "normalizedOutput": "\"Error\"",
      "fallbackUsed": false,
      "finalValueHash": "fc4ac19649f0ee8f37c71d2e2030a3743038bb96c0c27359ba115dd8657565cc"
    },
    {
      "workflowFile": "BGYY_Main.xaml",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "originalRawValue": "\"Error in Invoke BGYY_CreateReviewTask for ambiguous contact match: \" & exception.Message",
      "parsedIntentType": "pre-assembly:literal",
      "normalizedOutput": "[\"\"\"Error in Invoke BGYY_CreateReviewTask for ambiguous contact match: \"\" & exception.Message\"]",
      "fallbackUsed": false,
      "finalValueHash": "abd802f3bcff0c3429f7edefdc53a5a9ff691d2cbd9f9abd85c8b34eed56af6f"
    },
    {
      "workflowFile": "BGYY_Main.xaml",
      "activityType": "InvokeWorkflowFile",
      "propertyName": "WorkflowFileName",
      "originalRawValue": "BGYY_WriteSendLog.xaml",
      "parsedIntentType": "pre-assembly:literal",
      "normalizedOutput": "\"BGYY_WriteSendLog.xaml\"",
      "fallbackUsed": false,
      "finalValueHash": "aa8355c031ba54071ab9117a14ad05eef09270739d64960014cab42406194aac"
    },
    {
      "workflowFile": "BGYY_Main.xaml",
      "activityType": "LogMessage",
      "propertyName": "Level",
      "originalRawValue": "Error",
      "parsedIntentType": "pre-assembly:literal",
      "normalizedOutput": "\"Error\"",
      "fallbackUsed": false,
      "finalValueHash": "fc4ac19649f0ee8f37c71d2e2030a3743038bb96c0c27359ba115dd8657565cc"
    },
    {
      "workflowFile": "BGYY_Main.xaml",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "originalRawValue": "\"Error in Invoke BGYY_WriteSendLog for ambiguous match outcome: \" & exception.Message",
      "parsedIntentType": "pre-assembly:literal",
      "normalizedOutput": "[\"\"\"Error in Invoke BGYY_WriteSendLog for ambiguous match outcome: \"\" & exception.Message\"]",
      "fallbackUsed": false,
      "finalValueHash": "eb76a17e5b9a2790d5c5685ec8a138ea0c81c2dd77dba9f62c72228a03d2cf95"
    },
    {
      "workflowFile": "BGYY_Main.xaml",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "originalRawValue": "\"[BGYY_Main] RunId=\" & runId & \" | SkippedNoEmail: FullName='\" & currentFullName & \"' | EventId=\" & currentEventId & \". No personal/home email label found in Google Contacts.\"",
      "parsedIntentType": "pre-assembly:literal",
      "normalizedOutput": "[\"[BGYY_Main] RunId=\"\" & runId & \"\" | SkippedNoEmail: FullName='\"\" & currentFullName & \"\"' | EventId=\"\" & currentEventId & \"\". No personal/home email label found in Google Contacts.\"]",
      "fallbackUsed": false,
      "finalValueHash": "944d498a63b58765823aa46b7bb359119ea69f3e82746d1ee0695f0a6225cf36"
    },
    {
      "workflowFile": "BGYY_Main.xaml",
      "activityType": "LogMessage",
      "propertyName": "Level",
      "originalRawValue": "Info",
      "parsedIntentType": "pre-assembly:literal",
      "normalizedOutput": "\"Info\"",
      "fallbackUsed": false,
      "finalValueHash": "6e68b62d2aa611a44f3e7a4cb7e23da9ad1cab1b6abb592bb2795b12fe63e51c"
    },
    {
      "workflowFile": "BGYY_Main.xaml",
      "activityType": "InvokeWorkflowFile",
      "propertyName": "WorkflowFileName",
      "originalRawValue": "BGYY_WriteSendLog.xaml",
      "parsedIntentType": "pre-assembly:literal",
      "normalizedOutput": "\"BGYY_WriteSendLog.xaml\"",
      "fallbackUsed": false,
      "finalValueHash": "aa8355c031ba54071ab9117a14ad05eef09270739d64960014cab42406194aac"
    },
    {
      "workflowFile": "BGYY_Main.xaml",
      "activityType": "LogMessage",
      "propertyName": "Level",
      "originalRawValue": "Error",
      "parsedIntentType": "pre-assembly:literal",
      "normalizedOutput": "\"Error\"",
      "fallbackUsed": false,
      "finalValueHash": "fc4ac19649f0ee8f37c71d2e2030a3743038bb96c0c27359ba115dd8657565cc"
    },
    {
      "workflowFile": "BGYY_Main.xaml",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "originalRawValue": "\"Error in Invoke BGYY_WriteSendLog for SkippedNoEmail outcome: \" & exception.Message",
      "parsedIntentType": "pre-assembly:literal",
      "normalizedOutput": "[\"\"\"Error in Invoke BGYY_WriteSendLog for SkippedNoEmail outcome: \"\" & exception.Message\"]",
      "fallbackUsed": false,
      "finalValueHash": "a7576434bbd95705dab550b0e35b86c33da6cbafaa5bc6d9543cd14c1beddd31"
    },
    {
      "workflowFile": "BGYY_Main.xaml",
      "activityType": "InvokeWorkflowFile",
      "propertyName": "WorkflowFileName",
      "originalRawValue": "BGYY_CheckDedupe.xaml",
      "parsedIntentType": "pre-assembly:literal",
      "normalizedOutput": "\"BGYY_CheckDedupe.xaml\"",
      "fallbackUsed": false,
      "finalValueHash": "70823a7460e3f6031912529edf5ffa389662372f1e441e74b34dd87df31e6a8f"
    },
    {
      "workflowFile": "BGYY_Main.xaml",
      "activityType": "LogMessage",
      "propertyName": "Level",
      "originalRawValue": "Error",
      "parsedIntentType": "pre-assembly:literal",
      "normalizedOutput": "\"Error\"",
      "fallbackUsed": false,
      "finalValueHash": "fc4ac19649f0ee8f37c71d2e2030a3743038bb96c0c27359ba115dd8657565cc"
    },
    {
      "workflowFile": "BGYY_Main.xaml",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "originalRawValue": "\"Error in Invoke BGYY_CheckDedupe to determine if greeting was already sent this year: \" & exception.Message",
      "parsedIntentType": "pre-assembly:literal",
      "normalizedOutput": "[\"\"\"Error in Invoke BGYY_CheckDedupe to determine if greeting was already sent this year: \"\" & exception.Message\"]",
      "fallbackUsed": false,
      "finalValueHash": "4b129354fa673b53acd83bb8a81074528e87b3f39d7e9f559dc875216d78a98a"
    }
  ],
  "invokeContractTrace": [
    {
      "callerWorkflow": "BGYY_Main",
      "targetWorkflow": "BGYY_GetTodaysBirthdays",
      "targetDeclaredArguments": [
        "type",
        "value"
      ],
      "providedBindings": {
        "InRunId": "[InRunId]",
        "OutBirthdayEvents": "[OutBirthdayEvents]"
      },
      "unknownTargetArguments": [
        "InRunId",
        "OutBirthdayEvents"
      ],
      "missingRequiredArguments": [
        "type",
        "value"
      ],
      "undeclaredSymbols": []
    },
    {
      "callerWorkflow": "BGYY_Main",
      "targetWorkflow": "BGYY_ResolveRecipient",
      "targetDeclaredArguments": [],
      "providedBindings": {
        "InRunId": "[InRunId]",
        "InFullName": "[InFullName]",
        "OutSelectedEmail": "[OutSelectedEmail]",
        "OutIsAmbiguous": "[OutIsAmbiguous]",
        "OutSkipReason": "[OutSkipReason]"
      },
      "unknownTargetArguments": [
        "InRunId",
        "InFullName",
        "OutSelectedEmail",
        "OutIsAmbiguous",
        "OutSkipReason"
      ],
      "missingRequiredArguments": [],
      "undeclaredSymbols": []
    },
    {
      "callerWorkflow": "BGYY_Main",
      "targetWorkflow": "BGYY_CheckDedupe",
      "targetDeclaredArguments": [
        "in_PersonKey",
        "in_SendYear",
        "out_AlreadySent",
        "out_ExistingRecordId"
      ],
      "providedBindings": {
        "InPersonKey": "[InPersonKey]",
        "InSendYear": "[InSendYear]",
        "OutAlreadySent": "[OutAlreadySent]",
        "OutExistingRecordId": "[OutExistingRecordId]"
      },
      "unknownTargetArguments": [
        "InPersonKey",
        "InSendYear",
        "OutAlreadySent",
        "OutExistingRecordId"
      ],
      "missingRequiredArguments": [
        "in_PersonKey",
        "in_SendYear"
      ],
      "undeclaredSymbols": []
    },
    {
      "callerWorkflow": "BGYY_Main",
      "targetWorkflow": "BGYY_GenerateDraft",
      "targetDeclaredArguments": [],
      "providedBindings": {
        "InRunId": "[InRunId]",
        "InFullName": "[InFullName]",
        "OutSubject": "[OutSubject]",
        "OutBody": "[OutBody]",
        "OutDraftGenerationFailed": "[OutDraftGenerationFailed]"
      },
      "unknownTargetArguments": [
        "InRunId",
        "InFullName",
        "OutSubject",
        "OutBody",
        "OutDraftGenerationFailed"
      ],
      "missingRequiredArguments": [],
      "undeclaredSymbols": []
    },
    {
      "callerWorkflow": "BGYY_Main",
      "targetWorkflow": "BGYY_ValidateDraft",
      "targetDeclaredArguments": [],
      "providedBindings": {
        "InRunId": "[InRunId]",
        "InFullName": "[InFullName]",
        "InSubject": "[InSubject]",
        "InBody": "[InBody]",
        "OutIsValid": "[OutIsValid]",
        "OutFailReason": "[OutFailReason]"
      },
      "unknownTargetArguments": [
        "InRunId",
        "InFullName",
        "InSubject",
        "InBody",
        "OutIsValid",
        "OutFailReason"
      ],
      "missingRequiredArguments": [],
      "undeclaredSymbols": []
    },
    {
      "callerWorkflow": "BGYY_Main",
      "targetWorkflow": "BGYY_SendGmail",
      "targetDeclaredArguments": [],
      "providedBindings": {
        "InRunId": "[InRunId]",
        "InToEmail": "[InToEmail]",
        "InSubject": "[InSubject]",
        "InBody": "[InBody]",
        "InDryRun": "[InDryRun]",
        "OutGmailMessageId": "[OutGmailMessageId]"
      },
      "unknownTargetArguments": [
        "InRunId",
        "InToEmail",
        "InSubject",
        "InBody",
        "InDryRun",
        "OutGmailMessageId"
      ],
      "missingRequiredArguments": [],
      "undeclaredSymbols": []
    },
    {
      "callerWorkflow": "BGYY_Main",
      "targetWorkflow": "BGYY_WriteSendLog",
      "targetDeclaredArguments": [],
      "providedBindings": {
        "InRunId": "[InRunId]",
        "InPersonName": "[InPersonName]",
        "InPersonKey": "[InPersonKey]",
        "InSelectedEmail": "[InSelectedEmail]",
        "InSendYear": "[InSendYear]",
        "InCalendarEventId": "[InCalendarEventId]",
        "InOccurrenceStart": "[InOccurrenceStart]",
        "InGmailMessageId": "[InGmailMessageId]",
        "InSentTimestamp": "[InSentTimestamp]",
        "InStatus": "[InStatus]",
        "InFailureReason": "[InFailureReason]"
      },
      "unknownTargetArguments": [
        "InRunId",
        "InPersonName",
        "InPersonKey",
        "InSelectedEmail",
        "InSendYear",
        "InCalendarEventId",
        "InOccurrenceStart",
        "InGmailMessageId",
        "InSentTimestamp",
        "InStatus",
        "InFailureReason"
      ],
      "missingRequiredArguments": [],
      "undeclaredSymbols": []
    },
    {
      "callerWorkflow": "BGYY_Main",
      "targetWorkflow": "BGYY_CreateReviewTask",
      "targetDeclaredArguments": [
        "in_RunId",
        "in_EventId",
        "in_FullName",
        "in_SelectedEmail",
        "in_Subject",
        "in_DraftBody",
        "in_FailReason",
        "out_TaskId"
      ],
      "providedBindings": {
        "InRunId": "[InRunId]",
        "InEventId": "[InEventId]",
        "InFullName": "[InFullName]",
        "InSelectedEmail": "[InSelectedEmail]",
        "InSubject": "[InSubject]",
        "InDraftBody": "[InDraftBody]",
        "InFailReason": "[InFailReason]",
        "OutTaskId": "[OutTaskId]"
      },
      "unknownTargetArguments": [
        "InRunId",
        "InEventId",
        "InFullName",
        "InSelectedEmail",
        "InSubject",
        "InDraftBody",
        "InFailReason",
        "OutTaskId"
      ],
      "missingRequiredArguments": [
        "in_RunId",
        "in_EventId",
        "in_FullName",
        "in_SelectedEmail",
        "in_Subject",
        "in_DraftBody",
        "in_FailReason"
      ],
      "undeclaredSymbols": []
    },
    {
      "callerWorkflow": "Main",
      "targetWorkflow": "Init",
      "targetDeclaredArguments": [
        "in_Config",
        "io_Config"
      ],
      "providedBindings": {
        "Nothing": "[dict_Config]"
      },
      "unknownTargetArguments": [
        "Nothing"
      ],
      "missingRequiredArguments": [
        "in_Config"
      ],
      "undeclaredSymbols": []
    },
    {
      "callerWorkflow": "Main",
      "targetWorkflow": "GetTransactionData",
      "targetDeclaredArguments": [
        "in_QueueName",
        "out_TransactionItem",
        "io_TransactionNumber"
      ],
      "providedBindings": {
        "Nothing": "[int_TransactionNumber]"
      },
      "unknownTargetArguments": [
        "Nothing"
      ],
      "missingRequiredArguments": [
        "in_QueueName"
      ],
      "undeclaredSymbols": []
    },
    {
      "callerWorkflow": "Main",
      "targetWorkflow": "Process",
      "targetDeclaredArguments": [
        "in_TransactionItem"
      ],
      "providedBindings": {
        "Nothing": "[qi_TransactionItem]"
      },
      "unknownTargetArguments": [
        "Nothing"
      ],
      "missingRequiredArguments": [
        "in_TransactionItem"
      ],
      "undeclaredSymbols": []
    },
    {
      "callerWorkflow": "Main",
      "targetWorkflow": "SetTransactionStatus",
      "targetDeclaredArguments": [
        "in_TransactionItem",
        "in_Status",
        "in_ErrorMessage"
      ],
      "providedBindings": {
        "Nothing": "\"Successful\""
      },
      "unknownTargetArguments": [
        "Nothing"
      ],
      "missingRequiredArguments": [
        "in_TransactionItem",
        "in_Status",
        "in_ErrorMessage"
      ],
      "undeclaredSymbols": []
    },
    {
      "callerWorkflow": "Main",
      "targetWorkflow": "SetTransactionStatus",
      "targetDeclaredArguments": [
        "in_TransactionItem",
        "in_Status",
        "in_ErrorMessage"
      ],
      "providedBindings": {
        "Nothing": "\"Failed\""
      },
      "unknownTargetArguments": [
        "Nothing"
      ],
      "missingRequiredArguments": [
        "in_TransactionItem",
        "in_Status",
        "in_ErrorMessage"
      ],
      "undeclaredSymbols": []
    },
    {
      "callerWorkflow": "Main",
      "targetWorkflow": "CloseAllApplications",
      "targetDeclaredArguments": [],
      "providedBindings": {},
      "unknownTargetArguments": [],
      "missingRequiredArguments": [],
      "undeclaredSymbols": []
    },
    {
      "callerWorkflow": "Main",
      "targetWorkflow": "CloseAllApplications",
      "targetDeclaredArguments": [],
      "providedBindings": {},
      "unknownTargetArguments": [],
      "missingRequiredArguments": [],
      "undeclaredSymbols": []
    },
    {
      "callerWorkflow": "CloseAllApplications",
      "targetWorkflow": "KillAllProcesses",
      "targetDeclaredArguments": [],
      "providedBindings": {},
      "unknownTargetArguments": [],
      "missingRequiredArguments": [],
      "undeclaredSymbols": []
    },
    {
      "callerWorkflow": "Init",
      "targetWorkflow": "InitAllSettings",
      "targetDeclaredArguments": [
        "out_Config"
      ],
      "providedBindings": {
        "Nothing": "[dict_Config]"
      },
      "unknownTargetArguments": [
        "Nothing"
      ],
      "missingRequiredArguments": [],
      "undeclaredSymbols": []
    },
    {
      "callerWorkflow": "Process",
      "targetWorkflow": "BGYY_Main",
      "targetDeclaredArguments": [],
      "providedBindings": {},
      "unknownTargetArguments": [],
      "missingRequiredArguments": [],
      "undeclaredSymbols": []
    },
    {
      "callerWorkflow": "BGYY_Main.xaml",
      "targetWorkflow": "BGYY_GetTodaysBirthdays",
      "targetDeclaredArguments": [
        "type",
        "value"
      ],
      "providedBindings": {
        "InRunId": "[InRunId]",
        "OutBirthdayEvents": "[OutBirthdayEvents]"
      },
      "unknownTargetArguments": [
        "InRunId",
        "OutBirthdayEvents"
      ],
      "missingRequiredArguments": [
        "type",
        "value"
      ],
      "undeclaredSymbols": []
    },
    {
      "callerWorkflow": "BGYY_Main.xaml",
      "targetWorkflow": "BGYY_ResolveRecipient",
      "targetDeclaredArguments": [],
      "providedBindings": {
        "InRunId": "[InRunId]",
        "InFullName": "[InFullName]",
        "OutSelectedEmail": "[OutSelectedEmail]",
        "OutIsAmbiguous": "[OutIsAmbiguous]",
        "OutSkipReason": "[OutSkipReason]"
      },
      "unknownTargetArguments": [
        "InRunId",
        "InFullName",
        "OutSelectedEmail",
        "OutIsAmbiguous",
        "OutSkipReason"
      ],
      "missingRequiredArguments": [],
      "undeclaredSymbols": []
    },
    {
      "callerWorkflow": "BGYY_Main.xaml",
      "targetWorkflow": "BGYY_CheckDedupe",
      "targetDeclaredArguments": [
        "in_PersonKey",
        "in_SendYear",
        "out_AlreadySent",
        "out_ExistingRecordId"
      ],
      "providedBindings": {
        "InPersonKey": "[InPersonKey]",
        "InSendYear": "[InSendYear]",
        "OutAlreadySent": "[OutAlreadySent]",
        "OutExistingRecordId": "[OutExistingRecordId]"
      },
      "unknownTargetArguments": [
        "InPersonKey",
        "InSendYear",
        "OutAlreadySent",
        "OutExistingRecordId"
      ],
      "missingRequiredArguments": [
        "in_PersonKey",
        "in_SendYear"
      ],
      "undeclaredSymbols": []
    },
    {
      "callerWorkflow": "BGYY_Main.xaml",
      "targetWorkflow": "BGYY_GenerateDraft",
      "targetDeclaredArguments": [],
      "providedBindings": {
        "InRunId": "[InRunId]",
        "InFullName": "[InFullName]",
        "OutSubject": "[OutSubject]",
        "OutBody": "[OutBody]",
        "OutDraftGenerationFailed": "[OutDraftGenerationFailed]"
      },
      "unknownTargetArguments": [
        "InRunId",
        "InFullName",
        "OutSubject",
        "OutBody",
        "OutDraftGenerationFailed"
      ],
      "missingRequiredArguments": [],
      "undeclaredSymbols": []
    },
    {
      "callerWorkflow": "BGYY_Main.xaml",
      "targetWorkflow": "BGYY_ValidateDraft",
      "targetDeclaredArguments": [],
      "providedBindings": {
        "InRunId": "[InRunId]",
        "InFullName": "[InFullName]",
        "InSubject": "[InSubject]",
        "InBody": "[InBody]",
        "OutIsValid": "[OutIsValid]",
        "OutFailReason": "[OutFailReason]"
      },
      "unknownTargetArguments": [
        "InRunId",
        "InFullName",
        "InSubject",
        "InBody",
        "OutIsValid",
        "OutFailReason"
      ],
      "missingRequiredArguments": [],
      "undeclaredSymbols": []
    },
    {
      "callerWorkflow": "BGYY_Main.xaml",
      "targetWorkflow": "BGYY_SendGmail",
      "targetDeclaredArguments": [],
      "providedBindings": {
        "InRunId": "[InRunId]",
        "InToEmail": "[InToEmail]",
        "InSubject": "[InSubject]",
        "InBody": "[InBody]",
        "InDryRun": "[InDryRun]",
        "OutGmailMessageId": "[OutGmailMessageId]"
      },
      "unknownTargetArguments": [
        "InRunId",
        "InToEmail",
        "InSubject",
        "InBody",
        "InDryRun",
        "OutGmailMessageId"
      ],
      "missingRequiredArguments": [],
      "undeclaredSymbols": []
    },
    {
      "callerWorkflow": "BGYY_Main.xaml",
      "targetWorkflow": "BGYY_WriteSendLog",
      "targetDeclaredArguments": [],
      "providedBindings": {
        "InRunId": "[InRunId]",
        "InPersonName": "[InPersonName]",
        "InPersonKey": "[InPersonKey]",
        "InSelectedEmail": "[InSelectedEmail]",
        "InSendYear": "[InSendYear]",
        "InCalendarEventId": "[InCalendarEventId]",
        "InOccurrenceStart": "[InOccurrenceStart]",
        "InGmailMessageId": "[InGmailMessageId]",
        "InSentTimestamp": "[InSentTimestamp]",
        "InStatus": "[InStatus]",
        "InFailureReason": "[InFailureReason]"
      },
      "unknownTargetArguments": [
        "InRunId",
        "InPersonName",
        "InPersonKey",
        "InSelectedEmail",
        "InSendYear",
        "InCalendarEventId",
        "InOccurrenceStart",
        "InGmailMessageId",
        "InSentTimestamp",
        "InStatus",
        "InFailureReason"
      ],
      "missingRequiredArguments": [],
      "undeclaredSymbols": []
    },
    {
      "callerWorkflow": "BGYY_Main.xaml",
      "targetWorkflow": "BGYY_CreateReviewTask",
      "targetDeclaredArguments": [
        "in_RunId",
        "in_EventId",
        "in_FullName",
        "in_SelectedEmail",
        "in_Subject",
        "in_DraftBody",
        "in_FailReason",
        "out_TaskId"
      ],
      "providedBindings": {
        "InRunId": "[InRunId]",
        "InEventId": "[InEventId]",
        "InFullName": "[InFullName]",
        "InSelectedEmail": "[InSelectedEmail]",
        "InSubject": "[InSubject]",
        "InDraftBody": "[InDraftBody]",
        "InFailReason": "[InFailReason]",
        "OutTaskId": "[OutTaskId]"
      },
      "unknownTargetArguments": [
        "InRunId",
        "InEventId",
        "InFullName",
        "InSelectedEmail",
        "InSubject",
        "InDraftBody",
        "InFailReason",
        "OutTaskId"
      ],
      "missingRequiredArguments": [
        "in_RunId",
        "in_EventId",
        "in_FullName",
        "in_SelectedEmail",
        "in_Subject",
        "in_DraftBody",
        "in_FailReason"
      ],
      "undeclaredSymbols": []
    },
    {
      "callerWorkflow": "Main.xaml",
      "targetWorkflow": "Init",
      "targetDeclaredArguments": [
        "in_Config",
        "io_Config"
      ],
      "providedBindings": {
        "Nothing": "[dict_Config]"
      },
      "unknownTargetArguments": [
        "Nothing"
      ],
      "missingRequiredArguments": [
        "in_Config"
      ],
      "undeclaredSymbols": []
    },
    {
      "callerWorkflow": "Main.xaml",
      "targetWorkflow": "GetTransactionData",
      "targetDeclaredArguments": [
        "in_QueueName",
        "out_TransactionItem",
        "io_TransactionNumber"
      ],
      "providedBindings": {
        "Nothing": "[int_TransactionNumber]"
      },
      "unknownTargetArguments": [
        "Nothing"
      ],
      "missingRequiredArguments": [
        "in_QueueName"
      ],
      "undeclaredSymbols": []
    },
    {
      "callerWorkflow": "Main.xaml",
      "targetWorkflow": "Process",
      "targetDeclaredArguments": [
        "in_TransactionItem"
      ],
      "providedBindings": {
        "Nothing": "[qi_TransactionItem]"
      },
      "unknownTargetArguments": [
        "Nothing"
      ],
      "missingRequiredArguments": [
        "in_TransactionItem"
      ],
      "undeclaredSymbols": []
    },
    {
      "callerWorkflow": "Main.xaml",
      "targetWorkflow": "SetTransactionStatus",
      "targetDeclaredArguments": [
        "in_TransactionItem",
        "in_Status",
        "in_ErrorMessage"
      ],
      "providedBindings": {
        "Nothing": "\"Successful\""
      },
      "unknownTargetArguments": [
        "Nothing",
        "Nothing"
      ],
      "missingRequiredArguments": [
        "in_TransactionItem",
        "in_Status",
        "in_ErrorMessage",
        "in_TransactionItem",
        "in_Status",
        "in_ErrorMessage"
      ],
      "undeclaredSymbols": []
    },
    {
      "callerWorkflow": "Main.xaml",
      "targetWorkflow": "SetTransactionStatus",
      "targetDeclaredArguments": [
        "in_TransactionItem",
        "in_Status",
        "in_ErrorMessage"
      ],
      "providedBindings": {
        "Nothing": "\"Failed\""
      },
      "unknownTargetArguments": [
        "Nothing",
        "Nothing"
      ],
      "missingRequiredArguments": [
        "in_TransactionItem",
        "in_Status",
        "in_ErrorMessage",
        "in_TransactionItem",
        "in_Status",
        "in_ErrorMessage"
      ],
      "undeclaredSymbols": []
    },
    {
      "callerWorkflow": "Main.xaml",
      "targetWorkflow": "CloseAllApplications",
      "targetDeclaredArguments": [],
      "providedBindings": {},
      "unknownTargetArguments": [],
      "missingRequiredArguments": [],
      "undeclaredSymbols": []
    },
    {
      "callerWorkflow": "Main.xaml",
      "targetWorkflow": "CloseAllApplications",
      "targetDeclaredArguments": [],
      "providedBindings": {},
      "unknownTargetArguments": [],
      "missingRequiredArguments": [],
      "undeclaredSymbols": []
    },
    {
      "callerWorkflow": "CloseAllApplications.xaml",
      "targetWorkflow": "KillAllProcesses",
      "targetDeclaredArguments": [],
      "providedBindings": {},
      "unknownTargetArguments": [],
      "missingRequiredArguments": [],
      "undeclaredSymbols": []
    },
    {
      "callerWorkflow": "Init.xaml",
      "targetWorkflow": "InitAllSettings",
      "targetDeclaredArguments": [
        "out_Config"
      ],
      "providedBindings": {
        "Nothing": "[dict_Config]"
      },
      "unknownTargetArguments": [
        "Nothing"
      ],
      "missingRequiredArguments": [],
      "undeclaredSymbols": []
    },
    {
      "callerWorkflow": "Process.xaml",
      "targetWorkflow": "BGYY_Main",
      "targetDeclaredArguments": [],
      "providedBindings": {},
      "unknownTargetArguments": [],
      "missingRequiredArguments": [],
      "undeclaredSymbols": []
    }
  ],
  "stageHashParity": [
    {
      "workflowFile": "BGYY_GetTodaysBirthdays.xaml",
      "postGeneration": "9c01078b7dd0674b83cf0accc1586639c6373e4dba38fbb3283dc930f37111c6",
      "postRepair": "9c01078b7dd0674b83cf0accc1586639c6373e4dba38fbb3283dc930f37111c6",
      "postNormalization": "322b8f938c19672053ef22571f6364991ea5fa329fed4636e0782e25f1a32dc8",
      "preCanonicalization": "240f26eb6a03bd57f9711f2a0d54865c2e0505f9624489b4f5f3ed0b8669f690",
      "archivedFile": "3d48043c5c37b5817568eba90bbff8e05db4f9c899f8bec8464684868275579d",
      "postFinalValidationInput": "3d48043c5c37b5817568eba90bbff8e05db4f9c899f8bec8464684868275579d",
      "preArchive": "3d48043c5c37b5817568eba90bbff8e05db4f9c899f8bec8464684868275579d"
    },
    {
      "workflowFile": "BGYY_ResolveRecipient.xaml",
      "postGeneration": "be4d39c5682e2e1e88fc19ae892148d84e2689942b2974f74240eef9ae02e3b8",
      "postRepair": "be4d39c5682e2e1e88fc19ae892148d84e2689942b2974f74240eef9ae02e3b8",
      "postNormalization": "be4d39c5682e2e1e88fc19ae892148d84e2689942b2974f74240eef9ae02e3b8",
      "preCanonicalization": "be4d39c5682e2e1e88fc19ae892148d84e2689942b2974f74240eef9ae02e3b8",
      "archivedFile": "99415ae264bbbd4a673bf7816155e36f7b56268ef756c6d460c8a3d317d94458",
      "postFinalValidationInput": "99415ae264bbbd4a673bf7816155e36f7b56268ef756c6d460c8a3d317d94458",
      "preArchive": "99415ae264bbbd4a673bf7816155e36f7b56268ef756c6d460c8a3d317d94458"
    },
    {
      "workflowFile": "BGYY_CheckDedupe.xaml",
      "postGeneration": "2395881332fcf900b3e0d05417577fd21846f716443feaff3b314b94de33fc52",
      "postRepair": "2395881332fcf900b3e0d05417577fd21846f716443feaff3b314b94de33fc52",
      "postNormalization": "2395881332fcf900b3e0d05417577fd21846f716443feaff3b314b94de33fc52",
      "preCanonicalization": "1373289f3aae0f29585a697c9ed5b15d5586a9eb297990dc676b43c1fd600ed9",
      "archivedFile": "536dfc93c4676cd237f0d29825ae321aa7b79283dcb160ee830d1cd4c1079f16",
      "postFinalValidationInput": "536dfc93c4676cd237f0d29825ae321aa7b79283dcb160ee830d1cd4c1079f16",
      "preArchive": "536dfc93c4676cd237f0d29825ae321aa7b79283dcb160ee830d1cd4c1079f16"
    },
    {
      "workflowFile": "BGYY_GenerateDraft.xaml",
      "postGeneration": "75113eb7a044ed1e9cff2dee9cc7cbb08edeb79669bb2647889e1dc67f2f277a",
      "postRepair": "75113eb7a044ed1e9cff2dee9cc7cbb08edeb79669bb2647889e1dc67f2f277a",
      "postNormalization": "75113eb7a044ed1e9cff2dee9cc7cbb08edeb79669bb2647889e1dc67f2f277a",
      "preCanonicalization": "91804522b5d2f95575b1f7d99579d7e65e56217b6d7b0d13dc5e2b8b60bac43d",
      "archivedFile": "bec0a4d26abde52f1d643783f064244463a2f648ebee47160f880c25bc729163",
      "postFinalValidationInput": "bec0a4d26abde52f1d643783f064244463a2f648ebee47160f880c25bc729163",
      "preArchive": "bec0a4d26abde52f1d643783f064244463a2f648ebee47160f880c25bc729163"
    },
    {
      "workflowFile": "BGYY_ValidateDraft.xaml",
      "postGeneration": "e8e3cf54a9961b3fed6a6512f238837e719c608fa9143a59f6a512cde2a7506d",
      "postRepair": "e8e3cf54a9961b3fed6a6512f238837e719c608fa9143a59f6a512cde2a7506d",
      "postNormalization": "e8e3cf54a9961b3fed6a6512f238837e719c608fa9143a59f6a512cde2a7506d",
      "preCanonicalization": "06dbc8afb678f1e30c88a4961b6cddd4fa98d90e54e7e0b849fd42066272640e",
      "archivedFile": "e6407a729c1dba98d6167e57c79669ee036016e604a807b31570077a59351250",
      "postFinalValidationInput": "e6407a729c1dba98d6167e57c79669ee036016e604a807b31570077a59351250",
      "preArchive": "e6407a729c1dba98d6167e57c79669ee036016e604a807b31570077a59351250"
    },
    {
      "workflowFile": "BGYY_SendGmail.xaml",
      "postGeneration": "82ac2fb4d037bceef6f6531b81964bf328c3be0367c6c10a7bd71fe25a0be920",
      "postRepair": "82ac2fb4d037bceef6f6531b81964bf328c3be0367c6c10a7bd71fe25a0be920",
      "postNormalization": "82ac2fb4d037bceef6f6531b81964bf328c3be0367c6c10a7bd71fe25a0be920",
      "preCanonicalization": "b0accbf7c266e627cc3b13fa9fa62d79370990155a713c406d164fd707a5e459",
      "archivedFile": "abff6a1a95dd3b9de9910e68ee65144fb229f0b456f45efcad730d0c1414e2f8",
      "postFinalValidationInput": "abff6a1a95dd3b9de9910e68ee65144fb229f0b456f45efcad730d0c1414e2f8",
      "preArchive": "abff6a1a95dd3b9de9910e68ee65144fb229f0b456f45efcad730d0c1414e2f8"
    },
    {
      "workflowFile": "BGYY_WriteSendLog.xaml",
      "postGeneration": "3a11d99cbadb72427531df6e078d0672cefb90a1134d4310c8cf7c889f53729c",
      "postRepair": "3a11d99cbadb72427531df6e078d0672cefb90a1134d4310c8cf7c889f53729c",
      "postNormalization": "3a11d99cbadb72427531df6e078d0672cefb90a1134d4310c8cf7c889f53729c",
      "preCanonicalization": "b2c5167eacb60e90958a6bbd0eab24007e1cb4f149fc3c018b64042dff7d3d52",
      "archivedFile": "a32acb7a27127d38cf396adf6f34088146ed531f8f9b00de8f1250392014ec35",
      "postFinalValidationInput": "a32acb7a27127d38cf396adf6f34088146ed531f8f9b00de8f1250392014ec35",
      "preArchive": "a32acb7a27127d38cf396adf6f34088146ed531f8f9b00de8f1250392014ec35"
    },
    {
      "workflowFile": "BGYY_CreateReviewTask.xaml",
      "postGeneration": "796a54739bfd51c575a6f7928b34f81fe97577b2f88a90b3953ba06aa1f6e08c",
      "postRepair": "796a54739bfd51c575a6f7928b34f81fe97577b2f88a90b3953ba06aa1f6e08c",
      "postNormalization": "796a54739bfd51c575a6f7928b34f81fe97577b2f88a90b3953ba06aa1f6e08c",
      "preCanonicalization": "796a54739bfd51c575a6f7928b34f81fe97577b2f88a90b3953ba06aa1f6e08c",
      "archivedFile": "796a54739bfd51c575a6f7928b34f81fe97577b2f88a90b3953ba06aa1f6e08c",
      "postFinalValidationInput": "796a54739bfd51c575a6f7928b34f81fe97577b2f88a90b3953ba06aa1f6e08c",
      "preArchive": "796a54739bfd51c575a6f7928b34f81fe97577b2f88a90b3953ba06aa1f6e08c"
    },
    {
      "workflowFile": "BGYY_Main.xaml",
      "postGeneration": "191e6c9794684ea9d87de65e98b3fd41ee0c16284ae797a121bca199b0d47a32",
      "postRepair": "191e6c9794684ea9d87de65e98b3fd41ee0c16284ae797a121bca199b0d47a32",
      "postNormalization": "dc7abaa750424a8bd02ce8bd1ed7a5fc859abb4665f8fb9a93fca6cdaca761bb",
      "preCanonicalization": "244b38af92edfefd4e1687f4f37c0837db3e0aca68eba4273fe4b2462c10b277",
      "archivedFile": "244b38af92edfefd4e1687f4f37c0837db3e0aca68eba4273fe4b2462c10b277",
      "postFinalValidationInput": "244b38af92edfefd4e1687f4f37c0837db3e0aca68eba4273fe4b2462c10b277",
      "preArchive": "244b38af92edfefd4e1687f4f37c0837db3e0aca68eba4273fe4b2462c10b277"
    },
    {
      "workflowFile": "InitAllSettings.xaml",
      "postGeneration": "6b48121106e1c9ac31dd6244c3205da00643feb4fa3a5d56d9567f996fd50a64",
      "postRepair": "6b48121106e1c9ac31dd6244c3205da00643feb4fa3a5d56d9567f996fd50a64",
      "postNormalization": "6087a678442506f7d5c4605df3fd7e596bc7877cc9ad933776c707b4725d1b75",
      "preCanonicalization": "e7bee23e7319943b5f7902ad849c8bfa210ad9f6340a9d0ccda071df6d65a490",
      "archivedFile": "e7bee23e7319943b5f7902ad849c8bfa210ad9f6340a9d0ccda071df6d65a490",
      "postFinalValidationInput": "e7bee23e7319943b5f7902ad849c8bfa210ad9f6340a9d0ccda071df6d65a490",
      "preArchive": "e7bee23e7319943b5f7902ad849c8bfa210ad9f6340a9d0ccda071df6d65a490"
    },
    {
      "workflowFile": "Main.xaml",
      "postGeneration": "1a6dd9d3fc80874a3d9a791f81c7596d340417bfd52f9b4c671a19aac48d9a4b",
      "postRepair": "1a6dd9d3fc80874a3d9a791f81c7596d340417bfd52f9b4c671a19aac48d9a4b",
      "postNormalization": "1a6dd9d3fc80874a3d9a791f81c7596d340417bfd52f9b4c671a19aac48d9a4b",
      "preCanonicalization": "1a6dd9d3fc80874a3d9a791f81c7596d340417bfd52f9b4c671a19aac48d9a4b",
      "archivedFile": "d4f3449872b830d3831785c8438ad72db99f567c8ecf58444dd18e17bedc869e",
      "postFinalValidationInput": "d4f3449872b830d3831785c8438ad72db99f567c8ecf58444dd18e17bedc869e",
      "preArchive": "d4f3449872b830d3831785c8438ad72db99f567c8ecf58444dd18e17bedc869e"
    },
    {
      "workflowFile": "GetTransactionData.xaml",
      "postGeneration": "ae9e65c2c93e179def93525794245989e6a716804435e9d8fe7eae93aba667d4",
      "postRepair": "ae9e65c2c93e179def93525794245989e6a716804435e9d8fe7eae93aba667d4",
      "postNormalization": "9fc0b0934e80d781cd088b0381229cf92545d8ffd5a4e713b793a0d7ba36c005",
      "preCanonicalization": "9fc0b0934e80d781cd088b0381229cf92545d8ffd5a4e713b793a0d7ba36c005",
      "archivedFile": "9fc0b0934e80d781cd088b0381229cf92545d8ffd5a4e713b793a0d7ba36c005",
      "postFinalValidationInput": "9fc0b0934e80d781cd088b0381229cf92545d8ffd5a4e713b793a0d7ba36c005",
      "preArchive": "9fc0b0934e80d781cd088b0381229cf92545d8ffd5a4e713b793a0d7ba36c005"
    },
    {
      "workflowFile": "Init.xaml",
      "postGeneration": "59937d8b7a8ccb91771dafe3273b012e5a2a6cbc0c3850c53980d22d718afc7a",
      "postRepair": "59937d8b7a8ccb91771dafe3273b012e5a2a6cbc0c3850c53980d22d718afc7a",
      "postNormalization": "59937d8b7a8ccb91771dafe3273b012e5a2a6cbc0c3850c53980d22d718afc7a",
      "preCanonicalization": "59937d8b7a8ccb91771dafe3273b012e5a2a6cbc0c3850c53980d22d718afc7a",
      "archivedFile": "f44213c3e46b46c17650f45dfdfe51edffafbd18cc4a5294d890a3dd0b9b38bf",
      "postFinalValidationInput": "f44213c3e46b46c17650f45dfdfe51edffafbd18cc4a5294d890a3dd0b9b38bf",
      "preArchive": "f44213c3e46b46c17650f45dfdfe51edffafbd18cc4a5294d890a3dd0b9b38bf"
    },
    {
      "workflowFile": "InitAllApplications.xaml",
      "postGeneration": "5f36dc6bc4b5d25fedaca0bffd9163b903302540d7dc7b4a36a287115312a16f",
      "postRepair": "5f36dc6bc4b5d25fedaca0bffd9163b903302540d7dc7b4a36a287115312a16f",
      "postNormalization": "5f36dc6bc4b5d25fedaca0bffd9163b903302540d7dc7b4a36a287115312a16f",
      "preCanonicalization": "5f36dc6bc4b5d25fedaca0bffd9163b903302540d7dc7b4a36a287115312a16f",
      "archivedFile": "b769c321be4fd43fa3cb8ea65de348f95d31ef739494e5f1be7cb81be9018ad8",
      "postFinalValidationInput": "b769c321be4fd43fa3cb8ea65de348f95d31ef739494e5f1be7cb81be9018ad8",
      "preArchive": "b769c321be4fd43fa3cb8ea65de348f95d31ef739494e5f1be7cb81be9018ad8"
    },
    {
      "workflowFile": "RetryCurrentTransaction.xaml",
      "postGeneration": "39a5fb546f369dfb49d80e1c32a3f49c55cfd1ac6baf5cf5ae440dae5ddd36b9",
      "postRepair": "39a5fb546f369dfb49d80e1c32a3f49c55cfd1ac6baf5cf5ae440dae5ddd36b9",
      "postNormalization": "39a5fb546f369dfb49d80e1c32a3f49c55cfd1ac6baf5cf5ae440dae5ddd36b9",
      "preCanonicalization": "39a5fb546f369dfb49d80e1c32a3f49c55cfd1ac6baf5cf5ae440dae5ddd36b9",
      "archivedFile": "39a5fb546f369dfb49d80e1c32a3f49c55cfd1ac6baf5cf5ae440dae5ddd36b9",
      "postFinalValidationInput": "39a5fb546f369dfb49d80e1c32a3f49c55cfd1ac6baf5cf5ae440dae5ddd36b9",
      "preArchive": "39a5fb546f369dfb49d80e1c32a3f49c55cfd1ac6baf5cf5ae440dae5ddd36b9"
    },
    {
      "workflowFile": "RetryInit.xaml",
      "postGeneration": "694f0ead7ed225e69d2248e8534176858cc1c159c406597e10e1a08bd8d7fa4b",
      "postRepair": "694f0ead7ed225e69d2248e8534176858cc1c159c406597e10e1a08bd8d7fa4b",
      "postNormalization": "694f0ead7ed225e69d2248e8534176858cc1c159c406597e10e1a08bd8d7fa4b",
      "preCanonicalization": "694f0ead7ed225e69d2248e8534176858cc1c159c406597e10e1a08bd8d7fa4b",
      "archivedFile": "694f0ead7ed225e69d2248e8534176858cc1c159c406597e10e1a08bd8d7fa4b",
      "postFinalValidationInput": "694f0ead7ed225e69d2248e8534176858cc1c159c406597e10e1a08bd8d7fa4b",
      "preArchive": "694f0ead7ed225e69d2248e8534176858cc1c159c406597e10e1a08bd8d7fa4b"
    }
  ],
  "preEmissionValidation": {
    "totalActivities": 214,
    "validActivities": 214,
    "unknownActivities": 0,
    "deprecatedActivities": 0,
    "nonEmissionApprovedActivities": 0,
    "targetIncompatibleActivities": 0,
    "strippedProperties": 106,
    "enumCorrections": 0,
    "missingRequiredFilled": 0,
    "commentConversions": 0,
    "issueCount": 40
  },
  "invokeSerializationFixes": [],
  "expressionCanonicalizationFixes": [],
  "symbolScopeDefects": [
    {
      "file": "lib/net45/BGYY_GetTodaysBirthdays.xaml",
      "workflow": "BGYY_GetTodaysBirthdays",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "referencedSymbol": "rawCalendarEvents",
      "offendingExpression": "&quot;[BGYY_GetTodaysBirthdays][CalendarQuery] Success | calendarQuerySuccess=&quot; &amp; bool_CalendarQuerySuccess.ToString() &amp; &quot; | RawResult type=&quot; &amp; If(rawCalendarEvents IsNot No",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"rawCalendarEvents\" referenced in Message but not declared in workflow \"BGYY_GetTodaysBirthdays\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/BGYY_CheckDedupe.xaml",
      "workflow": "BGYY_CheckDedupe",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "referencedSymbol": "BGYY_CheckDedupe",
      "offendingExpression": "[BGYY_CheckDedupe] QueryEntity completed for PersonKey=&apos;&quot; &amp; in_PersonKey &amp; &quot;&apos;, SendYear=&quot; &amp; in_SendYear.ToString() &amp; &quot;. Result is Nothing: &quot; &amp; (o",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"BGYY_CheckDedupe\" referenced in Message but not declared in workflow \"BGYY_CheckDedupe\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/BGYY_CheckDedupe.xaml",
      "workflow": "BGYY_CheckDedupe",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "referencedSymbol": "QueryEntity",
      "offendingExpression": "[BGYY_CheckDedupe] QueryEntity completed for PersonKey=&apos;&quot; &amp; in_PersonKey &amp; &quot;&apos;, SendYear=&quot; &amp; in_SendYear.ToString() &amp; &quot;. Result is Nothing: &quot; &amp; (o",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"QueryEntity\" referenced in Message but not declared in workflow \"BGYY_CheckDedupe\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/BGYY_CheckDedupe.xaml",
      "workflow": "BGYY_CheckDedupe",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "referencedSymbol": "completed",
      "offendingExpression": "[BGYY_CheckDedupe] QueryEntity completed for PersonKey=&apos;&quot; &amp; in_PersonKey &amp; &quot;&apos;, SendYear=&quot; &amp; in_SendYear.ToString() &amp; &quot;. Result is Nothing: &quot; &amp; (o",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"completed\" referenced in Message but not declared in workflow \"BGYY_CheckDedupe\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/BGYY_CheckDedupe.xaml",
      "workflow": "BGYY_CheckDedupe",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "referencedSymbol": "PersonKey",
      "offendingExpression": "[BGYY_CheckDedupe] QueryEntity completed for PersonKey=&apos;&quot; &amp; in_PersonKey &amp; &quot;&apos;, SendYear=&quot; &amp; in_SendYear.ToString() &amp; &quot;. Result is Nothing: &quot; &amp; (o",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"PersonKey\" referenced in Message but not declared in workflow \"BGYY_CheckDedupe\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/BGYY_CheckDedupe.xaml",
      "workflow": "BGYY_CheckDedupe",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "referencedSymbol": "Result",
      "offendingExpression": "[BGYY_CheckDedupe] QueryEntity completed for PersonKey=&apos;&quot; &amp; in_PersonKey &amp; &quot;&apos;, SendYear=&quot; &amp; in_SendYear.ToString() &amp; &quot;. Result is Nothing: &quot; &amp; (o",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"Result\" referenced in Message but not declared in workflow \"BGYY_CheckDedupe\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/BGYY_CheckDedupe.xaml",
      "workflow": "BGYY_CheckDedupe",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "referencedSymbol": "BGYY_CheckDedupe",
      "offendingExpression": "[BGYY_CheckDedupe] ERROR querying BGYY_BirthdaySendLog for PersonKey=&apos;&quot; &amp; in_PersonKey &amp; &quot;&apos;, SendYear=&quot; &amp; in_SendYear.ToString() &amp; &quot;. Exception: &quot; &a",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"BGYY_CheckDedupe\" referenced in Message but not declared in workflow \"BGYY_CheckDedupe\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/BGYY_CheckDedupe.xaml",
      "workflow": "BGYY_CheckDedupe",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "referencedSymbol": "querying",
      "offendingExpression": "[BGYY_CheckDedupe] ERROR querying BGYY_BirthdaySendLog for PersonKey=&apos;&quot; &amp; in_PersonKey &amp; &quot;&apos;, SendYear=&quot; &amp; in_SendYear.ToString() &amp; &quot;. Exception: &quot; &a",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"querying\" referenced in Message but not declared in workflow \"BGYY_CheckDedupe\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/BGYY_CheckDedupe.xaml",
      "workflow": "BGYY_CheckDedupe",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "referencedSymbol": "BGYY_BirthdaySendLog",
      "offendingExpression": "[BGYY_CheckDedupe] ERROR querying BGYY_BirthdaySendLog for PersonKey=&apos;&quot; &amp; in_PersonKey &amp; &quot;&apos;, SendYear=&quot; &amp; in_SendYear.ToString() &amp; &quot;. Exception: &quot; &a",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"BGYY_BirthdaySendLog\" referenced in Message but not declared in workflow \"BGYY_CheckDedupe\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/BGYY_CheckDedupe.xaml",
      "workflow": "BGYY_CheckDedupe",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "referencedSymbol": "PersonKey",
      "offendingExpression": "[BGYY_CheckDedupe] ERROR querying BGYY_BirthdaySendLog for PersonKey=&apos;&quot; &amp; in_PersonKey &amp; &quot;&apos;, SendYear=&quot; &amp; in_SendYear.ToString() &amp; &quot;. Exception: &quot; &a",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"PersonKey\" referenced in Message but not declared in workflow \"BGYY_CheckDedupe\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/BGYY_CheckDedupe.xaml",
      "workflow": "BGYY_CheckDedupe",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "referencedSymbol": "ex_DedupeQuery",
      "offendingExpression": "[BGYY_CheckDedupe] ERROR querying BGYY_BirthdaySendLog for PersonKey=&apos;&quot; &amp; in_PersonKey &amp; &quot;&apos;, SendYear=&quot; &amp; in_SendYear.ToString() &amp; &quot;. Exception: &quot; &a",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"ex_DedupeQuery\" referenced in Message but not declared in workflow \"BGYY_CheckDedupe\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/BGYY_WriteSendLog.xaml",
      "workflow": "BGYY_WriteSendLog",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "referencedSymbol": "personKeyNormalized",
      "offendingExpression": "&quot;[BGYY_WriteSendLog][ERROR] Data Service write failed — record NOT persisted. PersonKey=&quot; &amp; personKeyNormalized &amp; &quot; | Status=&quot; &amp; InStatus &amp; &quot; | RunId=&quot; &a",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"personKeyNormalized\" referenced in Message but not declared in workflow \"BGYY_WriteSendLog\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/BGYY_WriteSendLog.xaml",
      "workflow": "BGYY_WriteSendLog",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "referencedSymbol": "errorMessage",
      "offendingExpression": "&quot;[BGYY_WriteSendLog][ERROR] Data Service write failed — record NOT persisted. PersonKey=&quot; &amp; personKeyNormalized &amp; &quot; | Status=&quot; &amp; InStatus &amp; &quot; | RunId=&quot; &a",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"errorMessage\" referenced in Message but not declared in workflow \"BGYY_WriteSendLog\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/BGYY_WriteSendLog.xaml",
      "workflow": "BGYY_WriteSendLog",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "referencedSymbol": "personKeyNormalized",
      "offendingExpression": "&quot;[BGYY_WriteSendLog][END] PersonKey=&quot; &amp; personKeyNormalized &amp; &quot; | Status=&quot; &amp; InStatus &amp; &quot; | RecordExists=&quot; &amp; bool_RecordExists.ToString() &amp; &quot;",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"personKeyNormalized\" referenced in Message but not declared in workflow \"BGYY_WriteSendLog\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/Main.xaml",
      "workflow": "Main",
      "activityType": "InOutArgument",
      "propertyName": "Key",
      "referencedSymbol": "io_Config",
      "offendingExpression": "io_Config",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "undeclared_argument_reference",
      "severity": "handoff_required",
      "rationale": "Argument \"io_Config\" referenced in Key but not declared in workflow \"Main\" — expression replaced with \"Nothing\""
    },
    {
      "file": "lib/net45/Main.xaml",
      "workflow": "Main",
      "activityType": "InArgument",
      "propertyName": "Key",
      "referencedSymbol": "in_QueueName",
      "offendingExpression": "in_QueueName",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "undeclared_argument_reference",
      "severity": "handoff_required",
      "rationale": "Argument \"in_QueueName\" referenced in Key but not declared in workflow \"Main\" — expression replaced with \"Nothing\""
    },
    {
      "file": "lib/net45/Main.xaml",
      "workflow": "Main",
      "activityType": "OutArgument",
      "propertyName": "Key",
      "referencedSymbol": "out_TransactionItem",
      "offendingExpression": "out_TransactionItem",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "undeclared_argument_reference",
      "severity": "handoff_required",
      "rationale": "Argument \"out_TransactionItem\" referenced in Key but not declared in workflow \"Main\" — expression replaced with \"Nothing\""
    },
    {
      "file": "lib/net45/Main.xaml",
      "workflow": "Main",
      "activityType": "InOutArgument",
      "propertyName": "Key",
      "referencedSymbol": "io_TransactionNumber",
      "offendingExpression": "io_TransactionNumber",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "undeclared_argument_reference",
      "severity": "handoff_required",
      "rationale": "Argument \"io_TransactionNumber\" referenced in Key but not declared in workflow \"Main\" — expression replaced with \"Nothing\""
    },
    {
      "file": "lib/net45/Main.xaml",
      "workflow": "Main",
      "activityType": "InArgument",
      "propertyName": "Key",
      "referencedSymbol": "in_TransactionItem",
      "offendingExpression": "in_TransactionItem",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "undeclared_argument_reference",
      "severity": "handoff_required",
      "rationale": "Argument \"in_TransactionItem\" referenced in Key but not declared in workflow \"Main\" — expression replaced with \"Nothing\""
    },
    {
      "file": "lib/net45/Main.xaml",
      "workflow": "Main",
      "activityType": "InArgument",
      "propertyName": "Key",
      "referencedSymbol": "in_TransactionItem",
      "offendingExpression": "in_TransactionItem",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "undeclared_argument_reference",
      "severity": "handoff_required",
      "rationale": "Argument \"in_TransactionItem\" referenced in Key but not declared in workflow \"Main\" — expression replaced with \"Nothing\""
    },
    {
      "file": "lib/net45/Main.xaml",
      "workflow": "Main",
      "activityType": "InArgument",
      "propertyName": "Key",
      "referencedSymbol": "in_Status",
      "offendingExpression": "in_Status",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "undeclared_argument_reference",
      "severity": "handoff_required",
      "rationale": "Argument \"in_Status\" referenced in Key but not declared in workflow \"Main\" — expression replaced with \"Nothing\""
    },
    {
      "file": "lib/net45/Main.xaml",
      "workflow": "Main",
      "activityType": "InArgument",
      "propertyName": "Key",
      "referencedSymbol": "in_TransactionItem",
      "offendingExpression": "in_TransactionItem",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "undeclared_argument_reference",
      "severity": "handoff_required",
      "rationale": "Argument \"in_TransactionItem\" referenced in Key but not declared in workflow \"Main\" — expression replaced with \"Nothing\""
    },
    {
      "file": "lib/net45/Main.xaml",
      "workflow": "Main",
      "activityType": "InArgument",
      "propertyName": "Key",
      "referencedSymbol": "in_Status",
      "offendingExpression": "in_Status",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "undeclared_argument_reference",
      "severity": "handoff_required",
      "rationale": "Argument \"in_Status\" referenced in Key but not declared in workflow \"Main\" — expression replaced with \"Nothing\""
    },
    {
      "file": "lib/net45/Init.xaml",
      "workflow": "Init",
      "activityType": "OutArgument",
      "propertyName": "Key",
      "referencedSymbol": "out_Config",
      "offendingExpression": "out_Config",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "undeclared_argument_reference",
      "severity": "handoff_required",
      "rationale": "Argument \"out_Config\" referenced in Key but not declared in workflow \"Init\" — expression replaced with \"Nothing\""
    }
  ],
  "targetValueCanonicalizationSummary": "Target/value canonicalization: 0 expression fix(es), 24 symbol scope defect(s), 29 sentinel replacement(s), 0 unresolvable JSON defect(s)",
  "residualExpressionSerializationDefects": [
    {
      "file": "lib/net45/BGYY_GetTodaysBirthdays.xaml",
      "workflow": "BGYY_GetTodaysBirthdays",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "originalValue": "[&quot;Placeholder — RetryScope body has no activities yet&quot;]",
      "defectType": "placeholder_in_executable",
      "severity": "handoff_required",
      "rationale": "Placeholder sentinel in executable property Message — requires business value"
    },
    {
      "file": "lib/net45/BGYY_GetTodaysBirthdays.xaml",
      "workflow": "BGYY_GetTodaysBirthdays",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "originalValue": "[&quot;Placeholder — Then branch has no activities yet&quot;]",
      "defectType": "placeholder_in_executable",
      "severity": "handoff_required",
      "rationale": "Placeholder sentinel in executable property Message — requires business value"
    },
    {
      "file": "lib/net45/BGYY_GetTodaysBirthdays.xaml",
      "workflow": "BGYY_GetTodaysBirthdays",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "originalValue": "[&quot;Placeholder — Then branch has no activities yet&quot;]",
      "defectType": "placeholder_in_executable",
      "severity": "handoff_required",
      "rationale": "Placeholder sentinel in executable property Message — requires business value"
    },
    {
      "file": "lib/net45/BGYY_ResolveRecipient.xaml",
      "workflow": "BGYY_ResolveRecipient",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "originalValue": "[&quot;Placeholder — RetryScope body has no activities yet&quot;]",
      "defectType": "placeholder_in_executable",
      "severity": "handoff_required",
      "rationale": "Placeholder sentinel in executable property Message — requires business value"
    },
    {
      "file": "lib/net45/BGYY_ResolveRecipient.xaml",
      "workflow": "BGYY_ResolveRecipient",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "originalValue": "[&quot;Placeholder — Then branch has no activities yet&quot;]",
      "defectType": "placeholder_in_executable",
      "severity": "handoff_required",
      "rationale": "Placeholder sentinel in executable property Message — requires business value"
    },
    {
      "file": "lib/net45/BGYY_ResolveRecipient.xaml",
      "workflow": "BGYY_ResolveRecipient",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "originalValue": "[&quot;Placeholder — Then branch has no activities yet&quot;]",
      "defectType": "placeholder_in_executable",
      "severity": "handoff_required",
      "rationale": "Placeholder sentinel in executable property Message — requires business value"
    },
    {
      "file": "lib/net45/BGYY_ResolveRecipient.xaml",
      "workflow": "BGYY_ResolveRecipient",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "originalValue": "[&quot;Placeholder — Then branch has no activities yet&quot;]",
      "defectType": "placeholder_in_executable",
      "severity": "handoff_required",
      "rationale": "Placeholder sentinel in executable property Message — requires business value"
    },
    {
      "file": "lib/net45/BGYY_ResolveRecipient.xaml",
      "workflow": "BGYY_ResolveRecipient",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "originalValue": "[&quot;Placeholder — Then branch has no activities yet&quot;]",
      "defectType": "placeholder_in_executable",
      "severity": "handoff_required",
      "rationale": "Placeholder sentinel in executable property Message — requires business value"
    },
    {
      "file": "lib/net45/BGYY_GenerateDraft.xaml",
      "workflow": "BGYY_GenerateDraft",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "originalValue": "[&quot;Placeholder — Then branch has no activities yet&quot;]",
      "defectType": "placeholder_in_executable",
      "severity": "handoff_required",
      "rationale": "Placeholder sentinel in executable property Message — requires business value"
    },
    {
      "file": "lib/net45/BGYY_GenerateDraft.xaml",
      "workflow": "BGYY_GenerateDraft",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "originalValue": "[&quot;Placeholder — RetryScope body has no activities yet&quot;]",
      "defectType": "placeholder_in_executable",
      "severity": "handoff_required",
      "rationale": "Placeholder sentinel in executable property Message — requires business value"
    },
    {
      "file": "lib/net45/BGYY_GenerateDraft.xaml",
      "workflow": "BGYY_GenerateDraft",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "originalValue": "[&quot;Placeholder — Then branch has no activities yet&quot;]",
      "defectType": "placeholder_in_executable",
      "severity": "handoff_required",
      "rationale": "Placeholder sentinel in executable property Message — requires business value"
    },
    {
      "file": "lib/net45/BGYY_GenerateDraft.xaml",
      "workflow": "BGYY_GenerateDraft",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "originalValue": "[&quot;Placeholder — Then branch has no activities yet&quot;]",
      "defectType": "placeholder_in_executable",
      "severity": "handoff_required",
      "rationale": "Placeholder sentinel in executable property Message — requires business value"
    },
    {
      "file": "lib/net45/BGYY_ValidateDraft.xaml",
      "workflow": "BGYY_ValidateDraft",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "originalValue": "[&quot;Placeholder — Then branch has no activities yet&quot;]",
      "defectType": "placeholder_in_executable",
      "severity": "handoff_required",
      "rationale": "Placeholder sentinel in executable property Message — requires business value"
    },
    {
      "file": "lib/net45/BGYY_ValidateDraft.xaml",
      "workflow": "BGYY_ValidateDraft",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "originalValue": "[&quot;Placeholder — Then branch has no activities yet&quot;]",
      "defectType": "placeholder_in_executable",
      "severity": "handoff_required",
      "rationale": "Placeholder sentinel in executable property Message — requires business value"
    },
    {
      "file": "lib/net45/BGYY_ValidateDraft.xaml",
      "workflow": "BGYY_ValidateDraft",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "originalValue": "[&quot;Placeholder — Then branch has no activities yet&quot;]",
      "defectType": "placeholder_in_executable",
      "severity": "handoff_required",
      "rationale": "Placeholder sentinel in executable property Message — requires business value"
    },
    {
      "file": "lib/net45/BGYY_ValidateDraft.xaml",
      "workflow": "BGYY_ValidateDraft",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "originalValue": "[&quot;Placeholder — Then branch has no activities yet&quot;]",
      "defectType": "placeholder_in_executable",
      "severity": "handoff_required",
      "rationale": "Placeholder sentinel in executable property Message — requires business value"
    },
    {
      "file": "lib/net45/BGYY_ValidateDraft.xaml",
      "workflow": "BGYY_ValidateDraft",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "originalValue": "[BGYY_ValidateDraft] FAIL placeholder-in-body - RunId=&quot; &amp; InRunId &amp; &quot; | FullName=&apos;&quot; &amp; InFullName &amp; &quot;&apos;",
      "defectType": "placeholder_in_executable",
      "severity": "handoff_required",
      "rationale": "Placeholder sentinel in executable property Message — requires business value"
    },
    {
      "file": "lib/net45/BGYY_ValidateDraft.xaml",
      "workflow": "BGYY_ValidateDraft",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "originalValue": "[&quot;Placeholder — Then branch has no activities yet&quot;]",
      "defectType": "placeholder_in_executable",
      "severity": "handoff_required",
      "rationale": "Placeholder sentinel in executable property Message — requires business value"
    },
    {
      "file": "lib/net45/BGYY_ValidateDraft.xaml",
      "workflow": "BGYY_ValidateDraft",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "originalValue": "[BGYY_ValidateDraft] FAIL placeholder-in-subject - RunId=&quot; &amp; InRunId &amp; &quot; | FullName=&apos;&quot; &amp; InFullName &amp; &quot;&apos;",
      "defectType": "placeholder_in_executable",
      "severity": "handoff_required",
      "rationale": "Placeholder sentinel in executable property Message — requires business value"
    },
    {
      "file": "lib/net45/BGYY_ValidateDraft.xaml",
      "workflow": "BGYY_ValidateDraft",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "originalValue": "[&quot;Placeholder — Then branch has no activities yet&quot;]",
      "defectType": "placeholder_in_executable",
      "severity": "handoff_required",
      "rationale": "Placeholder sentinel in executable property Message — requires business value"
    },
    {
      "file": "lib/net45/BGYY_ValidateDraft.xaml",
      "workflow": "BGYY_ValidateDraft",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "originalValue": "[&quot;Placeholder — Then branch has no activities yet&quot;]",
      "defectType": "placeholder_in_executable",
      "severity": "handoff_required",
      "rationale": "Placeholder sentinel in executable property Message — requires business value"
    },
    {
      "file": "lib/net45/BGYY_ValidateDraft.xaml",
      "workflow": "BGYY_ValidateDraft",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "originalValue": "[&quot;Placeholder — Then branch has no activities yet&quot;]",
      "defectType": "placeholder_in_executable",
      "severity": "handoff_required",
      "rationale": "Placeholder sentinel in executable property Message — requires business value"
    },
    {
      "file": "lib/net45/BGYY_SendGmail.xaml",
      "workflow": "BGYY_SendGmail",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "originalValue": "[&quot;Placeholder — Then branch has no activities yet&quot;]",
      "defectType": "placeholder_in_executable",
      "severity": "handoff_required",
      "rationale": "Placeholder sentinel in executable property Message — requires business value"
    },
    {
      "file": "lib/net45/BGYY_SendGmail.xaml",
      "workflow": "BGYY_SendGmail",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "originalValue": "[&quot;Placeholder — RetryScope body has no activities yet&quot;]",
      "defectType": "placeholder_in_executable",
      "severity": "handoff_required",
      "rationale": "Placeholder sentinel in executable property Message — requires business value"
    },
    {
      "file": "lib/net45/BGYY_SendGmail.xaml",
      "workflow": "BGYY_SendGmail",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "originalValue": "[&quot;Placeholder — Then branch has no activities yet&quot;]",
      "defectType": "placeholder_in_executable",
      "severity": "handoff_required",
      "rationale": "Placeholder sentinel in executable property Message — requires business value"
    },
    {
      "file": "lib/net45/BGYY_SendGmail.xaml",
      "workflow": "BGYY_SendGmail",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "originalValue": "[&quot;Placeholder — Then branch has no activities yet&quot;]",
      "defectType": "placeholder_in_executable",
      "severity": "handoff_required",
      "rationale": "Placeholder sentinel in executable property Message — requires business value"
    },
    {
      "file": "lib/net45/BGYY_WriteSendLog.xaml",
      "workflow": "BGYY_WriteSendLog",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "originalValue": "[&quot;Placeholder — Then branch has no activities yet&quot;]",
      "defectType": "placeholder_in_executable",
      "severity": "handoff_required",
      "rationale": "Placeholder sentinel in executable property Message — requires business value"
    },
    {
      "file": "lib/net45/BGYY_WriteSendLog.xaml",
      "workflow": "BGYY_WriteSendLog",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "originalValue": "[&quot;Placeholder — Then branch has no activities yet&quot;]",
      "defectType": "placeholder_in_executable",
      "severity": "handoff_required",
      "rationale": "Placeholder sentinel in executable property Message — requires business value"
    }
  ],
  "sentinelReplacements": [
    {
      "file": "lib/net45/BGYY_GetTodaysBirthdays.xaml",
      "workflow": "BGYY_GetTodaysBirthdays",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "originalValue": "[&quot;Placeholder — RetryScope body has no activities yet&quot;]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "placeholder_sentinel",
      "severity": "execution_blocking",
      "rationale": "Sentinel \"[&quot;Placeholder — RetryScope body has no activities yet&quot;]\" in executable property Message replaced with platform-safe value \"\"\"\" — not executable, degradation substitute"
    },
    {
      "file": "lib/net45/BGYY_GetTodaysBirthdays.xaml",
      "workflow": "BGYY_GetTodaysBirthdays",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "originalValue": "[&quot;Placeholder — Then branch has no activities yet&quot;]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "placeholder_sentinel",
      "severity": "execution_blocking",
      "rationale": "Sentinel \"[&quot;Placeholder — Then branch has no activities yet&quot;]\" in executable property Message replaced with platform-safe value \"\"\"\" — not executable, degradation substitute"
    },
    {
      "file": "lib/net45/BGYY_GetTodaysBirthdays.xaml",
      "workflow": "BGYY_GetTodaysBirthdays",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "originalValue": "[&quot;Placeholder — Then branch has no activities yet&quot;]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "placeholder_sentinel",
      "severity": "execution_blocking",
      "rationale": "Sentinel \"[&quot;Placeholder — Then branch has no activities yet&quot;]\" in executable property Message replaced with platform-safe value \"\"\"\" — not executable, degradation substitute"
    },
    {
      "file": "lib/net45/BGYY_ResolveRecipient.xaml",
      "workflow": "BGYY_ResolveRecipient",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "originalValue": "[&quot;Placeholder — RetryScope body has no activities yet&quot;]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "placeholder_sentinel",
      "severity": "execution_blocking",
      "rationale": "Sentinel \"[&quot;Placeholder — RetryScope body has no activities yet&quot;]\" in executable property Message replaced with platform-safe value \"\"\"\" — not executable, degradation substitute"
    },
    {
      "file": "lib/net45/BGYY_ResolveRecipient.xaml",
      "workflow": "BGYY_ResolveRecipient",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "originalValue": "[&quot;Placeholder — Then branch has no activities yet&quot;]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "placeholder_sentinel",
      "severity": "execution_blocking",
      "rationale": "Sentinel \"[&quot;Placeholder — Then branch has no activities yet&quot;]\" in executable property Message replaced with platform-safe value \"\"\"\" — not executable, degradation substitute"
    },
    {
      "file": "lib/net45/BGYY_ResolveRecipient.xaml",
      "workflow": "BGYY_ResolveRecipient",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "originalValue": "[&quot;Placeholder — Then branch has no activities yet&quot;]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "placeholder_sentinel",
      "severity": "execution_blocking",
      "rationale": "Sentinel \"[&quot;Placeholder — Then branch has no activities yet&quot;]\" in executable property Message replaced with platform-safe value \"\"\"\" — not executable, degradation substitute"
    },
    {
      "file": "lib/net45/BGYY_ResolveRecipient.xaml",
      "workflow": "BGYY_ResolveRecipient",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "originalValue": "[&quot;Placeholder — Then branch has no activities yet&quot;]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "placeholder_sentinel",
      "severity": "execution_blocking",
      "rationale": "Sentinel \"[&quot;Placeholder — Then branch has no activities yet&quot;]\" in executable property Message replaced with platform-safe value \"\"\"\" — not executable, degradation substitute"
    },
    {
      "file": "lib/net45/BGYY_ResolveRecipient.xaml",
      "workflow": "BGYY_ResolveRecipient",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "originalValue": "[&quot;Placeholder — Then branch has no activities yet&quot;]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "placeholder_sentinel",
      "severity": "execution_blocking",
      "rationale": "Sentinel \"[&quot;Placeholder — Then branch has no activities yet&quot;]\" in executable property Message replaced with platform-safe value \"\"\"\" — not executable, degradation substitute"
    },
    {
      "file": "lib/net45/BGYY_GenerateDraft.xaml",
      "workflow": "BGYY_GenerateDraft",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "originalValue": "[&quot;Placeholder — Then branch has no activities yet&quot;]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "placeholder_sentinel",
      "severity": "execution_blocking",
      "rationale": "Sentinel \"[&quot;Placeholder — Then branch has no activities yet&quot;]\" in executable property Message replaced with platform-safe value \"\"\"\" — not executable, degradation substitute"
    },
    {
      "file": "lib/net45/BGYY_GenerateDraft.xaml",
      "workflow": "BGYY_GenerateDraft",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "originalValue": "[&quot;Placeholder — RetryScope body has no activities yet&quot;]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "placeholder_sentinel",
      "severity": "execution_blocking",
      "rationale": "Sentinel \"[&quot;Placeholder — RetryScope body has no activities yet&quot;]\" in executable property Message replaced with platform-safe value \"\"\"\" — not executable, degradation substitute"
    },
    {
      "file": "lib/net45/BGYY_GenerateDraft.xaml",
      "workflow": "BGYY_GenerateDraft",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "originalValue": "[&quot;Placeholder — Then branch has no activities yet&quot;]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "placeholder_sentinel",
      "severity": "execution_blocking",
      "rationale": "Sentinel \"[&quot;Placeholder — Then branch has no activities yet&quot;]\" in executable property Message replaced with platform-safe value \"\"\"\" — not executable, degradation substitute"
    },
    {
      "file": "lib/net45/BGYY_GenerateDraft.xaml",
      "workflow": "BGYY_GenerateDraft",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "originalValue": "[&quot;Placeholder — Then branch has no activities yet&quot;]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "placeholder_sentinel",
      "severity": "execution_blocking",
      "rationale": "Sentinel \"[&quot;Placeholder — Then branch has no activities yet&quot;]\" in executable property Message replaced with platform-safe value \"\"\"\" — not executable, degradation substitute"
    },
    {
      "file": "lib/net45/BGYY_ValidateDraft.xaml",
      "workflow": "BGYY_ValidateDraft",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "originalValue": "[&quot;Placeholder — Then branch has no activities yet&quot;]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "placeholder_sentinel",
      "severity": "execution_blocking",
      "rationale": "Sentinel \"[&quot;Placeholder — Then branch has no activities yet&quot;]\" in executable property Message replaced with platform-safe value \"\"\"\" — not executable, degradation substitute"
    },
    {
      "file": "lib/net45/BGYY_ValidateDraft.xaml",
      "workflow": "BGYY_ValidateDraft",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "originalValue": "[&quot;Placeholder — Then branch has no activities yet&quot;]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "placeholder_sentinel",
      "severity": "execution_blocking",
      "rationale": "Sentinel \"[&quot;Placeholder — Then branch has no activities yet&quot;]\" in executable property Message replaced with platform-safe value \"\"\"\" — not executable, degradation substitute"
    },
    {
      "file": "lib/net45/BGYY_ValidateDraft.xaml",
      "workflow": "BGYY_ValidateDraft",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "originalValue": "[&quot;Placeholder — Then branch has no activities yet&quot;]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "placeholder_sentinel",
      "severity": "execution_blocking",
      "rationale": "Sentinel \"[&quot;Placeholder — Then branch has no activities yet&quot;]\" in executable property Message replaced with platform-safe value \"\"\"\" — not executable, degradation substitute"
    },
    {
      "file": "lib/net45/BGYY_ValidateDraft.xaml",
      "workflow": "BGYY_ValidateDraft",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "originalValue": "[&quot;Placeholder — Then branch has no activities yet&quot;]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "placeholder_sentinel",
      "severity": "execution_blocking",
      "rationale": "Sentinel \"[&quot;Placeholder — Then branch has no activities yet&quot;]\" in executable property Message replaced with platform-safe value \"\"\"\" — not executable, degradation substitute"
    },
    {
      "file": "lib/net45/BGYY_ValidateDraft.xaml",
      "workflow": "BGYY_ValidateDraft",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "originalValue": "[BGYY_ValidateDraft] FAIL placeholder-in-body - RunId=&quot; &amp; InRunId &amp; &quot; | FullName=&apos;&quot; &amp; InFullName &amp; &quot;&apos;",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "placeholder_sentinel",
      "severity": "execution_blocking",
      "rationale": "Sentinel \"[BGYY_ValidateDraft] FAIL placeholder-in-body - RunId=&quot; &amp; InRunId &amp;\" in executable property Message replaced with platform-safe value \"\"\"\" — not executable, degradation substitute"
    },
    {
      "file": "lib/net45/BGYY_ValidateDraft.xaml",
      "workflow": "BGYY_ValidateDraft",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "originalValue": "[&quot;Placeholder — Then branch has no activities yet&quot;]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "placeholder_sentinel",
      "severity": "execution_blocking",
      "rationale": "Sentinel \"[&quot;Placeholder — Then branch has no activities yet&quot;]\" in executable property Message replaced with platform-safe value \"\"\"\" — not executable, degradation substitute"
    },
    {
      "file": "lib/net45/BGYY_ValidateDraft.xaml",
      "workflow": "BGYY_ValidateDraft",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "originalValue": "[BGYY_ValidateDraft] FAIL placeholder-in-subject - RunId=&quot; &amp; InRunId &amp; &quot; | FullName=&apos;&quot; &amp; InFullName &amp; &quot;&apos;",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "placeholder_sentinel",
      "severity": "execution_blocking",
      "rationale": "Sentinel \"[BGYY_ValidateDraft] FAIL placeholder-in-subject - RunId=&quot; &amp; InRunId &a\" in executable property Message replaced with platform-safe value \"\"\"\" — not executable, degradation substitute"
    },
    {
      "file": "lib/net45/BGYY_ValidateDraft.xaml",
      "workflow": "BGYY_ValidateDraft",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "originalValue": "[&quot;Placeholder — Then branch has no activities yet&quot;]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "placeholder_sentinel",
      "severity": "execution_blocking",
      "rationale": "Sentinel \"[&quot;Placeholder — Then branch has no activities yet&quot;]\" in executable property Message replaced with platform-safe value \"\"\"\" — not executable, degradation substitute"
    },
    {
      "file": "lib/net45/BGYY_ValidateDraft.xaml",
      "workflow": "BGYY_ValidateDraft",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "originalValue": "[&quot;Placeholder — Then branch has no activities yet&quot;]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "placeholder_sentinel",
      "severity": "execution_blocking",
      "rationale": "Sentinel \"[&quot;Placeholder — Then branch has no activities yet&quot;]\" in executable property Message replaced with platform-safe value \"\"\"\" — not executable, degradation substitute"
    },
    {
      "file": "lib/net45/BGYY_ValidateDraft.xaml",
      "workflow": "BGYY_ValidateDraft",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "originalValue": "[&quot;Placeholder — Then branch has no activities yet&quot;]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "placeholder_sentinel",
      "severity": "execution_blocking",
      "rationale": "Sentinel \"[&quot;Placeholder — Then branch has no activities yet&quot;]\" in executable property Message replaced with platform-safe value \"\"\"\" — not executable, degradation substitute"
    },
    {
      "file": "lib/net45/BGYY_SendGmail.xaml",
      "workflow": "BGYY_SendGmail",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "originalValue": "[&quot;Placeholder — Then branch has no activities yet&quot;]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "placeholder_sentinel",
      "severity": "execution_blocking",
      "rationale": "Sentinel \"[&quot;Placeholder — Then branch has no activities yet&quot;]\" in executable property Message replaced with platform-safe value \"\"\"\" — not executable, degradation substitute"
    },
    {
      "file": "lib/net45/BGYY_SendGmail.xaml",
      "workflow": "BGYY_SendGmail",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "originalValue": "[&quot;Placeholder — RetryScope body has no activities yet&quot;]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "placeholder_sentinel",
      "severity": "execution_blocking",
      "rationale": "Sentinel \"[&quot;Placeholder — RetryScope body has no activities yet&quot;]\" in executable property Message replaced with platform-safe value \"\"\"\" — not executable, degradation substitute"
    },
    {
      "file": "lib/net45/BGYY_SendGmail.xaml",
      "workflow": "BGYY_SendGmail",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "originalValue": "[&quot;Placeholder — Then branch has no activities yet&quot;]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "placeholder_sentinel",
      "severity": "execution_blocking",
      "rationale": "Sentinel \"[&quot;Placeholder — Then branch has no activities yet&quot;]\" in executable property Message replaced with platform-safe value \"\"\"\" — not executable, degradation substitute"
    },
    {
      "file": "lib/net45/BGYY_SendGmail.xaml",
      "workflow": "BGYY_SendGmail",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "originalValue": "[&quot;Placeholder — Then branch has no activities yet&quot;]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "placeholder_sentinel",
      "severity": "execution_blocking",
      "rationale": "Sentinel \"[&quot;Placeholder — Then branch has no activities yet&quot;]\" in executable property Message replaced with platform-safe value \"\"\"\" — not executable, degradation substitute"
    },
    {
      "file": "lib/net45/BGYY_WriteSendLog.xaml",
      "workflow": "BGYY_WriteSendLog",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "originalValue": "[&quot;Placeholder — Then branch has no activities yet&quot;]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "placeholder_sentinel",
      "severity": "execution_blocking",
      "rationale": "Sentinel \"[&quot;Placeholder — Then branch has no activities yet&quot;]\" in executable property Message replaced with platform-safe value \"\"\"\" — not executable, degradation substitute"
    },
    {
      "file": "lib/net45/BGYY_WriteSendLog.xaml",
      "workflow": "BGYY_WriteSendLog",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "originalValue": "[&quot;Placeholder — Then branch has no activities yet&quot;]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "placeholder_sentinel",
      "severity": "execution_blocking",
      "rationale": "Sentinel \"[&quot;Placeholder — Then branch has no activities yet&quot;]\" in executable property Message replaced with platform-safe value \"\"\"\" — not executable, degradation substitute"
    },
    {
      "file": "lib/net45/InitAllApplications.xaml",
      "workflow": "InitAllApplications",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "originalValue": "[&quot;TODO: Add application initialization steps (e.g., open browsers, launch desktop apps)&quot;]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "todo_sentinel",
      "severity": "execution_blocking",
      "rationale": "Sentinel \"[&quot;TODO: Add application initialization steps (e.g., open browsers, launch d\" in executable property Message replaced with platform-safe value \"\"\"\" — not executable, degradation substitute"
    }
  ],
  "unresolvableJsonDefects": [],
  "requiredPropertyBindings": [
    {
      "file": "BGYY_GetTodaysBirthdays.xaml",
      "workflow": "BGYY_GetTodaysBirthdays",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[BGYY_GetTodaysBirthdays][Init] RunId=&quot; &amp; InRunId &amp; &quot; | Resolving today&apos;s date in America/New_York",
      "resolvedValue": "[BGYY_GetTodaysBirthdays][Init] RunId=&quot; &amp; InRunId &amp; &quot; | Resolving today&apos;s date in America/New_York",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[BGYY_GetTodaysBirthdays][Init] RunId=&quot; &amp; InRunId &amp; &quot; | Resolv",
        "precedenceTier": 4
      }
    },
    {
      "file": "BGYY_GetTodaysBirthdays.xaml",
      "workflow": "BGYY_GetTodaysBirthdays",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Error in Resolve current date/time in America/New_York via InvokeCode (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "resolvedValue": "[&quot;Error in Resolve current date/time in America/New_York via InvokeCode (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 1,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Error in Resolve current date/time in America/New_York via InvokeCode (&q",
        "precedenceTier": 4
      }
    },
    {
      "file": "BGYY_GetTodaysBirthdays.xaml",
      "workflow": "BGYY_GetTodaysBirthdays",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "&quot;Error in Resolve current date/time in America/New_York via InvokeCode: &quot; &amp; exception.Message",
      "resolvedValue": "&quot;Error in Resolve current date/time in America/New_York via InvokeCode: &quot; &amp; exception.Message",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 2,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "&quot;Error in Resolve current date/time in America/New_York via InvokeCode: &qu",
        "precedenceTier": 4
      }
    },
    {
      "file": "BGYY_GetTodaysBirthdays.xaml",
      "workflow": "BGYY_GetTodaysBirthdays",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "&quot;[BGYY_GetTodaysBirthdays][DateWindow] TodayEastern=&quot; &amp; dt_TodayEastern.ToString(&quot;yyyy-MM-dd HH:mm:ss&quot;) &amp; &quot; | WindowStart=&quot; &amp; dt_TodayStart.ToString(&quot;yyyy-MM-dd&quot;) &amp; &quot; | WindowEnd=&quot; &amp; dt_TodayEnd.ToString(&quot;yyyy-MM-dd&quot;)",
      "resolvedValue": "&quot;[BGYY_GetTodaysBirthdays][DateWindow] TodayEastern=&quot; &amp; dt_TodayEastern.ToString(&quot;yyyy-MM-dd HH:mm:ss&quot;) &amp; &quot; | WindowStart=&quot; &amp; dt_TodayStart.ToString(&quot;yyyy-MM-dd&quot;) &amp; &quot; | WindowEnd=&quot; &amp; dt_TodayEnd.ToString(&quot;yyyy-MM-dd&quot;)",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 3,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "&quot;[BGYY_GetTodaysBirthdays][DateWindow] TodayEastern=&quot; &amp; dt_TodayEa",
        "precedenceTier": 4
      }
    },
    {
      "file": "BGYY_GetTodaysBirthdays.xaml",
      "workflow": "BGYY_GetTodaysBirthdays",
      "activityType": "Assign",
      "propertyName": "To",
      "sourceBinding": "variable",
      "originalValue": "[int_RetryAttempt]",
      "resolvedValue": "[int_RetryAttempt]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "variable",
        "sourceName": "int_RetryAttempt",
        "sourceWorkflow": "BGYY_GetTodaysBirthdays",
        "precedenceTier": 2
      }
    },
    {
      "file": "BGYY_GetTodaysBirthdays.xaml",
      "workflow": "BGYY_GetTodaysBirthdays",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "\"0\"",
      "resolvedValue": "\"0\"",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "\"0\"",
        "precedenceTier": 4
      }
    },
    {
      "file": "BGYY_GetTodaysBirthdays.xaml",
      "workflow": "BGYY_GetTodaysBirthdays",
      "activityType": "Assign",
      "propertyName": "To",
      "sourceBinding": "variable",
      "originalValue": "[bool_CalendarQuerySuccess]",
      "resolvedValue": "[bool_CalendarQuerySuccess]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 1,
      "provenance": {
        "sourceKind": "variable",
        "sourceName": "bool_CalendarQuerySuccess",
        "sourceWorkflow": "BGYY_GetTodaysBirthdays",
        "precedenceTier": 2
      }
    },
    {
      "file": "BGYY_GetTodaysBirthdays.xaml",
      "workflow": "BGYY_GetTodaysBirthdays",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "False",
      "resolvedValue": "False",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 1,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "False",
        "precedenceTier": 4
      }
    },
    {
      "file": "BGYY_GetTodaysBirthdays.xaml",
      "workflow": "BGYY_GetTodaysBirthdays",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "variable",
      "originalValue": "",
      "resolvedValue": "[str_LogMessage]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 4,
      "provenance": {
        "sourceKind": "variable",
        "sourceName": "str_LogMessage",
        "sourceWorkflow": "BGYY_GetTodaysBirthdays",
        "precedenceTier": 2
      }
    },
    {
      "file": "BGYY_GetTodaysBirthdays.xaml",
      "workflow": "BGYY_GetTodaysBirthdays",
      "activityType": "Assign",
      "propertyName": "To",
      "sourceBinding": "variable",
      "originalValue": "[bool_CalendarQuerySuccess]",
      "resolvedValue": "[bool_CalendarQuerySuccess]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 2,
      "provenance": {
        "sourceKind": "variable",
        "sourceName": "bool_CalendarQuerySuccess",
        "sourceWorkflow": "BGYY_GetTodaysBirthdays",
        "precedenceTier": 2
      }
    },
    {
      "file": "BGYY_GetTodaysBirthdays.xaml",
      "workflow": "BGYY_GetTodaysBirthdays",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "True",
      "resolvedValue": "True",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 2,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "True",
        "precedenceTier": 4
      }
    },
    {
      "file": "BGYY_GetTodaysBirthdays.xaml",
      "workflow": "BGYY_GetTodaysBirthdays",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "variable",
      "originalValue": "",
      "resolvedValue": "[str_LogMessage]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 5,
      "provenance": {
        "sourceKind": "variable",
        "sourceName": "str_LogMessage",
        "sourceWorkflow": "BGYY_GetTodaysBirthdays",
        "precedenceTier": 2
      }
    },
    {
      "file": "BGYY_GetTodaysBirthdays.xaml",
      "workflow": "BGYY_GetTodaysBirthdays",
      "activityType": "If",
      "propertyName": "Condition",
      "sourceBinding": "attribute-value",
      "originalValue": "[obj_RawCalendarEvents Is Nothing]",
      "resolvedValue": "[obj_RawCalendarEvents Is Nothing]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[obj_RawCalendarEvents Is Nothing]",
        "precedenceTier": 4
      }
    },
    {
      "file": "BGYY_GetTodaysBirthdays.xaml",
      "workflow": "BGYY_GetTodaysBirthdays",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "variable",
      "originalValue": "",
      "resolvedValue": "[str_LogMessage]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 6,
      "provenance": {
        "sourceKind": "variable",
        "sourceName": "str_LogMessage",
        "sourceWorkflow": "BGYY_GetTodaysBirthdays",
        "precedenceTier": 2
      }
    },
    {
      "file": "BGYY_GetTodaysBirthdays.xaml",
      "workflow": "BGYY_GetTodaysBirthdays",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[BGYY_GetTodaysBirthdays][Warn] Google Calendar connector returned Nothing for RunId=&quot; &amp; InRunId &amp; &quot; | Treating as zero birthday events today",
      "resolvedValue": "[BGYY_GetTodaysBirthdays][Warn] Google Calendar connector returned Nothing for RunId=&quot; &amp; InRunId &amp; &quot; | Treating as zero birthday events today",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 7,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[BGYY_GetTodaysBirthdays][Warn] Google Calendar connector returned Nothing for R",
        "precedenceTier": 4
      }
    },
    {
      "file": "BGYY_GetTodaysBirthdays.xaml",
      "workflow": "BGYY_GetTodaysBirthdays",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Error in Parse raw connector response into enumerable events via InvokeCode (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "resolvedValue": "[&quot;Error in Parse raw connector response into enumerable events via InvokeCode (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 8,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Error in Parse raw connector response into enumerable events via InvokeCo",
        "precedenceTier": 4
      }
    },
    {
      "file": "BGYY_GetTodaysBirthdays.xaml",
      "workflow": "BGYY_GetTodaysBirthdays",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "&quot;Error in Parse raw connector response into enumerable events via InvokeCode: &quot; &amp; exception.Message",
      "resolvedValue": "&quot;Error in Parse raw connector response into enumerable events via InvokeCode: &quot; &amp; exception.Message",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 9,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "&quot;Error in Parse raw connector response into enumerable events via InvokeCod",
        "precedenceTier": 4
      }
    },
    {
      "file": "BGYY_GetTodaysBirthdays.xaml",
      "workflow": "BGYY_GetTodaysBirthdays",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "&quot;[BGYY_GetTodaysBirthdays][Parse] RunId=&quot; &amp; InRunId &amp; &quot; | BirthdayEventsFound=&quot; &amp; int_EventCount.ToString() &amp; &quot; | Date=&quot; &amp; dt_TodayEastern.ToString(&quot;yyyy-MM-dd&quot;)",
      "resolvedValue": "&quot;[BGYY_GetTodaysBirthdays][Parse] RunId=&quot; &amp; InRunId &amp; &quot; | BirthdayEventsFound=&quot; &amp; int_EventCount.ToString() &amp; &quot; | Date=&quot; &amp; dt_TodayEastern.ToString(&quot;yyyy-MM-dd&quot;)",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 10,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "&quot;[BGYY_GetTodaysBirthdays][Parse] RunId=&quot; &amp; InRunId &amp; &quot; |",
        "precedenceTier": 4
      }
    },
    {
      "file": "BGYY_GetTodaysBirthdays.xaml",
      "workflow": "BGYY_GetTodaysBirthdays",
      "activityType": "If",
      "propertyName": "Condition",
      "sourceBinding": "attribute-value",
      "originalValue": "[int_EventCount = 0]",
      "resolvedValue": "[int_EventCount = 0]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 1,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[int_EventCount = 0]",
        "precedenceTier": 4
      }
    },
    {
      "file": "BGYY_GetTodaysBirthdays.xaml",
      "workflow": "BGYY_GetTodaysBirthdays",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "variable",
      "originalValue": "",
      "resolvedValue": "[str_LogMessage]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 11,
      "provenance": {
        "sourceKind": "variable",
        "sourceName": "str_LogMessage",
        "sourceWorkflow": "BGYY_GetTodaysBirthdays",
        "precedenceTier": 2
      }
    },
    {
      "file": "BGYY_GetTodaysBirthdays.xaml",
      "workflow": "BGYY_GetTodaysBirthdays",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[BGYY_GetTodaysBirthdays][NoBirthdays] RunId=&quot; &amp; InRunId &amp; &quot; | No birthday events in &apos;Birthdays&apos; calendar for &quot; &amp; dt_TodayEastern.ToString(&quot;yyyy-MM-dd&quot;) &amp; &quot; America/New_York — ending cleanly",
      "resolvedValue": "[BGYY_GetTodaysBirthdays][NoBirthdays] RunId=&quot; &amp; InRunId &amp; &quot; | No birthday events in &apos;Birthdays&apos; calendar for &quot; &amp; dt_TodayEastern.ToString(&quot;yyyy-MM-dd&quot;) &amp; &quot; America/New_York — ending cleanly",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 12,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[BGYY_GetTodaysBirthdays][NoBirthdays] RunId=&quot; &amp; InRunId &amp; &quot; |",
        "precedenceTier": 4
      }
    },
    {
      "file": "BGYY_GetTodaysBirthdays.xaml",
      "workflow": "BGYY_GetTodaysBirthdays",
      "activityType": "Assign",
      "propertyName": "To",
      "sourceBinding": "attribute-value",
      "originalValue": "[\"OutBirthdayEvents\"]",
      "resolvedValue": "[\"OutBirthdayEvents\"]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 3,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[\"OutBirthdayEvents\"]",
        "precedenceTier": 4
      }
    },
    {
      "file": "BGYY_GetTodaysBirthdays.xaml",
      "workflow": "BGYY_GetTodaysBirthdays",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "variable",
      "originalValue": "[dt_BirthdayEventsTable]",
      "resolvedValue": "[dt_BirthdayEventsTable]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 3,
      "provenance": {
        "sourceKind": "variable",
        "sourceName": "dt_BirthdayEventsTable",
        "sourceWorkflow": "BGYY_GetTodaysBirthdays",
        "precedenceTier": 2
      }
    },
    {
      "file": "BGYY_GetTodaysBirthdays.xaml",
      "workflow": "BGYY_GetTodaysBirthdays",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[BGYY_GetTodaysBirthdays][Exit] RunId=&quot; &amp; InRunId &amp; &quot; | OutBirthdayEvents.Rows.Count=&quot; &amp; birthdayEventsTable.Rows.Count.ToString() &amp; &quot; | Status=Success",
      "resolvedValue": "[BGYY_GetTodaysBirthdays][Exit] RunId=&quot; &amp; InRunId &amp; &quot; | OutBirthdayEvents.Rows.Count=&quot; &amp; birthdayEventsTable.Rows.Count.ToString() &amp; &quot; | Status=Success",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 13,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[BGYY_GetTodaysBirthdays][Exit] RunId=&quot; &amp; InRunId &amp; &quot; | OutBir",
        "precedenceTier": 4
      }
    },
    {
      "file": "BGYY_ResolveRecipient.xaml",
      "workflow": "BGYY_ResolveRecipient",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[BGYY_ResolveRecipient][START] RunId=&quot; &amp; InRunId &amp; &quot; | FullName=&apos;&quot; &amp; InFullName &amp; &quot;&apos;",
      "resolvedValue": "[BGYY_ResolveRecipient][START] RunId=&quot; &amp; InRunId &amp; &quot; | FullName=&apos;&quot; &amp; InFullName &amp; &quot;&apos;",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[BGYY_ResolveRecipient][START] RunId=&quot; &amp; InRunId &amp; &quot; | FullNam",
        "precedenceTier": 4
      }
    },
    {
      "file": "BGYY_ResolveRecipient.xaml",
      "workflow": "BGYY_ResolveRecipient",
      "activityType": "Assign",
      "propertyName": "To",
      "sourceBinding": "variable",
      "originalValue": "[str_NormalizedName]",
      "resolvedValue": "[str_NormalizedName]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "variable",
        "sourceName": "str_NormalizedName",
        "sourceWorkflow": "BGYY_ResolveRecipient",
        "precedenceTier": 2
      }
    },
    {
      "file": "BGYY_ResolveRecipient.xaml",
      "workflow": "BGYY_ResolveRecipient",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "[InFullName.Trim().ToLower().Replace(\"  \", \" \")]",
      "resolvedValue": "[InFullName.Trim().ToLower().Replace(\"  \", \" \")]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[InFullName.Trim().ToLower().Replace(\"  \", \" \")]",
        "precedenceTier": 4
      }
    },
    {
      "file": "BGYY_ResolveRecipient.xaml",
      "workflow": "BGYY_ResolveRecipient",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "variable",
      "originalValue": "",
      "resolvedValue": "[str_LogMessage]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 1,
      "provenance": {
        "sourceKind": "variable",
        "sourceName": "str_LogMessage",
        "sourceWorkflow": "BGYY_ResolveRecipient",
        "precedenceTier": 2
      }
    },
    {
      "file": "BGYY_ResolveRecipient.xaml",
      "workflow": "BGYY_ResolveRecipient",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "&quot;[BGYY_ResolveRecipient] GoogleContacts query complete. FullName=&apos;&quot; &amp; InFullName &amp; &quot;&apos; | ResultRowCount=&quot; &amp; If(contactsDataTable IsNot Nothing, contactsDataTable.Rows.Count.ToString(), &quot;NULL&quot;)",
      "resolvedValue": "&quot;[BGYY_ResolveRecipient] GoogleContacts query complete. FullName=&apos;&quot; &amp; InFullName &amp; &quot;&apos; | ResultRowCount=&quot; &amp; If(contactsDataTable IsNot Nothing, contactsDataTable.Rows.Count.ToString(), &quot;NULL&quot;)",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 2,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "&quot;[BGYY_ResolveRecipient] GoogleContacts query complete. FullName=&apos;&quo",
        "precedenceTier": 4
      }
    },
    {
      "file": "BGYY_ResolveRecipient.xaml",
      "workflow": "BGYY_ResolveRecipient",
      "activityType": "Assign",
      "propertyName": "To",
      "sourceBinding": "variable",
      "originalValue": "[int_ContactCount]",
      "resolvedValue": "[int_ContactCount]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 1,
      "provenance": {
        "sourceKind": "variable",
        "sourceName": "int_ContactCount",
        "sourceWorkflow": "BGYY_ResolveRecipient",
        "precedenceTier": 2
      }
    },
    {
      "file": "BGYY_ResolveRecipient.xaml",
      "workflow": "BGYY_ResolveRecipient",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "[If(dt_ContactsDataTable IsNot Nothing, dt_ContactsDataTable.Rows.Count, 0)]",
      "resolvedValue": "[If(dt_ContactsDataTable IsNot Nothing, dt_ContactsDataTable.Rows.Count, 0)]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 1,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[If(dt_ContactsDataTable IsNot Nothing, dt_ContactsDataTable.Rows.Count, 0)]",
        "precedenceTier": 4
      }
    },
    {
      "file": "BGYY_ResolveRecipient.xaml",
      "workflow": "BGYY_ResolveRecipient",
      "activityType": "If",
      "propertyName": "Condition",
      "sourceBinding": "attribute-value",
      "originalValue": "[int_ContactCount = 0]",
      "resolvedValue": "[int_ContactCount = 0]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[int_ContactCount = 0]",
        "precedenceTier": 4
      }
    },
    {
      "file": "BGYY_ResolveRecipient.xaml",
      "workflow": "BGYY_ResolveRecipient",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "variable",
      "originalValue": "",
      "resolvedValue": "[str_LogMessage]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 3,
      "provenance": {
        "sourceKind": "variable",
        "sourceName": "str_LogMessage",
        "sourceWorkflow": "BGYY_ResolveRecipient",
        "precedenceTier": 2
      }
    },
    {
      "file": "BGYY_ResolveRecipient.xaml",
      "workflow": "BGYY_ResolveRecipient",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[BGYY_ResolveRecipient][SKIP] No contact found in Google Contacts. RunId=&quot; &amp; InRunId &amp; &quot; | FullName=&apos;&quot; &amp; InFullName &amp; &quot;&apos; | NormalizedKey=&apos;&quot; &amp; normalizedName &amp; &quot;&apos;",
      "resolvedValue": "[BGYY_ResolveRecipient][SKIP] No contact found in Google Contacts. RunId=&quot; &amp; InRunId &amp; &quot; | FullName=&apos;&quot; &amp; InFullName &amp; &quot;&apos; | NormalizedKey=&apos;&quot; &amp; normalizedName &amp; &quot;&apos;",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 4,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[BGYY_ResolveRecipient][SKIP] No contact found in Google Contacts. RunId=&quot; ",
        "precedenceTier": 4
      }
    },
    {
      "file": "BGYY_ResolveRecipient.xaml",
      "workflow": "BGYY_ResolveRecipient",
      "activityType": "If",
      "propertyName": "Condition",
      "sourceBinding": "attribute-value",
      "originalValue": "[int_ContactCount &gt; 1]",
      "resolvedValue": "[int_ContactCount &gt; 1]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 1,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[int_ContactCount &gt; 1]",
        "precedenceTier": 4
      }
    },
    {
      "file": "BGYY_ResolveRecipient.xaml",
      "workflow": "BGYY_ResolveRecipient",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "variable",
      "originalValue": "",
      "resolvedValue": "[str_LogMessage]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 5,
      "provenance": {
        "sourceKind": "variable",
        "sourceName": "str_LogMessage",
        "sourceWorkflow": "BGYY_ResolveRecipient",
        "precedenceTier": 2
      }
    },
    {
      "file": "BGYY_ResolveRecipient.xaml",
      "workflow": "BGYY_ResolveRecipient",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "&quot;[BGYY_ResolveRecipient][AMBIGUOUS] Multiple contacts matched. RunId=&quot; &amp; InRunId &amp; &quot; | FullName=&apos;&quot; &amp; InFullName &amp; &quot;&apos; | MatchCount=&quot; &amp; int_ContactCount.ToString()",
      "resolvedValue": "&quot;[BGYY_ResolveRecipient][AMBIGUOUS] Multiple contacts matched. RunId=&quot; &amp; InRunId &amp; &quot; | FullName=&apos;&quot; &amp; InFullName &amp; &quot;&apos; | MatchCount=&quot; &amp; int_ContactCount.ToString()",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 6,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "&quot;[BGYY_ResolveRecipient][AMBIGUOUS] Multiple contacts matched. RunId=&quot;",
        "precedenceTier": 4
      }
    },
    {
      "file": "BGYY_ResolveRecipient.xaml",
      "workflow": "BGYY_ResolveRecipient",
      "activityType": "Assign",
      "propertyName": "To",
      "sourceBinding": "variable",
      "originalValue": "[obj_SelectedContact]",
      "resolvedValue": "[obj_SelectedContact]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 2,
      "provenance": {
        "sourceKind": "variable",
        "sourceName": "obj_SelectedContact",
        "sourceWorkflow": "BGYY_ResolveRecipient",
        "precedenceTier": 2
      }
    },
    {
      "file": "BGYY_ResolveRecipient.xaml",
      "workflow": "BGYY_ResolveRecipient",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "[dt_ContactsDataTable.Rows(0)]",
      "resolvedValue": "[dt_ContactsDataTable.Rows(0)]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 2,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[dt_ContactsDataTable.Rows(0)]",
        "precedenceTier": 4
      }
    },
    {
      "file": "BGYY_ResolveRecipient.xaml",
      "workflow": "BGYY_ResolveRecipient",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Error in Extract single matching contact row from DataTable (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "resolvedValue": "[&quot;Error in Extract single matching contact row from DataTable (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 7,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Error in Extract single matching contact row from DataTable (&quot; &amp;",
        "precedenceTier": 4
      }
    },
    {
      "file": "BGYY_ResolveRecipient.xaml",
      "workflow": "BGYY_ResolveRecipient",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "&quot;Error in Extract single matching contact row from DataTable: &quot; &amp; exception.Message",
      "resolvedValue": "&quot;Error in Extract single matching contact row from DataTable: &quot; &amp; exception.Message",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 8,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "&quot;Error in Extract single matching contact row from DataTable: &quot; &amp; ",
        "precedenceTier": 4
      }
    },
    {
      "file": "BGYY_ResolveRecipient.xaml",
      "workflow": "BGYY_ResolveRecipient",
      "activityType": "Assign",
      "propertyName": "To",
      "sourceBinding": "variable",
      "originalValue": "[str_PersonalEmail]",
      "resolvedValue": "[str_PersonalEmail]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 3,
      "provenance": {
        "sourceKind": "variable",
        "sourceName": "str_PersonalEmail",
        "sourceWorkflow": "BGYY_ResolveRecipient",
        "precedenceTier": 2
      }
    },
    {
      "file": "BGYY_ResolveRecipient.xaml",
      "workflow": "BGYY_ResolveRecipient",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "[If(dt_ContactsDataTable.Columns.Contains(\"personal\") AndAlso dt_ContactsDataTable.Rows(0)(\"personal\") IsNot str_DBNull.Value, dt_ContactsDataTable.Rows(0)(\"personal\").ToString().Trim(), \"\")]",
      "resolvedValue": "[If(dt_ContactsDataTable.Columns.Contains(\"personal\") AndAlso dt_ContactsDataTable.Rows(0)(\"personal\") IsNot str_DBNull.Value, dt_ContactsDataTable.Rows(0)(\"personal\").ToString().Trim(), \"\")]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 3,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[If(dt_ContactsDataTable.Columns.Contains(\"personal\") AndAlso dt_ContactsDataTab",
        "precedenceTier": 4
      }
    },
    {
      "file": "BGYY_ResolveRecipient.xaml",
      "workflow": "BGYY_ResolveRecipient",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Error in Extract email addresses collection from contact (try &apos;personal&apos; column first) (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "resolvedValue": "[&quot;Error in Extract email addresses collection from contact (try &apos;personal&apos; column first) (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 9,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Error in Extract email addresses collection from contact (try &apos;perso",
        "precedenceTier": 4
      }
    },
    {
      "file": "BGYY_ResolveRecipient.xaml",
      "workflow": "BGYY_ResolveRecipient",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "&quot;Error in Extract email addresses collection from contact (try &apos;personal&apos; column first): &quot; &amp; exception.Message",
      "resolvedValue": "&quot;Error in Extract email addresses collection from contact (try &apos;personal&apos; column first): &quot; &amp; exception.Message",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 10,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "&quot;Error in Extract email addresses collection from contact (try &apos;person",
        "precedenceTier": 4
      }
    },
    {
      "file": "BGYY_ResolveRecipient.xaml",
      "workflow": "BGYY_ResolveRecipient",
      "activityType": "Assign",
      "propertyName": "To",
      "sourceBinding": "variable",
      "originalValue": "[str_HomeEmail]",
      "resolvedValue": "[str_HomeEmail]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 4,
      "provenance": {
        "sourceKind": "variable",
        "sourceName": "str_HomeEmail",
        "sourceWorkflow": "BGYY_ResolveRecipient",
        "precedenceTier": 2
      }
    },
    {
      "file": "BGYY_ResolveRecipient.xaml",
      "workflow": "BGYY_ResolveRecipient",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "[If(dt_ContactsDataTable.Columns.Contains(\"home\") AndAlso dt_ContactsDataTable.Rows(0)(\"home\") IsNot str_DBNull.Value, dt_ContactsDataTable.Rows(0)(\"home\").ToString().Trim(), \"\")]",
      "resolvedValue": "[If(dt_ContactsDataTable.Columns.Contains(\"home\") AndAlso dt_ContactsDataTable.Rows(0)(\"home\") IsNot str_DBNull.Value, dt_ContactsDataTable.Rows(0)(\"home\").ToString().Trim(), \"\")]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 4,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[If(dt_ContactsDataTable.Columns.Contains(\"home\") AndAlso dt_ContactsDataTable.R",
        "precedenceTier": 4
      }
    },
    {
      "file": "BGYY_ResolveRecipient.xaml",
      "workflow": "BGYY_ResolveRecipient",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Error in Extract home email from contact row (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "resolvedValue": "[&quot;Error in Extract home email from contact row (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 11,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Error in Extract home email from contact row (&quot; &amp; exception.GetT",
        "precedenceTier": 4
      }
    },
    {
      "file": "BGYY_ResolveRecipient.xaml",
      "workflow": "BGYY_ResolveRecipient",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "&quot;Error in Extract home email from contact row: &quot; &amp; exception.Message",
      "resolvedValue": "&quot;Error in Extract home email from contact row: &quot; &amp; exception.Message",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 12,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "&quot;Error in Extract home email from contact row: &quot; &amp; exception.Messa",
        "precedenceTier": 4
      }
    },
    {
      "file": "BGYY_ResolveRecipient.xaml",
      "workflow": "BGYY_ResolveRecipient",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "&quot;[BGYY_ResolveRecipient] Email label scan complete. RunId=&quot; &amp; InRunId &amp; &quot; | FullName=&apos;&quot; &amp; InFullName &amp; &quot;&apos; | PersonalEmailFound=&quot; &amp; (personalEmail &lt;&gt; &quot;&quot;).ToString() &amp; &quot; | HomeEmailFound=&quot; &amp; (homeEmail &lt;&gt; &quot;&quot;).ToString()",
      "resolvedValue": "&quot;[BGYY_ResolveRecipient] Email label scan complete. RunId=&quot; &amp; InRunId &amp; &quot; | FullName=&apos;&quot; &amp; InFullName &amp; &quot;&apos; | PersonalEmailFound=&quot; &amp; (personalEmail &lt;&gt; &quot;&quot;).ToString() &amp; &quot; | HomeEmailFound=&quot; &amp; (homeEmail &lt;&gt; &quot;&quot;).ToString()",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 13,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "&quot;[BGYY_ResolveRecipient] Email label scan complete. RunId=&quot; &amp; InRu",
        "precedenceTier": 4
      }
    },
    {
      "file": "BGYY_ResolveRecipient.xaml",
      "workflow": "BGYY_ResolveRecipient",
      "activityType": "If",
      "propertyName": "Condition",
      "sourceBinding": "attribute-value",
      "originalValue": "[str_PersonalEmail &lt;&gt; &quot;&quot;]",
      "resolvedValue": "[str_PersonalEmail &lt;&gt; &quot;&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 2,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[str_PersonalEmail &lt;&gt; &quot;&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "BGYY_ResolveRecipient.xaml",
      "workflow": "BGYY_ResolveRecipient",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "variable",
      "originalValue": "",
      "resolvedValue": "[str_LogMessage]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 14,
      "provenance": {
        "sourceKind": "variable",
        "sourceName": "str_LogMessage",
        "sourceWorkflow": "BGYY_ResolveRecipient",
        "precedenceTier": 2
      }
    },
    {
      "file": "BGYY_ResolveRecipient.xaml",
      "workflow": "BGYY_ResolveRecipient",
      "activityType": "Assign",
      "propertyName": "To",
      "sourceBinding": "variable",
      "originalValue": "[str_ResolvedEmail]",
      "resolvedValue": "[str_ResolvedEmail]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 5,
      "provenance": {
        "sourceKind": "variable",
        "sourceName": "str_ResolvedEmail",
        "sourceWorkflow": "BGYY_ResolveRecipient",
        "precedenceTier": 2
      }
    },
    {
      "file": "BGYY_ResolveRecipient.xaml",
      "workflow": "BGYY_ResolveRecipient",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "variable",
      "originalValue": "[str_PersonalEmail]",
      "resolvedValue": "[str_PersonalEmail]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 5,
      "provenance": {
        "sourceKind": "variable",
        "sourceName": "str_PersonalEmail",
        "sourceWorkflow": "BGYY_ResolveRecipient",
        "precedenceTier": 2
      }
    },
    {
      "file": "BGYY_ResolveRecipient.xaml",
      "workflow": "BGYY_ResolveRecipient",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[BGYY_ResolveRecipient] Selected email label=personal. RunId=&quot; &amp; InRunId &amp; &quot; | FullName=&apos;&quot; &amp; InFullName &amp; &quot;&apos;",
      "resolvedValue": "[BGYY_ResolveRecipient] Selected email label=personal. RunId=&quot; &amp; InRunId &amp; &quot; | FullName=&apos;&quot; &amp; InFullName &amp; &quot;&apos;",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 15,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[BGYY_ResolveRecipient] Selected email label=personal. RunId=&quot; &amp; InRunI",
        "precedenceTier": 4
      }
    },
    {
      "file": "BGYY_ResolveRecipient.xaml",
      "workflow": "BGYY_ResolveRecipient",
      "activityType": "If",
      "propertyName": "Condition",
      "sourceBinding": "attribute-value",
      "originalValue": "[str_HomeEmail &lt;&gt; &quot;&quot;]",
      "resolvedValue": "[str_HomeEmail &lt;&gt; &quot;&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 3,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[str_HomeEmail &lt;&gt; &quot;&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "BGYY_ResolveRecipient.xaml",
      "workflow": "BGYY_ResolveRecipient",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "variable",
      "originalValue": "",
      "resolvedValue": "[str_LogMessage]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 16,
      "provenance": {
        "sourceKind": "variable",
        "sourceName": "str_LogMessage",
        "sourceWorkflow": "BGYY_ResolveRecipient",
        "precedenceTier": 2
      }
    },
    {
      "file": "BGYY_ResolveRecipient.xaml",
      "workflow": "BGYY_ResolveRecipient",
      "activityType": "Assign",
      "propertyName": "To",
      "sourceBinding": "variable",
      "originalValue": "[str_ResolvedEmail]",
      "resolvedValue": "[str_ResolvedEmail]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 6,
      "provenance": {
        "sourceKind": "variable",
        "sourceName": "str_ResolvedEmail",
        "sourceWorkflow": "BGYY_ResolveRecipient",
        "precedenceTier": 2
      }
    },
    {
      "file": "BGYY_ResolveRecipient.xaml",
      "workflow": "BGYY_ResolveRecipient",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "variable",
      "originalValue": "[str_HomeEmail]",
      "resolvedValue": "[str_HomeEmail]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 6,
      "provenance": {
        "sourceKind": "variable",
        "sourceName": "str_HomeEmail",
        "sourceWorkflow": "BGYY_ResolveRecipient",
        "precedenceTier": 2
      }
    },
    {
      "file": "BGYY_ResolveRecipient.xaml",
      "workflow": "BGYY_ResolveRecipient",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[BGYY_ResolveRecipient] Selected email label=home (fallback, no personal found). RunId=&quot; &amp; InRunId &amp; &quot; | FullName=&apos;&quot; &amp; InFullName &amp; &quot;&apos;",
      "resolvedValue": "[BGYY_ResolveRecipient] Selected email label=home (fallback, no personal found). RunId=&quot; &amp; InRunId &amp; &quot; | FullName=&apos;&quot; &amp; InFullName &amp; &quot;&apos;",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 17,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[BGYY_ResolveRecipient] Selected email label=home (fallback, no personal found).",
        "precedenceTier": 4
      }
    },
    {
      "file": "BGYY_ResolveRecipient.xaml",
      "workflow": "BGYY_ResolveRecipient",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[BGYY_ResolveRecipient][SKIP] Contact found but no personal/home email label present. RunId=&quot; &amp; InRunId &amp; &quot; | FullName=&apos;&quot; &amp; InFullName &amp; &quot;&apos;",
      "resolvedValue": "[BGYY_ResolveRecipient][SKIP] Contact found but no personal/home email label present. RunId=&quot; &amp; InRunId &amp; &quot; | FullName=&apos;&quot; &amp; InFullName &amp; &quot;&apos;",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 18,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[BGYY_ResolveRecipient][SKIP] Contact found but no personal/home email label pre",
        "precedenceTier": 4
      }
    },
    {
      "file": "BGYY_ResolveRecipient.xaml",
      "workflow": "BGYY_ResolveRecipient",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[BGYY_ResolveRecipient][END-SUCCESS] Recipient resolved. RunId=&quot; &amp; InRunId &amp; &quot; | FullName=&apos;&quot; &amp; InFullName &amp; &quot;&apos; | EmailResolved=True",
      "resolvedValue": "[BGYY_ResolveRecipient][END-SUCCESS] Recipient resolved. RunId=&quot; &amp; InRunId &amp; &quot; | FullName=&apos;&quot; &amp; InFullName &amp; &quot;&apos; | EmailResolved=True",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 19,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[BGYY_ResolveRecipient][END-SUCCESS] Recipient resolved. RunId=&quot; &amp; InRu",
        "precedenceTier": 4
      }
    },
    {
      "file": "BGYY_ResolveRecipient.xaml",
      "workflow": "BGYY_ResolveRecipient",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "&quot;[BGYY_ResolveRecipient][ERROR] Google Contacts connector failed after all retries. RunId=&quot; &amp; InRunId &amp; &quot; | FullName=&apos;&quot; &amp; InFullName &amp; &quot;&apos; | ExceptionType=&quot; &amp; connectorException.GetType().Name &amp; &quot; | Message=&quot; &amp; connectorException.Message",
      "resolvedValue": "&quot;[BGYY_ResolveRecipient][ERROR] Google Contacts connector failed after all retries. RunId=&quot; &amp; InRunId &amp; &quot; | FullName=&apos;&quot; &amp; InFullName &amp; &quot;&apos; | ExceptionType=&quot; &amp; connectorException.GetType().Name &amp; &quot; | Message=&quot; &amp; connectorException.Message",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 20,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "&quot;[BGYY_ResolveRecipient][ERROR] Google Contacts connector failed after all ",
        "precedenceTier": 4
      }
    },
    {
      "file": "BGYY_ResolveRecipient.xaml",
      "workflow": "BGYY_ResolveRecipient",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Error in Catch persistent connector failure after all retries — log and set FailedSystem outputs (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "resolvedValue": "[&quot;Error in Catch persistent connector failure after all retries — log and set FailedSystem outputs (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 21,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Error in Catch persistent connector failure after all retries — log and s",
        "precedenceTier": 4
      }
    },
    {
      "file": "BGYY_ResolveRecipient.xaml",
      "workflow": "BGYY_ResolveRecipient",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;=== Completed: BGYY_ResolveRecipient ===&quot;]",
      "resolvedValue": "[&quot;=== Completed: BGYY_ResolveRecipient ===&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 22,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;=== Completed: BGYY_ResolveRecipient ===&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "BGYY_CheckDedupe.xaml",
      "workflow": "BGYY_CheckDedupe",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[BGYY_CheckDedupe] Starting dedupe check — PersonKey=&apos;&quot; &amp; in_PersonKey &amp; &quot;&apos;, SendYear=&quot; &amp; in_SendYear.ToString()",
      "resolvedValue": "[BGYY_CheckDedupe] Starting dedupe check — PersonKey=&apos;&quot; &amp; in_PersonKey &amp; &quot;&apos;, SendYear=&quot; &amp; in_SendYear.ToString()",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[BGYY_CheckDedupe] Starting dedupe check — PersonKey=&apos;&quot; &amp; in_Perso",
        "precedenceTier": 4
      }
    },
    {
      "file": "BGYY_CheckDedupe.xaml",
      "workflow": "BGYY_CheckDedupe",
      "activityType": "If",
      "propertyName": "Condition",
      "sourceBinding": "attribute-value",
      "originalValue": "[String.IsNullOrWhiteSpace(in_PersonKey)]",
      "resolvedValue": "[String.IsNullOrWhiteSpace(in_PersonKey)]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[String.IsNullOrWhiteSpace(in_PersonKey)]",
        "precedenceTier": 4
      }
    },
    {
      "file": "BGYY_CheckDedupe.xaml",
      "workflow": "BGYY_CheckDedupe",
      "activityType": "Assign",
      "propertyName": "To",
      "sourceBinding": "variable",
      "originalValue": "[str_DedupeFilterExpression]",
      "resolvedValue": "[str_DedupeFilterExpression]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "variable",
        "sourceName": "str_DedupeFilterExpression",
        "sourceWorkflow": "BGYY_CheckDedupe",
        "precedenceTier": 2
      }
    },
    {
      "file": "BGYY_CheckDedupe.xaml",
      "workflow": "BGYY_CheckDedupe",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;&quot;&quot;PersonKey = &apos;&quot;&quot; &amp; in_PersonKey &amp; &quot;&quot;&apos; AND SendYear = &quot;&quot; &amp; in_SendYear.ToString()&quot;]",
      "resolvedValue": "[&quot;&quot;&quot;PersonKey = &apos;&quot;&quot; &amp; in_PersonKey &amp; &quot;&quot;&apos; AND SendYear = &quot;&quot; &amp; in_SendYear.ToString()&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;&quot;&quot;PersonKey = &apos;&quot;&quot; &amp; in_PersonKey &amp; &quot",
        "precedenceTier": 4
      }
    },
    {
      "file": "BGYY_CheckDedupe.xaml",
      "workflow": "BGYY_CheckDedupe",
      "activityType": "QueryEntity",
      "propertyName": "EntityType",
      "sourceBinding": "attribute-value",
      "originalValue": "&quot;BGYY_BirthdaySendLog&quot;",
      "resolvedValue": "&quot;BGYY_BirthdaySendLog&quot;",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "&quot;BGYY_BirthdaySendLog&quot;",
        "precedenceTier": 4
      }
    },
    {
      "file": "BGYY_CheckDedupe.xaml",
      "workflow": "BGYY_CheckDedupe",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "variable",
      "originalValue": "",
      "resolvedValue": "[str_LogMessage]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 1,
      "provenance": {
        "sourceKind": "variable",
        "sourceName": "str_LogMessage",
        "sourceWorkflow": "BGYY_CheckDedupe",
        "precedenceTier": 2
      }
    },
    {
      "file": "BGYY_CheckDedupe.xaml",
      "workflow": "BGYY_CheckDedupe",
      "activityType": "Assign",
      "propertyName": "To",
      "sourceBinding": "variable",
      "originalValue": "[obj_QueryResultList]",
      "resolvedValue": "[obj_QueryResultList]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 1,
      "provenance": {
        "sourceKind": "variable",
        "sourceName": "obj_QueryResultList",
        "sourceWorkflow": "BGYY_CheckDedupe",
        "precedenceTier": 2
      }
    },
    {
      "file": "BGYY_CheckDedupe.xaml",
      "workflow": "BGYY_CheckDedupe",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;[If(obj_QueryResults IsNot Nothing, obj_QueryResults, New List(Of Object))]&quot;]",
      "resolvedValue": "[&quot;[If(obj_QueryResults IsNot Nothing, obj_QueryResults, New List(Of Object))]&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 1,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;[If(obj_QueryResults IsNot Nothing, obj_QueryResults, New List(Of Object)",
        "precedenceTier": 4
      }
    },
    {
      "file": "BGYY_CheckDedupe.xaml",
      "workflow": "BGYY_CheckDedupe",
      "activityType": "Assign",
      "propertyName": "To",
      "sourceBinding": "variable",
      "originalValue": "[int_RecordCount]",
      "resolvedValue": "[int_RecordCount]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 2,
      "provenance": {
        "sourceKind": "variable",
        "sourceName": "int_RecordCount",
        "sourceWorkflow": "BGYY_CheckDedupe",
        "precedenceTier": 2
      }
    },
    {
      "file": "BGYY_CheckDedupe.xaml",
      "workflow": "BGYY_CheckDedupe",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "&quot;[If(obj_QueryResultList IsNot Nothing, DirectCast(obj_QueryResultList, System.Collections.IList).Count, 0)]&quot;",
      "resolvedValue": "&quot;[If(obj_QueryResultList IsNot Nothing, DirectCast(obj_QueryResultList, System.Collections.IList).Count, 0)]&quot;",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 2,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "&quot;[If(obj_QueryResultList IsNot Nothing, DirectCast(obj_QueryResultList, Sys",
        "precedenceTier": 4
      }
    },
    {
      "file": "BGYY_CheckDedupe.xaml",
      "workflow": "BGYY_CheckDedupe",
      "activityType": "If",
      "propertyName": "Condition",
      "sourceBinding": "attribute-value",
      "originalValue": "[int_RecordCount &gt; 0]",
      "resolvedValue": "[int_RecordCount &gt; 0]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 1,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[int_RecordCount &gt; 0]",
        "precedenceTier": 4
      }
    },
    {
      "file": "BGYY_CheckDedupe.xaml",
      "workflow": "BGYY_CheckDedupe",
      "activityType": "Assign",
      "propertyName": "To",
      "sourceBinding": "variable",
      "originalValue": "[bool_AlreadySent]",
      "resolvedValue": "[bool_AlreadySent]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 3,
      "provenance": {
        "sourceKind": "variable",
        "sourceName": "bool_AlreadySent",
        "sourceWorkflow": "BGYY_CheckDedupe",
        "precedenceTier": 2
      }
    },
    {
      "file": "BGYY_CheckDedupe.xaml",
      "workflow": "BGYY_CheckDedupe",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "True",
      "resolvedValue": "True",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 3,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "True",
        "precedenceTier": 4
      }
    },
    {
      "file": "BGYY_CheckDedupe.xaml",
      "workflow": "BGYY_CheckDedupe",
      "activityType": "Assign",
      "propertyName": "To",
      "sourceBinding": "variable",
      "originalValue": "[str_ExistingRecordId]",
      "resolvedValue": "[str_ExistingRecordId]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 4,
      "provenance": {
        "sourceKind": "variable",
        "sourceName": "str_ExistingRecordId",
        "sourceWorkflow": "BGYY_CheckDedupe",
        "precedenceTier": 2
      }
    },
    {
      "file": "BGYY_CheckDedupe.xaml",
      "workflow": "BGYY_CheckDedupe",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;[DirectCast(DirectCast(obj_QueryResultList, System.Collections.IList)(0), UiPath.DataService.ApiClient.Models.EntityRecord)(&quot;&quot;str_Id&quot;&quot;).ToString()]&quot;]",
      "resolvedValue": "[&quot;[DirectCast(DirectCast(obj_QueryResultList, System.Collections.IList)(0), UiPath.DataService.ApiClient.Models.EntityRecord)(&quot;&quot;str_Id&quot;&quot;).ToString()]&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 4,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;[DirectCast(DirectCast(obj_QueryResultList, System.Collections.IList)(0),",
        "precedenceTier": 4
      }
    },
    {
      "file": "BGYY_CheckDedupe.xaml",
      "workflow": "BGYY_CheckDedupe",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[BGYY_CheckDedupe] Dedupe HIT — PersonKey=&apos;&quot; &amp; in_PersonKey &amp; &quot;&apos;, SendYear=&quot; &amp; in_SendYear.ToString() &amp; &quot;, ExistingRecordId=&apos;&quot; &amp; str_ExistingRecordId &amp; &quot;&apos;. Greeting already sent this year — skipping.",
      "resolvedValue": "[BGYY_CheckDedupe] Dedupe HIT — PersonKey=&apos;&quot; &amp; in_PersonKey &amp; &quot;&apos;, SendYear=&quot; &amp; in_SendYear.ToString() &amp; &quot;, ExistingRecordId=&apos;&quot; &amp; str_ExistingRecordId &amp; &quot;&apos;. Greeting already sent this year — skipping.",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 2,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[BGYY_CheckDedupe] Dedupe HIT — PersonKey=&apos;&quot; &amp; in_PersonKey &amp; ",
        "precedenceTier": 4
      }
    },
    {
      "file": "BGYY_CheckDedupe.xaml",
      "workflow": "BGYY_CheckDedupe",
      "activityType": "Assign",
      "propertyName": "To",
      "sourceBinding": "variable",
      "originalValue": "[bool_AlreadySent]",
      "resolvedValue": "[bool_AlreadySent]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 5,
      "provenance": {
        "sourceKind": "variable",
        "sourceName": "bool_AlreadySent",
        "sourceWorkflow": "BGYY_CheckDedupe",
        "precedenceTier": 2
      }
    },
    {
      "file": "BGYY_CheckDedupe.xaml",
      "workflow": "BGYY_CheckDedupe",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "False",
      "resolvedValue": "False",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 5,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "False",
        "precedenceTier": 4
      }
    },
    {
      "file": "BGYY_CheckDedupe.xaml",
      "workflow": "BGYY_CheckDedupe",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[BGYY_CheckDedupe] Dedupe MISS — PersonKey=&apos;&quot; &amp; in_PersonKey &amp; &quot;&apos;, SendYear=&quot; &amp; in_SendYear.ToString() &amp; &quot;. No prior send record found — safe to proceed.",
      "resolvedValue": "[BGYY_CheckDedupe] Dedupe MISS — PersonKey=&apos;&quot; &amp; in_PersonKey &amp; &quot;&apos;, SendYear=&quot; &amp; in_SendYear.ToString() &amp; &quot;. No prior send record found — safe to proceed.",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 3,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[BGYY_CheckDedupe] Dedupe MISS — PersonKey=&apos;&quot; &amp; in_PersonKey &amp;",
        "precedenceTier": 4
      }
    },
    {
      "file": "BGYY_CheckDedupe.xaml",
      "workflow": "BGYY_CheckDedupe",
      "activityType": "Assign",
      "propertyName": "To",
      "sourceBinding": "workflowArgument",
      "originalValue": "[out_AlreadySent]",
      "resolvedValue": "[out_AlreadySent]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 6,
      "provenance": {
        "sourceKind": "workflowArgument",
        "sourceName": "out_AlreadySent",
        "sourceWorkflow": "BGYY_CheckDedupe",
        "precedenceTier": 1
      }
    },
    {
      "file": "BGYY_CheckDedupe.xaml",
      "workflow": "BGYY_CheckDedupe",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "variable",
      "originalValue": "[bool_AlreadySent]",
      "resolvedValue": "[bool_AlreadySent]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 6,
      "provenance": {
        "sourceKind": "variable",
        "sourceName": "bool_AlreadySent",
        "sourceWorkflow": "BGYY_CheckDedupe",
        "precedenceTier": 2
      }
    },
    {
      "file": "BGYY_CheckDedupe.xaml",
      "workflow": "BGYY_CheckDedupe",
      "activityType": "Assign",
      "propertyName": "To",
      "sourceBinding": "workflowArgument",
      "originalValue": "[out_ExistingRecordId]",
      "resolvedValue": "[out_ExistingRecordId]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 7,
      "provenance": {
        "sourceKind": "workflowArgument",
        "sourceName": "out_ExistingRecordId",
        "sourceWorkflow": "BGYY_CheckDedupe",
        "precedenceTier": 1
      }
    },
    {
      "file": "BGYY_CheckDedupe.xaml",
      "workflow": "BGYY_CheckDedupe",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "variable",
      "originalValue": "[str_ExistingRecordId]",
      "resolvedValue": "[str_ExistingRecordId]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 7,
      "provenance": {
        "sourceKind": "variable",
        "sourceName": "str_ExistingRecordId",
        "sourceWorkflow": "BGYY_CheckDedupe",
        "precedenceTier": 2
      }
    },
    {
      "file": "BGYY_CheckDedupe.xaml",
      "workflow": "BGYY_CheckDedupe",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "variable",
      "originalValue": "",
      "resolvedValue": "[str_LogMessage]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 4,
      "provenance": {
        "sourceKind": "variable",
        "sourceName": "str_LogMessage",
        "sourceWorkflow": "BGYY_CheckDedupe",
        "precedenceTier": 2
      }
    },
    {
      "file": "BGYY_CheckDedupe.xaml",
      "workflow": "BGYY_CheckDedupe",
      "activityType": "Assign",
      "propertyName": "To",
      "sourceBinding": "variable",
      "originalValue": "[bool_AlreadySent]",
      "resolvedValue": "[bool_AlreadySent]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 8,
      "provenance": {
        "sourceKind": "variable",
        "sourceName": "bool_AlreadySent",
        "sourceWorkflow": "BGYY_CheckDedupe",
        "precedenceTier": 2
      }
    },
    {
      "file": "BGYY_CheckDedupe.xaml",
      "workflow": "BGYY_CheckDedupe",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "False",
      "resolvedValue": "False",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 8,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "False",
        "precedenceTier": 4
      }
    },
    {
      "file": "BGYY_CheckDedupe.xaml",
      "workflow": "BGYY_CheckDedupe",
      "activityType": "Assign",
      "propertyName": "To",
      "sourceBinding": "workflowArgument",
      "originalValue": "[out_AlreadySent]",
      "resolvedValue": "[out_AlreadySent]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 9,
      "provenance": {
        "sourceKind": "workflowArgument",
        "sourceName": "out_AlreadySent",
        "sourceWorkflow": "BGYY_CheckDedupe",
        "precedenceTier": 1
      }
    },
    {
      "file": "BGYY_CheckDedupe.xaml",
      "workflow": "BGYY_CheckDedupe",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;False&quot;]",
      "resolvedValue": "[&quot;False&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 9,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;False&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "BGYY_CheckDedupe.xaml",
      "workflow": "BGYY_CheckDedupe",
      "activityType": "Assign",
      "propertyName": "To",
      "sourceBinding": "workflowArgument",
      "originalValue": "[out_ExistingRecordId]",
      "resolvedValue": "[out_ExistingRecordId]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 10,
      "provenance": {
        "sourceKind": "workflowArgument",
        "sourceName": "out_ExistingRecordId",
        "sourceWorkflow": "BGYY_CheckDedupe",
        "precedenceTier": 1
      }
    },
    {
      "file": "BGYY_CheckDedupe.xaml",
      "workflow": "BGYY_CheckDedupe",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;&quot;]",
      "resolvedValue": "[&quot;&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 10,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "BGYY_CheckDedupe.xaml",
      "workflow": "BGYY_CheckDedupe",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[BGYY_CheckDedupe] Dedupe check complete — PersonKey=&apos;&quot; &amp; in_PersonKey &amp; &quot;&apos;, SendYear=&quot; &amp; in_SendYear.ToString() &amp; &quot;, AlreadySent=&quot; &amp; bool_AlreadySent.ToString() &amp; &quot;, ExistingRecordId=&apos;&quot; &amp; str_ExistingRecordId &amp; &quot;&apos;.",
      "resolvedValue": "[BGYY_CheckDedupe] Dedupe check complete — PersonKey=&apos;&quot; &amp; in_PersonKey &amp; &quot;&apos;, SendYear=&quot; &amp; in_SendYear.ToString() &amp; &quot;, AlreadySent=&quot; &amp; bool_AlreadySent.ToString() &amp; &quot;, ExistingRecordId=&apos;&quot; &amp; str_ExistingRecordId &amp; &quot;&apos;.",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 5,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[BGYY_CheckDedupe] Dedupe check complete — PersonKey=&apos;&quot; &amp; in_Perso",
        "precedenceTier": 4
      }
    },
    {
      "file": "BGYY_GenerateDraft.xaml",
      "workflow": "BGYY_GenerateDraft",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "&quot;[BGYY_GenerateDraft] START | RunId=&quot; &amp; InRunId &amp; &quot; | FullName=&quot; &amp; InFullName",
      "resolvedValue": "&quot;[BGYY_GenerateDraft] START | RunId=&quot; &amp; InRunId &amp; &quot; | FullName=&quot; &amp; InFullName",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "&quot;[BGYY_GenerateDraft] START | RunId=&quot; &amp; InRunId &amp; &quot; | Ful",
        "precedenceTier": 4
      }
    },
    {
      "file": "BGYY_GenerateDraft.xaml",
      "workflow": "BGYY_GenerateDraft",
      "activityType": "QueryEntity",
      "propertyName": "EntityType",
      "sourceBinding": "attribute-value",
      "originalValue": "&quot;BGYY_VoiceProfile&quot;",
      "resolvedValue": "&quot;BGYY_VoiceProfile&quot;",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "&quot;BGYY_VoiceProfile&quot;",
        "precedenceTier": 4
      }
    },
    {
      "file": "BGYY_GenerateDraft.xaml",
      "workflow": "BGYY_GenerateDraft",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Error in Query BGYY_VoiceProfile Data Service entity for Default profile (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "resolvedValue": "[&quot;Error in Query BGYY_VoiceProfile Data Service entity for Default profile (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 1,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Error in Query BGYY_VoiceProfile Data Service entity for Default profile ",
        "precedenceTier": 4
      }
    },
    {
      "file": "BGYY_GenerateDraft.xaml",
      "workflow": "BGYY_GenerateDraft",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "&quot;Error in Query BGYY_VoiceProfile Data Service entity for Default profile: &quot; &amp; exception.Message",
      "resolvedValue": "&quot;Error in Query BGYY_VoiceProfile Data Service entity for Default profile: &quot; &amp; exception.Message",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 2,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "&quot;Error in Query BGYY_VoiceProfile Data Service entity for Default profile: ",
        "precedenceTier": 4
      }
    },
    {
      "file": "BGYY_GenerateDraft.xaml",
      "workflow": "BGYY_GenerateDraft",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "&quot;[BGYY_GenerateDraft] WARN | Data Service unavailable for BGYY_VoiceProfile query; using hardcoded defaults | RunId=&quot; &amp; InRunId &amp; &quot; | FullName=&quot; &amp; InFullName",
      "resolvedValue": "&quot;[BGYY_GenerateDraft] WARN | Data Service unavailable for BGYY_VoiceProfile query; using hardcoded defaults | RunId=&quot; &amp; InRunId &amp; &quot; | FullName=&quot; &amp; InFullName",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 3,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "&quot;[BGYY_GenerateDraft] WARN | Data Service unavailable for BGYY_VoiceProfile",
        "precedenceTier": 4
      }
    },
    {
      "file": "BGYY_GenerateDraft.xaml",
      "workflow": "BGYY_GenerateDraft",
      "activityType": "If",
      "propertyName": "Condition",
      "sourceBinding": "attribute-value",
      "originalValue": "[obj_VoiceProfileRecords IsNot Nothing]",
      "resolvedValue": "[obj_VoiceProfileRecords IsNot Nothing]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[obj_VoiceProfileRecords IsNot Nothing]",
        "precedenceTier": 4
      }
    },
    {
      "file": "BGYY_GenerateDraft.xaml",
      "workflow": "BGYY_GenerateDraft",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "variable",
      "originalValue": "",
      "resolvedValue": "[str_LogMessage]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 4,
      "provenance": {
        "sourceKind": "variable",
        "sourceName": "str_LogMessage",
        "sourceWorkflow": "BGYY_GenerateDraft",
        "precedenceTier": 2
      }
    },
    {
      "file": "BGYY_GenerateDraft.xaml",
      "workflow": "BGYY_GenerateDraft",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "&quot;[BGYY_GenerateDraft] INFO | Voice profile loaded from Data Service | RunId=&quot; &amp; InRunId",
      "resolvedValue": "&quot;[BGYY_GenerateDraft] INFO | Voice profile loaded from Data Service | RunId=&quot; &amp; InRunId",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 5,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "&quot;[BGYY_GenerateDraft] INFO | Voice profile loaded from Data Service | RunId",
        "precedenceTier": 4
      }
    },
    {
      "file": "BGYY_GenerateDraft.xaml",
      "workflow": "BGYY_GenerateDraft",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Error in Assign voice profile fields from Data Service record (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "resolvedValue": "[&quot;Error in Assign voice profile fields from Data Service record (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 6,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Error in Assign voice profile fields from Data Service record (&quot; &am",
        "precedenceTier": 4
      }
    },
    {
      "file": "BGYY_GenerateDraft.xaml",
      "workflow": "BGYY_GenerateDraft",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "&quot;Error in Assign voice profile fields from Data Service record: &quot; &amp; exception.Message",
      "resolvedValue": "&quot;Error in Assign voice profile fields from Data Service record: &quot; &amp; exception.Message",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 7,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "&quot;Error in Assign voice profile fields from Data Service record: &quot; &amp",
        "precedenceTier": 4
      }
    },
    {
      "file": "BGYY_GenerateDraft.xaml",
      "workflow": "BGYY_GenerateDraft",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "&quot;[BGYY_GenerateDraft] WARN | No BGYY_VoiceProfile Default record found; using hardcoded defaults | RunId=&quot; &amp; InRunId",
      "resolvedValue": "&quot;[BGYY_GenerateDraft] WARN | No BGYY_VoiceProfile Default record found; using hardcoded defaults | RunId=&quot; &amp; InRunId",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 8,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "&quot;[BGYY_GenerateDraft] WARN | No BGYY_VoiceProfile Default record found; usi",
        "precedenceTier": 4
      }
    },
    {
      "file": "BGYY_GenerateDraft.xaml",
      "workflow": "BGYY_GenerateDraft",
      "activityType": "ReadStorageText",
      "propertyName": "Path",
      "sourceBinding": "attribute-value",
      "originalValue": "&quot;prompt_templates/voice_prompt.txt&quot;",
      "resolvedValue": "&quot;prompt_templates/voice_prompt.txt&quot;",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "&quot;prompt_templates/voice_prompt.txt&quot;",
        "precedenceTier": 4
      }
    },
    {
      "file": "BGYY_GenerateDraft.xaml",
      "workflow": "BGYY_GenerateDraft",
      "activityType": "ReadStorageText",
      "propertyName": "StorageBucketName",
      "sourceBinding": "attribute-value",
      "originalValue": "&quot;BGYY_RunArtifacts&quot;",
      "resolvedValue": "&quot;BGYY_RunArtifacts&quot;",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "&quot;BGYY_RunArtifacts&quot;",
        "precedenceTier": 4
      }
    },
    {
      "file": "BGYY_GenerateDraft.xaml",
      "workflow": "BGYY_GenerateDraft",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Error in Read voice prompt template from BGYY_RunArtifacts Storage Bucket (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "resolvedValue": "[&quot;Error in Read voice prompt template from BGYY_RunArtifacts Storage Bucket (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 9,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Error in Read voice prompt template from BGYY_RunArtifacts Storage Bucket",
        "precedenceTier": 4
      }
    },
    {
      "file": "BGYY_GenerateDraft.xaml",
      "workflow": "BGYY_GenerateDraft",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "&quot;Error in Read voice prompt template from BGYY_RunArtifacts Storage Bucket: &quot; &amp; exception.Message",
      "resolvedValue": "&quot;Error in Read voice prompt template from BGYY_RunArtifacts Storage Bucket: &quot; &amp; exception.Message",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 10,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "&quot;Error in Read voice prompt template from BGYY_RunArtifacts Storage Bucket:",
        "precedenceTier": 4
      }
    },
    {
      "file": "BGYY_GenerateDraft.xaml",
      "workflow": "BGYY_GenerateDraft",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;logMessage&quot;]",
      "resolvedValue": "[&quot;logMessage&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 11,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;logMessage&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "BGYY_GenerateDraft.xaml",
      "workflow": "BGYY_GenerateDraft",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "&quot;[BGYY_GenerateDraft] INFO | Prompt composed | Length=&quot; &amp; composedPrompt.Length.ToString() &amp; &quot; chars | RunId=&quot; &amp; InRunId &amp; &quot; | FullName=&quot; &amp; InFullName",
      "resolvedValue": "&quot;[BGYY_GenerateDraft] INFO | Prompt composed | Length=&quot; &amp; composedPrompt.Length.ToString() &amp; &quot; chars | RunId=&quot; &amp; InRunId &amp; &quot; | FullName=&quot; &amp; InFullName",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 12,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "&quot;[BGYY_GenerateDraft] INFO | Prompt composed | Length=&quot; &amp; composed",
        "precedenceTier": 4
      }
    },
    {
      "file": "BGYY_GenerateDraft.xaml",
      "workflow": "BGYY_GenerateDraft",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "variable",
      "originalValue": "",
      "resolvedValue": "[str_LogMessage]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 13,
      "provenance": {
        "sourceKind": "variable",
        "sourceName": "str_LogMessage",
        "sourceWorkflow": "BGYY_GenerateDraft",
        "precedenceTier": 2
      }
    },
    {
      "file": "BGYY_GenerateDraft.xaml",
      "workflow": "BGYY_GenerateDraft",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Error in Generate personalized birthday email draft via UiPath GenAI GenerateTextCompletion (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "resolvedValue": "[&quot;Error in Generate personalized birthday email draft via UiPath GenAI GenerateTextCompletion (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 14,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Error in Generate personalized birthday email draft via UiPath GenAI Gene",
        "precedenceTier": 4
      }
    },
    {
      "file": "BGYY_GenerateDraft.xaml",
      "workflow": "BGYY_GenerateDraft",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "&quot;Error in Generate personalized birthday email draft via UiPath GenAI GenerateTextCompletion: &quot; &amp; exception.Message",
      "resolvedValue": "&quot;Error in Generate personalized birthday email draft via UiPath GenAI GenerateTextCompletion: &quot; &amp; exception.Message",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 15,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "&quot;Error in Generate personalized birthday email draft via UiPath GenAI Gener",
        "precedenceTier": 4
      }
    },
    {
      "file": "BGYY_GenerateDraft.xaml",
      "workflow": "BGYY_GenerateDraft",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;logMessage&quot;]",
      "resolvedValue": "[&quot;logMessage&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 16,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;logMessage&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "BGYY_GenerateDraft.xaml",
      "workflow": "BGYY_GenerateDraft",
      "activityType": "UploadStorageFile",
      "propertyName": "Destination",
      "sourceBinding": "variable",
      "originalValue": "[str_ErrorScreenshotBucketPath]",
      "resolvedValue": "[str_ErrorScreenshotBucketPath]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "variable",
        "sourceName": "str_ErrorScreenshotBucketPath",
        "sourceWorkflow": "BGYY_GenerateDraft",
        "precedenceTier": 2
      }
    },
    {
      "file": "BGYY_GenerateDraft.xaml",
      "workflow": "BGYY_GenerateDraft",
      "activityType": "UploadStorageFile",
      "propertyName": "FileResource",
      "sourceBinding": "variable",
      "originalValue": "[str_ErrorScreenshotPath]",
      "resolvedValue": "[str_ErrorScreenshotPath]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "variable",
        "sourceName": "str_ErrorScreenshotPath",
        "sourceWorkflow": "BGYY_GenerateDraft",
        "precedenceTier": 2
      }
    },
    {
      "file": "BGYY_GenerateDraft.xaml",
      "workflow": "BGYY_GenerateDraft",
      "activityType": "UploadStorageFile",
      "propertyName": "Path",
      "sourceBinding": "attribute-value",
      "originalValue": "&quot;errorScreenshotBucketPath&quot;",
      "resolvedValue": "&quot;errorScreenshotBucketPath&quot;",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "&quot;errorScreenshotBucketPath&quot;",
        "precedenceTier": 4
      }
    },
    {
      "file": "BGYY_GenerateDraft.xaml",
      "workflow": "BGYY_GenerateDraft",
      "activityType": "UploadStorageFile",
      "propertyName": "StorageBucketName",
      "sourceBinding": "attribute-value",
      "originalValue": "&quot;BGYY_RunArtifacts&quot;",
      "resolvedValue": "&quot;BGYY_RunArtifacts&quot;",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "&quot;BGYY_RunArtifacts&quot;",
        "precedenceTier": 4
      }
    },
    {
      "file": "BGYY_GenerateDraft.xaml",
      "workflow": "BGYY_GenerateDraft",
      "activityType": "If",
      "propertyName": "Condition",
      "sourceBinding": "attribute-value",
      "originalValue": "[bool_GenAiFailed = True]",
      "resolvedValue": "[bool_GenAiFailed = True]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 1,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[bool_GenAiFailed = True]",
        "precedenceTier": 4
      }
    },
    {
      "file": "BGYY_GenerateDraft.xaml",
      "workflow": "BGYY_GenerateDraft",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "variable",
      "originalValue": "",
      "resolvedValue": "[str_LogMessage]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 17,
      "provenance": {
        "sourceKind": "variable",
        "sourceName": "str_LogMessage",
        "sourceWorkflow": "BGYY_GenerateDraft",
        "precedenceTier": 2
      }
    },
    {
      "file": "BGYY_GenerateDraft.xaml",
      "workflow": "BGYY_GenerateDraft",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "&quot;[BGYY_GenerateDraft] INFO | GenAI raw output received | Length=&quot; &amp; genAiRawOutput.Length.ToString() &amp; &quot; chars | RunId=&quot; &amp; InRunId &amp; &quot; | FullName=&quot; &amp; InFullName",
      "resolvedValue": "&quot;[BGYY_GenerateDraft] INFO | GenAI raw output received | Length=&quot; &amp; genAiRawOutput.Length.ToString() &amp; &quot; chars | RunId=&quot; &amp; InRunId &amp; &quot; | FullName=&quot; &amp; InFullName",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 18,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "&quot;[BGYY_GenerateDraft] INFO | GenAI raw output received | Length=&quot; &amp",
        "precedenceTier": 4
      }
    },
    {
      "file": "BGYY_GenerateDraft.xaml",
      "workflow": "BGYY_GenerateDraft",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Error in Parse Subject from GenAI JSON output using InvokeCode (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "resolvedValue": "[&quot;Error in Parse Subject from GenAI JSON output using InvokeCode (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 19,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Error in Parse Subject from GenAI JSON output using InvokeCode (&quot; &a",
        "precedenceTier": 4
      }
    },
    {
      "file": "BGYY_GenerateDraft.xaml",
      "workflow": "BGYY_GenerateDraft",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "&quot;Error in Parse Subject from GenAI JSON output using InvokeCode: &quot; &amp; exception.Message",
      "resolvedValue": "&quot;Error in Parse Subject from GenAI JSON output using InvokeCode: &quot; &amp; exception.Message",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 20,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "&quot;Error in Parse Subject from GenAI JSON output using InvokeCode: &quot; &am",
        "precedenceTier": 4
      }
    },
    {
      "file": "BGYY_GenerateDraft.xaml",
      "workflow": "BGYY_GenerateDraft",
      "activityType": "If",
      "propertyName": "Condition",
      "sourceBinding": "attribute-value",
      "originalValue": "[bool_ParseSucceeded = False]",
      "resolvedValue": "[bool_ParseSucceeded = False]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 2,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[bool_ParseSucceeded = False]",
        "precedenceTier": 4
      }
    },
    {
      "file": "BGYY_GenerateDraft.xaml",
      "workflow": "BGYY_GenerateDraft",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "variable",
      "originalValue": "",
      "resolvedValue": "[str_LogMessage]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 21,
      "provenance": {
        "sourceKind": "variable",
        "sourceName": "str_LogMessage",
        "sourceWorkflow": "BGYY_GenerateDraft",
        "precedenceTier": 2
      }
    },
    {
      "file": "BGYY_GenerateDraft.xaml",
      "workflow": "BGYY_GenerateDraft",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "&quot;[BGYY_GenerateDraft] ERROR | Failed to parse Subject/Body from GenAI output JSON | RunId=&quot; &amp; InRunId &amp; &quot; | FullName=&quot; &amp; InFullName &amp; &quot; | RawOutputLength=&quot; &amp; genAiRawOutput.Length.ToString()",
      "resolvedValue": "&quot;[BGYY_GenerateDraft] ERROR | Failed to parse Subject/Body from GenAI output JSON | RunId=&quot; &amp; InRunId &amp; &quot; | FullName=&quot; &amp; InFullName &amp; &quot; | RawOutputLength=&quot; &amp; genAiRawOutput.Length.ToString()",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 22,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "&quot;[BGYY_GenerateDraft] ERROR | Failed to parse Subject/Body from GenAI outpu",
        "precedenceTier": 4
      }
    },
    {
      "file": "BGYY_GenerateDraft.xaml",
      "workflow": "BGYY_GenerateDraft",
      "activityType": "Assign",
      "propertyName": "To",
      "sourceBinding": "variable",
      "originalValue": "[bool_GenAiFailed]",
      "resolvedValue": "[bool_GenAiFailed]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "variable",
        "sourceName": "bool_GenAiFailed",
        "sourceWorkflow": "BGYY_GenerateDraft",
        "precedenceTier": 2
      }
    },
    {
      "file": "BGYY_GenerateDraft.xaml",
      "workflow": "BGYY_GenerateDraft",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "True",
      "resolvedValue": "True",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "True",
        "precedenceTier": 4
      }
    },
    {
      "file": "BGYY_GenerateDraft.xaml",
      "workflow": "BGYY_GenerateDraft",
      "activityType": "UploadStorageFile",
      "propertyName": "Destination",
      "sourceBinding": "variable",
      "originalValue": "[str_ErrorScreenshotBucketPath]",
      "resolvedValue": "[str_ErrorScreenshotBucketPath]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 1,
      "provenance": {
        "sourceKind": "variable",
        "sourceName": "str_ErrorScreenshotBucketPath",
        "sourceWorkflow": "BGYY_GenerateDraft",
        "precedenceTier": 2
      }
    },
    {
      "file": "BGYY_GenerateDraft.xaml",
      "workflow": "BGYY_GenerateDraft",
      "activityType": "UploadStorageFile",
      "propertyName": "FileResource",
      "sourceBinding": "variable",
      "originalValue": "[str_ErrorScreenshotPath]",
      "resolvedValue": "[str_ErrorScreenshotPath]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 1,
      "provenance": {
        "sourceKind": "variable",
        "sourceName": "str_ErrorScreenshotPath",
        "sourceWorkflow": "BGYY_GenerateDraft",
        "precedenceTier": 2
      }
    },
    {
      "file": "BGYY_GenerateDraft.xaml",
      "workflow": "BGYY_GenerateDraft",
      "activityType": "UploadStorageFile",
      "propertyName": "Path",
      "sourceBinding": "attribute-value",
      "originalValue": "&quot;errorScreenshotBucketPath&quot;",
      "resolvedValue": "&quot;errorScreenshotBucketPath&quot;",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 1,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "&quot;errorScreenshotBucketPath&quot;",
        "precedenceTier": 4
      }
    },
    {
      "file": "BGYY_GenerateDraft.xaml",
      "workflow": "BGYY_GenerateDraft",
      "activityType": "UploadStorageFile",
      "propertyName": "StorageBucketName",
      "sourceBinding": "attribute-value",
      "originalValue": "&quot;BGYY_RunArtifacts&quot;",
      "resolvedValue": "&quot;BGYY_RunArtifacts&quot;",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 1,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "&quot;BGYY_RunArtifacts&quot;",
        "precedenceTier": 4
      }
    },
    {
      "file": "BGYY_GenerateDraft.xaml",
      "workflow": "BGYY_GenerateDraft",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "&quot;[BGYY_GenerateDraft] INFO | GenAI draft parsed successfully | SubjectLength=&quot; &amp; parsedSubject.Length.ToString() &amp; &quot; | BodyLength=&quot; &amp; parsedBody.Length.ToString() &amp; &quot; | RunId=&quot; &amp; InRunId &amp; &quot; | FullName=&quot; &amp; InFullName",
      "resolvedValue": "&quot;[BGYY_GenerateDraft] INFO | GenAI draft parsed successfully | SubjectLength=&quot; &amp; parsedSubject.Length.ToString() &amp; &quot; | BodyLength=&quot; &amp; parsedBody.Length.ToString() &amp; &quot; | RunId=&quot; &amp; InRunId &amp; &quot; | FullName=&quot; &amp; InFullName",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 23,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "&quot;[BGYY_GenerateDraft] INFO | GenAI draft parsed successfully | SubjectLengt",
        "precedenceTier": 4
      }
    },
    {
      "file": "BGYY_GenerateDraft.xaml",
      "workflow": "BGYY_GenerateDraft",
      "activityType": "Assign",
      "propertyName": "To",
      "sourceBinding": "variable",
      "originalValue": "[str_DraftArtifactJson]",
      "resolvedValue": "[str_DraftArtifactJson]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 1,
      "provenance": {
        "sourceKind": "variable",
        "sourceName": "str_DraftArtifactJson",
        "sourceWorkflow": "BGYY_GenerateDraft",
        "precedenceTier": 2
      }
    },
    {
      "file": "BGYY_GenerateDraft.xaml",
      "workflow": "BGYY_GenerateDraft",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "&quot;&quot;",
      "resolvedValue": "&quot;&quot;",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 1,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "&quot;&quot;",
        "precedenceTier": 4
      }
    },
    {
      "file": "BGYY_GenerateDraft.xaml",
      "workflow": "BGYY_GenerateDraft",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;=== Completed: BGYY_GenerateDraft ===&quot;]",
      "resolvedValue": "[&quot;=== Completed: BGYY_GenerateDraft ===&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 24,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;=== Completed: BGYY_GenerateDraft ===&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "BGYY_ValidateDraft.xaml",
      "workflow": "BGYY_ValidateDraft",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "&quot;[BGYY_ValidateDraft] START - RunId=&quot; &amp; InRunId &amp; &quot; | FullName=&quot; &amp; InFullName &amp; &quot; | SubjectLen=&quot; &amp; InSubject.Length.ToString() &amp; &quot; | BodyLen=&quot; &amp; InBody.Length.ToString()",
      "resolvedValue": "&quot;[BGYY_ValidateDraft] START - RunId=&quot; &amp; InRunId &amp; &quot; | FullName=&quot; &amp; InFullName &amp; &quot; | SubjectLen=&quot; &amp; InSubject.Length.ToString() &amp; &quot; | BodyLen=&quot; &amp; InBody.Length.ToString()",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "&quot;[BGYY_ValidateDraft] START - RunId=&quot; &amp; InRunId &amp; &quot; | Ful",
        "precedenceTier": 4
      }
    },
    {
      "file": "BGYY_ValidateDraft.xaml",
      "workflow": "BGYY_ValidateDraft",
      "activityType": "If",
      "propertyName": "Condition",
      "sourceBinding": "attribute-value",
      "originalValue": "[String.IsNullOrWhiteSpace(InFullName) OrElse String.IsNullOrWhiteSpace(InSubject) OrElse String.IsNullOrWhiteSpace(InBody)]",
      "resolvedValue": "[String.IsNullOrWhiteSpace(InFullName) OrElse String.IsNullOrWhiteSpace(InSubject) OrElse String.IsNullOrWhiteSpace(InBody)]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[String.IsNullOrWhiteSpace(InFullName) OrElse String.IsNullOrWhiteSpace(InSubjec",
        "precedenceTier": 4
      }
    },
    {
      "file": "BGYY_ValidateDraft.xaml",
      "workflow": "BGYY_ValidateDraft",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "variable",
      "originalValue": "",
      "resolvedValue": "[str_LogMessage]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 1,
      "provenance": {
        "sourceKind": "variable",
        "sourceName": "str_LogMessage",
        "sourceWorkflow": "BGYY_ValidateDraft",
        "precedenceTier": 2
      }
    },
    {
      "file": "BGYY_ValidateDraft.xaml",
      "workflow": "BGYY_ValidateDraft",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[BGYY_ValidateDraft] GUARD FAIL - Empty input detected. RunId=&quot; &amp; InRunId &amp; &quot; | FullName=&apos;&quot; &amp; InFullName &amp; &quot;&apos;",
      "resolvedValue": "[BGYY_ValidateDraft] GUARD FAIL - Empty input detected. RunId=&quot; &amp; InRunId &amp; &quot; | FullName=&apos;&quot; &amp; InFullName &amp; &quot;&apos;",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 2,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[BGYY_ValidateDraft] GUARD FAIL - Empty input detected. RunId=&quot; &amp; InRun",
        "precedenceTier": 4
      }
    },
    {
      "file": "BGYY_ValidateDraft.xaml",
      "workflow": "BGYY_ValidateDraft",
      "activityType": "Assign",
      "propertyName": "To",
      "sourceBinding": "variable",
      "originalValue": "[bool_NameFoundInBody]",
      "resolvedValue": "[bool_NameFoundInBody]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "variable",
        "sourceName": "bool_NameFoundInBody",
        "sourceWorkflow": "BGYY_ValidateDraft",
        "precedenceTier": 2
      }
    },
    {
      "file": "BGYY_ValidateDraft.xaml",
      "workflow": "BGYY_ValidateDraft",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "[str_NormalizedBody.Contains(str_NormalizedFullName)]",
      "resolvedValue": "[str_NormalizedBody.Contains(str_NormalizedFullName)]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[str_NormalizedBody.Contains(str_NormalizedFullName)]",
        "precedenceTier": 4
      }
    },
    {
      "file": "BGYY_ValidateDraft.xaml",
      "workflow": "BGYY_ValidateDraft",
      "activityType": "Assign",
      "propertyName": "To",
      "sourceBinding": "variable",
      "originalValue": "[bool_NameFoundInSubject]",
      "resolvedValue": "[bool_NameFoundInSubject]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 1,
      "provenance": {
        "sourceKind": "variable",
        "sourceName": "bool_NameFoundInSubject",
        "sourceWorkflow": "BGYY_ValidateDraft",
        "precedenceTier": 2
      }
    },
    {
      "file": "BGYY_ValidateDraft.xaml",
      "workflow": "BGYY_ValidateDraft",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "[str_NormalizedSubject.Contains(str_NormalizedFullName)]",
      "resolvedValue": "[str_NormalizedSubject.Contains(str_NormalizedFullName)]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 1,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[str_NormalizedSubject.Contains(str_NormalizedFullName)]",
        "precedenceTier": 4
      }
    },
    {
      "file": "BGYY_ValidateDraft.xaml",
      "workflow": "BGYY_ValidateDraft",
      "activityType": "If",
      "propertyName": "Condition",
      "sourceBinding": "attribute-value",
      "originalValue": "[bool_NameFoundInBody = False]",
      "resolvedValue": "[bool_NameFoundInBody = False]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 1,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[bool_NameFoundInBody = False]",
        "precedenceTier": 4
      }
    },
    {
      "file": "BGYY_ValidateDraft.xaml",
      "workflow": "BGYY_ValidateDraft",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "variable",
      "originalValue": "",
      "resolvedValue": "[str_LogMessage]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 3,
      "provenance": {
        "sourceKind": "variable",
        "sourceName": "str_LogMessage",
        "sourceWorkflow": "BGYY_ValidateDraft",
        "precedenceTier": 2
      }
    },
    {
      "file": "BGYY_ValidateDraft.xaml",
      "workflow": "BGYY_ValidateDraft",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[BGYY_ValidateDraft] FAIL name-in-body - RunId=&quot; &amp; InRunId &amp; &quot; | FullName=&apos;&quot; &amp; InFullName &amp; &quot;&apos;",
      "resolvedValue": "[BGYY_ValidateDraft] FAIL name-in-body - RunId=&quot; &amp; InRunId &amp; &quot; | FullName=&apos;&quot; &amp; InFullName &amp; &quot;&apos;",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 4,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[BGYY_ValidateDraft] FAIL name-in-body - RunId=&quot; &amp; InRunId &amp; &quot;",
        "precedenceTier": 4
      }
    },
    {
      "file": "BGYY_ValidateDraft.xaml",
      "workflow": "BGYY_ValidateDraft",
      "activityType": "If",
      "propertyName": "Condition",
      "sourceBinding": "attribute-value",
      "originalValue": "[bool_NameFoundInSubject = False]",
      "resolvedValue": "[bool_NameFoundInSubject = False]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 2,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[bool_NameFoundInSubject = False]",
        "precedenceTier": 4
      }
    },
    {
      "file": "BGYY_ValidateDraft.xaml",
      "workflow": "BGYY_ValidateDraft",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "variable",
      "originalValue": "",
      "resolvedValue": "[str_LogMessage]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 5,
      "provenance": {
        "sourceKind": "variable",
        "sourceName": "str_LogMessage",
        "sourceWorkflow": "BGYY_ValidateDraft",
        "precedenceTier": 2
      }
    },
    {
      "file": "BGYY_ValidateDraft.xaml",
      "workflow": "BGYY_ValidateDraft",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[BGYY_ValidateDraft] FAIL name-in-subject - RunId=&quot; &amp; InRunId &amp; &quot; | FullName=&apos;&quot; &amp; InFullName &amp; &quot;&apos;",
      "resolvedValue": "[BGYY_ValidateDraft] FAIL name-in-subject - RunId=&quot; &amp; InRunId &amp; &quot; | FullName=&apos;&quot; &amp; InFullName &amp; &quot;&apos;",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 6,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[BGYY_ValidateDraft] FAIL name-in-subject - RunId=&quot; &amp; InRunId &amp; &qu",
        "precedenceTier": 4
      }
    },
    {
      "file": "BGYY_ValidateDraft.xaml",
      "workflow": "BGYY_ValidateDraft",
      "activityType": "IsMatch",
      "propertyName": "Input",
      "sourceBinding": "attribute-value",
      "originalValue": "&quot;InBody&quot;",
      "resolvedValue": "&quot;InBody&quot;",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "&quot;InBody&quot;",
        "precedenceTier": 4
      }
    },
    {
      "file": "BGYY_ValidateDraft.xaml",
      "workflow": "BGYY_ValidateDraft",
      "activityType": "IsMatch",
      "propertyName": "Pattern",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;(?i)(\\{\\{[^}]+\\}\\}|\\[[A-Z_]{2}\\]|&lt;[A-Z_]{2}&gt;|\\[INSERT[^\\]]*\\]|\\[YOUR[^\\]]*\\])&quot;]",
      "resolvedValue": "[&quot;(?i)(\\{\\{[^}]+\\}\\}|\\[[A-Z_]{2}\\]|&lt;[A-Z_]{2}&gt;|\\[INSERT[^\\]]*\\]|\\[YOUR[^\\]]*\\])&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;(?i)(\\{\\{[^}]+\\}\\}|\\[[A-Z_]{2}\\]|&lt;[A-Z_]{2}&gt;|\\[INSERT[^\\]]*\\]|\\[YOU",
        "precedenceTier": 4
      }
    },
    {
      "file": "BGYY_ValidateDraft.xaml",
      "workflow": "BGYY_ValidateDraft",
      "activityType": "IsMatch",
      "propertyName": "Input",
      "sourceBinding": "attribute-value",
      "originalValue": "&quot;InSubject&quot;",
      "resolvedValue": "&quot;InSubject&quot;",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 1,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "&quot;InSubject&quot;",
        "precedenceTier": 4
      }
    },
    {
      "file": "BGYY_ValidateDraft.xaml",
      "workflow": "BGYY_ValidateDraft",
      "activityType": "IsMatch",
      "propertyName": "Pattern",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;(?i)(\\{\\{[^}]+\\}\\}|\\[[A-Z_]{2}\\]|&lt;[A-Z_]{2}&gt;|\\[INSERT[^\\]]*\\]|\\[YOUR[^\\]]*\\])&quot;]",
      "resolvedValue": "[&quot;(?i)(\\{\\{[^}]+\\}\\}|\\[[A-Z_]{2}\\]|&lt;[A-Z_]{2}&gt;|\\[INSERT[^\\]]*\\]|\\[YOUR[^\\]]*\\])&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 1,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;(?i)(\\{\\{[^}]+\\}\\}|\\[[A-Z_]{2}\\]|&lt;[A-Z_]{2}&gt;|\\[INSERT[^\\]]*\\]|\\[YOU",
        "precedenceTier": 4
      }
    },
    {
      "file": "BGYY_ValidateDraft.xaml",
      "workflow": "BGYY_ValidateDraft",
      "activityType": "If",
      "propertyName": "Condition",
      "sourceBinding": "attribute-value",
      "originalValue": "[bool_PlaceholderCheckBody = True]",
      "resolvedValue": "[bool_PlaceholderCheckBody = True]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 3,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[bool_PlaceholderCheckBody = True]",
        "precedenceTier": 4
      }
    },
    {
      "file": "BGYY_ValidateDraft.xaml",
      "workflow": "BGYY_ValidateDraft",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "variable",
      "originalValue": "",
      "resolvedValue": "[str_LogMessage]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 7,
      "provenance": {
        "sourceKind": "variable",
        "sourceName": "str_LogMessage",
        "sourceWorkflow": "BGYY_ValidateDraft",
        "precedenceTier": 2
      }
    },
    {
      "file": "BGYY_ValidateDraft.xaml",
      "workflow": "BGYY_ValidateDraft",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "variable",
      "originalValue": "",
      "resolvedValue": "[str_LogMessage]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 8,
      "provenance": {
        "sourceKind": "variable",
        "sourceName": "str_LogMessage",
        "sourceWorkflow": "BGYY_ValidateDraft",
        "precedenceTier": 2
      }
    },
    {
      "file": "BGYY_ValidateDraft.xaml",
      "workflow": "BGYY_ValidateDraft",
      "activityType": "If",
      "propertyName": "Condition",
      "sourceBinding": "attribute-value",
      "originalValue": "[bool_PlaceholderCheckSubject = True]",
      "resolvedValue": "[bool_PlaceholderCheckSubject = True]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 4,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[bool_PlaceholderCheckSubject = True]",
        "precedenceTier": 4
      }
    },
    {
      "file": "BGYY_ValidateDraft.xaml",
      "workflow": "BGYY_ValidateDraft",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "variable",
      "originalValue": "",
      "resolvedValue": "[str_LogMessage]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 9,
      "provenance": {
        "sourceKind": "variable",
        "sourceName": "str_LogMessage",
        "sourceWorkflow": "BGYY_ValidateDraft",
        "precedenceTier": 2
      }
    },
    {
      "file": "BGYY_ValidateDraft.xaml",
      "workflow": "BGYY_ValidateDraft",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "variable",
      "originalValue": "",
      "resolvedValue": "[str_LogMessage]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 10,
      "provenance": {
        "sourceKind": "variable",
        "sourceName": "str_LogMessage",
        "sourceWorkflow": "BGYY_ValidateDraft",
        "precedenceTier": 2
      }
    },
    {
      "file": "BGYY_ValidateDraft.xaml",
      "workflow": "BGYY_ValidateDraft",
      "activityType": "Assign",
      "propertyName": "To",
      "sourceBinding": "variable",
      "originalValue": "[BodyWordArray]",
      "resolvedValue": "[BodyWordArray]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 2,
      "provenance": {
        "sourceKind": "variable",
        "sourceName": "BodyWordArray",
        "sourceWorkflow": "BGYY_ValidateDraft",
        "precedenceTier": 2
      }
    },
    {
      "file": "BGYY_ValidateDraft.xaml",
      "workflow": "BGYY_ValidateDraft",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "[InBody.Trim().Split(New Char(){&quot; &quot;c, Chr(10), Chr(13), Chr(9)}, StringSplitOptions.RemoveEmptyEntries)]",
      "resolvedValue": "[InBody.Trim().Split(New Char(){&quot; &quot;c, Chr(10), Chr(13), Chr(9)}, StringSplitOptions.RemoveEmptyEntries)]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 2,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[InBody.Trim().Split(New Char(){&quot; &quot;c, Chr(10), Chr(13), Chr(9)}, Strin",
        "precedenceTier": 4
      }
    },
    {
      "file": "BGYY_ValidateDraft.xaml",
      "workflow": "BGYY_ValidateDraft",
      "activityType": "Assign",
      "propertyName": "To",
      "sourceBinding": "variable",
      "originalValue": "[int_BodyWordCount]",
      "resolvedValue": "[int_BodyWordCount]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 3,
      "provenance": {
        "sourceKind": "variable",
        "sourceName": "int_BodyWordCount",
        "sourceWorkflow": "BGYY_ValidateDraft",
        "precedenceTier": 2
      }
    },
    {
      "file": "BGYY_ValidateDraft.xaml",
      "workflow": "BGYY_ValidateDraft",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "[BodyWordArray.Length]",
      "resolvedValue": "[BodyWordArray.Length]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 3,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[BodyWordArray.Length]",
        "precedenceTier": 4
      }
    },
    {
      "file": "BGYY_ValidateDraft.xaml",
      "workflow": "BGYY_ValidateDraft",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "&quot;[BGYY_ValidateDraft] Word count check - RunId=&quot; &amp; InRunId &amp; &quot; | FullName=&apos;&quot; &amp; InFullName &amp; &quot;&apos; | WordCount=&quot; &amp; int_BodyWordCount.ToString()",
      "resolvedValue": "&quot;[BGYY_ValidateDraft] Word count check - RunId=&quot; &amp; InRunId &amp; &quot; | FullName=&apos;&quot; &amp; InFullName &amp; &quot;&apos; | WordCount=&quot; &amp; int_BodyWordCount.ToString()",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 11,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "&quot;[BGYY_ValidateDraft] Word count check - RunId=&quot; &amp; InRunId &amp; &",
        "precedenceTier": 4
      }
    },
    {
      "file": "BGYY_ValidateDraft.xaml",
      "workflow": "BGYY_ValidateDraft",
      "activityType": "If",
      "propertyName": "Condition",
      "sourceBinding": "attribute-value",
      "originalValue": "[int_BodyWordCount &lt; 80]",
      "resolvedValue": "[int_BodyWordCount &lt; 80]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 5,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[int_BodyWordCount &lt; 80]",
        "precedenceTier": 4
      }
    },
    {
      "file": "BGYY_ValidateDraft.xaml",
      "workflow": "BGYY_ValidateDraft",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "variable",
      "originalValue": "",
      "resolvedValue": "[str_LogMessage]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 12,
      "provenance": {
        "sourceKind": "variable",
        "sourceName": "str_LogMessage",
        "sourceWorkflow": "BGYY_ValidateDraft",
        "precedenceTier": 2
      }
    },
    {
      "file": "BGYY_ValidateDraft.xaml",
      "workflow": "BGYY_ValidateDraft",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "&quot;[BGYY_ValidateDraft] FAIL word-count-min - RunId=&quot; &amp; InRunId &amp; &quot; | FullName=&apos;&quot; &amp; InFullName &amp; &quot;&apos; | WordCount=&quot; &amp; int_BodyWordCount.ToString()",
      "resolvedValue": "&quot;[BGYY_ValidateDraft] FAIL word-count-min - RunId=&quot; &amp; InRunId &amp; &quot; | FullName=&apos;&quot; &amp; InFullName &amp; &quot;&apos; | WordCount=&quot; &amp; int_BodyWordCount.ToString()",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 13,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "&quot;[BGYY_ValidateDraft] FAIL word-count-min - RunId=&quot; &amp; InRunId &amp",
        "precedenceTier": 4
      }
    },
    {
      "file": "BGYY_ValidateDraft.xaml",
      "workflow": "BGYY_ValidateDraft",
      "activityType": "If",
      "propertyName": "Condition",
      "sourceBinding": "attribute-value",
      "originalValue": "[int_BodyWordCount &gt; 150]",
      "resolvedValue": "[int_BodyWordCount &gt; 150]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 6,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[int_BodyWordCount &gt; 150]",
        "precedenceTier": 4
      }
    },
    {
      "file": "BGYY_ValidateDraft.xaml",
      "workflow": "BGYY_ValidateDraft",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "variable",
      "originalValue": "",
      "resolvedValue": "[str_LogMessage]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 14,
      "provenance": {
        "sourceKind": "variable",
        "sourceName": "str_LogMessage",
        "sourceWorkflow": "BGYY_ValidateDraft",
        "precedenceTier": 2
      }
    },
    {
      "file": "BGYY_ValidateDraft.xaml",
      "workflow": "BGYY_ValidateDraft",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "&quot;[BGYY_ValidateDraft] FAIL word-count-max - RunId=&quot; &amp; InRunId &amp; &quot; | FullName=&apos;&quot; &amp; InFullName &amp; &quot;&apos; | WordCount=&quot; &amp; int_BodyWordCount.ToString()",
      "resolvedValue": "&quot;[BGYY_ValidateDraft] FAIL word-count-max - RunId=&quot; &amp; InRunId &amp; &quot; | FullName=&apos;&quot; &amp; InFullName &amp; &quot;&apos; | WordCount=&quot; &amp; int_BodyWordCount.ToString()",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 15,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "&quot;[BGYY_ValidateDraft] FAIL word-count-max - RunId=&quot; &amp; InRunId &amp",
        "precedenceTier": 4
      }
    },
    {
      "file": "BGYY_ValidateDraft.xaml",
      "workflow": "BGYY_ValidateDraft",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "&quot;[BGYY_ValidateDraft] Downloading banned phrases from BGYY_RunArtifacts/guardrails/banned_phrases.txt - RunId=&quot; &amp; InRunId",
      "resolvedValue": "&quot;[BGYY_ValidateDraft] Downloading banned phrases from BGYY_RunArtifacts/guardrails/banned_phrases.txt - RunId=&quot; &amp; InRunId",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 16,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "&quot;[BGYY_ValidateDraft] Downloading banned phrases from BGYY_RunArtifacts/gua",
        "precedenceTier": 4
      }
    },
    {
      "file": "BGYY_ValidateDraft.xaml",
      "workflow": "BGYY_ValidateDraft",
      "activityType": "ReadStorageText",
      "propertyName": "Path",
      "sourceBinding": "attribute-value",
      "originalValue": "&quot;guardrails/banned_phrases.txt&quot;",
      "resolvedValue": "&quot;guardrails/banned_phrases.txt&quot;",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "&quot;guardrails/banned_phrases.txt&quot;",
        "precedenceTier": 4
      }
    },
    {
      "file": "BGYY_ValidateDraft.xaml",
      "workflow": "BGYY_ValidateDraft",
      "activityType": "ReadStorageText",
      "propertyName": "StorageBucketName",
      "sourceBinding": "attribute-value",
      "originalValue": "&quot;BGYY_RunArtifacts&quot;",
      "resolvedValue": "&quot;BGYY_RunArtifacts&quot;",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "&quot;BGYY_RunArtifacts&quot;",
        "precedenceTier": 4
      }
    },
    {
      "file": "BGYY_ValidateDraft.xaml",
      "workflow": "BGYY_ValidateDraft",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Error in Download banned_phrases.txt from BGYY_RunArtifacts Storage Bucket (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "resolvedValue": "[&quot;Error in Download banned_phrases.txt from BGYY_RunArtifacts Storage Bucket (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 17,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Error in Download banned_phrases.txt from BGYY_RunArtifacts Storage Bucke",
        "precedenceTier": 4
      }
    },
    {
      "file": "BGYY_ValidateDraft.xaml",
      "workflow": "BGYY_ValidateDraft",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "&quot;Error in Download banned_phrases.txt from BGYY_RunArtifacts Storage Bucket: &quot; &amp; exception.Message",
      "resolvedValue": "&quot;Error in Download banned_phrases.txt from BGYY_RunArtifacts Storage Bucket: &quot; &amp; exception.Message",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 18,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "&quot;Error in Download banned_phrases.txt from BGYY_RunArtifacts Storage Bucket",
        "precedenceTier": 4
      }
    },
    {
      "file": "BGYY_ValidateDraft.xaml",
      "workflow": "BGYY_ValidateDraft",
      "activityType": "Assign",
      "propertyName": "To",
      "sourceBinding": "variable",
      "originalValue": "[bool_StorageReadSuccess]",
      "resolvedValue": "[bool_StorageReadSuccess]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 4,
      "provenance": {
        "sourceKind": "variable",
        "sourceName": "bool_StorageReadSuccess",
        "sourceWorkflow": "BGYY_ValidateDraft",
        "precedenceTier": 2
      }
    },
    {
      "file": "BGYY_ValidateDraft.xaml",
      "workflow": "BGYY_ValidateDraft",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "True",
      "resolvedValue": "True",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 4,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "True",
        "precedenceTier": 4
      }
    },
    {
      "file": "BGYY_ValidateDraft.xaml",
      "workflow": "BGYY_ValidateDraft",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "&quot;[BGYY_ValidateDraft] WARN banned-phrases file unavailable from Storage Bucket. Skipping banned-phrase checks. RunId=&quot; &amp; InRunId",
      "resolvedValue": "&quot;[BGYY_ValidateDraft] WARN banned-phrases file unavailable from Storage Bucket. Skipping banned-phrase checks. RunId=&quot; &amp; InRunId",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 19,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "&quot;[BGYY_ValidateDraft] WARN banned-phrases file unavailable from Storage Buc",
        "precedenceTier": 4
      }
    },
    {
      "file": "BGYY_ValidateDraft.xaml",
      "workflow": "BGYY_ValidateDraft",
      "activityType": "If",
      "propertyName": "Condition",
      "sourceBinding": "attribute-value",
      "originalValue": "[bool_StorageReadSuccess = True]",
      "resolvedValue": "[bool_StorageReadSuccess = True]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 7,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[bool_StorageReadSuccess = True]",
        "precedenceTier": 4
      }
    },
    {
      "file": "BGYY_ValidateDraft.xaml",
      "workflow": "BGYY_ValidateDraft",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "variable",
      "originalValue": "",
      "resolvedValue": "[str_LogMessage]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 20,
      "provenance": {
        "sourceKind": "variable",
        "sourceName": "str_LogMessage",
        "sourceWorkflow": "BGYY_ValidateDraft",
        "precedenceTier": 2
      }
    },
    {
      "file": "BGYY_ValidateDraft.xaml",
      "workflow": "BGYY_ValidateDraft",
      "activityType": "Assign",
      "propertyName": "To",
      "sourceBinding": "variable",
      "originalValue": "[BannedPhrasesList]",
      "resolvedValue": "[BannedPhrasesList]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 5,
      "provenance": {
        "sourceKind": "variable",
        "sourceName": "BannedPhrasesList",
        "sourceWorkflow": "BGYY_ValidateDraft",
        "precedenceTier": 2
      }
    },
    {
      "file": "BGYY_ValidateDraft.xaml",
      "workflow": "BGYY_ValidateDraft",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "[str_BannedPhrasesRaw.Split(New Char(){Chr(10), Chr(13)}, StringSplitOptions.RemoveEmptyEntries)]",
      "resolvedValue": "[str_BannedPhrasesRaw.Split(New Char(){Chr(10), Chr(13)}, StringSplitOptions.RemoveEmptyEntries)]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 5,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[str_BannedPhrasesRaw.Split(New Char(){Chr(10), Chr(13)}, StringSplitOptions.Rem",
        "precedenceTier": 4
      }
    },
    {
      "file": "BGYY_ValidateDraft.xaml",
      "workflow": "BGYY_ValidateDraft",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "&quot;[BGYY_ValidateDraft] Loaded &quot; &amp; bannedPhrasesList.Length.ToString() &amp; &quot; banned phrases. Checking body and subject. RunId=&quot; &amp; InRunId",
      "resolvedValue": "&quot;[BGYY_ValidateDraft] Loaded &quot; &amp; bannedPhrasesList.Length.ToString() &amp; &quot; banned phrases. Checking body and subject. RunId=&quot; &amp; InRunId",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 21,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "&quot;[BGYY_ValidateDraft] Loaded &quot; &amp; bannedPhrasesList.Length.ToString",
        "precedenceTier": 4
      }
    },
    {
      "file": "BGYY_ValidateDraft.xaml",
      "workflow": "BGYY_ValidateDraft",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;=== Completed: BGYY_ValidateDraft ===&quot;]",
      "resolvedValue": "[&quot;=== Completed: BGYY_ValidateDraft ===&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 22,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;=== Completed: BGYY_ValidateDraft ===&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "BGYY_SendGmail.xaml",
      "workflow": "BGYY_SendGmail",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "&quot;[BGYY_SendGmail] START | RunId=&quot; &amp; InRunId &amp; &quot; | To=&quot; &amp; InToEmail &amp; &quot; | Subject=&quot; &amp; InSubject &amp; &quot; | DryRun=&quot; &amp; InDryRun.ToString()",
      "resolvedValue": "&quot;[BGYY_SendGmail] START | RunId=&quot; &amp; InRunId &amp; &quot; | To=&quot; &amp; InToEmail &amp; &quot; | Subject=&quot; &amp; InSubject &amp; &quot; | DryRun=&quot; &amp; InDryRun.ToString()",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "&quot;[BGYY_SendGmail] START | RunId=&quot; &amp; InRunId &amp; &quot; | To=&quo",
        "precedenceTier": 4
      }
    },
    {
      "file": "BGYY_SendGmail.xaml",
      "workflow": "BGYY_SendGmail",
      "activityType": "If",
      "propertyName": "Condition",
      "sourceBinding": "attribute-value",
      "originalValue": "[InDryRun = True]",
      "resolvedValue": "[InDryRun = True]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[InDryRun = True]",
        "precedenceTier": 4
      }
    },
    {
      "file": "BGYY_SendGmail.xaml",
      "workflow": "BGYY_SendGmail",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "context-derived",
      "originalValue": "",
      "resolvedValue": "[&quot;[Auto-generated] Log: TODO: Implement Then branch&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 1,
      "provenance": {
        "sourceKind": "context-derived",
        "sourceName": "LogMessage.Message.context-derived",
        "precedenceTier": 7
      }
    },
    {
      "file": "BGYY_SendGmail.xaml",
      "workflow": "BGYY_SendGmail",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "&quot;[BGYY_SendGmail] DRY-RUN mode active — email NOT sent | RunId=&quot; &amp; InRunId &amp; &quot; | To=&quot; &amp; InToEmail",
      "resolvedValue": "&quot;[BGYY_SendGmail] DRY-RUN mode active — email NOT sent | RunId=&quot; &amp; InRunId &amp; &quot; | To=&quot; &amp; InToEmail",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 2,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "&quot;[BGYY_SendGmail] DRY-RUN mode active — email NOT sent | RunId=&quot; &amp;",
        "precedenceTier": 4
      }
    },
    {
      "file": "BGYY_SendGmail.xaml",
      "workflow": "BGYY_SendGmail",
      "activityType": "Assign",
      "propertyName": "To",
      "sourceBinding": "variable",
      "originalValue": "[str_ResolvedMessageId]",
      "resolvedValue": "[str_ResolvedMessageId]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "variable",
        "sourceName": "str_ResolvedMessageId",
        "sourceWorkflow": "BGYY_SendGmail",
        "precedenceTier": 2
      }
    },
    {
      "file": "BGYY_SendGmail.xaml",
      "workflow": "BGYY_SendGmail",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;DRYRUN-&quot; &amp; str_InRunId &amp; &quot;-&quot; &amp; DateTime.UtcNow.ToString(&quot;yyyyMMddHHmmss&quot;)]",
      "resolvedValue": "[&quot;DRYRUN-&quot; &amp; str_InRunId &amp; &quot;-&quot; &amp; DateTime.UtcNow.ToString(&quot;yyyyMMddHHmmss&quot;)]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;DRYRUN-&quot; &amp; str_InRunId &amp; &quot;-&quot; &amp; DateTime.UtcNow",
        "precedenceTier": 4
      }
    },
    {
      "file": "BGYY_SendGmail.xaml",
      "workflow": "BGYY_SendGmail",
      "activityType": "Assign",
      "propertyName": "To",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;OutGmailMessageId&quot;]",
      "resolvedValue": "[&quot;OutGmailMessageId&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 1,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;OutGmailMessageId&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "BGYY_SendGmail.xaml",
      "workflow": "BGYY_SendGmail",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "variable",
      "originalValue": "[str_ResolvedMessageId]",
      "resolvedValue": "[str_ResolvedMessageId]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 1,
      "provenance": {
        "sourceKind": "variable",
        "sourceName": "str_ResolvedMessageId",
        "sourceWorkflow": "BGYY_SendGmail",
        "precedenceTier": 2
      }
    },
    {
      "file": "BGYY_SendGmail.xaml",
      "workflow": "BGYY_SendGmail",
      "activityType": "Assign",
      "propertyName": "To",
      "sourceBinding": "variable",
      "originalValue": "[int_AttemptNumber]",
      "resolvedValue": "[int_AttemptNumber]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 2,
      "provenance": {
        "sourceKind": "variable",
        "sourceName": "int_AttemptNumber",
        "sourceWorkflow": "BGYY_SendGmail",
        "precedenceTier": 2
      }
    },
    {
      "file": "BGYY_SendGmail.xaml",
      "workflow": "BGYY_SendGmail",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "&quot;0&quot;",
      "resolvedValue": "&quot;0&quot;",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 2,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "&quot;0&quot;",
        "precedenceTier": 4
      }
    },
    {
      "file": "BGYY_SendGmail.xaml",
      "workflow": "BGYY_SendGmail",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "context-derived",
      "originalValue": "",
      "resolvedValue": "[&quot;[Auto-generated] Log: TODO: Implement RetryScope body&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 3,
      "provenance": {
        "sourceKind": "context-derived",
        "sourceName": "LogMessage.Message.context-derived",
        "precedenceTier": 7
      }
    },
    {
      "file": "BGYY_SendGmail.xaml",
      "workflow": "BGYY_SendGmail",
      "activityType": "Assign",
      "propertyName": "To",
      "sourceBinding": "variable",
      "originalValue": "[int_AttemptNumber]",
      "resolvedValue": "[int_AttemptNumber]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 3,
      "provenance": {
        "sourceKind": "variable",
        "sourceName": "int_AttemptNumber",
        "sourceWorkflow": "BGYY_SendGmail",
        "precedenceTier": 2
      }
    },
    {
      "file": "BGYY_SendGmail.xaml",
      "workflow": "BGYY_SendGmail",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "[int_AttemptNumber + 1]",
      "resolvedValue": "[int_AttemptNumber + 1]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 3,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[int_AttemptNumber + 1]",
        "precedenceTier": 4
      }
    },
    {
      "file": "BGYY_SendGmail.xaml",
      "workflow": "BGYY_SendGmail",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "&quot;[BGYY_SendGmail] Gmail send attempt &quot; &amp; attemptNumber &amp; &quot;/3 | RunId=&quot; &amp; InRunId &amp; &quot; | To=&quot; &amp; InToEmail",
      "resolvedValue": "&quot;[BGYY_SendGmail] Gmail send attempt &quot; &amp; attemptNumber &amp; &quot;/3 | RunId=&quot; &amp; InRunId &amp; &quot; | To=&quot; &amp; InToEmail",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 4,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "&quot;[BGYY_SendGmail] Gmail send attempt &quot; &amp; attemptNumber &amp; &quot",
        "precedenceTier": 4
      }
    },
    {
      "file": "BGYY_SendGmail.xaml",
      "workflow": "BGYY_SendGmail",
      "activityType": "If",
      "propertyName": "Condition",
      "sourceBinding": "attribute-value",
      "originalValue": "[int_AttemptNumber &gt; 1]",
      "resolvedValue": "[int_AttemptNumber &gt; 1]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 1,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[int_AttemptNumber &gt; 1]",
        "precedenceTier": 4
      }
    },
    {
      "file": "BGYY_SendGmail.xaml",
      "workflow": "BGYY_SendGmail",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "context-derived",
      "originalValue": "",
      "resolvedValue": "[&quot;[Auto-generated] Log: TODO: Implement Then branch&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 5,
      "provenance": {
        "sourceKind": "context-derived",
        "sourceName": "LogMessage.Message.context-derived",
        "precedenceTier": 7
      }
    },
    {
      "file": "BGYY_SendGmail.xaml",
      "workflow": "BGYY_SendGmail",
      "activityType": "Assign",
      "propertyName": "To",
      "sourceBinding": "variable",
      "originalValue": "[int_RetryDelaySeconds]",
      "resolvedValue": "[int_RetryDelaySeconds]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 4,
      "provenance": {
        "sourceKind": "variable",
        "sourceName": "int_RetryDelaySeconds",
        "sourceWorkflow": "BGYY_SendGmail",
        "precedenceTier": 2
      }
    },
    {
      "file": "BGYY_SendGmail.xaml",
      "workflow": "BGYY_SendGmail",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "[If(int_AttemptNumber = 2, 15, 45)]",
      "resolvedValue": "[If(int_AttemptNumber = 2, 15, 45)]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 4,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[If(int_AttemptNumber = 2, 15, 45)]",
        "precedenceTier": 4
      }
    },
    {
      "file": "BGYY_SendGmail.xaml",
      "workflow": "BGYY_SendGmail",
      "activityType": "Delay",
      "propertyName": "Duration",
      "sourceBinding": "attribute-value",
      "originalValue": "TimeSpan.FromSeconds(retryDelaySeconds)",
      "resolvedValue": "TimeSpan.FromSeconds(retryDelaySeconds)",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "TimeSpan.FromSeconds(retryDelaySeconds)",
        "precedenceTier": 4
      }
    },
    {
      "file": "BGYY_SendGmail.xaml",
      "workflow": "BGYY_SendGmail",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[HANDOFF] Activity &apos;Send birthday email via Gmail Integration Service connector&apos; (UiPath.GSuite.Activities.GmailSendMessage) requires developer implementation — missing: Body",
      "resolvedValue": "[HANDOFF] Activity &apos;Send birthday email via Gmail Integration Service connector&apos; (UiPath.GSuite.Activities.GmailSendMessage) requires developer implementation — missing: Body",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 6,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[HANDOFF] Activity &apos;Send birthday email via Gmail Integration Service conne",
        "precedenceTier": 4
      }
    },
    {
      "file": "BGYY_SendGmail.xaml",
      "workflow": "BGYY_SendGmail",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "&quot;Error in Send birthday email via Gmail Integration Service connector: &quot; &amp; exception.Message",
      "resolvedValue": "&quot;Error in Send birthday email via Gmail Integration Service connector: &quot; &amp; exception.Message",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 7,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "&quot;Error in Send birthday email via Gmail Integration Service connector: &quo",
        "precedenceTier": 4
      }
    },
    {
      "file": "BGYY_SendGmail.xaml",
      "workflow": "BGYY_SendGmail",
      "activityType": "Assign",
      "propertyName": "To",
      "sourceBinding": "variable",
      "originalValue": "[bool_GmailSendSuccess]",
      "resolvedValue": "[bool_GmailSendSuccess]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 5,
      "provenance": {
        "sourceKind": "variable",
        "sourceName": "bool_GmailSendSuccess",
        "sourceWorkflow": "BGYY_SendGmail",
        "precedenceTier": 2
      }
    },
    {
      "file": "BGYY_SendGmail.xaml",
      "workflow": "BGYY_SendGmail",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "True",
      "resolvedValue": "True",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 5,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "True",
        "precedenceTier": 4
      }
    },
    {
      "file": "BGYY_SendGmail.xaml",
      "workflow": "BGYY_SendGmail",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "&quot;[BGYY_SendGmail] Email sent successfully on attempt &quot; &amp; attemptNumber &amp; &quot; | RunId=&quot; &amp; InRunId &amp; &quot; | To=&quot; &amp; InToEmail",
      "resolvedValue": "&quot;[BGYY_SendGmail] Email sent successfully on attempt &quot; &amp; attemptNumber &amp; &quot; | RunId=&quot; &amp; InRunId &amp; &quot; | To=&quot; &amp; InToEmail",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 8,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "&quot;[BGYY_SendGmail] Email sent successfully on attempt &quot; &amp; attemptNu",
        "precedenceTier": 4
      }
    },
    {
      "file": "BGYY_SendGmail.xaml",
      "workflow": "BGYY_SendGmail",
      "activityType": "If",
      "propertyName": "Condition",
      "sourceBinding": "attribute-value",
      "originalValue": "[str_ResolvedMessageId = Nothing]",
      "resolvedValue": "[str_ResolvedMessageId = Nothing]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 2,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[str_ResolvedMessageId = Nothing]",
        "precedenceTier": 4
      }
    },
    {
      "file": "BGYY_SendGmail.xaml",
      "workflow": "BGYY_SendGmail",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "context-derived",
      "originalValue": "",
      "resolvedValue": "[&quot;[Auto-generated] Log: TODO: Implement Then branch&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 9,
      "provenance": {
        "sourceKind": "context-derived",
        "sourceName": "LogMessage.Message.context-derived",
        "precedenceTier": 7
      }
    },
    {
      "file": "BGYY_SendGmail.xaml",
      "workflow": "BGYY_SendGmail",
      "activityType": "Assign",
      "propertyName": "To",
      "sourceBinding": "variable",
      "originalValue": "[str_ResolvedMessageId]",
      "resolvedValue": "[str_ResolvedMessageId]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 6,
      "provenance": {
        "sourceKind": "variable",
        "sourceName": "str_ResolvedMessageId",
        "sourceWorkflow": "BGYY_SendGmail",
        "precedenceTier": 2
      }
    },
    {
      "file": "BGYY_SendGmail.xaml",
      "workflow": "BGYY_SendGmail",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;SENT-&quot; &amp; str_InRunId &amp; &quot;-&quot; &amp; DateTime.UtcNow.ToString(&quot;yyyyMMddHHmmssfff&quot;)]",
      "resolvedValue": "[&quot;SENT-&quot; &amp; str_InRunId &amp; &quot;-&quot; &amp; DateTime.UtcNow.ToString(&quot;yyyyMMddHHmmssfff&quot;)]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 6,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;SENT-&quot; &amp; str_InRunId &amp; &quot;-&quot; &amp; DateTime.UtcNow.T",
        "precedenceTier": 4
      }
    },
    {
      "file": "BGYY_SendGmail.xaml",
      "workflow": "BGYY_SendGmail",
      "activityType": "Assign",
      "propertyName": "To",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;OutGmailMessageId&quot;]",
      "resolvedValue": "[&quot;OutGmailMessageId&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 7,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;OutGmailMessageId&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "BGYY_SendGmail.xaml",
      "workflow": "BGYY_SendGmail",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "variable",
      "originalValue": "[str_ResolvedMessageId]",
      "resolvedValue": "[str_ResolvedMessageId]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 7,
      "provenance": {
        "sourceKind": "variable",
        "sourceName": "str_ResolvedMessageId",
        "sourceWorkflow": "BGYY_SendGmail",
        "precedenceTier": 2
      }
    },
    {
      "file": "BGYY_SendGmail.xaml",
      "workflow": "BGYY_SendGmail",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "&quot;[BGYY_SendGmail] OutGmailMessageId=&quot; &amp; OutGmailMessageId &amp; &quot; | RunId=&quot; &amp; InRunId",
      "resolvedValue": "&quot;[BGYY_SendGmail] OutGmailMessageId=&quot; &amp; OutGmailMessageId &amp; &quot; | RunId=&quot; &amp; InRunId",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 10,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "&quot;[BGYY_SendGmail] OutGmailMessageId=&quot; &amp; OutGmailMessageId &amp; &q",
        "precedenceTier": 4
      }
    },
    {
      "file": "BGYY_SendGmail.xaml",
      "workflow": "BGYY_SendGmail",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Error: &quot; &amp; exception.Message]",
      "resolvedValue": "[&quot;Error: &quot; &amp; exception.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 11,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Error: &quot; &amp; exception.Message]",
        "precedenceTier": 4
      }
    },
    {
      "file": "BGYY_SendGmail.xaml",
      "workflow": "BGYY_SendGmail",
      "activityType": "Assign",
      "propertyName": "To",
      "sourceBinding": "variable",
      "originalValue": "[str_ScreenshotPath]",
      "resolvedValue": "[str_ScreenshotPath]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 8,
      "provenance": {
        "sourceKind": "variable",
        "sourceName": "str_ScreenshotPath",
        "sourceWorkflow": "BGYY_SendGmail",
        "precedenceTier": 2
      }
    },
    {
      "file": "BGYY_SendGmail.xaml",
      "workflow": "BGYY_SendGmail",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "[System.IO.Path.Combine(System.IO.Path.GetTempPath(), &quot;BGYY_SendGmail_&quot; &amp; str_InRunId &amp; &quot;_&quot; &amp; DateTime.UtcNow.ToString(&quot;yyyyMMddHHmmss&quot;) &amp; &quot;.png&quot;)]",
      "resolvedValue": "[System.IO.Path.Combine(System.IO.Path.GetTempPath(), &quot;BGYY_SendGmail_&quot; &amp; str_InRunId &amp; &quot;_&quot; &amp; DateTime.UtcNow.ToString(&quot;yyyyMMddHHmmss&quot;) &amp; &quot;.png&quot;)]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 8,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[System.IO.Path.Combine(System.IO.Path.GetTempPath(), &quot;BGYY_SendGmail_&quot",
        "precedenceTier": 4
      }
    },
    {
      "file": "BGYY_SendGmail.xaml",
      "workflow": "BGYY_SendGmail",
      "activityType": "Assign",
      "propertyName": "To",
      "sourceBinding": "variable",
      "originalValue": "[str_ErrorBucketPath]",
      "resolvedValue": "[str_ErrorBucketPath]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 9,
      "provenance": {
        "sourceKind": "variable",
        "sourceName": "str_ErrorBucketPath",
        "sourceWorkflow": "BGYY_SendGmail",
        "precedenceTier": 2
      }
    },
    {
      "file": "BGYY_SendGmail.xaml",
      "workflow": "BGYY_SendGmail",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;runs/&quot; &amp; str_InRunId &amp; &quot;/error/BGYY_SendGmail_&quot; &amp; DateTime.UtcNow.ToString(&quot;yyyyMMddHHmmss&quot;) &amp; &quot;.png&quot;]",
      "resolvedValue": "[&quot;runs/&quot; &amp; str_InRunId &amp; &quot;/error/BGYY_SendGmail_&quot; &amp; DateTime.UtcNow.ToString(&quot;yyyyMMddHHmmss&quot;) &amp; &quot;.png&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 9,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;runs/&quot; &amp; str_InRunId &amp; &quot;/error/BGYY_SendGmail_&quot; &a",
        "precedenceTier": 4
      }
    },
    {
      "file": "BGYY_SendGmail.xaml",
      "workflow": "BGYY_SendGmail",
      "activityType": "UploadStorageFile",
      "propertyName": "Destination",
      "sourceBinding": "variable",
      "originalValue": "[str_ErrorBucketPath]",
      "resolvedValue": "[str_ErrorBucketPath]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "variable",
        "sourceName": "str_ErrorBucketPath",
        "sourceWorkflow": "BGYY_SendGmail",
        "precedenceTier": 2
      }
    },
    {
      "file": "BGYY_SendGmail.xaml",
      "workflow": "BGYY_SendGmail",
      "activityType": "UploadStorageFile",
      "propertyName": "FileResource",
      "sourceBinding": "variable",
      "originalValue": "[str_ScreenshotPath]",
      "resolvedValue": "[str_ScreenshotPath]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "variable",
        "sourceName": "str_ScreenshotPath",
        "sourceWorkflow": "BGYY_SendGmail",
        "precedenceTier": 2
      }
    },
    {
      "file": "BGYY_SendGmail.xaml",
      "workflow": "BGYY_SendGmail",
      "activityType": "UploadStorageFile",
      "propertyName": "Path",
      "sourceBinding": "attribute-value",
      "originalValue": "&quot;errorBucketPath&quot;",
      "resolvedValue": "&quot;errorBucketPath&quot;",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "&quot;errorBucketPath&quot;",
        "precedenceTier": 4
      }
    },
    {
      "file": "BGYY_SendGmail.xaml",
      "workflow": "BGYY_SendGmail",
      "activityType": "UploadStorageFile",
      "propertyName": "StorageBucketName",
      "sourceBinding": "attribute-value",
      "originalValue": "&quot;BGYY_RunArtifacts&quot;",
      "resolvedValue": "&quot;BGYY_RunArtifacts&quot;",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "&quot;BGYY_RunArtifacts&quot;",
        "precedenceTier": 4
      }
    },
    {
      "file": "BGYY_SendGmail.xaml",
      "workflow": "BGYY_SendGmail",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "&quot;[BGYY_SendGmail] PERSISTENT FAILURE — all 3 send attempts failed | RunId=&quot; &amp; InRunId &amp; &quot; | To=&quot; &amp; InToEmail &amp; &quot; | Screenshot=&quot; &amp; errorBucketPath",
      "resolvedValue": "&quot;[BGYY_SendGmail] PERSISTENT FAILURE — all 3 send attempts failed | RunId=&quot; &amp; InRunId &amp; &quot; | To=&quot; &amp; InToEmail &amp; &quot; | Screenshot=&quot; &amp; errorBucketPath",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 12,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "&quot;[BGYY_SendGmail] PERSISTENT FAILURE — all 3 send attempts failed | RunId=&",
        "precedenceTier": 4
      }
    },
    {
      "file": "BGYY_SendGmail.xaml",
      "workflow": "BGYY_SendGmail",
      "activityType": "Assign",
      "propertyName": "To",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;OutGmailMessageId&quot;]",
      "resolvedValue": "[&quot;OutGmailMessageId&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 10,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;OutGmailMessageId&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "BGYY_SendGmail.xaml",
      "workflow": "BGYY_SendGmail",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;&quot;]",
      "resolvedValue": "[&quot;&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 10,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "BGYY_SendGmail.xaml",
      "workflow": "BGYY_SendGmail",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Error in Rethrow persistent send exception to caller for dead-letter handling (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "resolvedValue": "[&quot;Error in Rethrow persistent send exception to caller for dead-letter handling (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 13,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Error in Rethrow persistent send exception to caller for dead-letter hand",
        "precedenceTier": 4
      }
    },
    {
      "file": "BGYY_SendGmail.xaml",
      "workflow": "BGYY_SendGmail",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "&quot;[BGYY_SendGmail] END | RunId=&quot; &amp; InRunId &amp; &quot; | GmailMessageId=&quot; &amp; OutGmailMessageId &amp; &quot; | DryRun=&quot; &amp; InDryRun.ToString()",
      "resolvedValue": "&quot;[BGYY_SendGmail] END | RunId=&quot; &amp; InRunId &amp; &quot; | GmailMessageId=&quot; &amp; OutGmailMessageId &amp; &quot; | DryRun=&quot; &amp; InDryRun.ToString()",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 14,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "&quot;[BGYY_SendGmail] END | RunId=&quot; &amp; InRunId &amp; &quot; | GmailMess",
        "precedenceTier": 4
      }
    },
    {
      "file": "BGYY_SendGmail.xaml",
      "workflow": "BGYY_SendGmail",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;=== Completed: BGYY_SendGmail ===&quot;]",
      "resolvedValue": "[&quot;=== Completed: BGYY_SendGmail ===&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 15,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;=== Completed: BGYY_SendGmail ===&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "BGYY_WriteSendLog.xaml",
      "workflow": "BGYY_WriteSendLog",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "&quot;[BGYY_WriteSendLog][START] RunId=&quot; &amp; InRunId &amp; &quot; | PersonKey=&quot; &amp; InPersonKey &amp; &quot; | Status=&quot; &amp; InStatus &amp; &quot; | SendYear=&quot; &amp; InSendYear.ToString()",
      "resolvedValue": "&quot;[BGYY_WriteSendLog][START] RunId=&quot; &amp; InRunId &amp; &quot; | PersonKey=&quot; &amp; InPersonKey &amp; &quot; | Status=&quot; &amp; InStatus &amp; &quot; | SendYear=&quot; &amp; InSendYear.ToString()",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "&quot;[BGYY_WriteSendLog][START] RunId=&quot; &amp; InRunId &amp; &quot; | Perso",
        "precedenceTier": 4
      }
    },
    {
      "file": "BGYY_WriteSendLog.xaml",
      "workflow": "BGYY_WriteSendLog",
      "activityType": "Assign",
      "propertyName": "To",
      "sourceBinding": "variable",
      "originalValue": "[str_PersonKeyNormalized]",
      "resolvedValue": "[str_PersonKeyNormalized]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "variable",
        "sourceName": "str_PersonKeyNormalized",
        "sourceWorkflow": "BGYY_WriteSendLog",
        "precedenceTier": 2
      }
    },
    {
      "file": "BGYY_WriteSendLog.xaml",
      "workflow": "BGYY_WriteSendLog",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "[InPersonKey.Trim().ToLower()]",
      "resolvedValue": "[InPersonKey.Trim().ToLower()]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[InPersonKey.Trim().ToLower()]",
        "precedenceTier": 4
      }
    },
    {
      "file": "BGYY_WriteSendLog.xaml",
      "workflow": "BGYY_WriteSendLog",
      "activityType": "If",
      "propertyName": "Condition",
      "sourceBinding": "attribute-value",
      "originalValue": "[str_PersonKeyNormalized = &quot;&quot;]",
      "resolvedValue": "[str_PersonKeyNormalized = &quot;&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[str_PersonKeyNormalized = &quot;&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "BGYY_WriteSendLog.xaml",
      "workflow": "BGYY_WriteSendLog",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "context-derived",
      "originalValue": "",
      "resolvedValue": "[&quot;[Auto-generated] Log: TODO: Implement Then branch&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 1,
      "provenance": {
        "sourceKind": "context-derived",
        "sourceName": "LogMessage.Message.context-derived",
        "precedenceTier": 7
      }
    },
    {
      "file": "BGYY_WriteSendLog.xaml",
      "workflow": "BGYY_WriteSendLog",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "&quot;[BGYY_WriteSendLog][SKIP] PersonKey is blank — cannot write send log. RunId=&quot; &amp; InRunId &amp; &quot; | PersonName=&quot; &amp; InPersonName &amp; &quot; | Status=&quot; &amp; InStatus",
      "resolvedValue": "&quot;[BGYY_WriteSendLog][SKIP] PersonKey is blank — cannot write send log. RunId=&quot; &amp; InRunId &amp; &quot; | PersonName=&quot; &amp; InPersonName &amp; &quot; | Status=&quot; &amp; InStatus",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 2,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "&quot;[BGYY_WriteSendLog][SKIP] PersonKey is blank — cannot write send log. RunI",
        "precedenceTier": 4
      }
    },
    {
      "file": "BGYY_WriteSendLog.xaml",
      "workflow": "BGYY_WriteSendLog",
      "activityType": "Assign",
      "propertyName": "To",
      "sourceBinding": "variable",
      "originalValue": "[str_FilterExpression]",
      "resolvedValue": "[str_FilterExpression]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 1,
      "provenance": {
        "sourceKind": "variable",
        "sourceName": "str_FilterExpression",
        "sourceWorkflow": "BGYY_WriteSendLog",
        "precedenceTier": 2
      }
    },
    {
      "file": "BGYY_WriteSendLog.xaml",
      "workflow": "BGYY_WriteSendLog",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;PersonKey eq &apos;&quot; &amp; str_PersonKeyNormalized &amp; &quot;&apos; and SendYear eq &quot; &amp; InSendYear.ToString()]",
      "resolvedValue": "[&quot;PersonKey eq &apos;&quot; &amp; str_PersonKeyNormalized &amp; &quot;&apos; and SendYear eq &quot; &amp; InSendYear.ToString()]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 1,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;PersonKey eq &apos;&quot; &amp; str_PersonKeyNormalized &amp; &quot;&apos",
        "precedenceTier": 4
      }
    },
    {
      "file": "BGYY_WriteSendLog.xaml",
      "workflow": "BGYY_WriteSendLog",
      "activityType": "QueryEntity",
      "propertyName": "EntityType",
      "sourceBinding": "attribute-value",
      "originalValue": "&quot;BGYY_BirthdaySendLog&quot;",
      "resolvedValue": "&quot;BGYY_BirthdaySendLog&quot;",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "&quot;BGYY_BirthdaySendLog&quot;",
        "precedenceTier": 4
      }
    },
    {
      "file": "BGYY_WriteSendLog.xaml",
      "workflow": "BGYY_WriteSendLog",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Error in Query BGYY_BirthdaySendLog for existing record matching PersonKey + SendYear (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "resolvedValue": "[&quot;Error in Query BGYY_BirthdaySendLog for existing record matching PersonKey + SendYear (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 3,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Error in Query BGYY_BirthdaySendLog for existing record matching PersonKe",
        "precedenceTier": 4
      }
    },
    {
      "file": "BGYY_WriteSendLog.xaml",
      "workflow": "BGYY_WriteSendLog",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "&quot;Error in Query BGYY_BirthdaySendLog for existing record matching PersonKey + SendYear: &quot; &amp; exception.Message",
      "resolvedValue": "&quot;Error in Query BGYY_BirthdaySendLog for existing record matching PersonKey + SendYear: &quot; &amp; exception.Message",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 4,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "&quot;Error in Query BGYY_BirthdaySendLog for existing record matching PersonKey",
        "precedenceTier": 4
      }
    },
    {
      "file": "BGYY_WriteSendLog.xaml",
      "workflow": "BGYY_WriteSendLog",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "&quot;[BGYY_WriteSendLog][QUERY] PersonKey=&quot; &amp; personKeyNormalized &amp; &quot; | SendYear=&quot; &amp; InSendYear.ToString() &amp; &quot; | QueryStatus=&quot; &amp; If(existingRecords IsNot Nothing, &quot;RecordsReturned&quot;, &quot;NullResult&quot;)",
      "resolvedValue": "&quot;[BGYY_WriteSendLog][QUERY] PersonKey=&quot; &amp; personKeyNormalized &amp; &quot; | SendYear=&quot; &amp; InSendYear.ToString() &amp; &quot; | QueryStatus=&quot; &amp; If(existingRecords IsNot Nothing, &quot;RecordsReturned&quot;, &quot;NullResult&quot;)",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 5,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "&quot;[BGYY_WriteSendLog][QUERY] PersonKey=&quot; &amp; personKeyNormalized &amp",
        "precedenceTier": 4
      }
    },
    {
      "file": "BGYY_WriteSendLog.xaml",
      "workflow": "BGYY_WriteSendLog",
      "activityType": "If",
      "propertyName": "Condition",
      "sourceBinding": "attribute-value",
      "originalValue": "[obj_ExistingRecords IsNot Nothing]",
      "resolvedValue": "[obj_ExistingRecords IsNot Nothing]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 1,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[obj_ExistingRecords IsNot Nothing]",
        "precedenceTier": 4
      }
    },
    {
      "file": "BGYY_WriteSendLog.xaml",
      "workflow": "BGYY_WriteSendLog",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "context-derived",
      "originalValue": "",
      "resolvedValue": "[&quot;[Auto-generated] Log: TODO: Implement Then branch&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 6,
      "provenance": {
        "sourceKind": "context-derived",
        "sourceName": "LogMessage.Message.context-derived",
        "precedenceTier": 7
      }
    },
    {
      "file": "BGYY_WriteSendLog.xaml",
      "workflow": "BGYY_WriteSendLog",
      "activityType": "Assign",
      "propertyName": "To",
      "sourceBinding": "variable",
      "originalValue": "[bool_RecordExists]",
      "resolvedValue": "[bool_RecordExists]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 2,
      "provenance": {
        "sourceKind": "variable",
        "sourceName": "bool_RecordExists",
        "sourceWorkflow": "BGYY_WriteSendLog",
        "precedenceTier": 2
      }
    },
    {
      "file": "BGYY_WriteSendLog.xaml",
      "workflow": "BGYY_WriteSendLog",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "True",
      "resolvedValue": "True",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 2,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "True",
        "precedenceTier": 4
      }
    },
    {
      "file": "BGYY_WriteSendLog.xaml",
      "workflow": "BGYY_WriteSendLog",
      "activityType": "Assign",
      "propertyName": "To",
      "sourceBinding": "variable",
      "originalValue": "[str_ExistingRecordId]",
      "resolvedValue": "[str_ExistingRecordId]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 3,
      "provenance": {
        "sourceKind": "variable",
        "sourceName": "str_ExistingRecordId",
        "sourceWorkflow": "BGYY_WriteSendLog",
        "precedenceTier": 2
      }
    },
    {
      "file": "BGYY_WriteSendLog.xaml",
      "workflow": "BGYY_WriteSendLog",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "[If(obj_ExistingRecords IsNot Nothing, CStr(CallByName(obj_ExistingRecords, &quot;Id&quot;, CallType.Get)), &quot;&quot;)]",
      "resolvedValue": "[If(obj_ExistingRecords IsNot Nothing, CStr(CallByName(obj_ExistingRecords, &quot;Id&quot;, CallType.Get)), &quot;&quot;)]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 3,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[If(obj_ExistingRecords IsNot Nothing, CStr(CallByName(obj_ExistingRecords, &quo",
        "precedenceTier": 4
      }
    },
    {
      "file": "BGYY_WriteSendLog.xaml",
      "workflow": "BGYY_WriteSendLog",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "&quot;[BGYY_WriteSendLog][UPDATE] Existing record found. RecordId=&quot; &amp; existingRecordId &amp; &quot; | PersonKey=&quot; &amp; personKeyNormalized &amp; &quot; | NewStatus=&quot; &amp; InStatus",
      "resolvedValue": "&quot;[BGYY_WriteSendLog][UPDATE] Existing record found. RecordId=&quot; &amp; existingRecordId &amp; &quot; | PersonKey=&quot; &amp; personKeyNormalized &amp; &quot; | NewStatus=&quot; &amp; InStatus",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 7,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "&quot;[BGYY_WriteSendLog][UPDATE] Existing record found. RecordId=&quot; &amp; e",
        "precedenceTier": 4
      }
    },
    {
      "file": "BGYY_WriteSendLog.xaml",
      "workflow": "BGYY_WriteSendLog",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[HANDOFF] Activity &apos;Update existing BGYY_BirthdaySendLog record with latest outcome fields&apos; (UiPath.DataService.Activities.UpdateEntity) requires developer implementation — missing: EntityObject",
      "resolvedValue": "[HANDOFF] Activity &apos;Update existing BGYY_BirthdaySendLog record with latest outcome fields&apos; (UiPath.DataService.Activities.UpdateEntity) requires developer implementation — missing: EntityObject",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 8,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[HANDOFF] Activity &apos;Update existing BGYY_BirthdaySendLog record with latest",
        "precedenceTier": 4
      }
    },
    {
      "file": "BGYY_WriteSendLog.xaml",
      "workflow": "BGYY_WriteSendLog",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "&quot;Error in Update existing BGYY_BirthdaySendLog record with latest outcome fields: &quot; &amp; exception.Message",
      "resolvedValue": "&quot;Error in Update existing BGYY_BirthdaySendLog record with latest outcome fields: &quot; &amp; exception.Message",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 9,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "&quot;Error in Update existing BGYY_BirthdaySendLog record with latest outcome f",
        "precedenceTier": 4
      }
    },
    {
      "file": "BGYY_WriteSendLog.xaml",
      "workflow": "BGYY_WriteSendLog",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "&quot;[BGYY_WriteSendLog][UPDATE-OK] RecordId=&quot; &amp; existingRecordId &amp; &quot; | Status=&quot; &amp; InStatus &amp; &quot; | PersonName=&quot; &amp; InPersonName &amp; &quot; | RunId=&quot; &amp; InRunId",
      "resolvedValue": "&quot;[BGYY_WriteSendLog][UPDATE-OK] RecordId=&quot; &amp; existingRecordId &amp; &quot; | Status=&quot; &amp; InStatus &amp; &quot; | PersonName=&quot; &amp; InPersonName &amp; &quot; | RunId=&quot; &amp; InRunId",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 10,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "&quot;[BGYY_WriteSendLog][UPDATE-OK] RecordId=&quot; &amp; existingRecordId &amp",
        "precedenceTier": 4
      }
    },
    {
      "file": "BGYY_WriteSendLog.xaml",
      "workflow": "BGYY_WriteSendLog",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "&quot;[BGYY_WriteSendLog][CREATE] No existing record. PersonKey=&quot; &amp; personKeyNormalized &amp; &quot; | Status=&quot; &amp; InStatus &amp; &quot; | RunId=&quot; &amp; InRunId",
      "resolvedValue": "&quot;[BGYY_WriteSendLog][CREATE] No existing record. PersonKey=&quot; &amp; personKeyNormalized &amp; &quot; | Status=&quot; &amp; InStatus &amp; &quot; | RunId=&quot; &amp; InRunId",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 11,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "&quot;[BGYY_WriteSendLog][CREATE] No existing record. PersonKey=&quot; &amp; per",
        "precedenceTier": 4
      }
    },
    {
      "file": "BGYY_WriteSendLog.xaml",
      "workflow": "BGYY_WriteSendLog",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[HANDOFF] Activity &apos;Create new BGYY_BirthdaySendLog record with all audit fields&apos; (UiPath.DataService.Activities.CreateEntity) requires developer implementation — missing: EntityObject",
      "resolvedValue": "[HANDOFF] Activity &apos;Create new BGYY_BirthdaySendLog record with all audit fields&apos; (UiPath.DataService.Activities.CreateEntity) requires developer implementation — missing: EntityObject",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 12,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[HANDOFF] Activity &apos;Create new BGYY_BirthdaySendLog record with all audit f",
        "precedenceTier": 4
      }
    },
    {
      "file": "BGYY_WriteSendLog.xaml",
      "workflow": "BGYY_WriteSendLog",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "&quot;Error in Create new BGYY_BirthdaySendLog record with all audit fields: &quot; &amp; exception.Message",
      "resolvedValue": "&quot;Error in Create new BGYY_BirthdaySendLog record with all audit fields: &quot; &amp; exception.Message",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 13,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "&quot;Error in Create new BGYY_BirthdaySendLog record with all audit fields: &qu",
        "precedenceTier": 4
      }
    },
    {
      "file": "BGYY_WriteSendLog.xaml",
      "workflow": "BGYY_WriteSendLog",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "&quot;[BGYY_WriteSendLog][CREATE-OK] New record created. PersonKey=&quot; &amp; personKeyNormalized &amp; &quot; | Status=&quot; &amp; InStatus &amp; &quot; | PersonName=&quot; &amp; InPersonName &amp; &quot; | RunId=&quot; &amp; InRunId",
      "resolvedValue": "&quot;[BGYY_WriteSendLog][CREATE-OK] New record created. PersonKey=&quot; &amp; personKeyNormalized &amp; &quot; | Status=&quot; &amp; InStatus &amp; &quot; | PersonName=&quot; &amp; InPersonName &amp; &quot; | RunId=&quot; &amp; InRunId",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 14,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "&quot;[BGYY_WriteSendLog][CREATE-OK] New record created. PersonKey=&quot; &amp; ",
        "precedenceTier": 4
      }
    },
    {
      "file": "BGYY_WriteSendLog.xaml",
      "workflow": "BGYY_WriteSendLog",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "context-derived",
      "originalValue": "",
      "resolvedValue": "[&quot;[Auto-generated] Log: Catch handler: log Data Service write failure with full diagnostic context&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 15,
      "provenance": {
        "sourceKind": "context-derived",
        "sourceName": "LogMessage.Message.context-derived",
        "precedenceTier": 7
      }
    },
    {
      "file": "BGYY_WriteSendLog.xaml",
      "workflow": "BGYY_WriteSendLog",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "context-derived",
      "originalValue": "",
      "resolvedValue": "[&quot;[Auto-generated] Log: Log workflow exit with final outcome summary&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 16,
      "provenance": {
        "sourceKind": "context-derived",
        "sourceName": "LogMessage.Message.context-derived",
        "precedenceTier": 7
      }
    },
    {
      "file": "BGYY_WriteSendLog.xaml",
      "workflow": "BGYY_WriteSendLog",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;=== Completed: BGYY_WriteSendLog ===&quot;]",
      "resolvedValue": "[&quot;=== Completed: BGYY_WriteSendLog ===&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 17,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;=== Completed: BGYY_WriteSendLog ===&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "BGYY_CreateReviewTask.xaml",
      "workflow": "BGYY_CreateReviewTask",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "&quot;[BGYY_CreateReviewTask][INFO] Starting review task creation. RunId=&quot; &amp; in_RunId &amp; &quot; | EventId=&quot; &amp; in_EventId &amp; &quot; | FullName=&quot; &amp; in_FullName &amp; &quot; | FailReason=&quot; &amp; in_FailReason",
      "resolvedValue": "&quot;[BGYY_CreateReviewTask][INFO] Starting review task creation. RunId=&quot; &amp; in_RunId &amp; &quot; | EventId=&quot; &amp; in_EventId &amp; &quot; | FullName=&quot; &amp; in_FullName &amp; &quot; | FailReason=&quot; &amp; in_FailReason",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "&quot;[BGYY_CreateReviewTask][INFO] Starting review task creation. RunId=&quot; ",
        "precedenceTier": 4
      }
    },
    {
      "file": "BGYY_CreateReviewTask.xaml",
      "workflow": "BGYY_CreateReviewTask",
      "activityType": "Assign",
      "propertyName": "To",
      "sourceBinding": "variable",
      "originalValue": "[dt_DueByDateTime]",
      "resolvedValue": "[dt_DueByDateTime]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "variable",
        "sourceName": "dt_DueByDateTime",
        "sourceWorkflow": "BGYY_CreateReviewTask",
        "precedenceTier": 2
      }
    },
    {
      "file": "BGYY_CreateReviewTask.xaml",
      "workflow": "BGYY_CreateReviewTask",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "[DateTime.UtcNow.AddHours(2)]",
      "resolvedValue": "[DateTime.UtcNow.AddHours(2)]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[DateTime.UtcNow.AddHours(2)]",
        "precedenceTier": 4
      }
    },
    {
      "file": "BGYY_CreateReviewTask.xaml",
      "workflow": "BGYY_CreateReviewTask",
      "activityType": "Assign",
      "propertyName": "To",
      "sourceBinding": "variable",
      "originalValue": "[str_TaskTitle]",
      "resolvedValue": "[str_TaskTitle]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 1,
      "provenance": {
        "sourceKind": "variable",
        "sourceName": "str_TaskTitle",
        "sourceWorkflow": "BGYY_CreateReviewTask",
        "precedenceTier": 2
      }
    },
    {
      "file": "BGYY_CreateReviewTask.xaml",
      "workflow": "BGYY_CreateReviewTask",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "[\"[BGYY] Birthday Greeting Review – \"\" &amp; in_FullName &amp; \"\" (Run: \"\" &amp; in_RunId &amp; \"\")\"]",
      "resolvedValue": "[\"[BGYY] Birthday Greeting Review – \"\" &amp; in_FullName &amp; \"\" (Run: \"\" &amp; in_RunId &amp; \"\")\"]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 1,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[\"[BGYY] Birthday Greeting Review – \"\" &amp; in_FullName &amp; \"\" (Run: \"\" &amp;",
        "precedenceTier": 4
      }
    },
    {
      "file": "BGYY_CreateReviewTask.xaml",
      "workflow": "BGYY_CreateReviewTask",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[HANDOFF] Activity &apos;Create Action Center Form Task in BGYY_DraftReview Catalog&apos; (UiPath.Persistence.Activities.CreateFormTask) requires developer implementation — missing: TaskTitle",
      "resolvedValue": "[HANDOFF] Activity &apos;Create Action Center Form Task in BGYY_DraftReview Catalog&apos; (UiPath.Persistence.Activities.CreateFormTask) requires developer implementation — missing: TaskTitle",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 1,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[HANDOFF] Activity &apos;Create Action Center Form Task in BGYY_DraftReview Cata",
        "precedenceTier": 4
      }
    },
    {
      "file": "BGYY_CreateReviewTask.xaml",
      "workflow": "BGYY_CreateReviewTask",
      "activityType": "Assign",
      "propertyName": "To",
      "sourceBinding": "variable",
      "originalValue": "[str_CreatedTaskId]",
      "resolvedValue": "[str_CreatedTaskId]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 2,
      "provenance": {
        "sourceKind": "variable",
        "sourceName": "str_CreatedTaskId",
        "sourceWorkflow": "BGYY_CreateReviewTask",
        "precedenceTier": 2
      }
    },
    {
      "file": "BGYY_CreateReviewTask.xaml",
      "workflow": "BGYY_CreateReviewTask",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "[\"[If(obj_FormTaskObject IsNot Nothing, obj_FormTaskObject.ToString(), \"\"\"\")]\"]",
      "resolvedValue": "[\"[If(obj_FormTaskObject IsNot Nothing, obj_FormTaskObject.ToString(), \"\"\"\")]\"]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 2,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[\"[If(obj_FormTaskObject IsNot Nothing, obj_FormTaskObject.ToString(), \"\"\"\")]\"]",
        "precedenceTier": 4
      }
    },
    {
      "file": "BGYY_CreateReviewTask.xaml",
      "workflow": "BGYY_CreateReviewTask",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "&quot;[BGYY_CreateReviewTask][INFO] Action Center task created successfully. TaskId=&quot; &amp; str_CreatedTaskId &amp; &quot; | FullName=&quot; &amp; in_FullName &amp; &quot; | RunId=&quot; &amp; in_RunId",
      "resolvedValue": "&quot;[BGYY_CreateReviewTask][INFO] Action Center task created successfully. TaskId=&quot; &amp; str_CreatedTaskId &amp; &quot; | FullName=&quot; &amp; in_FullName &amp; &quot; | RunId=&quot; &amp; in_RunId",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 2,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "&quot;[BGYY_CreateReviewTask][INFO] Action Center task created successfully. Tas",
        "precedenceTier": 4
      }
    },
    {
      "file": "BGYY_CreateReviewTask.xaml",
      "workflow": "BGYY_CreateReviewTask",
      "activityType": "Assign",
      "propertyName": "To",
      "sourceBinding": "variable",
      "originalValue": "[obj_TaskCreationException]",
      "resolvedValue": "[obj_TaskCreationException]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 3,
      "provenance": {
        "sourceKind": "variable",
        "sourceName": "obj_TaskCreationException",
        "sourceWorkflow": "BGYY_CreateReviewTask",
        "precedenceTier": 2
      }
    },
    {
      "file": "BGYY_CreateReviewTask.xaml",
      "workflow": "BGYY_CreateReviewTask",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "[\"ex_TaskCreation\"]",
      "resolvedValue": "[\"ex_TaskCreation\"]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 3,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[\"ex_TaskCreation\"]",
        "precedenceTier": 4
      }
    },
    {
      "file": "BGYY_CreateReviewTask.xaml",
      "workflow": "BGYY_CreateReviewTask",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "&quot;[BGYY_CreateReviewTask][ERROR] Failed to create Action Center task. FullName=&quot; &amp; in_FullName &amp; &quot; | RunId=&quot; &amp; in_RunId &amp; &quot; | Error=&quot; &amp; ex_TaskCreation.Message",
      "resolvedValue": "&quot;[BGYY_CreateReviewTask][ERROR] Failed to create Action Center task. FullName=&quot; &amp; in_FullName &amp; &quot; | RunId=&quot; &amp; in_RunId &amp; &quot; | Error=&quot; &amp; ex_TaskCreation.Message",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 3,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "&quot;[BGYY_CreateReviewTask][ERROR] Failed to create Action Center task. FullNa",
        "precedenceTier": 4
      }
    },
    {
      "file": "BGYY_CreateReviewTask.xaml",
      "workflow": "BGYY_CreateReviewTask",
      "activityType": "Assign",
      "propertyName": "To",
      "sourceBinding": "variable",
      "originalValue": "[str_CreatedTaskId]",
      "resolvedValue": "[str_CreatedTaskId]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 4,
      "provenance": {
        "sourceKind": "variable",
        "sourceName": "str_CreatedTaskId",
        "sourceWorkflow": "BGYY_CreateReviewTask",
        "precedenceTier": 2
      }
    },
    {
      "file": "BGYY_CreateReviewTask.xaml",
      "workflow": "BGYY_CreateReviewTask",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "\"\"",
      "resolvedValue": "\"\"",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 4,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "\"\"",
        "precedenceTier": 4
      }
    },
    {
      "file": "BGYY_CreateReviewTask.xaml",
      "workflow": "BGYY_CreateReviewTask",
      "activityType": "Assign",
      "propertyName": "To",
      "sourceBinding": "workflowArgument",
      "originalValue": "[out_TaskId]",
      "resolvedValue": "[out_TaskId]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 5,
      "provenance": {
        "sourceKind": "workflowArgument",
        "sourceName": "out_TaskId",
        "sourceWorkflow": "BGYY_CreateReviewTask",
        "precedenceTier": 1
      }
    },
    {
      "file": "BGYY_CreateReviewTask.xaml",
      "workflow": "BGYY_CreateReviewTask",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "variable",
      "originalValue": "[str_CreatedTaskId]",
      "resolvedValue": "[str_CreatedTaskId]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 5,
      "provenance": {
        "sourceKind": "variable",
        "sourceName": "str_CreatedTaskId",
        "sourceWorkflow": "BGYY_CreateReviewTask",
        "precedenceTier": 2
      }
    },
    {
      "file": "BGYY_CreateReviewTask.xaml",
      "workflow": "BGYY_CreateReviewTask",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "&quot;[BGYY_CreateReviewTask][INFO] Review task workflow complete. out_TaskId=&quot; &amp; out_TaskId &amp; &quot; | FullName=&quot; &amp; in_FullName &amp; &quot; | RunId=&quot; &amp; in_RunId",
      "resolvedValue": "&quot;[BGYY_CreateReviewTask][INFO] Review task workflow complete. out_TaskId=&quot; &amp; out_TaskId &amp; &quot; | FullName=&quot; &amp; in_FullName &amp; &quot; | RunId=&quot; &amp; in_RunId",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 4,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "&quot;[BGYY_CreateReviewTask][INFO] Review task workflow complete. out_TaskId=&q",
        "precedenceTier": 4
      }
    },
    {
      "file": "BGYY_CreateReviewTask.xaml",
      "workflow": "BGYY_CreateReviewTask",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;=== Completed: BGYY_CreateReviewTask ===&quot;]",
      "resolvedValue": "[&quot;=== Completed: BGYY_CreateReviewTask ===&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 5,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;=== Completed: BGYY_CreateReviewTask ===&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "BGYY_Main.xaml",
      "workflow": "BGYY_Main",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;STUB: BGYY_Main — Final validation remediation — original XAML had well-formedness violations. Implement the actual logic here.&quot;]",
      "resolvedValue": "[&quot;STUB: BGYY_Main — Final validation remediation — original XAML had well-formedness violations. Implement the actual logic here.&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;STUB: BGYY_Main — Final validation remediation — original XAML had well-f",
        "precedenceTier": 4
      }
    },
    {
      "file": "BGYY_Main.xaml",
      "workflow": "BGYY_Main",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;=== Completed: BGYY_Main ===&quot;]",
      "resolvedValue": "[&quot;=== Completed: BGYY_Main ===&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 1,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;=== Completed: BGYY_Main ===&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "BGYY_Main.xaml",
      "workflow": "BGYY_Main",
      "activityType": "InvokeWorkflowFile",
      "propertyName": "WorkflowFileName",
      "sourceBinding": "attribute-value",
      "originalValue": "BGYY_GetTodaysBirthdays.xaml",
      "resolvedValue": "BGYY_GetTodaysBirthdays.xaml",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "BGYY_GetTodaysBirthdays.xaml",
        "precedenceTier": 4
      }
    },
    {
      "file": "BGYY_Main.xaml",
      "workflow": "BGYY_Main",
      "activityType": "InvokeWorkflowFile",
      "propertyName": "WorkflowFileName",
      "sourceBinding": "attribute-value",
      "originalValue": "BGYY_ResolveRecipient.xaml",
      "resolvedValue": "BGYY_ResolveRecipient.xaml",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 1,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "BGYY_ResolveRecipient.xaml",
        "precedenceTier": 4
      }
    },
    {
      "file": "BGYY_Main.xaml",
      "workflow": "BGYY_Main",
      "activityType": "InvokeWorkflowFile",
      "propertyName": "WorkflowFileName",
      "sourceBinding": "attribute-value",
      "originalValue": "BGYY_CheckDedupe.xaml",
      "resolvedValue": "BGYY_CheckDedupe.xaml",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 2,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "BGYY_CheckDedupe.xaml",
        "precedenceTier": 4
      }
    },
    {
      "file": "BGYY_Main.xaml",
      "workflow": "BGYY_Main",
      "activityType": "InvokeWorkflowFile",
      "propertyName": "WorkflowFileName",
      "sourceBinding": "attribute-value",
      "originalValue": "BGYY_GenerateDraft.xaml",
      "resolvedValue": "BGYY_GenerateDraft.xaml",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 3,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "BGYY_GenerateDraft.xaml",
        "precedenceTier": 4
      }
    },
    {
      "file": "BGYY_Main.xaml",
      "workflow": "BGYY_Main",
      "activityType": "InvokeWorkflowFile",
      "propertyName": "WorkflowFileName",
      "sourceBinding": "attribute-value",
      "originalValue": "BGYY_ValidateDraft.xaml",
      "resolvedValue": "BGYY_ValidateDraft.xaml",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 4,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "BGYY_ValidateDraft.xaml",
        "precedenceTier": 4
      }
    },
    {
      "file": "BGYY_Main.xaml",
      "workflow": "BGYY_Main",
      "activityType": "InvokeWorkflowFile",
      "propertyName": "WorkflowFileName",
      "sourceBinding": "attribute-value",
      "originalValue": "BGYY_SendGmail.xaml",
      "resolvedValue": "BGYY_SendGmail.xaml",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 5,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "BGYY_SendGmail.xaml",
        "precedenceTier": 4
      }
    },
    {
      "file": "BGYY_Main.xaml",
      "workflow": "BGYY_Main",
      "activityType": "InvokeWorkflowFile",
      "propertyName": "WorkflowFileName",
      "sourceBinding": "attribute-value",
      "originalValue": "BGYY_WriteSendLog.xaml",
      "resolvedValue": "BGYY_WriteSendLog.xaml",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 6,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "BGYY_WriteSendLog.xaml",
        "precedenceTier": 4
      }
    },
    {
      "file": "BGYY_Main.xaml",
      "workflow": "BGYY_Main",
      "activityType": "InvokeWorkflowFile",
      "propertyName": "WorkflowFileName",
      "sourceBinding": "attribute-value",
      "originalValue": "BGYY_CreateReviewTask.xaml",
      "resolvedValue": "BGYY_CreateReviewTask.xaml",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 7,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "BGYY_CreateReviewTask.xaml",
        "precedenceTier": 4
      }
    },
    {
      "file": "InitAllSettings.xaml",
      "workflow": "InitAllSettings",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Reading configuration from Config.xlsx...&quot;]",
      "resolvedValue": "[&quot;Reading configuration from Config.xlsx...&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Reading configuration from Config.xlsx...&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "InitAllSettings.xaml",
      "workflow": "InitAllSettings",
      "activityType": "ForEach",
      "propertyName": "Values",
      "sourceBinding": "attribute-value",
      "originalValue": "[dt_Settings.Rows]",
      "resolvedValue": "[dt_Settings.Rows]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[dt_Settings.Rows]",
        "precedenceTier": 4
      }
    },
    {
      "file": "InitAllSettings.xaml",
      "workflow": "InitAllSettings",
      "activityType": "Assign",
      "propertyName": "To",
      "sourceBinding": "attribute-value",
      "originalValue": "[dict_Config(row(&quot;Name&quot;).ToString)]",
      "resolvedValue": "[dict_Config(row(&quot;Name&quot;).ToString)]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[dict_Config(row(&quot;Name&quot;).ToString)]",
        "precedenceTier": 4
      }
    },
    {
      "file": "InitAllSettings.xaml",
      "workflow": "InitAllSettings",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "[row(&quot;Value&quot;)]",
      "resolvedValue": "[row(&quot;Value&quot;)]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[row(&quot;Value&quot;)]",
        "precedenceTier": 4
      }
    },
    {
      "file": "InitAllSettings.xaml",
      "workflow": "InitAllSettings",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Processing setting: &quot; &amp; row(&quot;Name&quot;).ToString]",
      "resolvedValue": "[&quot;Processing setting: &quot; &amp; row(&quot;Name&quot;).ToString]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 1,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Processing setting: &quot; &amp; row(&quot;Name&quot;).ToString]",
        "precedenceTier": 4
      }
    },
    {
      "file": "InitAllSettings.xaml",
      "workflow": "InitAllSettings",
      "activityType": "Assign",
      "propertyName": "To",
      "sourceBinding": "attribute-value",
      "originalValue": "[dict_Config(&quot;BGYY_DryRun&quot;)]",
      "resolvedValue": "[dict_Config(&quot;BGYY_DryRun&quot;)]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 1,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[dict_Config(&quot;BGYY_DryRun&quot;)]",
        "precedenceTier": 4
      }
    },
    {
      "file": "InitAllSettings.xaml",
      "workflow": "InitAllSettings",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "variable",
      "originalValue": "[str_AssetValue]",
      "resolvedValue": "[str_AssetValue]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 1,
      "provenance": {
        "sourceKind": "variable",
        "sourceName": "str_AssetValue",
        "sourceWorkflow": "InitAllSettings",
        "precedenceTier": 2
      }
    },
    {
      "file": "InitAllSettings.xaml",
      "workflow": "InitAllSettings",
      "activityType": "ForEach",
      "propertyName": "Values",
      "sourceBinding": "attribute-value",
      "originalValue": "[dt_Constants.Rows]",
      "resolvedValue": "[dt_Constants.Rows]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 1,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[dt_Constants.Rows]",
        "precedenceTier": 4
      }
    },
    {
      "file": "InitAllSettings.xaml",
      "workflow": "InitAllSettings",
      "activityType": "Assign",
      "propertyName": "To",
      "sourceBinding": "attribute-value",
      "originalValue": "[dict_Config(constRow(&quot;Name&quot;).ToString)]",
      "resolvedValue": "[dict_Config(constRow(&quot;Name&quot;).ToString)]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 2,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[dict_Config(constRow(&quot;Name&quot;).ToString)]",
        "precedenceTier": 4
      }
    },
    {
      "file": "InitAllSettings.xaml",
      "workflow": "InitAllSettings",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "[constRow(&quot;Value&quot;)]",
      "resolvedValue": "[constRow(&quot;Value&quot;)]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 2,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[constRow(&quot;Value&quot;)]",
        "precedenceTier": 4
      }
    },
    {
      "file": "InitAllSettings.xaml",
      "workflow": "InitAllSettings",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Loaded constant: &quot; &amp; constRow(&quot;Name&quot;).ToString]",
      "resolvedValue": "[&quot;Loaded constant: &quot; &amp; constRow(&quot;Name&quot;).ToString]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 2,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Loaded constant: &quot; &amp; constRow(&quot;Name&quot;).ToString]",
        "precedenceTier": 4
      }
    },
    {
      "file": "InitAllSettings.xaml",
      "workflow": "InitAllSettings",
      "activityType": "Assign",
      "propertyName": "To",
      "sourceBinding": "workflowArgument",
      "originalValue": "[out_Config]",
      "resolvedValue": "[out_Config]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 3,
      "provenance": {
        "sourceKind": "workflowArgument",
        "sourceName": "out_Config",
        "sourceWorkflow": "InitAllSettings",
        "precedenceTier": 1
      }
    },
    {
      "file": "InitAllSettings.xaml",
      "workflow": "InitAllSettings",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "variable",
      "originalValue": "[dict_Config]",
      "resolvedValue": "[dict_Config]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 3,
      "provenance": {
        "sourceKind": "variable",
        "sourceName": "dict_Config",
        "sourceWorkflow": "InitAllSettings",
        "precedenceTier": 2
      }
    },
    {
      "file": "InitAllSettings.xaml",
      "workflow": "InitAllSettings",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Configuration loaded successfully&quot;]",
      "resolvedValue": "[&quot;Configuration loaded successfully&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 3,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Configuration loaded successfully&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "InitAllSettings.xaml",
      "workflow": "InitAllSettings",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;=== Completed: InitAllSettings ===&quot;]",
      "resolvedValue": "[&quot;=== Completed: InitAllSettings ===&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 4,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;=== Completed: InitAllSettings ===&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "Main.xaml",
      "workflow": "Main",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;=== Initializing BirthdayGreetingsYY ===&quot;]",
      "resolvedValue": "[&quot;=== Initializing BirthdayGreetingsYY ===&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;=== Initializing BirthdayGreetingsYY ===&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "Main.xaml",
      "workflow": "Main",
      "activityType": "InvokeWorkflowFile",
      "propertyName": "WorkflowFileName",
      "sourceBinding": "attribute-value",
      "originalValue": "Init.xaml",
      "resolvedValue": "Init.xaml",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "Init.xaml",
        "precedenceTier": 4
      }
    },
    {
      "file": "Main.xaml",
      "workflow": "Main",
      "activityType": "Assign",
      "propertyName": "To",
      "sourceBinding": "variable",
      "originalValue": "[bool_SystemReady]",
      "resolvedValue": "[bool_SystemReady]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "variable",
        "sourceName": "bool_SystemReady",
        "sourceWorkflow": "Main",
        "precedenceTier": 2
      }
    },
    {
      "file": "Main.xaml",
      "workflow": "Main",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "True",
      "resolvedValue": "True",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "True",
        "precedenceTier": 4
      }
    },
    {
      "file": "Main.xaml",
      "workflow": "Main",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Initialization complete&quot;]",
      "resolvedValue": "[&quot;Initialization complete&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 1,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Initialization complete&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "Main.xaml",
      "workflow": "Main",
      "activityType": "InvokeWorkflowFile",
      "propertyName": "WorkflowFileName",
      "sourceBinding": "attribute-value",
      "originalValue": "GetTransactionData.xaml",
      "resolvedValue": "GetTransactionData.xaml",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 1,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "GetTransactionData.xaml",
        "precedenceTier": 4
      }
    },
    {
      "file": "Main.xaml",
      "workflow": "Main",
      "activityType": "InvokeWorkflowFile",
      "propertyName": "WorkflowFileName",
      "sourceBinding": "attribute-value",
      "originalValue": "Process.xaml",
      "resolvedValue": "Process.xaml",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 2,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "Process.xaml",
        "precedenceTier": 4
      }
    },
    {
      "file": "Main.xaml",
      "workflow": "Main",
      "activityType": "InvokeWorkflowFile",
      "propertyName": "WorkflowFileName",
      "sourceBinding": "attribute-value",
      "originalValue": "SetTransactionStatus.xaml",
      "resolvedValue": "SetTransactionStatus.xaml",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 3,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "SetTransactionStatus.xaml",
        "precedenceTier": 4
      }
    },
    {
      "file": "Main.xaml",
      "workflow": "Main",
      "activityType": "Assign",
      "propertyName": "To",
      "sourceBinding": "variable",
      "originalValue": "[int_RetryNumber]",
      "resolvedValue": "[int_RetryNumber]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 1,
      "provenance": {
        "sourceKind": "variable",
        "sourceName": "int_RetryNumber",
        "sourceWorkflow": "Main",
        "precedenceTier": 2
      }
    },
    {
      "file": "Main.xaml",
      "workflow": "Main",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "0",
      "resolvedValue": "0",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 1,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "0",
        "precedenceTier": 4
      }
    },
    {
      "file": "Main.xaml",
      "workflow": "Main",
      "activityType": "Assign",
      "propertyName": "To",
      "sourceBinding": "variable",
      "originalValue": "[str_ErrorScreenshotPath]",
      "resolvedValue": "[str_ErrorScreenshotPath]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 2,
      "provenance": {
        "sourceKind": "variable",
        "sourceName": "str_ErrorScreenshotPath",
        "sourceWorkflow": "Main",
        "precedenceTier": 2
      }
    },
    {
      "file": "Main.xaml",
      "workflow": "Main",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "[\"screenshots/error_tx_\" &amp; int_TransactionNumber.ToString &amp; \"_\" &amp; DateTime.Now.ToString(\"yyyyMMdd_HHmmss\") &amp; \".png\"]",
      "resolvedValue": "[\"screenshots/error_tx_\" &amp; int_TransactionNumber.ToString &amp; \"_\" &amp; DateTime.Now.ToString(\"yyyyMMdd_HHmmss\") &amp; \".png\"]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 2,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[\"screenshots/error_tx_\" &amp; int_TransactionNumber.ToString &amp; \"_\" &amp; Da",
        "precedenceTier": 4
      }
    },
    {
      "file": "Main.xaml",
      "workflow": "Main",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot capture failed: &quot; &amp; ssEx.Message]",
      "resolvedValue": "[&quot;Screenshot capture failed: &quot; &amp; ssEx.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 2,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot capture failed: &quot; &amp; ssEx.Message]",
        "precedenceTier": 4
      }
    },
    {
      "file": "Main.xaml",
      "workflow": "Main",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Transaction #&quot; &amp; int_TransactionNumber.ToString &amp; &quot; failed: &quot; &amp; exception.Message &amp; &quot; | Screenshot: &quot; &amp; str_ErrorScreenshotPath]",
      "resolvedValue": "[&quot;Transaction #&quot; &amp; int_TransactionNumber.ToString &amp; &quot; failed: &quot; &amp; exception.Message &amp; &quot; | Screenshot: &quot; &amp; str_ErrorScreenshotPath]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 3,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Transaction #&quot; &amp; int_TransactionNumber.ToString &amp; &quot; fai",
        "precedenceTier": 4
      }
    },
    {
      "file": "Main.xaml",
      "workflow": "Main",
      "activityType": "InvokeWorkflowFile",
      "propertyName": "WorkflowFileName",
      "sourceBinding": "attribute-value",
      "originalValue": "SetTransactionStatus.xaml",
      "resolvedValue": "SetTransactionStatus.xaml",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 4,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "SetTransactionStatus.xaml",
        "precedenceTier": 4
      }
    },
    {
      "file": "Main.xaml",
      "workflow": "Main",
      "activityType": "InvokeWorkflowFile",
      "propertyName": "WorkflowFileName",
      "sourceBinding": "attribute-value",
      "originalValue": "CloseAllApplications.xaml",
      "resolvedValue": "CloseAllApplications.xaml",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 5,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "CloseAllApplications.xaml",
        "precedenceTier": 4
      }
    },
    {
      "file": "Main.xaml",
      "workflow": "Main",
      "activityType": "InvokeWorkflowFile",
      "propertyName": "WorkflowFileName",
      "sourceBinding": "attribute-value",
      "originalValue": "CloseAllApplications.xaml",
      "resolvedValue": "CloseAllApplications.xaml",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 6,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "CloseAllApplications.xaml",
        "precedenceTier": 4
      }
    },
    {
      "file": "Main.xaml",
      "workflow": "Main",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;=== BirthdayGreetingsYY Complete. Transactions processed: &quot; &amp; int_TransactionNumber.ToString]",
      "resolvedValue": "[&quot;=== BirthdayGreetingsYY Complete. Transactions processed: &quot; &amp; int_TransactionNumber.ToString]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 4,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;=== BirthdayGreetingsYY Complete. Transactions processed: &quot; &amp; in",
        "precedenceTier": 4
      }
    },
    {
      "file": "GetTransactionData.xaml",
      "workflow": "GetTransactionData",
      "activityType": "If",
      "propertyName": "Condition",
      "sourceBinding": "attribute-value",
      "originalValue": "[out_TransactionItem IsNot Nothing]",
      "resolvedValue": "[out_TransactionItem IsNot Nothing]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[out_TransactionItem IsNot Nothing]",
        "precedenceTier": 4
      }
    },
    {
      "file": "GetTransactionData.xaml",
      "workflow": "GetTransactionData",
      "activityType": "Assign",
      "propertyName": "To",
      "sourceBinding": "workflowArgument",
      "originalValue": "[io_TransactionNumber]",
      "resolvedValue": "[io_TransactionNumber]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "workflowArgument",
        "sourceName": "io_TransactionNumber",
        "sourceWorkflow": "GetTransactionData",
        "precedenceTier": 1
      }
    },
    {
      "file": "GetTransactionData.xaml",
      "workflow": "GetTransactionData",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "[io_TransactionNumber + 1]",
      "resolvedValue": "[io_TransactionNumber + 1]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[io_TransactionNumber + 1]",
        "precedenceTier": 4
      }
    },
    {
      "file": "GetTransactionData.xaml",
      "workflow": "GetTransactionData",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Processing transaction #&quot; &amp; io_TransactionNumber.ToString &amp; &quot; - Ref: &quot; &amp; out_TransactionItem.Reference]",
      "resolvedValue": "[&quot;Processing transaction #&quot; &amp; io_TransactionNumber.ToString &amp; &quot; - Ref: &quot; &amp; out_TransactionItem.Reference]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Processing transaction #&quot; &amp; io_TransactionNumber.ToString &amp; ",
        "precedenceTier": 4
      }
    },
    {
      "file": "GetTransactionData.xaml",
      "workflow": "GetTransactionData",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;No more transactions in queue&quot;]",
      "resolvedValue": "[&quot;No more transactions in queue&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 1,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;No more transactions in queue&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "GetTransactionData.xaml",
      "workflow": "GetTransactionData",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;=== Completed: GetTransactionData ===&quot;]",
      "resolvedValue": "[&quot;=== Completed: GetTransactionData ===&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 2,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;=== Completed: GetTransactionData ===&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "SetTransactionStatus.xaml",
      "workflow": "SetTransactionStatus",
      "activityType": "If",
      "propertyName": "Condition",
      "sourceBinding": "attribute-value",
      "originalValue": "[in_Status = &quot;Successful&quot;]",
      "resolvedValue": "[in_Status = &quot;Successful&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[in_Status = &quot;Successful&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "SetTransactionStatus.xaml",
      "workflow": "SetTransactionStatus",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Transaction failure screenshot: &quot; &amp; str_ScreenshotPath]",
      "resolvedValue": "[&quot;Transaction failure screenshot: &quot; &amp; str_ScreenshotPath]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Transaction failure screenshot: &quot; &amp; str_ScreenshotPath]",
        "precedenceTier": 4
      }
    },
    {
      "file": "SetTransactionStatus.xaml",
      "workflow": "SetTransactionStatus",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot capture failed: &quot; &amp; ssEx.Message]",
      "resolvedValue": "[&quot;Screenshot capture failed: &quot; &amp; ssEx.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 1,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot capture failed: &quot; &amp; ssEx.Message]",
        "precedenceTier": 4
      }
    },
    {
      "file": "SetTransactionStatus.xaml",
      "workflow": "SetTransactionStatus",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Transaction failed: &quot; &amp; in_ErrorMessage]",
      "resolvedValue": "[&quot;Transaction failed: &quot; &amp; in_ErrorMessage]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 2,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Transaction failed: &quot; &amp; in_ErrorMessage]",
        "precedenceTier": 4
      }
    },
    {
      "file": "SetTransactionStatus.xaml",
      "workflow": "SetTransactionStatus",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;=== Completed: SetTransactionStatus ===&quot;]",
      "resolvedValue": "[&quot;=== Completed: SetTransactionStatus ===&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 3,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;=== Completed: SetTransactionStatus ===&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "CloseAllApplications.xaml",
      "workflow": "CloseAllApplications",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Closing all applications...&quot;]",
      "resolvedValue": "[&quot;Closing all applications...&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Closing all applications...&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "CloseAllApplications.xaml",
      "workflow": "CloseAllApplications",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;All applications closed&quot;]",
      "resolvedValue": "[&quot;All applications closed&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 1,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;All applications closed&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "CloseAllApplications.xaml",
      "workflow": "CloseAllApplications",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Error during cleanup: &quot; &amp; closeEx.Message]",
      "resolvedValue": "[&quot;Error during cleanup: &quot; &amp; closeEx.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 2,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Error during cleanup: &quot; &amp; closeEx.Message]",
        "precedenceTier": 4
      }
    },
    {
      "file": "CloseAllApplications.xaml",
      "workflow": "CloseAllApplications",
      "activityType": "InvokeWorkflowFile",
      "propertyName": "WorkflowFileName",
      "sourceBinding": "attribute-value",
      "originalValue": "KillAllProcesses.xaml",
      "resolvedValue": "KillAllProcesses.xaml",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "KillAllProcesses.xaml",
        "precedenceTier": 4
      }
    },
    {
      "file": "CloseAllApplications.xaml",
      "workflow": "CloseAllApplications",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Kill processes failed: &quot; &amp; killEx.Message]",
      "resolvedValue": "[&quot;Kill processes failed: &quot; &amp; killEx.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 3,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Kill processes failed: &quot; &amp; killEx.Message]",
        "precedenceTier": 4
      }
    },
    {
      "file": "CloseAllApplications.xaml",
      "workflow": "CloseAllApplications",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;=== Completed: CloseAllApplications ===&quot;]",
      "resolvedValue": "[&quot;=== Completed: CloseAllApplications ===&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 4,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;=== Completed: CloseAllApplications ===&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "KillAllProcesses.xaml",
      "workflow": "KillAllProcesses",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Force killing all application processes...&quot;]",
      "resolvedValue": "[&quot;Force killing all application processes...&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Force killing all application processes...&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "KillAllProcesses.xaml",
      "workflow": "KillAllProcesses",
      "activityType": "KillProcess",
      "propertyName": "ProcessName",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;chrome&quot;]",
      "resolvedValue": "[&quot;chrome&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;chrome&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "KillAllProcesses.xaml",
      "workflow": "KillAllProcesses",
      "activityType": "KillProcess",
      "propertyName": "ProcessName",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;iexplore&quot;]",
      "resolvedValue": "[&quot;iexplore&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 1,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;iexplore&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "KillAllProcesses.xaml",
      "workflow": "KillAllProcesses",
      "activityType": "KillProcess",
      "propertyName": "ProcessName",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;EXCEL&quot;]",
      "resolvedValue": "[&quot;EXCEL&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 2,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;EXCEL&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "KillAllProcesses.xaml",
      "workflow": "KillAllProcesses",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;All processes terminated&quot;]",
      "resolvedValue": "[&quot;All processes terminated&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 1,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;All processes terminated&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "KillAllProcesses.xaml",
      "workflow": "KillAllProcesses",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;=== Completed: KillAllProcesses ===&quot;]",
      "resolvedValue": "[&quot;=== Completed: KillAllProcesses ===&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 2,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;=== Completed: KillAllProcesses ===&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "Init.xaml",
      "workflow": "Init",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;=== Initialization Started ===&quot;]",
      "resolvedValue": "[&quot;=== Initialization Started ===&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;=== Initialization Started ===&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "Init.xaml",
      "workflow": "Init",
      "activityType": "InvokeWorkflowFile",
      "propertyName": "WorkflowFileName",
      "sourceBinding": "attribute-value",
      "originalValue": "InitAllSettings.xaml",
      "resolvedValue": "InitAllSettings.xaml",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "InitAllSettings.xaml",
        "precedenceTier": 4
      }
    },
    {
      "file": "Init.xaml",
      "workflow": "Init",
      "activityType": "Assign",
      "propertyName": "To",
      "sourceBinding": "workflowArgument",
      "originalValue": "[io_Config]",
      "resolvedValue": "[io_Config]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "workflowArgument",
        "sourceName": "io_Config",
        "sourceWorkflow": "Init",
        "precedenceTier": 1
      }
    },
    {
      "file": "Init.xaml",
      "workflow": "Init",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "variable",
      "originalValue": "[dict_Config]",
      "resolvedValue": "[dict_Config]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "variable",
        "sourceName": "dict_Config",
        "sourceWorkflow": "Init",
        "precedenceTier": 2
      }
    },
    {
      "file": "Init.xaml",
      "workflow": "Init",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Configuration loaded successfully&quot;]",
      "resolvedValue": "[&quot;Configuration loaded successfully&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 1,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Configuration loaded successfully&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "Init.xaml",
      "workflow": "Init",
      "activityType": "Assign",
      "propertyName": "To",
      "sourceBinding": "variable",
      "originalValue": "[bool_InitSuccess]",
      "resolvedValue": "[bool_InitSuccess]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 1,
      "provenance": {
        "sourceKind": "variable",
        "sourceName": "bool_InitSuccess",
        "sourceWorkflow": "Init",
        "precedenceTier": 2
      }
    },
    {
      "file": "Init.xaml",
      "workflow": "Init",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "True",
      "resolvedValue": "True",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 1,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "True",
        "precedenceTier": 4
      }
    },
    {
      "file": "Init.xaml",
      "workflow": "Init",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Initialization failed: &quot; &amp; exception.Message]",
      "resolvedValue": "[&quot;Initialization failed: &quot; &amp; exception.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 2,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Initialization failed: &quot; &amp; exception.Message]",
        "precedenceTier": 4
      }
    },
    {
      "file": "Init.xaml",
      "workflow": "Init",
      "activityType": "Assign",
      "propertyName": "To",
      "sourceBinding": "variable",
      "originalValue": "[bool_InitSuccess]",
      "resolvedValue": "[bool_InitSuccess]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 2,
      "provenance": {
        "sourceKind": "variable",
        "sourceName": "bool_InitSuccess",
        "sourceWorkflow": "Init",
        "precedenceTier": 2
      }
    },
    {
      "file": "Init.xaml",
      "workflow": "Init",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "False",
      "resolvedValue": "False",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 2,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "False",
        "precedenceTier": 4
      }
    },
    {
      "file": "Init.xaml",
      "workflow": "Init",
      "activityType": "If",
      "propertyName": "Condition",
      "sourceBinding": "variable",
      "originalValue": "[bool_InitSuccess]",
      "resolvedValue": "[bool_InitSuccess]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "variable",
        "sourceName": "bool_InitSuccess",
        "sourceWorkflow": "Init",
        "precedenceTier": 2
      }
    },
    {
      "file": "Init.xaml",
      "workflow": "Init",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;=== Initialization Complete ===&quot;]",
      "resolvedValue": "[&quot;=== Initialization Complete ===&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 3,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;=== Initialization Complete ===&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "Init.xaml",
      "workflow": "Init",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;=== Initialization FAILED — process cannot continue ===&quot;]",
      "resolvedValue": "[&quot;=== Initialization FAILED — process cannot continue ===&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 4,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;=== Initialization FAILED — process cannot continue ===&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "InitAllApplications.xaml",
      "workflow": "InitAllApplications",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Initializing all applications...&quot;]",
      "resolvedValue": "[&quot;Initializing all applications...&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Initializing all applications...&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "InitAllApplications.xaml",
      "workflow": "InitAllApplications",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "context-derived",
      "originalValue": "",
      "resolvedValue": "[&quot;[Auto-generated] Log: Log Init Placeholder&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 1,
      "provenance": {
        "sourceKind": "context-derived",
        "sourceName": "LogMessage.Message.context-derived",
        "precedenceTier": 7
      }
    },
    {
      "file": "InitAllApplications.xaml",
      "workflow": "InitAllApplications",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Application initialization failed: &quot; &amp; initEx.Message]",
      "resolvedValue": "[&quot;Application initialization failed: &quot; &amp; initEx.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 2,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Application initialization failed: &quot; &amp; initEx.Message]",
        "precedenceTier": 4
      }
    },
    {
      "file": "InitAllApplications.xaml",
      "workflow": "InitAllApplications",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;All applications initialized successfully&quot;]",
      "resolvedValue": "[&quot;All applications initialized successfully&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 3,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;All applications initialized successfully&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "InitAllApplications.xaml",
      "workflow": "InitAllApplications",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;=== Completed: Initialize_Applications ===&quot;]",
      "resolvedValue": "[&quot;=== Completed: Initialize_Applications ===&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 4,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;=== Completed: Initialize_Applications ===&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "RetryCurrentTransaction.xaml",
      "workflow": "RetryCurrentTransaction",
      "activityType": "If",
      "propertyName": "Condition",
      "sourceBinding": "attribute-value",
      "originalValue": "[in_QueueRetry]",
      "resolvedValue": "[in_QueueRetry]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[in_QueueRetry]",
        "precedenceTier": 4
      }
    },
    {
      "file": "RetryCurrentTransaction.xaml",
      "workflow": "RetryCurrentTransaction",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Retry managed by Orchestrator Queue — skipping local retry counter&quot;]",
      "resolvedValue": "[&quot;Retry managed by Orchestrator Queue — skipping local retry counter&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Retry managed by Orchestrator Queue — skipping local retry counter&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "RetryCurrentTransaction.xaml",
      "workflow": "RetryCurrentTransaction",
      "activityType": "Assign",
      "propertyName": "To",
      "sourceBinding": "workflowArgument",
      "originalValue": "[out_MaxRetryReached]",
      "resolvedValue": "[out_MaxRetryReached]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "workflowArgument",
        "sourceName": "out_MaxRetryReached",
        "sourceWorkflow": "RetryCurrentTransaction",
        "precedenceTier": 1
      }
    },
    {
      "file": "RetryCurrentTransaction.xaml",
      "workflow": "RetryCurrentTransaction",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "[False]",
      "resolvedValue": "[False]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[False]",
        "precedenceTier": 4
      }
    },
    {
      "file": "RetryCurrentTransaction.xaml",
      "workflow": "RetryCurrentTransaction",
      "activityType": "Assign",
      "propertyName": "To",
      "sourceBinding": "attribute-value",
      "originalValue": "[io_RetryNumber]",
      "resolvedValue": "[io_RetryNumber]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 1,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[io_RetryNumber]",
        "precedenceTier": 4
      }
    },
    {
      "file": "RetryCurrentTransaction.xaml",
      "workflow": "RetryCurrentTransaction",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "[io_RetryNumber + 1]",
      "resolvedValue": "[io_RetryNumber + 1]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 1,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[io_RetryNumber + 1]",
        "precedenceTier": 4
      }
    },
    {
      "file": "RetryCurrentTransaction.xaml",
      "workflow": "RetryCurrentTransaction",
      "activityType": "If",
      "propertyName": "Condition",
      "sourceBinding": "attribute-value",
      "originalValue": "[io_RetryNumber &gt;= int_MaxRetries]",
      "resolvedValue": "[io_RetryNumber &gt;= int_MaxRetries]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 1,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[io_RetryNumber &gt;= int_MaxRetries]",
        "precedenceTier": 4
      }
    },
    {
      "file": "RetryCurrentTransaction.xaml",
      "workflow": "RetryCurrentTransaction",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Maximum retry count reached (&quot; &amp; io_RetryNumber.ToString() &amp; &quot;/&quot; &amp; int_MaxRetries.ToString() &amp; &quot;)&quot;]",
      "resolvedValue": "[&quot;Maximum retry count reached (&quot; &amp; io_RetryNumber.ToString() &amp; &quot;/&quot; &amp; int_MaxRetries.ToString() &amp; &quot;)&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 1,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Maximum retry count reached (&quot; &amp; io_RetryNumber.ToString() &amp;",
        "precedenceTier": 4
      }
    },
    {
      "file": "RetryCurrentTransaction.xaml",
      "workflow": "RetryCurrentTransaction",
      "activityType": "Assign",
      "propertyName": "To",
      "sourceBinding": "workflowArgument",
      "originalValue": "[out_MaxRetryReached]",
      "resolvedValue": "[out_MaxRetryReached]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 2,
      "provenance": {
        "sourceKind": "workflowArgument",
        "sourceName": "out_MaxRetryReached",
        "sourceWorkflow": "RetryCurrentTransaction",
        "precedenceTier": 1
      }
    },
    {
      "file": "RetryCurrentTransaction.xaml",
      "workflow": "RetryCurrentTransaction",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "[True]",
      "resolvedValue": "[True]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 2,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[True]",
        "precedenceTier": 4
      }
    },
    {
      "file": "RetryCurrentTransaction.xaml",
      "workflow": "RetryCurrentTransaction",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Retrying transaction (&quot; &amp; io_RetryNumber.ToString() &amp; &quot;/&quot; &amp; int_MaxRetries.ToString() &amp; &quot;)&quot;]",
      "resolvedValue": "[&quot;Retrying transaction (&quot; &amp; io_RetryNumber.ToString() &amp; &quot;/&quot; &amp; int_MaxRetries.ToString() &amp; &quot;)&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 2,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Retrying transaction (&quot; &amp; io_RetryNumber.ToString() &amp; &quot;",
        "precedenceTier": 4
      }
    },
    {
      "file": "RetryCurrentTransaction.xaml",
      "workflow": "RetryCurrentTransaction",
      "activityType": "Assign",
      "propertyName": "To",
      "sourceBinding": "attribute-value",
      "originalValue": "[io_TransactionNumber]",
      "resolvedValue": "[io_TransactionNumber]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 3,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[io_TransactionNumber]",
        "precedenceTier": 4
      }
    },
    {
      "file": "RetryCurrentTransaction.xaml",
      "workflow": "RetryCurrentTransaction",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "[io_TransactionNumber - 1]",
      "resolvedValue": "[io_TransactionNumber - 1]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 3,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[io_TransactionNumber - 1]",
        "precedenceTier": 4
      }
    },
    {
      "file": "RetryCurrentTransaction.xaml",
      "workflow": "RetryCurrentTransaction",
      "activityType": "Assign",
      "propertyName": "To",
      "sourceBinding": "workflowArgument",
      "originalValue": "[out_MaxRetryReached]",
      "resolvedValue": "[out_MaxRetryReached]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 4,
      "provenance": {
        "sourceKind": "workflowArgument",
        "sourceName": "out_MaxRetryReached",
        "sourceWorkflow": "RetryCurrentTransaction",
        "precedenceTier": 1
      }
    },
    {
      "file": "RetryCurrentTransaction.xaml",
      "workflow": "RetryCurrentTransaction",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "[False]",
      "resolvedValue": "[False]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 4,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[False]",
        "precedenceTier": 4
      }
    },
    {
      "file": "RetryCurrentTransaction.xaml",
      "workflow": "RetryCurrentTransaction",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;=== Completed: RetryCurrentTransaction ===&quot;]",
      "resolvedValue": "[&quot;=== Completed: RetryCurrentTransaction ===&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 3,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;=== Completed: RetryCurrentTransaction ===&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "RetryInit.xaml",
      "workflow": "RetryInit",
      "activityType": "Assign",
      "propertyName": "To",
      "sourceBinding": "workflowArgument",
      "originalValue": "[io_InitRetryCounter]",
      "resolvedValue": "[io_InitRetryCounter]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "workflowArgument",
        "sourceName": "io_InitRetryCounter",
        "sourceWorkflow": "RetryInit",
        "precedenceTier": 1
      }
    },
    {
      "file": "RetryInit.xaml",
      "workflow": "RetryInit",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "[io_InitRetryCounter + 1]",
      "resolvedValue": "[io_InitRetryCounter + 1]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[io_InitRetryCounter + 1]",
        "precedenceTier": 4
      }
    },
    {
      "file": "RetryInit.xaml",
      "workflow": "RetryInit",
      "activityType": "If",
      "propertyName": "Condition",
      "sourceBinding": "attribute-value",
      "originalValue": "[io_InitRetryCounter &lt; int_MaxInitRetries]",
      "resolvedValue": "[io_InitRetryCounter &lt; int_MaxInitRetries]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[io_InitRetryCounter &lt; int_MaxInitRetries]",
        "precedenceTier": 4
      }
    },
    {
      "file": "RetryInit.xaml",
      "workflow": "RetryInit",
      "activityType": "Assign",
      "propertyName": "To",
      "sourceBinding": "workflowArgument",
      "originalValue": "[io_RetryInit]",
      "resolvedValue": "[io_RetryInit]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 1,
      "provenance": {
        "sourceKind": "workflowArgument",
        "sourceName": "io_RetryInit",
        "sourceWorkflow": "RetryInit",
        "precedenceTier": 1
      }
    },
    {
      "file": "RetryInit.xaml",
      "workflow": "RetryInit",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "[True]",
      "resolvedValue": "[True]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 1,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[True]",
        "precedenceTier": 4
      }
    },
    {
      "file": "RetryInit.xaml",
      "workflow": "RetryInit",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Init retry allowed — attempt &quot; &amp; io_InitRetryCounter.ToString() &amp; &quot; of &quot; &amp; int_MaxInitRetries.ToString()]",
      "resolvedValue": "[&quot;Init retry allowed — attempt &quot; &amp; io_InitRetryCounter.ToString() &amp; &quot; of &quot; &amp; int_MaxInitRetries.ToString()]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Init retry allowed — attempt &quot; &amp; io_InitRetryCounter.ToString() ",
        "precedenceTier": 4
      }
    },
    {
      "file": "RetryInit.xaml",
      "workflow": "RetryInit",
      "activityType": "Assign",
      "propertyName": "To",
      "sourceBinding": "workflowArgument",
      "originalValue": "[io_RetryInit]",
      "resolvedValue": "[io_RetryInit]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 2,
      "provenance": {
        "sourceKind": "workflowArgument",
        "sourceName": "io_RetryInit",
        "sourceWorkflow": "RetryInit",
        "precedenceTier": 1
      }
    },
    {
      "file": "RetryInit.xaml",
      "workflow": "RetryInit",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "[False]",
      "resolvedValue": "[False]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 2,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[False]",
        "precedenceTier": 4
      }
    },
    {
      "file": "RetryInit.xaml",
      "workflow": "RetryInit",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Init retries exhausted — max (&quot; &amp; int_MaxInitRetries.ToString() &amp; &quot;) reached&quot;]",
      "resolvedValue": "[&quot;Init retries exhausted — max (&quot; &amp; int_MaxInitRetries.ToString() &amp; &quot;) reached&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 1,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Init retries exhausted — max (&quot; &amp; int_MaxInitRetries.ToString() ",
        "precedenceTier": 4
      }
    },
    {
      "file": "RetryInit.xaml",
      "workflow": "RetryInit",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;=== Completed: RetryInit ===&quot;]",
      "resolvedValue": "[&quot;=== Completed: RetryInit ===&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 2,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;=== Completed: RetryInit ===&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "Process.xaml",
      "workflow": "Process",
      "activityType": "InvokeWorkflowFile",
      "propertyName": "WorkflowFileName",
      "sourceBinding": "attribute-value",
      "originalValue": "BGYY_Main.xaml",
      "resolvedValue": "BGYY_Main.xaml",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "BGYY_Main.xaml",
        "precedenceTier": 4
      }
    },
    {
      "file": "Process.xaml",
      "workflow": "Process",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;=== Completed: Process ===&quot;]",
      "resolvedValue": "[&quot;=== Completed: Process ===&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;=== Completed: Process ===&quot;]",
        "precedenceTier": 4
      }
    }
  ],
  "unresolvedRequiredPropertyDefects": [
    {
      "file": "BGYY_GetTodaysBirthdays.xaml",
      "workflow": "BGYY_GetTodaysBirthdays",
      "activityType": "BuildDataTable",
      "propertyName": "TableInfo",
      "failureReason": "BuildDataTable.TableInfo is not classified — defaulting to unsupported.",
      "originalValue": "",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "InitAllSettings.xaml",
      "workflow": "InitAllSettings",
      "activityType": "ExcelApplicationScope",
      "propertyName": "ExistingWorkbook",
      "failureReason": "ExcelApplicationScope.ExistingWorkbook is not classified — defaulting to unsupported.",
      "originalValue": "",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    }
  ],
  "expressionLoweringFixes": [],
  "expressionLoweringFailures": [],
  "requiredPropertyEnforcementSummary": "393 required property binding(s) resolved; 2 unresolved required property defect(s); 11 classification diagnostic(s)",
  "classificationDiagnostics": [
    {
      "file": "BGYY_GetTodaysBirthdays.xaml",
      "workflow": "BGYY_GetTodaysBirthdays",
      "activityType": "BuildDataTable",
      "propertyName": "TableInfo",
      "classification": "unsupported",
      "approvedEnforcerRecovery": false,
      "message": "BuildDataTable.TableInfo is not classified — defaulting to unsupported.",
      "resolved": false,
      "resolvedValue": null
    },
    {
      "file": "BGYY_SendGmail.xaml",
      "workflow": "BGYY_SendGmail",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "classification": "generator-owned",
      "approvedEnforcerRecovery": true,
      "message": "LogMessage.Message is generator-owned with approved enforcer recovery — context-derived value replaced generic default \"\".",
      "resolved": true,
      "resolvedValue": "[&quot;[Auto-generated] Log: TODO: Implement Then branch&quot;]"
    },
    {
      "file": "BGYY_SendGmail.xaml",
      "workflow": "BGYY_SendGmail",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "classification": "generator-owned",
      "approvedEnforcerRecovery": true,
      "message": "LogMessage.Message is generator-owned with approved enforcer recovery — context-derived value replaced generic default \"\".",
      "resolved": true,
      "resolvedValue": "[&quot;[Auto-generated] Log: TODO: Implement RetryScope body&quot;]"
    },
    {
      "file": "BGYY_SendGmail.xaml",
      "workflow": "BGYY_SendGmail",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "classification": "generator-owned",
      "approvedEnforcerRecovery": true,
      "message": "LogMessage.Message is generator-owned with approved enforcer recovery — context-derived value replaced generic default \"\".",
      "resolved": true,
      "resolvedValue": "[&quot;[Auto-generated] Log: TODO: Implement Then branch&quot;]"
    },
    {
      "file": "BGYY_SendGmail.xaml",
      "workflow": "BGYY_SendGmail",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "classification": "generator-owned",
      "approvedEnforcerRecovery": true,
      "message": "LogMessage.Message is generator-owned with approved enforcer recovery — context-derived value replaced generic default \"\".",
      "resolved": true,
      "resolvedValue": "[&quot;[Auto-generated] Log: TODO: Implement Then branch&quot;]"
    },
    {
      "file": "BGYY_WriteSendLog.xaml",
      "workflow": "BGYY_WriteSendLog",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "classification": "generator-owned",
      "approvedEnforcerRecovery": true,
      "message": "LogMessage.Message is generator-owned with approved enforcer recovery — context-derived value replaced generic default \"\".",
      "resolved": true,
      "resolvedValue": "[&quot;[Auto-generated] Log: TODO: Implement Then branch&quot;]"
    },
    {
      "file": "BGYY_WriteSendLog.xaml",
      "workflow": "BGYY_WriteSendLog",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "classification": "generator-owned",
      "approvedEnforcerRecovery": true,
      "message": "LogMessage.Message is generator-owned with approved enforcer recovery — context-derived value replaced generic default \"\".",
      "resolved": true,
      "resolvedValue": "[&quot;[Auto-generated] Log: TODO: Implement Then branch&quot;]"
    },
    {
      "file": "BGYY_WriteSendLog.xaml",
      "workflow": "BGYY_WriteSendLog",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "classification": "generator-owned",
      "approvedEnforcerRecovery": true,
      "message": "LogMessage.Message is generator-owned with approved enforcer recovery — context-derived value replaced generic default \"\".",
      "resolved": true,
      "resolvedValue": "[&quot;[Auto-generated] Log: Catch handler: log Data Service write failure with full diagnostic context&quot;]"
    },
    {
      "file": "BGYY_WriteSendLog.xaml",
      "workflow": "BGYY_WriteSendLog",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "classification": "generator-owned",
      "approvedEnforcerRecovery": true,
      "message": "LogMessage.Message is generator-owned with approved enforcer recovery — context-derived value replaced generic default \"\".",
      "resolved": true,
      "resolvedValue": "[&quot;[Auto-generated] Log: Log workflow exit with final outcome summary&quot;]"
    },
    {
      "file": "InitAllSettings.xaml",
      "workflow": "InitAllSettings",
      "activityType": "ExcelApplicationScope",
      "propertyName": "ExistingWorkbook",
      "classification": "unsupported",
      "approvedEnforcerRecovery": false,
      "message": "ExcelApplicationScope.ExistingWorkbook is not classified — defaulting to unsupported.",
      "resolved": false,
      "resolvedValue": null
    },
    {
      "file": "InitAllApplications.xaml",
      "workflow": "InitAllApplications",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "classification": "generator-owned",
      "approvedEnforcerRecovery": true,
      "message": "LogMessage.Message is generator-owned with approved enforcer recovery — context-derived value replaced generic default \"\".",
      "resolved": true,
      "resolvedValue": "[&quot;[Auto-generated] Log: Log Init Placeholder&quot;]"
    }
  ],
  "preComplianceGuardPassed": true,
  "preComplianceGuardViolationCount": 0,
  "canonicalizationArchiveParity": [
    {
      "file": "BGYY_GetTodaysBirthdays.xaml",
      "preCanonicalizationHash": "240f26eb6a03bd57f9711f2a0d54865c2e0505f9624489b4f5f3ed0b8669f690",
      "canonicalizedHash": "3d48043c5c37b5817568eba90bbff8e05db4f9c899f8bec8464684868275579d",
      "archivedHash": "3d48043c5c37b5817568eba90bbff8e05db4f9c899f8bec8464684868275579d",
      "identical": true,
      "mutated": true
    },
    {
      "file": "BGYY_ResolveRecipient.xaml",
      "preCanonicalizationHash": "be4d39c5682e2e1e88fc19ae892148d84e2689942b2974f74240eef9ae02e3b8",
      "canonicalizedHash": "99415ae264bbbd4a673bf7816155e36f7b56268ef756c6d460c8a3d317d94458",
      "archivedHash": "99415ae264bbbd4a673bf7816155e36f7b56268ef756c6d460c8a3d317d94458",
      "identical": true,
      "mutated": true
    },
    {
      "file": "BGYY_CheckDedupe.xaml",
      "preCanonicalizationHash": "1373289f3aae0f29585a697c9ed5b15d5586a9eb297990dc676b43c1fd600ed9",
      "canonicalizedHash": "536dfc93c4676cd237f0d29825ae321aa7b79283dcb160ee830d1cd4c1079f16",
      "archivedHash": "536dfc93c4676cd237f0d29825ae321aa7b79283dcb160ee830d1cd4c1079f16",
      "identical": true,
      "mutated": true
    },
    {
      "file": "BGYY_GenerateDraft.xaml",
      "preCanonicalizationHash": "91804522b5d2f95575b1f7d99579d7e65e56217b6d7b0d13dc5e2b8b60bac43d",
      "canonicalizedHash": "bec0a4d26abde52f1d643783f064244463a2f648ebee47160f880c25bc729163",
      "archivedHash": "bec0a4d26abde52f1d643783f064244463a2f648ebee47160f880c25bc729163",
      "identical": true,
      "mutated": true
    },
    {
      "file": "BGYY_ValidateDraft.xaml",
      "preCanonicalizationHash": "06dbc8afb678f1e30c88a4961b6cddd4fa98d90e54e7e0b849fd42066272640e",
      "canonicalizedHash": "e6407a729c1dba98d6167e57c79669ee036016e604a807b31570077a59351250",
      "archivedHash": "e6407a729c1dba98d6167e57c79669ee036016e604a807b31570077a59351250",
      "identical": true,
      "mutated": true
    },
    {
      "file": "BGYY_SendGmail.xaml",
      "preCanonicalizationHash": "b0accbf7c266e627cc3b13fa9fa62d79370990155a713c406d164fd707a5e459",
      "canonicalizedHash": "abff6a1a95dd3b9de9910e68ee65144fb229f0b456f45efcad730d0c1414e2f8",
      "archivedHash": "abff6a1a95dd3b9de9910e68ee65144fb229f0b456f45efcad730d0c1414e2f8",
      "identical": true,
      "mutated": true
    },
    {
      "file": "BGYY_WriteSendLog.xaml",
      "preCanonicalizationHash": "b2c5167eacb60e90958a6bbd0eab24007e1cb4f149fc3c018b64042dff7d3d52",
      "canonicalizedHash": "a32acb7a27127d38cf396adf6f34088146ed531f8f9b00de8f1250392014ec35",
      "archivedHash": "a32acb7a27127d38cf396adf6f34088146ed531f8f9b00de8f1250392014ec35",
      "identical": true,
      "mutated": true
    },
    {
      "file": "BGYY_CreateReviewTask.xaml",
      "preCanonicalizationHash": "796a54739bfd51c575a6f7928b34f81fe97577b2f88a90b3953ba06aa1f6e08c",
      "canonicalizedHash": "796a54739bfd51c575a6f7928b34f81fe97577b2f88a90b3953ba06aa1f6e08c",
      "archivedHash": "796a54739bfd51c575a6f7928b34f81fe97577b2f88a90b3953ba06aa1f6e08c",
      "identical": true,
      "mutated": false
    },
    {
      "file": "BGYY_Main.xaml",
      "preCanonicalizationHash": "244b38af92edfefd4e1687f4f37c0837db3e0aca68eba4273fe4b2462c10b277",
      "canonicalizedHash": "244b38af92edfefd4e1687f4f37c0837db3e0aca68eba4273fe4b2462c10b277",
      "archivedHash": "244b38af92edfefd4e1687f4f37c0837db3e0aca68eba4273fe4b2462c10b277",
      "identical": true,
      "mutated": false
    },
    {
      "file": "InitAllSettings.xaml",
      "preCanonicalizationHash": "e7bee23e7319943b5f7902ad849c8bfa210ad9f6340a9d0ccda071df6d65a490",
      "canonicalizedHash": "e7bee23e7319943b5f7902ad849c8bfa210ad9f6340a9d0ccda071df6d65a490",
      "archivedHash": "e7bee23e7319943b5f7902ad849c8bfa210ad9f6340a9d0ccda071df6d65a490",
      "identical": true,
      "mutated": false
    },
    {
      "file": "Main.xaml",
      "preCanonicalizationHash": "1a6dd9d3fc80874a3d9a791f81c7596d340417bfd52f9b4c671a19aac48d9a4b",
      "canonicalizedHash": "d4f3449872b830d3831785c8438ad72db99f567c8ecf58444dd18e17bedc869e",
      "archivedHash": "d4f3449872b830d3831785c8438ad72db99f567c8ecf58444dd18e17bedc869e",
      "identical": true,
      "mutated": true
    },
    {
      "file": "GetTransactionData.xaml",
      "preCanonicalizationHash": "9fc0b0934e80d781cd088b0381229cf92545d8ffd5a4e713b793a0d7ba36c005",
      "canonicalizedHash": "9fc0b0934e80d781cd088b0381229cf92545d8ffd5a4e713b793a0d7ba36c005",
      "archivedHash": "9fc0b0934e80d781cd088b0381229cf92545d8ffd5a4e713b793a0d7ba36c005",
      "identical": true,
      "mutated": false
    },
    {
      "file": "SetTransactionStatus.xaml",
      "preCanonicalizationHash": "c87cbd3f5316c54df356f2d2a569a58df6669e6af60ed6e199f37eaaf9a8624b",
      "canonicalizedHash": "c87cbd3f5316c54df356f2d2a569a58df6669e6af60ed6e199f37eaaf9a8624b",
      "archivedHash": "c87cbd3f5316c54df356f2d2a569a58df6669e6af60ed6e199f37eaaf9a8624b",
      "identical": true,
      "mutated": false
    },
    {
      "file": "CloseAllApplications.xaml",
      "preCanonicalizationHash": "b1422460d64ed0a4961f1b32e46524dd7e9a62db7898fba1568518e973bca67d",
      "canonicalizedHash": "b1422460d64ed0a4961f1b32e46524dd7e9a62db7898fba1568518e973bca67d",
      "archivedHash": "b1422460d64ed0a4961f1b32e46524dd7e9a62db7898fba1568518e973bca67d",
      "identical": true,
      "mutated": false
    },
    {
      "file": "KillAllProcesses.xaml",
      "preCanonicalizationHash": "9c6ff76dd44c4e2dad41088dc1b0d396920b62d7269b65cd42d270d0aac760cb",
      "canonicalizedHash": "9c6ff76dd44c4e2dad41088dc1b0d396920b62d7269b65cd42d270d0aac760cb",
      "archivedHash": "9c6ff76dd44c4e2dad41088dc1b0d396920b62d7269b65cd42d270d0aac760cb",
      "identical": true,
      "mutated": false
    },
    {
      "file": "Init.xaml",
      "preCanonicalizationHash": "59937d8b7a8ccb91771dafe3273b012e5a2a6cbc0c3850c53980d22d718afc7a",
      "canonicalizedHash": "f44213c3e46b46c17650f45dfdfe51edffafbd18cc4a5294d890a3dd0b9b38bf",
      "archivedHash": "f44213c3e46b46c17650f45dfdfe51edffafbd18cc4a5294d890a3dd0b9b38bf",
      "identical": true,
      "mutated": true
    },
    {
      "file": "InitAllApplications.xaml",
      "preCanonicalizationHash": "5f36dc6bc4b5d25fedaca0bffd9163b903302540d7dc7b4a36a287115312a16f",
      "canonicalizedHash": "b769c321be4fd43fa3cb8ea65de348f95d31ef739494e5f1be7cb81be9018ad8",
      "archivedHash": "b769c321be4fd43fa3cb8ea65de348f95d31ef739494e5f1be7cb81be9018ad8",
      "identical": true,
      "mutated": true
    },
    {
      "file": "RetryCurrentTransaction.xaml",
      "preCanonicalizationHash": "39a5fb546f369dfb49d80e1c32a3f49c55cfd1ac6baf5cf5ae440dae5ddd36b9",
      "canonicalizedHash": "39a5fb546f369dfb49d80e1c32a3f49c55cfd1ac6baf5cf5ae440dae5ddd36b9",
      "archivedHash": "39a5fb546f369dfb49d80e1c32a3f49c55cfd1ac6baf5cf5ae440dae5ddd36b9",
      "identical": true,
      "mutated": false
    },
    {
      "file": "RetryInit.xaml",
      "preCanonicalizationHash": "694f0ead7ed225e69d2248e8534176858cc1c159c406597e10e1a08bd8d7fa4b",
      "canonicalizedHash": "694f0ead7ed225e69d2248e8534176858cc1c159c406597e10e1a08bd8d7fa4b",
      "archivedHash": "694f0ead7ed225e69d2248e8534176858cc1c159c406597e10e1a08bd8d7fa4b",
      "identical": true,
      "mutated": false
    },
    {
      "file": "Process.xaml",
      "preCanonicalizationHash": "121fa3d7ad75a57ff6de9e731c5d9522020a03c67e6d65f1f30264bca799c33b",
      "canonicalizedHash": "121fa3d7ad75a57ff6de9e731c5d9522020a03c67e6d65f1f30264bca799c33b",
      "archivedHash": "121fa3d7ad75a57ff6de9e731c5d9522020a03c67e6d65f1f30264bca799c33b",
      "identical": true,
      "mutated": false
    }
  ],
  "preArchiveStructuralDefects": [
    {
      "file": "BGYY_GenerateDraft.xaml",
      "pattern": "malformed_attribute_quoting",
      "detail": "Malformed attribute quoting detected: Message=\"[&quot;logMessage&quot;]"
    },
    {
      "file": "InitAllSettings.xaml",
      "pattern": "malformed_attribute_quoting",
      "detail": "Malformed attribute quoting detected: AssetName=\"[&quot;BGYY_DryRun&quot;]"
    }
  ],
  "postClassifierMutationTrace": {
    "entries": [
      {
        "stage": "pre-freeze-snapshot",
        "function": "freezeArchiveWorkflows",
        "file": "BGYY_CheckDedupe.xaml",
        "mutationType": "xaml_bytes",
        "preHash": "N/A",
        "postHash": "536dfc93c4676cd237f0d29825ae321aa7b79283dcb160ee830d1cd4c1079f16",
        "allowed": true,
        "reason": "Workflow \"BGYY_CheckDedupe.xaml\" content captured at freeze point (status=non-stub)",
        "changedBytes": false,
        "changedStatus": false,
        "enforcementAction": "none"
      },
      {
        "stage": "pre-freeze-snapshot",
        "function": "freezeArchiveWorkflows",
        "file": "BGYY_CreateReviewTask.xaml",
        "mutationType": "xaml_bytes",
        "preHash": "N/A",
        "postHash": "796a54739bfd51c575a6f7928b34f81fe97577b2f88a90b3953ba06aa1f6e08c",
        "allowed": true,
        "reason": "Workflow \"BGYY_CreateReviewTask.xaml\" content captured at freeze point (status=non-stub)",
        "changedBytes": false,
        "changedStatus": false,
        "enforcementAction": "none"
      },
      {
        "stage": "pre-freeze-snapshot",
        "function": "freezeArchiveWorkflows",
        "file": "BGYY_GenerateDraft.xaml",
        "mutationType": "xaml_bytes",
        "preHash": "N/A",
        "postHash": "bec0a4d26abde52f1d643783f064244463a2f648ebee47160f880c25bc729163",
        "allowed": true,
        "reason": "Workflow \"BGYY_GenerateDraft.xaml\" content captured at freeze point (status=non-stub)",
        "changedBytes": false,
        "changedStatus": false,
        "enforcementAction": "none"
      },
      {
        "stage": "pre-freeze-snapshot",
        "function": "freezeArchiveWorkflows",
        "file": "BGYY_GetTodaysBirthdays.xaml",
        "mutationType": "xaml_bytes",
        "preHash": "N/A",
        "postHash": "3d48043c5c37b5817568eba90bbff8e05db4f9c899f8bec8464684868275579d",
        "allowed": true,
        "reason": "Workflow \"BGYY_GetTodaysBirthdays.xaml\" content captured at freeze point (status=non-stub)",
        "changedBytes": false,
        "changedStatus": false,
        "enforcementAction": "none"
      },
      {
        "stage": "pre-freeze-snapshot",
        "function": "freezeArchiveWorkflows",
        "file": "BGYY_Main.xaml",
        "mutationType": "xaml_bytes",
        "preHash": "N/A",
        "postHash": "244b38af92edfefd4e1687f4f37c0837db3e0aca68eba4273fe4b2462c10b277",
        "allowed": true,
        "reason": "Workflow \"BGYY_Main.xaml\" content captured at freeze point (status=stub)",
        "changedBytes": false,
        "changedStatus": false,
        "enforcementAction": "none"
      },
      {
        "stage": "pre-freeze-snapshot",
        "function": "freezeArchiveWorkflows",
        "file": "BGYY_ResolveRecipient.xaml",
        "mutationType": "xaml_bytes",
        "preHash": "N/A",
        "postHash": "99415ae264bbbd4a673bf7816155e36f7b56268ef756c6d460c8a3d317d94458",
        "allowed": true,
        "reason": "Workflow \"BGYY_ResolveRecipient.xaml\" content captured at freeze point (status=non-stub)",
        "changedBytes": false,
        "changedStatus": false,
        "enforcementAction": "none"
      },
      {
        "stage": "pre-freeze-snapshot",
        "function": "freezeArchiveWorkflows",
        "file": "BGYY_SendGmail.xaml",
        "mutationType": "xaml_bytes",
        "preHash": "N/A",
        "postHash": "abff6a1a95dd3b9de9910e68ee65144fb229f0b456f45efcad730d0c1414e2f8",
        "allowed": true,
        "reason": "Workflow \"BGYY_SendGmail.xaml\" content captured at freeze point (status=non-stub)",
        "changedBytes": false,
        "changedStatus": false,
        "enforcementAction": "none"
      },
      {
        "stage": "pre-freeze-snapshot",
        "function": "freezeArchiveWorkflows",
        "file": "BGYY_ValidateDraft.xaml",
        "mutationType": "xaml_bytes",
        "preHash": "N/A",
        "postHash": "e6407a729c1dba98d6167e57c79669ee036016e604a807b31570077a59351250",
        "allowed": true,
        "reason": "Workflow \"BGYY_ValidateDraft.xaml\" content captured at freeze point (status=non-stub)",
        "changedBytes": false,
        "changedStatus": false,
        "enforcementAction": "none"
      },
      {
        "stage": "pre-freeze-snapshot",
        "function": "freezeArchiveWorkflows",
        "file": "BGYY_WriteSendLog.xaml",
        "mutationType": "xaml_bytes",
        "preHash": "N/A",
        "postHash": "a32acb7a27127d38cf396adf6f34088146ed531f8f9b00de8f1250392014ec35",
        "allowed": true,
        "reason": "Workflow \"BGYY_WriteSendLog.xaml\" content captured at freeze point (status=non-stub)",
        "changedBytes": false,
        "changedStatus": false,
        "enforcementAction": "none"
      },
      {
        "stage": "pre-freeze-snapshot",
        "function": "freezeArchiveWorkflows",
        "file": "CloseAllApplications.xaml",
        "mutationType": "xaml_bytes",
        "preHash": "N/A",
        "postHash": "b1422460d64ed0a4961f1b32e46524dd7e9a62db7898fba1568518e973bca67d",
        "allowed": true,
        "reason": "Workflow \"CloseAllApplications.xaml\" content captured at freeze point (status=non-stub)",
        "changedBytes": false,
        "changedStatus": false,
        "enforcementAction": "none"
      },
      {
        "stage": "pre-freeze-snapshot",
        "function": "freezeArchiveWorkflows",
        "file": "GetTransactionData.xaml",
        "mutationType": "xaml_bytes",
        "preHash": "N/A",
        "postHash": "9fc0b0934e80d781cd088b0381229cf92545d8ffd5a4e713b793a0d7ba36c005",
        "allowed": true,
        "reason": "Workflow \"GetTransactionData.xaml\" content captured at freeze point (status=non-stub)",
        "changedBytes": false,
        "changedStatus": false,
        "enforcementAction": "none"
      },
      {
        "stage": "pre-freeze-snapshot",
        "function": "freezeArchiveWorkflows",
        "file": "Init.xaml",
        "mutationType": "xaml_bytes",
        "preHash": "N/A",
        "postHash": "f44213c3e46b46c17650f45dfdfe51edffafbd18cc4a5294d890a3dd0b9b38bf",
        "allowed": true,
        "reason": "Workflow \"Init.xaml\" content captured at freeze point (status=non-stub)",
        "changedBytes": false,
        "changedStatus": false,
        "enforcementAction": "none"
      },
      {
        "stage": "pre-freeze-snapshot",
        "function": "freezeArchiveWorkflows",
        "file": "InitAllApplications.xaml",
        "mutationType": "xaml_bytes",
        "preHash": "N/A",
        "postHash": "b769c321be4fd43fa3cb8ea65de348f95d31ef739494e5f1be7cb81be9018ad8",
        "allowed": true,
        "reason": "Workflow \"InitAllApplications.xaml\" content captured at freeze point (status=non-stub)",
        "changedBytes": false,
        "changedStatus": false,
        "enforcementAction": "none"
      },
      {
        "stage": "pre-freeze-snapshot",
        "function": "freezeArchiveWorkflows",
        "file": "InitAllSettings.xaml",
        "mutationType": "xaml_bytes",
        "preHash": "N/A",
        "postHash": "e7bee23e7319943b5f7902ad849c8bfa210ad9f6340a9d0ccda071df6d65a490",
        "allowed": true,
        "reason": "Workflow \"InitAllSettings.xaml\" content captured at freeze point (status=non-stub)",
        "changedBytes": false,
        "changedStatus": false,
        "enforcementAction": "none"
      },
      {
        "stage": "pre-freeze-snapshot",
        "function": "freezeArchiveWorkflows",
        "file": "KillAllProcesses.xaml",
        "mutationType": "xaml_bytes",
        "preHash": "N/A",
        "postHash": "9c6ff76dd44c4e2dad41088dc1b0d396920b62d7269b65cd42d270d0aac760cb",
        "allowed": true,
        "reason": "Workflow \"KillAllProcesses.xaml\" content captured at freeze point (status=non-stub)",
        "changedBytes": false,
        "changedStatus": false,
        "enforcementAction": "none"
      },
      {
        "stage": "pre-freeze-snapshot",
        "function": "freezeArchiveWorkflows",
        "file": "Main.xaml",
        "mutationType": "xaml_bytes",
        "preHash": "N/A",
        "postHash": "d4f3449872b830d3831785c8438ad72db99f567c8ecf58444dd18e17bedc869e",
        "allowed": true,
        "reason": "Workflow \"Main.xaml\" content captured at freeze point (status=non-stub)",
        "changedBytes": false,
        "changedStatus": false,
        "enforcementAction": "none"
      },
      {
        "stage": "pre-freeze-snapshot",
        "function": "freezeArchiveWorkflows",
        "file": "Process.xaml",
        "mutationType": "xaml_bytes",
        "preHash": "N/A",
        "postHash": "121fa3d7ad75a57ff6de9e731c5d9522020a03c67e6d65f1f30264bca799c33b",
        "allowed": true,
        "reason": "Workflow \"Process.xaml\" content captured at freeze point (status=non-stub)",
        "changedBytes": false,
        "changedStatus": false,
        "enforcementAction": "none"
      },
      {
        "stage": "pre-freeze-snapshot",
        "function": "freezeArchiveWorkflows",
        "file": "RetryCurrentTransaction.xaml",
        "mutationType": "xaml_bytes",
        "preHash": "N/A",
        "postHash": "39a5fb546f369dfb49d80e1c32a3f49c55cfd1ac6baf5cf5ae440dae5ddd36b9",
        "allowed": true,
        "reason": "Workflow \"RetryCurrentTransaction.xaml\" content captured at freeze point (status=non-stub)",
        "changedBytes": false,
        "changedStatus": false,
        "enforcementAction": "none"
      },
      {
        "stage": "pre-freeze-snapshot",
        "function": "freezeArchiveWorkflows",
        "file": "RetryInit.xaml",
        "mutationType": "xaml_bytes",
        "preHash": "N/A",
        "postHash": "694f0ead7ed225e69d2248e8534176858cc1c159c406597e10e1a08bd8d7fa4b",
        "allowed": true,
        "reason": "Workflow \"RetryInit.xaml\" content captured at freeze point (status=non-stub)",
        "changedBytes": false,
        "changedStatus": false,
        "enforcementAction": "none"
      },
      {
        "stage": "pre-freeze-snapshot",
        "function": "freezeArchiveWorkflows",
        "file": "SetTransactionStatus.xaml",
        "mutationType": "xaml_bytes",
        "preHash": "N/A",
        "postHash": "c87cbd3f5316c54df356f2d2a569a58df6669e6af60ed6e199f37eaaf9a8624b",
        "allowed": true,
        "reason": "Workflow \"SetTransactionStatus.xaml\" content captured at freeze point (status=non-stub)",
        "changedBytes": false,
        "changedStatus": false,
        "enforcementAction": "none"
      }
    ],
    "perFileMutationCounts": {
      "BGYY_CheckDedupe.xaml": 1,
      "BGYY_CreateReviewTask.xaml": 1,
      "BGYY_GenerateDraft.xaml": 1,
      "BGYY_GetTodaysBirthdays.xaml": 1,
      "BGYY_Main.xaml": 1,
      "BGYY_ResolveRecipient.xaml": 1,
      "BGYY_SendGmail.xaml": 1,
      "BGYY_ValidateDraft.xaml": 1,
      "BGYY_WriteSendLog.xaml": 1,
      "CloseAllApplications.xaml": 1,
      "GetTransactionData.xaml": 1,
      "Init.xaml": 1,
      "InitAllApplications.xaml": 1,
      "InitAllSettings.xaml": 1,
      "KillAllProcesses.xaml": 1,
      "Main.xaml": 1,
      "Process.xaml": 1,
      "RetryCurrentTransaction.xaml": 1,
      "RetryInit.xaml": 1,
      "SetTransactionStatus.xaml": 1
    },
    "filesChangedAfterFreeze": [],
    "summary": {
      "totalAttemptedMutations": 20,
      "totalBlockedMutations": 0,
      "totalAllowedPreFreezeMutations": 20,
      "totalPostFreezeViolations": 0,
      "totalUnexpectedPostFreezeMutations": 0,
      "filesChangedAfterFreeze": 0
    }
  },
  "postFreezeMutationTrace": {
    "entries": [
      {
        "stage": "pre-freeze-snapshot",
        "function": "freezeArchiveWorkflows",
        "file": "BGYY_CheckDedupe.xaml",
        "mutationType": "xaml_bytes",
        "preHash": "N/A",
        "postHash": "536dfc93c4676cd237f0d29825ae321aa7b79283dcb160ee830d1cd4c1079f16",
        "allowed": true,
        "reason": "Workflow \"BGYY_CheckDedupe.xaml\" content captured at freeze point (status=non-stub)",
        "changedBytes": false,
        "changedStatus": false,
        "enforcementAction": "none"
      },
      {
        "stage": "pre-freeze-snapshot",
        "function": "freezeArchiveWorkflows",
        "file": "BGYY_CreateReviewTask.xaml",
        "mutationType": "xaml_bytes",
        "preHash": "N/A",
        "postHash": "796a54739bfd51c575a6f7928b34f81fe97577b2f88a90b3953ba06aa1f6e08c",
        "allowed": true,
        "reason": "Workflow \"BGYY_CreateReviewTask.xaml\" content captured at freeze point (status=non-stub)",
        "changedBytes": false,
        "changedStatus": false,
        "enforcementAction": "none"
      },
      {
        "stage": "pre-freeze-snapshot",
        "function": "freezeArchiveWorkflows",
        "file": "BGYY_GenerateDraft.xaml",
        "mutationType": "xaml_bytes",
        "preHash": "N/A",
        "postHash": "bec0a4d26abde52f1d643783f064244463a2f648ebee47160f880c25bc729163",
        "allowed": true,
        "reason": "Workflow \"BGYY_GenerateDraft.xaml\" content captured at freeze point (status=non-stub)",
        "changedBytes": false,
        "changedStatus": false,
        "enforcementAction": "none"
      },
      {
        "stage": "pre-freeze-snapshot",
        "function": "freezeArchiveWorkflows",
        "file": "BGYY_GetTodaysBirthdays.xaml",
        "mutationType": "xaml_bytes",
        "preHash": "N/A",
        "postHash": "3d48043c5c37b5817568eba90bbff8e05db4f9c899f8bec8464684868275579d",
        "allowed": true,
        "reason": "Workflow \"BGYY_GetTodaysBirthdays.xaml\" content captured at freeze point (status=non-stub)",
        "changedBytes": false,
        "changedStatus": false,
        "enforcementAction": "none"
      },
      {
        "stage": "pre-freeze-snapshot",
        "function": "freezeArchiveWorkflows",
        "file": "BGYY_Main.xaml",
        "mutationType": "xaml_bytes",
        "preHash": "N/A",
        "postHash": "244b38af92edfefd4e1687f4f37c0837db3e0aca68eba4273fe4b2462c10b277",
        "allowed": true,
        "reason": "Workflow \"BGYY_Main.xaml\" content captured at freeze point (status=stub)",
        "changedBytes": false,
        "changedStatus": false,
        "enforcementAction": "none"
      },
      {
        "stage": "pre-freeze-snapshot",
        "function": "freezeArchiveWorkflows",
        "file": "BGYY_ResolveRecipient.xaml",
        "mutationType": "xaml_bytes",
        "preHash": "N/A",
        "postHash": "99415ae264bbbd4a673bf7816155e36f7b56268ef756c6d460c8a3d317d94458",
        "allowed": true,
        "reason": "Workflow \"BGYY_ResolveRecipient.xaml\" content captured at freeze point (status=non-stub)",
        "changedBytes": false,
        "changedStatus": false,
        "enforcementAction": "none"
      },
      {
        "stage": "pre-freeze-snapshot",
        "function": "freezeArchiveWorkflows",
        "file": "BGYY_SendGmail.xaml",
        "mutationType": "xaml_bytes",
        "preHash": "N/A",
        "postHash": "abff6a1a95dd3b9de9910e68ee65144fb229f0b456f45efcad730d0c1414e2f8",
        "allowed": true,
        "reason": "Workflow \"BGYY_SendGmail.xaml\" content captured at freeze point (status=non-stub)",
        "changedBytes": false,
        "changedStatus": false,
        "enforcementAction": "none"
      },
      {
        "stage": "pre-freeze-snapshot",
        "function": "freezeArchiveWorkflows",
        "file": "BGYY_ValidateDraft.xaml",
        "mutationType": "xaml_bytes",
        "preHash": "N/A",
        "postHash": "e6407a729c1dba98d6167e57c79669ee036016e604a807b31570077a59351250",
        "allowed": true,
        "reason": "Workflow \"BGYY_ValidateDraft.xaml\" content captured at freeze point (status=non-stub)",
        "changedBytes": false,
        "changedStatus": false,
        "enforcementAction": "none"
      },
      {
        "stage": "pre-freeze-snapshot",
        "function": "freezeArchiveWorkflows",
        "file": "BGYY_WriteSendLog.xaml",
        "mutationType": "xaml_bytes",
        "preHash": "N/A",
        "postHash": "a32acb7a27127d38cf396adf6f34088146ed531f8f9b00de8f1250392014ec35",
        "allowed": true,
        "reason": "Workflow \"BGYY_WriteSendLog.xaml\" content captured at freeze point (status=non-stub)",
        "changedBytes": false,
        "changedStatus": false,
        "enforcementAction": "none"
      },
      {
        "stage": "pre-freeze-snapshot",
        "function": "freezeArchiveWorkflows",
        "file": "CloseAllApplications.xaml",
        "mutationType": "xaml_bytes",
        "preHash": "N/A",
        "postHash": "b1422460d64ed0a4961f1b32e46524dd7e9a62db7898fba1568518e973bca67d",
        "allowed": true,
        "reason": "Workflow \"CloseAllApplications.xaml\" content captured at freeze point (status=non-stub)",
        "changedBytes": false,
        "changedStatus": false,
        "enforcementAction": "none"
      },
      {
        "stage": "pre-freeze-snapshot",
        "function": "freezeArchiveWorkflows",
        "file": "GetTransactionData.xaml",
        "mutationType": "xaml_bytes",
        "preHash": "N/A",
        "postHash": "9fc0b0934e80d781cd088b0381229cf92545d8ffd5a4e713b793a0d7ba36c005",
        "allowed": true,
        "reason": "Workflow \"GetTransactionData.xaml\" content captured at freeze point (status=non-stub)",
        "changedBytes": false,
        "changedStatus": false,
        "enforcementAction": "none"
      },
      {
        "stage": "pre-freeze-snapshot",
        "function": "freezeArchiveWorkflows",
        "file": "Init.xaml",
        "mutationType": "xaml_bytes",
        "preHash": "N/A",
        "postHash": "f44213c3e46b46c17650f45dfdfe51edffafbd18cc4a5294d890a3dd0b9b38bf",
        "allowed": true,
        "reason": "Workflow \"Init.xaml\" content captured at freeze point (status=non-stub)",
        "changedBytes": false,
        "changedStatus": false,
        "enforcementAction": "none"
      },
      {
        "stage": "pre-freeze-snapshot",
        "function": "freezeArchiveWorkflows",
        "file": "InitAllApplications.xaml",
        "mutationType": "xaml_bytes",
        "preHash": "N/A",
        "postHash": "b769c321be4fd43fa3cb8ea65de348f95d31ef739494e5f1be7cb81be9018ad8",
        "allowed": true,
        "reason": "Workflow \"InitAllApplications.xaml\" content captured at freeze point (status=non-stub)",
        "changedBytes": false,
        "changedStatus": false,
        "enforcementAction": "none"
      },
      {
        "stage": "pre-freeze-snapshot",
        "function": "freezeArchiveWorkflows",
        "file": "InitAllSettings.xaml",
        "mutationType": "xaml_bytes",
        "preHash": "N/A",
        "postHash": "e7bee23e7319943b5f7902ad849c8bfa210ad9f6340a9d0ccda071df6d65a490",
        "allowed": true,
        "reason": "Workflow \"InitAllSettings.xaml\" content captured at freeze point (status=non-stub)",
        "changedBytes": false,
        "changedStatus": false,
        "enforcementAction": "none"
      },
      {
        "stage": "pre-freeze-snapshot",
        "function": "freezeArchiveWorkflows",
        "file": "KillAllProcesses.xaml",
        "mutationType": "xaml_bytes",
        "preHash": "N/A",
        "postHash": "9c6ff76dd44c4e2dad41088dc1b0d396920b62d7269b65cd42d270d0aac760cb",
        "allowed": true,
        "reason": "Workflow \"KillAllProcesses.xaml\" content captured at freeze point (status=non-stub)",
        "changedBytes": false,
        "changedStatus": false,
        "enforcementAction": "none"
      },
      {
        "stage": "pre-freeze-snapshot",
        "function": "freezeArchiveWorkflows",
        "file": "Main.xaml",
        "mutationType": "xaml_bytes",
        "preHash": "N/A",
        "postHash": "d4f3449872b830d3831785c8438ad72db99f567c8ecf58444dd18e17bedc869e",
        "allowed": true,
        "reason": "Workflow \"Main.xaml\" content captured at freeze point (status=non-stub)",
        "changedBytes": false,
        "changedStatus": false,
        "enforcementAction": "none"
      },
      {
        "stage": "pre-freeze-snapshot",
        "function": "freezeArchiveWorkflows",
        "file": "Process.xaml",
        "mutationType": "xaml_bytes",
        "preHash": "N/A",
        "postHash": "121fa3d7ad75a57ff6de9e731c5d9522020a03c67e6d65f1f30264bca799c33b",
        "allowed": true,
        "reason": "Workflow \"Process.xaml\" content captured at freeze point (status=non-stub)",
        "changedBytes": false,
        "changedStatus": false,
        "enforcementAction": "none"
      },
      {
        "stage": "pre-freeze-snapshot",
        "function": "freezeArchiveWorkflows",
        "file": "RetryCurrentTransaction.xaml",
        "mutationType": "xaml_bytes",
        "preHash": "N/A",
        "postHash": "39a5fb546f369dfb49d80e1c32a3f49c55cfd1ac6baf5cf5ae440dae5ddd36b9",
        "allowed": true,
        "reason": "Workflow \"RetryCurrentTransaction.xaml\" content captured at freeze point (status=non-stub)",
        "changedBytes": false,
        "changedStatus": false,
        "enforcementAction": "none"
      },
      {
        "stage": "pre-freeze-snapshot",
        "function": "freezeArchiveWorkflows",
        "file": "RetryInit.xaml",
        "mutationType": "xaml_bytes",
        "preHash": "N/A",
        "postHash": "694f0ead7ed225e69d2248e8534176858cc1c159c406597e10e1a08bd8d7fa4b",
        "allowed": true,
        "reason": "Workflow \"RetryInit.xaml\" content captured at freeze point (status=non-stub)",
        "changedBytes": false,
        "changedStatus": false,
        "enforcementAction": "none"
      },
      {
        "stage": "pre-freeze-snapshot",
        "function": "freezeArchiveWorkflows",
        "file": "SetTransactionStatus.xaml",
        "mutationType": "xaml_bytes",
        "preHash": "N/A",
        "postHash": "c87cbd3f5316c54df356f2d2a569a58df6669e6af60ed6e199f37eaaf9a8624b",
        "allowed": true,
        "reason": "Workflow \"SetTransactionStatus.xaml\" content captured at freeze point (status=non-stub)",
        "changedBytes": false,
        "changedStatus": false,
        "enforcementAction": "none"
      }
    ],
    "perFileMutationCounts": {
      "BGYY_CheckDedupe.xaml": 1,
      "BGYY_CreateReviewTask.xaml": 1,
      "BGYY_GenerateDraft.xaml": 1,
      "BGYY_GetTodaysBirthdays.xaml": 1,
      "BGYY_Main.xaml": 1,
      "BGYY_ResolveRecipient.xaml": 1,
      "BGYY_SendGmail.xaml": 1,
      "BGYY_ValidateDraft.xaml": 1,
      "BGYY_WriteSendLog.xaml": 1,
      "CloseAllApplications.xaml": 1,
      "GetTransactionData.xaml": 1,
      "Init.xaml": 1,
      "InitAllApplications.xaml": 1,
      "InitAllSettings.xaml": 1,
      "KillAllProcesses.xaml": 1,
      "Main.xaml": 1,
      "Process.xaml": 1,
      "RetryCurrentTransaction.xaml": 1,
      "RetryInit.xaml": 1,
      "SetTransactionStatus.xaml": 1
    },
    "filesChangedAfterFreeze": [],
    "summary": {
      "totalAttemptedMutations": 20,
      "totalBlockedMutations": 0,
      "totalAllowedPreFreezeMutations": 20,
      "totalPostFreezeViolations": 0,
      "totalUnexpectedPostFreezeMutations": 0,
      "filesChangedAfterFreeze": 0
    }
  },
  "workflowAutoWiringDiagnostics": {
    "entries": [
      {
        "file": "BGYY_GetTodaysBirthdays.xaml",
        "generated": true,
        "required": true,
        "workflowRole": "decomposed_child",
        "classificationSourceRule": "generated_by_spec_decomposition",
        "requiredByPath": "Main.xaml → BGYY_GetTodaysBirthdays.xaml → spec-decomposition:BGYY_GetTodaysBirthdays",
        "expectedCaller": "BGYY_GetTodaysBirthdays.xaml",
        "callerCandidates": [
          "BGYY_GetTodaysBirthdays.xaml",
          "BGYY_Main.xaml",
          "Process.xaml",
          "Main.xaml"
        ],
        "invokeAttempted": true,
        "invokeSucceeded": true,
        "invokeSkippedReason": null,
        "invokeRejectedReason": null,
        "actualCallers": [
          "BGYY_GetTodaysBirthdays.xaml",
          "BGYY_Main.xaml"
        ],
        "reachableFromMain": true,
        "finalWiringStatus": "wired_and_reachable",
        "rootCauseCategory": "none",
        "remediationHint": null,
        "unwiredSeverity": "none"
      },
      {
        "file": "BGYY_ResolveRecipient.xaml",
        "generated": true,
        "required": true,
        "workflowRole": "decomposed_child",
        "classificationSourceRule": "generated_by_spec_decomposition",
        "requiredByPath": "Main.xaml → BGYY_GetTodaysBirthdays.xaml → spec-decomposition:BGYY_ResolveRecipient",
        "expectedCaller": "BGYY_GetTodaysBirthdays.xaml",
        "callerCandidates": [
          "BGYY_GetTodaysBirthdays.xaml",
          "BGYY_Main.xaml",
          "Process.xaml",
          "Main.xaml"
        ],
        "invokeAttempted": true,
        "invokeSucceeded": true,
        "invokeSkippedReason": null,
        "invokeRejectedReason": null,
        "actualCallers": [
          "BGYY_GetTodaysBirthdays.xaml",
          "BGYY_Main.xaml"
        ],
        "reachableFromMain": true,
        "finalWiringStatus": "wired_and_reachable",
        "rootCauseCategory": "none",
        "remediationHint": null,
        "unwiredSeverity": "none"
      },
      {
        "file": "BGYY_CheckDedupe.xaml",
        "generated": true,
        "required": true,
        "workflowRole": "decomposed_child",
        "classificationSourceRule": "generated_by_spec_decomposition",
        "requiredByPath": "Main.xaml → BGYY_GetTodaysBirthdays.xaml → spec-decomposition:BGYY_CheckDedupe",
        "expectedCaller": "BGYY_GetTodaysBirthdays.xaml",
        "callerCandidates": [
          "BGYY_GetTodaysBirthdays.xaml",
          "BGYY_Main.xaml",
          "Process.xaml",
          "Main.xaml"
        ],
        "invokeAttempted": true,
        "invokeSucceeded": true,
        "invokeSkippedReason": null,
        "invokeRejectedReason": null,
        "actualCallers": [
          "BGYY_GetTodaysBirthdays.xaml",
          "BGYY_Main.xaml"
        ],
        "reachableFromMain": true,
        "finalWiringStatus": "wired_and_reachable",
        "rootCauseCategory": "none",
        "remediationHint": null,
        "unwiredSeverity": "none"
      },
      {
        "file": "BGYY_GenerateDraft.xaml",
        "generated": true,
        "required": true,
        "workflowRole": "decomposed_child",
        "classificationSourceRule": "generated_by_spec_decomposition",
        "requiredByPath": "Main.xaml → BGYY_GetTodaysBirthdays.xaml → spec-decomposition:BGYY_GenerateDraft",
        "expectedCaller": "BGYY_GetTodaysBirthdays.xaml",
        "callerCandidates": [
          "BGYY_GetTodaysBirthdays.xaml",
          "Process.xaml",
          "Main.xaml"
        ],
        "invokeAttempted": true,
        "invokeSucceeded": true,
        "invokeSkippedReason": null,
        "invokeRejectedReason": null,
        "actualCallers": [
          "BGYY_GetTodaysBirthdays.xaml"
        ],
        "reachableFromMain": true,
        "finalWiringStatus": "wired_and_reachable",
        "rootCauseCategory": "none",
        "remediationHint": null,
        "unwiredSeverity": "none"
      },
      {
        "file": "BGYY_ValidateDraft.xaml",
        "generated": true,
        "required": true,
        "workflowRole": "decomposed_child",
        "classificationSourceRule": "generated_by_spec_decomposition",
        "requiredByPath": "Main.xaml → BGYY_GetTodaysBirthdays.xaml → spec-decomposition:BGYY_ValidateDraft",
        "expectedCaller": "BGYY_GetTodaysBirthdays.xaml",
        "callerCandidates": [
          "BGYY_GetTodaysBirthdays.xaml",
          "Process.xaml",
          "Main.xaml"
        ],
        "invokeAttempted": true,
        "invokeSucceeded": true,
        "invokeSkippedReason": null,
        "invokeRejectedReason": null,
        "actualCallers": [
          "BGYY_GetTodaysBirthdays.xaml"
        ],
        "reachableFromMain": true,
        "finalWiringStatus": "wired_and_reachable",
        "rootCauseCategory": "none",
        "remediationHint": null,
        "unwiredSeverity": "none"
      },
      {
        "file": "BGYY_SendGmail.xaml",
        "generated": true,
        "required": true,
        "workflowRole": "decomposed_child",
        "classificationSourceRule": "generated_by_spec_decomposition",
        "requiredByPath": "Main.xaml → BGYY_GetTodaysBirthdays.xaml → spec-decomposition:BGYY_SendGmail",
        "expectedCaller": "BGYY_GetTodaysBirthdays.xaml",
        "callerCandidates": [
          "BGYY_GetTodaysBirthdays.xaml",
          "Process.xaml",
          "Main.xaml"
        ],
        "invokeAttempted": true,
        "invokeSucceeded": true,
        "invokeSkippedReason": null,
        "invokeRejectedReason": null,
        "actualCallers": [
          "BGYY_GetTodaysBirthdays.xaml"
        ],
        "reachableFromMain": true,
        "finalWiringStatus": "wired_and_reachable",
        "rootCauseCategory": "none",
        "remediationHint": null,
        "unwiredSeverity": "none"
      },
      {
        "file": "BGYY_WriteSendLog.xaml",
        "generated": true,
        "required": true,
        "workflowRole": "decomposed_child",
        "classificationSourceRule": "generated_by_spec_decomposition",
        "requiredByPath": "Main.xaml → BGYY_GetTodaysBirthdays.xaml → spec-decomposition:BGYY_WriteSendLog",
        "expectedCaller": "BGYY_GetTodaysBirthdays.xaml",
        "callerCandidates": [
          "BGYY_GetTodaysBirthdays.xaml",
          "BGYY_Main.xaml",
          "Process.xaml",
          "Main.xaml"
        ],
        "invokeAttempted": true,
        "invokeSucceeded": true,
        "invokeSkippedReason": null,
        "invokeRejectedReason": null,
        "actualCallers": [
          "BGYY_GetTodaysBirthdays.xaml",
          "BGYY_Main.xaml",
          "BGYY_Main.xaml"
        ],
        "reachableFromMain": true,
        "finalWiringStatus": "wired_and_reachable",
        "rootCauseCategory": "none",
        "remediationHint": null,
        "unwiredSeverity": "none"
      },
      {
        "file": "BGYY_CreateReviewTask.xaml",
        "generated": true,
        "required": true,
        "workflowRole": "decomposed_child",
        "classificationSourceRule": "generated_by_spec_decomposition",
        "requiredByPath": "Main.xaml → BGYY_GetTodaysBirthdays.xaml → spec-decomposition:BGYY_CreateReviewTask",
        "expectedCaller": "BGYY_GetTodaysBirthdays.xaml",
        "callerCandidates": [
          "BGYY_GetTodaysBirthdays.xaml",
          "BGYY_Main.xaml",
          "Process.xaml",
          "Main.xaml"
        ],
        "invokeAttempted": true,
        "invokeSucceeded": true,
        "invokeSkippedReason": null,
        "invokeRejectedReason": null,
        "actualCallers": [
          "BGYY_GetTodaysBirthdays.xaml",
          "BGYY_Main.xaml"
        ],
        "reachableFromMain": true,
        "finalWiringStatus": "wired_and_reachable",
        "rootCauseCategory": "none",
        "remediationHint": null,
        "unwiredSeverity": "none"
      },
      {
        "file": "BGYY_Main.xaml",
        "generated": true,
        "required": true,
        "workflowRole": "decomposed_child",
        "classificationSourceRule": "generated_by_spec_decomposition",
        "requiredByPath": "Main.xaml → BGYY_GetTodaysBirthdays.xaml → spec-decomposition:BGYY_Main",
        "expectedCaller": "BGYY_GetTodaysBirthdays.xaml",
        "callerCandidates": [
          "BGYY_GetTodaysBirthdays.xaml",
          "Process.xaml",
          "Main.xaml"
        ],
        "invokeAttempted": true,
        "invokeSucceeded": true,
        "invokeSkippedReason": null,
        "invokeRejectedReason": null,
        "actualCallers": [
          "BGYY_GetTodaysBirthdays.xaml",
          "Process.xaml"
        ],
        "reachableFromMain": true,
        "finalWiringStatus": "wired_and_reachable",
        "rootCauseCategory": "none",
        "remediationHint": null,
        "unwiredSeverity": "none"
      },
      {
        "file": "InitAllSettings.xaml",
        "generated": false,
        "required": false,
        "workflowRole": "helper",
        "classificationSourceRule": "infrastructure_basename_match:initallsettings",
        "unwiredSeverity": "none",
        "requiredByPath": "infrastructure utility",
        "expectedCaller": "Main.xaml",
        "callerCandidates": [
          "Main.xaml"
        ],
        "invokeAttempted": false,
        "invokeSucceeded": false,
        "invokeSkippedReason": "infrastructure file — always included",
        "invokeRejectedReason": null,
        "actualCallers": [
          "BGYY_GetTodaysBirthdays.xaml",
          "Init.xaml"
        ],
        "reachableFromMain": true,
        "finalWiringStatus": "skipped_infrastructure",
        "rootCauseCategory": "none",
        "remediationHint": null
      },
      {
        "file": "Main.xaml",
        "generated": false,
        "required": true,
        "workflowRole": "entrypoint",
        "classificationSourceRule": "basename_match:Main",
        "requiredByPath": "Main.xaml (entry point)",
        "expectedCaller": null,
        "callerCandidates": [],
        "invokeAttempted": false,
        "invokeSucceeded": false,
        "invokeSkippedReason": "entrypoint workflow — wired by framework structure",
        "invokeRejectedReason": null,
        "actualCallers": [],
        "reachableFromMain": true,
        "finalWiringStatus": "wired_and_reachable",
        "rootCauseCategory": "none",
        "remediationHint": null,
        "unwiredSeverity": "none"
      },
      {
        "file": "GetTransactionData.xaml",
        "generated": false,
        "required": true,
        "workflowRole": "transaction_handler",
        "classificationSourceRule": "transaction_pattern_match:GetTransactionData",
        "requiredByPath": "Main.xaml → state-machine transition",
        "expectedCaller": "Main.xaml",
        "callerCandidates": [
          "Main.xaml"
        ],
        "invokeAttempted": true,
        "invokeSucceeded": true,
        "invokeSkippedReason": null,
        "invokeRejectedReason": null,
        "actualCallers": [
          "Main.xaml"
        ],
        "reachableFromMain": true,
        "finalWiringStatus": "wired_and_reachable",
        "rootCauseCategory": "none",
        "remediationHint": null,
        "unwiredSeverity": "none"
      },
      {
        "file": "SetTransactionStatus.xaml",
        "generated": false,
        "required": true,
        "workflowRole": "transaction_handler",
        "classificationSourceRule": "transaction_pattern_match:SetTransactionStatus",
        "requiredByPath": "Main.xaml → state-machine transition",
        "expectedCaller": "Main.xaml",
        "callerCandidates": [
          "Main.xaml"
        ],
        "invokeAttempted": true,
        "invokeSucceeded": true,
        "invokeSkippedReason": null,
        "invokeRejectedReason": null,
        "actualCallers": [
          "Main.xaml",
          "Main.xaml"
        ],
        "reachableFromMain": true,
        "finalWiringStatus": "wired_and_reachable",
        "rootCauseCategory": "none",
        "remediationHint": null,
        "unwiredSeverity": "none"
      },
      {
        "file": "CloseAllApplications.xaml",
        "generated": false,
        "required": false,
        "workflowRole": "helper",
        "classificationSourceRule": "infrastructure_basename_match:closeallapplications",
        "unwiredSeverity": "none",
        "requiredByPath": "infrastructure utility",
        "expectedCaller": "Main.xaml",
        "callerCandidates": [
          "Main.xaml"
        ],
        "invokeAttempted": false,
        "invokeSucceeded": false,
        "invokeSkippedReason": "infrastructure file — always included",
        "invokeRejectedReason": null,
        "actualCallers": [
          "Main.xaml",
          "Main.xaml"
        ],
        "reachableFromMain": true,
        "finalWiringStatus": "skipped_infrastructure",
        "rootCauseCategory": "none",
        "remediationHint": null
      },
      {
        "file": "KillAllProcesses.xaml",
        "generated": false,
        "required": false,
        "workflowRole": "helper",
        "classificationSourceRule": "infrastructure_basename_match:killallprocesses",
        "unwiredSeverity": "none",
        "requiredByPath": "infrastructure utility",
        "expectedCaller": "Main.xaml",
        "callerCandidates": [
          "Main.xaml"
        ],
        "invokeAttempted": false,
        "invokeSucceeded": false,
        "invokeSkippedReason": "infrastructure file — always included",
        "invokeRejectedReason": null,
        "actualCallers": [
          "CloseAllApplications.xaml"
        ],
        "reachableFromMain": true,
        "finalWiringStatus": "skipped_infrastructure",
        "rootCauseCategory": "none",
        "remediationHint": null
      },
      {
        "file": "Init.xaml",
        "generated": false,
        "required": false,
        "workflowRole": "helper",
        "classificationSourceRule": "non_generated_non_entrypoint",
        "requiredByPath": "Main.xaml → Main.xaml → spec-decomposition:Init",
        "expectedCaller": "Main.xaml",
        "callerCandidates": [
          "Main.xaml",
          "Process.xaml"
        ],
        "invokeAttempted": true,
        "invokeSucceeded": true,
        "invokeSkippedReason": null,
        "invokeRejectedReason": null,
        "actualCallers": [
          "Main.xaml"
        ],
        "reachableFromMain": true,
        "finalWiringStatus": "wired_and_reachable",
        "rootCauseCategory": "none",
        "remediationHint": null,
        "unwiredSeverity": "none"
      },
      {
        "file": "InitAllApplications.xaml",
        "generated": false,
        "required": false,
        "workflowRole": "helper",
        "classificationSourceRule": "non_generated_non_entrypoint",
        "requiredByPath": "Main.xaml → Process.xaml → spec-decomposition:InitAllApplications",
        "expectedCaller": "Process.xaml",
        "callerCandidates": [
          "Process.xaml",
          "Main.xaml"
        ],
        "invokeAttempted": false,
        "invokeSucceeded": false,
        "invokeSkippedReason": "non-generated optional workflow — not a wiring target",
        "invokeRejectedReason": null,
        "actualCallers": [],
        "reachableFromMain": false,
        "finalWiringStatus": "unwired_but_retained",
        "rootCauseCategory": "none",
        "remediationHint": null,
        "unwiredSeverity": "info"
      },
      {
        "file": "RetryCurrentTransaction.xaml",
        "generated": false,
        "required": false,
        "workflowRole": "helper",
        "classificationSourceRule": "non_generated_non_entrypoint",
        "requiredByPath": "Main.xaml → Process.xaml → spec-decomposition:RetryCurrentTransaction",
        "expectedCaller": "Process.xaml",
        "callerCandidates": [
          "Process.xaml",
          "Main.xaml"
        ],
        "invokeAttempted": false,
        "invokeSucceeded": false,
        "invokeSkippedReason": "non-generated optional workflow — not a wiring target",
        "invokeRejectedReason": null,
        "actualCallers": [],
        "reachableFromMain": false,
        "finalWiringStatus": "unwired_but_retained",
        "rootCauseCategory": "none",
        "remediationHint": null,
        "unwiredSeverity": "info"
      },
      {
        "file": "RetryInit.xaml",
        "generated": false,
        "required": false,
        "workflowRole": "helper",
        "classificationSourceRule": "non_generated_non_entrypoint",
        "requiredByPath": "Main.xaml → Process.xaml → spec-decomposition:RetryInit",
        "expectedCaller": "Process.xaml",
        "callerCandidates": [
          "Process.xaml",
          "Main.xaml"
        ],
        "invokeAttempted": false,
        "invokeSucceeded": false,
        "invokeSkippedReason": "non-generated optional workflow — not a wiring target",
        "invokeRejectedReason": null,
        "actualCallers": [],
        "reachableFromMain": false,
        "finalWiringStatus": "unwired_but_retained",
        "rootCauseCategory": "none",
        "remediationHint": null,
        "unwiredSeverity": "info"
      },
      {
        "file": "Process.xaml",
        "generated": false,
        "required": true,
        "workflowRole": "entrypoint",
        "classificationSourceRule": "basename_match:Process",
        "requiredByPath": "Main.xaml (entry point)",
        "expectedCaller": "Main.xaml",
        "callerCandidates": [
          "Main.xaml"
        ],
        "invokeAttempted": false,
        "invokeSucceeded": false,
        "invokeSkippedReason": "entrypoint workflow — wired by framework structure",
        "invokeRejectedReason": null,
        "actualCallers": [
          "Main.xaml"
        ],
        "reachableFromMain": true,
        "finalWiringStatus": "wired_and_reachable",
        "rootCauseCategory": "none",
        "remediationHint": null,
        "unwiredSeverity": "none"
      }
    ],
    "summary": {
      "totalGeneratedWorkflows": 9,
      "totalRequiredWorkflows": 13,
      "totalRequiredWorkflowsWired": 13,
      "totalGeneratedButUnwired": 0,
      "totalUnreachableFromMain": 3,
      "totalMissingInvokeEdges": 0,
      "totalCallerMismatchDefects": 2,
      "totalInvokeEmissionFailures": 0
    },
    "activePathProof": {
      "reachabilityComputedOnFinalizedSet": true,
      "reachabilityPruningSkipped": false,
      "wiringComputedOnFinalizedSet": true,
      "workflowSetHashAtWiringTime": "bbb5812a207bf479",
      "workflowSetHashAtReachabilityTime": "dc6640bd16d2164c",
      "consistent": false
    }
  },
  "symbolDiscoveryDiagnostics": [
    {
      "symbol": "Is",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: excluded symbol token (keyword/CLR type/XML entity)"
    },
    {
      "symbol": "Nothing",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: excluded symbol token (keyword/CLR type/XML entity)"
    },
    {
      "symbol": "expected",
      "category": "variable",
      "inferredType": "unknown",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "No prefix and no expression context evidence — declaration blocked to avoid generic placeholder",
      "expressionContext": {
        "activityType": "InvokeCode",
        "propertyName": "Code",
        "expectedType": "unknown",
        "evidenceStrength": "weak"
      }
    },
    {
      "symbol": "be",
      "category": "variable",
      "inferredType": "unknown",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "No prefix and no expression context evidence — declaration blocked to avoid generic placeholder",
      "expressionContext": {
        "activityType": "InvokeCode",
        "propertyName": "Code",
        "expectedType": "unknown",
        "evidenceStrength": "weak"
      }
    },
    {
      "symbol": "from",
      "category": "variable",
      "inferredType": "unknown",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "No prefix and no expression context evidence — declaration blocked to avoid generic placeholder",
      "expressionContext": {
        "activityType": "InvokeCode",
        "propertyName": "Code",
        "expectedType": "unknown",
        "evidenceStrength": "weak"
      }
    },
    {
      "symbol": "the",
      "category": "variable",
      "inferredType": "unknown",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "No prefix and no expression context evidence — declaration blocked to avoid generic placeholder",
      "expressionContext": {
        "activityType": "InvokeCode",
        "propertyName": "Code",
        "expectedType": "unknown",
        "evidenceStrength": "weak"
      }
    },
    {
      "symbol": "connector",
      "category": "variable",
      "inferredType": "unknown",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "No prefix and no expression context evidence — declaration blocked to avoid generic placeholder",
      "expressionContext": {
        "activityType": "InvokeCode",
        "propertyName": "Code",
        "expectedType": "unknown",
        "evidenceStrength": "weak"
      }
    },
    {
      "symbol": "Attempt",
      "category": "variable",
      "inferredType": "unknown",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "No prefix and no expression context evidence — declaration blocked to avoid generic placeholder",
      "expressionContext": {
        "activityType": "InvokeCode",
        "propertyName": "Code",
        "expectedType": "unknown",
        "evidenceStrength": "weak"
      }
    },
    {
      "symbol": "cast",
      "category": "variable",
      "inferredType": "unknown",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "No prefix and no expression context evidence — declaration blocked to avoid generic placeholder",
      "expressionContext": {
        "activityType": "InvokeCode",
        "propertyName": "Code",
        "expectedType": "unknown",
        "evidenceStrength": "weak"
      }
    },
    {
      "symbol": "iterate",
      "category": "variable",
      "inferredType": "unknown",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "No prefix and no expression context evidence — declaration blocked to avoid generic placeholder",
      "expressionContext": {
        "activityType": "InvokeCode",
        "propertyName": "Code",
        "expectedType": "unknown",
        "evidenceStrength": "weak"
      }
    },
    {
      "symbol": "events",
      "category": "variable",
      "inferredType": "unknown",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "No prefix and no expression context evidence — declaration blocked to avoid generic placeholder",
      "expressionContext": {
        "activityType": "InvokeCode",
        "propertyName": "Code",
        "expectedType": "unknown",
        "evidenceStrength": "weak"
      }
    },
    {
      "symbol": "treating",
      "category": "variable",
      "inferredType": "unknown",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "No prefix and no expression context evidence — declaration blocked to avoid generic placeholder",
      "expressionContext": {
        "activityType": "InvokeCode",
        "propertyName": "Code",
        "expectedType": "unknown",
        "evidenceStrength": "weak"
      }
    },
    {
      "symbol": "item",
      "category": "variable",
      "inferredType": "unknown",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "No prefix and no expression context evidence — declaration blocked to avoid generic placeholder",
      "expressionContext": {
        "activityType": "InvokeCode",
        "propertyName": "Code",
        "expectedType": "unknown",
        "evidenceStrength": "weak"
      }
    },
    {
      "symbol": "wrapper",
      "category": "variable",
      "inferredType": "unknown",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "No prefix and no expression context evidence — declaration blocked to avoid generic placeholder",
      "expressionContext": {
        "activityType": "InvokeCode",
        "propertyName": "Code",
        "expectedType": "unknown",
        "evidenceStrength": "weak"
      }
    },
    {
      "symbol": "Items",
      "category": "variable",
      "inferredType": "unknown",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "No prefix and no expression context evidence — declaration blocked to avoid generic placeholder",
      "expressionContext": {
        "activityType": "InvokeCode",
        "propertyName": "Code",
        "expectedType": "unknown",
        "evidenceStrength": "weak"
      }
    },
    {
      "symbol": "Value",
      "category": "variable",
      "inferredType": "unknown",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "No prefix and no expression context evidence — declaration blocked to avoid generic placeholder",
      "expressionContext": {
        "activityType": "InvokeCode",
        "propertyName": "Code",
        "expectedType": "unknown",
        "evidenceStrength": "weak"
      }
    },
    {
      "symbol": "prop",
      "category": "variable",
      "inferredType": "unknown",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "No prefix and no expression context evidence — declaration blocked to avoid generic placeholder",
      "expressionContext": {
        "activityType": "InvokeCode",
        "propertyName": "Code",
        "expectedType": "unknown",
        "evidenceStrength": "weak"
      }
    },
    {
      "symbol": "evt",
      "category": "variable",
      "inferredType": "unknown",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "No prefix and no expression context evidence — declaration blocked to avoid generic placeholder",
      "expressionContext": {
        "activityType": "InvokeCode",
        "propertyName": "Code",
        "expectedType": "unknown",
        "evidenceStrength": "weak"
      }
    },
    {
      "symbol": "evtType",
      "category": "variable",
      "inferredType": "unknown",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "No prefix and no expression context evidence — declaration blocked to avoid generic placeholder",
      "expressionContext": {
        "activityType": "InvokeCode",
        "propertyName": "Code",
        "expectedType": "unknown",
        "evidenceStrength": "weak"
      }
    },
    {
      "symbol": "idProp",
      "category": "variable",
      "inferredType": "unknown",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "No prefix and no expression context evidence — declaration blocked to avoid generic placeholder",
      "expressionContext": {
        "activityType": "InvokeCode",
        "propertyName": "Code",
        "expectedType": "unknown",
        "evidenceStrength": "weak"
      }
    },
    {
      "symbol": "summaryProp",
      "category": "variable",
      "inferredType": "unknown",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "No prefix and no expression context evidence — declaration blocked to avoid generic placeholder",
      "expressionContext": {
        "activityType": "InvokeCode",
        "propertyName": "Code",
        "expectedType": "unknown",
        "evidenceStrength": "weak"
      }
    },
    {
      "symbol": "startProp",
      "category": "variable",
      "inferredType": "unknown",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "No prefix and no expression context evidence — declaration blocked to avoid generic placeholder",
      "expressionContext": {
        "activityType": "InvokeCode",
        "propertyName": "Code",
        "expectedType": "unknown",
        "evidenceStrength": "weak"
      }
    },
    {
      "symbol": "eventId",
      "category": "variable",
      "inferredType": "unknown",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "No prefix and no expression context evidence — declaration blocked to avoid generic placeholder",
      "expressionContext": {
        "activityType": "InvokeCode",
        "propertyName": "Code",
        "expectedType": "unknown",
        "evidenceStrength": "weak"
      }
    },
    {
      "symbol": "summary",
      "category": "variable",
      "inferredType": "unknown",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "No prefix and no expression context evidence — declaration blocked to avoid generic placeholder",
      "expressionContext": {
        "activityType": "InvokeCode",
        "propertyName": "Code",
        "expectedType": "unknown",
        "evidenceStrength": "weak"
      }
    },
    {
      "symbol": "occStart",
      "category": "variable",
      "inferredType": "unknown",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "No prefix and no expression context evidence — declaration blocked to avoid generic placeholder",
      "expressionContext": {
        "activityType": "InvokeCode",
        "propertyName": "Code",
        "expectedType": "unknown",
        "evidenceStrength": "weak"
      }
    },
    {
      "symbol": "startObj",
      "category": "variable",
      "inferredType": "unknown",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "No prefix and no expression context evidence — declaration blocked to avoid generic placeholder",
      "expressionContext": {
        "activityType": "InvokeCode",
        "propertyName": "Code",
        "expectedType": "unknown",
        "evidenceStrength": "weak"
      }
    },
    {
      "symbol": "dateProp",
      "category": "variable",
      "inferredType": "unknown",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "No prefix and no expression context evidence — declaration blocked to avoid generic placeholder",
      "expressionContext": {
        "activityType": "InvokeCode",
        "propertyName": "Code",
        "expectedType": "unknown",
        "evidenceStrength": "weak"
      }
    },
    {
      "symbol": "dateTimeProp",
      "category": "variable",
      "inferredType": "unknown",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "No prefix and no expression context evidence — declaration blocked to avoid generic placeholder",
      "expressionContext": {
        "activityType": "InvokeCode",
        "propertyName": "Code",
        "expectedType": "unknown",
        "evidenceStrength": "weak"
      }
    },
    {
      "symbol": "Normalize",
      "category": "variable",
      "inferredType": "unknown",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "No prefix and no expression context evidence — declaration blocked to avoid generic placeholder",
      "expressionContext": {
        "activityType": "InvokeCode",
        "propertyName": "Code",
        "expectedType": "unknown",
        "evidenceStrength": "weak"
      }
    },
    {
      "symbol": "FullName",
      "category": "variable",
      "inferredType": "unknown",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "No prefix and no expression context evidence — declaration blocked to avoid generic placeholder",
      "expressionContext": {
        "activityType": "InvokeCode",
        "propertyName": "Code",
        "expectedType": "unknown",
        "evidenceStrength": "weak"
      }
    },
    {
      "symbol": "whitespace",
      "category": "variable",
      "inferredType": "unknown",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "No prefix and no expression context evidence — declaration blocked to avoid generic placeholder",
      "expressionContext": {
        "activityType": "InvokeCode",
        "propertyName": "Code",
        "expectedType": "unknown",
        "evidenceStrength": "weak"
      }
    },
    {
      "symbol": "fullName",
      "category": "variable",
      "inferredType": "unknown",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "No prefix and no expression context evidence — declaration blocked to avoid generic placeholder",
      "expressionContext": {
        "activityType": "InvokeCode",
        "propertyName": "Code",
        "expectedType": "unknown",
        "evidenceStrength": "weak"
      }
    },
    {
      "symbol": "is",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: excluded symbol token (keyword/CLR type/XML entity)"
    },
    {
      "symbol": "to",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: excluded symbol token (keyword/CLR type/XML entity)"
    },
    {
      "symbol": "IEnumerable",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: identifier used as function call"
    },
    {
      "symbol": "or",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: excluded symbol token (keyword/CLR type/XML entity)"
    },
    {
      "symbol": "a",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: identifier too short"
    },
    {
      "symbol": "JArray",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: excluded symbol token (keyword/CLR type/XML entity)"
    },
    {
      "symbol": "List",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: excluded symbol token (keyword/CLR type/XML entity)"
    },
    {
      "symbol": "Of",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: excluded symbol token (keyword/CLR type/XML entity)"
    },
    {
      "symbol": "Object",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: excluded symbol token (keyword/CLR type/XML entity)"
    },
    {
      "symbol": "and",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: excluded symbol token (keyword/CLR type/XML entity)"
    },
    {
      "symbol": "Dim",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: excluded symbol token (keyword/CLR type/XML entity)"
    },
    {
      "symbol": "As",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: excluded symbol token (keyword/CLR type/XML entity)"
    },
    {
      "symbol": "System",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: excluded symbol token (keyword/CLR type/XML entity)"
    },
    {
      "symbol": "Collections",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: excluded symbol token (keyword/CLR type/XML entity)"
    },
    {
      "symbol": "TryCast",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: excluded symbol token (keyword/CLR type/XML entity)"
    },
    {
      "symbol": "If",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: excluded symbol token (keyword/CLR type/XML entity)"
    },
    {
      "symbol": "Is",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: excluded symbol token (keyword/CLR type/XML entity)"
    },
    {
      "symbol": "Nothing",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: excluded symbol token (keyword/CLR type/XML entity)"
    },
    {
      "symbol": "Then",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: excluded symbol token (keyword/CLR type/XML entity)"
    },
    {
      "symbol": "Try",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: excluded symbol token (keyword/CLR type/XML entity)"
    },
    {
      "symbol": "as",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: excluded symbol token (keyword/CLR type/XML entity)"
    },
    {
      "symbol": "single",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: excluded symbol token (keyword/CLR type/XML entity)"
    },
    {
      "symbol": "with",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: excluded symbol token (keyword/CLR type/XML entity)"
    },
    {
      "symbol": "property",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: VB.NET reserved word"
    },
    {
      "symbol": "t",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: identifier too short"
    },
    {
      "symbol": "Type",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: excluded symbol token (keyword/CLR type/XML entity)"
    },
    {
      "symbol": "GetType",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: excluded symbol token (keyword/CLR type/XML entity)"
    },
    {
      "symbol": "Reflection",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: PascalCase identifier followed by dot (member access)"
    },
    {
      "symbol": "PropertyInfo",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: identifier accessed as member"
    },
    {
      "symbol": "GetProperty",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: identifier used as function call"
    },
    {
      "symbol": "IsNot",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: excluded symbol token (keyword/CLR type/XML entity)"
    },
    {
      "symbol": "GetValue",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: identifier used as function call"
    },
    {
      "symbol": "End",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: excluded symbol token (keyword/CLR type/XML entity)"
    },
    {
      "symbol": "New",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: excluded symbol token (keyword/CLR type/XML entity)"
    },
    {
      "symbol": "For",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: excluded symbol token (keyword/CLR type/XML entity)"
    },
    {
      "symbol": "Each",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: excluded symbol token (keyword/CLR type/XML entity)"
    },
    {
      "symbol": "In",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: excluded symbol token (keyword/CLR type/XML entity)"
    },
    {
      "symbol": "String",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: excluded symbol token (keyword/CLR type/XML entity)"
    },
    {
      "symbol": "CStr",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: excluded symbol token (keyword/CLR type/XML entity)"
    },
    {
      "symbol": "DateTime",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: excluded symbol token (keyword/CLR type/XML entity)"
    },
    {
      "symbol": "Today",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: excluded symbol token (keyword/CLR type/XML entity)"
    },
    {
      "symbol": "AndAlso",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: excluded symbol token (keyword/CLR type/XML entity)"
    },
    {
      "symbol": "CDate",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: excluded symbol token (keyword/CLR type/XML entity)"
    },
    {
      "symbol": "ElseIf",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: excluded symbol token (keyword/CLR type/XML entity)"
    },
    {
      "symbol": "trim",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: excluded symbol token (keyword/CLR type/XML entity)"
    },
    {
      "symbol": "Trim",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: excluded symbol token (keyword/CLR type/XML entity)"
    },
    {
      "symbol": "IsNullOrWhiteSpace",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: identifier used as function call"
    },
    {
      "symbol": "row",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: identifier used as function call"
    },
    {
      "symbol": "DataRow",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: excluded symbol token (keyword/CLR type/XML entity)"
    },
    {
      "symbol": "NewRow",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: identifier used as function call"
    },
    {
      "symbol": "Rows",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: PascalCase identifier followed by dot (member access)"
    },
    {
      "symbol": "Add",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: identifier used as function call"
    },
    {
      "symbol": "Next",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: excluded symbol token (keyword/CLR type/XML entity)"
    },
    {
      "symbol": "Count",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: identifier accessed as member"
    },
    {
      "symbol": "OutBirthdayEvents",
      "category": "variable",
      "inferredType": "unknown",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "No prefix and no expression context evidence — declaration blocked to avoid generic placeholder",
      "expressionContext": {
        "activityType": "Assign",
        "propertyName": "To",
        "expectedType": "unknown",
        "evidenceStrength": "weak"
      }
    },
    {
      "symbol": "InFullName",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: PascalCase identifier followed by dot (member access)"
    },
    {
      "symbol": "Trim",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: excluded symbol token (keyword/CLR type/XML entity)"
    },
    {
      "symbol": "ToLower",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: identifier used as function call"
    },
    {
      "symbol": "Replace",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: excluded symbol token (keyword/CLR type/XML entity)"
    },
    {
      "symbol": "InFullName",
      "category": "variable",
      "inferredType": "unknown",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "No prefix and no expression context evidence — declaration blocked to avoid generic placeholder",
      "expressionContext": {
        "activityType": "GoogleContactsSearchContacts",
        "propertyName": "Query",
        "expectedType": "unknown",
        "evidenceStrength": "weak"
      }
    },
    {
      "symbol": "If",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: excluded symbol token (keyword/CLR type/XML entity)"
    },
    {
      "symbol": "IsNot",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: excluded symbol token (keyword/CLR type/XML entity)"
    },
    {
      "symbol": "Nothing",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: excluded symbol token (keyword/CLR type/XML entity)"
    },
    {
      "symbol": "Rows",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: PascalCase identifier followed by dot (member access)"
    },
    {
      "symbol": "Count",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: identifier accessed as member"
    },
    {
      "symbol": "Rows",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: identifier used as function call"
    },
    {
      "symbol": "DBNull",
      "category": "variable",
      "inferredType": "String",
      "declarationEmitted": true,
      "scope": "workflow",
      "source": "discovered-reference",
      "expressionContext": {
        "activityType": "Assign",
        "propertyName": "Value",
        "expectedType": "String",
        "evidenceStrength": "strong"
      }
    },
    {
      "symbol": "If",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: excluded symbol token (keyword/CLR type/XML entity)"
    },
    {
      "symbol": "Columns",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: PascalCase identifier followed by dot (member access)"
    },
    {
      "symbol": "Contains",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: identifier used as function call"
    },
    {
      "symbol": "AndAlso",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: excluded symbol token (keyword/CLR type/XML entity)"
    },
    {
      "symbol": "Rows",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: identifier used as function call"
    },
    {
      "symbol": "IsNot",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: excluded symbol token (keyword/CLR type/XML entity)"
    },
    {
      "symbol": "Value",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: identifier accessed as member"
    },
    {
      "symbol": "ToString",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: identifier used as function call"
    },
    {
      "symbol": "Trim",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: excluded symbol token (keyword/CLR type/XML entity)"
    },
    {
      "symbol": "If",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: excluded symbol token (keyword/CLR type/XML entity)"
    },
    {
      "symbol": "Columns",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: PascalCase identifier followed by dot (member access)"
    },
    {
      "symbol": "Contains",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: identifier used as function call"
    },
    {
      "symbol": "AndAlso",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: excluded symbol token (keyword/CLR type/XML entity)"
    },
    {
      "symbol": "Rows",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: identifier used as function call"
    },
    {
      "symbol": "IsNot",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: excluded symbol token (keyword/CLR type/XML entity)"
    },
    {
      "symbol": "Value",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: identifier accessed as member"
    },
    {
      "symbol": "ToString",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: identifier used as function call"
    },
    {
      "symbol": "Trim",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: excluded symbol token (keyword/CLR type/XML entity)"
    },
    {
      "symbol": "in_PersonKey",
      "category": "argument",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "No type evidence from prefix for argument \"in_PersonKey\""
    },
    {
      "symbol": "in_SendYear",
      "category": "argument",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "No type evidence from prefix for argument \"in_SendYear\""
    },
    {
      "symbol": "in_PersonKey",
      "category": "argument",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "No type evidence from prefix for argument \"in_PersonKey\""
    },
    {
      "symbol": "String",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: excluded symbol token (keyword/CLR type/XML entity)"
    },
    {
      "symbol": "IsNullOrWhiteSpace",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: identifier used as function call"
    },
    {
      "symbol": "in_PersonKey",
      "category": "argument",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "No type evidence from prefix for argument \"in_PersonKey\""
    },
    {
      "symbol": "in_PersonKey",
      "category": "argument",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "No type evidence from prefix for argument \"in_PersonKey\""
    },
    {
      "symbol": "in_SendYear",
      "category": "argument",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "No type evidence from prefix for argument \"in_SendYear\""
    },
    {
      "symbol": "in_PersonKey",
      "category": "argument",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "No type evidence from prefix for argument \"in_PersonKey\""
    },
    {
      "symbol": "in_SendYear",
      "category": "argument",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "No type evidence from prefix for argument \"in_SendYear\""
    },
    {
      "symbol": "If",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: excluded symbol token (keyword/CLR type/XML entity)"
    },
    {
      "symbol": "IsNot",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: excluded symbol token (keyword/CLR type/XML entity)"
    },
    {
      "symbol": "Nothing",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: excluded symbol token (keyword/CLR type/XML entity)"
    },
    {
      "symbol": "New",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: excluded symbol token (keyword/CLR type/XML entity)"
    },
    {
      "symbol": "List",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: excluded symbol token (keyword/CLR type/XML entity)"
    },
    {
      "symbol": "Of",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: excluded symbol token (keyword/CLR type/XML entity)"
    },
    {
      "symbol": "Object",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: excluded symbol token (keyword/CLR type/XML entity)"
    },
    {
      "symbol": "If",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: excluded symbol token (keyword/CLR type/XML entity)"
    },
    {
      "symbol": "IsNot",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: excluded symbol token (keyword/CLR type/XML entity)"
    },
    {
      "symbol": "Nothing",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: excluded symbol token (keyword/CLR type/XML entity)"
    },
    {
      "symbol": "DirectCast",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: excluded symbol token (keyword/CLR type/XML entity)"
    },
    {
      "symbol": "System",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: excluded symbol token (keyword/CLR type/XML entity)"
    },
    {
      "symbol": "Collections",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: excluded symbol token (keyword/CLR type/XML entity)"
    },
    {
      "symbol": "IList",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: identifier accessed as member"
    },
    {
      "symbol": "Count",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: identifier accessed as member"
    },
    {
      "symbol": "Id",
      "category": "variable",
      "inferredType": "String",
      "declarationEmitted": true,
      "scope": "workflow",
      "source": "discovered-reference",
      "expressionContext": {
        "activityType": "Assign",
        "propertyName": "Value",
        "expectedType": "String",
        "evidenceStrength": "strong"
      }
    },
    {
      "symbol": "DirectCast",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: excluded symbol token (keyword/CLR type/XML entity)"
    },
    {
      "symbol": "System",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: excluded symbol token (keyword/CLR type/XML entity)"
    },
    {
      "symbol": "Collections",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: excluded symbol token (keyword/CLR type/XML entity)"
    },
    {
      "symbol": "IList",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: identifier accessed as member"
    },
    {
      "symbol": "UiPath",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: PascalCase identifier followed by dot (member access)"
    },
    {
      "symbol": "DataService",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: PascalCase identifier followed by dot (member access)"
    },
    {
      "symbol": "ApiClient",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: PascalCase identifier followed by dot (member access)"
    },
    {
      "symbol": "Models",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: PascalCase identifier followed by dot (member access)"
    },
    {
      "symbol": "EntityRecord",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: identifier accessed as member"
    },
    {
      "symbol": "ToString",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: identifier used as function call"
    },
    {
      "symbol": "in_PersonKey",
      "category": "argument",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "No type evidence from prefix for argument \"in_PersonKey\""
    },
    {
      "symbol": "in_SendYear",
      "category": "argument",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "No type evidence from prefix for argument \"in_SendYear\""
    },
    {
      "symbol": "in_PersonKey",
      "category": "argument",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "No type evidence from prefix for argument \"in_PersonKey\""
    },
    {
      "symbol": "in_SendYear",
      "category": "argument",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "No type evidence from prefix for argument \"in_SendYear\""
    },
    {
      "symbol": "out_AlreadySent",
      "category": "argument",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "No type evidence from prefix for argument \"out_AlreadySent\""
    },
    {
      "symbol": "out_ExistingRecordId",
      "category": "argument",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "No type evidence from prefix for argument \"out_ExistingRecordId\""
    },
    {
      "symbol": "in_PersonKey",
      "category": "argument",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "No type evidence from prefix for argument \"in_PersonKey\""
    },
    {
      "symbol": "in_SendYear",
      "category": "argument",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "No type evidence from prefix for argument \"in_SendYear\""
    },
    {
      "symbol": "out_AlreadySent",
      "category": "argument",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "No type evidence from prefix for argument \"out_AlreadySent\""
    },
    {
      "symbol": "out_ExistingRecordId",
      "category": "argument",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "No type evidence from prefix for argument \"out_ExistingRecordId\""
    },
    {
      "symbol": "in_PersonKey",
      "category": "argument",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "No type evidence from prefix for argument \"in_PersonKey\""
    },
    {
      "symbol": "in_SendYear",
      "category": "argument",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "No type evidence from prefix for argument \"in_SendYear\""
    },
    {
      "symbol": "IsNot",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: excluded symbol token (keyword/CLR type/XML entity)"
    },
    {
      "symbol": "Nothing",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: excluded symbol token (keyword/CLR type/XML entity)"
    },
    {
      "symbol": "True",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: excluded symbol token (keyword/CLR type/XML entity)"
    },
    {
      "symbol": "rawJson",
      "category": "variable",
      "inferredType": "unknown",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "No prefix and no expression context evidence — declaration blocked to avoid generic placeholder",
      "expressionContext": {
        "activityType": "InvokeCode",
        "propertyName": "Code",
        "expectedType": "unknown",
        "evidenceStrength": "weak"
      }
    },
    {
      "symbol": "cleaned",
      "category": "variable",
      "inferredType": "unknown",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "No prefix and no expression context evidence — declaration blocked to avoid generic placeholder",
      "expressionContext": {
        "activityType": "InvokeCode",
        "propertyName": "Code",
        "expectedType": "unknown",
        "evidenceStrength": "weak"
      }
    },
    {
      "symbol": "ex",
      "category": "variable",
      "inferredType": "unknown",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "No prefix and no expression context evidence — declaration blocked to avoid generic placeholder",
      "expressionContext": {
        "activityType": "InvokeCode",
        "propertyName": "Code",
        "expectedType": "unknown",
        "evidenceStrength": "weak"
      }
    },
    {
      "symbol": "Dim",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: excluded symbol token (keyword/CLR type/XML entity)"
    },
    {
      "symbol": "As",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: excluded symbol token (keyword/CLR type/XML entity)"
    },
    {
      "symbol": "String",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: excluded symbol token (keyword/CLR type/XML entity)"
    },
    {
      "symbol": "Trim",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: excluded symbol token (keyword/CLR type/XML entity)"
    },
    {
      "symbol": "If",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: excluded symbol token (keyword/CLR type/XML entity)"
    },
    {
      "symbol": "StartsWith",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: identifier used as function call"
    },
    {
      "symbol": "Then",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: excluded symbol token (keyword/CLR type/XML entity)"
    },
    {
      "symbol": "Substring",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: identifier used as function call"
    },
    {
      "symbol": "EndsWith",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: identifier used as function call"
    },
    {
      "symbol": "Length",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: identifier accessed as member"
    },
    {
      "symbol": "parsed",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: identifier used as function call"
    },
    {
      "symbol": "System",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: excluded symbol token (keyword/CLR type/XML entity)"
    },
    {
      "symbol": "Collections",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: excluded symbol token (keyword/CLR type/XML entity)"
    },
    {
      "symbol": "Generic",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: excluded symbol token (keyword/CLR type/XML entity)"
    },
    {
      "symbol": "Dictionary",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: excluded symbol token (keyword/CLR type/XML entity)"
    },
    {
      "symbol": "Of",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: excluded symbol token (keyword/CLR type/XML entity)"
    },
    {
      "symbol": "Object",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: excluded symbol token (keyword/CLR type/XML entity)"
    },
    {
      "symbol": "Try",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: excluded symbol token (keyword/CLR type/XML entity)"
    },
    {
      "symbol": "Newtonsoft",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: excluded symbol token (keyword/CLR type/XML entity)"
    },
    {
      "symbol": "Json",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: excluded symbol token (keyword/CLR type/XML entity)"
    },
    {
      "symbol": "JsonConvert",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: excluded symbol token (keyword/CLR type/XML entity)"
    },
    {
      "symbol": "DeserializeObject",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: identifier used as function call"
    },
    {
      "symbol": "ContainsKey",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: identifier used as function call"
    },
    {
      "symbol": "AndAlso",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: excluded symbol token (keyword/CLR type/XML entity)"
    },
    {
      "symbol": "ToString",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: identifier used as function call"
    },
    {
      "symbol": "True",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: excluded symbol token (keyword/CLR type/XML entity)"
    },
    {
      "symbol": "Else",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: excluded symbol token (keyword/CLR type/XML entity)"
    },
    {
      "symbol": "False",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: excluded symbol token (keyword/CLR type/XML entity)"
    },
    {
      "symbol": "End",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: excluded symbol token (keyword/CLR type/XML entity)"
    },
    {
      "symbol": "Catch",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: excluded symbol token (keyword/CLR type/XML entity)"
    },
    {
      "symbol": "Exception",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: excluded symbol token (keyword/CLR type/XML entity)"
    },
    {
      "symbol": "From",
      "category": "variable",
      "inferredType": "unknown",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "No prefix and no expression context evidence — declaration blocked to avoid generic placeholder",
      "expressionContext": {
        "activityType": "InvokeCode",
        "propertyName": "Arguments",
        "expectedType": "unknown",
        "evidenceStrength": "weak"
      }
    },
    {
      "symbol": "New",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: excluded symbol token (keyword/CLR type/XML entity)"
    },
    {
      "symbol": "Dictionary",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: excluded symbol token (keyword/CLR type/XML entity)"
    },
    {
      "symbol": "Of",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: excluded symbol token (keyword/CLR type/XML entity)"
    },
    {
      "symbol": "String",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: excluded symbol token (keyword/CLR type/XML entity)"
    },
    {
      "symbol": "Object",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: excluded symbol token (keyword/CLR type/XML entity)"
    },
    {
      "symbol": "False",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: excluded symbol token (keyword/CLR type/XML entity)"
    },
    {
      "symbol": "InFullName",
      "category": "variable",
      "inferredType": "unknown",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "No prefix and no expression context evidence — declaration blocked to avoid generic placeholder"
    },
    {
      "symbol": "InSubject",
      "category": "variable",
      "inferredType": "unknown",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "No prefix and no expression context evidence — declaration blocked to avoid generic placeholder"
    },
    {
      "symbol": "InBody",
      "category": "variable",
      "inferredType": "unknown",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "No prefix and no expression context evidence — declaration blocked to avoid generic placeholder"
    },
    {
      "symbol": "String",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: excluded symbol token (keyword/CLR type/XML entity)"
    },
    {
      "symbol": "IsNullOrWhiteSpace",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: identifier used as function call"
    },
    {
      "symbol": "OrElse",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: excluded symbol token (keyword/CLR type/XML entity)"
    },
    {
      "symbol": "Contains",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: identifier used as function call"
    },
    {
      "symbol": "Contains",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: identifier used as function call"
    },
    {
      "symbol": "False",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: excluded symbol token (keyword/CLR type/XML entity)"
    },
    {
      "symbol": "False",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: excluded symbol token (keyword/CLR type/XML entity)"
    },
    {
      "symbol": "InBody",
      "category": "variable",
      "inferredType": "unknown",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "No prefix and no expression context evidence — declaration blocked to avoid generic placeholder",
      "expressionContext": {
        "activityType": "IsMatch",
        "propertyName": "Input",
        "expectedType": "unknown",
        "evidenceStrength": "weak"
      }
    },
    {
      "symbol": "InSubject",
      "category": "variable",
      "inferredType": "unknown",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "No prefix and no expression context evidence — declaration blocked to avoid generic placeholder",
      "expressionContext": {
        "activityType": "IsMatch",
        "propertyName": "Input",
        "expectedType": "unknown",
        "evidenceStrength": "weak"
      }
    },
    {
      "symbol": "True",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: excluded symbol token (keyword/CLR type/XML entity)"
    },
    {
      "symbol": "True",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: excluded symbol token (keyword/CLR type/XML entity)"
    },
    {
      "symbol": "InBody",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: PascalCase identifier followed by dot (member access)"
    },
    {
      "symbol": "Trim",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: excluded symbol token (keyword/CLR type/XML entity)"
    },
    {
      "symbol": "Split",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: excluded symbol token (keyword/CLR type/XML entity)"
    },
    {
      "symbol": "New",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: excluded symbol token (keyword/CLR type/XML entity)"
    },
    {
      "symbol": "Char",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: excluded symbol token (keyword/CLR type/XML entity)"
    },
    {
      "symbol": "c",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: identifier too short"
    },
    {
      "symbol": "Chr",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: excluded symbol token (keyword/CLR type/XML entity)"
    },
    {
      "symbol": "StringSplitOptions",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: PascalCase identifier followed by dot (member access)"
    },
    {
      "symbol": "RemoveEmptyEntries",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: identifier accessed as member"
    },
    {
      "symbol": "Length",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: identifier accessed as member"
    },
    {
      "symbol": "True",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: excluded symbol token (keyword/CLR type/XML entity)"
    },
    {
      "symbol": "Split",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: excluded symbol token (keyword/CLR type/XML entity)"
    },
    {
      "symbol": "New",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: excluded symbol token (keyword/CLR type/XML entity)"
    },
    {
      "symbol": "Char",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: excluded symbol token (keyword/CLR type/XML entity)"
    },
    {
      "symbol": "Chr",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: excluded symbol token (keyword/CLR type/XML entity)"
    },
    {
      "symbol": "StringSplitOptions",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: PascalCase identifier followed by dot (member access)"
    },
    {
      "symbol": "RemoveEmptyEntries",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: identifier accessed as member"
    },
    {
      "symbol": "InDryRun",
      "category": "variable",
      "inferredType": "unknown",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "No prefix and no expression context evidence — declaration blocked to avoid generic placeholder"
    },
    {
      "symbol": "True",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: excluded symbol token (keyword/CLR type/XML entity)"
    },
    {
      "symbol": "InRunId",
      "category": "variable",
      "inferredType": "String",
      "declarationEmitted": true,
      "scope": "workflow",
      "source": "discovered-reference",
      "expressionContext": {
        "activityType": "Assign",
        "propertyName": "Value",
        "expectedType": "String",
        "evidenceStrength": "strong"
      }
    },
    {
      "symbol": "DateTime",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: excluded symbol token (keyword/CLR type/XML entity)"
    },
    {
      "symbol": "UtcNow",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: PascalCase identifier followed by dot (member access)"
    },
    {
      "symbol": "ToString",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: identifier used as function call"
    },
    {
      "symbol": "OutGmailMessageId",
      "category": "variable",
      "inferredType": "unknown",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "No prefix and no expression context evidence — declaration blocked to avoid generic placeholder",
      "expressionContext": {
        "activityType": "Assign",
        "propertyName": "To",
        "expectedType": "unknown",
        "evidenceStrength": "weak"
      }
    },
    {
      "symbol": "If",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: excluded symbol token (keyword/CLR type/XML entity)"
    },
    {
      "symbol": "TimeSpan",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: excluded symbol token (keyword/CLR type/XML entity)"
    },
    {
      "symbol": "FromSeconds",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: identifier used as function call"
    },
    {
      "symbol": "Nothing",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: excluded symbol token (keyword/CLR type/XML entity)"
    },
    {
      "symbol": "DateTime",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: excluded symbol token (keyword/CLR type/XML entity)"
    },
    {
      "symbol": "UtcNow",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: PascalCase identifier followed by dot (member access)"
    },
    {
      "symbol": "ToString",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: identifier used as function call"
    },
    {
      "symbol": "OutGmailMessageId",
      "category": "variable",
      "inferredType": "unknown",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "No prefix and no expression context evidence — declaration blocked to avoid generic placeholder",
      "expressionContext": {
        "activityType": "Assign",
        "propertyName": "To",
        "expectedType": "unknown",
        "evidenceStrength": "weak"
      }
    },
    {
      "symbol": "System",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: excluded symbol token (keyword/CLR type/XML entity)"
    },
    {
      "symbol": "IO",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: excluded symbol token (keyword/CLR type/XML entity)"
    },
    {
      "symbol": "Path",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: excluded symbol token (keyword/CLR type/XML entity)"
    },
    {
      "symbol": "Combine",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: identifier used as function call"
    },
    {
      "symbol": "GetTempPath",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: identifier used as function call"
    },
    {
      "symbol": "DateTime",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: excluded symbol token (keyword/CLR type/XML entity)"
    },
    {
      "symbol": "UtcNow",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: PascalCase identifier followed by dot (member access)"
    },
    {
      "symbol": "ToString",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: identifier used as function call"
    },
    {
      "symbol": "DateTime",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: excluded symbol token (keyword/CLR type/XML entity)"
    },
    {
      "symbol": "UtcNow",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: PascalCase identifier followed by dot (member access)"
    },
    {
      "symbol": "ToString",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: identifier used as function call"
    },
    {
      "symbol": "OutGmailMessageId",
      "category": "variable",
      "inferredType": "unknown",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "No prefix and no expression context evidence — declaration blocked to avoid generic placeholder",
      "expressionContext": {
        "activityType": "Assign",
        "propertyName": "To",
        "expectedType": "unknown",
        "evidenceStrength": "weak"
      }
    },
    {
      "symbol": "InPersonKey",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: PascalCase identifier followed by dot (member access)"
    },
    {
      "symbol": "Trim",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: excluded symbol token (keyword/CLR type/XML entity)"
    },
    {
      "symbol": "ToLower",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: identifier used as function call"
    },
    {
      "symbol": "InSendYear",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: PascalCase identifier followed by dot (member access)"
    },
    {
      "symbol": "ToString",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: identifier used as function call"
    },
    {
      "symbol": "IsNot",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: excluded symbol token (keyword/CLR type/XML entity)"
    },
    {
      "symbol": "Nothing",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: excluded symbol token (keyword/CLR type/XML entity)"
    },
    {
      "symbol": "If",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: excluded symbol token (keyword/CLR type/XML entity)"
    },
    {
      "symbol": "IsNot",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: excluded symbol token (keyword/CLR type/XML entity)"
    },
    {
      "symbol": "Nothing",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: excluded symbol token (keyword/CLR type/XML entity)"
    },
    {
      "symbol": "CStr",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: excluded symbol token (keyword/CLR type/XML entity)"
    },
    {
      "symbol": "CallByName",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: identifier used as function call"
    },
    {
      "symbol": "CallType",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: PascalCase identifier followed by dot (member access)"
    },
    {
      "symbol": "Get",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: VB.NET reserved word"
    },
    {
      "symbol": "in_RunId",
      "category": "argument",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "No type evidence from prefix for argument \"in_RunId\""
    },
    {
      "symbol": "in_EventId",
      "category": "argument",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "No type evidence from prefix for argument \"in_EventId\""
    },
    {
      "symbol": "in_FullName",
      "category": "argument",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "No type evidence from prefix for argument \"in_FullName\""
    },
    {
      "symbol": "in_FailReason",
      "category": "argument",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "No type evidence from prefix for argument \"in_FailReason\""
    },
    {
      "symbol": "DateTime",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: excluded symbol token (keyword/CLR type/XML entity)"
    },
    {
      "symbol": "UtcNow",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: PascalCase identifier followed by dot (member access)"
    },
    {
      "symbol": "AddHours",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: identifier used as function call"
    },
    {
      "symbol": "in_FullName",
      "category": "argument",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "No type evidence from prefix for argument \"in_FullName\""
    },
    {
      "symbol": "in_RunId",
      "category": "argument",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "No type evidence from prefix for argument \"in_RunId\""
    },
    {
      "symbol": "If",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: excluded symbol token (keyword/CLR type/XML entity)"
    },
    {
      "symbol": "IsNot",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: excluded symbol token (keyword/CLR type/XML entity)"
    },
    {
      "symbol": "Nothing",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: excluded symbol token (keyword/CLR type/XML entity)"
    },
    {
      "symbol": "ToString",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: identifier used as function call"
    },
    {
      "symbol": "in_FullName",
      "category": "argument",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "No type evidence from prefix for argument \"in_FullName\""
    },
    {
      "symbol": "in_RunId",
      "category": "argument",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "No type evidence from prefix for argument \"in_RunId\""
    },
    {
      "symbol": "in_FullName",
      "category": "argument",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "No type evidence from prefix for argument \"in_FullName\""
    },
    {
      "symbol": "in_RunId",
      "category": "argument",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "No type evidence from prefix for argument \"in_RunId\""
    },
    {
      "symbol": "out_TaskId",
      "category": "argument",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "No type evidence from prefix for argument \"out_TaskId\""
    },
    {
      "symbol": "out_TaskId",
      "category": "argument",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "No type evidence from prefix for argument \"out_TaskId\""
    },
    {
      "symbol": "out_TaskId",
      "category": "argument",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "No type evidence from prefix for argument \"out_TaskId\""
    },
    {
      "symbol": "in_FullName",
      "category": "argument",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "No type evidence from prefix for argument \"in_FullName\""
    },
    {
      "symbol": "in_RunId",
      "category": "argument",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "No type evidence from prefix for argument \"in_RunId\""
    },
    {
      "symbol": "System",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: excluded symbol token (keyword/CLR type/XML entity)"
    },
    {
      "symbol": "Guid",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: excluded symbol token (keyword/CLR type/XML entity)"
    },
    {
      "symbol": "NewGuid",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: identifier used as function call"
    },
    {
      "symbol": "ToString",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: identifier used as function call"
    },
    {
      "symbol": "DateTime",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: excluded symbol token (keyword/CLR type/XML entity)"
    },
    {
      "symbol": "Now",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: excluded symbol token (keyword/CLR type/XML entity)"
    },
    {
      "symbol": "Year",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: excluded symbol token (keyword/CLR type/XML entity)"
    },
    {
      "symbol": "Boolean",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: excluded symbol token (keyword/CLR type/XML entity)"
    },
    {
      "symbol": "Parse",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: identifier used as function call"
    },
    {
      "symbol": "If",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: excluded symbol token (keyword/CLR type/XML entity)"
    },
    {
      "symbol": "String",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: excluded symbol token (keyword/CLR type/XML entity)"
    },
    {
      "symbol": "IsNullOrWhiteSpace",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: identifier used as function call"
    },
    {
      "symbol": "InArgument",
      "category": "variable",
      "inferredType": "unknown",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "No prefix and no expression context evidence — declaration blocked to avoid generic placeholder",
      "expressionContext": {
        "activityType": "InvokeWorkflowFile",
        "propertyName": "Arguments",
        "expectedType": "unknown",
        "evidenceStrength": "weak"
      }
    },
    {
      "symbol": "x",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: identifier too short"
    },
    {
      "symbol": "Object",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: excluded symbol token (keyword/CLR type/XML entity)"
    },
    {
      "symbol": "vb_expression",
      "category": "variable",
      "inferredType": "unknown",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "No prefix and no expression context evidence — declaration blocked to avoid generic placeholder",
      "expressionContext": {
        "activityType": "InvokeWorkflowFile",
        "propertyName": "Arguments",
        "expectedType": "unknown",
        "evidenceStrength": "weak"
      }
    },
    {
      "symbol": "InArgument",
      "category": "variable",
      "inferredType": "unknown",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "No prefix and no expression context evidence — declaration blocked to avoid generic placeholder",
      "expressionContext": {
        "activityType": "InvokeWorkflowFile",
        "propertyName": "Arguments",
        "expectedType": "unknown",
        "evidenceStrength": "weak"
      }
    },
    {
      "symbol": "x",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: identifier too short"
    },
    {
      "symbol": "Object",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: excluded symbol token (keyword/CLR type/XML entity)"
    },
    {
      "symbol": "in_RunId",
      "category": "argument",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "No type evidence from prefix for argument \"in_RunId\""
    },
    {
      "symbol": "out_BirthdayEvents",
      "category": "argument",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "No type evidence from prefix for argument \"out_BirthdayEvents\""
    },
    {
      "symbol": "From",
      "category": "variable",
      "inferredType": "unknown",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "No prefix and no expression context evidence — declaration blocked to avoid generic placeholder",
      "expressionContext": {
        "activityType": "InvokeWorkflowFile",
        "propertyName": "Arguments",
        "expectedType": "unknown",
        "evidenceStrength": "weak"
      }
    },
    {
      "symbol": "New",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: excluded symbol token (keyword/CLR type/XML entity)"
    },
    {
      "symbol": "Dictionary",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: excluded symbol token (keyword/CLR type/XML entity)"
    },
    {
      "symbol": "Of",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: excluded symbol token (keyword/CLR type/XML entity)"
    },
    {
      "symbol": "String",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: excluded symbol token (keyword/CLR type/XML entity)"
    },
    {
      "symbol": "Object",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: excluded symbol token (keyword/CLR type/XML entity)"
    },
    {
      "symbol": "Nothing",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: excluded symbol token (keyword/CLR type/XML entity)"
    },
    {
      "symbol": "Is",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: excluded symbol token (keyword/CLR type/XML entity)"
    },
    {
      "symbol": "Nothing",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: excluded symbol token (keyword/CLR type/XML entity)"
    },
    {
      "symbol": "OrElse",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: excluded symbol token (keyword/CLR type/XML entity)"
    },
    {
      "symbol": "Length",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: identifier accessed as member"
    },
    {
      "symbol": "Length",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: identifier accessed as member"
    },
    {
      "symbol": "System",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: excluded symbol token (keyword/CLR type/XML entity)"
    },
    {
      "symbol": "Text",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: excluded symbol token (keyword/CLR type/XML entity)"
    },
    {
      "symbol": "RegularExpressions",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: PascalCase identifier followed by dot (member access)"
    },
    {
      "symbol": "Regex",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: excluded symbol token (keyword/CLR type/XML entity)"
    },
    {
      "symbol": "Replace",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: excluded symbol token (keyword/CLR type/XML entity)"
    },
    {
      "symbol": "ToLowerInvariant",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: identifier used as function call"
    },
    {
      "symbol": "Trim",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: excluded symbol token (keyword/CLR type/XML entity)"
    },
    {
      "symbol": "True",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: excluded symbol token (keyword/CLR type/XML entity)"
    },
    {
      "symbol": "DateTime",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: excluded symbol token (keyword/CLR type/XML entity)"
    },
    {
      "symbol": "MinValue",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: identifier accessed as member"
    },
    {
      "symbol": "False",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: excluded symbol token (keyword/CLR type/XML entity)"
    },
    {
      "symbol": "DateTime",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: excluded symbol token (keyword/CLR type/XML entity)"
    },
    {
      "symbol": "MinValue",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: identifier accessed as member"
    },
    {
      "symbol": "True",
      "category": "variable",
      "inferredType": "x:Object",
      "declarationEmitted": false,
      "scope": "workflow",
      "source": "discovered-reference",
      "ambiguityReason": "Withheld: excluded symbol token (keyword/CLR type/XML entity)"
    }
  ],
  "catalogFilterAdoption": [
    {
      "stage": "quality-gate",
      "adopted": true,
      "lookups": {
        "total": 712,
        "approved": 712,
        "deprecated": 0,
        "nonEmissionApproved": 0,
        "targetIncompatible": 0,
        "unknown": 0
      }
    },
    {
      "stage": "deterministic-validators",
      "adopted": true,
      "lookups": {
        "total": 0,
        "approved": 0,
        "deprecated": 0,
        "nonEmissionApproved": 0,
        "targetIncompatible": 0,
        "unknown": 0
      }
    },
    {
      "stage": "iterative-llm-corrector",
      "adopted": true,
      "lookups": {
        "total": 0,
        "approved": 0,
        "deprecated": 0,
        "nonEmissionApproved": 0,
        "targetIncompatible": 0,
        "unknown": 0
      }
    },
    {
      "stage": "workflow-tree-assembler",
      "adopted": true,
      "lookups": {
        "total": 144,
        "approved": 144,
        "deprecated": 0,
        "nonEmissionApproved": 0,
        "targetIncompatible": 0,
        "unknown": 0
      }
    },
    {
      "stage": "xaml-compliance",
      "adopted": true,
      "lookups": {
        "total": 203292,
        "approved": 177137,
        "deprecated": 0,
        "nonEmissionApproved": 24645,
        "targetIncompatible": 0,
        "unknown": 1510
      }
    },
    {
      "stage": "executable-path-validator",
      "adopted": true,
      "lookups": {
        "total": 520,
        "approved": 445,
        "deprecated": 0,
        "nonEmissionApproved": 0,
        "targetIncompatible": 0,
        "unknown": 75
      }
    },
    {
      "stage": "post-emission-dependency-analyzer",
      "adopted": true,
      "lookups": {
        "total": 14,
        "approved": 14,
        "deprecated": 0,
        "nonEmissionApproved": 0,
        "targetIncompatible": 0,
        "unknown": 0
      }
    }
  ]
}
```
