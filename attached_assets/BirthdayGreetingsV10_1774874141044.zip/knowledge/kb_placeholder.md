# Knowledge Base — BirthdayGreetingsV10

This folder should contain the documents the agent needs for retrieval-augmented generation (RAG).

## Recommended Documents

- Standard Operating Procedures (SOPs) for BirthdayGreetingsV10
- Business rules and exception handling documentation
- Reference data tables and lookup values
- Previous process execution logs and examples

## Setup Steps

1. Upload documents to the UiPath AI Center knowledge base
2. Configure indexing and chunking strategy
3. Test retrieval with representative queries
4. Verify agent can cite relevant document sections
