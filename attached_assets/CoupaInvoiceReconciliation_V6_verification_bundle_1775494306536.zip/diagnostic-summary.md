# Diagnostic Summary

## Run Metadata
- **Run ID:** e1f1472c-764b-4958-919b-adfb0ab0f807
- **Idea ID:** 4e008772-687a-4046-8e1b-472832d1e3ed
- **Status:** completed_with_warnings
- **Generation Mode:** baseline_openable
- **Triggered By:** chat
- **Created At:** Mon Apr 06 2026 16:40:16 GMT+0000 (Coordinated Universal Time)
- **Completed At:** Mon Apr 06 2026 16:46:23 GMT+0000 (Coordinated Universal Time)
- **Duration:** 366.8s
- **Error:** orphaned_after_restart

## Stage Timing

| Stage | Status | Duration (ms) |
|-------|--------|--------------|
| sdd_validation | succeeded | 20 |
| pipeline_sdd_validation | succeeded | 20 |
| spec_generation | succeeded | 359511 |
| spec_context_loading | succeeded | 3 |
| spec_prompt_assembly | succeeded | 1 |
| pre_complexity_estimation | succeeded | 0 |
| spec_scaffold | succeeded | 63574 |
| workflow_budget_check | succeeded | 0 |
| spec_merge | succeeded | 1 |
| spec_handoff | succeeded | 1 |
| build_pipeline | succeeded | 7230 |
| pipeline_build_pipeline | succeeded | 7230 |
| pipeline_decomposition | succeeded | 2 |
| pipeline_pre_complexity_estimation | succeeded | 1 |
| pipeline_workflow_budget_check | succeeded | 1 |
| pipeline_complexity_classification | succeeded | 1 |
| pipeline_xaml_emission | succeeded | 4808 |
| pipeline_xaml_emission_fallback | degraded | 0 |
| pipeline_xaml_emission_fallback | degraded | 0 |
| pipeline_xaml_emission_fallback | degraded | 0 |
| pipeline_xaml_emission_fallback | degraded | 0 |
| pipeline_xaml_emission_fallback | degraded | 0 |
| pipeline_compliance_normalization | succeeded | 49 |
| pipeline_validation | succeeded | 754 |
| pipeline_packaging_dhg | succeeded | 0 |
| pipeline_final_artifact_validation | succeeded | 661 |
| pipeline_packaging_dhg_guide | succeeded | 87 |
| pipeline_structural-deduplication_fallback | degraded | 0 |
| pipeline_dependency-crosscheck_fallback | degraded | 0 |
| pipeline_post-assembly-validation_fallback | degraded | 0 |
| pipeline_post-assembly-validation_fallback | degraded | 0 |
| pipeline_post-assembly-validation_fallback | degraded | 0 |
| pipeline_remediating_fallback | degraded | 0 |
| pipeline_remediating_fallback | degraded | 0 |
| pipeline_remediating_fallback | degraded | 0 |
| pipeline_remediating_fallback | degraded | 0 |
| pipeline_remediating_fallback | degraded | 0 |
| pipeline_remediating_fallback | degraded | 0 |
| pipeline_remediating_fallback | degraded | 0 |
| pipeline_remediating_fallback | degraded | 0 |
| pipeline_remediating_fallback | degraded | 0 |
| pipeline_remediating_fallback | degraded | 0 |
| pipeline_remediating_fallback | degraded | 0 |
| pipeline_remediating_fallback | degraded | 0 |
| pipeline_remediating_fallback | degraded | 0 |
| pipeline_remediating_fallback | degraded | 0 |
| pipeline_remediating_fallback | degraded | 0 |
| pipeline_remediating_fallback | degraded | 0 |
| pipeline_remediating_fallback | degraded | 0 |
| pipeline_remediating_fallback | degraded | 0 |
| pipeline_remediating_fallback | degraded | 0 |
| pipeline_remediating_fallback | degraded | 0 |
| pipeline_remediating_fallback | degraded | 0 |
| pipeline_remediating_fallback | degraded | 0 |
| pipeline_remediating_fallback | degraded | 0 |
| pipeline_remediating_fallback | degraded | 0 |
| pipeline_remediating_fallback | degraded | 0 |
| pipeline_remediating_fallback | degraded | 0 |
| pipeline_remediating_fallback | degraded | 0 |
| pipeline_remediating_fallback | degraded | 0 |
| pipeline_remediating_fallback | degraded | 0 |
| pipeline_remediating_fallback | degraded | 0 |
| pipeline_remediating_fallback | degraded | 0 |
| pipeline_remediating_fallback | degraded | 0 |
| pipeline_remediating_fallback | degraded | 0 |
| pipeline_remediating_fallback | degraded | 0 |
| pipeline_remediating_fallback | degraded | 0 |
| pipeline_remediating_fallback | degraded | 0 |
| pipeline_remediating_fallback | degraded | 0 |
| pipeline_remediating_fallback | degraded | 0 |
| pipeline_remediating_fallback | degraded | 0 |
| pipeline_remediating_fallback | degraded | 0 |
| pipeline_remediating_fallback | degraded | 0 |
| pipeline_remediating_fallback | degraded | 0 |
| pipeline_remediating_fallback | degraded | 0 |
| pipeline_remediating_fallback | degraded | 0 |
| pipeline_remediating_fallback | degraded | 0 |
| pipeline_remediating_fallback | degraded | 0 |
| pipeline_remediating_fallback | degraded | 0 |
| pipeline_remediating_fallback | degraded | 0 |
| pipeline_remediating_fallback | degraded | 0 |
| pipeline_remediating_fallback | degraded | 0 |
| pipeline_remediating_fallback | degraded | 0 |
| pipeline_remediating_fallback | degraded | 0 |
| pipeline_remediating_fallback | degraded | 0 |
| pipeline_remediating_fallback | degraded | 0 |
| pipeline_remediating_fallback | degraded | 0 |
| pipeline_remediating_fallback | degraded | 0 |
| pipeline_remediating_fallback | degraded | 0 |
| pipeline_remediating_fallback | degraded | 0 |
| pipeline_remediating_fallback | degraded | 0 |
| pipeline_remediating_fallback | degraded | 0 |
| pipeline_remediating_fallback | degraded | 0 |
| pipeline_remediating_fallback | degraded | 0 |
| pipeline_remediating_fallback | degraded | 0 |
| pipeline_remediating_fallback | degraded | 0 |
| pipeline_remediating_fallback | degraded | 0 |
| pipeline_remediating_fallback | degraded | 0 |
| pipeline_remediating_fallback | degraded | 0 |
| pipeline_remediating_fallback | degraded | 0 |
| pipeline_remediating_fallback | degraded | 0 |
| pipeline_remediating_fallback | degraded | 0 |
| pipeline_remediating_fallback | degraded | 0 |
| pipeline_remediating_fallback | degraded | 0 |
| pipeline_remediating_fallback | degraded | 0 |
| pipeline_remediating_fallback | degraded | 0 |
| pipeline_remediating_fallback | degraded | 0 |
| pipeline_remediating_fallback | degraded | 0 |
| pipeline_remediating_fallback | degraded | 0 |
| pipeline_remediating_fallback | degraded | 0 |
| pipeline_remediating_fallback | degraded | 0 |
| pipeline_remediating_fallback | degraded | 0 |
| pipeline_remediating_fallback | degraded | 0 |
| pipeline_remediating_fallback | degraded | 0 |
| pipeline_remediating_fallback | degraded | 0 |
| pipeline_remediating_fallback | degraded | 0 |
| pipeline_remediating_fallback | degraded | 0 |
| pipeline_remediating_fallback | degraded | 0 |
| pipeline_remediating_fallback | degraded | 0 |
| pipeline_remediating_fallback | degraded | 0 |
| pipeline_remediating_fallback | degraded | 0 |
| pipeline_remediating_fallback | degraded | 0 |
| pipeline_complete | succeeded | 0 |

## Deterministic Transforms

| Transform Type | Count |
|---------------|-------|
| compliance_normalization | 15 |
| activity_policy_filter | 8 |
| workflow_analyzer_autofix | 7 |
| expression_lint | 2 |
| required_property_enforcement | 2 |

## Quality Gate Summary

- **Passed:** false
- **Total Errors:** 14
- **Total Warnings:** 38
- **Completeness:** functional

## Meta-Validation Summary

- **Engaged:** true
- **Mode:** Always
- **Corrections Applied:** 6
- **Corrections Skipped:** 1
- **Corrections Failed:** 1
- **Confidence Score:** 0.4411764705882353
- **Duration:** 108ms

## Remediations

- {"level":"validation-finding","file":"ExtractInvoiceFields.xaml","remediationCode":"STUB_ACTIVITY_UNKNOWN","reason":"Line 110: Activity \"DigitizeDocument\" has no namespace prefix — Studio will fail to resolve it. Expected a prefix like \"ui:DigitizeDocument\"","classifiedCheck":"unprefixed-activity","developerAction":"Manually implement activity in ExtractInvoiceFields.xaml — estimated 15 min","estimatedEffortMinutes":15}
- {"level":"validation-finding","file":"ExtractInvoiceFields.xaml","remediationCode":"STUB_ACTIVITY_UNKNOWN","reason":"Line 150: Activity \"ExtractDocumentData\" has no namespace prefix — Studio will fail to resolve it. Expected a prefix like \"ui:ExtractDocumentData\"","classifiedCheck":"unprefixed-activity","developerAction":"Manually implement activity in ExtractInvoiceFields.xaml — estimated 15 min","estimatedEffortMinutes":15}
- {"level":"validation-finding","file":"InitialiseConfig.xaml","remediationCode":"STUB_ACTIVITY_UNKNOWN","reason":"Line 612: Undeclared variable \"value\" in expression: value — variable is not declared in any <Variable> block in scope","classifiedCheck":"UNDECLARED_VARIABLE","developerAction":"Manually implement activity in InitialiseConfig.xaml — estimated 15 min","estimatedEffortMinutes":15}
- {"level":"validation-finding","file":"ValidateAndDecide.xaml","remediationCode":"STUB_ACTIVITY_UNKNOWN","reason":"Line 126: .UrlEncode() has unbalanced parentheses in expression: {&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;coupaBaseUrl...","classifiedCheck":"EXPRESSION_SYNTAX_UNFIXABLE","developerAction":"Manually implement activity in ValidateAndDecide.xaml — estimated 15 min","estimatedEffortMinutes":15}
- {"level":"validation-finding","file":"ValidateAndDecide.xaml","remediationCode":"STUB_ACTIVITY_UNKNOWN","reason":"Line 274: .TrimEnd() has unbalanced parentheses in expression: {&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;coupaBaseUrl...","classifiedCheck":"EXPRESSION_SYNTAX_UNFIXABLE","developerAction":"Manually implement activity in ValidateAndDecide.xaml — estimated 15 min","estimatedEffortMinutes":15}
- {"level":"validation-finding","file":"ValidateAndDecide.xaml","remediationCode":"STUB_ACTIVITY_UNKNOWN","reason":"Line 522: Undeclared variable \"value\" in expression: value — variable is not declared in any <Variable> block in scope","classifiedCheck":"UNDECLARED_VARIABLE","developerAction":"Manually implement activity in ValidateAndDecide.xaml — estimated 15 min","estimatedEffortMinutes":15}
- {"level":"validation-finding","file":"ProcessTransaction.xaml","remediationCode":"STUB_ACTIVITY_UNKNOWN","reason":"Line 483: uds:CreateEntityRecord is missing required property \"EntityObject\"","classifiedCheck":"MISSING_REQUIRED_ACTIVITY_PROPERTY","developerAction":"Manually implement activity in ProcessTransaction.xaml — estimated 15 min","estimatedEffortMinutes":15}
- {"level":"activity","file":"InitialiseConfig.xaml","remediationCode":"UNDECLARED_VARIABLE_MANUAL","reason":"Undeclared variable \"value\" — type cannot be auto-inferred (no recognized naming prefix)","classifiedCheck":"UNDECLARED_VARIABLE","developerAction":"Declare variable \"value\" in InitialiseConfig.xaml with the appropriate type. Expression context: value","estimatedEffortMinutes":5}
- {"level":"activity","file":"ValidateAndDecide.xaml","remediationCode":"UNDECLARED_VARIABLE_MANUAL","reason":"Undeclared variable \"value\" — type cannot be auto-inferred (no recognized naming prefix)","classifiedCheck":"UNDECLARED_VARIABLE","developerAction":"Declare variable \"value\" in ValidateAndDecide.xaml with the appropriate type. Expression context: value","estimatedEffortMinutes":5}
- {"level":"activity","file":"","remediationCode":"POST_ASSEMBLY_REPAIR","reason":"[MISSING_REQUIRED_PROPERTY_DEFECT] uds:CreateEntityRecord.EntityObject has no valid source binding and no contract-valid fallback — structured defect, property left absent","classifiedCheck":"post-assembly-repair","developerAction":"uds:CreateEntityRecord.EntityObject has no valid source binding and no contract-valid fallback — structured defect, property left absent","estimatedEffortMinutes":5}
- {"level":"activity","file":"","remediationCode":"POST_ASSEMBLY_REPAIR","reason":"[MISSING_REQUIRED_PROPERTY_DEFECT] uds:CreateEntityRecord.EntityObject has no valid source binding and no contract-valid fallback — structured defect, property left absent","classifiedCheck":"post-assembly-repair","developerAction":"uds:CreateEntityRecord.EntityObject has no valid source binding and no contract-valid fallback — structured defect, property left absent","estimatedEffortMinutes":5}
- {"level":"workflow","file":"Main.xaml","remediationCode":"STUB_WORKFLOW_BLOCKING","reason":"Pre-archive assertion: object_payload_in_target_value_slot — Object payload in target/value slot: <Assign.To><OutArgument x:TypeArguments=\"x:String\">Nothing</OutArgument></Assign.To>\n              <Assign.Value><InArgu","classifiedCheck":"pre-archive-canonicalization","developerAction":"Resolve object_payload_in_target_value_slot in Main.xaml","estimatedEffortMinutes":10}
- {"level":"workflow","file":"Dispatcher.xaml","remediationCode":"STUB_WORKFLOW_BLOCKING","reason":"Pre-archive assertion: object_payload_in_target_value_slot — Object payload in target/value slot: <Assign.To><OutArgument x:TypeArguments=\"x:String\">Nothing</OutArgument></Assign.To>\n              <Assign.Value><InArgu","classifiedCheck":"pre-archive-canonicalization","developerAction":"Resolve object_payload_in_target_value_slot in Dispatcher.xaml","estimatedEffortMinutes":10}
- {"level":"workflow","file":"InitialiseConfig.xaml","remediationCode":"STUB_WORKFLOW_BLOCKING","reason":"Pre-archive assertion: object_payload_in_target_value_slot — Object payload in target/value slot: <Assign.To><OutArgument x:TypeArguments=\"x:String\">Nothing</OutArgument></Assign.To>\n              <Assign.Value><InArgu","classifiedCheck":"pre-archive-canonicalization","developerAction":"Resolve object_payload_in_target_value_slot in InitialiseConfig.xaml","estimatedEffortMinutes":10}
- {"level":"workflow","file":"ProcessTransaction.xaml","remediationCode":"STUB_WORKFLOW_BLOCKING","reason":"Pre-archive assertion: object_payload_in_target_value_slot — Object payload in target/value slot: <Assign.To><OutArgument x:TypeArguments=\"x:String\">Nothing</OutArgument></Assign.To>\n              <Assign.Value><InArgu","classifiedCheck":"pre-archive-canonicalization","developerAction":"Resolve object_payload_in_target_value_slot in ProcessTransaction.xaml","estimatedEffortMinutes":10}
- {"level":"workflow","file":"RetrieveInvoicePdf.xaml","remediationCode":"STUB_WORKFLOW_BLOCKING","reason":"Pre-archive assertion: object_payload_in_target_value_slot — Object payload in target/value slot: <Assign.To><OutArgument x:TypeArguments=\"x:String\">Nothing</OutArgument></Assign.To>\n              <Assign.Value><InArgu","classifiedCheck":"pre-archive-canonicalization","developerAction":"Resolve object_payload_in_target_value_slot in RetrieveInvoicePdf.xaml","estimatedEffortMinutes":10}
- {"level":"workflow","file":"ExtractInvoiceFields.xaml","remediationCode":"STUB_WORKFLOW_BLOCKING","reason":"Pre-archive assertion: object_payload_in_target_value_slot — Object payload in target/value slot: <Assign.To><OutArgument x:TypeArguments=\"x:String\">Nothing</OutArgument></Assign.To>\n              <Assign.Value><InArgu","classifiedCheck":"pre-archive-canonicalization","developerAction":"Resolve object_payload_in_target_value_slot in ExtractInvoiceFields.xaml","estimatedEffortMinutes":10}
- {"level":"workflow","file":"ValidateAndDecide.xaml","remediationCode":"STUB_WORKFLOW_BLOCKING","reason":"Pre-archive assertion: object_payload_in_target_value_slot — Object payload in target/value slot: <Assign.To><OutArgument x:TypeArguments=\"x:String\">Nothing</OutArgument></Assign.To>\n              <Assign.Value><InArgu","classifiedCheck":"pre-archive-canonicalization","developerAction":"Resolve object_payload_in_target_value_slot in ValidateAndDecide.xaml","estimatedEffortMinutes":10}
- {"level":"workflow","file":"InitAllSettings.xaml","remediationCode":"STUB_WORKFLOW_BLOCKING","reason":"Pre-archive assertion: malformed_attribute_quoting — Malformed attribute quoting detected: AssetName=\"[&quot;Cred_Coupa_API&quot;]","classifiedCheck":"pre-archive-canonicalization","developerAction":"Resolve malformed_attribute_quoting in InitAllSettings.xaml","estimatedEffortMinutes":10}

## Auto-Repairs

- {"repairCode":"REPAIR_GENERIC","file":"Main.xaml","description":"Catalog (fallback): Moved ucs:MultipleAssign.Assignments from attribute to child-element in Main.xaml"}
- {"repairCode":"REPAIR_GENERIC","file":"Main.xaml","description":"Catalog (fallback): Moved ui:GetTransactionItem.QueueName from attribute to child-element in Main.xaml"}
- {"repairCode":"REPAIR_GENERIC","file":"Main.xaml","description":"Catalog (fallback): Moved ui:GetTransactionItem.TransactionItem from attribute to child-element in Main.xaml"}
- {"repairCode":"REPAIR_GENERIC","file":"Main.xaml","description":"Catalog (fallback): Moved ucs:MultipleAssign.Assignments from attribute to child-element in Main.xaml"}
- {"repairCode":"REPAIR_GENERIC","file":"Main.xaml","description":"Catalog (fallback): Moved ucs:MultipleAssign.Assignments from attribute to child-element in Main.xaml"}
