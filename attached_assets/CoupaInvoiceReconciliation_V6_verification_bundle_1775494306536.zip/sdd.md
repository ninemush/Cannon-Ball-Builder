## 1. Automation Architecture Overview

### 1.1 Chosen automation type and rationale
**Automation pattern:** **Queue-driven dispatcher–performer (unattended) + human-in-the-loop validation**  
- **RPA (unattended)** is the primary execution model because the process is deterministic (PO match + 5% tolerance + route/reject) and volume is stable (~50/day).  
- **Hybrid** is required due to PDF variability: when Document Understanding confidence is low, a person must confirm fields. This is implemented with **Action Center** (not attended robots) because **only unattended robots (11 slots)** exist and interactive desktop automation is not permitted.  
- **Agents** are **not** used on the critical path (capability detected with limited certainty). They may be used later for analytics/explanations, but the core reconciliation must remain deterministic, auditable, and operable without agent runtime dependencies.

**Why Orchestrator Queues vs Data Service for work dispatch?**  
- Use **Orchestrator Queues** to represent “invoice to be processed” items because they provide built-in **retry, transaction states, SLA visibility, and queue triggers**—the right fit for reliable background throughput and idempotent processing.  
- Use **Data Service** for **case persistence** (invoice run history, extracted/validated fields, decisions, timestamps) and to bind to **Action Center** tasks and reporting.

**Why Integration Service vs custom HTTP to Coupa?**  
- Policy requirement: must use Integration Service connectors. This also reduces maintenance (auth refresh, pagination helpers), improves observability, and centralizes credentials.

**Why Triggers vs Maestro?**  
- For this scope (single intake → validation → route/reject with one optional human validation), **Orchestrator Triggers + Queue triggers** are simpler and more operable than standing up a full BPMN case model in Maestro.  
- Maestro is retained as a future recommendation if the process expands into multi-stage exception management (multi-party approvals, vendor dispute cases, aging/SLA escalations across several steps).

### 1.2 Target-state architecture (logical)
1. **Coupa invoice submission** detected by a **scheduled trigger** (polling) or event trigger (if available through connector/webhook).  
2. **Dispatcher** process pulls new invoices and **adds one queue item per invoice** with Coupa invoice ID and PDF reference.  
3. **Performer** process (REFramework-style transaction) dequeues an invoice, downloads PDF, runs **Document Understanding** extraction (with **Generative Extraction fallback**), validates PO + tolerance via Coupa connector, then **routes** or **rejects** in Coupa.  
4. If extraction confidence is low: create **Action Center** task with a strongly-typed form; after validation, performer resumes and completes Coupa update.  
5. All outcomes persisted to **Data Service** for auditability and operational dashboards; PDFs stored in **Storage Buckets** with retention controls.

### 1.3 Operability / monitoring / SLAs
- **SLA target:** same-day processing; design assumes <5 minutes average automated handling, with human validation SLA (see Action Center SLA below).  
- **Monitoring:**
  - Queue item states (New/In Progress/Successful/Failed) as the primary operational metric.
  - Data Service “InvoiceCase” entity stores timestamps to report aging (Submitted → Picked up → Completed).
- **Alerting approach (tenant-native):**
  - Use Orchestrator queue “Failed” items and job failures as alert sources (integrate to Teams/Twilio later if required; not mandatory for initial deployment).
  - Action Center escalation rules (warning + overdue) ensure human tasks don’t stall.

### 1.4 Deployment topology and licensing implications
- **Robots:** Unattended only; designed for **background execution** and **API-first** integration (no UI dependencies).  
- **Document Understanding:** Uses DU activities and validation station in Action Center (no attended robot needed).  
- **Action Center users:** AP Clerks need Action Center access (licensing depends on your UiPath plan) to complete validation tasks.  
- **Serverless vs classic unattended:** This design is compatible with either; however, because Coupa is API-based here, **serverless robots are a good fit** (no UI, elastic scaling). Final choice depends on tenant capability and machine setup (to be specified in deployment spec section 9).

---

## 2. Process Components and Workflow Breakdown

### 2.1 Orchestrator objects (logical)
- **Queue:** `Coupa_Invoice_Recon_Q` (unique name; no conflict with existing processes)
- **Processes (new, unique):**
  1. `CoupaInvoiceRecon_Dispatcher`
  2. `CoupaInvoiceRecon_Performer`
  3. `CoupaInvoiceRecon_ReprocessFromValidation` (optional helper; can be merged into Performer)

> Note: Existing deployed processes `InvoicePOValidation` / `POInvoiceReconciliation` may contain reusable components (e.g., tolerance calculation). Reuse is recommended only if they are aligned to the approved PDD and can be versioned without breaking current runs.

### 2.2 Workflow 1 — Dispatcher (Unattended, scheduled trigger)
**Name:** `CoupaInvoiceRecon_Dispatcher`  
**Purpose:** Identify new invoice submissions in Coupa since last successful run; enqueue work items.  
**High-level steps:**
1. Read watermark timestamp from Orchestrator Asset `CoupaInvoiceRecon_LastRunUtc`.
2. Query Coupa invoices “Submitted” (or equivalent status) created/updated since watermark.
3. For each invoice:
   - Create/Upsert `InvoiceCase` entity record (Data Service) with status `Queued`.
   - Add Queue Item to `Coupa_Invoice_Recon_Q` with:
     - `CoupaInvoiceId`
     - `VendorId/Name` (if available from metadata)
     - `InvoicePdfUrl/AttachmentId`
     - `SubmittedUtc`
4. Update watermark asset.

**Trigger:** Orchestrator **Process Schedule** every 10 minutes (tunable to meet SLA and Coupa API limits).

**Idempotency:** Before enqueueing, check Data Service for existing open case by `CoupaInvoiceId` with status not in (Completed, Rejected) to avoid duplicates.

### 2.3 Workflow 2 — Performer (Unattended, queue trigger; REFramework-style)
**Name:** `CoupaInvoiceRecon_Performer`  
**Purpose:** Process one invoice transaction reliably with retries and clear business/system exception separation.  
**Pattern:** REFramework-like (Init → Get Transaction → Process → End) using Orchestrator Queue as transaction source.

**Transaction steps (per queue item):**
1. **Load context**:
   - Get `InvoiceCase` by `CoupaInvoiceId`; mark status `InProgress`.
2. **Retrieve PDF**:
   - Download invoice PDF from Coupa; store raw file to Storage Bucket path `invoices/raw/{CoupaInvoiceId}.pdf`.
3. **Document Understanding extraction**:
   - Digitize: OCR (DU pipeline).
   - Extract fields: PO number, Invoice number, Vendor, Amount, Currency (if present).
   - If confidence < thresholds → create Action Center task (see §2.4).
   - If confidence ok → proceed.
4. **PO validation**:
   - Query Coupa PO by extracted PO#.
   - If not found/mismatch → Reject invoice in Coupa with standardized reason `PO_MISMATCH_OR_NOT_FOUND`; update case `Rejected`.
5. **Tolerance check**:
   - Calculate: `Abs(InvoiceTotal - ReferenceAmount) / ReferenceAmount <= 0.05`  
   - ReferenceAmount basis must match business policy (PO total vs remaining); captured as config Asset `ToleranceBasis`.
   - If out of tolerance → Reject in Coupa with reason `OUT_OF_TOLERANCE`; update case `Rejected`.
6. **Route for DOA approval**:
   - Call Coupa action to submit/route invoice into DOA chain.
   - Update case `RoutedForApproval` and end (scope ends at progression to next stage).
7. **Persist audit**:
   - Store extracted + validated fields, decision, timestamps, Coupa response payload reference, and Storage Bucket file paths in Data Service.

**Queue retry policy:**  
- System exceptions: retry up to 2 times with exponential backoff (queue item retry configured).  
- Business exceptions: no retry; mark as successful transaction but outcome “Rejected” (since the process executed correctly).

### 2.4 Human-in-the-loop — Action Center validation
**When created:** extraction confidence below threshold OR missing required fields.  
**Task type:** “Document Validation Task” (via Persistence/Action Center integration) linked to Data Service entity.

**Form schema (Action Center) — `InvoiceValidationForm`**
Fields (all displayed; required fields must be validated):
- `CoupaInvoiceId` (string, read-only)
- `VendorName` (string, read-only if from Coupa; editable if missing)
- `InvoiceNumber` (string, required)
- `InvoiceDate` (date, optional)
- `PONumber` (string, required; regex validation e.g. `^[A-Za-z0-9\-]+$`)
- `Currency` (string, optional; default from Coupa metadata if available)
- `InvoiceTotal` (number/decimal, required; min 0.01)
- `Comments` (string, optional)
- `ValidatorUser` (string, auto-filled from task context)
- `ValidationOutcome` (choice: `Validated`, `CannotDetermine`)

**SLA configuration**
- **Due:** 4 business hours from creation
- **Warning:** 2 business hours
- **Escalation:** if overdue, reassign to `AP_Team_Lead` group (or configured Orchestrator/AC group) and set case flag `ValidationOverdue = true`.

**Resumption mechanism**
- Performer creates task and sets case status `PendingValidation`.
- A dedicated Orchestrator trigger (schedule every 5 minutes) runs `CoupaInvoiceRecon_ReprocessFromValidation` or the performer itself queries for completed tasks:
  - Upon completion, update `InvoiceCase` with validated fields and set status `Validated`.
  - Add a new queue item (or continue within same run if using long-running workflow not required).  
**Design choice:** use **queue-driven resumption** (add new queue item) to avoid long-running suspended jobs and to keep robot slots free.

---

## 3. UiPath Activities and Packages Required

> Only packages with verified versions are listed with versions. Anything not in the verified list is explicitly marked as not verified.

### 3.1 Core orchestration / resilience
- **UiPath.System.Activities 26.2.4**
  - Log Message, Retry Scope pattern (implemented via loops), Take Screenshot (from UIAutomation), Read/Write Text File (local temp), Path Exists, Delay, Rethrow
- **UiPath.ComplexScenarios.Activities 1.5.1**
  - Repeat Until, Build Data Table (if needed for PO lines), Filter/Sort (if needed)

### 3.2 Integration Service (Coupa + other connectors)
- **UiPath.IntegrationService.Activities — version not verified (not in verified catalog)**
  - Integration Service activities to execute Coupa connector operations (Get Invoice, Download Attachment, Get PO, Reject Invoice, Route Invoice)

### 3.3 Document Understanding
- **UiPath.IntelligentOCR.Activities 6.27.3**
  - Digitize Document
  - Classify Document Scope (if multiple doc types later; for now single type “Invoice” still fine)
  - Extract Document Data
  - Validate Document Data (to create validation actions/tasks)

> Generative Extraction uses DU/GenAI integration; activity package for GenAI is not in verified list.  
- **UiPath GenAI Activities — version not verified (not in verified catalog)** (tenant has Integration Service connections for “UiPath GenAI Activities” and “Microsoft Azure OpenAI”)

### 3.4 Action Center / long-running
- **UiPath.Persistence.Activities — version not verified (not in verified catalog)**  
  - Create Task / Wait for Task and Resume pattern (we’ll use create task + queue-based resumption; minimal waiting)

### 3.5 Data persistence (Data Service)
- **UiPath.DataService.Activities 25.9.3**
  - Create Entity Record, Query Entity, Update Entity, Get Entity By Id, Delete Entity (admin use only)

### 3.6 Storage Buckets
- Storage bucket operations are typically via Orchestrator/Storage Bucket activities; package not in verified list.  
- **UiPath.Orchestrator/Storage Bucket activities — version not verified (not in verified catalog)**

### 3.7 UI Automation (for screenshots on errors)
- **UiPath.UIAutomation.Activities 25.10.29**
  - Take Screenshot (even for headless troubleshooting; attach to logs/artifacts where possible)

---

## 4. Integration Points and API/System Connections

### 4.1 Coupa (primary system)
- **Connection method:** Integration Service connector for Coupa (**to be created/configured**; not listed among active connections, so provisioning is required as part of deployment).  
- **Used operations (logical):**
  - Search/List invoices by status/date
  - Get invoice metadata by invoice ID
  - Download invoice PDF attachment
  - Get PO details by PO number
  - Reject invoice with standardized reason code/text
  - Route/submit invoice into DOA chain

**Why not custom HTTP?** Disallowed by design rule; also reduces auth/token handling and improves maintainability.

### 4.2 Microsoft Azure OpenAI (optional; for Generative Extraction fallback)
- **Integration Service connection available:** “Azure OpenAI” (IDs: `ec386c63-e4cd-49f0-abfc-b30571ca0bda`, `1481c109-996d-4aff-b86e-e3a62ed83e17`)  
- **Use:** Only if classic extraction confidence is low or invoice layouts are highly variable. Prompts and outputs are stored in Data Service for audit (with redaction rules as needed).

### 4.3 Data Service (internal)
- Entity operations via **UiPath.DataService.Activities 25.9.3** (Create/Query/Update).  
- Used for cross-run persistence, Action Center linkage, and reporting.

### 4.4 Action Center (internal)
- Task creation and completion used for validation exceptions and SLA escalation.

---

## 5. Exception Handling Strategy

### 5.1 Business exceptions (no retries)
- **PO not found / mismatch:** Reject in Coupa; mark case `Rejected` with reason `PO_MISMATCH_OR_NOT_FOUND`.
- **Out of tolerance:** Reject in Coupa; mark case `Rejected` with reason `OUT_OF_TOLERANCE`.
- **DOA chain rejection:** Out of scope for automation action (Coupa manages). If Coupa provides status callback, we record it asynchronously but do not reprocess.

### 5.2 System exceptions (retries + dead-letter)
Examples: Coupa connector timeout, Storage bucket failure, transient DU service error.
- Use queue retry (2 retries).  
- On final failure:
  - Mark queue item failed with exception details.
  - Update Data Service case `FailedSystem`.
  - Persist evidence: PDF path, last successful step, error screenshot.

### 5.3 Evidence capture (“screenshot on error”)
Every Try/Catch at workflow boundaries will:
1. **Take Screenshot** (UiPath.UIAutomation.Activities 25.10.29) of the current context (even if no UI, it captures desktop state for robot VM)  
2. Write error context to Data Service (stack trace truncated + correlation id)  
3. Store screenshot to Storage Bucket path `evidence/errors/{CoupaInvoiceId}/{timestamp}.png`

### 5.4 Action Center escalation handling
- If validation task overdue:
  - Data Service flag `ValidationOverdue=true`
  - Task reassignment to lead group
  - Optional: create a Teams message (available connector) in later iteration; not required for MVP.

---

## 6. Security Considerations

### 6.1 Credential and secret management
- Store Coupa credentials / OAuth client secrets in **Orchestrator Assets** (Credential or Text assets).
- Integration Service connection uses its own credential vaulting; access controlled by Orchestrator roles.

### 6.2 Access control / RBAC
- Separate Orchestrator folders for Prod/NonProd with least privilege:
  - Robots: execute + queue access + storage bucket access
  - AP Clerks: Action Center task access only (no robot execution rights)
  - Admin/CoE: manage assets, processes, triggers

### 6.3 Data protection
- PDFs stored in Storage Buckets with retention policy and access control.
- Data Service stores only necessary fields; avoid storing full invoice text unless required.
- If Generative Extraction is used: redact sensitive info in prompts where possible; store prompt/output for audit with restricted access.

### 6.4 Auditability
- Data Service provides immutable-ish event trail (via timestamps + outcome fields).
- Orchestrator logs + queue item history provide run-by-run traceability.

---

## 7. Test Strategy

### 7.1 Test approach using Test Manager
- **Test project:** `CoupaInvoiceRecon_Tests`
- **Test suites:**
  1. **Extraction suite**: sample PDFs (high quality, low quality, rotated, multi-page) → verify fields and confidence thresholds.
  2. **Business rule suite**: tolerance boundary tests (4.99%, 5.00%, 5.01%), currency present/absent, PO not found.
  3. **Integration suite** (mock/stage Coupa): validate connector operations (get invoice, reject, route).
  4. **Resilience suite**: simulated timeouts; ensure retries and dead-letter behavior.

### 7.2 UAT
- Run against Coupa UAT with a controlled vendor set; validate rejection reasons and DOA routing behavior.
- Validate Action Center workload: number of tasks/day, completion time, escalations.

---

## 7a. Governance Compliance
Automation Ops is not available, so tenant-wide governance policies cannot be programmatically enforced. This solution design still adheres to common governance expectations:
- Naming conventions for queues/processes/assets are defined and consistent.
- Centralized credential storage (Orchestrator Assets / Integration Service).
- Mandatory exception handling and evidence capture.
- No hard-coded endpoints/secrets in workflows.

(If Automation Ops is enabled later, map policies for allowed packages, logging level, exception handling, and naming conventions to these design choices.)

---

## 8. Data Model and Entity Design (Data Service)

### 8.1 Entity: `InvoiceCase`
**Purpose:** Single source of truth for invoice processing status and audit across runs.

Fields:
- `InvoiceCaseId` (string, primary key or system id)
- `CoupaInvoiceId` (string, unique, required)
- `CoupaInvoiceNumber` (string, nullable)
- `VendorId` (string, nullable)
- `VendorName` (string, nullable)
- `SubmittedUtc` (datetime, required)
- `QueuedUtc` (datetime, nullable)
- `PickedUpUtc` (datetime, nullable)
- `CompletedUtc` (datetime, nullable)

Extraction/validation:
- `ExtractedPONumber` (string, nullable)
- `ExtractedInvoiceNumber` (string, nullable)
- `ExtractedInvoiceTotal` (decimal, nullable)
- `ExtractedCurrency` (string, nullable)
- `ExtractionConfidence` (decimal, nullable)
- `NeedsHumanValidation` (boolean, required, default false)

Validated fields (post Action Center):
- `ValidatedPONumber` (string, nullable)
- `ValidatedInvoiceNumber` (string, nullable)
- `ValidatedInvoiceTotal` (decimal, nullable)
- `ValidatedCurrency` (string, nullable)
- `ValidatedBy` (string, nullable)
- `ValidatedUtc` (datetime, nullable)
- `ValidationOutcome` (string, allowed: `Validated`,`CannotDetermine`)

Business decisions:
- `PONotFound` (boolean, default false)
- `POMismatch` (boolean, default false)
- `ToleranceBasis` (string, e.g., `POTotal` / `PORemaining`)
- `ReferenceAmount` (decimal, nullable)
- `TolerancePercent` (decimal, default 5.0)
- `WithinTolerance` (boolean, nullable)

Outcome:
- `CaseStatus` (string, required; values: `Queued`,`InProgress`,`PendingValidation`,`Validated`,`Rejected`,`RoutedForApproval`,`FailedSystem`)
- `RejectionReasonCode` (string, nullable; values: `PO_MISMATCH_OR_NOT_FOUND`,`OUT_OF_TOLERANCE`,`APPROVAL_REJECTED`(record-only))
- `CoupaActionResult` (string, nullable; short text)
- `CorrelationId` (string, nullable)

Artifacts:
- `PdfBucketPath` (string, nullable)
- `ErrorScreenshotBucketPath` (string, nullable)

Escalation:
- `ValidationDueUtc` (datetime, nullable)
- `ValidationOverdue` (boolean, default false)

### 8.2 Entity: `InvoiceEventLog` (optional but recommended)
**Purpose:** Append-only events for step-level traceability beyond Orchestrator logs.

Fields:
- `EventId` (string/system)
- `CoupaInvoiceId` (string, required; relationship to InvoiceCase by CoupaInvoiceId)
- `EventUtc` (datetime, required)
- `EventType` (string, e.g., `Queued`,`ExtractionCompleted`,`ValidationTaskCreated`,`RejectedInCoupa`,`RoutedInCoupa`,`SystemFailure`)
- `EventDetail` (string, nullable)
- `QueueItemId` (string, nullable)
- `JobId` (string, nullable)

### 8.3 Action Center linkage
- Each Action Center task stores:
  - `CoupaInvoiceId` as business key
  - Reference to `InvoiceCase` record (store `InvoiceCaseId` in task context)
- On completion, validated fields are written back to `InvoiceCase` and an `InvoiceEventLog` entry is created.

---

## Platform Recommendations (not available on tenant)

1. **Environments (not accessible):** Would simplify governance and deployment targeting by grouping machines/robots per environment (Dev/Test/Prod) and controlling process availability consistently. Current design will use folder-based machine assignments instead.
2. **Autopilot (not available):** Could accelerate exception triage (“why rejected?”, “what field missing?”) and generate operator summaries; not required for core automation.
3. **Automation Ops (not available):** Would enforce policies (package allowlists, logging, naming), perform automated risk checks, and standardize best practices across releases.
4. **Automation Store (no external API):** Could standardize reusable invoice DU components and governance artifacts; not critical.
5. **Apps (no external API):** A lightweight AP operations dashboard (case list, aging, exceptions) would significantly improve visibility. With external API support, Apps could be fully provisioned and linked to Data Service entities.
6. **Assistant (no external API):** Not applicable since this solution is unattended; Assistant would matter mainly for attended use cases.

## 9. Orchestrator & Platform Deployment Specification

```orchestrator_artifacts
{
  "queues": [
    {
      "name": "Q_Coupa_InvoiceReconciliation",
      "description": "Primary work queue for Coupa invoice submissions to be processed end-to-end (DU extraction, PO validation, tolerance check, route or reject). Reference = Coupa Invoice ID.",
      "maxRetries": 2,
      "uniqueReference": true
    },
    {
      "name": "Q_Coupa_InvoiceReconciliation_Exceptions",
      "description": "Secondary queue for technical exceptions requiring automatic retry or support intervention (API errors, transient DU service failures). Reference = Coupa Invoice ID + Exception Category.",
      "maxRetries": 3,
      "uniqueReference": true
    }
  ],
  "assets": [
    {
      "name": "Coupa.BaseUrl",
      "type": "Text",
      "value": "https://<your-tenant>.coupahost.com",
      "description": "Coupa tenant base URL used by Integration Service/HTTP calls where needed."
    },
    {
      "name": "Coupa.Polling.Enabled",
      "type": "Bool",
      "value": "true",
      "description": "If event-based triggers are not feasible, enables scheduled polling for new invoices."
    },
    {
      "name": "Coupa.Polling.LookbackMinutes",
      "type": "Integer",
      "value": "60",
      "description": "Polling lookback window (minutes) to capture any missed invoices."
    },
    {
      "name": "Business.TolerancePercent",
      "type": "Integer",
      "value": "5",
      "description": "Tolerance percentage for invoice total vs PO basis amount."
    },
    {
      "name": "Business.ToleranceBasis",
      "type": "Text",
      "value": "PO_TOTAL",
      "description": "Defines tolerance comparison basis. Expected values: PO_TOTAL | PO_REMAINING | LINE_LEVEL (confirm and update per finalized policy)."
    },
    {
      "name": "DU.ConfidenceThreshold",
      "type": "Integer",
      "value": "85",
      "description": "Minimum confidence (0-100) required to proceed without human validation."
    },
    {
      "name": "ActionCenter.SLAHours",
      "type": "Integer",
      "value": "24",
      "description": "SLA for human validation turnaround in Action Center."
    },
    {
      "name": "Storage.RetentionDays",
      "type": "Integer",
      "value": "30",
      "description": "Retention for stored invoice PDFs and processing artifacts in Storage Buckets (align with AP compliance policy)."
    },
    {
      "name": "Orchestrator.FolderName",
      "type": "Text",
      "value": "FIN_AP_InvoiceReconciliation_PRD",
      "description": "Target Orchestrator modern folder for production deployment and runtime isolation."
    },
    {
      "name": "Cred_Coupa_API",
      "type": "Credential",
      "value": "",
      "description": "Credential for Coupa API access if required by connector design (client id/secret, token, or service account)."
    }
  ],
  "machines": [
    {
      "name": "MT_UATD_CoupaInvoiceRecon",
      "type": "Unattended",
      "slots": 3,
      "description": "Unattended execution template for invoice reconciliation. Allocate 3 of 11 available unattended slots to meet throughput and peak handling."
    },
    {
      "name": "MT_DEV_CoupaInvoiceRecon",
      "type": "Development",
      "slots": 1,
      "description": "Development machine template for build/test runs, DU model iteration and regression validation."
    }
  ],
  "triggers": [
    {
      "name": "TRG_CoupaInvoiceRecon_Dispatcher_Polling_5min",
      "type": "Time",
      "cron": "0 */5 * ? * * *",
      "description": "Scheduled dispatcher trigger (polling mode) to detect new Coupa invoice submissions and enqueue items. Used when Coupa event/webhook trigger is not available."
    },
    {
      "name": "TRG_CoupaInvoiceRecon_Performer_Queue",
      "type": "Queue",
      "queueName": "Q_Coupa_InvoiceReconciliation",
      "cron": "",
      "description": "Queue trigger to start performer processing when new invoice items arrive."
    }
  ],
  "storageBuckets": [
    {
      "name": "SB_CoupaInvoiceRecon_Invoices",
      "description": "Stores retrieved invoice PDFs from Coupa for DU processing, validation preview, and audit trace (subject to retention policy)."
    },
    {
      "name": "SB_CoupaInvoiceRecon_Artifacts",
      "description": "Stores processing artifacts (extraction JSON, validation snapshots, API payloads, logs) needed for audit and troubleshooting."
    }
  ],
  "environments": [
    {
      "name": "FIN_AP_InvoiceReconciliation_PROD",
      "type": "Production",
      "description": "Production runtime grouping for AP invoice reconciliation processes (folder-based execution; environments may be informational depending on tenant configuration)."
    },
    {
      "name": "FIN_AP_InvoiceReconciliation_TEST",
      "type": "Testing",
      "description": "Testing runtime grouping for UAT and regression validation."
    },
    {
      "name": "FIN_AP_InvoiceReconciliation_DEV",
      "type": "Development",
      "description": "Development runtime grouping for iterative DU and workflow development."
    }
  ],
  "actionCenter": [
    {
      "taskCatalog": "AC_CoupaInvoiceRecon_DUValidation",
      "assignedRole": "AP Clerk",
      "sla": "24 hours",
      "escalation": "If task not completed within SLA, escalate to AP Team Lead and reassign highest priority; invoice remains pending until validated.",
      "description": "Human validation for low-confidence invoice field extraction (PO#, Invoice#, Vendor, Amount)."
    }
  ],
  "documentUnderstanding": [
    {
      "name": "DU_Coupa_InvoiceReconciliation",
      "documentTypes": [
        "Invoice"
      ],
      "extractionApproach": "hybrid",
      "description": "Invoice extraction using DU with fallback to Generative Extraction for layout variability. Routes to Action Center when confidence is below threshold.",
      "taxonomyFields": [
        {
          "documentType": "Invoice",
          "fields": [
            {
              "name": "PONumber",
              "type": "String"
            },
            {
              "name": "InvoiceNumber",
              "type": "String"
            },
            {
              "name": "VendorName",
              "type": "String"
            },
            {
              "name": "InvoiceDate",
              "type": "String"
            },
            {
              "name": "Currency",
              "type": "String"
            },
            {
              "name": "TotalAmount",
              "type": "Number"
            }
          ]
        }
      ],
      "classifierType": "ML",
      "validationRules": [
        {
          "field": "PONumber",
          "rule": "confidence >= 0.85",
          "action": "flag_for_review"
        },
        {
          "field": "InvoiceNumber",
          "rule": "confidence >= 0.85",
          "action": "flag_for_review"
        },
        {
          "field": "VendorName",
          "rule": "confidence >= 0.80",
          "action": "flag_for_review"
        },
        {
          "field": "TotalAmount",
          "rule": "confidence >= 0.85",
          "action": "flag_for_review"
        }
      ]
    }
  ],
  "requirements": [
    {
      "name": "REQ-001: Unattended-only processing",
      "description": "Automation must run fully unattended; any human involvement must be via Action Center tasks (no attended UI steps).",
      "source": "PDD Section 4, 7"
    },
    {
      "name": "REQ-002: Trigger on new Coupa invoice submissions",
      "description": "Process initiation must occur upon new invoice submission; if event triggers are not feasible, scheduled polling must be used.",
      "source": "PDD Section 4, 8"
    },
    {
      "name": "REQ-003: Retrieve invoice PDF and metadata from Coupa",
      "description": "Automation must programmatically retrieve invoice PDF and metadata required for validation from Coupa.",
      "source": "PDD Section 2, 4, 8"
    },
    {
      "name": "REQ-004: Extract required fields from PDF",
      "description": "Automation must extract PO number, invoice number, vendor, and invoice total from the invoice PDF using Document Understanding.",
      "source": "PDD Section 2, 4"
    },
    {
      "name": "REQ-005: Human validation for low-confidence extraction",
      "description": "When extraction confidence is below threshold, create an Action Center task for AP Clerk validation and resume processing with validated values.",
      "source": "PDD Section 4, 7"
    },
    {
      "name": "REQ-006: Validate PO existence and match",
      "description": "Automation must query Coupa for PO details using extracted/validated PO number and reject invoice if PO not found or mismatch.",
      "source": "PDD Section 4"
    },
    {
      "name": "REQ-007: Apply 5% tolerance rule",
      "description": "Automation must validate invoice amount within 5% tolerance against agreed PO basis amount; otherwise reject with standardized reason.",
      "source": "PDD Section 1, 4, 7"
    },
    {
      "name": "REQ-008: Route compliant invoices into Coupa DOA chain",
      "description": "If validations pass, automation must route invoice to Coupa DOA approval workflow; Coupa remains system of record for approvals.",
      "source": "PDD Section 4"
    },
    {
      "name": "REQ-009: Standardized Coupa rejection reasons",
      "description": "Rejections must use standardized reasons: PO Mismatch/Not Found, Out of Tolerance, Approval Rejected (Coupa outcome).",
      "source": "PDD Section 4"
    },
    {
      "name": "REQ-010: Resubmissions treated as new submissions",
      "description": "Vendor resubmissions must be processed as new invoices without correlation to prior rejects (unless enhanced later).",
      "source": "PDD Section 2, 4, 7"
    },
    {
      "name": "REQ-011: Secure storage and retention for PDFs/artifacts",
      "description": "If temporary storage is required, use UiPath Storage Buckets with retention aligned to AP compliance requirements.",
      "source": "PDD Section 8"
    }
  ],
  "testCases": [
    {
      "name": "TC001 - Happy path: High-confidence extraction, PO match, within tolerance",
      "description": "Valid invoice is extracted with sufficient confidence, PO is found and matches, amount within 5%, then routed to DOA in Coupa.",
      "steps": [
        {
          "action": "Enqueue invoice item with valid Coupa Invoice ID and accessible PDF; DU returns confidence >= thresholds.",
          "expected": "Performer completes without Action Center; invoice routed to DOA; queue item successful."
        }
      ]
    },
    {
      "name": "TC002 - Low-confidence extraction -> Action Center validation -> continue",
      "description": "Invoice extraction confidence below threshold triggers Action Center task; after validation, process resumes and routes/rejects accordingly.",
      "steps": [
        {
          "action": "Provide invoice PDF with low extraction confidence for PO/Amount.",
          "expected": "Action Center task created in AC_CoupaInvoiceRecon_DUValidation; after completion, performer resumes and completes decisioning."
        }
      ]
    },
    {
      "name": "TC003 - Reject: PO not found",
      "description": "Extracted/validated PO does not exist in Coupa; invoice is rejected with standardized reason.",
      "steps": [
        {
          "action": "Submit invoice with PO number not present in Coupa.",
          "expected": "Invoice rejected in Coupa with reason 'PO Not Found/PO Mismatch'; queue item successful (business rejection)."
        }
      ]
    },
    {
      "name": "TC004 - Reject: Out of tolerance (>5%)",
      "description": "Invoice total outside tolerance compared to configured basis; invoice rejected with standardized reason.",
      "steps": [
        {
          "action": "Submit invoice with total amount outside configured 5% tolerance.",
          "expected": "Invoice rejected in Coupa with reason 'Out of Tolerance'; queue item successful (business rejection)."
        }
      ]
    },
    {
      "name": "TC005 - Technical exception: Coupa API transient failure -> retry",
      "description": "Transient API errors should trigger retry behavior and/or route to exception queue after retries.",
      "steps": [
        {
          "action": "Simulate Coupa connector/API returning 5xx or timeout during PO lookup.",
          "expected": "Transaction is retried per queue policy; if still failing, item moved/recorded to Q_Coupa_InvoiceReconciliation_Exceptions with exception details."
        }
      ]
    },
    {
      "name": "TC006 - Resubmission treated as new case",
      "description": "A corrected invoice resubmission should be processed independently as a new invoice.",
      "steps": [
        {
          "action": "Reject an invoice, then submit corrected invoice as a new Coupa Invoice ID.",
          "expected": "New queue item is created and processed without reference to prior invoice outcome."
        }
      ]
    }
  ],
  "testSets": [
    {
      "name": "Happy Path Tests",
      "description": "Core scenario validation for end-to-end automation success.",
      "testCaseNames": [
        "TC001 - Happy path: High-confidence extraction, PO match, within tolerance"
      ]
    },
    {
      "name": "Exception Handling Tests",
      "description": "Validates business and technical exception outcomes including HITL.",
      "testCaseNames": [
        "TC002 - Low-confidence extraction -> Action Center validation -> continue",
        "TC003 - Reject: PO not found",
        "TC004 - Reject: Out of tolerance (>5%)",
        "TC005 - Technical exception: Coupa API transient failure -> retry"
      ]
    },
    {
      "name": "Regression Tests",
      "description": "Ensures stability against key policy and behavior constraints over time.",
      "testCaseNames": [
        "TC006 - Resubmission treated as new case"
      ]
    }
  ],
  "maestroProcesses": [
    {
      "name": "MST_Coupa_InvoiceReconciliation_E2E",
      "description": "End-to-end orchestration combining dispatcher, DU extraction/validation with Action Center, and performer decisioning (route or reject).",
      "serviceTasks": [
        {
          "name": "ST_Dispatch_NewInvoices",
          "processRef": "PRC_Coupa_InvoiceReconciliation_Dispatcher",
          "description": "Polls Coupa for new invoices and adds them to Q_Coupa_InvoiceReconciliation with Coupa Invoice ID as reference."
        },
        {
          "name": "ST_Perform_Reconciliation",
          "processRef": "PRC_Coupa_InvoiceReconciliation_Performer",
          "description": "Processes each invoice: retrieve PDF/metadata, DU extract, validate PO and tolerance, route to DOA or reject."
        }
      ],
      "userTasks": [
        {
          "name": "UT_Validate_InvoiceFields",
          "actionCenterCatalog": "AC_CoupaInvoiceRecon_DUValidation",
          "assignee": "AP Clerk",
          "description": "Human validation of low-confidence extracted fields; returns validated PO#, Invoice#, Vendor, and Amount."
        }
      ],
      "gateways": [
        {
          "name": "GW_ExtractionConfidence_OK",
          "type": "exclusive",
          "conditions": [
            "DU_Confidence >= Threshold",
            "DU_Confidence < Threshold"
          ],
          "description": "Routes flow to either straight-through processing or human validation based on DU confidence."
        }
      ],
      "sequenceFlows": [
        {
          "from": "ST_Dispatch_NewInvoices",
          "to": "ST_Perform_Reconciliation",
          "condition": ""
        },
        {
          "from": "ST_Perform_Reconciliation",
          "to": "GW_ExtractionConfidence_OK",
          "condition": ""
        },
        {
          "from": "GW_ExtractionConfidence_OK",
          "to": "UT_Validate_InvoiceFields",
          "condition": "DU_Confidence < Threshold"
        },
        {
          "from": "UT_Validate_InvoiceFields",
          "to": "ST_Perform_Reconciliation",
          "condition": "ValidationCompleted == true"
        }
      ],
      "crossReferences": {
        "orchestratorProcesses": [
          "PRC_Coupa_InvoiceReconciliation_Dispatcher",
          "PRC_Coupa_InvoiceReconciliation_Performer"
        ],
        "actionCenterCatalogs": [
          "AC_CoupaInvoiceRecon_DUValidation"
        ],
        "queues": [
          "Q_Coupa_InvoiceReconciliation",
          "Q_Coupa_InvoiceReconciliation_Exceptions"
        ]
      }
    }
  ],
  "integrationServiceConnectors": [
    {
      "connectorName": "Microsoft Azure OpenAI",
      "connectionName": "Azure OpenAI",
      "connectionId": "ec386c63-e4cd-49f0-abfc-b30571ca0bda",
      "usedActions": [
        "Chat Completions",
        "Completions"
      ],
      "usedTriggers": [],
      "description": "Optional dependency for Generative Extraction assistance and prompt-based normalization (e.g., vendor name cleanup) within DU hybrid approach.",
      "packageDependency": "UiPath.IntegrationService.Activities"
    }
  ]
}
```