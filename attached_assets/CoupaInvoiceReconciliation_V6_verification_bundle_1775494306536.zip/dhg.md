# Developer Handoff Guide

**Project:** CoupaInvoiceReconciliation
**Generated:** 2026-04-06
**Generation Mode:** Baseline Openable (minimal, deterministic)
**Deployment Readiness:** Needs Work (62%)

**9 workflows: 1 fully generated, 0 with handoff blocks, 8 workflow-level stubs**
**Total Estimated Effort: ~205 minutes (3.4 hours)**
**Remediations:** 19 total (0 property, 4 activity, 0 sequence, 0 structural-leaf, 8 workflow)
**Auto-Repairs:** 5
**Quality Warnings:** 76

---

### Per-Workflow Preservation Summary

| # | Workflow | Tier | Business Steps (SDD) | Preserved | Degraded (Handoff) | Manual | Bind Points |
|---|----------|------|-------------|-----------|-------------------|--------|-------------|
| 1 | `Main.xaml` | Stub | 2 | 0 | 0 | 2 | 0 |
| 2 | `Dispatcher.xaml` | Stub | 2 | 0 | 0 | 2 | 0 |
| 3 | `InitialiseConfig.xaml` | Stub | 2 | 0 | 1 | 2 | 0 |
| 4 | `ProcessTransaction.xaml` | Stub | 2 | 0 | 0 | 2 | 0 |
| 5 | `RetrieveInvoicePdf.xaml` | Stub | 2 | 0 | 0 | 2 | 0 |
| 6 | `ExtractInvoiceFields.xaml` | Stub | 2 | 0 | 0 | 2 | 0 |
| 7 | `CreateValidationTask.xaml` | Generated | 2 | 2 | 0 | 0 | 0 |
| 8 | `ValidateAndDecide.xaml` | Stub | 2 | 0 | 1 | 2 | 0 |
| 9 | `InitAllSettings.xaml` | Stub | 2 | 0 | 0 | 2 | 0 |

## 1. Generated Logic (ready to use)

Generated XAML that is Studio-openable and does not contain handoff blocks or workflow-level stubs. May include auto-resolved property remediations or placeholders for fine-tuning.

The following 1 workflow(s) were fully generated and are ready to use:

| # | Workflow | Status | Studio Compatibility |
|---|----------|--------|---------------------|
| 1 | `CreateValidationTask.xaml` | Generated with Placeholders | Studio-openable |

### AI-Resolved with Smart Defaults (5)

The following issue(s) were automatically corrected during the build pipeline. **No developer action required.**

| # | Code | File | Description | Est. Minutes Saved |
|---|------|------|-------------|-------------------|
| 1 | `REPAIR_GENERIC` | `Main.xaml` | Catalog (fallback): Moved ucs:MultipleAssign.Assignments from attribute to child-element in Main.... | undefined |
| 2 | `REPAIR_GENERIC` | `Main.xaml` | Catalog (fallback): Moved ui:GetTransactionItem.QueueName from attribute to child-element in Main... | undefined |
| 3 | `REPAIR_GENERIC` | `Main.xaml` | Catalog (fallback): Moved ui:GetTransactionItem.TransactionItem from attribute to child-element i... | undefined |
| 4 | `REPAIR_GENERIC` | `Main.xaml` | Catalog (fallback): Moved ucs:MultipleAssign.Assignments from attribute to child-element in Main.... | undefined |
| 5 | `REPAIR_GENERIC` | `Main.xaml` | Catalog (fallback): Moved ucs:MultipleAssign.Assignments from attribute to child-element in Main.... | undefined |

### Studio Compatibility

| # | Workflow | Compatibility | Failure Category | Blockers |
|---|----------|--------------|-----------------|----------|
| 1 | `Main.xaml` | Studio-openable | — | — |
| 2 | `Dispatcher.xaml` | Studio-openable | — | — |
| 3 | `InitialiseConfig.xaml` | Studio-openable | — | — |
| 4 | `ProcessTransaction.xaml` | Studio-openable | — | — |
| 5 | `RetrieveInvoicePdf.xaml` | Studio-openable | — | — |
| 6 | `ExtractInvoiceFields.xaml` | Studio-openable | — | — |
| 7 | `CreateValidationTask.xaml` | Studio-openable | — | — |
| 8 | `ValidateAndDecide.xaml` | Studio-openable | — | — |
| 9 | `InitAllSettings.xaml` | Studio-openable | — | — |

**Summary:** 9 Studio-loadable, 0 with warnings, 0 not Studio-loadable

## 2. Handoff Blocks (business logic preserved, implementation required)

Blocks where business logic is preserved as documentation but implementation requires manual Studio work. Each entry includes the workflow file, block type, business description from the SDD (when available), expected inputs/outputs, and the developer action required.

**4 handoff block(s) requiring manual implementation**

#### 1. `InitialiseConfig.xaml` — — (activity)

- **Workflow File:** `InitialiseConfig.xaml`
- **Block Type:** activity
- **Business Description (SDD):** —
- **Business Rule:** —
- **Expected Inputs:** —
- **Expected Outputs:** —
- **Contained Activities:** —
- **Remediation Code:** `UNDECLARED_VARIABLE_MANUAL`
- **Developer Action:** Declare variable "value" in InitialiseConfig.xaml with the appropriate type. Expression context: value
- **Estimated Effort:** 5 minutes

#### 2. `ValidateAndDecide.xaml` — — (activity)

- **Workflow File:** `ValidateAndDecide.xaml`
- **Block Type:** activity
- **Business Description (SDD):** —
- **Business Rule:** —
- **Expected Inputs:** —
- **Expected Outputs:** —
- **Contained Activities:** —
- **Remediation Code:** `UNDECLARED_VARIABLE_MANUAL`
- **Developer Action:** Declare variable "value" in ValidateAndDecide.xaml with the appropriate type. Expression context: value
- **Estimated Effort:** 5 minutes

#### 3. `` — — (activity)

- **Workflow File:** ``
- **Block Type:** activity
- **Business Description (SDD):** —
- **Business Rule:** —
- **Expected Inputs:** —
- **Expected Outputs:** —
- **Contained Activities:** —
- **Remediation Code:** `POST_ASSEMBLY_REPAIR`
- **Developer Action:** uds:CreateEntityRecord.EntityObject has no valid source binding and no contract-valid fallback — structured defect, property left absent
- **Estimated Effort:** 5 minutes

#### 4. `` — — (activity)

- **Workflow File:** ``
- **Block Type:** activity
- **Business Description (SDD):** —
- **Business Rule:** —
- **Expected Inputs:** —
- **Expected Outputs:** —
- **Contained Activities:** —
- **Remediation Code:** `POST_ASSEMBLY_REPAIR`
- **Developer Action:** uds:CreateEntityRecord.EntityObject has no valid source binding and no contract-valid fallback — structured defect, property left absent
- **Estimated Effort:** 5 minutes

## 3. Manual Work Remaining

Consolidated developer TODO list organized by workflow, with estimated effort per item.

**95 items remaining — ~965 minutes (16.1 hours) total estimated effort**

### Dispatcher.xaml (10 items, ~100 min)

| # | Priority | Category | Description | Developer Action | Est. Minutes |
|---|----------|----------|-------------|-----------------|-------------|
| 1 | High | Workflow Stub | Entire workflow `Dispatcher.xaml` replaced with Studio-openable stub | Resolve object_payload_in_target_value_slot in Dispatcher.xaml | 10 |
| 2 | Low | Quality Warning | hardcoded-credential: Potential hardcoded credential detected (pattern: passw... | Review and address | 10 |
| 3 | Low | Quality Warning | hardcoded-retry-interval: Line 328: retry interval hardcoded as "{&quot;type&... | Review and address | 10 |
| 4 | Low | Quality Warning | hardcoded-asset-name: Line 77: asset name "{&quot;type&quot;:&quot;literal&qu... | Review and address | 10 |
| 5 | Low | Quality Warning | hardcoded-asset-name: Line 116: asset name "{&quot;type&quot;:&quot;literal&q... | Review and address | 10 |
| 6 | Low | Quality Warning | hardcoded-asset-name: Line 155: asset name "{&quot;type&quot;:&quot;literal&q... | Review and address | 10 |
| 7 | Low | Quality Warning | hardcoded-asset-name: Line 194: asset name "{&quot;type&quot;:&quot;literal&q... | Review and address | 10 |
| 8 | Low | Quality Warning | hardcoded-asset-name: Line 233: asset name "{&quot;type&quot;:&quot;literal&q... | Review and address | 10 |
| 9 | Low | Quality Warning | hardcoded-asset-name: Line 272: asset name "{&quot;type&quot;:&quot;literal&q... | Review and address | 10 |
| 10 | Low | Quality Warning | COMPLEX_EXPRESSION_PASSTHROUGH: Line 563: Complex expression (lambdas, LINQ, ... | Review and address | 10 |

### ExtractInvoiceFields.xaml (5 items, ~60 min)

| # | Priority | Category | Description | Developer Action | Est. Minutes |
|---|----------|----------|-------------|-----------------|-------------|
| 11 | High | Workflow Stub | Entire workflow `ExtractInvoiceFields.xaml` replaced with Studio-openable stub | Resolve object_payload_in_target_value_slot in ExtractInvoiceFields.xaml | 10 |
| 12 | Low | Validation Finding | Quality gate finding: `unprefixed-activity` | Manually implement activity in ExtractInvoiceFields.xaml — estimated 15 min | 15 |
| 13 | Low | Validation Finding | Quality gate finding: `unprefixed-activity` | Manually implement activity in ExtractInvoiceFields.xaml — estimated 15 min | 15 |
| 14 | Low | Implementation Required | Contains 1 placeholder value(s) matching "\bPLACEHOLDER\b" [Developer Impleme... | Implement in Studio | 10 |
| 15 | Low | Quality Warning | COMPLEX_EXPRESSION_PASSTHROUGH: Line 611: Complex expression (lambdas, LINQ, ... | Review and address | 10 |

### InitAllSettings.xaml (14 items, ~140 min)

| # | Priority | Category | Description | Developer Action | Est. Minutes |
|---|----------|----------|-------------|-----------------|-------------|
| 16 | High | Workflow Stub | Entire workflow `InitAllSettings.xaml` replaced with Studio-openable stub | Resolve malformed_attribute_quoting in InitAllSettings.xaml | 10 |
| 17 | Low | Quality Warning | hardcoded-asset-name: Line 100: asset name "Cred_Coupa_API" is hardcoded — co... | Review and address | 10 |
| 18 | Low | Quality Warning | hardcoded-asset-name: Line 105: asset name "Coupa.BaseUrl" is hardcoded — con... | Review and address | 10 |
| 19 | Low | Quality Warning | hardcoded-asset-name: Line 114: asset name "Coupa.Polling.Enabled" is hardcod... | Review and address | 10 |
| 20 | Low | Quality Warning | hardcoded-asset-name: Line 123: asset name "Coupa.Polling.LookbackMinutes" is... | Review and address | 10 |
| 21 | Low | Quality Warning | hardcoded-asset-name: Line 132: asset name "Business.TolerancePercent" is har... | Review and address | 10 |
| 22 | Low | Quality Warning | hardcoded-asset-name: Line 141: asset name "Business.ToleranceBasis" is hardc... | Review and address | 10 |
| 23 | Low | Quality Warning | hardcoded-asset-name: Line 150: asset name "DU.ConfidenceThreshold" is hardco... | Review and address | 10 |
| 24 | Low | Quality Warning | hardcoded-asset-name: Line 159: asset name "ActionCenter.SLAHours" is hardcod... | Review and address | 10 |
| 25 | Low | Quality Warning | hardcoded-asset-name: Line 168: asset name "Storage.RetentionDays" is hardcod... | Review and address | 10 |
| 26 | Low | Quality Warning | hardcoded-asset-name: Line 177: asset name "Orchestrator.FolderName" is hardc... | Review and address | 10 |
| 27 | Low | Quality Warning | BARE_TOKEN_QUOTED: Auto-quoted bare token "Settings" for uexcel:ExcelReadRang... | Review and address | 10 |
| 28 | Low | Quality Warning | BARE_TOKEN_QUOTED: Auto-quoted bare token "Constants" for uexcel:ExcelReadRan... | Review and address | 10 |
| 29 | Low | Quality Warning | BARE_TOKEN_QUOTED: Auto-quoted bare token "Cred_Coupa_API" for ui:GetCredenti... | Review and address | 10 |

### InitialiseConfig.xaml (23 items, ~230 min)

| # | Priority | Category | Description | Developer Action | Est. Minutes |
|---|----------|----------|-------------|-----------------|-------------|
| 30 | High | Workflow Stub | Entire workflow `InitialiseConfig.xaml` replaced with Studio-openable stub | Resolve object_payload_in_target_value_slot in InitialiseConfig.xaml | 10 |
| 31 | Medium | Activity Stub | Activity "unknown" stubbed | Declare variable "value" in InitialiseConfig.xaml with the appropriate type. ... | 5 |
| 32 | Low | Validation Finding | Quality gate finding: `UNDECLARED_VARIABLE` | Manually implement activity in InitialiseConfig.xaml — estimated 15 min | 15 |
| 33 | Low | Implementation Required | Contains 1 placeholder value(s) matching "\bPLACEHOLDER\b" [Developer Impleme... | Implement in Studio | 10 |
| 34 | Low | Quality Warning | hardcoded-credential: Potential hardcoded credential detected (pattern: passw... | Review and address | 10 |
| 35 | Low | Quality Warning | hardcoded-asset-name: Line 71: asset name "{&quot;type&quot;:&quot;literal&qu... | Review and address | 10 |
| 36 | Low | Quality Warning | hardcoded-asset-name: Line 110: asset name "{&quot;type&quot;:&quot;literal&q... | Review and address | 10 |
| 37 | Low | Quality Warning | hardcoded-asset-name: Line 149: asset name "{&quot;type&quot;:&quot;literal&q... | Review and address | 10 |
| 38 | Low | Quality Warning | hardcoded-asset-name: Line 188: asset name "{&quot;type&quot;:&quot;literal&q... | Review and address | 10 |
| 39 | Low | Quality Warning | hardcoded-asset-name: Line 227: asset name "{&quot;type&quot;:&quot;literal&q... | Review and address | 10 |
| 40 | Low | Quality Warning | hardcoded-asset-name: Line 266: asset name "{&quot;type&quot;:&quot;literal&q... | Review and address | 10 |
| 41 | Low | Quality Warning | hardcoded-asset-name: Line 305: asset name "{&quot;type&quot;:&quot;literal&q... | Review and address | 10 |
| 42 | Low | Quality Warning | hardcoded-asset-name: Line 344: asset name "{&quot;type&quot;:&quot;literal&q... | Review and address | 10 |
| 43 | Low | Quality Warning | hardcoded-asset-name: Line 383: asset name "{&quot;type&quot;:&quot;literal&q... | Review and address | 10 |
| 44 | Low | Quality Warning | hardcoded-asset-name: Line 422: asset name "{&quot;type&quot;:&quot;literal&q... | Review and address | 10 |
| 45 | Low | Quality Warning | EXPRESSION_SYNTAX: Line 472: C# 'null' should be VB.NET 'Nothing' in expressi... | Review and address | 10 |
| 46 | Low | Quality Warning | EXPRESSION_SYNTAX: Line 480: Unbalanced parentheses: 1 open vs 0 close — appe... | Review and address | 10 |
| 47 | Low | Quality Warning | EXPRESSION_SYNTAX: Line 488: Unbalanced parentheses: 1 open vs 0 close — appe... | Review and address | 10 |
| 48 | Low | Quality Warning | EXPRESSION_SYNTAX: Line 496: Unbalanced parentheses: 1 open vs 0 close — appe... | Review and address | 10 |
| 49 | Low | Quality Warning | EXPRESSION_SYNTAX: Line 504: Unbalanced parentheses: 1 open vs 0 close — appe... | Review and address | 10 |
| 50 | Low | Quality Warning | EXPRESSION_SYNTAX: Line 512: Unbalanced parentheses: 1 open vs 0 close — appe... | Review and address | 10 |
| 51 | Low | Quality Warning | EXPRESSION_SYNTAX: Line 520: Unbalanced parentheses: 0 open vs 1 close — remo... | Review and address | 10 |
| 52 | Low | Quality Warning | EXPRESSION_SYNTAX: Line 524: C# 'null' should be VB.NET 'Nothing' in expressi... | Review and address | 10 |

### Main.xaml (1 item, ~10 min)

| # | Priority | Category | Description | Developer Action | Est. Minutes |
|---|----------|----------|-------------|-----------------|-------------|
| 53 | High | Workflow Stub | Entire workflow `Main.xaml` replaced with Studio-openable stub | Resolve object_payload_in_target_value_slot in Main.xaml | 10 |

### ProcessTransaction.xaml (4 items, ~45 min)

| # | Priority | Category | Description | Developer Action | Est. Minutes |
|---|----------|----------|-------------|-----------------|-------------|
| 54 | High | Workflow Stub | Entire workflow `ProcessTransaction.xaml` replaced with Studio-openable stub | Resolve object_payload_in_target_value_slot in ProcessTransaction.xaml | 10 |
| 55 | Low | Validation Finding | Quality gate finding: `MISSING_REQUIRED_ACTIVITY_PROPERTY` | Manually implement activity in ProcessTransaction.xaml — estimated 15 min | 15 |
| 56 | Low | Implementation Required | Contains 1 placeholder value(s) matching "\bPLACEHOLDER\b" [Developer Impleme... | Implement in Studio | 10 |
| 57 | Low | Quality Warning | COMPLEX_EXPRESSION_PASSTHROUGH: Line 198: Complex expression (lambdas, LINQ, ... | Review and address | 10 |

### RetrieveInvoicePdf.xaml (10 items, ~100 min)

| # | Priority | Category | Description | Developer Action | Est. Minutes |
|---|----------|----------|-------------|-----------------|-------------|
| 58 | High | Workflow Stub | Entire workflow `RetrieveInvoicePdf.xaml` replaced with Studio-openable stub | Resolve object_payload_in_target_value_slot in RetrieveInvoicePdf.xaml | 10 |
| 59 | Low | Implementation Required | Contains 1 placeholder value(s) matching "\bPLACEHOLDER\b" [Developer Impleme... | Implement in Studio | 10 |
| 60 | Low | Quality Warning | hardcoded-retry-count: Line 217: retry count hardcoded as 3 — consider extern... | Review and address | 10 |
| 61 | Low | Quality Warning | hardcoded-retry-count: Line 442: retry count hardcoded as 3 — consider extern... | Review and address | 10 |
| 62 | Low | Quality Warning | hardcoded-retry-interval: Line 169: retry interval hardcoded as "{&quot;type&... | Review and address | 10 |
| 63 | Low | Quality Warning | hardcoded-retry-interval: Line 217: retry interval hardcoded as "00:00:05" — ... | Review and address | 10 |
| 64 | Low | Quality Warning | hardcoded-retry-interval: Line 442: retry interval hardcoded as "00:00:05" — ... | Review and address | 10 |
| 65 | Low | Quality Warning | hardcoded-asset-name: Line 70: asset name "{&quot;type&quot;:&quot;literal&qu... | Review and address | 10 |
| 66 | Low | Quality Warning | RETRY_INTERVAL_DEFAULTED: Post-repair: RetryInterval defaulted to "00:00:05" ... | Review and address | 10 |
| 67 | Low | Quality Warning | RETRY_INTERVAL_DEFAULTED: Post-repair: RetryInterval defaulted to "00:00:05" ... | Review and address | 10 |

### ValidateAndDecide.xaml (12 items, ~130 min)

| # | Priority | Category | Description | Developer Action | Est. Minutes |
|---|----------|----------|-------------|-----------------|-------------|
| 68 | High | Workflow Stub | Entire workflow `ValidateAndDecide.xaml` replaced with Studio-openable stub | Resolve object_payload_in_target_value_slot in ValidateAndDecide.xaml | 10 |
| 69 | Medium | Activity Stub | Activity "unknown" stubbed | Declare variable "value" in ValidateAndDecide.xaml with the appropriate type.... | 5 |
| 70 | Low | Validation Finding | Quality gate finding: `EXPRESSION_SYNTAX_UNFIXABLE` | Manually implement activity in ValidateAndDecide.xaml — estimated 15 min | 15 |
| 71 | Low | Validation Finding | Quality gate finding: `EXPRESSION_SYNTAX_UNFIXABLE` | Manually implement activity in ValidateAndDecide.xaml — estimated 15 min | 15 |
| 72 | Low | Validation Finding | Quality gate finding: `UNDECLARED_VARIABLE` | Manually implement activity in ValidateAndDecide.xaml — estimated 15 min | 15 |
| 73 | Low | Implementation Required | Contains 1 placeholder value(s) matching "\bPLACEHOLDER\b" [Developer Impleme... | Implement in Studio | 10 |
| 74 | Low | Quality Warning | hardcoded-retry-count: Line 175: retry count hardcoded as 3 — consider extern... | Review and address | 10 |
| 75 | Low | Quality Warning | hardcoded-retry-interval: Line 132: retry interval hardcoded as "{&quot;type&... | Review and address | 10 |
| 76 | Low | Quality Warning | hardcoded-retry-interval: Line 175: retry interval hardcoded as "00:00:05" — ... | Review and address | 10 |
| 77 | Low | Quality Warning | EXPRESSION_SYNTAX: Line 126: Unbalanced parentheses: 1 open vs 2 close — remo... | Review and address | 10 |
| 78 | Low | Quality Warning | EXPRESSION_SYNTAX: Line 274: Unbalanced parentheses: 0 open vs 1 close — remo... | Review and address | 10 |
| 79 | Low | Quality Warning | RETRY_INTERVAL_DEFAULTED: Post-repair: RetryInterval defaulted to "00:00:05" ... | Review and address | 10 |

### Unknown.xaml (2 items, ~10 min)

| # | Priority | Category | Description | Developer Action | Est. Minutes |
|---|----------|----------|-------------|-----------------|-------------|
| 80 | Medium | Activity Stub | Activity "unknown" stubbed | uds:CreateEntityRecord.EntityObject has no valid source binding and no contra... | 5 |
| 81 | Medium | Activity Stub | Activity "unknown" stubbed | uds:CreateEntityRecord.EntityObject has no valid source binding and no contra... | 5 |

### CreateValidationTask.xaml (3 items, ~30 min)

| # | Priority | Category | Description | Developer Action | Est. Minutes |
|---|----------|----------|-------------|-----------------|-------------|
| 82 | Low | Implementation Required | Contains 1 placeholder value(s) matching "\bPLACEHOLDER\b" [Developer Impleme... | Implement in Studio | 10 |
| 83 | Low | Quality Warning | hardcoded-asset-name: Line 70: asset name "{&quot;type&quot;:&quot;literal&qu... | Review and address | 10 |
| 84 | Low | Quality Warning | COMPLEX_EXPRESSION_PASSTHROUGH: Line 159: Complex expression (lambdas, LINQ, ... | Review and address | 10 |

### orchestrator.xaml (11 items, ~110 min)

| # | Priority | Category | Description | Developer Action | Est. Minutes |
|---|----------|----------|-------------|-----------------|-------------|
| 85 | Low | Quality Warning | undeclared-asset: Asset "{type:literal,value:Coupa.BaseUrl}" is referenced in... | Review and address | 10 |
| 86 | Low | Quality Warning | undeclared-asset: Asset "{type:literal,value:Coupa.Polling.Enabled}" is refer... | Review and address | 10 |
| 87 | Low | Quality Warning | undeclared-asset: Asset "{type:literal,value:Coupa.Polling.LookbackMinutes}" ... | Review and address | 10 |
| 88 | Low | Quality Warning | undeclared-asset: Asset "{type:literal,value:Orchestrator.FolderName}" is ref... | Review and address | 10 |
| 89 | Low | Quality Warning | undeclared-asset: Asset "{type:literal,value:Cred_Coupa_API}" is referenced i... | Review and address | 10 |
| 90 | Low | Quality Warning | undeclared-asset: Asset "{type:literal,value:CoupaInvoiceRecon_LastRunUtc}" i... | Review and address | 10 |
| 91 | Low | Quality Warning | undeclared-asset: Asset "{type:literal,value:Business.TolerancePercent}" is r... | Review and address | 10 |
| 92 | Low | Quality Warning | undeclared-asset: Asset "{type:literal,value:Business.ToleranceBasis}" is ref... | Review and address | 10 |
| 93 | Low | Quality Warning | undeclared-asset: Asset "{type:literal,value:DU.ConfidenceThreshold}" is refe... | Review and address | 10 |
| 94 | Low | Quality Warning | undeclared-asset: Asset "{type:literal,value:ActionCenter.SLAHours}" is refer... | Review and address | 10 |
| 95 | Low | Quality Warning | undeclared-asset: Asset "{type:literal,value:Storage.RetentionDays}" is refer... | Review and address | 10 |

## 4. Process Context (from Pipeline)

### Idea Description

Test recon

### PDD Summary

## 1. Executive Summary
This Process Design Document (PDD) defines the current (“As‑Is”) and future (“To‑Be”) process for Purchase Order (PO) and invoice reconciliation in Coupa. Today, vendors submit invoices as PDFs directly in Coupa. An AP Clerk manually opens each invoice, checks that the PO number matches the Coupa PO, verifies the invoice amount is within a 5% tolerance, and then routes compliant invoices into Coupa’s Delegation of Authority (DOA) approval chain. Invoices that fail validation are rejected in Coupa; the vendor corrects and resubmits, which is treated as a new invoice submission. The process runs at approximately 50 invoices per day and currently takes around 10 minutes per invoice, creating a high daily manual workload.

The proposed To‑Be design implements an unattended, fully autonomous workflow using UiPath Orchestrator triggers, Integration Service connectivity to Coupa, and Document Understanding to extract invoice fields from PDFs. The automation validates PO existence/match and applies the 5% tolerance rule. When extraction confidence is insufficient, the invoice is routed to Action Center for human validation and then resumes automated processing. Successful invoices are routed into the Coupa DOA approval chain; failed invoices are rejected in Coupa with standardized rejection reasons. The automation ends when the invoice is either rejected or progressed to the next stage, consistent with the defined scope.

## 2. Process Scope
The scope of this PDD begins when a vendor submits an invoice (PDF) into Coupa and ends when the invoice is either (a) rejected in Coupa due to PO mismatch/not found, out‑of‑tolerance amount, or DOA rejection, or (b) routed for and approved through Coupa’s DOA chain and thereby progressed to the next stage.

In scope are: retrieval of invoice PDF and invoice metadata from Coupa; extraction of key fields (PO number, invoice number, vendor, invoice amount) from the submitted PDF; validation that the PO exists and m...

### SDD Summary

## 1. Automation Architecture Overview

### 1.1 Chosen automation type and rationale
**Automation pattern:** **Queue-driven dispatcher–performer (unattended) + human-in-the-loop validation**  
- **RPA (unattended)** is the primary execution model because the process is deterministic (PO match + 5% tolerance + route/reject) and volume is stable (~50/day).  
- **Hybrid** is required due to PDF variability: when Document Understanding confidence is low, a person must confirm fields. This is implemented with **Action Center** (not attended robots) because **only unattended robots (11 slots)** exist and interactive desktop automation is not permitted.  
- **Agents** are **not** used on the critical path (capability detected with limited certainty). They may be used later for analytics/explanations, but the core reconciliation must remain deterministic, auditable, and operable without agent runtime dependencies.

**Why Orchestrator Queues vs Data Service for work dispatch?**  
- Use **Orchestrator Queues** to represent “invoice to be processed” items because they provide built-in **retry, transaction states, SLA visibility, and queue triggers**—the right fit for reliable background throughput and idempotent processing.  
- Use **Data Service** for **case persistence** (invoice run history, extracted/validated fields, decisions, timestamps) and to bind to **Action Center** tasks and reporting.

**Why Integration Service vs custom HTTP to Coupa?**  
- Policy requirement: must use Integration Service connectors. This also reduces maintenance (auth refresh, pagination helpers), improves observability, and centralizes credentials.

**Why Triggers vs Maestro?**  
- For this scope (single intake → validation → route/reject with one optional human validation), **Orchestrator Triggers + Queue triggers** are simpler and more operable than standing up a full BPMN case model in Maestro.  
- Maestro is retained as a future recommendation if the process expands into multi-stage excepti...

**Automation Type:** rpa
**Rationale:** The inputs are structured (Coupa invoice + PO fields) and the decisions are deterministic (PO match, 5% tolerance, DOA workflow), making this a high-volume, rules-based unattended RPA use case with optional human-in-loop only for low-confidence extraction.
**Feasibility Complexity:** medium
**Effort Estimate:** 2-4 weeks

## 5. Business Process Overview

### Process Steps

| # | Step | Role | System | Type | Pain Point |
|---|------|------|--------|------|------------|
| 1 | Invoice Submitted in Coupa Triggers Automation | System | Orchestrator Trigger | start | — |
| 2 | Retrieve Invoice PDF + Metadata from Coupa | System | Coupa (via Integration Service connector) | task | — |
| 3 | Extract Invoice Fields from PDF (PO#, Invoice#, Amount, Vendor) | System | Document Understanding (Invoice taxonomy) | task | — |
| 4 | Extraction Confidence OK? | System | Document Understanding | decision | — |
| 5 | Send to Human Validation | AP Clerk | Action Center | task | — |
| 6 | Apply Validated Fields | System | Action Center | task | — |
| 7 | Get PO Details from Coupa for Extracted PO# | System | Coupa (via Integration Service connector) | task | — |
| 8 | Get PO Details from Coupa for Validated PO# | System | Coupa (via Integration Service connector) | task | — |
| 9 | PO Found and Matches Invoice PO? | System | Coupa | decision | — |
| 10 | Reject Invoice in Coupa (PO Mismatch/Not Found) | System | Coupa (via Integration Service connector) | task | — |
| 11 | Amount Within 5% Tolerance? | System | Business Rules | decision | — |
| 12 | Route Invoice for DOA Approval in Coupa | System | Coupa (via Integration Service connector) | task | — |
| 13 | Reject Invoice in Coupa (Out of Tolerance) | System | Coupa (via Integration Service connector) | task | — |
| 14 | Invoice Progressed to Next Stage End | System | Coupa | end | — |
| 15 | Invoice Rejected End | System | Coupa | end | — |

### Target Applications / Systems

The following applications were identified from the process map and must be accessible from the robot machine:

- Orchestrator Trigger
- Coupa (via Integration Service connector)
- Document Understanding (Invoice taxonomy)
- Document Understanding
- Action Center
- Coupa
- Business Rules

### User Roles Involved

- System
- AP Clerk

### Decision Points (Process Map Topology)

**Extraction Confidence OK?**
  - [No] → Send to Human Validation
  - [Yes] → Get PO Details from Coupa for Extracted PO#

**PO Found and Matches Invoice PO?**
  - [No] → Reject Invoice in Coupa (PO Mismatch/Not Found)
  - [Yes] → Amount Within 5% Tolerance?

**Amount Within 5% Tolerance?**
  - [Yes] → Route Invoice for DOA Approval in Coupa
  - [No] → Reject Invoice in Coupa (Out of Tolerance)

## 6. Environment Setup

| Requirement | Value |
|---|---|
| Target Framework | Windows (required) |
| Robot Type | Unattended |
| Modern Activities | No |
| Studio Version | 25.10.7 |
| Orchestrator Connection | Required |
| Machine Template | Server |
| Action Center | Required |
| Document Understanding | Required |
| Data Service | Required |

### Machine Template

**Recommended:** Server
Server machine recommended for AI/DU workloads — allocate GPU resources if using local ML models

### Orchestrator Folder Structure

Create a Modern Folder with unattended robot pool (2+ robots recommended for queue-based processing). Enable Auto-scaling if available.

### NuGet Dependencies

| # | Package |
|---|--------|
| 1 | `UiPath.ComplexScenarios.Activities` |
| 2 | `UiPath.System.Activities` |
| 3 | `UiPath.UIAutomation.Activities` |
| 4 | `UiPath.WebAPI.Activities` |
| 5 | `UiPath.DataService.Activities` |
| 6 | `Newtonsoft.Json` |
| 7 | `UiPath.Persistence.Activities` |
| 8 | `UiPath.Excel.Activities` |

### Target Applications (from Process Map)

The following applications were identified from the business process map. Ensure network connectivity and access credentials are configured on the robot machine:

- Orchestrator Trigger
- Coupa (via Integration Service connector)
- Document Understanding (Invoice taxonomy)
- Document Understanding
- Action Center
- Coupa
- Business Rules

## 7. Credential & Asset Inventory

**Total:** 37 activities (24 hardcoded, 13 variable-driven)

### Orchestrator Credentials to Provision

| # | Credential Name | Type | Consuming Activity | File | Action |
|---|----------------|------|-------------------|------|--------|
| 1 | `[` | Credential | — | `Dispatcher.xaml` | Verify exists in target environment |
| 2 | `[Cred_Coupa_API]` | Credential | — | `InitAllSettings.xaml` | Verify exists in target environment |

### Orchestrator Assets to Provision

| # | Asset Name | Value Type | Consuming Activity | File | Action |
|---|-----------|-----------|-------------------|------|--------|
| 1 | `Coupa.BaseUrl` | Unknown | — | `Dispatcher.xaml` | Create in Orchestrator before deployment |
| 2 | `Coupa.Polling.Enabled` | Unknown | — | `Dispatcher.xaml` | Create in Orchestrator before deployment |
| 3 | `Coupa.Polling.LookbackMinutes` | Unknown | — | `Dispatcher.xaml` | Create in Orchestrator before deployment |
| 4 | `Orchestrator.FolderName` | Unknown | — | `Dispatcher.xaml` | Create in Orchestrator before deployment |
| 5 | `[` | Unknown | — | `Dispatcher.xaml` | Verify exists in target environment |
| 6 | `Business.TolerancePercent` | Unknown | — | `InitialiseConfig.xaml` | Create in Orchestrator before deployment |
| 7 | `Business.ToleranceBasis` | Unknown | — | `InitialiseConfig.xaml` | Create in Orchestrator before deployment |
| 8 | `DU.ConfidenceThreshold` | Unknown | — | `InitialiseConfig.xaml` | Create in Orchestrator before deployment |
| 9 | `ActionCenter.SLAHours` | Unknown | — | `InitialiseConfig.xaml` | Create in Orchestrator before deployment |
| 10 | `Storage.RetentionDays` | Unknown | — | `InitialiseConfig.xaml` | Create in Orchestrator before deployment |

### Detailed Usage Map

| File | Line | Activity | Asset/Credential | Type | Variable | Hardcoded |
|------|------|----------|-----------------|------|----------|----------|
| `Dispatcher.xaml` | 81 | GetAsset | `Coupa.BaseUrl` | Unknown | — | Yes |
| `Dispatcher.xaml` | 120 | GetAsset | `Coupa.Polling.Enabled` | Unknown | — | Yes |
| `Dispatcher.xaml` | 159 | GetAsset | `Coupa.Polling.LookbackMinutes` | Unknown | — | Yes |
| `Dispatcher.xaml` | 198 | GetAsset | `Orchestrator.FolderName` | Unknown | — | Yes |
| `Dispatcher.xaml` | 237 | GetCredential | `[` | Credential | — | No |
| `Dispatcher.xaml` | 276 | GetAsset | `[` | Unknown | — | No |
| `InitialiseConfig.xaml` | 71 | GetAsset | `Coupa.BaseUrl` | Unknown | — | Yes |
| `InitialiseConfig.xaml` | 110 | GetAsset | `Coupa.Polling.Enabled` | Unknown | — | Yes |
| `InitialiseConfig.xaml` | 149 | GetAsset | `Coupa.Polling.LookbackMinutes` | Unknown | — | Yes |
| `InitialiseConfig.xaml` | 188 | GetAsset | `Business.TolerancePercent` | Unknown | — | Yes |
| `InitialiseConfig.xaml` | 227 | GetAsset | `Business.ToleranceBasis` | Unknown | — | Yes |
| `InitialiseConfig.xaml` | 266 | GetAsset | `DU.ConfidenceThreshold` | Unknown | — | Yes |
| `InitialiseConfig.xaml` | 305 | GetAsset | `ActionCenter.SLAHours` | Unknown | — | Yes |
| `InitialiseConfig.xaml` | 344 | GetAsset | `Storage.RetentionDays` | Unknown | — | Yes |
| `InitialiseConfig.xaml` | 383 | GetAsset | `Orchestrator.FolderName` | Unknown | — | Yes |
| `InitialiseConfig.xaml` | 422 | GetCredential | `[` | Credential | — | No |
| `RetrieveInvoicePdf.xaml` | 70 | GetAsset | `Coupa.BaseUrl` | Unknown | — | Yes |
| `CreateValidationTask.xaml` | 70 | GetAsset | `ActionCenter.SLAHours` | Unknown | — | Yes |
| `InitAllSettings.xaml` | 100 | GetCredential | `[Cred_Coupa_API]` | Credential | — | No |
| `InitAllSettings.xaml` | 105 | GetAsset | `Coupa.BaseUrl` | Unknown | — | Yes |
| `InitAllSettings.xaml` | 106 | GetAsset | `UNKNOWN` | Unknown | — | No |
| `InitAllSettings.xaml` | 114 | GetAsset | `Coupa.Polling.Enabled` | Unknown | — | Yes |
| `InitAllSettings.xaml` | 115 | GetAsset | `UNKNOWN` | Unknown | — | No |
| `InitAllSettings.xaml` | 123 | GetAsset | `Coupa.Polling.LookbackMinutes` | Unknown | — | Yes |
| `InitAllSettings.xaml` | 124 | GetAsset | `UNKNOWN` | Unknown | — | No |
| `InitAllSettings.xaml` | 132 | GetAsset | `Business.TolerancePercent` | Unknown | — | Yes |
| `InitAllSettings.xaml` | 133 | GetAsset | `UNKNOWN` | Unknown | — | No |
| `InitAllSettings.xaml` | 141 | GetAsset | `Business.ToleranceBasis` | Unknown | — | Yes |
| `InitAllSettings.xaml` | 142 | GetAsset | `UNKNOWN` | Unknown | — | No |
| `InitAllSettings.xaml` | 150 | GetAsset | `DU.ConfidenceThreshold` | Unknown | — | Yes |
| `InitAllSettings.xaml` | 151 | GetAsset | `UNKNOWN` | Unknown | — | No |
| `InitAllSettings.xaml` | 159 | GetAsset | `ActionCenter.SLAHours` | Unknown | — | Yes |
| `InitAllSettings.xaml` | 160 | GetAsset | `UNKNOWN` | Unknown | — | No |
| `InitAllSettings.xaml` | 168 | GetAsset | `Storage.RetentionDays` | Unknown | — | Yes |
| `InitAllSettings.xaml` | 169 | GetAsset | `UNKNOWN` | Unknown | — | No |
| `InitAllSettings.xaml` | 177 | GetAsset | `Orchestrator.FolderName` | Unknown | — | Yes |
| `InitAllSettings.xaml` | 178 | GetAsset | `UNKNOWN` | Unknown | — | No |

> **Warning:** 24 asset/credential name(s) are hardcoded. Consider externalizing to Orchestrator Config assets for environment portability.

## 8. SDD × XAML Artifact Reconciliation

**Summary:** 9 aligned, 3 SDD-only, 5 XAML-only

> **Warning:** 3 artifact(s) declared in the SDD were not found in the generated XAML. These must be provisioned in Orchestrator but are not referenced in code — verify the SDD spec or add the corresponding activities.

> **Warning:** 5 artifact(s) found in XAML are not declared in the SDD. Update the SDD orchestrator_artifacts block to include these, or the deployment manifest will be incomplete.

| # | Name | Type | Status | SDD Config | XAML File | XAML Line |
|---|------|------|--------|-----------|----------|----------|
| 1 | `Coupa.BaseUrl` | asset | **Aligned** | type: Text, value: https://<your-tenant>.coupahost.com, description: Coupa tenant base URL used by Integration Service/HTTP calls where needed. | `Dispatcher.xaml` | 81 |
| 2 | `Coupa.Polling.Enabled` | asset | **Aligned** | type: Bool, value: true, description: If event-based triggers are not feasible, enables scheduled polling for new invoices. | `Dispatcher.xaml` | 120 |
| 3 | `Coupa.Polling.LookbackMinutes` | asset | **Aligned** | type: Integer, value: 60, description: Polling lookback window (minutes) to capture any missed invoices. | `Dispatcher.xaml` | 159 |
| 4 | `Business.TolerancePercent` | asset | **Aligned** | type: Integer, value: 5, description: Tolerance percentage for invoice total vs PO basis amount. | `InitialiseConfig.xaml` | 188 |
| 5 | `Business.ToleranceBasis` | asset | **Aligned** | type: Text, value: PO_TOTAL, description: Defines tolerance comparison basis. Expected values: PO_TOTAL | PO_REMAINING | LINE_LEVEL (confirm and update per finalized policy). | `InitialiseConfig.xaml` | 227 |
| 6 | `DU.ConfidenceThreshold` | asset | **Aligned** | type: Integer, value: 85, description: Minimum confidence (0-100) required to proceed without human validation. | `InitialiseConfig.xaml` | 266 |
| 7 | `ActionCenter.SLAHours` | asset | **Aligned** | type: Integer, value: 24, description: SLA for human validation turnaround in Action Center. | `InitialiseConfig.xaml` | 305 |
| 8 | `Storage.RetentionDays` | asset | **Aligned** | type: Integer, value: 30, description: Retention for stored invoice PDFs and processing artifacts in Storage Buckets (align with AP compliance policy). | `InitialiseConfig.xaml` | 344 |
| 9 | `Orchestrator.FolderName` | asset | **Aligned** | type: Text, value: FIN_AP_InvoiceReconciliation_PRD, description: Target Orchestrator modern folder for production deployment and runtime isolation. | `Dispatcher.xaml` | 198 |
| 10 | `Cred_Coupa_API` | credential | **SDD Only** | type: Credential, description: Credential for Coupa API access if required by connector design (client id/secret, token, or service account). | — | — |
| 11 | `[` | asset | **XAML Only** | — | `Dispatcher.xaml` | 237 |
| 12 | `[` | credential | **XAML Only** | — | `Dispatcher.xaml` | 237 |
| 13 | `[Cred_Coupa_API]` | credential | **XAML Only** | — | `InitAllSettings.xaml` | 100 |
| 14 | `Q_Coupa_InvoiceReconciliation` | queue | **SDD Only** | maxRetries: 2, uniqueReference: true, description: Primary work queue for Coupa invoice submissions to be processed end-to-end (DU extraction, PO validation, tolerance check, route or reject). Reference = Coupa Invoice ID. | — | — |
| 15 | `Q_Coupa_InvoiceReconciliation_Exceptions` | queue | **SDD Only** | maxRetries: 3, uniqueReference: true, description: Secondary queue for technical exceptions requiring automatic retry or support intervention (API errors, transient DU service failures). Reference = Coupa Invoice ID + Exception Category. | — | — |
| 16 | `{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;queueName&quot;}` | queue | **XAML Only** | — | `Main.xaml` | 135 |
| 17 | `[` | queue | **XAML Only** | — | `Dispatcher.xaml` | 628 |

## 9. Queue Management

**Pattern:** Transactional (Dispatcher/Performer)

### Queues to Provision

| # | Queue Name | Activities | Unique Reference | Auto Retry | SLA | Action |
|---|-----------|------------|-----------------|------------|-----|--------|
| 1 | `{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;queueName&quot;}` | GetTransactionItem | Recommended | Yes (3x) | — | Create in Orchestrator |
| 2 | `[` | AddQueueItem | Recommended | Yes (3x) | — | Verify exists |

### SDD-Defined Queues (Not Yet in XAML)

| # | Queue Name | Unique Reference | Max Retries | SLA | Note |
|---|-----------|-----------------|-------------|-----|------|
| 1 | `Q_Coupa_InvoiceReconciliation` | Yes | 2x | — | Defined in SDD but no matching XAML activity — verify implementation |
| 2 | `Q_Coupa_InvoiceReconciliation_Exceptions` | Yes | 3x | — | Defined in SDD but no matching XAML activity — verify implementation |

### Queue Activity Summary

| Capability | Present |
|---|---|
| Add Queue Item | Yes |
| Get Transaction Item | Yes |
| Set Transaction Status | Yes |

### Retry Policy

Transactional pattern detected — configure Auto Retry (recommended: 3 retries) in Orchestrator Queue settings

### SLA Guidance

Configure SLA in Orchestrator: set Maximum Execution Time per transaction item and monitor Queue SLA reports. Recommended: base SLA on observed P95 processing time + 20% buffer.

### Dead-Letter / Failed Items Handling

Items exceeding max retries are marked as Failed. Review failed items in Orchestrator Queues dashboard. Consider: (1) Create a separate cleanup/reprocessing workflow for DLQ items, (2) Set up email alerts for failed transaction counts exceeding threshold, (3) Log detailed failure context in SetTransactionStatus output for troubleshooting.

## 10. Exception Handling Coverage

**Coverage:** 26/45 high-risk activities inside TryCatch (58%)

### Files Without TryCatch

- `InitAllSettings.xaml`

### Uncovered High-Risk Activities

| # | Location | Activity |
|---|----------|----------|
| 1 | `InitAllSettings.xaml:100` | Get Cred_Coupa_API |
| 2 | `InitAllSettings.xaml:105` | Get Coupa.BaseUrl |
| 3 | `InitAllSettings.xaml:106` | ui:GetAsset |
| 4 | `InitAllSettings.xaml:114` | Get Coupa.Polling.Enabled |
| 5 | `InitAllSettings.xaml:115` | ui:GetAsset |
| 6 | `InitAllSettings.xaml:123` | Get Coupa.Polling.LookbackMinutes |
| 7 | `InitAllSettings.xaml:124` | ui:GetAsset |
| 8 | `InitAllSettings.xaml:132` | Get Business.TolerancePercent |
| 9 | `InitAllSettings.xaml:133` | ui:GetAsset |
| 10 | `InitAllSettings.xaml:141` | Get Business.ToleranceBasis |
| 11 | `InitAllSettings.xaml:142` | ui:GetAsset |
| 12 | `InitAllSettings.xaml:150` | Get DU.ConfidenceThreshold |
| 13 | `InitAllSettings.xaml:151` | ui:GetAsset |
| 14 | `InitAllSettings.xaml:159` | Get ActionCenter.SLAHours |
| 15 | `InitAllSettings.xaml:160` | ui:GetAsset |
| 16 | `InitAllSettings.xaml:168` | Get Storage.RetentionDays |
| 17 | `InitAllSettings.xaml:169` | ui:GetAsset |
| 18 | `InitAllSettings.xaml:177` | Get Orchestrator.FolderName |
| 19 | `InitAllSettings.xaml:178` | ui:GetAsset |

> **Recommendation:** Wrap these activities in TryCatch blocks with appropriate exception types (BusinessRuleException for data errors, System.Exception for general failures).

## 11. Trigger Configuration

Based on the process analysis, the following trigger configuration is recommended:

| # | Trigger Type | Reason | Configuration |
|---|-------------|--------|---------------|
| 1 | **Schedule** | Defined in SDD orchestrator_artifacts: TRG_CoupaInvoiceRecon_Dispatcher_Polling_5min | SDD-specified: TRG_CoupaInvoiceRecon_Dispatcher_Polling_5min | Cron: 0 */5 * ? * * * | Scheduled dispatcher trigger (polling mode) to detect new Coupa invoice submissions and enqueue items. Used when Coupa event/webhook trigger is not available. |
| 2 | **Queue** | Defined in SDD orchestrator_artifacts: TRG_CoupaInvoiceRecon_Performer_Queue | SDD-specified: TRG_CoupaInvoiceRecon_Performer_Queue | Queue: Q_Coupa_InvoiceReconciliation | Queue trigger to start performer processing when new invoice items arrive. |

## 12. Upstream Quality Findings

The following quality warnings were produced by upstream pipeline stages (selector scoring, type validation, expression linting, etc.) and should be addressed during development:

| Code | Severity | Count | Sample Message |
|------|----------|-------|----------------|
| hardcoded-credential | warning | 2 | Potential hardcoded credential detected (pattern: password\s*[:=]\s*["'](?!\[)[^...) |
| placeholder-value | warning | 6 | Contains 1 placeholder value(s) matching "\bPLACEHOLDER\b" [Developer Implementation Required] |
| undeclared-asset | warning | 11 | Asset "{type:literal,value:Coupa.BaseUrl}" is referenced in XAML but not declared in orchestrator artifacts |
| hardcoded-retry-interval | warning | 6 | Line 328: retry interval hardcoded as "{&quot;type&quot;:&quot;literal&quot;,&quot;value&quot;:&quot;00:00:15&quot;}" — ... |
| hardcoded-asset-name | warning | 28 | Line 77: asset name "{&quot;type&quot;:&quot;literal&quot;,&quot;value&quot;:&quot;Coupa.BaseUrl&quot;}" is hardcoded — ... |
| hardcoded-retry-count | warning | 3 | Line 217: retry count hardcoded as 3 — consider externalizing to Config.xlsx (e.g., in_Config("MaxRetryNumber")) |
| COMPLEX_EXPRESSION_PASSTHROUGH | warning | 4 | Line 563: Complex expression (lambdas, LINQ, nested calls, or 3+ operators) — emitting as-is to avoid regex corruption i... |
| EXPRESSION_SYNTAX | warning | 10 | Line 472: C# 'null' should be VB.NET 'Nothing' in expression: {&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&qu... |
| BARE_TOKEN_QUOTED | warning | 3 | Auto-quoted bare token "Settings" for uexcel:ExcelReadRange.SheetName (expected String type) — wrapped in VB string quot... |
| RETRY_INTERVAL_DEFAULTED | warning | 3 | Post-repair: RetryInterval defaulted to "00:00:05" — verify this is appropriate for the workflow context |

## 13. Pre-Deployment Checklist

| # | Category | Task | Required |
|---|----------|------|----------|
| 1 | Deployment | Publish package to Orchestrator feed | Yes |
| 2 | Deployment | Create Process in target folder | Yes |
| 3 | Environment | Verify Orchestrator connection from robot | Yes |
| 4 | Credentials | Provision credential: `[` | Yes |
| 5 | Credentials | Provision credential: `[Cred_Coupa_API]` | Yes |
| 6 | Assets | Provision asset: `Coupa.BaseUrl` | Yes |
| 7 | Assets | Provision asset: `Coupa.Polling.Enabled` | Yes |
| 8 | Assets | Provision asset: `Coupa.Polling.LookbackMinutes` | Yes |
| 9 | Assets | Provision asset: `Orchestrator.FolderName` | Yes |
| 10 | Assets | Provision asset: `[` | Yes |
| 11 | Assets | Provision asset: `Business.TolerancePercent` | Yes |
| 12 | Assets | Provision asset: `Business.ToleranceBasis` | Yes |
| 13 | Assets | Provision asset: `DU.ConfidenceThreshold` | Yes |
| 14 | Assets | Provision asset: `ActionCenter.SLAHours` | Yes |
| 15 | Assets | Provision asset: `Storage.RetentionDays` | Yes |
| 16 | Queues | Create queue: `{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;queueName&quot;}` | Yes |
| 17 | Queues | Create queue: `[` | Yes |
| 18 | Trigger | Configure trigger (schedule/queue/API) | Yes |
| 19 | Testing | Run smoke test in target environment | Yes |
| 20 | Monitoring | Verify logging output in Orchestrator | Recommended |
| 21 | Governance | UAT test execution completed and sign-off obtained | Yes |
| 22 | Governance | Peer code review completed | Yes |
| 23 | Governance | All quality gate warnings addressed or risk-accepted | Yes |
| 24 | Governance | Business process owner validation obtained | Yes |
| 25 | Governance | CoE approval obtained | Yes |
| 26 | Governance | Production readiness assessment completed (monitoring, alerting, rollback plan documented) | Yes |

## 14. Deployment Readiness Score

**Overall: Needs Work — 31/50 (62%)**

| Section | Score | Notes |
|---------|-------|-------|
| Credentials & Assets | 5/10 | 24 hardcoded asset name(s) — use Orchestrator assets/config |
| Exception Handling | 6/10 | 58% coverage — consider wrapping remaining activities; 1 file(s) with no TryCatch blocks |
| Queue Management | 9/10 | 1 hardcoded queue name(s) — externalize to config |
| Build Quality | 1/10 | 76 quality warnings — significant remediation needed; 19 remediations — stub replacements need developer attention |
| Environment Setup | 10/10 | Environment requirements are straightforward |

> **Action Required:** Address the items above before deploying to production. Focus on sections with the lowest scores first.

## 15. Pre-emission Spec Validation

Validation was performed on the WorkflowSpec tree before XAML assembly. Issues caught at this stage are cheaper to fix than post-emission quality gate findings.

| Metric | Count |
|---|---|
| Total activities checked | 0 |
| Valid activities | 0 |
| Unknown → Comment stubs | 0 |
| Non-catalog properties stripped | 0 |
| Enum values auto-corrected | 0 |
| Missing required props filled | 0 |
| Total issues | 0 |

### Pre-emission vs Post-emission

| Stage | Issues Caught/Fixed |
|---|---|
| Pre-emission (spec validation) | 0 auto-fixed, 0 total issues |
| Post-emission (quality gate) | 95 warnings/remediations |

## 16. Catalog Filter Adoption Report

Shows which pipeline stages use the filtered activity catalog (deprecated, non-emission-approved, and target-incompatible activities are excluded).

| Stage | Adopted | Total Lookups | Approved | Deprecated | Non-Approved | Target-Incompatible | Unknown |
|---|---|---|---|---|---|---|---|
| quality-gate | Yes | 1767 | 1767 | 0 | 0 | 0 | 0 |
| deterministic-validators | Yes | 15018 | 8250 | 0 | 0 | 0 | 6768 |
| iterative-llm-corrector | Yes | 0 | 0 | 0 | 0 | 0 | 0 |
| workflow-tree-assembler | Yes | 0 | 0 | 0 | 0 | 0 | 0 |
| xaml-compliance | Yes | 13098 | 7908 | 0 | 2475 | 0 | 2715 |
| executable-path-validator | Yes | 939 | 789 | 0 | 0 | 0 | 150 |
| post-emission-dependency-analyzer | Yes | 10 | 10 | 0 | 0 | 0 | 0 |

---

## 17. Structured Report (JSON)

The following JSON appendix contains the full pipeline outcome report for programmatic consumption:

```json
{
  "fullyGeneratedFiles": [],
  "autoRepairs": [
    {
      "repairCode": "REPAIR_GENERIC",
      "file": "Main.xaml",
      "description": "Catalog (fallback): Moved ucs:MultipleAssign.Assignments from attribute to child-element in Main.xaml"
    },
    {
      "repairCode": "REPAIR_GENERIC",
      "file": "Main.xaml",
      "description": "Catalog (fallback): Moved ui:GetTransactionItem.QueueName from attribute to child-element in Main.xaml"
    },
    {
      "repairCode": "REPAIR_GENERIC",
      "file": "Main.xaml",
      "description": "Catalog (fallback): Moved ui:GetTransactionItem.TransactionItem from attribute to child-element in Main.xaml"
    },
    {
      "repairCode": "REPAIR_GENERIC",
      "file": "Main.xaml",
      "description": "Catalog (fallback): Moved ucs:MultipleAssign.Assignments from attribute to child-element in Main.xaml"
    },
    {
      "repairCode": "REPAIR_GENERIC",
      "file": "Main.xaml",
      "description": "Catalog (fallback): Moved ucs:MultipleAssign.Assignments from attribute to child-element in Main.xaml"
    }
  ],
  "remediations": [
    {
      "level": "validation-finding",
      "file": "ExtractInvoiceFields.xaml",
      "remediationCode": "STUB_ACTIVITY_UNKNOWN",
      "reason": "Line 110: Activity \"DigitizeDocument\" has no namespace prefix — Studio will fail to resolve it. Expected a prefix like \"ui:DigitizeDocument\"",
      "classifiedCheck": "unprefixed-activity",
      "developerAction": "Manually implement activity in ExtractInvoiceFields.xaml — estimated 15 min",
      "estimatedEffortMinutes": 15
    },
    {
      "level": "validation-finding",
      "file": "ExtractInvoiceFields.xaml",
      "remediationCode": "STUB_ACTIVITY_UNKNOWN",
      "reason": "Line 150: Activity \"ExtractDocumentData\" has no namespace prefix — Studio will fail to resolve it. Expected a prefix like \"ui:ExtractDocumentData\"",
      "classifiedCheck": "unprefixed-activity",
      "developerAction": "Manually implement activity in ExtractInvoiceFields.xaml — estimated 15 min",
      "estimatedEffortMinutes": 15
    },
    {
      "level": "validation-finding",
      "file": "InitialiseConfig.xaml",
      "remediationCode": "STUB_ACTIVITY_UNKNOWN",
      "reason": "Line 612: Undeclared variable \"value\" in expression: value — variable is not declared in any <Variable> block in scope",
      "classifiedCheck": "UNDECLARED_VARIABLE",
      "developerAction": "Manually implement activity in InitialiseConfig.xaml — estimated 15 min",
      "estimatedEffortMinutes": 15
    },
    {
      "level": "validation-finding",
      "file": "ValidateAndDecide.xaml",
      "remediationCode": "STUB_ACTIVITY_UNKNOWN",
      "reason": "Line 126: .UrlEncode() has unbalanced parentheses in expression: {&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;coupaBaseUrl...",
      "classifiedCheck": "EXPRESSION_SYNTAX_UNFIXABLE",
      "developerAction": "Manually implement activity in ValidateAndDecide.xaml — estimated 15 min",
      "estimatedEffortMinutes": 15
    },
    {
      "level": "validation-finding",
      "file": "ValidateAndDecide.xaml",
      "remediationCode": "STUB_ACTIVITY_UNKNOWN",
      "reason": "Line 274: .TrimEnd() has unbalanced parentheses in expression: {&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;coupaBaseUrl...",
      "classifiedCheck": "EXPRESSION_SYNTAX_UNFIXABLE",
      "developerAction": "Manually implement activity in ValidateAndDecide.xaml — estimated 15 min",
      "estimatedEffortMinutes": 15
    },
    {
      "level": "validation-finding",
      "file": "ValidateAndDecide.xaml",
      "remediationCode": "STUB_ACTIVITY_UNKNOWN",
      "reason": "Line 522: Undeclared variable \"value\" in expression: value — variable is not declared in any <Variable> block in scope",
      "classifiedCheck": "UNDECLARED_VARIABLE",
      "developerAction": "Manually implement activity in ValidateAndDecide.xaml — estimated 15 min",
      "estimatedEffortMinutes": 15
    },
    {
      "level": "validation-finding",
      "file": "ProcessTransaction.xaml",
      "remediationCode": "STUB_ACTIVITY_UNKNOWN",
      "reason": "Line 483: uds:CreateEntityRecord is missing required property \"EntityObject\"",
      "classifiedCheck": "MISSING_REQUIRED_ACTIVITY_PROPERTY",
      "developerAction": "Manually implement activity in ProcessTransaction.xaml — estimated 15 min",
      "estimatedEffortMinutes": 15
    },
    {
      "level": "activity",
      "file": "InitialiseConfig.xaml",
      "remediationCode": "UNDECLARED_VARIABLE_MANUAL",
      "reason": "Undeclared variable \"value\" — type cannot be auto-inferred (no recognized naming prefix)",
      "classifiedCheck": "UNDECLARED_VARIABLE",
      "developerAction": "Declare variable \"value\" in InitialiseConfig.xaml with the appropriate type. Expression context: value",
      "estimatedEffortMinutes": 5
    },
    {
      "level": "activity",
      "file": "ValidateAndDecide.xaml",
      "remediationCode": "UNDECLARED_VARIABLE_MANUAL",
      "reason": "Undeclared variable \"value\" — type cannot be auto-inferred (no recognized naming prefix)",
      "classifiedCheck": "UNDECLARED_VARIABLE",
      "developerAction": "Declare variable \"value\" in ValidateAndDecide.xaml with the appropriate type. Expression context: value",
      "estimatedEffortMinutes": 5
    },
    {
      "level": "activity",
      "file": "",
      "remediationCode": "POST_ASSEMBLY_REPAIR",
      "reason": "[MISSING_REQUIRED_PROPERTY_DEFECT] uds:CreateEntityRecord.EntityObject has no valid source binding and no contract-valid fallback — structured defect, property left absent",
      "classifiedCheck": "post-assembly-repair",
      "developerAction": "uds:CreateEntityRecord.EntityObject has no valid source binding and no contract-valid fallback — structured defect, property left absent",
      "estimatedEffortMinutes": 5
    },
    {
      "level": "activity",
      "file": "",
      "remediationCode": "POST_ASSEMBLY_REPAIR",
      "reason": "[MISSING_REQUIRED_PROPERTY_DEFECT] uds:CreateEntityRecord.EntityObject has no valid source binding and no contract-valid fallback — structured defect, property left absent",
      "classifiedCheck": "post-assembly-repair",
      "developerAction": "uds:CreateEntityRecord.EntityObject has no valid source binding and no contract-valid fallback — structured defect, property left absent",
      "estimatedEffortMinutes": 5
    },
    {
      "level": "workflow",
      "file": "Main.xaml",
      "remediationCode": "STUB_WORKFLOW_BLOCKING",
      "reason": "Pre-archive assertion: object_payload_in_target_value_slot — Object payload in target/value slot: <Assign.To><OutArgument x:TypeArguments=\"x:String\">Nothing</OutArgument></Assign.To>\n              <Assign.Value><InArgu",
      "classifiedCheck": "pre-archive-canonicalization",
      "developerAction": "Resolve object_payload_in_target_value_slot in Main.xaml",
      "estimatedEffortMinutes": 10
    },
    {
      "level": "workflow",
      "file": "Dispatcher.xaml",
      "remediationCode": "STUB_WORKFLOW_BLOCKING",
      "reason": "Pre-archive assertion: object_payload_in_target_value_slot — Object payload in target/value slot: <Assign.To><OutArgument x:TypeArguments=\"x:String\">Nothing</OutArgument></Assign.To>\n              <Assign.Value><InArgu",
      "classifiedCheck": "pre-archive-canonicalization",
      "developerAction": "Resolve object_payload_in_target_value_slot in Dispatcher.xaml",
      "estimatedEffortMinutes": 10
    },
    {
      "level": "workflow",
      "file": "InitialiseConfig.xaml",
      "remediationCode": "STUB_WORKFLOW_BLOCKING",
      "reason": "Pre-archive assertion: object_payload_in_target_value_slot — Object payload in target/value slot: <Assign.To><OutArgument x:TypeArguments=\"x:String\">Nothing</OutArgument></Assign.To>\n              <Assign.Value><InArgu",
      "classifiedCheck": "pre-archive-canonicalization",
      "developerAction": "Resolve object_payload_in_target_value_slot in InitialiseConfig.xaml",
      "estimatedEffortMinutes": 10
    },
    {
      "level": "workflow",
      "file": "ProcessTransaction.xaml",
      "remediationCode": "STUB_WORKFLOW_BLOCKING",
      "reason": "Pre-archive assertion: object_payload_in_target_value_slot — Object payload in target/value slot: <Assign.To><OutArgument x:TypeArguments=\"x:String\">Nothing</OutArgument></Assign.To>\n              <Assign.Value><InArgu",
      "classifiedCheck": "pre-archive-canonicalization",
      "developerAction": "Resolve object_payload_in_target_value_slot in ProcessTransaction.xaml",
      "estimatedEffortMinutes": 10
    },
    {
      "level": "workflow",
      "file": "RetrieveInvoicePdf.xaml",
      "remediationCode": "STUB_WORKFLOW_BLOCKING",
      "reason": "Pre-archive assertion: object_payload_in_target_value_slot — Object payload in target/value slot: <Assign.To><OutArgument x:TypeArguments=\"x:String\">Nothing</OutArgument></Assign.To>\n              <Assign.Value><InArgu",
      "classifiedCheck": "pre-archive-canonicalization",
      "developerAction": "Resolve object_payload_in_target_value_slot in RetrieveInvoicePdf.xaml",
      "estimatedEffortMinutes": 10
    },
    {
      "level": "workflow",
      "file": "ExtractInvoiceFields.xaml",
      "remediationCode": "STUB_WORKFLOW_BLOCKING",
      "reason": "Pre-archive assertion: object_payload_in_target_value_slot — Object payload in target/value slot: <Assign.To><OutArgument x:TypeArguments=\"x:String\">Nothing</OutArgument></Assign.To>\n              <Assign.Value><InArgu",
      "classifiedCheck": "pre-archive-canonicalization",
      "developerAction": "Resolve object_payload_in_target_value_slot in ExtractInvoiceFields.xaml",
      "estimatedEffortMinutes": 10
    },
    {
      "level": "workflow",
      "file": "ValidateAndDecide.xaml",
      "remediationCode": "STUB_WORKFLOW_BLOCKING",
      "reason": "Pre-archive assertion: object_payload_in_target_value_slot — Object payload in target/value slot: <Assign.To><OutArgument x:TypeArguments=\"x:String\">Nothing</OutArgument></Assign.To>\n              <Assign.Value><InArgu",
      "classifiedCheck": "pre-archive-canonicalization",
      "developerAction": "Resolve object_payload_in_target_value_slot in ValidateAndDecide.xaml",
      "estimatedEffortMinutes": 10
    },
    {
      "level": "workflow",
      "file": "InitAllSettings.xaml",
      "remediationCode": "STUB_WORKFLOW_BLOCKING",
      "reason": "Pre-archive assertion: malformed_attribute_quoting — Malformed attribute quoting detected: AssetName=\"[&quot;Cred_Coupa_API&quot;]",
      "classifiedCheck": "pre-archive-canonicalization",
      "developerAction": "Resolve malformed_attribute_quoting in InitAllSettings.xaml",
      "estimatedEffortMinutes": 10
    }
  ],
  "propertyRemediations": [],
  "downgradeEvents": [],
  "qualityWarnings": [
    {
      "check": "hardcoded-credential",
      "file": "Dispatcher.xaml",
      "detail": "Potential hardcoded credential detected (pattern: password\\s*[:=]\\s*[\"'](?!\\[)[^...)",
      "severity": "warning"
    },
    {
      "check": "hardcoded-credential",
      "file": "InitialiseConfig.xaml",
      "detail": "Potential hardcoded credential detected (pattern: password\\s*[:=]\\s*[\"'](?!\\[)[^...)",
      "severity": "warning"
    },
    {
      "check": "placeholder-value",
      "file": "InitialiseConfig",
      "detail": "Contains 1 placeholder value(s) matching \"\\bPLACEHOLDER\\b\" [Developer Implementation Required]",
      "severity": "warning",
      "stubCategory": "handoff"
    },
    {
      "check": "placeholder-value",
      "file": "ProcessTransaction",
      "detail": "Contains 1 placeholder value(s) matching \"\\bPLACEHOLDER\\b\" [Developer Implementation Required]",
      "severity": "warning",
      "stubCategory": "handoff"
    },
    {
      "check": "placeholder-value",
      "file": "RetrieveInvoicePdf",
      "detail": "Contains 1 placeholder value(s) matching \"\\bPLACEHOLDER\\b\" [Developer Implementation Required]",
      "severity": "warning",
      "stubCategory": "handoff"
    },
    {
      "check": "placeholder-value",
      "file": "ExtractInvoiceFields",
      "detail": "Contains 1 placeholder value(s) matching \"\\bPLACEHOLDER\\b\" [Developer Implementation Required]",
      "severity": "warning",
      "stubCategory": "handoff"
    },
    {
      "check": "placeholder-value",
      "file": "CreateValidationTask",
      "detail": "Contains 1 placeholder value(s) matching \"\\bPLACEHOLDER\\b\" [Developer Implementation Required]",
      "severity": "warning",
      "stubCategory": "handoff"
    },
    {
      "check": "placeholder-value",
      "file": "ValidateAndDecide",
      "detail": "Contains 1 placeholder value(s) matching \"\\bPLACEHOLDER\\b\" [Developer Implementation Required]",
      "severity": "warning",
      "stubCategory": "handoff"
    },
    {
      "check": "undeclared-asset",
      "file": "orchestrator",
      "detail": "Asset \"{type:literal,value:Coupa.BaseUrl}\" is referenced in XAML but not declared in orchestrator artifacts",
      "severity": "warning"
    },
    {
      "check": "undeclared-asset",
      "file": "orchestrator",
      "detail": "Asset \"{type:literal,value:Coupa.Polling.Enabled}\" is referenced in XAML but not declared in orchestrator artifacts",
      "severity": "warning"
    },
    {
      "check": "undeclared-asset",
      "file": "orchestrator",
      "detail": "Asset \"{type:literal,value:Coupa.Polling.LookbackMinutes}\" is referenced in XAML but not declared in orchestrator artifacts",
      "severity": "warning"
    },
    {
      "check": "undeclared-asset",
      "file": "orchestrator",
      "detail": "Asset \"{type:literal,value:Orchestrator.FolderName}\" is referenced in XAML but not declared in orchestrator artifacts",
      "severity": "warning"
    },
    {
      "check": "undeclared-asset",
      "file": "orchestrator",
      "detail": "Asset \"{type:literal,value:Cred_Coupa_API}\" is referenced in XAML but not declared in orchestrator artifacts",
      "severity": "warning"
    },
    {
      "check": "undeclared-asset",
      "file": "orchestrator",
      "detail": "Asset \"{type:literal,value:CoupaInvoiceRecon_LastRunUtc}\" is referenced in XAML but not declared in orchestrator artifacts",
      "severity": "warning"
    },
    {
      "check": "undeclared-asset",
      "file": "orchestrator",
      "detail": "Asset \"{type:literal,value:Business.TolerancePercent}\" is referenced in XAML but not declared in orchestrator artifacts",
      "severity": "warning"
    },
    {
      "check": "undeclared-asset",
      "file": "orchestrator",
      "detail": "Asset \"{type:literal,value:Business.ToleranceBasis}\" is referenced in XAML but not declared in orchestrator artifacts",
      "severity": "warning"
    },
    {
      "check": "undeclared-asset",
      "file": "orchestrator",
      "detail": "Asset \"{type:literal,value:DU.ConfidenceThreshold}\" is referenced in XAML but not declared in orchestrator artifacts",
      "severity": "warning"
    },
    {
      "check": "undeclared-asset",
      "file": "orchestrator",
      "detail": "Asset \"{type:literal,value:ActionCenter.SLAHours}\" is referenced in XAML but not declared in orchestrator artifacts",
      "severity": "warning"
    },
    {
      "check": "undeclared-asset",
      "file": "orchestrator",
      "detail": "Asset \"{type:literal,value:Storage.RetentionDays}\" is referenced in XAML but not declared in orchestrator artifacts",
      "severity": "warning"
    },
    {
      "check": "hardcoded-retry-interval",
      "file": "Dispatcher.xaml",
      "detail": "Line 328: retry interval hardcoded as \"{&quot;type&quot;:&quot;literal&quot;,&quot;value&quot;:&quot;00:00:15&quot;}\" — consider externalizing to Config.xlsx",
      "severity": "warning"
    },
    {
      "check": "hardcoded-asset-name",
      "file": "Dispatcher.xaml",
      "detail": "Line 77: asset name \"{&quot;type&quot;:&quot;literal&quot;,&quot;value&quot;:&quot;Coupa.BaseUrl&quot;}\" is hardcoded — consider using a Config.xlsx entry or workflow argument",
      "severity": "warning"
    },
    {
      "check": "hardcoded-asset-name",
      "file": "Dispatcher.xaml",
      "detail": "Line 116: asset name \"{&quot;type&quot;:&quot;literal&quot;,&quot;value&quot;:&quot;Coupa.Polling.Enabled&quot;}\" is hardcoded — consider using a Config.xlsx entry or workflow argument",
      "severity": "warning"
    },
    {
      "check": "hardcoded-asset-name",
      "file": "Dispatcher.xaml",
      "detail": "Line 155: asset name \"{&quot;type&quot;:&quot;literal&quot;,&quot;value&quot;:&quot;Coupa.Polling.LookbackMinutes&quot;}\" is hardcoded — consider using a Config.xlsx entry or workflow argument",
      "severity": "warning"
    },
    {
      "check": "hardcoded-asset-name",
      "file": "Dispatcher.xaml",
      "detail": "Line 194: asset name \"{&quot;type&quot;:&quot;literal&quot;,&quot;value&quot;:&quot;Orchestrator.FolderName&quot;}\" is hardcoded — consider using a Config.xlsx entry or workflow argument",
      "severity": "warning"
    },
    {
      "check": "hardcoded-asset-name",
      "file": "Dispatcher.xaml",
      "detail": "Line 233: asset name \"{&quot;type&quot;:&quot;literal&quot;,&quot;value&quot;:&quot;Cred_Coupa_API&quot;}\" is hardcoded — consider using a Config.xlsx entry or workflow argument",
      "severity": "warning"
    },
    {
      "check": "hardcoded-asset-name",
      "file": "Dispatcher.xaml",
      "detail": "Line 272: asset name \"{&quot;type&quot;:&quot;literal&quot;,&quot;value&quot;:&quot;CoupaInvoiceRecon_LastRunUtc&quot;}\" is hardcoded — consider using a Config.xlsx entry or workflow argument",
      "severity": "warning"
    },
    {
      "check": "hardcoded-asset-name",
      "file": "InitialiseConfig.xaml",
      "detail": "Line 71: asset name \"{&quot;type&quot;:&quot;literal&quot;,&quot;value&quot;:&quot;Coupa.BaseUrl&quot;}\" is hardcoded — consider using a Config.xlsx entry or workflow argument",
      "severity": "warning"
    },
    {
      "check": "hardcoded-asset-name",
      "file": "InitialiseConfig.xaml",
      "detail": "Line 110: asset name \"{&quot;type&quot;:&quot;literal&quot;,&quot;value&quot;:&quot;Coupa.Polling.Enabled&quot;}\" is hardcoded — consider using a Config.xlsx entry or workflow argument",
      "severity": "warning"
    },
    {
      "check": "hardcoded-asset-name",
      "file": "InitialiseConfig.xaml",
      "detail": "Line 149: asset name \"{&quot;type&quot;:&quot;literal&quot;,&quot;value&quot;:&quot;Coupa.Polling.LookbackMinutes&quot;}\" is hardcoded — consider using a Config.xlsx entry or workflow argument",
      "severity": "warning"
    },
    {
      "check": "hardcoded-asset-name",
      "file": "InitialiseConfig.xaml",
      "detail": "Line 188: asset name \"{&quot;type&quot;:&quot;literal&quot;,&quot;value&quot;:&quot;Business.TolerancePercent&quot;}\" is hardcoded — consider using a Config.xlsx entry or workflow argument",
      "severity": "warning"
    },
    {
      "check": "hardcoded-asset-name",
      "file": "InitialiseConfig.xaml",
      "detail": "Line 227: asset name \"{&quot;type&quot;:&quot;literal&quot;,&quot;value&quot;:&quot;Business.ToleranceBasis&quot;}\" is hardcoded — consider using a Config.xlsx entry or workflow argument",
      "severity": "warning"
    },
    {
      "check": "hardcoded-asset-name",
      "file": "InitialiseConfig.xaml",
      "detail": "Line 266: asset name \"{&quot;type&quot;:&quot;literal&quot;,&quot;value&quot;:&quot;DU.ConfidenceThreshold&quot;}\" is hardcoded — consider using a Config.xlsx entry or workflow argument",
      "severity": "warning"
    },
    {
      "check": "hardcoded-asset-name",
      "file": "InitialiseConfig.xaml",
      "detail": "Line 305: asset name \"{&quot;type&quot;:&quot;literal&quot;,&quot;value&quot;:&quot;ActionCenter.SLAHours&quot;}\" is hardcoded — consider using a Config.xlsx entry or workflow argument",
      "severity": "warning"
    },
    {
      "check": "hardcoded-asset-name",
      "file": "InitialiseConfig.xaml",
      "detail": "Line 344: asset name \"{&quot;type&quot;:&quot;literal&quot;,&quot;value&quot;:&quot;Storage.RetentionDays&quot;}\" is hardcoded — consider using a Config.xlsx entry or workflow argument",
      "severity": "warning"
    },
    {
      "check": "hardcoded-asset-name",
      "file": "InitialiseConfig.xaml",
      "detail": "Line 383: asset name \"{&quot;type&quot;:&quot;literal&quot;,&quot;value&quot;:&quot;Orchestrator.FolderName&quot;}\" is hardcoded — consider using a Config.xlsx entry or workflow argument",
      "severity": "warning"
    },
    {
      "check": "hardcoded-asset-name",
      "file": "InitialiseConfig.xaml",
      "detail": "Line 422: asset name \"{&quot;type&quot;:&quot;literal&quot;,&quot;value&quot;:&quot;Cred_Coupa_API&quot;}\" is hardcoded — consider using a Config.xlsx entry or workflow argument",
      "severity": "warning"
    },
    {
      "check": "hardcoded-retry-count",
      "file": "RetrieveInvoicePdf.xaml",
      "detail": "Line 217: retry count hardcoded as 3 — consider externalizing to Config.xlsx (e.g., in_Config(\"MaxRetryNumber\"))",
      "severity": "warning"
    },
    {
      "check": "hardcoded-retry-count",
      "file": "RetrieveInvoicePdf.xaml",
      "detail": "Line 442: retry count hardcoded as 3 — consider externalizing to Config.xlsx (e.g., in_Config(\"MaxRetryNumber\"))",
      "severity": "warning"
    },
    {
      "check": "hardcoded-retry-interval",
      "file": "RetrieveInvoicePdf.xaml",
      "detail": "Line 169: retry interval hardcoded as \"{&quot;type&quot;:&quot;literal&quot;,&quot;value&quot;:&quot;00:00:10&quot;}\" — consider externalizing to Config.xlsx",
      "severity": "warning"
    },
    {
      "check": "hardcoded-retry-interval",
      "file": "RetrieveInvoicePdf.xaml",
      "detail": "Line 217: retry interval hardcoded as \"00:00:05\" — consider externalizing to Config.xlsx",
      "severity": "warning"
    },
    {
      "check": "hardcoded-retry-interval",
      "file": "RetrieveInvoicePdf.xaml",
      "detail": "Line 442: retry interval hardcoded as \"00:00:05\" — consider externalizing to Config.xlsx",
      "severity": "warning"
    },
    {
      "check": "hardcoded-asset-name",
      "file": "RetrieveInvoicePdf.xaml",
      "detail": "Line 70: asset name \"{&quot;type&quot;:&quot;literal&quot;,&quot;value&quot;:&quot;Coupa.BaseUrl&quot;}\" is hardcoded — consider using a Config.xlsx entry or workflow argument",
      "severity": "warning"
    },
    {
      "check": "hardcoded-asset-name",
      "file": "CreateValidationTask.xaml",
      "detail": "Line 70: asset name \"{&quot;type&quot;:&quot;literal&quot;,&quot;value&quot;:&quot;ActionCenter.SLAHours&quot;}\" is hardcoded — consider using a Config.xlsx entry or workflow argument",
      "severity": "warning"
    },
    {
      "check": "hardcoded-retry-count",
      "file": "ValidateAndDecide.xaml",
      "detail": "Line 175: retry count hardcoded as 3 — consider externalizing to Config.xlsx (e.g., in_Config(\"MaxRetryNumber\"))",
      "severity": "warning"
    },
    {
      "check": "hardcoded-retry-interval",
      "file": "ValidateAndDecide.xaml",
      "detail": "Line 132: retry interval hardcoded as \"{&quot;type&quot;:&quot;literal&quot;,&quot;value&quot;:&quot;00:00:15&quot;}\" — consider externalizing to Config.xlsx",
      "severity": "warning"
    },
    {
      "check": "hardcoded-retry-interval",
      "file": "ValidateAndDecide.xaml",
      "detail": "Line 175: retry interval hardcoded as \"00:00:05\" — consider externalizing to Config.xlsx",
      "severity": "warning"
    },
    {
      "check": "hardcoded-asset-name",
      "file": "InitAllSettings.xaml",
      "detail": "Line 100: asset name \"Cred_Coupa_API\" is hardcoded — consider using a Config.xlsx entry or workflow argument",
      "severity": "warning"
    },
    {
      "check": "hardcoded-asset-name",
      "file": "InitAllSettings.xaml",
      "detail": "Line 105: asset name \"Coupa.BaseUrl\" is hardcoded — consider using a Config.xlsx entry or workflow argument",
      "severity": "warning"
    },
    {
      "check": "hardcoded-asset-name",
      "file": "InitAllSettings.xaml",
      "detail": "Line 114: asset name \"Coupa.Polling.Enabled\" is hardcoded — consider using a Config.xlsx entry or workflow argument",
      "severity": "warning"
    },
    {
      "check": "hardcoded-asset-name",
      "file": "InitAllSettings.xaml",
      "detail": "Line 123: asset name \"Coupa.Polling.LookbackMinutes\" is hardcoded — consider using a Config.xlsx entry or workflow argument",
      "severity": "warning"
    },
    {
      "check": "hardcoded-asset-name",
      "file": "InitAllSettings.xaml",
      "detail": "Line 132: asset name \"Business.TolerancePercent\" is hardcoded — consider using a Config.xlsx entry or workflow argument",
      "severity": "warning"
    },
    {
      "check": "hardcoded-asset-name",
      "file": "InitAllSettings.xaml",
      "detail": "Line 141: asset name \"Business.ToleranceBasis\" is hardcoded — consider using a Config.xlsx entry or workflow argument",
      "severity": "warning"
    },
    {
      "check": "hardcoded-asset-name",
      "file": "InitAllSettings.xaml",
      "detail": "Line 150: asset name \"DU.ConfidenceThreshold\" is hardcoded — consider using a Config.xlsx entry or workflow argument",
      "severity": "warning"
    },
    {
      "check": "hardcoded-asset-name",
      "file": "InitAllSettings.xaml",
      "detail": "Line 159: asset name \"ActionCenter.SLAHours\" is hardcoded — consider using a Config.xlsx entry or workflow argument",
      "severity": "warning"
    },
    {
      "check": "hardcoded-asset-name",
      "file": "InitAllSettings.xaml",
      "detail": "Line 168: asset name \"Storage.RetentionDays\" is hardcoded — consider using a Config.xlsx entry or workflow argument",
      "severity": "warning"
    },
    {
      "check": "hardcoded-asset-name",
      "file": "InitAllSettings.xaml",
      "detail": "Line 177: asset name \"Orchestrator.FolderName\" is hardcoded — consider using a Config.xlsx entry or workflow argument",
      "severity": "warning"
    },
    {
      "check": "COMPLEX_EXPRESSION_PASSTHROUGH",
      "file": "Dispatcher.xaml",
      "detail": "Line 563: Complex expression (lambdas, LINQ, nested calls, or 3+ operators) — emitting as-is to avoid regex corruption in expression: {&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;obj_Existing...",
      "severity": "warning"
    },
    {
      "check": "EXPRESSION_SYNTAX",
      "file": "InitialiseConfig.xaml",
      "detail": "Line 472: C# 'null' should be VB.NET 'Nothing' in expression: {&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;If(String.Is...",
      "severity": "warning"
    },
    {
      "check": "EXPRESSION_SYNTAX",
      "file": "InitialiseConfig.xaml",
      "detail": "Line 480: Unbalanced parentheses: 1 open vs 0 close — appended 1 closing paren(s) | max nesting depth: 1, first imbalance near position 342, fragment: \"}\" in expression: {&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;If(int_Toler...",
      "severity": "warning"
    },
    {
      "check": "EXPRESSION_SYNTAX",
      "file": "InitialiseConfig.xaml",
      "detail": "Line 488: Unbalanced parentheses: 1 open vs 0 close — appended 1 closing paren(s) | max nesting depth: 1, first imbalance near position 354, fragment: \"}\" in expression: {&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;If(int_DuCon...",
      "severity": "warning"
    },
    {
      "check": "EXPRESSION_SYNTAX",
      "file": "InitialiseConfig.xaml",
      "detail": "Line 496: Unbalanced parentheses: 1 open vs 0 close — appended 1 closing paren(s) | max nesting depth: 1, first imbalance near position 299, fragment: \"}\" in expression: {&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;If(int_Actio...",
      "severity": "warning"
    },
    {
      "check": "EXPRESSION_SYNTAX",
      "file": "InitialiseConfig.xaml",
      "detail": "Line 504: Unbalanced parentheses: 1 open vs 0 close — appended 1 closing paren(s) | max nesting depth: 1, first imbalance near position 299, fragment: \"}\" in expression: {&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;If(int_Stora...",
      "severity": "warning"
    },
    {
      "check": "EXPRESSION_SYNTAX",
      "file": "InitialiseConfig.xaml",
      "detail": "Line 512: Unbalanced parentheses: 1 open vs 0 close — appended 1 closing paren(s) | max nesting depth: 1, first imbalance near position 316, fragment: \"}\" in expression: {&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;If(int_Polli...",
      "severity": "warning"
    },
    {
      "check": "EXPRESSION_SYNTAX",
      "file": "InitialiseConfig.xaml",
      "detail": "Line 520: Unbalanced parentheses: 0 open vs 1 close — removed 1 extra closing paren(s) | max nesting depth: 0, first imbalance near position 227, fragment: \"LINE_LEVEL\\&quot;), str_ValidationErrors &amp;\" in expression: {&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;If(Not (str_...",
      "severity": "warning"
    },
    {
      "check": "EXPRESSION_SYNTAX",
      "file": "InitialiseConfig.xaml",
      "detail": "Line 524: C# 'null' should be VB.NET 'Nothing' in expression: {&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;If(String.Is...",
      "severity": "warning"
    },
    {
      "check": "COMPLEX_EXPRESSION_PASSTHROUGH",
      "file": "ProcessTransaction.xaml",
      "detail": "Line 198: Complex expression (lambdas, LINQ, nested calls, or 3+ operators) — emitting as-is to avoid regex corruption in expression: {&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;If(String.Is...",
      "severity": "warning"
    },
    {
      "check": "COMPLEX_EXPRESSION_PASSTHROUGH",
      "file": "ExtractInvoiceFields.xaml",
      "detail": "Line 611: Complex expression (lambdas, LINQ, nested calls, or 3+ operators) — emitting as-is to avoid regex corruption in expression: {&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;CDbl(poNumbe...",
      "severity": "warning"
    },
    {
      "check": "COMPLEX_EXPRESSION_PASSTHROUGH",
      "file": "CreateValidationTask.xaml",
      "detail": "Line 159: Complex expression (lambdas, LINQ, nested calls, or 3+ operators) — emitting as-is to avoid regex corruption in expression: {&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;If(queriedCa...",
      "severity": "warning"
    },
    {
      "check": "EXPRESSION_SYNTAX",
      "file": "ValidateAndDecide.xaml",
      "detail": "Line 126: Unbalanced parentheses: 1 open vs 2 close — removed 1 extra closing paren(s) | max nesting depth: 0, first imbalance near position 105, fragment: \"/\\&quot;c) &amp; \\\" in expression: {&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;coupaBaseUrl...",
      "severity": "warning"
    },
    {
      "check": "EXPRESSION_SYNTAX",
      "file": "ValidateAndDecide.xaml",
      "detail": "Line 274: Unbalanced parentheses: 0 open vs 1 close — removed 1 extra closing paren(s) | max nesting depth: 0, first imbalance near position 105, fragment: \"/\\&quot;c) &amp; \\\" in expression: {&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;coupaBaseUrl...",
      "severity": "warning"
    },
    {
      "check": "BARE_TOKEN_QUOTED",
      "file": "InitAllSettings.xaml",
      "detail": "Auto-quoted bare token \"Settings\" for uexcel:ExcelReadRange.SheetName (expected String type) — wrapped in VB string quotes",
      "severity": "warning"
    },
    {
      "check": "BARE_TOKEN_QUOTED",
      "file": "InitAllSettings.xaml",
      "detail": "Auto-quoted bare token \"Constants\" for uexcel:ExcelReadRange.SheetName (expected String type) — wrapped in VB string quotes",
      "severity": "warning"
    },
    {
      "check": "BARE_TOKEN_QUOTED",
      "file": "InitAllSettings.xaml",
      "detail": "Auto-quoted bare token \"Cred_Coupa_API\" for ui:GetCredential.AssetName (expected String type) — wrapped in VB string quotes",
      "severity": "warning"
    },
    {
      "check": "RETRY_INTERVAL_DEFAULTED",
      "file": "RetrieveInvoicePdf.xaml",
      "detail": "Post-repair: RetryInterval defaulted to \"00:00:05\" — verify this is appropriate for the workflow context",
      "severity": "warning"
    },
    {
      "check": "RETRY_INTERVAL_DEFAULTED",
      "file": "RetrieveInvoicePdf.xaml",
      "detail": "Post-repair: RetryInterval defaulted to \"00:00:05\" — verify this is appropriate for the workflow context",
      "severity": "warning"
    },
    {
      "check": "RETRY_INTERVAL_DEFAULTED",
      "file": "ValidateAndDecide.xaml",
      "detail": "Post-repair: RetryInterval defaulted to \"00:00:05\" — verify this is appropriate for the workflow context",
      "severity": "warning"
    }
  ],
  "totalEstimatedEffortMinutes": 205,
  "studioCompatibility": [
    {
      "file": "Main.xaml",
      "level": "studio-blocked",
      "blockers": [
        "[COMPLIANCE-FAILURE] Compliance or quality gate failure requiring manual remediation"
      ],
      "failureCategory": "compliance-failure",
      "failureSummary": "Compliance or quality gate failure requiring manual remediation"
    },
    {
      "file": "Dispatcher.xaml",
      "level": "studio-blocked",
      "blockers": [
        "[COMPLIANCE-FAILURE] Compliance or quality gate failure requiring manual remediation"
      ],
      "failureCategory": "compliance-failure",
      "failureSummary": "Compliance or quality gate failure requiring manual remediation"
    },
    {
      "file": "InitialiseConfig.xaml",
      "level": "studio-blocked",
      "blockers": [
        "[COMPLIANCE-FAILURE] Compliance or quality gate failure requiring manual remediation"
      ],
      "failureCategory": "compliance-failure",
      "failureSummary": "Compliance or quality gate failure requiring manual remediation"
    },
    {
      "file": "ProcessTransaction.xaml",
      "level": "studio-blocked",
      "blockers": [
        "[COMPLIANCE-FAILURE] Compliance or quality gate failure requiring manual remediation"
      ],
      "failureCategory": "compliance-failure",
      "failureSummary": "Compliance or quality gate failure requiring manual remediation"
    },
    {
      "file": "RetrieveInvoicePdf.xaml",
      "level": "studio-blocked",
      "blockers": [
        "[COMPLIANCE-FAILURE] Compliance or quality gate failure requiring manual remediation"
      ],
      "failureCategory": "compliance-failure",
      "failureSummary": "Compliance or quality gate failure requiring manual remediation"
    },
    {
      "file": "ExtractInvoiceFields.xaml",
      "level": "studio-blocked",
      "blockers": [
        "[COMPLIANCE-FAILURE] Compliance or quality gate failure requiring manual remediation"
      ],
      "failureCategory": "compliance-failure",
      "failureSummary": "Compliance or quality gate failure requiring manual remediation"
    },
    {
      "file": "CreateValidationTask.xaml",
      "level": "studio-clean",
      "blockers": []
    },
    {
      "file": "ValidateAndDecide.xaml",
      "level": "studio-blocked",
      "blockers": [
        "[EXPRESSION-SYNTAX] Expression syntax errors that could not be auto-corrected"
      ],
      "failureCategory": "expression-syntax",
      "failureSummary": "Expression syntax errors that could not be auto-corrected"
    },
    {
      "file": "InitAllSettings.xaml",
      "level": "studio-blocked",
      "blockers": [
        "[COMPLIANCE-FAILURE] Compliance or quality gate failure requiring manual remediation"
      ],
      "failureCategory": "compliance-failure",
      "failureSummary": "Compliance or quality gate failure requiring manual remediation"
    },
    {
      "file": "InitialiseConfig",
      "level": "studio-blocked",
      "blockers": [
        "[COMPLIANCE-FAILURE] Compliance or quality gate failure requiring manual remediation"
      ],
      "failureCategory": "compliance-failure",
      "failureSummary": "Compliance or quality gate failure requiring manual remediation"
    },
    {
      "file": "ProcessTransaction",
      "level": "studio-blocked",
      "blockers": [
        "[COMPLIANCE-FAILURE] Compliance or quality gate failure requiring manual remediation"
      ],
      "failureCategory": "compliance-failure",
      "failureSummary": "Compliance or quality gate failure requiring manual remediation"
    },
    {
      "file": "RetrieveInvoicePdf",
      "level": "studio-blocked",
      "blockers": [
        "[COMPLIANCE-FAILURE] Compliance or quality gate failure requiring manual remediation"
      ],
      "failureCategory": "compliance-failure",
      "failureSummary": "Compliance or quality gate failure requiring manual remediation"
    },
    {
      "file": "ExtractInvoiceFields",
      "level": "studio-blocked",
      "blockers": [
        "[COMPLIANCE-FAILURE] Compliance or quality gate failure requiring manual remediation"
      ],
      "failureCategory": "compliance-failure",
      "failureSummary": "Compliance or quality gate failure requiring manual remediation"
    },
    {
      "file": "CreateValidationTask",
      "level": "studio-blocked",
      "blockers": [
        "[COMPLIANCE-FAILURE] Compliance or quality gate failure requiring manual remediation"
      ],
      "failureCategory": "compliance-failure",
      "failureSummary": "Compliance or quality gate failure requiring manual remediation"
    },
    {
      "file": "ValidateAndDecide",
      "level": "studio-blocked",
      "blockers": [
        "[COMPLIANCE-FAILURE] Compliance or quality gate failure requiring manual remediation"
      ],
      "failureCategory": "compliance-failure",
      "failureSummary": "Compliance or quality gate failure requiring manual remediation"
    }
  ],
  "invokeContractTrace": [
    {
      "callerWorkflow": "Main.xaml",
      "targetWorkflow": "InitialiseConfig",
      "targetDeclaredArguments": [
        "in_Config"
      ],
      "providedBindings": {
        "Arguments": "[{&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;New Dictionary(Of String, Object) From {{\\&quot;out_Config\\&quot;, dictConfig}}&quot;}]"
      },
      "unknownTargetArguments": [
        "Arguments"
      ],
      "missingRequiredArguments": [
        "in_Config"
      ],
      "undeclaredSymbols": [
        "out_Config"
      ]
    },
    {
      "callerWorkflow": "Main.xaml",
      "targetWorkflow": "ProcessTransaction",
      "targetDeclaredArguments": [],
      "providedBindings": {
        "Arguments": "[{&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;New Dictionary(Of String, Object) From {{\\&quot;in_TransactionItem\\&quot;, transactionItem}, {\\&quot;in_Config\\&quot;, dictConfig}, {\\&quot;in_CoupaInvoiceId\\&quot;, coupaInvoiceId}, {\\&quot;out_TransactionStatus\\&quot;, transactionStatus}, {\\&quot;out_IsBusinessException\\&quot;, isBusinessException}}&quot;}]"
      },
      "unknownTargetArguments": [
        "Arguments"
      ],
      "missingRequiredArguments": [],
      "undeclaredSymbols": [
        "in_TransactionItem",
        "in_Config",
        "in_CoupaInvoiceId",
        "out_TransactionStatus",
        "out_IsBusinessException"
      ]
    },
    {
      "callerWorkflow": "ProcessTransaction.xaml",
      "targetWorkflow": "RetrieveInvoicePdf",
      "targetDeclaredArguments": [],
      "providedBindings": {
        "Arguments": "[{&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;New Dictionary(Of String, Object) From {{\\&quot;in_CoupaInvoiceId\\&quot;, CoupaInvoiceId}, {\\&quot;in_InvoicePdfUrl\\&quot;, InvoicePdfUrl}, {\\&quot;in_Config\\&quot;, Config}, {\\&quot;out_LocalPdfPath\\&quot;, localPdfPath}, {\\&quot;out_PdfBucketPath\\&quot;, pdfBucketPath}}&quot;}]"
      },
      "unknownTargetArguments": [
        "Arguments"
      ],
      "missingRequiredArguments": [],
      "undeclaredSymbols": [
        "in_CoupaInvoiceId",
        "in_InvoicePdfUrl",
        "in_Config",
        "out_LocalPdfPath",
        "out_PdfBucketPath"
      ]
    },
    {
      "callerWorkflow": "ProcessTransaction.xaml",
      "targetWorkflow": "ExtractInvoiceFields",
      "targetDeclaredArguments": [],
      "providedBindings": {
        "Arguments": "[{&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;New Dictionary(Of String, Object) From {{\\&quot;in_LocalPdfPath\\&quot;, localPdfPath}, {\\&quot;in_CoupaInvoiceId\\&quot;, CoupaInvoiceId}, {\\&quot;in_Config\\&quot;, Config}, {\\&quot;out_ExtractedPONumber\\&quot;, extractedPONumber}, {\\&quot;out_ExtractedInvoiceNumber\\&quot;, extractedInvoiceNumber}, {\\&quot;out_ExtractedVendorName\\&quot;, extractedVendorName}, {\\&quot;out_ExtractedInvoiceTotal\\&quot;, extractedInvoiceTotal}, {\\&quot;out_ExtractedCurrency\\&quot;, extractedCurrency}, {\\&quot;out_ExtractedInvoiceDate\\&quot;, extractedInvoiceDate}, {\\&quot;out_OverallExtractionConfidence\\&quot;, overallExtractionConfidence}, {\\&quot;out_NeedsHumanValidation\\&quot;, needsHumanValidation}}&quot;}]"
      },
      "unknownTargetArguments": [
        "Arguments"
      ],
      "missingRequiredArguments": [],
      "undeclaredSymbols": [
        "in_CoupaInvoiceId",
        "in_Config",
        "in_LocalPdfPath",
        "out_ExtractedPONumber",
        "out_ExtractedInvoiceNumber",
        "out_ExtractedVendorName",
        "out_ExtractedInvoiceTotal",
        "out_ExtractedCurrency",
        "out_ExtractedInvoiceDate",
        "out_OverallExtractionConfidence",
        "out_NeedsHumanValidation"
      ]
    },
    {
      "callerWorkflow": "ProcessTransaction.xaml",
      "targetWorkflow": "CreateValidationTask",
      "targetDeclaredArguments": [],
      "providedBindings": {
        "Arguments": "[{&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;New Dictionary(Of String, Object) From {{\\&quot;in_CoupaInvoiceId\\&quot;, CoupaInvoiceId}, {\\&quot;in_VendorName\\&quot;, VendorName}, {\\&quot;in_ExtractedPONumber\\&quot;, extractedPONumber}, {\\&quot;in_ExtractedInvoiceNumber\\&quot;, extractedInvoiceNumber}, {\\&quot;in_ExtractedInvoiceTotal\\&quot;, extractedInvoiceTotal}, {\\&quot;in_ExtractedCurrency\\&quot;, extractedCurrency}, {\\&quot;in_Config\\&quot;, Config}}&quot;}]"
      },
      "unknownTargetArguments": [
        "Arguments"
      ],
      "missingRequiredArguments": [],
      "undeclaredSymbols": [
        "in_CoupaInvoiceId",
        "in_Config",
        "in_VendorName",
        "in_ExtractedPONumber",
        "in_ExtractedInvoiceNumber",
        "in_ExtractedInvoiceTotal",
        "in_ExtractedCurrency"
      ]
    },
    {
      "callerWorkflow": "ProcessTransaction.xaml",
      "targetWorkflow": "ValidateAndDecide",
      "targetDeclaredArguments": [],
      "providedBindings": {
        "Arguments": "[{&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;New Dictionary(Of String, Object) From {{\\&quot;in_CoupaInvoiceId\\&quot;, CoupaInvoiceId}, {\\&quot;in_PONumber\\&quot;, extractedPONumber}, {\\&quot;in_InvoiceTotal\\&quot;, extractedInvoiceTotal}, {\\&quot;in_VendorName\\&quot;, VendorName}, {\\&quot;in_Config\\&quot;, Config}, {\\&quot;out_FinalCaseStatus\\&quot;, validateAndDecideCaseStatus}, {\\&quot;out_RejectionReasonCode\\&quot;, validateAndDecideRejectionCode}}&quot;}]"
      },
      "unknownTargetArguments": [
        "Arguments"
      ],
      "missingRequiredArguments": [],
      "undeclaredSymbols": [
        "in_CoupaInvoiceId",
        "in_Config",
        "in_VendorName",
        "in_PONumber",
        "in_InvoiceTotal",
        "out_FinalCaseStatus",
        "out_RejectionReasonCode"
      ]
    }
  ],
  "stageHashParity": [
    {
      "workflowFile": "Main.xaml",
      "postGeneration": "7dbb66f8508bbada967d3769878c7ba9f533c0f93bd3c5ca46cd3584f5475c67",
      "postRepair": "7dbb66f8508bbada967d3769878c7ba9f533c0f93bd3c5ca46cd3584f5475c67",
      "postNormalization": "7dbb66f8508bbada967d3769878c7ba9f533c0f93bd3c5ca46cd3584f5475c67",
      "preCanonicalization": "53a70c603eb06f06582906c40dcf7be3ae7053ec8644daf797b8105e25de00a8",
      "archivedFile": "95e2b3a56dd6f2f7e089df88f84c5c533061ad4ef1ab0108722082962d66ca28",
      "postFinalValidationInput": "95e2b3a56dd6f2f7e089df88f84c5c533061ad4ef1ab0108722082962d66ca28",
      "preArchive": "95e2b3a56dd6f2f7e089df88f84c5c533061ad4ef1ab0108722082962d66ca28"
    },
    {
      "workflowFile": "Dispatcher.xaml",
      "postGeneration": "59e0e71b47e2f71cebe05326e23d2a542615d74482318197cd25ee377ad6171a",
      "postRepair": "59e0e71b47e2f71cebe05326e23d2a542615d74482318197cd25ee377ad6171a",
      "postNormalization": "59e0e71b47e2f71cebe05326e23d2a542615d74482318197cd25ee377ad6171a",
      "preCanonicalization": "4097d1b5d5a138ebb9cb1177f8b6da0d2ebeb039461c44f705473d8b121ceef6",
      "archivedFile": "98bb31d721f2fb47a79ace4ac3a050b07c5450a250a3b919709b5bc942abed6e",
      "postFinalValidationInput": "98bb31d721f2fb47a79ace4ac3a050b07c5450a250a3b919709b5bc942abed6e",
      "preArchive": "98bb31d721f2fb47a79ace4ac3a050b07c5450a250a3b919709b5bc942abed6e"
    },
    {
      "workflowFile": "InitialiseConfig.xaml",
      "postGeneration": "dc0d25486374aef6c092596071d62585697819159d98fd04d24277ec6302a6e3",
      "postRepair": "dc0d25486374aef6c092596071d62585697819159d98fd04d24277ec6302a6e3",
      "postNormalization": "dc0d25486374aef6c092596071d62585697819159d98fd04d24277ec6302a6e3",
      "preCanonicalization": "7f7907e4ef548d69559a60a246b821e646261843c54c0c0e553cc715d4f1157c",
      "archivedFile": "a93a316afc5150edb94288ae5a238d0d82ac3321af6a9c39a9b001feac43c658",
      "postFinalValidationInput": "a93a316afc5150edb94288ae5a238d0d82ac3321af6a9c39a9b001feac43c658",
      "preArchive": "a93a316afc5150edb94288ae5a238d0d82ac3321af6a9c39a9b001feac43c658"
    },
    {
      "workflowFile": "ProcessTransaction.xaml",
      "postGeneration": "95a2a24d4ec3a306b3ccf3e81620ae7481662f0ac3c8f6b72675e41aecbb10a7",
      "postRepair": "95a2a24d4ec3a306b3ccf3e81620ae7481662f0ac3c8f6b72675e41aecbb10a7",
      "postNormalization": "95a2a24d4ec3a306b3ccf3e81620ae7481662f0ac3c8f6b72675e41aecbb10a7",
      "preCanonicalization": "88795396df483d629f85103276db97c609c71b38627e90b49ed015ea8b3151aa",
      "archivedFile": "67ca8703cf90f9af3572a29913c42927ba3b1a79de5011e0145978351bf2fcef",
      "postFinalValidationInput": "67ca8703cf90f9af3572a29913c42927ba3b1a79de5011e0145978351bf2fcef",
      "preArchive": "67ca8703cf90f9af3572a29913c42927ba3b1a79de5011e0145978351bf2fcef"
    },
    {
      "workflowFile": "RetrieveInvoicePdf.xaml",
      "postGeneration": "9b61118a31f304936c1b3a9b182e8b2b9da77b72c45353d9f997d76e9738af1e",
      "postRepair": "9b61118a31f304936c1b3a9b182e8b2b9da77b72c45353d9f997d76e9738af1e",
      "postNormalization": "9b61118a31f304936c1b3a9b182e8b2b9da77b72c45353d9f997d76e9738af1e",
      "preCanonicalization": "894884fb148e2f14a35a49f5ff126f85ce687347cc63d9bee471933a4fc8a90d",
      "archivedFile": "f692bab3ec60059aae9243b3293942e36fd44ed8faacfa7d619ec4d76f3ca11b",
      "postFinalValidationInput": "f692bab3ec60059aae9243b3293942e36fd44ed8faacfa7d619ec4d76f3ca11b",
      "preArchive": "f692bab3ec60059aae9243b3293942e36fd44ed8faacfa7d619ec4d76f3ca11b"
    },
    {
      "workflowFile": "ExtractInvoiceFields.xaml",
      "postGeneration": "87391660d53ed3e4a4c0da17f924edc41bb8589e00f5c3f1c022c1f06debe47d",
      "postRepair": "87391660d53ed3e4a4c0da17f924edc41bb8589e00f5c3f1c022c1f06debe47d",
      "postNormalization": "87391660d53ed3e4a4c0da17f924edc41bb8589e00f5c3f1c022c1f06debe47d",
      "preCanonicalization": "0e014b02a58fc809298dd656c9b094ca2081cb7ffb30239c1ff2ed3ee919769b",
      "archivedFile": "bd20252928a59768810a45d76aec152cd665ef0910d01b93f8c5f8bd410ae524",
      "postFinalValidationInput": "bd20252928a59768810a45d76aec152cd665ef0910d01b93f8c5f8bd410ae524",
      "preArchive": "bd20252928a59768810a45d76aec152cd665ef0910d01b93f8c5f8bd410ae524"
    },
    {
      "workflowFile": "ValidateAndDecide.xaml",
      "postGeneration": "884395b169a237dc7a1d2fcf020e94142ea4a769e6d22e96fb31f49f94c2c6f7",
      "postRepair": "884395b169a237dc7a1d2fcf020e94142ea4a769e6d22e96fb31f49f94c2c6f7",
      "postNormalization": "884395b169a237dc7a1d2fcf020e94142ea4a769e6d22e96fb31f49f94c2c6f7",
      "preCanonicalization": "fa4fe7f5098f358c13d71c5b433742020646fb6eca805abce23bd31f6d1e4abe",
      "archivedFile": "d6b3824f73afe05c901a88c6dcfa89fa07ccd3e87e747ac520ed398780b50074",
      "postFinalValidationInput": "d6b3824f73afe05c901a88c6dcfa89fa07ccd3e87e747ac520ed398780b50074",
      "preArchive": "d6b3824f73afe05c901a88c6dcfa89fa07ccd3e87e747ac520ed398780b50074"
    },
    {
      "workflowFile": "InitAllSettings.xaml",
      "postGeneration": "3e17289cad7f6c78db30cadfe9e528a9280b3b8e80e0402f739d8869bec183f4",
      "postRepair": "3e17289cad7f6c78db30cadfe9e528a9280b3b8e80e0402f739d8869bec183f4",
      "postNormalization": "3e17289cad7f6c78db30cadfe9e528a9280b3b8e80e0402f739d8869bec183f4",
      "preCanonicalization": "64e6306774a67dc60a66faed3c0cf330e8c34a6fde53339854591e49c02b9fff",
      "archivedFile": "64e6306774a67dc60a66faed3c0cf330e8c34a6fde53339854591e49c02b9fff",
      "postFinalValidationInput": "64e6306774a67dc60a66faed3c0cf330e8c34a6fde53339854591e49c02b9fff",
      "preArchive": "64e6306774a67dc60a66faed3c0cf330e8c34a6fde53339854591e49c02b9fff"
    },
    {
      "workflowFile": "InitialiseConfig",
      "postNormalization": "c7344f4ebac89d06fefb3e6ddc28cd157834d353f116fae212c3b0ddaa382f4c"
    },
    {
      "workflowFile": "ProcessTransaction",
      "postNormalization": "558fb3f50387944e628e2b308fd2539c9b9af244d6df02b8783f37e265a7bedf"
    },
    {
      "workflowFile": "RetrieveInvoicePdf",
      "postNormalization": "dc466aafe14aee5926fd09e4b2b8b5bdf6b8eb4e1cba98932d78ab475fa06bcc"
    },
    {
      "workflowFile": "ExtractInvoiceFields",
      "postNormalization": "c9c82a3ff31a0c1ac6d732746813b1398c5329a93c634fcb41d560abd82fc72a"
    },
    {
      "workflowFile": "CreateValidationTask",
      "postNormalization": "c3ddd2ad21fcdb8cce50c23740a347f31c7cc7d361ddce677783a4960a2d1b33"
    },
    {
      "workflowFile": "ValidateAndDecide",
      "postNormalization": "36eb13c85b8f367c976523023148aa0b270e1dfdf50b9d5f82e5f84a05531d0a"
    }
  ],
  "preEmissionValidation": {
    "totalActivities": 0,
    "validActivities": 0,
    "unknownActivities": 0,
    "strippedProperties": 0,
    "enumCorrections": 0,
    "missingRequiredFilled": 0,
    "commentConversions": 0,
    "issueCount": 0
  },
  "invokeSerializationFixes": [
    {
      "originalForm": "Message=\"{&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;\\&quot;[Main][Init] CoupaInvoiceRecon Performer starting. RunId=\\&quot; &amp; runId &amp; \\&quot; StartUtc=\\&quot; &amp; processStar\"",
      "canonicalizedForm": "Message=\"[\"[Main][Init] CoupaInvoiceRecon Performer starting. RunId=\" & runId & \" StartUtc=\" & processStartTime.ToString(\"o\")]\"",
      "normalizationType": "json_expression_normalize",
      "file": "lib/net45/Main.xaml",
      "workflow": "Main",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "rationale": "JSON expression leak in Message normalized to VB expression"
    },
    {
      "originalForm": "Message=\"{&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;\\&quot;[Main][Init] Configuration loaded successfully. TolerancePercent=\\&quot; &amp; dictConfig(\\&quot;Business.TolerancePercent\\&q\"",
      "canonicalizedForm": "Message=\"[\"[Main][Init] Configuration loaded successfully. TolerancePercent=\" & dictConfig(\"Business.TolerancePercent\").ToString() & \" ConfidenceThreshold=\" & dictConfig(\"DU.ConfidenceThreshold\").ToString() & \" Queue=\" & queueName]\"",
      "normalizationType": "json_expression_normalize",
      "file": "lib/net45/Main.xaml",
      "workflow": "Main",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "rationale": "JSON expression leak in Message normalized to VB expression"
    },
    {
      "originalForm": "Message=\"{&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;\\&quot;[Main][Init] WARN: shouldStopProcessing=True after Init. No transactions will be processed. RunId=\\&quot; &amp; runId&quot;}\"",
      "canonicalizedForm": "Message=\"[\"[Main][Init] WARN: shouldStopProcessing=True after Init. No transactions will be processed. RunId=\" & runId]\"",
      "normalizationType": "json_expression_normalize",
      "file": "lib/net45/Main.xaml",
      "workflow": "Main",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "rationale": "JSON expression leak in Message normalized to VB expression"
    },
    {
      "originalForm": "Message=\"{&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;\\&quot;[Main][GetTransaction] Queue \\&quot; &amp; queueName &amp; \\&quot; returned no transaction item. Exiting loop. TransactionsPr\"",
      "canonicalizedForm": "Message=\"[\"[Main][GetTransaction] Queue \" & queueName & \" returned no transaction item. Exiting loop. TransactionsProcessed=\" & transactionNumber.ToString() & \" RunId=\" & runId]\"",
      "normalizationType": "json_expression_normalize",
      "file": "lib/net45/Main.xaml",
      "workflow": "Main",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "rationale": "JSON expression leak in Message normalized to VB expression"
    },
    {
      "originalForm": "Message=\"{&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;\\&quot;[Main][Process] Transaction #\\&quot; &amp; transactionNumber.ToString() &amp; \\&quot; started. CoupaInvoiceId=\\&quot; &amp; c\"",
      "canonicalizedForm": "Message=\"[\"[Main][Process] Transaction #\" & transactionNumber.ToString() & \" started. CoupaInvoiceId=\" & coupaInvoiceId & \" RunId=\" & runId]\"",
      "normalizationType": "json_expression_normalize",
      "file": "lib/net45/Main.xaml",
      "workflow": "Main",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "rationale": "JSON expression leak in Message normalized to VB expression"
    },
    {
      "originalForm": "Message=\"{&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;\\&quot;[Main][Process] ProcessTransaction completed. CoupaInvoiceId=\\&quot; &amp; coupaInvoiceId &amp; \\&quot; Status=\\&quot; &amp; \"",
      "canonicalizedForm": "Message=\"[\"[Main][Process] ProcessTransaction completed. CoupaInvoiceId=\" & coupaInvoiceId & \" Status=\" & transactionStatus & \" IsBusinessException=\" & isBusinessException.ToString() & \" ExceptionType=\" & currentExceptionType]\"",
      "normalizationType": "json_expression_normalize",
      "file": "lib/net45/Main.xaml",
      "workflow": "Main",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "rationale": "JSON expression leak in Message normalized to VB expression"
    },
    {
      "originalForm": "Message=\"{&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;\\&quot;[Main][Exception] System exception on transaction #\\&quot; &amp; transactionNumber.ToString() &amp; \\&quot;. CoupaInvoiceId=\\\"",
      "canonicalizedForm": "Message=\"[\"[Main][Exception] System exception on transaction #\" & transactionNumber.ToString() & \". CoupaInvoiceId=\" & coupaInvoiceId & \" ExceptionType=\" & currentExceptionType & \" ConsecutiveFailures=\" & consecutiveSystemExceptions.ToString() & \" MaxAllowed=\" & maxConsecutiveSystemExceptions.ToString() & \" Message=\" & currentExceptionMessage]\"",
      "normalizationType": "json_expression_normalize",
      "file": "lib/net45/Main.xaml",
      "workflow": "Main",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "rationale": "JSON expression leak in Message normalized to VB expression"
    },
    {
      "originalForm": "Message=\"{&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;\\&quot;[Main][Exception] FATAL: Consecutive system exception threshold reached (\\&quot; &amp; consecutiveSystemExceptions.ToString()\"",
      "canonicalizedForm": "Message=\"[\"[Main][Exception] FATAL: Consecutive system exception threshold reached (\" & consecutiveSystemExceptions.ToString() & \"/\" & maxConsecutiveSystemExceptions.ToString() & \"). Stopping performer loop to prevent queue exhaustion. RunId=\" & runId & \" LastInvoiceId=\" & coupaInvoiceId]\"",
      "normalizationType": "json_expression_normalize",
      "file": "lib/net45/Main.xaml",
      "workflow": "Main",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "rationale": "JSON expression leak in Message normalized to VB expression"
    },
    {
      "originalForm": "Message=\"{&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;\\&quot;[Main][Process] Transaction #\\&quot; &amp; transactionNumber.ToString() &amp; \\&quot; complete. CoupaInvoiceId=\\&quot; &amp; \"",
      "canonicalizedForm": "Message=\"[\"[Main][Process] Transaction #\" & transactionNumber.ToString() & \" complete. CoupaInvoiceId=\" & coupaInvoiceId & \" FinalStatus=\" & transactionStatus & \" RunningTotal: Processed=\" & totalProcessed.ToString() & \" Succeeded=\" & totalSucceeded.ToString() & \" Failed=\" & totalFailed.ToString()]\"",
      "normalizationType": "json_expression_normalize",
      "file": "lib/net45/Main.xaml",
      "workflow": "Main",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "rationale": "JSON expression leak in Message normalized to VB expression"
    },
    {
      "originalForm": "Message=\"{&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;\\&quot;[Main][End] CoupaInvoiceRecon Performer completed. RunId=\\&quot; &amp; runId &amp; \\&quot; TotalProcessed=\\&quot; &amp; total\"",
      "canonicalizedForm": "Message=\"[\"[Main][End] CoupaInvoiceRecon Performer completed. RunId=\" & runId & \" TotalProcessed=\" & totalProcessed.ToString() & \" Succeeded=\" & totalSucceeded.ToString() & \" Failed=\" & totalFailed.ToString() & \" DurationSeconds=\" & (processEndTime - processStartTime).TotalSeconds.ToString(\"F1\") & \" StoppedEarly=\" & shouldStopProcessing.ToString()]\"",
      "normalizationType": "json_expression_normalize",
      "file": "lib/net45/Main.xaml",
      "workflow": "Main",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "rationale": "JSON expression leak in Message normalized to VB expression"
    },
    {
      "originalForm": "Condition=\"{&quot;type&quot;:&quot;expression&quot;,&quot;left&quot;:&quot;shouldStopProcessing&quot;,&quot;operator&quot;:&quot;=&quot;,&quot;right&quot;:&quot;False&quot;}\"",
      "canonicalizedForm": "Condition=\"[shouldStopProcessing = False]\"",
      "normalizationType": "json_expression_normalize",
      "file": "lib/net45/Main.xaml",
      "workflow": "Main",
      "activityType": "While",
      "propertyName": "Condition",
      "rationale": "JSON expression leak in Condition normalized to VB expression"
    },
    {
      "originalForm": "Message=\"{&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;\\&quot;[Dispatcher] Config loaded. BaseUrl=\\&quot; &amp; str_CoupaBaseUrl &amp; \\&quot; | LastRunUtc=\\&quot; &amp; str_LastRunUtc &a\"",
      "canonicalizedForm": "Message=\"[\"[Dispatcher] Config loaded. BaseUrl=\" & str_CoupaBaseUrl & \" | LastRunUtc=\" & str_LastRunUtc & \" | LookbackMinutes=\" & int_LookbackMinutes.ToString() & \" | PollingEnabled=\" & bool_PollingEnabled.ToString()]\"",
      "normalizationType": "json_expression_normalize",
      "file": "lib/net45/Dispatcher.xaml",
      "workflow": "Dispatcher",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "rationale": "JSON expression leak in Message normalized to VB expression"
    },
    {
      "originalForm": "Message=\"{&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;\\&quot;[Dispatcher] Coupa API responded successfully. Response length=\\&quot; &amp; str_CoupaApiResponse.Length.ToString() &amp; \\&q\"",
      "canonicalizedForm": "Message=\"[\"[Dispatcher] Coupa API responded successfully. Response length=\" & str_CoupaApiResponse.Length.ToString() & \" chars. Proceeding to deserialise.\"]\"",
      "normalizationType": "json_expression_normalize",
      "file": "lib/net45/Dispatcher.xaml",
      "workflow": "Dispatcher",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "rationale": "JSON expression leak in Message normalized to VB expression"
    },
    {
      "originalForm": "Message=\"{&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;\\&quot;[Dispatcher] Processing invoice. CoupaInvoiceId=\\&quot; &amp; str_CurrentInvoiceId &amp; \\&quot; | VendorName=\\&quot; &amp; s\"",
      "canonicalizedForm": "Message=\"[\"[Dispatcher] Processing invoice. CoupaInvoiceId=\" & str_CurrentInvoiceId & \" | VendorName=\" & str_CurrentVendorName & \" | SubmittedUtc=\" & str_CurrentSubmittedUtc & \" | PdfUrlPresent=\" & (str_CurrentPdfUrl <> String.Empty).ToString()]\"",
      "normalizationType": "json_expression_normalize",
      "file": "lib/net45/Dispatcher.xaml",
      "workflow": "Dispatcher",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "rationale": "JSON expression leak in Message normalized to VB expression"
    },
    {
      "originalForm": "Message=\"{&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;\\&quot;[Dispatcher] InvoiceCase record created in Data Service. CoupaInvoiceId=\\&quot; &amp; str_CurrentInvoiceId &amp; \\&quot; | St\"",
      "canonicalizedForm": "Message=\"[\"[Dispatcher] InvoiceCase record created in Data Service. CoupaInvoiceId=\" & str_CurrentInvoiceId & \" | Status=Queued | QueuedUtc=\" & DateTime.UtcNow.ToString(\"yyyy-MM-ddTHH:mm:ssZ\")]\"",
      "normalizationType": "json_expression_normalize",
      "file": "lib/net45/Dispatcher.xaml",
      "workflow": "Dispatcher",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "rationale": "JSON expression leak in Message normalized to VB expression"
    },
    {
      "originalForm": "Value=\"{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;str_CoupaBaseUrl&quot;}\"",
      "canonicalizedForm": "Value=\"[str_CoupaBaseUrl]\"",
      "normalizationType": "json_expression_normalize",
      "file": "lib/net45/Dispatcher.xaml",
      "workflow": "Dispatcher",
      "activityType": "ui:GetAsset",
      "propertyName": "Value",
      "rationale": "JSON expression leak in Value normalized to VB expression"
    },
    {
      "originalForm": "Value=\"{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;bool_PollingEnabled&quot;}\"",
      "canonicalizedForm": "Value=\"[bool_PollingEnabled]\"",
      "normalizationType": "json_expression_normalize",
      "file": "lib/net45/Dispatcher.xaml",
      "workflow": "Dispatcher",
      "activityType": "ui:GetAsset",
      "propertyName": "Value",
      "rationale": "JSON expression leak in Value normalized to VB expression"
    },
    {
      "originalForm": "Value=\"{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;int_LookbackMinutes&quot;}\"",
      "canonicalizedForm": "Value=\"[int_LookbackMinutes]\"",
      "normalizationType": "json_expression_normalize",
      "file": "lib/net45/Dispatcher.xaml",
      "workflow": "Dispatcher",
      "activityType": "ui:GetAsset",
      "propertyName": "Value",
      "rationale": "JSON expression leak in Value normalized to VB expression"
    },
    {
      "originalForm": "Value=\"{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;str_OrchestratorFolder&quot;}\"",
      "canonicalizedForm": "Value=\"[str_OrchestratorFolder]\"",
      "normalizationType": "json_expression_normalize",
      "file": "lib/net45/Dispatcher.xaml",
      "workflow": "Dispatcher",
      "activityType": "ui:GetAsset",
      "propertyName": "Value",
      "rationale": "JSON expression leak in Value normalized to VB expression"
    },
    {
      "originalForm": "Value=\"{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;str_LastRunUtc&quot;}\"",
      "canonicalizedForm": "Value=\"[str_LastRunUtc]\"",
      "normalizationType": "json_expression_normalize",
      "file": "lib/net45/Dispatcher.xaml",
      "workflow": "Dispatcher",
      "activityType": "ui:GetAsset",
      "propertyName": "Value",
      "rationale": "JSON expression leak in Value normalized to VB expression"
    },
    {
      "originalForm": "Result=\"{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;obj_ExistingCaseQuery&quot;}\"",
      "canonicalizedForm": "Result=\"[obj_ExistingCaseQuery]\"",
      "normalizationType": "json_expression_normalize",
      "file": "lib/net45/Dispatcher.xaml",
      "workflow": "Dispatcher",
      "activityType": "uds:QueryEntity",
      "propertyName": "Result",
      "rationale": "JSON expression leak in Result normalized to VB expression"
    },
    {
      "originalForm": "Result=\"{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;obj_NewInvoiceCase&quot;}\"",
      "canonicalizedForm": "Result=\"[obj_NewInvoiceCase]\"",
      "normalizationType": "json_expression_normalize",
      "file": "lib/net45/Dispatcher.xaml",
      "workflow": "Dispatcher",
      "activityType": "unknown",
      "propertyName": "Result",
      "rationale": "JSON expression leak in Result normalized to VB expression"
    },
    {
      "originalForm": "Message=\"{&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;\\&quot;[InitialiseConfig] Asset validation complete. Error count (empty = none): '\\&quot; &amp; str_ValidationErrors &amp; \\&quot;'\\\"",
      "canonicalizedForm": "Message=\"[\"[InitialiseConfig] Asset validation complete. Error count (empty = none): '\" & str_ValidationErrors & \"'\"]\"",
      "normalizationType": "json_expression_normalize",
      "file": "lib/net45/InitialiseConfig.xaml",
      "workflow": "InitialiseConfig",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "rationale": "JSON expression leak in Message normalized to VB expression"
    },
    {
      "originalForm": "Value=\"{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;str_CoupaBaseUrl&quot;}\"",
      "canonicalizedForm": "Value=\"[str_CoupaBaseUrl]\"",
      "normalizationType": "json_expression_normalize",
      "file": "lib/net45/InitialiseConfig.xaml",
      "workflow": "InitialiseConfig",
      "activityType": "ui:GetAsset",
      "propertyName": "Value",
      "rationale": "JSON expression leak in Value normalized to VB expression"
    },
    {
      "originalForm": "Value=\"{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;str_CoupaPollingEnabled&quot;}\"",
      "canonicalizedForm": "Value=\"[str_CoupaPollingEnabled]\"",
      "normalizationType": "json_expression_normalize",
      "file": "lib/net45/InitialiseConfig.xaml",
      "workflow": "InitialiseConfig",
      "activityType": "ui:GetAsset",
      "propertyName": "Value",
      "rationale": "JSON expression leak in Value normalized to VB expression"
    },
    {
      "originalForm": "Value=\"{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;str_CoupaPollingLookbackMinutes&quot;}\"",
      "canonicalizedForm": "Value=\"[str_CoupaPollingLookbackMinutes]\"",
      "normalizationType": "json_expression_normalize",
      "file": "lib/net45/InitialiseConfig.xaml",
      "workflow": "InitialiseConfig",
      "activityType": "ui:GetAsset",
      "propertyName": "Value",
      "rationale": "JSON expression leak in Value normalized to VB expression"
    },
    {
      "originalForm": "Value=\"{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;str_TolerancePercent&quot;}\"",
      "canonicalizedForm": "Value=\"[str_TolerancePercent]\"",
      "normalizationType": "json_expression_normalize",
      "file": "lib/net45/InitialiseConfig.xaml",
      "workflow": "InitialiseConfig",
      "activityType": "ui:GetAsset",
      "propertyName": "Value",
      "rationale": "JSON expression leak in Value normalized to VB expression"
    },
    {
      "originalForm": "Value=\"{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;str_ToleranceBasis&quot;}\"",
      "canonicalizedForm": "Value=\"[str_ToleranceBasis]\"",
      "normalizationType": "json_expression_normalize",
      "file": "lib/net45/InitialiseConfig.xaml",
      "workflow": "InitialiseConfig",
      "activityType": "ui:GetAsset",
      "propertyName": "Value",
      "rationale": "JSON expression leak in Value normalized to VB expression"
    },
    {
      "originalForm": "Value=\"{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;str_DuConfidenceThreshold&quot;}\"",
      "canonicalizedForm": "Value=\"[str_DuConfidenceThreshold]\"",
      "normalizationType": "json_expression_normalize",
      "file": "lib/net45/InitialiseConfig.xaml",
      "workflow": "InitialiseConfig",
      "activityType": "ui:GetAsset",
      "propertyName": "Value",
      "rationale": "JSON expression leak in Value normalized to VB expression"
    },
    {
      "originalForm": "Value=\"{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;str_ActionCenterSlaHours&quot;}\"",
      "canonicalizedForm": "Value=\"[str_ActionCenterSlaHours]\"",
      "normalizationType": "json_expression_normalize",
      "file": "lib/net45/InitialiseConfig.xaml",
      "workflow": "InitialiseConfig",
      "activityType": "ui:GetAsset",
      "propertyName": "Value",
      "rationale": "JSON expression leak in Value normalized to VB expression"
    },
    {
      "originalForm": "Value=\"{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;str_StorageRetentionDays&quot;}\"",
      "canonicalizedForm": "Value=\"[str_StorageRetentionDays]\"",
      "normalizationType": "json_expression_normalize",
      "file": "lib/net45/InitialiseConfig.xaml",
      "workflow": "InitialiseConfig",
      "activityType": "ui:GetAsset",
      "propertyName": "Value",
      "rationale": "JSON expression leak in Value normalized to VB expression"
    },
    {
      "originalForm": "Value=\"{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;str_OrchestratorFolderName&quot;}\"",
      "canonicalizedForm": "Value=\"[str_OrchestratorFolderName]\"",
      "normalizationType": "json_expression_normalize",
      "file": "lib/net45/InitialiseConfig.xaml",
      "workflow": "InitialiseConfig",
      "activityType": "ui:GetAsset",
      "propertyName": "Value",
      "rationale": "JSON expression leak in Value normalized to VB expression"
    },
    {
      "originalForm": "Exception=\"{&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;New BusinessRuleException(\\&quot;[InitialiseConfig] Configuration validation failed. Errors: \\&quot; &amp; str_ValidationErrors)&quo\"",
      "canonicalizedForm": "Exception=\"[New BusinessRuleException(\"[InitialiseConfig] Configuration validation failed. Errors: \" & str_ValidationErrors)]\"",
      "normalizationType": "json_expression_normalize",
      "file": "lib/net45/InitialiseConfig.xaml",
      "workflow": "InitialiseConfig",
      "activityType": "Throw",
      "propertyName": "Exception",
      "rationale": "JSON expression leak in Exception normalized to VB expression"
    },
    {
      "originalForm": "Message=\"{&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;\\&quot;[ProcessTransaction] START CoupaInvoiceId=\\&quot; &amp; CoupaInvoiceId &amp; \\&quot; VendorName=\\&quot; &amp; VendorName &amp\"",
      "canonicalizedForm": "Message=\"[\"[ProcessTransaction] START CoupaInvoiceId=\" & CoupaInvoiceId & \" VendorName=\" & VendorName & \" IsResumedFromValidation=\" & IsResumedFromValidation.ToString()]\"",
      "normalizationType": "json_expression_normalize",
      "file": "lib/net45/ProcessTransaction.xaml",
      "workflow": "ProcessTransaction",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "rationale": "JSON expression leak in Message normalized to VB expression"
    },
    {
      "originalForm": "Message=\"{&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;\\&quot;[ProcessTransaction] InvoiceCase query complete for CoupaInvoiceId=\\&quot; &amp; CoupaInvoiceId &amp; \\&quot;. QueryResult is\"",
      "canonicalizedForm": "Message=\"[\"[ProcessTransaction] InvoiceCase query complete for CoupaInvoiceId=\" & CoupaInvoiceId & \". QueryResult is Nothing=\" & (queryResults Is Nothing).ToString()]\"",
      "normalizationType": "json_expression_normalize",
      "file": "lib/net45/ProcessTransaction.xaml",
      "workflow": "ProcessTransaction",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "rationale": "JSON expression leak in Message normalized to VB expression"
    },
    {
      "originalForm": "Message=\"{&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;\\&quot;[ProcessTransaction] InvoiceCase status set to InProgress. CoupaInvoiceId=\\&quot; &amp; CoupaInvoiceId &amp; \\&quot; PickedUp\"",
      "canonicalizedForm": "Message=\"[\"[ProcessTransaction] InvoiceCase status set to InProgress. CoupaInvoiceId=\" & CoupaInvoiceId & \" PickedUpUtc=\" & pickedUpUtc.ToString(\"o\")]\"",
      "normalizationType": "json_expression_normalize",
      "file": "lib/net45/ProcessTransaction.xaml",
      "workflow": "ProcessTransaction",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "rationale": "JSON expression leak in Message normalized to VB expression"
    },
    {
      "originalForm": "Message=\"{&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;\\&quot;[ProcessTransaction] PDF retrieved. CoupaInvoiceId=\\&quot; &amp; CoupaInvoiceId &amp; \\&quot; LocalPdfPath=\\&quot; &amp; loca\"",
      "canonicalizedForm": "Message=\"[\"[ProcessTransaction] PDF retrieved. CoupaInvoiceId=\" & CoupaInvoiceId & \" LocalPdfPath=\" & localPdfPath & \" BucketPath=\" & pdfBucketPath]\"",
      "normalizationType": "json_expression_normalize",
      "file": "lib/net45/ProcessTransaction.xaml",
      "workflow": "ProcessTransaction",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "rationale": "JSON expression leak in Message normalized to VB expression"
    },
    {
      "originalForm": "Message=\"{&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;\\&quot;[ProcessTransaction] Extraction complete. CoupaInvoiceId=\\&quot; &amp; CoupaInvoiceId &amp; \\&quot; PONumber=\\&quot; &amp; ex\"",
      "canonicalizedForm": "Message=\"[\"[ProcessTransaction] Extraction complete. CoupaInvoiceId=\" & CoupaInvoiceId & \" PONumber=\" & extractedPONumber & \" InvoiceNumber=\" & extractedInvoiceNumber & \" InvoiceTotal=\" & extractedInvoiceTotal.ToString() & \" OverallConfidence=\" & overallExtractionConfidence.ToString() & \" NeedsHumanValidation=\" & needsHumanValidation.ToString()]\"",
      "normalizationType": "json_expression_normalize",
      "file": "lib/net45/ProcessTransaction.xaml",
      "workflow": "ProcessTransaction",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "rationale": "JSON expression leak in Message normalized to VB expression"
    },
    {
      "originalForm": "Message=\"{&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;\\&quot;[ProcessTransaction] WARN Low extraction confidence. CoupaInvoiceId=\\&quot; &amp; CoupaInvoiceId &amp; \\&quot; OverallConfide\"",
      "canonicalizedForm": "Message=\"[\"[ProcessTransaction] WARN Low extraction confidence. CoupaInvoiceId=\" & CoupaInvoiceId & \" OverallConfidence=\" & overallExtractionConfidence.ToString() & \" Threshold=\" & confidenceThreshold.ToString() & \". Invoking CreateValidationTask.\"]\"",
      "normalizationType": "json_expression_normalize",
      "file": "lib/net45/ProcessTransaction.xaml",
      "workflow": "ProcessTransaction",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "rationale": "JSON expression leak in Message normalized to VB expression"
    },
    {
      "originalForm": "Message=\"{&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;\\&quot;[ProcessTransaction] Action Center task created. CoupaInvoiceId=\\&quot; &amp; CoupaInvoiceId &amp; \\&quot; TransactionOutcome\"",
      "canonicalizedForm": "Message=\"[\"[ProcessTransaction] Action Center task created. CoupaInvoiceId=\" & CoupaInvoiceId & \" TransactionOutcome=PendingValidation. Exiting for queue-based AC resumption.\"]\"",
      "normalizationType": "json_expression_normalize",
      "file": "lib/net45/ProcessTransaction.xaml",
      "workflow": "ProcessTransaction",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "rationale": "JSON expression leak in Message normalized to VB expression"
    },
    {
      "originalForm": "Message=\"{&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;\\&quot;[ProcessTransaction] ValidateAndDecide complete. CoupaInvoiceId=\\&quot; &amp; CoupaInvoiceId &amp; \\&quot; FinalCaseStatus=\\&\"",
      "canonicalizedForm": "Message=\"[\"[ProcessTransaction] ValidateAndDecide complete. CoupaInvoiceId=\" & CoupaInvoiceId & \" FinalCaseStatus=\" & finalCaseStatus & \" RejectionReasonCode=\" & rejectionReasonCode]\"",
      "normalizationType": "json_expression_normalize",
      "file": "lib/net45/ProcessTransaction.xaml",
      "workflow": "ProcessTransaction",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "rationale": "JSON expression leak in Message normalized to VB expression"
    },
    {
      "originalForm": "Result=\"{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;queryResults&quot;}\"",
      "canonicalizedForm": "Result=\"[queryResults]\"",
      "normalizationType": "json_expression_normalize",
      "file": "lib/net45/ProcessTransaction.xaml",
      "workflow": "ProcessTransaction",
      "activityType": "uds:QueryEntity",
      "propertyName": "Result",
      "rationale": "JSON expression leak in Result normalized to VB expression"
    },
    {
      "originalForm": "Message=\"{&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;\\&quot;[RetrieveInvoicePdf] START — CoupaInvoiceId=\\&quot; &amp; CoupaInvoiceId &amp; \\&quot; | InvoicePdfUrl=\\&quot; &amp; InvoiceP\"",
      "canonicalizedForm": "Message=\"[\"[RetrieveInvoicePdf] START — CoupaInvoiceId=\" & CoupaInvoiceId & \" | InvoicePdfUrl=\" & InvoicePdfUrl]\"",
      "normalizationType": "json_expression_normalize",
      "file": "lib/net45/RetrieveInvoicePdf.xaml",
      "workflow": "RetrieveInvoicePdf",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "rationale": "JSON expression leak in Message normalized to VB expression"
    },
    {
      "originalForm": "Message=\"{&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;\\&quot;[RetrieveInvoicePdf] Initiating PDF download — CoupaInvoiceId=\\&quot; &amp; CoupaInvoiceId &amp; \\&quot; | CandidatePath=\\&qu\"",
      "canonicalizedForm": "Message=\"[\"[RetrieveInvoicePdf] Initiating PDF download — CoupaInvoiceId=\" & CoupaInvoiceId & \" | CandidatePath=\" & candidateLocalPath & \" | BucketPath=\" & bucketPathResolved]\"",
      "normalizationType": "json_expression_normalize",
      "file": "lib/net45/RetrieveInvoicePdf.xaml",
      "workflow": "RetrieveInvoicePdf",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "rationale": "JSON expression leak in Message normalized to VB expression"
    },
    {
      "originalForm": "Message=\"{&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;\\&quot;[RetrieveInvoicePdf] Download attempt \\&quot; &amp; downloadAttempt.ToString() &amp; \\&quot; — CoupaInvoiceId=\\&quot; &amp; C\"",
      "canonicalizedForm": "Message=\"[\"[RetrieveInvoicePdf] Download attempt \" & downloadAttempt.ToString() & \" — CoupaInvoiceId=\" & CoupaInvoiceId & \" | Url=\" & InvoicePdfUrl]\"",
      "normalizationType": "json_expression_normalize",
      "file": "lib/net45/RetrieveInvoicePdf.xaml",
      "workflow": "RetrieveInvoicePdf",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "rationale": "JSON expression leak in Message normalized to VB expression"
    },
    {
      "originalForm": "Message=\"{&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;\\&quot;[RetrieveInvoicePdf] FileLockDetected=\\&quot; &amp; fileLockDetected.ToString() &amp; \\&quot; | ResolvedLocalPath=\\&quot; &am\"",
      "canonicalizedForm": "Message=\"[\"[RetrieveInvoicePdf] FileLockDetected=\" & fileLockDetected.ToString() & \" | ResolvedLocalPath=\" & resolvedLocalPath & \" | CoupaInvoiceId=\" & CoupaInvoiceId]\"",
      "normalizationType": "json_expression_normalize",
      "file": "lib/net45/RetrieveInvoicePdf.xaml",
      "workflow": "RetrieveInvoicePdf",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "rationale": "JSON expression leak in Message normalized to VB expression"
    },
    {
      "originalForm": "Message=\"{&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;\\&quot;[RetrieveInvoicePdf] SUCCESS — CoupaInvoiceId=\\&quot; &amp; CoupaInvoiceId &amp; \\&quot; | LocalPath=\\&quot; &amp; resolvedLo\"",
      "canonicalizedForm": "Message=\"[\"[RetrieveInvoicePdf] SUCCESS — CoupaInvoiceId=\" & CoupaInvoiceId & \" | LocalPath=\" & resolvedLocalPath & \" | FileSizeBytes=\" & fileSizeBytes.ToString() & \" | BucketPath=\" & bucketPathResolved & \" | DownloadAttempts=\" & downloadAttempt.ToString()]\"",
      "normalizationType": "json_expression_normalize",
      "file": "lib/net45/RetrieveInvoicePdf.xaml",
      "workflow": "RetrieveInvoicePdf",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "rationale": "JSON expression leak in Message normalized to VB expression"
    },
    {
      "originalForm": "Value=\"{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;coupaBaseUrl&quot;}\"",
      "canonicalizedForm": "Value=\"[coupaBaseUrl]\"",
      "normalizationType": "json_expression_normalize",
      "file": "lib/net45/RetrieveInvoicePdf.xaml",
      "workflow": "RetrieveInvoicePdf",
      "activityType": "ui:GetAsset",
      "propertyName": "Value",
      "rationale": "JSON expression leak in Value normalized to VB expression"
    },
    {
      "originalForm": "Message=\"{&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;\\&quot;[ExtractInvoiceFields] START — CoupaInvoiceId=\\&quot; &amp; CoupaInvoiceId &amp; \\&quot; | LocalPdfPath=\\&quot; &amp; LocalPd\"",
      "canonicalizedForm": "Message=\"[\"[ExtractInvoiceFields] START — CoupaInvoiceId=\" & CoupaInvoiceId & \" | LocalPdfPath=\" & LocalPdfPath]\"",
      "normalizationType": "json_expression_normalize",
      "file": "lib/net45/ExtractInvoiceFields.xaml",
      "workflow": "ExtractInvoiceFields",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "rationale": "JSON expression leak in Message normalized to VB expression"
    },
    {
      "originalForm": "Message=\"{&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;\\&quot;[ExtractInvoiceFields] Digitize complete — CoupaInvoiceId=\\&quot; &amp; CoupaInvoiceId &amp; \\&quot; | DocumentPages=\\&quot; \"",
      "canonicalizedForm": "Message=\"[\"[ExtractInvoiceFields] Digitize complete — CoupaInvoiceId=\" & CoupaInvoiceId & \" | DocumentPages=\" & If(digitizedDocument IsNot Nothing, \"(document object available)\", \"null\")]\"",
      "normalizationType": "json_expression_normalize",
      "file": "lib/net45/ExtractInvoiceFields.xaml",
      "workflow": "ExtractInvoiceFields",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "rationale": "JSON expression leak in Message normalized to VB expression"
    },
    {
      "originalForm": "Message=\"{&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;\\&quot;[ExtractInvoiceFields] ExtractDocumentData complete — CoupaInvoiceId=\\&quot; &amp; CoupaInvoiceId &amp; \\&quot; | ResultsAvai\"",
      "canonicalizedForm": "Message=\"[\"[ExtractInvoiceFields] ExtractDocumentData complete — CoupaInvoiceId=\" & CoupaInvoiceId & \" | ResultsAvailable=\" & If(extractionResults IsNot Nothing, \"True\", \"False\")]\"",
      "normalizationType": "json_expression_normalize",
      "file": "lib/net45/ExtractInvoiceFields.xaml",
      "workflow": "ExtractInvoiceFields",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "rationale": "JSON expression leak in Message normalized to VB expression"
    },
    {
      "originalForm": "Message=\"{&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;\\&quot;[ExtractInvoiceFields] FieldConfidences — CoupaInvoiceId=\\&quot; &amp; CoupaInvoiceId &amp; \\&quot; | PONumber=\\&quot; &amp; \"",
      "canonicalizedForm": "Message=\"[\"[ExtractInvoiceFields] FieldConfidences — CoupaInvoiceId=\" & CoupaInvoiceId & \" | PONumber=\" & poNumberConfidenceDouble.ToString(\"F4\") & \" | InvoiceNumber=\" & invoiceNumberConfidenceDouble.ToString(\"F4\") & \" | VendorName=\" & vendorNameConfidence.ToString(\"F4\") & \" | TotalAmount=\" & totalAmountConfidenceDouble.ToString(\"F4\") & \" | Threshold=\" & confidenceThresholdFraction.ToString(\"F4\")]\"",
      "normalizationType": "json_expression_normalize",
      "file": "lib/net45/ExtractInvoiceFields.xaml",
      "workflow": "ExtractInvoiceFields",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "rationale": "JSON expression leak in Message normalized to VB expression"
    },
    {
      "originalForm": "Message=\"{&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;\\&quot;[ExtractInvoiceFields] ExtractedValues — CoupaInvoiceId=\\&quot; &amp; CoupaInvoiceId &amp; \\&quot; | PONumber='\\&quot; &amp; \"",
      "canonicalizedForm": "Message=\"[\"[ExtractInvoiceFields] ExtractedValues — CoupaInvoiceId=\" & CoupaInvoiceId & \" | PONumber='\" & rawPoNumber & \"' | InvoiceNumber='\" & rawInvoiceNumber & \"' | VendorName='\" & rawVendorName & \"' | TotalAmount='\" & rawInvoiceTotal & \"' | Currency='\" & rawCurrency & \"' | InvoiceDate='\" & rawInvoiceDate & \"'\"]\"",
      "normalizationType": "json_expression_normalize",
      "file": "lib/net45/ExtractInvoiceFields.xaml",
      "workflow": "ExtractInvoiceFields",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "rationale": "JSON expression leak in Message normalized to VB expression"
    },
    {
      "originalForm": "Message=\"{&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;\\&quot;[ExtractInvoiceFields] ConfidenceDecision — CoupaInvoiceId=\\&quot; &amp; CoupaInvoiceId &amp; \\&quot; | FieldsBelowThreshold=\"",
      "canonicalizedForm": "Message=\"[\"[ExtractInvoiceFields] ConfidenceDecision — CoupaInvoiceId=\" & CoupaInvoiceId & \" | FieldsBelowThreshold=\" & fieldsBelowThreshold.ToString() & \" | NeedsHumanValidation=\" & fieldsBelowThreshold.ToString()]\"",
      "normalizationType": "json_expression_normalize",
      "file": "lib/net45/ExtractInvoiceFields.xaml",
      "workflow": "ExtractInvoiceFields",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "rationale": "JSON expression leak in Message normalized to VB expression"
    },
    {
      "originalForm": "Message=\"{&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;\\&quot;[ExtractInvoiceFields] END — CoupaInvoiceId=\\&quot; &amp; CoupaInvoiceId &amp; \\&quot; | OverallConfidence=\\&quot; &amp; Extr\"",
      "canonicalizedForm": "Message=\"[\"[ExtractInvoiceFields] END — CoupaInvoiceId=\" & CoupaInvoiceId & \" | OverallConfidence=\" & ExtractionConfidence & \" | NeedsHumanValidation=\" & NeedsHumanValidation.ToString() & \" | ExtractedPO='\" & ExtractedPONumber & \"' | ExtractedTotal='\" & ExtractedInvoiceTotal & \"'\"]\"",
      "normalizationType": "json_expression_normalize",
      "file": "lib/net45/ExtractInvoiceFields.xaml",
      "workflow": "ExtractInvoiceFields",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "rationale": "JSON expression leak in Message normalized to VB expression"
    },
    {
      "originalForm": "Message=\"{&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;\\&quot;[CreateValidationTask] START — CoupaInvoiceId=\\&quot; &amp; CoupaInvoiceId &amp; \\&quot; | VendorName=\\&quot; &amp; VendorNam\"",
      "canonicalizedForm": "Message=\"[\"[CreateValidationTask] START — CoupaInvoiceId=\" & CoupaInvoiceId & \" | VendorName=\" & VendorName & \" | ExtractedPONumber=\" & ExtractedPONumber & \" | PdfBucketPath=\" & PdfBucketPath]\"",
      "normalizationType": "json_expression_normalize",
      "file": "lib/net45/CreateValidationTask.xaml",
      "workflow": "CreateValidationTask",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "rationale": "JSON expression leak in Message normalized to VB expression"
    },
    {
      "originalForm": "Message=\"{&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;\\&quot;[CreateValidationTask] Action Center task created — CoupaInvoiceId=\\&quot; &amp; CoupaInvoiceId &amp; \\&quot; | TaskId=\\&quot\"",
      "canonicalizedForm": "Message=\"[\"[CreateValidationTask] Action Center task created — CoupaInvoiceId=\" & CoupaInvoiceId & \" | TaskId=\" & createdTaskId & \" | DueUtc=\" & taskDueUtc.ToString(\"o\") & \" | Catalog=AC_CoupaInvoiceRecon_DUValidation\"]\"",
      "normalizationType": "json_expression_normalize",
      "file": "lib/net45/CreateValidationTask.xaml",
      "workflow": "CreateValidationTask",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "rationale": "JSON expression leak in Message normalized to VB expression"
    },
    {
      "originalForm": "Message=\"{&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;\\&quot;[CreateValidationTask] END — CoupaInvoiceId=\\&quot; &amp; CoupaInvoiceId &amp; \\&quot; | TaskId=\\&quot; &amp; createdTaskId &\"",
      "canonicalizedForm": "Message=\"[\"[CreateValidationTask] END — CoupaInvoiceId=\" & CoupaInvoiceId & \" | TaskId=\" & createdTaskId & \" | CaseStatus=PendingValidation | InvoiceCaseId=\" & invoiceCaseId]\"",
      "normalizationType": "json_expression_normalize",
      "file": "lib/net45/CreateValidationTask.xaml",
      "workflow": "CreateValidationTask",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "rationale": "JSON expression leak in Message normalized to VB expression"
    },
    {
      "originalForm": "Value=\"{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;slaHoursRaw&quot;}\"",
      "canonicalizedForm": "Value=\"[slaHoursRaw]\"",
      "normalizationType": "json_expression_normalize",
      "file": "lib/net45/CreateValidationTask.xaml",
      "workflow": "CreateValidationTask",
      "activityType": "ui:GetAsset",
      "propertyName": "Value",
      "rationale": "JSON expression leak in Value normalized to VB expression"
    },
    {
      "originalForm": "Result=\"{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;queriedCases&quot;}\"",
      "canonicalizedForm": "Result=\"[queriedCases]\"",
      "normalizationType": "json_expression_normalize",
      "file": "lib/net45/CreateValidationTask.xaml",
      "workflow": "CreateValidationTask",
      "activityType": "uds:QueryEntity",
      "propertyName": "Result",
      "rationale": "JSON expression leak in Result normalized to VB expression"
    },
    {
      "originalForm": "Message=\"{&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;\\&quot;[ValidateAndDecide][INFO] Starting validation. CoupaInvoiceId=\\&quot; &amp; CoupaInvoiceId &amp; \\&quot; | PONumber=\\&quot; &\"",
      "canonicalizedForm": "Message=\"[\"[ValidateAndDecide][INFO] Starting validation. CoupaInvoiceId=\" & CoupaInvoiceId & \" | PONumber=\" & PONumber & \" | InvoiceTotal=\" & InvoiceTotal & \" | VendorName=\" & VendorName]\"",
      "normalizationType": "json_expression_normalize",
      "file": "lib/net45/ValidateAndDecide.xaml",
      "workflow": "ValidateAndDecide",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "rationale": "JSON expression leak in Message normalized to VB expression"
    },
    {
      "originalForm": "Message=\"{&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;\\&quot;[ValidateAndDecide][INFO] Step1-POLookup: Querying Coupa PO. CoupaInvoiceId=\\&quot; &amp; CoupaInvoiceId &amp; \\&quot; | PONu\"",
      "canonicalizedForm": "Message=\"[\"[ValidateAndDecide][INFO] Step1-POLookup: Querying Coupa PO. CoupaInvoiceId=\" & CoupaInvoiceId & \" | PONumber=\" & PONumber & \" | URL=\" & poLookupUrl]\"",
      "normalizationType": "json_expression_normalize",
      "file": "lib/net45/ValidateAndDecide.xaml",
      "workflow": "ValidateAndDecide",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "rationale": "JSON expression leak in Message normalized to VB expression"
    },
    {
      "originalForm": "Message=\"{&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;\\&quot;[ValidateAndDecide][INFO] Step1-POLookup result: poFound=\\&quot; &amp; poFound.ToString() &amp; \\&quot; | CoupaInvoiceId=\\&qu\"",
      "canonicalizedForm": "Message=\"[\"[ValidateAndDecide][INFO] Step1-POLookup result: poFound=\" & poFound.ToString() & \" | CoupaInvoiceId=\" & CoupaInvoiceId & \" | PONumber=\" & PONumber]\"",
      "normalizationType": "json_expression_normalize",
      "file": "lib/net45/ValidateAndDecide.xaml",
      "workflow": "ValidateAndDecide",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "rationale": "JSON expression leak in Message normalized to VB expression"
    },
    {
      "originalForm": "Message=\"{&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;\\&quot;[ValidateAndDecide][WARN] BusinessRejection: PO_MISMATCH_OR_NOT_FOUND. CoupaInvoiceId=\\&quot; &amp; CoupaInvoiceId &amp; \\&qu\"",
      "canonicalizedForm": "Message=\"[\"[ValidateAndDecide][WARN] BusinessRejection: PO_MISMATCH_OR_NOT_FOUND. CoupaInvoiceId=\" & CoupaInvoiceId & \" | PONumber=\" & PONumber & \" | CoupaResponse=\" & CStr(coupaRejectResponse)]\"",
      "normalizationType": "json_expression_normalize",
      "file": "lib/net45/ValidateAndDecide.xaml",
      "workflow": "ValidateAndDecide",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "rationale": "JSON expression leak in Message normalized to VB expression"
    },
    {
      "originalForm": "Message=\"{&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;\\&quot;[ValidateAndDecide][INFO] Step2-ToleranceCheck: InvoiceTotal=\\&quot; &amp; invoiceTotalDecimal.ToString() &amp; \\&quot; | Ref\"",
      "canonicalizedForm": "Message=\"[\"[ValidateAndDecide][INFO] Step2-ToleranceCheck: InvoiceTotal=\" & invoiceTotalDecimal.ToString() & \" | ReferenceAmount=\" & referenceAmount.ToString() & \" | ToleranceBasis=\" & toleranceBasis & \" | TolerancePercent=\" & tolerancePercent.ToString() & \" | CoupaInvoiceId=\" & CoupaInvoiceId]\"",
      "normalizationType": "json_expression_normalize",
      "file": "lib/net45/ValidateAndDecide.xaml",
      "workflow": "ValidateAndDecide",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "rationale": "JSON expression leak in Message normalized to VB expression"
    },
    {
      "originalForm": "Exception=\"{&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;New UiPath.Core.Activities.BusinessRuleException(\\&quot;PO_MISMATCH_OR_NOT_FOUND: PO '\\&quot; &amp; PONumber &amp; \\&quot;' not foun\"",
      "canonicalizedForm": "Exception=\"[New UiPath.Core.Activities.BusinessRuleException(\"PO_MISMATCH_OR_NOT_FOUND: PO '\" & PONumber & \"' not found or mismatch for invoice '\" & CoupaInvoiceId & \"'. Invoice rejected in Coupa.\")]\"",
      "normalizationType": "json_expression_normalize",
      "file": "lib/net45/ValidateAndDecide.xaml",
      "workflow": "ValidateAndDecide",
      "activityType": "Throw",
      "propertyName": "Exception",
      "rationale": "JSON expression leak in Exception normalized to VB expression"
    },
    {
      "originalForm": "Result=\"{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;poLookupResponse&quot;}\"",
      "canonicalizedForm": "Result=\"[poLookupResponse]\"",
      "normalizationType": "json_expression_normalize",
      "file": "lib/net45/ValidateAndDecide.xaml",
      "workflow": "ValidateAndDecide",
      "activityType": "uweb:HttpClient",
      "propertyName": "Result",
      "rationale": "JSON expression leak in Result normalized to VB expression"
    },
    {
      "originalForm": "Result=\"{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;poLookupResponse&quot;}\"",
      "canonicalizedForm": "Result=\"[poLookupResponse]\"",
      "normalizationType": "json_expression_normalize",
      "file": "lib/net45/ValidateAndDecide.xaml",
      "workflow": "ValidateAndDecide",
      "activityType": "uweb:DeserializeJson",
      "propertyName": "Result",
      "rationale": "JSON expression leak in Result normalized to VB expression"
    },
    {
      "originalForm": "Result=\"{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;coupaRejectResponse&quot;}\"",
      "canonicalizedForm": "Result=\"[coupaRejectResponse]\"",
      "normalizationType": "json_expression_normalize",
      "file": "lib/net45/ValidateAndDecide.xaml",
      "workflow": "ValidateAndDecide",
      "activityType": "uweb:HttpClient",
      "propertyName": "Result",
      "rationale": "JSON expression leak in Result normalized to VB expression"
    },
    {
      "originalForm": "Result=\"{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;invoiceCaseQueryResult&quot;}\"",
      "canonicalizedForm": "Result=\"[invoiceCaseQueryResult]\"",
      "normalizationType": "json_expression_normalize",
      "file": "lib/net45/ValidateAndDecide.xaml",
      "workflow": "ValidateAndDecide",
      "activityType": "uds:QueryEntity",
      "propertyName": "Result",
      "rationale": "JSON expression leak in Result normalized to VB expression"
    }
  ],
  "expressionCanonicalizationFixes": [],
  "symbolScopeDefects": [
    {
      "file": "lib/net45/Main.xaml",
      "workflow": "Main",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "referencedSymbol": "runId",
      "offendingExpression": "[&quot;[Main][Init] CoupaInvoiceRecon Performer starting. RunId=&quot; &amp; runId &amp; &quot; StartUtc=&quot; &amp; processStartTime.ToString(&quot;o&quot;)]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"runId\" referenced in Message but not declared in workflow \"Main\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/Main.xaml",
      "workflow": "Main",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "referencedSymbol": "processStartTime",
      "offendingExpression": "[&quot;[Main][Init] CoupaInvoiceRecon Performer starting. RunId=&quot; &amp; runId &amp; &quot; StartUtc=&quot; &amp; processStartTime.ToString(&quot;o&quot;)]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"processStartTime\" referenced in Message but not declared in workflow \"Main\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/Main.xaml",
      "workflow": "Main",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "referencedSymbol": "dictConfig",
      "offendingExpression": "[&quot;[Main][Init] Configuration loaded successfully. TolerancePercent=&quot; &amp; dictConfig(&quot;Business.TolerancePercent&quot;).ToString() &amp; &quot; ConfidenceThreshold=&quot; &amp; dictConf",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"dictConfig\" referenced in Message but not declared in workflow \"Main\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/Main.xaml",
      "workflow": "Main",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "referencedSymbol": "queueName",
      "offendingExpression": "[&quot;[Main][Init] Configuration loaded successfully. TolerancePercent=&quot; &amp; dictConfig(&quot;Business.TolerancePercent&quot;).ToString() &amp; &quot; ConfidenceThreshold=&quot; &amp; dictConf",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"queueName\" referenced in Message but not declared in workflow \"Main\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/Main.xaml",
      "workflow": "Main",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "referencedSymbol": "runId",
      "offendingExpression": "[&quot;[Main][Init] WARN: shouldStopProcessing=True after Init. No transactions will be processed. RunId=&quot; &amp; runId]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"runId\" referenced in Message but not declared in workflow \"Main\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/Main.xaml",
      "workflow": "Main",
      "activityType": "While",
      "propertyName": "Condition",
      "referencedSymbol": "shouldStopProcessing",
      "offendingExpression": "[shouldStopProcessing = False]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "False",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"shouldStopProcessing\" referenced in Condition but not declared in workflow \"Main\" — expression replaced with \"False\""
    },
    {
      "file": "lib/net45/Main.xaml",
      "workflow": "Main",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "referencedSymbol": "queueName",
      "offendingExpression": "[&quot;[Main][GetTransaction] Queue &quot; &amp; queueName &amp; &quot; returned no transaction item. Exiting loop. TransactionsProcessed=&quot; &amp; transactionNumber.ToString() &amp; &quot; RunId=&",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"queueName\" referenced in Message but not declared in workflow \"Main\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/Main.xaml",
      "workflow": "Main",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "referencedSymbol": "transactionNumber",
      "offendingExpression": "[&quot;[Main][GetTransaction] Queue &quot; &amp; queueName &amp; &quot; returned no transaction item. Exiting loop. TransactionsProcessed=&quot; &amp; transactionNumber.ToString() &amp; &quot; RunId=&",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"transactionNumber\" referenced in Message but not declared in workflow \"Main\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/Main.xaml",
      "workflow": "Main",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "referencedSymbol": "runId",
      "offendingExpression": "[&quot;[Main][GetTransaction] Queue &quot; &amp; queueName &amp; &quot; returned no transaction item. Exiting loop. TransactionsProcessed=&quot; &amp; transactionNumber.ToString() &amp; &quot; RunId=&",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"runId\" referenced in Message but not declared in workflow \"Main\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/Main.xaml",
      "workflow": "Main",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "referencedSymbol": "transactionNumber",
      "offendingExpression": "[&quot;[Main][Process] Transaction #&quot; &amp; transactionNumber.ToString() &amp; &quot; started. CoupaInvoiceId=&quot; &amp; coupaInvoiceId &amp; &quot; RunId=&quot; &amp; runId]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"transactionNumber\" referenced in Message but not declared in workflow \"Main\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/Main.xaml",
      "workflow": "Main",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "referencedSymbol": "coupaInvoiceId",
      "offendingExpression": "[&quot;[Main][Process] Transaction #&quot; &amp; transactionNumber.ToString() &amp; &quot; started. CoupaInvoiceId=&quot; &amp; coupaInvoiceId &amp; &quot; RunId=&quot; &amp; runId]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"coupaInvoiceId\" referenced in Message but not declared in workflow \"Main\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/Main.xaml",
      "workflow": "Main",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "referencedSymbol": "runId",
      "offendingExpression": "[&quot;[Main][Process] Transaction #&quot; &amp; transactionNumber.ToString() &amp; &quot; started. CoupaInvoiceId=&quot; &amp; coupaInvoiceId &amp; &quot; RunId=&quot; &amp; runId]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"runId\" referenced in Message but not declared in workflow \"Main\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/Main.xaml",
      "workflow": "Main",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "referencedSymbol": "coupaInvoiceId",
      "offendingExpression": "[&quot;[Main][Process] ProcessTransaction completed. CoupaInvoiceId=&quot; &amp; coupaInvoiceId &amp; &quot; Status=&quot; &amp; transactionStatus &amp; &quot; IsBusinessException=&quot; &amp; isBusin",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"coupaInvoiceId\" referenced in Message but not declared in workflow \"Main\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/Main.xaml",
      "workflow": "Main",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "referencedSymbol": "transactionStatus",
      "offendingExpression": "[&quot;[Main][Process] ProcessTransaction completed. CoupaInvoiceId=&quot; &amp; coupaInvoiceId &amp; &quot; Status=&quot; &amp; transactionStatus &amp; &quot; IsBusinessException=&quot; &amp; isBusin",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"transactionStatus\" referenced in Message but not declared in workflow \"Main\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/Main.xaml",
      "workflow": "Main",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "referencedSymbol": "isBusinessException",
      "offendingExpression": "[&quot;[Main][Process] ProcessTransaction completed. CoupaInvoiceId=&quot; &amp; coupaInvoiceId &amp; &quot; Status=&quot; &amp; transactionStatus &amp; &quot; IsBusinessException=&quot; &amp; isBusin",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"isBusinessException\" referenced in Message but not declared in workflow \"Main\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/Main.xaml",
      "workflow": "Main",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "referencedSymbol": "currentExceptionType",
      "offendingExpression": "[&quot;[Main][Process] ProcessTransaction completed. CoupaInvoiceId=&quot; &amp; coupaInvoiceId &amp; &quot; Status=&quot; &amp; transactionStatus &amp; &quot; IsBusinessException=&quot; &amp; isBusin",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"currentExceptionType\" referenced in Message but not declared in workflow \"Main\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/Main.xaml",
      "workflow": "Main",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "referencedSymbol": "transactionNumber",
      "offendingExpression": "[&quot;[Main][Exception] System exception on transaction #&quot; &amp; transactionNumber.ToString() &amp; &quot;. CoupaInvoiceId=&quot; &amp; coupaInvoiceId &amp; &quot; ExceptionType=&quot; &amp; cur",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"transactionNumber\" referenced in Message but not declared in workflow \"Main\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/Main.xaml",
      "workflow": "Main",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "referencedSymbol": "coupaInvoiceId",
      "offendingExpression": "[&quot;[Main][Exception] System exception on transaction #&quot; &amp; transactionNumber.ToString() &amp; &quot;. CoupaInvoiceId=&quot; &amp; coupaInvoiceId &amp; &quot; ExceptionType=&quot; &amp; cur",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"coupaInvoiceId\" referenced in Message but not declared in workflow \"Main\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/Main.xaml",
      "workflow": "Main",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "referencedSymbol": "currentExceptionType",
      "offendingExpression": "[&quot;[Main][Exception] System exception on transaction #&quot; &amp; transactionNumber.ToString() &amp; &quot;. CoupaInvoiceId=&quot; &amp; coupaInvoiceId &amp; &quot; ExceptionType=&quot; &amp; cur",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"currentExceptionType\" referenced in Message but not declared in workflow \"Main\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/Main.xaml",
      "workflow": "Main",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "referencedSymbol": "consecutiveSystemExceptions",
      "offendingExpression": "[&quot;[Main][Exception] System exception on transaction #&quot; &amp; transactionNumber.ToString() &amp; &quot;. CoupaInvoiceId=&quot; &amp; coupaInvoiceId &amp; &quot; ExceptionType=&quot; &amp; cur",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"consecutiveSystemExceptions\" referenced in Message but not declared in workflow \"Main\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/Main.xaml",
      "workflow": "Main",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "referencedSymbol": "maxConsecutiveSystemExceptions",
      "offendingExpression": "[&quot;[Main][Exception] System exception on transaction #&quot; &amp; transactionNumber.ToString() &amp; &quot;. CoupaInvoiceId=&quot; &amp; coupaInvoiceId &amp; &quot; ExceptionType=&quot; &amp; cur",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"maxConsecutiveSystemExceptions\" referenced in Message but not declared in workflow \"Main\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/Main.xaml",
      "workflow": "Main",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "referencedSymbol": "currentExceptionMessage",
      "offendingExpression": "[&quot;[Main][Exception] System exception on transaction #&quot; &amp; transactionNumber.ToString() &amp; &quot;. CoupaInvoiceId=&quot; &amp; coupaInvoiceId &amp; &quot; ExceptionType=&quot; &amp; cur",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"currentExceptionMessage\" referenced in Message but not declared in workflow \"Main\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/Main.xaml",
      "workflow": "Main",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "referencedSymbol": "consecutiveSystemExceptions",
      "offendingExpression": "[&quot;[Main][Exception] FATAL: Consecutive system exception threshold reached (&quot; &amp; consecutiveSystemExceptions.ToString() &amp; &quot;/&quot; &amp; maxConsecutiveSystemExceptions.ToString() ",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"consecutiveSystemExceptions\" referenced in Message but not declared in workflow \"Main\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/Main.xaml",
      "workflow": "Main",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "referencedSymbol": "maxConsecutiveSystemExceptions",
      "offendingExpression": "[&quot;[Main][Exception] FATAL: Consecutive system exception threshold reached (&quot; &amp; consecutiveSystemExceptions.ToString() &amp; &quot;/&quot; &amp; maxConsecutiveSystemExceptions.ToString() ",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"maxConsecutiveSystemExceptions\" referenced in Message but not declared in workflow \"Main\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/Main.xaml",
      "workflow": "Main",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "referencedSymbol": "runId",
      "offendingExpression": "[&quot;[Main][Exception] FATAL: Consecutive system exception threshold reached (&quot; &amp; consecutiveSystemExceptions.ToString() &amp; &quot;/&quot; &amp; maxConsecutiveSystemExceptions.ToString() ",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"runId\" referenced in Message but not declared in workflow \"Main\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/Main.xaml",
      "workflow": "Main",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "referencedSymbol": "coupaInvoiceId",
      "offendingExpression": "[&quot;[Main][Exception] FATAL: Consecutive system exception threshold reached (&quot; &amp; consecutiveSystemExceptions.ToString() &amp; &quot;/&quot; &amp; maxConsecutiveSystemExceptions.ToString() ",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"coupaInvoiceId\" referenced in Message but not declared in workflow \"Main\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/Main.xaml",
      "workflow": "Main",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "referencedSymbol": "transactionNumber",
      "offendingExpression": "[&quot;[Main][Process] Transaction #&quot; &amp; transactionNumber.ToString() &amp; &quot; complete. CoupaInvoiceId=&quot; &amp; coupaInvoiceId &amp; &quot; FinalStatus=&quot; &amp; transactionStatus ",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"transactionNumber\" referenced in Message but not declared in workflow \"Main\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/Main.xaml",
      "workflow": "Main",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "referencedSymbol": "coupaInvoiceId",
      "offendingExpression": "[&quot;[Main][Process] Transaction #&quot; &amp; transactionNumber.ToString() &amp; &quot; complete. CoupaInvoiceId=&quot; &amp; coupaInvoiceId &amp; &quot; FinalStatus=&quot; &amp; transactionStatus ",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"coupaInvoiceId\" referenced in Message but not declared in workflow \"Main\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/Main.xaml",
      "workflow": "Main",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "referencedSymbol": "transactionStatus",
      "offendingExpression": "[&quot;[Main][Process] Transaction #&quot; &amp; transactionNumber.ToString() &amp; &quot; complete. CoupaInvoiceId=&quot; &amp; coupaInvoiceId &amp; &quot; FinalStatus=&quot; &amp; transactionStatus ",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"transactionStatus\" referenced in Message but not declared in workflow \"Main\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/Main.xaml",
      "workflow": "Main",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "referencedSymbol": "totalProcessed",
      "offendingExpression": "[&quot;[Main][Process] Transaction #&quot; &amp; transactionNumber.ToString() &amp; &quot; complete. CoupaInvoiceId=&quot; &amp; coupaInvoiceId &amp; &quot; FinalStatus=&quot; &amp; transactionStatus ",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"totalProcessed\" referenced in Message but not declared in workflow \"Main\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/Main.xaml",
      "workflow": "Main",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "referencedSymbol": "totalSucceeded",
      "offendingExpression": "[&quot;[Main][Process] Transaction #&quot; &amp; transactionNumber.ToString() &amp; &quot; complete. CoupaInvoiceId=&quot; &amp; coupaInvoiceId &amp; &quot; FinalStatus=&quot; &amp; transactionStatus ",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"totalSucceeded\" referenced in Message but not declared in workflow \"Main\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/Main.xaml",
      "workflow": "Main",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "referencedSymbol": "totalFailed",
      "offendingExpression": "[&quot;[Main][Process] Transaction #&quot; &amp; transactionNumber.ToString() &amp; &quot; complete. CoupaInvoiceId=&quot; &amp; coupaInvoiceId &amp; &quot; FinalStatus=&quot; &amp; transactionStatus ",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"totalFailed\" referenced in Message but not declared in workflow \"Main\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/Main.xaml",
      "workflow": "Main",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "referencedSymbol": "runId",
      "offendingExpression": "[&quot;[Main][End] CoupaInvoiceRecon Performer completed. RunId=&quot; &amp; runId &amp; &quot; TotalProcessed=&quot; &amp; totalProcessed.ToString() &amp; &quot; Succeeded=&quot; &amp; totalSucceeded",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"runId\" referenced in Message but not declared in workflow \"Main\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/Main.xaml",
      "workflow": "Main",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "referencedSymbol": "totalProcessed",
      "offendingExpression": "[&quot;[Main][End] CoupaInvoiceRecon Performer completed. RunId=&quot; &amp; runId &amp; &quot; TotalProcessed=&quot; &amp; totalProcessed.ToString() &amp; &quot; Succeeded=&quot; &amp; totalSucceeded",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"totalProcessed\" referenced in Message but not declared in workflow \"Main\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/Main.xaml",
      "workflow": "Main",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "referencedSymbol": "totalSucceeded",
      "offendingExpression": "[&quot;[Main][End] CoupaInvoiceRecon Performer completed. RunId=&quot; &amp; runId &amp; &quot; TotalProcessed=&quot; &amp; totalProcessed.ToString() &amp; &quot; Succeeded=&quot; &amp; totalSucceeded",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"totalSucceeded\" referenced in Message but not declared in workflow \"Main\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/Main.xaml",
      "workflow": "Main",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "referencedSymbol": "totalFailed",
      "offendingExpression": "[&quot;[Main][End] CoupaInvoiceRecon Performer completed. RunId=&quot; &amp; runId &amp; &quot; TotalProcessed=&quot; &amp; totalProcessed.ToString() &amp; &quot; Succeeded=&quot; &amp; totalSucceeded",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"totalFailed\" referenced in Message but not declared in workflow \"Main\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/Main.xaml",
      "workflow": "Main",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "referencedSymbol": "processEndTime",
      "offendingExpression": "[&quot;[Main][End] CoupaInvoiceRecon Performer completed. RunId=&quot; &amp; runId &amp; &quot; TotalProcessed=&quot; &amp; totalProcessed.ToString() &amp; &quot; Succeeded=&quot; &amp; totalSucceeded",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"processEndTime\" referenced in Message but not declared in workflow \"Main\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/Main.xaml",
      "workflow": "Main",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "referencedSymbol": "processStartTime",
      "offendingExpression": "[&quot;[Main][End] CoupaInvoiceRecon Performer completed. RunId=&quot; &amp; runId &amp; &quot; TotalProcessed=&quot; &amp; totalProcessed.ToString() &amp; &quot; Succeeded=&quot; &amp; totalSucceeded",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"processStartTime\" referenced in Message but not declared in workflow \"Main\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/Main.xaml",
      "workflow": "Main",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "referencedSymbol": "shouldStopProcessing",
      "offendingExpression": "[&quot;[Main][End] CoupaInvoiceRecon Performer completed. RunId=&quot; &amp; runId &amp; &quot; TotalProcessed=&quot; &amp; totalProcessed.ToString() &amp; &quot; Succeeded=&quot; &amp; totalSucceeded",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"shouldStopProcessing\" referenced in Message but not declared in workflow \"Main\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/Main.xaml",
      "workflow": "Main",
      "activityType": "Assign",
      "propertyName": "Value",
      "referencedSymbol": "totalSucceeded",
      "offendingExpression": "[totalSucceeded + 1]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"totalSucceeded\" referenced in child element <Assign.Value> but not declared in workflow \"Main\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/Main.xaml",
      "workflow": "Main",
      "activityType": "Assign",
      "propertyName": "Value",
      "referencedSymbol": "totalProcessed",
      "offendingExpression": "[totalProcessed + 1]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"totalProcessed\" referenced in child element <Assign.Value> but not declared in workflow \"Main\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/Dispatcher.xaml",
      "workflow": "Dispatcher",
      "activityType": "ui:GetAsset",
      "propertyName": "Value",
      "referencedSymbol": "str_CoupaBaseUrl",
      "offendingExpression": "[str_CoupaBaseUrl]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"str_CoupaBaseUrl\" referenced in Value but not declared in workflow \"Dispatcher\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/Dispatcher.xaml",
      "workflow": "Dispatcher",
      "activityType": "ui:GetAsset",
      "propertyName": "Value",
      "referencedSymbol": "bool_PollingEnabled",
      "offendingExpression": "[bool_PollingEnabled]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"bool_PollingEnabled\" referenced in Value but not declared in workflow \"Dispatcher\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/Dispatcher.xaml",
      "workflow": "Dispatcher",
      "activityType": "ui:GetAsset",
      "propertyName": "Value",
      "referencedSymbol": "int_LookbackMinutes",
      "offendingExpression": "[int_LookbackMinutes]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"int_LookbackMinutes\" referenced in Value but not declared in workflow \"Dispatcher\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/Dispatcher.xaml",
      "workflow": "Dispatcher",
      "activityType": "ui:GetAsset",
      "propertyName": "Value",
      "referencedSymbol": "str_OrchestratorFolder",
      "offendingExpression": "[str_OrchestratorFolder]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"str_OrchestratorFolder\" referenced in Value but not declared in workflow \"Dispatcher\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/Dispatcher.xaml",
      "workflow": "Dispatcher",
      "activityType": "ui:GetAsset",
      "propertyName": "Value",
      "referencedSymbol": "str_LastRunUtc",
      "offendingExpression": "[str_LastRunUtc]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"str_LastRunUtc\" referenced in Value but not declared in workflow \"Dispatcher\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/Dispatcher.xaml",
      "workflow": "Dispatcher",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "referencedSymbol": "str_CoupaBaseUrl",
      "offendingExpression": "[&quot;[Dispatcher] Config loaded. BaseUrl=&quot; &amp; str_CoupaBaseUrl &amp; &quot; | LastRunUtc=&quot; &amp; str_LastRunUtc &amp; &quot; | LookbackMinutes=&quot; &amp; int_LookbackMinutes.ToString(",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"str_CoupaBaseUrl\" referenced in Message but not declared in workflow \"Dispatcher\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/Dispatcher.xaml",
      "workflow": "Dispatcher",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "referencedSymbol": "str_LastRunUtc",
      "offendingExpression": "[&quot;[Dispatcher] Config loaded. BaseUrl=&quot; &amp; str_CoupaBaseUrl &amp; &quot; | LastRunUtc=&quot; &amp; str_LastRunUtc &amp; &quot; | LookbackMinutes=&quot; &amp; int_LookbackMinutes.ToString(",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"str_LastRunUtc\" referenced in Message but not declared in workflow \"Dispatcher\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/Dispatcher.xaml",
      "workflow": "Dispatcher",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "referencedSymbol": "int_LookbackMinutes",
      "offendingExpression": "[&quot;[Dispatcher] Config loaded. BaseUrl=&quot; &amp; str_CoupaBaseUrl &amp; &quot; | LastRunUtc=&quot; &amp; str_LastRunUtc &amp; &quot; | LookbackMinutes=&quot; &amp; int_LookbackMinutes.ToString(",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"int_LookbackMinutes\" referenced in Message but not declared in workflow \"Dispatcher\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/Dispatcher.xaml",
      "workflow": "Dispatcher",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "referencedSymbol": "bool_PollingEnabled",
      "offendingExpression": "[&quot;[Dispatcher] Config loaded. BaseUrl=&quot; &amp; str_CoupaBaseUrl &amp; &quot; | LastRunUtc=&quot; &amp; str_LastRunUtc &amp; &quot; | LookbackMinutes=&quot; &amp; int_LookbackMinutes.ToString(",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"bool_PollingEnabled\" referenced in Message but not declared in workflow \"Dispatcher\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/Dispatcher.xaml",
      "workflow": "Dispatcher",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "referencedSymbol": "str_CurrentInvoiceId",
      "offendingExpression": "[&quot;[Dispatcher] Processing invoice. CoupaInvoiceId=&quot; &amp; str_CurrentInvoiceId &amp; &quot; | VendorName=&quot; &amp; str_CurrentVendorName &amp; &quot; | SubmittedUtc=&quot; &amp; str_Curre",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"str_CurrentInvoiceId\" referenced in Message but not declared in workflow \"Dispatcher\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/Dispatcher.xaml",
      "workflow": "Dispatcher",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "referencedSymbol": "str_CurrentVendorName",
      "offendingExpression": "[&quot;[Dispatcher] Processing invoice. CoupaInvoiceId=&quot; &amp; str_CurrentInvoiceId &amp; &quot; | VendorName=&quot; &amp; str_CurrentVendorName &amp; &quot; | SubmittedUtc=&quot; &amp; str_Curre",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"str_CurrentVendorName\" referenced in Message but not declared in workflow \"Dispatcher\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/Dispatcher.xaml",
      "workflow": "Dispatcher",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "referencedSymbol": "str_CurrentSubmittedUtc",
      "offendingExpression": "[&quot;[Dispatcher] Processing invoice. CoupaInvoiceId=&quot; &amp; str_CurrentInvoiceId &amp; &quot; | VendorName=&quot; &amp; str_CurrentVendorName &amp; &quot; | SubmittedUtc=&quot; &amp; str_Curre",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"str_CurrentSubmittedUtc\" referenced in Message but not declared in workflow \"Dispatcher\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/Dispatcher.xaml",
      "workflow": "Dispatcher",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "referencedSymbol": "str_CurrentPdfUrl",
      "offendingExpression": "[&quot;[Dispatcher] Processing invoice. CoupaInvoiceId=&quot; &amp; str_CurrentInvoiceId &amp; &quot; | VendorName=&quot; &amp; str_CurrentVendorName &amp; &quot; | SubmittedUtc=&quot; &amp; str_Curre",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"str_CurrentPdfUrl\" referenced in Message but not declared in workflow \"Dispatcher\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/Dispatcher.xaml",
      "workflow": "Dispatcher",
      "activityType": "uds:QueryEntity",
      "propertyName": "Result",
      "referencedSymbol": "obj_ExistingCaseQuery",
      "offendingExpression": "[obj_ExistingCaseQuery]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "execution_blocking",
      "rationale": "Variable \"obj_ExistingCaseQuery\" referenced in Result but not declared in workflow \"Dispatcher\" — expression replaced with \"Nothing\""
    },
    {
      "file": "lib/net45/Dispatcher.xaml",
      "workflow": "Dispatcher",
      "activityType": "uds:CreateEntityRecord",
      "propertyName": "Result",
      "referencedSymbol": "obj_NewInvoiceCase",
      "offendingExpression": "[obj_NewInvoiceCase]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "execution_blocking",
      "rationale": "Variable \"obj_NewInvoiceCase\" referenced in Result but not declared in workflow \"Dispatcher\" — expression replaced with \"Nothing\""
    },
    {
      "file": "lib/net45/Dispatcher.xaml",
      "workflow": "Dispatcher",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "referencedSymbol": "str_CurrentInvoiceId",
      "offendingExpression": "[&quot;[Dispatcher] InvoiceCase record created in Data Service. CoupaInvoiceId=&quot; &amp; str_CurrentInvoiceId &amp; &quot; | Status=Queued | QueuedUtc=&quot; &amp; DateTime.UtcNow.ToString(&quot;yy",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"str_CurrentInvoiceId\" referenced in Message but not declared in workflow \"Dispatcher\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/Dispatcher.xaml",
      "workflow": "Dispatcher",
      "activityType": "Assign",
      "propertyName": "Value",
      "referencedSymbol": "int_EnqueuedCount",
      "offendingExpression": "[int_EnqueuedCount + 1]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"int_EnqueuedCount\" referenced in child element <Assign.Value> but not declared in workflow \"Dispatcher\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/InitialiseConfig.xaml",
      "workflow": "InitialiseConfig",
      "activityType": "ui:GetAsset",
      "propertyName": "Value",
      "referencedSymbol": "str_CoupaBaseUrl",
      "offendingExpression": "[str_CoupaBaseUrl]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"str_CoupaBaseUrl\" referenced in Value but not declared in workflow \"InitialiseConfig\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/InitialiseConfig.xaml",
      "workflow": "InitialiseConfig",
      "activityType": "ui:GetAsset",
      "propertyName": "Value",
      "referencedSymbol": "str_CoupaPollingEnabled",
      "offendingExpression": "[str_CoupaPollingEnabled]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"str_CoupaPollingEnabled\" referenced in Value but not declared in workflow \"InitialiseConfig\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/InitialiseConfig.xaml",
      "workflow": "InitialiseConfig",
      "activityType": "ui:GetAsset",
      "propertyName": "Value",
      "referencedSymbol": "str_CoupaPollingLookbackMinutes",
      "offendingExpression": "[str_CoupaPollingLookbackMinutes]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"str_CoupaPollingLookbackMinutes\" referenced in Value but not declared in workflow \"InitialiseConfig\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/InitialiseConfig.xaml",
      "workflow": "InitialiseConfig",
      "activityType": "ui:GetAsset",
      "propertyName": "Value",
      "referencedSymbol": "str_TolerancePercent",
      "offendingExpression": "[str_TolerancePercent]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"str_TolerancePercent\" referenced in Value but not declared in workflow \"InitialiseConfig\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/InitialiseConfig.xaml",
      "workflow": "InitialiseConfig",
      "activityType": "ui:GetAsset",
      "propertyName": "Value",
      "referencedSymbol": "str_ToleranceBasis",
      "offendingExpression": "[str_ToleranceBasis]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"str_ToleranceBasis\" referenced in Value but not declared in workflow \"InitialiseConfig\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/InitialiseConfig.xaml",
      "workflow": "InitialiseConfig",
      "activityType": "ui:GetAsset",
      "propertyName": "Value",
      "referencedSymbol": "str_DuConfidenceThreshold",
      "offendingExpression": "[str_DuConfidenceThreshold]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"str_DuConfidenceThreshold\" referenced in Value but not declared in workflow \"InitialiseConfig\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/InitialiseConfig.xaml",
      "workflow": "InitialiseConfig",
      "activityType": "ui:GetAsset",
      "propertyName": "Value",
      "referencedSymbol": "str_ActionCenterSlaHours",
      "offendingExpression": "[str_ActionCenterSlaHours]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"str_ActionCenterSlaHours\" referenced in Value but not declared in workflow \"InitialiseConfig\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/InitialiseConfig.xaml",
      "workflow": "InitialiseConfig",
      "activityType": "ui:GetAsset",
      "propertyName": "Value",
      "referencedSymbol": "str_StorageRetentionDays",
      "offendingExpression": "[str_StorageRetentionDays]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"str_StorageRetentionDays\" referenced in Value but not declared in workflow \"InitialiseConfig\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/InitialiseConfig.xaml",
      "workflow": "InitialiseConfig",
      "activityType": "ui:GetAsset",
      "propertyName": "Value",
      "referencedSymbol": "str_OrchestratorFolderName",
      "offendingExpression": "[str_OrchestratorFolderName]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"str_OrchestratorFolderName\" referenced in Value but not declared in workflow \"InitialiseConfig\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/InitialiseConfig.xaml",
      "workflow": "InitialiseConfig",
      "activityType": "Throw",
      "propertyName": "Exception",
      "referencedSymbol": "str_ValidationErrors",
      "offendingExpression": "[New BusinessRuleException(&quot;[InitialiseConfig] Configuration validation failed. Errors: &quot; &amp; str_ValidationErrors)]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"str_ValidationErrors\" referenced in Exception but not declared in workflow \"InitialiseConfig\" — expression replaced with \"Nothing\""
    },
    {
      "file": "lib/net45/InitialiseConfig.xaml",
      "workflow": "InitialiseConfig",
      "activityType": "Assign",
      "propertyName": "Value",
      "referencedSymbol": "str_TolerancePercent",
      "offendingExpression": "[If(Integer.TryParse(str_TolerancePercent, int_TolerancePercent), int_TolerancePercent, -1)]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"str_TolerancePercent\" referenced in child element <Assign.Value> but not declared in workflow \"InitialiseConfig\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/InitialiseConfig.xaml",
      "workflow": "InitialiseConfig",
      "activityType": "Assign",
      "propertyName": "Value",
      "referencedSymbol": "int_TolerancePercent",
      "offendingExpression": "[If(Integer.TryParse(str_TolerancePercent, int_TolerancePercent), int_TolerancePercent, -1)]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"int_TolerancePercent\" referenced in child element <Assign.Value> but not declared in workflow \"InitialiseConfig\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/InitialiseConfig.xaml",
      "workflow": "InitialiseConfig",
      "activityType": "Assign",
      "propertyName": "Value",
      "referencedSymbol": "str_DuConfidenceThreshold",
      "offendingExpression": "[If(Integer.TryParse(str_DuConfidenceThreshold, int_DuConfidenceThreshold), int_DuConfidenceThreshold, -1)]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"str_DuConfidenceThreshold\" referenced in child element <Assign.Value> but not declared in workflow \"InitialiseConfig\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/InitialiseConfig.xaml",
      "workflow": "InitialiseConfig",
      "activityType": "Assign",
      "propertyName": "Value",
      "referencedSymbol": "int_DuConfidenceThreshold",
      "offendingExpression": "[If(Integer.TryParse(str_DuConfidenceThreshold, int_DuConfidenceThreshold), int_DuConfidenceThreshold, -1)]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"int_DuConfidenceThreshold\" referenced in child element <Assign.Value> but not declared in workflow \"InitialiseConfig\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/InitialiseConfig.xaml",
      "workflow": "InitialiseConfig",
      "activityType": "Assign",
      "propertyName": "Value",
      "referencedSymbol": "str_ActionCenterSlaHours",
      "offendingExpression": "[If(Integer.TryParse(str_ActionCenterSlaHours, int_ActionCenterSlaHours), int_ActionCenterSlaHours, -1)]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"str_ActionCenterSlaHours\" referenced in child element <Assign.Value> but not declared in workflow \"InitialiseConfig\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/InitialiseConfig.xaml",
      "workflow": "InitialiseConfig",
      "activityType": "Assign",
      "propertyName": "Value",
      "referencedSymbol": "int_ActionCenterSlaHours",
      "offendingExpression": "[If(Integer.TryParse(str_ActionCenterSlaHours, int_ActionCenterSlaHours), int_ActionCenterSlaHours, -1)]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"int_ActionCenterSlaHours\" referenced in child element <Assign.Value> but not declared in workflow \"InitialiseConfig\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/InitialiseConfig.xaml",
      "workflow": "InitialiseConfig",
      "activityType": "Assign",
      "propertyName": "Value",
      "referencedSymbol": "str_StorageRetentionDays",
      "offendingExpression": "[If(Integer.TryParse(str_StorageRetentionDays, int_StorageRetentionDays), int_StorageRetentionDays, -1)]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"str_StorageRetentionDays\" referenced in child element <Assign.Value> but not declared in workflow \"InitialiseConfig\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/InitialiseConfig.xaml",
      "workflow": "InitialiseConfig",
      "activityType": "Assign",
      "propertyName": "Value",
      "referencedSymbol": "int_StorageRetentionDays",
      "offendingExpression": "[If(Integer.TryParse(str_StorageRetentionDays, int_StorageRetentionDays), int_StorageRetentionDays, -1)]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"int_StorageRetentionDays\" referenced in child element <Assign.Value> but not declared in workflow \"InitialiseConfig\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/InitialiseConfig.xaml",
      "workflow": "InitialiseConfig",
      "activityType": "Assign",
      "propertyName": "Value",
      "referencedSymbol": "str_CoupaPollingLookbackMinutes",
      "offendingExpression": "[If(Integer.TryParse(str_CoupaPollingLookbackMinutes, int_PollingLookbackMinutes), int_PollingLookbackMinutes, -1)]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"str_CoupaPollingLookbackMinutes\" referenced in child element <Assign.Value> but not declared in workflow \"InitialiseConfig\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/InitialiseConfig.xaml",
      "workflow": "InitialiseConfig",
      "activityType": "Assign",
      "propertyName": "Value",
      "referencedSymbol": "int_PollingLookbackMinutes",
      "offendingExpression": "[If(Integer.TryParse(str_CoupaPollingLookbackMinutes, int_PollingLookbackMinutes), int_PollingLookbackMinutes, -1)]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"int_PollingLookbackMinutes\" referenced in child element <Assign.Value> but not declared in workflow \"InitialiseConfig\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/InitialiseConfig.xaml",
      "workflow": "InitialiseConfig",
      "activityType": "Assign",
      "propertyName": "Value",
      "referencedSymbol": "str_CoupaPollingEnabled",
      "offendingExpression": "[If(Boolean.TryParse(str_CoupaPollingEnabled, bool_PollingEnabled), bool_PollingEnabled, True)]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"str_CoupaPollingEnabled\" referenced in child element <Assign.Value> but not declared in workflow \"InitialiseConfig\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/InitialiseConfig.xaml",
      "workflow": "InitialiseConfig",
      "activityType": "Assign",
      "propertyName": "Value",
      "referencedSymbol": "bool_PollingEnabled",
      "offendingExpression": "[If(Boolean.TryParse(str_CoupaPollingEnabled, bool_PollingEnabled), bool_PollingEnabled, True)]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"bool_PollingEnabled\" referenced in child element <Assign.Value> but not declared in workflow \"InitialiseConfig\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/InitialiseConfig.xaml",
      "workflow": "InitialiseConfig",
      "activityType": "Assign",
      "propertyName": "Value",
      "referencedSymbol": "value",
      "offendingExpression": "[value]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"value\" referenced in child element <Assign.Value> but not declared in workflow \"InitialiseConfig\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/ProcessTransaction.xaml",
      "workflow": "ProcessTransaction",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "referencedSymbol": "CoupaInvoiceId",
      "offendingExpression": "[&quot;[ProcessTransaction] START CoupaInvoiceId=&quot; &amp; CoupaInvoiceId &amp; &quot; VendorName=&quot; &amp; VendorName &amp; &quot; IsResumedFromValidation=&quot; &amp; IsResumedFromValidation.T",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"CoupaInvoiceId\" referenced in Message but not declared in workflow \"ProcessTransaction\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/ProcessTransaction.xaml",
      "workflow": "ProcessTransaction",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "referencedSymbol": "VendorName",
      "offendingExpression": "[&quot;[ProcessTransaction] START CoupaInvoiceId=&quot; &amp; CoupaInvoiceId &amp; &quot; VendorName=&quot; &amp; VendorName &amp; &quot; IsResumedFromValidation=&quot; &amp; IsResumedFromValidation.T",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"VendorName\" referenced in Message but not declared in workflow \"ProcessTransaction\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/ProcessTransaction.xaml",
      "workflow": "ProcessTransaction",
      "activityType": "uds:QueryEntity",
      "propertyName": "Result",
      "referencedSymbol": "queryResults",
      "offendingExpression": "[queryResults]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "execution_blocking",
      "rationale": "Variable \"queryResults\" referenced in Result but not declared in workflow \"ProcessTransaction\" — expression replaced with \"Nothing\""
    },
    {
      "file": "lib/net45/ProcessTransaction.xaml",
      "workflow": "ProcessTransaction",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "referencedSymbol": "CoupaInvoiceId",
      "offendingExpression": "[&quot;[ProcessTransaction] InvoiceCase query complete for CoupaInvoiceId=&quot; &amp; CoupaInvoiceId &amp; &quot;. QueryResult is Nothing=&quot; &amp; (queryResults Is Nothing).ToString()]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"CoupaInvoiceId\" referenced in Message but not declared in workflow \"ProcessTransaction\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/ProcessTransaction.xaml",
      "workflow": "ProcessTransaction",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "referencedSymbol": "queryResults",
      "offendingExpression": "[&quot;[ProcessTransaction] InvoiceCase query complete for CoupaInvoiceId=&quot; &amp; CoupaInvoiceId &amp; &quot;. QueryResult is Nothing=&quot; &amp; (queryResults Is Nothing).ToString()]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"queryResults\" referenced in Message but not declared in workflow \"ProcessTransaction\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/ProcessTransaction.xaml",
      "workflow": "ProcessTransaction",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "referencedSymbol": "CoupaInvoiceId",
      "offendingExpression": "[&quot;[ProcessTransaction] InvoiceCase status set to InProgress. CoupaInvoiceId=&quot; &amp; CoupaInvoiceId &amp; &quot; PickedUpUtc=&quot; &amp; pickedUpUtc.ToString(&quot;o&quot;)]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"CoupaInvoiceId\" referenced in Message but not declared in workflow \"ProcessTransaction\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/ProcessTransaction.xaml",
      "workflow": "ProcessTransaction",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "referencedSymbol": "pickedUpUtc",
      "offendingExpression": "[&quot;[ProcessTransaction] InvoiceCase status set to InProgress. CoupaInvoiceId=&quot; &amp; CoupaInvoiceId &amp; &quot; PickedUpUtc=&quot; &amp; pickedUpUtc.ToString(&quot;o&quot;)]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"pickedUpUtc\" referenced in Message but not declared in workflow \"ProcessTransaction\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/ProcessTransaction.xaml",
      "workflow": "ProcessTransaction",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "referencedSymbol": "CoupaInvoiceId",
      "offendingExpression": "[&quot;[ProcessTransaction] PDF retrieved. CoupaInvoiceId=&quot; &amp; CoupaInvoiceId &amp; &quot; LocalPdfPath=&quot; &amp; localPdfPath &amp; &quot; BucketPath=&quot; &amp; pdfBucketPath]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"CoupaInvoiceId\" referenced in Message but not declared in workflow \"ProcessTransaction\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/ProcessTransaction.xaml",
      "workflow": "ProcessTransaction",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "referencedSymbol": "localPdfPath",
      "offendingExpression": "[&quot;[ProcessTransaction] PDF retrieved. CoupaInvoiceId=&quot; &amp; CoupaInvoiceId &amp; &quot; LocalPdfPath=&quot; &amp; localPdfPath &amp; &quot; BucketPath=&quot; &amp; pdfBucketPath]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"localPdfPath\" referenced in Message but not declared in workflow \"ProcessTransaction\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/ProcessTransaction.xaml",
      "workflow": "ProcessTransaction",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "referencedSymbol": "pdfBucketPath",
      "offendingExpression": "[&quot;[ProcessTransaction] PDF retrieved. CoupaInvoiceId=&quot; &amp; CoupaInvoiceId &amp; &quot; LocalPdfPath=&quot; &amp; localPdfPath &amp; &quot; BucketPath=&quot; &amp; pdfBucketPath]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"pdfBucketPath\" referenced in Message but not declared in workflow \"ProcessTransaction\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/ProcessTransaction.xaml",
      "workflow": "ProcessTransaction",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "referencedSymbol": "CoupaInvoiceId",
      "offendingExpression": "[&quot;[ProcessTransaction] Extraction complete. CoupaInvoiceId=&quot; &amp; CoupaInvoiceId &amp; &quot; PONumber=&quot; &amp; extractedPONumber &amp; &quot; InvoiceNumber=&quot; &amp; extractedInvoic",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"CoupaInvoiceId\" referenced in Message but not declared in workflow \"ProcessTransaction\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/ProcessTransaction.xaml",
      "workflow": "ProcessTransaction",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "referencedSymbol": "extractedPONumber",
      "offendingExpression": "[&quot;[ProcessTransaction] Extraction complete. CoupaInvoiceId=&quot; &amp; CoupaInvoiceId &amp; &quot; PONumber=&quot; &amp; extractedPONumber &amp; &quot; InvoiceNumber=&quot; &amp; extractedInvoic",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"extractedPONumber\" referenced in Message but not declared in workflow \"ProcessTransaction\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/ProcessTransaction.xaml",
      "workflow": "ProcessTransaction",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "referencedSymbol": "extractedInvoiceNumber",
      "offendingExpression": "[&quot;[ProcessTransaction] Extraction complete. CoupaInvoiceId=&quot; &amp; CoupaInvoiceId &amp; &quot; PONumber=&quot; &amp; extractedPONumber &amp; &quot; InvoiceNumber=&quot; &amp; extractedInvoic",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"extractedInvoiceNumber\" referenced in Message but not declared in workflow \"ProcessTransaction\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/ProcessTransaction.xaml",
      "workflow": "ProcessTransaction",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "referencedSymbol": "extractedInvoiceTotal",
      "offendingExpression": "[&quot;[ProcessTransaction] Extraction complete. CoupaInvoiceId=&quot; &amp; CoupaInvoiceId &amp; &quot; PONumber=&quot; &amp; extractedPONumber &amp; &quot; InvoiceNumber=&quot; &amp; extractedInvoic",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"extractedInvoiceTotal\" referenced in Message but not declared in workflow \"ProcessTransaction\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/ProcessTransaction.xaml",
      "workflow": "ProcessTransaction",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "referencedSymbol": "overallExtractionConfidence",
      "offendingExpression": "[&quot;[ProcessTransaction] Extraction complete. CoupaInvoiceId=&quot; &amp; CoupaInvoiceId &amp; &quot; PONumber=&quot; &amp; extractedPONumber &amp; &quot; InvoiceNumber=&quot; &amp; extractedInvoic",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"overallExtractionConfidence\" referenced in Message but not declared in workflow \"ProcessTransaction\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/ProcessTransaction.xaml",
      "workflow": "ProcessTransaction",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "referencedSymbol": "needsHumanValidation",
      "offendingExpression": "[&quot;[ProcessTransaction] Extraction complete. CoupaInvoiceId=&quot; &amp; CoupaInvoiceId &amp; &quot; PONumber=&quot; &amp; extractedPONumber &amp; &quot; InvoiceNumber=&quot; &amp; extractedInvoic",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"needsHumanValidation\" referenced in Message but not declared in workflow \"ProcessTransaction\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/ProcessTransaction.xaml",
      "workflow": "ProcessTransaction",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "referencedSymbol": "CoupaInvoiceId",
      "offendingExpression": "[&quot;[ProcessTransaction] ValidateAndDecide complete. CoupaInvoiceId=&quot; &amp; CoupaInvoiceId &amp; &quot; FinalCaseStatus=&quot; &amp; finalCaseStatus &amp; &quot; RejectionReasonCode=&quot; &am",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"CoupaInvoiceId\" referenced in Message but not declared in workflow \"ProcessTransaction\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/ProcessTransaction.xaml",
      "workflow": "ProcessTransaction",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "referencedSymbol": "finalCaseStatus",
      "offendingExpression": "[&quot;[ProcessTransaction] ValidateAndDecide complete. CoupaInvoiceId=&quot; &amp; CoupaInvoiceId &amp; &quot; FinalCaseStatus=&quot; &amp; finalCaseStatus &amp; &quot; RejectionReasonCode=&quot; &am",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"finalCaseStatus\" referenced in Message but not declared in workflow \"ProcessTransaction\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/ProcessTransaction.xaml",
      "workflow": "ProcessTransaction",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "referencedSymbol": "rejectionReasonCode",
      "offendingExpression": "[&quot;[ProcessTransaction] ValidateAndDecide complete. CoupaInvoiceId=&quot; &amp; CoupaInvoiceId &amp; &quot; FinalCaseStatus=&quot; &amp; finalCaseStatus &amp; &quot; RejectionReasonCode=&quot; &am",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"rejectionReasonCode\" referenced in Message but not declared in workflow \"ProcessTransaction\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/ProcessTransaction.xaml",
      "workflow": "ProcessTransaction",
      "activityType": "Assign",
      "propertyName": "Value",
      "referencedSymbol": "PendingValidation",
      "offendingExpression": "[PendingValidation]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"PendingValidation\" referenced in child element <Assign.Value> but not declared in workflow \"ProcessTransaction\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/ProcessTransaction.xaml",
      "workflow": "ProcessTransaction",
      "activityType": "Assign",
      "propertyName": "Value",
      "referencedSymbol": "PendingValidation",
      "offendingExpression": "[PendingValidation]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"PendingValidation\" referenced in child element <Assign.Value> but not declared in workflow \"ProcessTransaction\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/RetrieveInvoicePdf.xaml",
      "workflow": "RetrieveInvoicePdf",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "referencedSymbol": "CoupaInvoiceId",
      "offendingExpression": "[&quot;[RetrieveInvoicePdf] START — CoupaInvoiceId=&quot; &amp; CoupaInvoiceId &amp; &quot; | InvoicePdfUrl=&quot; &amp; InvoicePdfUrl]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"CoupaInvoiceId\" referenced in Message but not declared in workflow \"RetrieveInvoicePdf\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/RetrieveInvoicePdf.xaml",
      "workflow": "RetrieveInvoicePdf",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "referencedSymbol": "InvoicePdfUrl",
      "offendingExpression": "[&quot;[RetrieveInvoicePdf] START — CoupaInvoiceId=&quot; &amp; CoupaInvoiceId &amp; &quot; | InvoicePdfUrl=&quot; &amp; InvoicePdfUrl]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"InvoicePdfUrl\" referenced in Message but not declared in workflow \"RetrieveInvoicePdf\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/RetrieveInvoicePdf.xaml",
      "workflow": "RetrieveInvoicePdf",
      "activityType": "ui:GetAsset",
      "propertyName": "Value",
      "referencedSymbol": "coupaBaseUrl",
      "offendingExpression": "[coupaBaseUrl]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"coupaBaseUrl\" referenced in Value but not declared in workflow \"RetrieveInvoicePdf\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/RetrieveInvoicePdf.xaml",
      "workflow": "RetrieveInvoicePdf",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "referencedSymbol": "CoupaInvoiceId",
      "offendingExpression": "[&quot;[RetrieveInvoicePdf] Initiating PDF download — CoupaInvoiceId=&quot; &amp; CoupaInvoiceId &amp; &quot; | CandidatePath=&quot; &amp; candidateLocalPath &amp; &quot; | BucketPath=&quot; &amp; buc",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"CoupaInvoiceId\" referenced in Message but not declared in workflow \"RetrieveInvoicePdf\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/RetrieveInvoicePdf.xaml",
      "workflow": "RetrieveInvoicePdf",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "referencedSymbol": "candidateLocalPath",
      "offendingExpression": "[&quot;[RetrieveInvoicePdf] Initiating PDF download — CoupaInvoiceId=&quot; &amp; CoupaInvoiceId &amp; &quot; | CandidatePath=&quot; &amp; candidateLocalPath &amp; &quot; | BucketPath=&quot; &amp; buc",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"candidateLocalPath\" referenced in Message but not declared in workflow \"RetrieveInvoicePdf\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/RetrieveInvoicePdf.xaml",
      "workflow": "RetrieveInvoicePdf",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "referencedSymbol": "bucketPathResolved",
      "offendingExpression": "[&quot;[RetrieveInvoicePdf] Initiating PDF download — CoupaInvoiceId=&quot; &amp; CoupaInvoiceId &amp; &quot; | CandidatePath=&quot; &amp; candidateLocalPath &amp; &quot; | BucketPath=&quot; &amp; buc",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"bucketPathResolved\" referenced in Message but not declared in workflow \"RetrieveInvoicePdf\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/RetrieveInvoicePdf.xaml",
      "workflow": "RetrieveInvoicePdf",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "referencedSymbol": "downloadAttempt",
      "offendingExpression": "[&quot;[RetrieveInvoicePdf] Download attempt &quot; &amp; downloadAttempt.ToString() &amp; &quot; — CoupaInvoiceId=&quot; &amp; CoupaInvoiceId &amp; &quot; | Url=&quot; &amp; InvoicePdfUrl]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"downloadAttempt\" referenced in Message but not declared in workflow \"RetrieveInvoicePdf\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/RetrieveInvoicePdf.xaml",
      "workflow": "RetrieveInvoicePdf",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "referencedSymbol": "CoupaInvoiceId",
      "offendingExpression": "[&quot;[RetrieveInvoicePdf] Download attempt &quot; &amp; downloadAttempt.ToString() &amp; &quot; — CoupaInvoiceId=&quot; &amp; CoupaInvoiceId &amp; &quot; | Url=&quot; &amp; InvoicePdfUrl]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"CoupaInvoiceId\" referenced in Message but not declared in workflow \"RetrieveInvoicePdf\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/RetrieveInvoicePdf.xaml",
      "workflow": "RetrieveInvoicePdf",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "referencedSymbol": "InvoicePdfUrl",
      "offendingExpression": "[&quot;[RetrieveInvoicePdf] Download attempt &quot; &amp; downloadAttempt.ToString() &amp; &quot; — CoupaInvoiceId=&quot; &amp; CoupaInvoiceId &amp; &quot; | Url=&quot; &amp; InvoicePdfUrl]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"InvoicePdfUrl\" referenced in Message but not declared in workflow \"RetrieveInvoicePdf\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/RetrieveInvoicePdf.xaml",
      "workflow": "RetrieveInvoicePdf",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "referencedSymbol": "fileLockDetected",
      "offendingExpression": "[&quot;[RetrieveInvoicePdf] FileLockDetected=&quot; &amp; fileLockDetected.ToString() &amp; &quot; | ResolvedLocalPath=&quot; &amp; resolvedLocalPath &amp; &quot; | CoupaInvoiceId=&quot; &amp; CoupaIn",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"fileLockDetected\" referenced in Message but not declared in workflow \"RetrieveInvoicePdf\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/RetrieveInvoicePdf.xaml",
      "workflow": "RetrieveInvoicePdf",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "referencedSymbol": "resolvedLocalPath",
      "offendingExpression": "[&quot;[RetrieveInvoicePdf] FileLockDetected=&quot; &amp; fileLockDetected.ToString() &amp; &quot; | ResolvedLocalPath=&quot; &amp; resolvedLocalPath &amp; &quot; | CoupaInvoiceId=&quot; &amp; CoupaIn",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"resolvedLocalPath\" referenced in Message but not declared in workflow \"RetrieveInvoicePdf\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/RetrieveInvoicePdf.xaml",
      "workflow": "RetrieveInvoicePdf",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "referencedSymbol": "CoupaInvoiceId",
      "offendingExpression": "[&quot;[RetrieveInvoicePdf] FileLockDetected=&quot; &amp; fileLockDetected.ToString() &amp; &quot; | ResolvedLocalPath=&quot; &amp; resolvedLocalPath &amp; &quot; | CoupaInvoiceId=&quot; &amp; CoupaIn",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"CoupaInvoiceId\" referenced in Message but not declared in workflow \"RetrieveInvoicePdf\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/RetrieveInvoicePdf.xaml",
      "workflow": "RetrieveInvoicePdf",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "referencedSymbol": "CoupaInvoiceId",
      "offendingExpression": "[&quot;[RetrieveInvoicePdf] SUCCESS — CoupaInvoiceId=&quot; &amp; CoupaInvoiceId &amp; &quot; | LocalPath=&quot; &amp; resolvedLocalPath &amp; &quot; | FileSizeBytes=&quot; &amp; fileSizeBytes.ToStrin",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"CoupaInvoiceId\" referenced in Message but not declared in workflow \"RetrieveInvoicePdf\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/RetrieveInvoicePdf.xaml",
      "workflow": "RetrieveInvoicePdf",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "referencedSymbol": "resolvedLocalPath",
      "offendingExpression": "[&quot;[RetrieveInvoicePdf] SUCCESS — CoupaInvoiceId=&quot; &amp; CoupaInvoiceId &amp; &quot; | LocalPath=&quot; &amp; resolvedLocalPath &amp; &quot; | FileSizeBytes=&quot; &amp; fileSizeBytes.ToStrin",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"resolvedLocalPath\" referenced in Message but not declared in workflow \"RetrieveInvoicePdf\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/RetrieveInvoicePdf.xaml",
      "workflow": "RetrieveInvoicePdf",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "referencedSymbol": "fileSizeBytes",
      "offendingExpression": "[&quot;[RetrieveInvoicePdf] SUCCESS — CoupaInvoiceId=&quot; &amp; CoupaInvoiceId &amp; &quot; | LocalPath=&quot; &amp; resolvedLocalPath &amp; &quot; | FileSizeBytes=&quot; &amp; fileSizeBytes.ToStrin",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"fileSizeBytes\" referenced in Message but not declared in workflow \"RetrieveInvoicePdf\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/RetrieveInvoicePdf.xaml",
      "workflow": "RetrieveInvoicePdf",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "referencedSymbol": "bucketPathResolved",
      "offendingExpression": "[&quot;[RetrieveInvoicePdf] SUCCESS — CoupaInvoiceId=&quot; &amp; CoupaInvoiceId &amp; &quot; | LocalPath=&quot; &amp; resolvedLocalPath &amp; &quot; | FileSizeBytes=&quot; &amp; fileSizeBytes.ToStrin",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"bucketPathResolved\" referenced in Message but not declared in workflow \"RetrieveInvoicePdf\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/RetrieveInvoicePdf.xaml",
      "workflow": "RetrieveInvoicePdf",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "referencedSymbol": "downloadAttempt",
      "offendingExpression": "[&quot;[RetrieveInvoicePdf] SUCCESS — CoupaInvoiceId=&quot; &amp; CoupaInvoiceId &amp; &quot; | LocalPath=&quot; &amp; resolvedLocalPath &amp; &quot; | FileSizeBytes=&quot; &amp; fileSizeBytes.ToStrin",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"downloadAttempt\" referenced in Message but not declared in workflow \"RetrieveInvoicePdf\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/RetrieveInvoicePdf.xaml",
      "workflow": "RetrieveInvoicePdf",
      "activityType": "Assign",
      "propertyName": "Value",
      "referencedSymbol": "downloadAttempt",
      "offendingExpression": "[downloadAttempt + 1]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"downloadAttempt\" referenced in child element <Assign.Value> but not declared in workflow \"RetrieveInvoicePdf\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/RetrieveInvoicePdf.xaml",
      "workflow": "RetrieveInvoicePdf",
      "activityType": "Assign",
      "propertyName": "Value",
      "referencedSymbol": "resolvedLocalPath",
      "offendingExpression": "[CInt(New System.IO.FileInfo(resolvedLocalPath).Length)]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"resolvedLocalPath\" referenced in child element <Assign.Value> but not declared in workflow \"RetrieveInvoicePdf\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/ExtractInvoiceFields.xaml",
      "workflow": "ExtractInvoiceFields",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "referencedSymbol": "CoupaInvoiceId",
      "offendingExpression": "[&quot;[ExtractInvoiceFields] START — CoupaInvoiceId=&quot; &amp; CoupaInvoiceId &amp; &quot; | LocalPdfPath=&quot; &amp; LocalPdfPath]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"CoupaInvoiceId\" referenced in Message but not declared in workflow \"ExtractInvoiceFields\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/ExtractInvoiceFields.xaml",
      "workflow": "ExtractInvoiceFields",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "referencedSymbol": "LocalPdfPath",
      "offendingExpression": "[&quot;[ExtractInvoiceFields] START — CoupaInvoiceId=&quot; &amp; CoupaInvoiceId &amp; &quot; | LocalPdfPath=&quot; &amp; LocalPdfPath]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"LocalPdfPath\" referenced in Message but not declared in workflow \"ExtractInvoiceFields\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/ExtractInvoiceFields.xaml",
      "workflow": "ExtractInvoiceFields",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "referencedSymbol": "CoupaInvoiceId",
      "offendingExpression": "[&quot;[ExtractInvoiceFields] Digitize complete — CoupaInvoiceId=&quot; &amp; CoupaInvoiceId &amp; &quot; | DocumentPages=&quot; &amp; If(digitizedDocument IsNot Nothing, &quot;(document object availa",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"CoupaInvoiceId\" referenced in Message but not declared in workflow \"ExtractInvoiceFields\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/ExtractInvoiceFields.xaml",
      "workflow": "ExtractInvoiceFields",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "referencedSymbol": "digitizedDocument",
      "offendingExpression": "[&quot;[ExtractInvoiceFields] Digitize complete — CoupaInvoiceId=&quot; &amp; CoupaInvoiceId &amp; &quot; | DocumentPages=&quot; &amp; If(digitizedDocument IsNot Nothing, &quot;(document object availa",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"digitizedDocument\" referenced in Message but not declared in workflow \"ExtractInvoiceFields\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/ExtractInvoiceFields.xaml",
      "workflow": "ExtractInvoiceFields",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "referencedSymbol": "CoupaInvoiceId",
      "offendingExpression": "[&quot;[ExtractInvoiceFields] ExtractDocumentData complete — CoupaInvoiceId=&quot; &amp; CoupaInvoiceId &amp; &quot; | ResultsAvailable=&quot; &amp; If(extractionResults IsNot Nothing, &quot;True&quot",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"CoupaInvoiceId\" referenced in Message but not declared in workflow \"ExtractInvoiceFields\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/ExtractInvoiceFields.xaml",
      "workflow": "ExtractInvoiceFields",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "referencedSymbol": "extractionResults",
      "offendingExpression": "[&quot;[ExtractInvoiceFields] ExtractDocumentData complete — CoupaInvoiceId=&quot; &amp; CoupaInvoiceId &amp; &quot; | ResultsAvailable=&quot; &amp; If(extractionResults IsNot Nothing, &quot;True&quot",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"extractionResults\" referenced in Message but not declared in workflow \"ExtractInvoiceFields\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/ExtractInvoiceFields.xaml",
      "workflow": "ExtractInvoiceFields",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "referencedSymbol": "CoupaInvoiceId",
      "offendingExpression": "[&quot;[ExtractInvoiceFields] FieldConfidences — CoupaInvoiceId=&quot; &amp; CoupaInvoiceId &amp; &quot; | PONumber=&quot; &amp; poNumberConfidenceDouble.ToString(&quot;F4&quot;) &amp; &quot; | Invoic",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"CoupaInvoiceId\" referenced in Message but not declared in workflow \"ExtractInvoiceFields\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/ExtractInvoiceFields.xaml",
      "workflow": "ExtractInvoiceFields",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "referencedSymbol": "poNumberConfidenceDouble",
      "offendingExpression": "[&quot;[ExtractInvoiceFields] FieldConfidences — CoupaInvoiceId=&quot; &amp; CoupaInvoiceId &amp; &quot; | PONumber=&quot; &amp; poNumberConfidenceDouble.ToString(&quot;F4&quot;) &amp; &quot; | Invoic",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"poNumberConfidenceDouble\" referenced in Message but not declared in workflow \"ExtractInvoiceFields\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/ExtractInvoiceFields.xaml",
      "workflow": "ExtractInvoiceFields",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "referencedSymbol": "invoiceNumberConfidenceDouble",
      "offendingExpression": "[&quot;[ExtractInvoiceFields] FieldConfidences — CoupaInvoiceId=&quot; &amp; CoupaInvoiceId &amp; &quot; | PONumber=&quot; &amp; poNumberConfidenceDouble.ToString(&quot;F4&quot;) &amp; &quot; | Invoic",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"invoiceNumberConfidenceDouble\" referenced in Message but not declared in workflow \"ExtractInvoiceFields\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/ExtractInvoiceFields.xaml",
      "workflow": "ExtractInvoiceFields",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "referencedSymbol": "vendorNameConfidence",
      "offendingExpression": "[&quot;[ExtractInvoiceFields] FieldConfidences — CoupaInvoiceId=&quot; &amp; CoupaInvoiceId &amp; &quot; | PONumber=&quot; &amp; poNumberConfidenceDouble.ToString(&quot;F4&quot;) &amp; &quot; | Invoic",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"vendorNameConfidence\" referenced in Message but not declared in workflow \"ExtractInvoiceFields\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/ExtractInvoiceFields.xaml",
      "workflow": "ExtractInvoiceFields",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "referencedSymbol": "totalAmountConfidenceDouble",
      "offendingExpression": "[&quot;[ExtractInvoiceFields] FieldConfidences — CoupaInvoiceId=&quot; &amp; CoupaInvoiceId &amp; &quot; | PONumber=&quot; &amp; poNumberConfidenceDouble.ToString(&quot;F4&quot;) &amp; &quot; | Invoic",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"totalAmountConfidenceDouble\" referenced in Message but not declared in workflow \"ExtractInvoiceFields\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/ExtractInvoiceFields.xaml",
      "workflow": "ExtractInvoiceFields",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "referencedSymbol": "confidenceThresholdFraction",
      "offendingExpression": "[&quot;[ExtractInvoiceFields] FieldConfidences — CoupaInvoiceId=&quot; &amp; CoupaInvoiceId &amp; &quot; | PONumber=&quot; &amp; poNumberConfidenceDouble.ToString(&quot;F4&quot;) &amp; &quot; | Invoic",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"confidenceThresholdFraction\" referenced in Message but not declared in workflow \"ExtractInvoiceFields\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/ExtractInvoiceFields.xaml",
      "workflow": "ExtractInvoiceFields",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "referencedSymbol": "CoupaInvoiceId",
      "offendingExpression": "[&quot;[ExtractInvoiceFields] ConfidenceDecision — CoupaInvoiceId=&quot; &amp; CoupaInvoiceId &amp; &quot; | FieldsBelowThreshold=&quot; &amp; fieldsBelowThreshold.ToString() &amp; &quot; | NeedsHuman",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"CoupaInvoiceId\" referenced in Message but not declared in workflow \"ExtractInvoiceFields\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/ExtractInvoiceFields.xaml",
      "workflow": "ExtractInvoiceFields",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "referencedSymbol": "fieldsBelowThreshold",
      "offendingExpression": "[&quot;[ExtractInvoiceFields] ConfidenceDecision — CoupaInvoiceId=&quot; &amp; CoupaInvoiceId &amp; &quot; | FieldsBelowThreshold=&quot; &amp; fieldsBelowThreshold.ToString() &amp; &quot; | NeedsHuman",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"fieldsBelowThreshold\" referenced in Message but not declared in workflow \"ExtractInvoiceFields\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/ExtractInvoiceFields.xaml",
      "workflow": "ExtractInvoiceFields",
      "activityType": "Assign",
      "propertyName": "Value",
      "referencedSymbol": "confidenceThreshold",
      "offendingExpression": "[CDbl(confidenceThreshold) / 100.0]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"confidenceThreshold\" referenced in child element <Assign.Value> but not declared in workflow \"ExtractInvoiceFields\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/CreateValidationTask.xaml",
      "workflow": "CreateValidationTask",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "referencedSymbol": "CoupaInvoiceId",
      "offendingExpression": "[&quot;[CreateValidationTask] START — CoupaInvoiceId=&quot; &amp; CoupaInvoiceId &amp; &quot; | VendorName=&quot; &amp; VendorName &amp; &quot; | ExtractedPONumber=&quot; &amp; ExtractedPONumber &amp;",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"CoupaInvoiceId\" referenced in Message but not declared in workflow \"CreateValidationTask\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/CreateValidationTask.xaml",
      "workflow": "CreateValidationTask",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "referencedSymbol": "VendorName",
      "offendingExpression": "[&quot;[CreateValidationTask] START — CoupaInvoiceId=&quot; &amp; CoupaInvoiceId &amp; &quot; | VendorName=&quot; &amp; VendorName &amp; &quot; | ExtractedPONumber=&quot; &amp; ExtractedPONumber &amp;",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"VendorName\" referenced in Message but not declared in workflow \"CreateValidationTask\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/CreateValidationTask.xaml",
      "workflow": "CreateValidationTask",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "referencedSymbol": "ExtractedPONumber",
      "offendingExpression": "[&quot;[CreateValidationTask] START — CoupaInvoiceId=&quot; &amp; CoupaInvoiceId &amp; &quot; | VendorName=&quot; &amp; VendorName &amp; &quot; | ExtractedPONumber=&quot; &amp; ExtractedPONumber &amp;",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"ExtractedPONumber\" referenced in Message but not declared in workflow \"CreateValidationTask\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/CreateValidationTask.xaml",
      "workflow": "CreateValidationTask",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "referencedSymbol": "PdfBucketPath",
      "offendingExpression": "[&quot;[CreateValidationTask] START — CoupaInvoiceId=&quot; &amp; CoupaInvoiceId &amp; &quot; | VendorName=&quot; &amp; VendorName &amp; &quot; | ExtractedPONumber=&quot; &amp; ExtractedPONumber &amp;",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"PdfBucketPath\" referenced in Message but not declared in workflow \"CreateValidationTask\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/CreateValidationTask.xaml",
      "workflow": "CreateValidationTask",
      "activityType": "ui:GetAsset",
      "propertyName": "Value",
      "referencedSymbol": "slaHoursRaw",
      "offendingExpression": "[slaHoursRaw]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"slaHoursRaw\" referenced in Value but not declared in workflow \"CreateValidationTask\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/CreateValidationTask.xaml",
      "workflow": "CreateValidationTask",
      "activityType": "uds:QueryEntity",
      "propertyName": "Result",
      "referencedSymbol": "queriedCases",
      "offendingExpression": "[queriedCases]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "execution_blocking",
      "rationale": "Variable \"queriedCases\" referenced in Result but not declared in workflow \"CreateValidationTask\" — expression replaced with \"Nothing\""
    },
    {
      "file": "lib/net45/CreateValidationTask.xaml",
      "workflow": "CreateValidationTask",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "referencedSymbol": "CoupaInvoiceId",
      "offendingExpression": "[&quot;[CreateValidationTask] END — CoupaInvoiceId=&quot; &amp; CoupaInvoiceId &amp; &quot; | TaskId=&quot; &amp; createdTaskId &amp; &quot; | CaseStatus=PendingValidation | InvoiceCaseId=&quot; &amp;",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"CoupaInvoiceId\" referenced in Message but not declared in workflow \"CreateValidationTask\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/CreateValidationTask.xaml",
      "workflow": "CreateValidationTask",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "referencedSymbol": "createdTaskId",
      "offendingExpression": "[&quot;[CreateValidationTask] END — CoupaInvoiceId=&quot; &amp; CoupaInvoiceId &amp; &quot; | TaskId=&quot; &amp; createdTaskId &amp; &quot; | CaseStatus=PendingValidation | InvoiceCaseId=&quot; &amp;",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"createdTaskId\" referenced in Message but not declared in workflow \"CreateValidationTask\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/CreateValidationTask.xaml",
      "workflow": "CreateValidationTask",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "referencedSymbol": "invoiceCaseId",
      "offendingExpression": "[&quot;[CreateValidationTask] END — CoupaInvoiceId=&quot; &amp; CoupaInvoiceId &amp; &quot; | TaskId=&quot; &amp; createdTaskId &amp; &quot; | CaseStatus=PendingValidation | InvoiceCaseId=&quot; &amp;",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"invoiceCaseId\" referenced in Message but not declared in workflow \"CreateValidationTask\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/CreateValidationTask.xaml",
      "workflow": "CreateValidationTask",
      "activityType": "Assign",
      "propertyName": "Value",
      "referencedSymbol": "slaHoursRaw",
      "offendingExpression": "[If(Integer.TryParse(slaHoursRaw, Nothing), CInt(slaHoursRaw), 24)]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"slaHoursRaw\" referenced in child element <Assign.Value> but not declared in workflow \"CreateValidationTask\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/CreateValidationTask.xaml",
      "workflow": "CreateValidationTask",
      "activityType": "Assign",
      "propertyName": "Value",
      "referencedSymbol": "slaHours",
      "offendingExpression": "[DateTime.UtcNow.AddHours(slaHours)]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"slaHours\" referenced in child element <Assign.Value> but not declared in workflow \"CreateValidationTask\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/ValidateAndDecide.xaml",
      "workflow": "ValidateAndDecide",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "referencedSymbol": "CoupaInvoiceId",
      "offendingExpression": "[&quot;[ValidateAndDecide][INFO] Starting validation. CoupaInvoiceId=&quot; &amp; CoupaInvoiceId &amp; &quot; | PONumber=&quot; &amp; PONumber &amp; &quot; | InvoiceTotal=&quot; &amp; InvoiceTotal &am",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"CoupaInvoiceId\" referenced in Message but not declared in workflow \"ValidateAndDecide\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/ValidateAndDecide.xaml",
      "workflow": "ValidateAndDecide",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "referencedSymbol": "PONumber",
      "offendingExpression": "[&quot;[ValidateAndDecide][INFO] Starting validation. CoupaInvoiceId=&quot; &amp; CoupaInvoiceId &amp; &quot; | PONumber=&quot; &amp; PONumber &amp; &quot; | InvoiceTotal=&quot; &amp; InvoiceTotal &am",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"PONumber\" referenced in Message but not declared in workflow \"ValidateAndDecide\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/ValidateAndDecide.xaml",
      "workflow": "ValidateAndDecide",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "referencedSymbol": "InvoiceTotal",
      "offendingExpression": "[&quot;[ValidateAndDecide][INFO] Starting validation. CoupaInvoiceId=&quot; &amp; CoupaInvoiceId &amp; &quot; | PONumber=&quot; &amp; PONumber &amp; &quot; | InvoiceTotal=&quot; &amp; InvoiceTotal &am",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"InvoiceTotal\" referenced in Message but not declared in workflow \"ValidateAndDecide\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/ValidateAndDecide.xaml",
      "workflow": "ValidateAndDecide",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "referencedSymbol": "VendorName",
      "offendingExpression": "[&quot;[ValidateAndDecide][INFO] Starting validation. CoupaInvoiceId=&quot; &amp; CoupaInvoiceId &amp; &quot; | PONumber=&quot; &amp; PONumber &amp; &quot; | InvoiceTotal=&quot; &amp; InvoiceTotal &am",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"VendorName\" referenced in Message but not declared in workflow \"ValidateAndDecide\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/ValidateAndDecide.xaml",
      "workflow": "ValidateAndDecide",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "referencedSymbol": "CoupaInvoiceId",
      "offendingExpression": "[&quot;[ValidateAndDecide][INFO] Step1-POLookup: Querying Coupa PO. CoupaInvoiceId=&quot; &amp; CoupaInvoiceId &amp; &quot; | PONumber=&quot; &amp; PONumber &amp; &quot; | URL=&quot; &amp; poLookupUrl",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"CoupaInvoiceId\" referenced in Message but not declared in workflow \"ValidateAndDecide\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/ValidateAndDecide.xaml",
      "workflow": "ValidateAndDecide",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "referencedSymbol": "PONumber",
      "offendingExpression": "[&quot;[ValidateAndDecide][INFO] Step1-POLookup: Querying Coupa PO. CoupaInvoiceId=&quot; &amp; CoupaInvoiceId &amp; &quot; | PONumber=&quot; &amp; PONumber &amp; &quot; | URL=&quot; &amp; poLookupUrl",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"PONumber\" referenced in Message but not declared in workflow \"ValidateAndDecide\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/ValidateAndDecide.xaml",
      "workflow": "ValidateAndDecide",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "referencedSymbol": "poLookupUrl",
      "offendingExpression": "[&quot;[ValidateAndDecide][INFO] Step1-POLookup: Querying Coupa PO. CoupaInvoiceId=&quot; &amp; CoupaInvoiceId &amp; &quot; | PONumber=&quot; &amp; PONumber &amp; &quot; | URL=&quot; &amp; poLookupUrl",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"poLookupUrl\" referenced in Message but not declared in workflow \"ValidateAndDecide\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/ValidateAndDecide.xaml",
      "workflow": "ValidateAndDecide",
      "activityType": "uweb:HttpClient",
      "propertyName": "Result",
      "referencedSymbol": "poLookupResponse",
      "offendingExpression": "[poLookupResponse]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "execution_blocking",
      "rationale": "Variable \"poLookupResponse\" referenced in Result but not declared in workflow \"ValidateAndDecide\" — expression replaced with \"Nothing\""
    },
    {
      "file": "lib/net45/ValidateAndDecide.xaml",
      "workflow": "ValidateAndDecide",
      "activityType": "uweb:DeserializeJson",
      "propertyName": "Result",
      "referencedSymbol": "poLookupResponse",
      "offendingExpression": "[poLookupResponse]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "execution_blocking",
      "rationale": "Variable \"poLookupResponse\" referenced in Result but not declared in workflow \"ValidateAndDecide\" — expression replaced with \"Nothing\""
    },
    {
      "file": "lib/net45/ValidateAndDecide.xaml",
      "workflow": "ValidateAndDecide",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "referencedSymbol": "poFound",
      "offendingExpression": "[&quot;[ValidateAndDecide][INFO] Step1-POLookup result: poFound=&quot; &amp; poFound.ToString() &amp; &quot; | CoupaInvoiceId=&quot; &amp; CoupaInvoiceId &amp; &quot; | PONumber=&quot; &amp; PONumber]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"poFound\" referenced in Message but not declared in workflow \"ValidateAndDecide\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/ValidateAndDecide.xaml",
      "workflow": "ValidateAndDecide",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "referencedSymbol": "CoupaInvoiceId",
      "offendingExpression": "[&quot;[ValidateAndDecide][INFO] Step1-POLookup result: poFound=&quot; &amp; poFound.ToString() &amp; &quot; | CoupaInvoiceId=&quot; &amp; CoupaInvoiceId &amp; &quot; | PONumber=&quot; &amp; PONumber]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"CoupaInvoiceId\" referenced in Message but not declared in workflow \"ValidateAndDecide\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/ValidateAndDecide.xaml",
      "workflow": "ValidateAndDecide",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "referencedSymbol": "PONumber",
      "offendingExpression": "[&quot;[ValidateAndDecide][INFO] Step1-POLookup result: poFound=&quot; &amp; poFound.ToString() &amp; &quot; | CoupaInvoiceId=&quot; &amp; CoupaInvoiceId &amp; &quot; | PONumber=&quot; &amp; PONumber]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"PONumber\" referenced in Message but not declared in workflow \"ValidateAndDecide\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/ValidateAndDecide.xaml",
      "workflow": "ValidateAndDecide",
      "activityType": "uweb:HttpClient",
      "propertyName": "Result",
      "referencedSymbol": "coupaRejectResponse",
      "offendingExpression": "[coupaRejectResponse]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "execution_blocking",
      "rationale": "Variable \"coupaRejectResponse\" referenced in Result but not declared in workflow \"ValidateAndDecide\" — expression replaced with \"Nothing\""
    },
    {
      "file": "lib/net45/ValidateAndDecide.xaml",
      "workflow": "ValidateAndDecide",
      "activityType": "uds:QueryEntity",
      "propertyName": "Result",
      "referencedSymbol": "invoiceCaseQueryResult",
      "offendingExpression": "[invoiceCaseQueryResult]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "execution_blocking",
      "rationale": "Variable \"invoiceCaseQueryResult\" referenced in Result but not declared in workflow \"ValidateAndDecide\" — expression replaced with \"Nothing\""
    },
    {
      "file": "lib/net45/ValidateAndDecide.xaml",
      "workflow": "ValidateAndDecide",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "referencedSymbol": "CoupaInvoiceId",
      "offendingExpression": "[&quot;[ValidateAndDecide][WARN] BusinessRejection: PO_MISMATCH_OR_NOT_FOUND. CoupaInvoiceId=&quot; &amp; CoupaInvoiceId &amp; &quot; | PONumber=&quot; &amp; PONumber &amp; &quot; | CoupaResponse=&quo",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"CoupaInvoiceId\" referenced in Message but not declared in workflow \"ValidateAndDecide\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/ValidateAndDecide.xaml",
      "workflow": "ValidateAndDecide",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "referencedSymbol": "PONumber",
      "offendingExpression": "[&quot;[ValidateAndDecide][WARN] BusinessRejection: PO_MISMATCH_OR_NOT_FOUND. CoupaInvoiceId=&quot; &amp; CoupaInvoiceId &amp; &quot; | PONumber=&quot; &amp; PONumber &amp; &quot; | CoupaResponse=&quo",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"PONumber\" referenced in Message but not declared in workflow \"ValidateAndDecide\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/ValidateAndDecide.xaml",
      "workflow": "ValidateAndDecide",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "referencedSymbol": "coupaRejectResponse",
      "offendingExpression": "[&quot;[ValidateAndDecide][WARN] BusinessRejection: PO_MISMATCH_OR_NOT_FOUND. CoupaInvoiceId=&quot; &amp; CoupaInvoiceId &amp; &quot; | PONumber=&quot; &amp; PONumber &amp; &quot; | CoupaResponse=&quo",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"coupaRejectResponse\" referenced in Message but not declared in workflow \"ValidateAndDecide\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/ValidateAndDecide.xaml",
      "workflow": "ValidateAndDecide",
      "activityType": "Throw",
      "propertyName": "Exception",
      "referencedSymbol": "PONumber",
      "offendingExpression": "[New UiPath.Core.Activities.BusinessRuleException(&quot;PO_MISMATCH_OR_NOT_FOUND: PO &apos;&quot; &amp; PONumber &amp; &quot;&apos; not found or mismatch for invoice &apos;&quot; &amp; CoupaInvoiceId ",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"PONumber\" referenced in Exception but not declared in workflow \"ValidateAndDecide\" — expression replaced with \"Nothing\""
    },
    {
      "file": "lib/net45/ValidateAndDecide.xaml",
      "workflow": "ValidateAndDecide",
      "activityType": "Throw",
      "propertyName": "Exception",
      "referencedSymbol": "CoupaInvoiceId",
      "offendingExpression": "[New UiPath.Core.Activities.BusinessRuleException(&quot;PO_MISMATCH_OR_NOT_FOUND: PO &apos;&quot; &amp; PONumber &amp; &quot;&apos; not found or mismatch for invoice &apos;&quot; &amp; CoupaInvoiceId ",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"CoupaInvoiceId\" referenced in Exception but not declared in workflow \"ValidateAndDecide\" — expression replaced with \"Nothing\""
    },
    {
      "file": "lib/net45/ValidateAndDecide.xaml",
      "workflow": "ValidateAndDecide",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "referencedSymbol": "invoiceTotalDecimal",
      "offendingExpression": "[&quot;[ValidateAndDecide][INFO] Step2-ToleranceCheck: InvoiceTotal=&quot; &amp; invoiceTotalDecimal.ToString() &amp; &quot; | ReferenceAmount=&quot; &amp; referenceAmount.ToString() &amp; &quot; | To",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"invoiceTotalDecimal\" referenced in Message but not declared in workflow \"ValidateAndDecide\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/ValidateAndDecide.xaml",
      "workflow": "ValidateAndDecide",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "referencedSymbol": "referenceAmount",
      "offendingExpression": "[&quot;[ValidateAndDecide][INFO] Step2-ToleranceCheck: InvoiceTotal=&quot; &amp; invoiceTotalDecimal.ToString() &amp; &quot; | ReferenceAmount=&quot; &amp; referenceAmount.ToString() &amp; &quot; | To",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"referenceAmount\" referenced in Message but not declared in workflow \"ValidateAndDecide\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/ValidateAndDecide.xaml",
      "workflow": "ValidateAndDecide",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "referencedSymbol": "toleranceBasis",
      "offendingExpression": "[&quot;[ValidateAndDecide][INFO] Step2-ToleranceCheck: InvoiceTotal=&quot; &amp; invoiceTotalDecimal.ToString() &amp; &quot; | ReferenceAmount=&quot; &amp; referenceAmount.ToString() &amp; &quot; | To",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"toleranceBasis\" referenced in Message but not declared in workflow \"ValidateAndDecide\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/ValidateAndDecide.xaml",
      "workflow": "ValidateAndDecide",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "referencedSymbol": "tolerancePercent",
      "offendingExpression": "[&quot;[ValidateAndDecide][INFO] Step2-ToleranceCheck: InvoiceTotal=&quot; &amp; invoiceTotalDecimal.ToString() &amp; &quot; | ReferenceAmount=&quot; &amp; referenceAmount.ToString() &amp; &quot; | To",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"tolerancePercent\" referenced in Message but not declared in workflow \"ValidateAndDecide\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/ValidateAndDecide.xaml",
      "workflow": "ValidateAndDecide",
      "activityType": "ui:LogMessage",
      "propertyName": "Message",
      "referencedSymbol": "CoupaInvoiceId",
      "offendingExpression": "[&quot;[ValidateAndDecide][INFO] Step2-ToleranceCheck: InvoiceTotal=&quot; &amp; invoiceTotalDecimal.ToString() &amp; &quot; | ReferenceAmount=&quot; &amp; referenceAmount.ToString() &amp; &quot; | To",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"CoupaInvoiceId\" referenced in Message but not declared in workflow \"ValidateAndDecide\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/ValidateAndDecide.xaml",
      "workflow": "ValidateAndDecide",
      "activityType": "Assign",
      "propertyName": "Value",
      "referencedSymbol": "Rejected",
      "offendingExpression": "[Rejected]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"Rejected\" referenced in child element <Assign.Value> but not declared in workflow \"ValidateAndDecide\" — expression replaced with \"\"\"\""
    },
    {
      "file": "lib/net45/ValidateAndDecide.xaml",
      "workflow": "ValidateAndDecide",
      "activityType": "Assign",
      "propertyName": "Value",
      "referencedSymbol": "value",
      "offendingExpression": "[value]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "undeclared_variable_reference",
      "severity": "handoff_required",
      "rationale": "Variable \"value\" referenced in child element <Assign.Value> but not declared in workflow \"ValidateAndDecide\" — expression replaced with \"\"\"\""
    }
  ],
  "targetValueCanonicalizationSummary": "Target/value canonicalization: 0 expression fix(es), 173 symbol scope defect(s), 0 sentinel replacement(s), 169 unresolvable JSON defect(s)",
  "residualExpressionSerializationDefects": [
    {
      "file": "lib/net45/Main.xaml",
      "workflow": "Main",
      "activityType": "If",
      "propertyName": "Condition",
      "originalValue": "[{&quot;type&quot;:&quot;expression&quot;,&quot;left&quot;:&quot;initSuccess&quot;,&quot;operator&quot;:&quot;=&quot;,&quot;right&quot;:&quot;False&quot;}]",
      "defectType": "json_expression_leak",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON expression payload in Condition — manual remediation required"
    },
    {
      "file": "lib/net45/Main.xaml",
      "workflow": "Main",
      "activityType": "If",
      "propertyName": "Condition",
      "originalValue": "[{&quot;type&quot;:&quot;expression&quot;,&quot;left&quot;:&quot;transactionItem&quot;,&quot;operator&quot;:&quot;Is&quot;,&quot;right&quot;:&quot;Nothing&quot;}]",
      "defectType": "json_expression_leak",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON expression payload in Condition — manual remediation required"
    },
    {
      "file": "lib/net45/Main.xaml",
      "workflow": "Main",
      "activityType": "If",
      "propertyName": "Condition",
      "originalValue": "[{&quot;type&quot;:&quot;expression&quot;,&quot;left&quot;:&quot;isBusinessException&quot;,&quot;operator&quot;:&quot;=&quot;,&quot;right&quot;:&quot;True&quot;}]",
      "defectType": "json_expression_leak",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON expression payload in Condition — manual remediation required"
    },
    {
      "file": "lib/net45/Main.xaml",
      "workflow": "Main",
      "activityType": "If",
      "propertyName": "Condition",
      "originalValue": "[{&quot;type&quot;:&quot;expression&quot;,&quot;left&quot;:&quot;consecutiveSystemExceptions&quot;,&quot;operator&quot;:&quot;&gt;=&quot;,&quot;right&quot;:&quot;maxConsecutiveSystemExceptions&quot;}]",
      "defectType": "json_expression_leak",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON expression payload in Condition — manual remediation required"
    },
    {
      "file": "lib/net45/Main.xaml",
      "workflow": "Main",
      "activityType": "If",
      "propertyName": "Condition",
      "originalValue": "[{&quot;type&quot;:&quot;expression&quot;,&quot;left&quot;:&quot;isBusinessException&quot;,&quot;operator&quot;:&quot;OrElse&quot;,&quot;right&quot;:&quot;transactionStatus&quot;}]",
      "defectType": "json_expression_leak",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON expression payload in Condition — manual remediation required"
    },
    {
      "file": "lib/net45/Dispatcher.xaml",
      "workflow": "Dispatcher",
      "activityType": "If",
      "propertyName": "Condition",
      "originalValue": "[{&quot;type&quot;:&quot;expression&quot;,&quot;left&quot;:&quot;bool_PollingEnabled&quot;,&quot;operator&quot;:&quot;=&quot;,&quot;right&quot;:&quot;False&quot;}]",
      "defectType": "json_expression_leak",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON expression payload in Condition — manual remediation required"
    },
    {
      "file": "lib/net45/Dispatcher.xaml",
      "workflow": "Dispatcher",
      "activityType": "If",
      "propertyName": "Condition",
      "originalValue": "[{&quot;type&quot;:&quot;expression&quot;,&quot;left&quot;:&quot;bool_CaseExists&quot;,&quot;operator&quot;:&quot;=&quot;,&quot;right&quot;:&quot;True&quot;}]",
      "defectType": "json_expression_leak",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON expression payload in Condition — manual remediation required"
    },
    {
      "file": "lib/net45/InitialiseConfig.xaml",
      "workflow": "InitialiseConfig",
      "activityType": "If",
      "propertyName": "Condition",
      "originalValue": "[{&quot;type&quot;:&quot;expression&quot;,&quot;left&quot;:&quot;String.IsNullOrWhiteSpace(str_CoupaBaseUrl)&quot;,&quot;operator&quot;:&quot;=&quot;,&quot;right&quot;:&quot;True&quot;}]",
      "defectType": "json_expression_leak",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON expression payload in Condition — manual remediation required"
    },
    {
      "file": "lib/net45/InitialiseConfig.xaml",
      "workflow": "InitialiseConfig",
      "activityType": "If",
      "propertyName": "Condition",
      "originalValue": "[{&quot;type&quot;:&quot;expression&quot;,&quot;left&quot;:&quot;String.IsNullOrWhiteSpace(str_ValidationErrors)&quot;,&quot;operator&quot;:&quot;=&quot;,&quot;right&quot;:&quot;False&quot;}]",
      "defectType": "json_expression_leak",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON expression payload in Condition — manual remediation required"
    },
    {
      "file": "lib/net45/ProcessTransaction.xaml",
      "workflow": "ProcessTransaction",
      "activityType": "If",
      "propertyName": "Condition",
      "originalValue": "[{&quot;type&quot;:&quot;expression&quot;,&quot;left&quot;:&quot;needsHumanValidation&quot;,&quot;operator&quot;:&quot;=&quot;,&quot;right&quot;:&quot;True&quot;}]",
      "defectType": "json_expression_leak",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON expression payload in Condition — manual remediation required"
    },
    {
      "file": "lib/net45/RetrieveInvoicePdf.xaml",
      "workflow": "RetrieveInvoicePdf",
      "activityType": "If",
      "propertyName": "Condition",
      "originalValue": "[{&quot;type&quot;:&quot;expression&quot;,&quot;left&quot;:&quot;tempPathExists&quot;,&quot;operator&quot;:&quot;&lt;&gt;&quot;,&quot;right&quot;:&quot;True&quot;}]",
      "defectType": "json_expression_leak",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON expression payload in Condition — manual remediation required"
    },
    {
      "file": "lib/net45/RetrieveInvoicePdf.xaml",
      "workflow": "RetrieveInvoicePdf",
      "activityType": "If",
      "propertyName": "Condition",
      "originalValue": "[{&quot;type&quot;:&quot;expression&quot;,&quot;left&quot;:&quot;fileLockDetected&quot;,&quot;operator&quot;:&quot;=&quot;,&quot;right&quot;:&quot;True&quot;}]",
      "defectType": "json_expression_leak",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON expression payload in Condition — manual remediation required"
    },
    {
      "file": "lib/net45/RetrieveInvoicePdf.xaml",
      "workflow": "RetrieveInvoicePdf",
      "activityType": "If",
      "propertyName": "Condition",
      "originalValue": "[{&quot;type&quot;:&quot;expression&quot;,&quot;left&quot;:&quot;fileLockDetected&quot;,&quot;operator&quot;:&quot;=&quot;,&quot;right&quot;:&quot;True&quot;}]",
      "defectType": "json_expression_leak",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON expression payload in Condition — manual remediation required"
    },
    {
      "file": "lib/net45/RetrieveInvoicePdf.xaml",
      "workflow": "RetrieveInvoicePdf",
      "activityType": "If",
      "propertyName": "Condition",
      "originalValue": "[{&quot;type&quot;:&quot;expression&quot;,&quot;left&quot;:&quot;fileSizeBytes&quot;,&quot;operator&quot;:&quot;&lt;=&quot;,&quot;right&quot;:&quot;0&quot;}]",
      "defectType": "json_expression_leak",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON expression payload in Condition — manual remediation required"
    },
    {
      "file": "lib/net45/ValidateAndDecide.xaml",
      "workflow": "ValidateAndDecide",
      "activityType": "If",
      "propertyName": "Condition",
      "originalValue": "[{&quot;type&quot;:&quot;expression&quot;,&quot;left&quot;:&quot;poFound&quot;,&quot;operator&quot;:&quot;=&quot;,&quot;right&quot;:&quot;False&quot;}]",
      "defectType": "json_expression_leak",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON expression payload in Condition — manual remediation required"
    },
    {
      "file": "lib/net45/ValidateAndDecide.xaml",
      "workflow": "ValidateAndDecide",
      "activityType": "If",
      "propertyName": "Condition",
      "originalValue": "[{&quot;type&quot;:&quot;expression&quot;,&quot;left&quot;:&quot;toleranceBasis&quot;,&quot;operator&quot;:&quot;=&quot;,&quot;right&quot;:&quot;PO_REMAINING&quot;}]",
      "defectType": "json_expression_leak",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON expression payload in Condition — manual remediation required"
    }
  ],
  "sentinelReplacements": [],
  "unresolvableJsonDefects": [
    {
      "file": "lib/net45/Main.xaml",
      "workflow": "Main",
      "activityType": "Assign",
      "propertyName": "To",
      "originalValue": "\"{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;initSuccess&quot;}\"",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.To> replaced with platform-safe value \"Nothing\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/Main.xaml",
      "workflow": "Main",
      "activityType": "Assign",
      "propertyName": "To",
      "originalValue": "\"{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;totalSucceeded&quot;}\"",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.To> replaced with platform-safe value \"Nothing\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/Main.xaml",
      "workflow": "Main",
      "activityType": "Assign",
      "propertyName": "To",
      "originalValue": "\"{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;totalProcessed&quot;}\"",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.To> replaced with platform-safe value \"Nothing\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/Main.xaml",
      "workflow": "Main",
      "activityType": "Assign",
      "propertyName": "To",
      "originalValue": "\"{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;processEndTime&quot;}\"",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.To> replaced with platform-safe value \"Nothing\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/Dispatcher.xaml",
      "workflow": "Dispatcher",
      "activityType": "Assign",
      "propertyName": "To",
      "originalValue": "\"{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;str_RunStartUtc&quot;}\"",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.To> replaced with platform-safe value \"Nothing\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/Dispatcher.xaml",
      "workflow": "Dispatcher",
      "activityType": "Assign",
      "propertyName": "To",
      "originalValue": "\"{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;str_CoupaInvoicesEndpoint&quot;}\"",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.To> replaced with platform-safe value \"Nothing\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/Dispatcher.xaml",
      "workflow": "Dispatcher",
      "activityType": "Assign",
      "propertyName": "To",
      "originalValue": "\"{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;arr_Invoices&quot;}\"",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.To> replaced with platform-safe value \"Nothing\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/Dispatcher.xaml",
      "workflow": "Dispatcher",
      "activityType": "Assign",
      "propertyName": "To",
      "originalValue": "\"{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;int_EnqueuedCount&quot;}\"",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.To> replaced with platform-safe value \"Nothing\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/Dispatcher.xaml",
      "workflow": "Dispatcher",
      "activityType": "Assign",
      "propertyName": "To",
      "originalValue": "\"{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;str_CurrentInvoiceId&quot;}\"",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.To> replaced with platform-safe value \"Nothing\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/Dispatcher.xaml",
      "workflow": "Dispatcher",
      "activityType": "Assign",
      "propertyName": "To",
      "originalValue": "\"{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;str_CurrentVendorName&quot;}\"",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.To> replaced with platform-safe value \"Nothing\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/Dispatcher.xaml",
      "workflow": "Dispatcher",
      "activityType": "Assign",
      "propertyName": "To",
      "originalValue": "\"{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;str_CurrentPdfUrl&quot;}\"",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.To> replaced with platform-safe value \"Nothing\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/Dispatcher.xaml",
      "workflow": "Dispatcher",
      "activityType": "Assign",
      "propertyName": "To",
      "originalValue": "\"{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;str_CurrentSubmittedUtc&quot;}\"",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.To> replaced with platform-safe value \"Nothing\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/Dispatcher.xaml",
      "workflow": "Dispatcher",
      "activityType": "Assign",
      "propertyName": "To",
      "originalValue": "\"{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;bool_CaseExists&quot;}\"",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.To> replaced with platform-safe value \"Nothing\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/Dispatcher.xaml",
      "workflow": "Dispatcher",
      "activityType": "Assign",
      "propertyName": "To",
      "originalValue": "\"{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;dict_QueueItemSpecificContent&quot;}\"",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.To> replaced with platform-safe value \"Nothing\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/Dispatcher.xaml",
      "workflow": "Dispatcher",
      "activityType": "Assign",
      "propertyName": "To",
      "originalValue": "\"{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;int_EnqueuedCount&quot;}\"",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.To> replaced with platform-safe value \"Nothing\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/Dispatcher.xaml",
      "workflow": "Dispatcher",
      "activityType": "Assign",
      "propertyName": "Value",
      "originalValue": "[{&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;DateTime.UtcNow.ToString(\\&quot;yyyy-MM-ddTHH:mm:ssZ\\&quot;)&quot;}]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.Value> replaced with platform-safe value \"\"\"\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/Dispatcher.xaml",
      "workflow": "Dispatcher",
      "activityType": "Assign",
      "propertyName": "Value",
      "originalValue": "[{&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;str_CoupaBaseUrl &amp; \\&quot;/api/invoices?status=submitted&amp;created-at[gt_or_eq]=\\&quot; &amp; str_LastRunUtc &amp; \\&quot;&am",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.Value> replaced with platform-safe value \"\"\"\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/Dispatcher.xaml",
      "workflow": "Dispatcher",
      "activityType": "Assign",
      "propertyName": "Value",
      "originalValue": "[{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;obj_CoupaResponseJson&quot;}]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.Value> replaced with platform-safe value \"\"\"\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/Dispatcher.xaml",
      "workflow": "Dispatcher",
      "activityType": "Assign",
      "propertyName": "Value",
      "originalValue": "[{&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;CType(item, Newtonsoft.Json.Linq.JObject)(\\&quot;id\\&quot;).ToString()&quot;}]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.Value> replaced with platform-safe value \"\"\"\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/Dispatcher.xaml",
      "workflow": "Dispatcher",
      "activityType": "Assign",
      "propertyName": "Value",
      "originalValue": "[{&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;If(CType(item, Newtonsoft.Json.Linq.JObject)(\\&quot;supplier\\&quot;) IsNot Nothing, CType(item, Newtonsoft.Json.Linq.JObject)(\\&quo",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.Value> replaced with platform-safe value \"\"\"\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/Dispatcher.xaml",
      "workflow": "Dispatcher",
      "activityType": "Assign",
      "propertyName": "Value",
      "originalValue": "[{&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;If(CType(item, Newtonsoft.Json.Linq.JObject)(\\&quot;attachments\\&quot;) IsNot Nothing AndAlso CType(item, Newtonsoft.Json.Linq.JObj",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.Value> replaced with platform-safe value \"\"\"\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/Dispatcher.xaml",
      "workflow": "Dispatcher",
      "activityType": "Assign",
      "propertyName": "Value",
      "originalValue": "[{&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;If(CType(item, Newtonsoft.Json.Linq.JObject)(\\&quot;created-at\\&quot;) IsNot Nothing, CType(item, Newtonsoft.Json.Linq.JObject)(\\&q",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.Value> replaced with platform-safe value \"\"\"\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/Dispatcher.xaml",
      "workflow": "Dispatcher",
      "activityType": "Assign",
      "propertyName": "Value",
      "originalValue": "[{&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;obj_ExistingCaseQuery IsNot Nothing AndAlso CType(obj_ExistingCaseQuery, System.Collections.Generic.IEnumerable(Of Object)).Count()",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.Value> replaced with platform-safe value \"\"\"\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/Dispatcher.xaml",
      "workflow": "Dispatcher",
      "activityType": "Assign",
      "propertyName": "Value",
      "originalValue": "[{&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;New Dictionary(Of String, Object) From {{\\&quot;CoupaInvoiceId\\&quot;, str_CurrentInvoiceId}, {\\&quot;VendorName\\&quot;, str_Curren",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.Value> replaced with platform-safe value \"\"\"\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/InitialiseConfig.xaml",
      "workflow": "InitialiseConfig",
      "activityType": "Assign",
      "propertyName": "To",
      "originalValue": "\"{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;dict_Config&quot;}\"",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.To> replaced with platform-safe value \"Nothing\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/InitialiseConfig.xaml",
      "workflow": "InitialiseConfig",
      "activityType": "Assign",
      "propertyName": "To",
      "originalValue": "\"{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;str_ValidationErrors&quot;}\"",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.To> replaced with platform-safe value \"Nothing\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/InitialiseConfig.xaml",
      "workflow": "InitialiseConfig",
      "activityType": "Assign",
      "propertyName": "To",
      "originalValue": "\"{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;int_TolerancePercent&quot;}\"",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.To> replaced with platform-safe value \"Nothing\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/InitialiseConfig.xaml",
      "workflow": "InitialiseConfig",
      "activityType": "Assign",
      "propertyName": "To",
      "originalValue": "\"{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;str_ValidationErrors&quot;}\"",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.To> replaced with platform-safe value \"Nothing\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/InitialiseConfig.xaml",
      "workflow": "InitialiseConfig",
      "activityType": "Assign",
      "propertyName": "To",
      "originalValue": "\"{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;int_DuConfidenceThreshold&quot;}\"",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.To> replaced with platform-safe value \"Nothing\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/InitialiseConfig.xaml",
      "workflow": "InitialiseConfig",
      "activityType": "Assign",
      "propertyName": "To",
      "originalValue": "\"{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;str_ValidationErrors&quot;}\"",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.To> replaced with platform-safe value \"Nothing\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/InitialiseConfig.xaml",
      "workflow": "InitialiseConfig",
      "activityType": "Assign",
      "propertyName": "To",
      "originalValue": "\"{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;int_ActionCenterSlaHours&quot;}\"",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.To> replaced with platform-safe value \"Nothing\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/InitialiseConfig.xaml",
      "workflow": "InitialiseConfig",
      "activityType": "Assign",
      "propertyName": "To",
      "originalValue": "\"{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;str_ValidationErrors&quot;}\"",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.To> replaced with platform-safe value \"Nothing\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/InitialiseConfig.xaml",
      "workflow": "InitialiseConfig",
      "activityType": "Assign",
      "propertyName": "To",
      "originalValue": "\"{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;int_StorageRetentionDays&quot;}\"",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.To> replaced with platform-safe value \"Nothing\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/InitialiseConfig.xaml",
      "workflow": "InitialiseConfig",
      "activityType": "Assign",
      "propertyName": "To",
      "originalValue": "\"{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;str_ValidationErrors&quot;}\"",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.To> replaced with platform-safe value \"Nothing\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/InitialiseConfig.xaml",
      "workflow": "InitialiseConfig",
      "activityType": "Assign",
      "propertyName": "To",
      "originalValue": "\"{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;int_PollingLookbackMinutes&quot;}\"",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.To> replaced with platform-safe value \"Nothing\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/InitialiseConfig.xaml",
      "workflow": "InitialiseConfig",
      "activityType": "Assign",
      "propertyName": "To",
      "originalValue": "\"{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;str_ValidationErrors&quot;}\"",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.To> replaced with platform-safe value \"Nothing\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/InitialiseConfig.xaml",
      "workflow": "InitialiseConfig",
      "activityType": "Assign",
      "propertyName": "To",
      "originalValue": "\"{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;bool_PollingEnabled&quot;}\"",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.To> replaced with platform-safe value \"Nothing\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/InitialiseConfig.xaml",
      "workflow": "InitialiseConfig",
      "activityType": "Assign",
      "propertyName": "To",
      "originalValue": "\"{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;str_ValidationErrors&quot;}\"",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.To> replaced with platform-safe value \"Nothing\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/InitialiseConfig.xaml",
      "workflow": "InitialiseConfig",
      "activityType": "Assign",
      "propertyName": "To",
      "originalValue": "\"{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;str_ValidationErrors&quot;}\"",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.To> replaced with platform-safe value \"Nothing\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/InitialiseConfig.xaml",
      "workflow": "InitialiseConfig",
      "activityType": "Assign",
      "propertyName": "To",
      "originalValue": "\"{&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;dict_Config(\\&quot;Coupa.BaseUrl\\&quot;)&quot;}\"",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.To> replaced with platform-safe value \"Nothing\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/InitialiseConfig.xaml",
      "workflow": "InitialiseConfig",
      "activityType": "Assign",
      "propertyName": "To",
      "originalValue": "\"{&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;dict_Config(\\&quot;Coupa.Polling.Enabled\\&quot;)&quot;}\"",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.To> replaced with platform-safe value \"Nothing\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/InitialiseConfig.xaml",
      "workflow": "InitialiseConfig",
      "activityType": "Assign",
      "propertyName": "To",
      "originalValue": "\"{&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;dict_Config(\\&quot;Coupa.Polling.LookbackMinutes\\&quot;)&quot;}\"",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.To> replaced with platform-safe value \"Nothing\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/InitialiseConfig.xaml",
      "workflow": "InitialiseConfig",
      "activityType": "Assign",
      "propertyName": "To",
      "originalValue": "\"{&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;dict_Config(\\&quot;Business.TolerancePercent\\&quot;)&quot;}\"",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.To> replaced with platform-safe value \"Nothing\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/InitialiseConfig.xaml",
      "workflow": "InitialiseConfig",
      "activityType": "Assign",
      "propertyName": "To",
      "originalValue": "\"{&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;dict_Config(\\&quot;Business.ToleranceBasis\\&quot;)&quot;}\"",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.To> replaced with platform-safe value \"Nothing\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/InitialiseConfig.xaml",
      "workflow": "InitialiseConfig",
      "activityType": "Assign",
      "propertyName": "To",
      "originalValue": "\"{&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;dict_Config(\\&quot;DU.ConfidenceThreshold\\&quot;)&quot;}\"",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.To> replaced with platform-safe value \"Nothing\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/InitialiseConfig.xaml",
      "workflow": "InitialiseConfig",
      "activityType": "Assign",
      "propertyName": "To",
      "originalValue": "\"{&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;dict_Config(\\&quot;ActionCenter.SLAHours\\&quot;)&quot;}\"",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.To> replaced with platform-safe value \"Nothing\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/InitialiseConfig.xaml",
      "workflow": "InitialiseConfig",
      "activityType": "Assign",
      "propertyName": "To",
      "originalValue": "\"{&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;dict_Config(\\&quot;Storage.RetentionDays\\&quot;)&quot;}\"",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.To> replaced with platform-safe value \"Nothing\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/InitialiseConfig.xaml",
      "workflow": "InitialiseConfig",
      "activityType": "Assign",
      "propertyName": "To",
      "originalValue": "\"{&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;dict_Config(\\&quot;Orchestrator.FolderName\\&quot;)&quot;}\"",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.To> replaced with platform-safe value \"Nothing\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/InitialiseConfig.xaml",
      "workflow": "InitialiseConfig",
      "activityType": "Assign",
      "propertyName": "Value",
      "originalValue": "[{&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;If(String.IsNullOrWhiteSpace(str_CoupaBaseUrl), str_ValidationErrors &amp; \\&quot;[MISSING] Coupa.BaseUrl is null or empty. \\&quot;",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.Value> replaced with platform-safe value \"\"\"\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/InitialiseConfig.xaml",
      "workflow": "InitialiseConfig",
      "activityType": "Assign",
      "propertyName": "Value",
      "originalValue": "[{&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;If(int_TolerancePercent &lt; 1 OrElse int_TolerancePercent &gt; 100, str_ValidationErrors &amp; \\&quot;[INVALID] Business.Tolerance",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.Value> replaced with platform-safe value \"\"\"\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/InitialiseConfig.xaml",
      "workflow": "InitialiseConfig",
      "activityType": "Assign",
      "propertyName": "Value",
      "originalValue": "[{&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;If(int_DuConfidenceThreshold &lt; 0 OrElse int_DuConfidenceThreshold &gt; 100, str_ValidationErrors &amp; \\&quot;[INVALID] DU.Confi",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.Value> replaced with platform-safe value \"\"\"\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/InitialiseConfig.xaml",
      "workflow": "InitialiseConfig",
      "activityType": "Assign",
      "propertyName": "Value",
      "originalValue": "[{&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;If(int_ActionCenterSlaHours &lt; 1, str_ValidationErrors &amp; \\&quot;[INVALID] ActionCenter.SLAHours must be &gt;= 1. Current: &ap",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.Value> replaced with platform-safe value \"\"\"\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/InitialiseConfig.xaml",
      "workflow": "InitialiseConfig",
      "activityType": "Assign",
      "propertyName": "Value",
      "originalValue": "[{&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;If(int_StorageRetentionDays &lt; 1, str_ValidationErrors &amp; \\&quot;[INVALID] Storage.RetentionDays must be &gt;= 1. Current: &ap",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.Value> replaced with platform-safe value \"\"\"\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/InitialiseConfig.xaml",
      "workflow": "InitialiseConfig",
      "activityType": "Assign",
      "propertyName": "Value",
      "originalValue": "[{&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;If(int_PollingLookbackMinutes &lt; 1, str_ValidationErrors &amp; \\&quot;[INVALID] Coupa.Polling.LookbackMinutes must be &gt;= 1. Cu",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.Value> replaced with platform-safe value \"\"\"\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/InitialiseConfig.xaml",
      "workflow": "InitialiseConfig",
      "activityType": "Assign",
      "propertyName": "Value",
      "originalValue": "[{&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;If(Not (str_ToleranceBasis = \\&quot;PO_TOTAL\\&quot; OrElse str_ToleranceBasis = \\&quot;PO_REMAINING\\&quot; OrElse str_ToleranceBasi",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.Value> replaced with platform-safe value \"\"\"\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/InitialiseConfig.xaml",
      "workflow": "InitialiseConfig",
      "activityType": "Assign",
      "propertyName": "Value",
      "originalValue": "[{&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;If(String.IsNullOrWhiteSpace(str_CoupaApiUsername), str_ValidationErrors &amp; \\&quot;[MISSING] Cred_Coupa_API username is null or ",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.Value> replaced with platform-safe value \"\"\"\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/InitialiseConfig.xaml",
      "workflow": "InitialiseConfig",
      "activityType": "Assign",
      "propertyName": "Value",
      "originalValue": "[{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;str_CoupaBaseUrl&quot;}]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.Value> replaced with platform-safe value \"\"\"\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/InitialiseConfig.xaml",
      "workflow": "InitialiseConfig",
      "activityType": "Assign",
      "propertyName": "Value",
      "originalValue": "[{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;bool_PollingEnabled&quot;}]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.Value> replaced with platform-safe value \"\"\"\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/InitialiseConfig.xaml",
      "workflow": "InitialiseConfig",
      "activityType": "Assign",
      "propertyName": "Value",
      "originalValue": "[{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;int_PollingLookbackMinutes&quot;}]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.Value> replaced with platform-safe value \"\"\"\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/InitialiseConfig.xaml",
      "workflow": "InitialiseConfig",
      "activityType": "Assign",
      "propertyName": "Value",
      "originalValue": "[{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;int_TolerancePercent&quot;}]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.Value> replaced with platform-safe value \"\"\"\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/InitialiseConfig.xaml",
      "workflow": "InitialiseConfig",
      "activityType": "Assign",
      "propertyName": "Value",
      "originalValue": "[{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;str_ToleranceBasis&quot;}]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.Value> replaced with platform-safe value \"\"\"\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/InitialiseConfig.xaml",
      "workflow": "InitialiseConfig",
      "activityType": "Assign",
      "propertyName": "Value",
      "originalValue": "[{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;int_DuConfidenceThreshold&quot;}]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.Value> replaced with platform-safe value \"\"\"\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/InitialiseConfig.xaml",
      "workflow": "InitialiseConfig",
      "activityType": "Assign",
      "propertyName": "Value",
      "originalValue": "[{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;int_ActionCenterSlaHours&quot;}]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.Value> replaced with platform-safe value \"\"\"\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/InitialiseConfig.xaml",
      "workflow": "InitialiseConfig",
      "activityType": "Assign",
      "propertyName": "Value",
      "originalValue": "[{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;int_StorageRetentionDays&quot;}]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.Value> replaced with platform-safe value \"\"\"\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/ProcessTransaction.xaml",
      "workflow": "ProcessTransaction",
      "activityType": "Assign",
      "propertyName": "To",
      "originalValue": "\"{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;pickedUpUtc&quot;}\"",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.To> replaced with platform-safe value \"Nothing\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/ProcessTransaction.xaml",
      "workflow": "ProcessTransaction",
      "activityType": "Assign",
      "propertyName": "To",
      "originalValue": "\"{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;confidenceThreshold&quot;}\"",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.To> replaced with platform-safe value \"Nothing\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/ProcessTransaction.xaml",
      "workflow": "ProcessTransaction",
      "activityType": "Assign",
      "propertyName": "To",
      "originalValue": "\"{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;localPdfPath&quot;}\"",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.To> replaced with platform-safe value \"Nothing\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/ProcessTransaction.xaml",
      "workflow": "ProcessTransaction",
      "activityType": "Assign",
      "propertyName": "To",
      "originalValue": "\"{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;finalCaseStatus&quot;}\"",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.To> replaced with platform-safe value \"Nothing\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/ProcessTransaction.xaml",
      "workflow": "ProcessTransaction",
      "activityType": "Assign",
      "propertyName": "To",
      "originalValue": "\"{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;TransactionOutcome&quot;}\"",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.To> replaced with platform-safe value \"Nothing\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/ProcessTransaction.xaml",
      "workflow": "ProcessTransaction",
      "activityType": "Assign",
      "propertyName": "To",
      "originalValue": "\"{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;finalCaseStatus&quot;}\"",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.To> replaced with platform-safe value \"Nothing\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/ProcessTransaction.xaml",
      "workflow": "ProcessTransaction",
      "activityType": "Assign",
      "propertyName": "To",
      "originalValue": "\"{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;rejectionReasonCode&quot;}\"",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.To> replaced with platform-safe value \"Nothing\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/ProcessTransaction.xaml",
      "workflow": "ProcessTransaction",
      "activityType": "Assign",
      "propertyName": "To",
      "originalValue": "\"{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;completedUtc&quot;}\"",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.To> replaced with platform-safe value \"Nothing\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/ProcessTransaction.xaml",
      "workflow": "ProcessTransaction",
      "activityType": "Assign",
      "propertyName": "Value",
      "originalValue": "[{&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;If(Config.ContainsKey(\\&quot;DU.ConfidenceThreshold\\&quot;), CInt(Config(\\&quot;DU.ConfidenceThreshold\\&quot;)), 85)&quot;}]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.Value> replaced with platform-safe value \"\"\"\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/ProcessTransaction.xaml",
      "workflow": "ProcessTransaction",
      "activityType": "Assign",
      "propertyName": "Value",
      "originalValue": "[{&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;If(String.IsNullOrEmpty(localPdfPath), System.IO.Path.Combine(System.IO.Path.GetTempPath(), CoupaInvoiceId &amp; \\&quot;.pdf\\&quot;",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.Value> replaced with platform-safe value \"\"\"\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/ProcessTransaction.xaml",
      "workflow": "ProcessTransaction",
      "activityType": "Assign",
      "propertyName": "Value",
      "originalValue": "[{&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;If(String.IsNullOrEmpty(validateAndDecideCaseStatus), \\&quot;FailedSystem\\&quot;, validateAndDecideCaseStatus)&quot;}]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.Value> replaced with platform-safe value \"\"\"\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/ProcessTransaction.xaml",
      "workflow": "ProcessTransaction",
      "activityType": "Assign",
      "propertyName": "Value",
      "originalValue": "[{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;validateAndDecideRejectionCode&quot;}]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.Value> replaced with platform-safe value \"\"\"\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/RetrieveInvoicePdf.xaml",
      "workflow": "RetrieveInvoicePdf",
      "activityType": "Assign",
      "propertyName": "To",
      "originalValue": "\"{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;candidateLocalPath&quot;}\"",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.To> replaced with platform-safe value \"Nothing\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/RetrieveInvoicePdf.xaml",
      "workflow": "RetrieveInvoicePdf",
      "activityType": "Assign",
      "propertyName": "To",
      "originalValue": "\"{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;bucketPathResolved&quot;}\"",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.To> replaced with platform-safe value \"Nothing\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/RetrieveInvoicePdf.xaml",
      "workflow": "RetrieveInvoicePdf",
      "activityType": "Assign",
      "propertyName": "To",
      "originalValue": "\"{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;downloadAttempt&quot;}\"",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.To> replaced with platform-safe value \"Nothing\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/RetrieveInvoicePdf.xaml",
      "workflow": "RetrieveInvoicePdf",
      "activityType": "Assign",
      "propertyName": "To",
      "originalValue": "\"{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;downloadSucceeded&quot;}\"",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.To> replaced with platform-safe value \"Nothing\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/RetrieveInvoicePdf.xaml",
      "workflow": "RetrieveInvoicePdf",
      "activityType": "Assign",
      "propertyName": "To",
      "originalValue": "\"{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;alternateTempSuffix&quot;}\"",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.To> replaced with platform-safe value \"Nothing\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/RetrieveInvoicePdf.xaml",
      "workflow": "RetrieveInvoicePdf",
      "activityType": "Assign",
      "propertyName": "To",
      "originalValue": "\"{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;fileSizeBytes&quot;}\"",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.To> replaced with platform-safe value \"Nothing\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/RetrieveInvoicePdf.xaml",
      "workflow": "RetrieveInvoicePdf",
      "activityType": "Assign",
      "propertyName": "To",
      "originalValue": "\"{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;LocalPdfPath&quot;}\"",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.To> replaced with platform-safe value \"Nothing\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/RetrieveInvoicePdf.xaml",
      "workflow": "RetrieveInvoicePdf",
      "activityType": "Assign",
      "propertyName": "To",
      "originalValue": "\"{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;PdfBucketPath&quot;}\"",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.To> replaced with platform-safe value \"Nothing\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/RetrieveInvoicePdf.xaml",
      "workflow": "RetrieveInvoicePdf",
      "activityType": "Assign",
      "propertyName": "Value",
      "originalValue": "[{&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;System.IO.Path.Combine(localTempFolder, CoupaInvoiceId &amp; \\&quot;_invoice.pdf\\&quot;)&quot;}]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.Value> replaced with platform-safe value \"\"\"\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/RetrieveInvoicePdf.xaml",
      "workflow": "RetrieveInvoicePdf",
      "activityType": "Assign",
      "propertyName": "Value",
      "originalValue": "[{&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;\\&quot;invoices/raw/\\&quot; &amp; CoupaInvoiceId &amp; \\&quot;.pdf\\&quot;&quot;}]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.Value> replaced with platform-safe value \"\"\"\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/RetrieveInvoicePdf.xaml",
      "workflow": "RetrieveInvoicePdf",
      "activityType": "Assign",
      "propertyName": "Value",
      "originalValue": "[{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;resolvedLocalPath&quot;}]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.Value> replaced with platform-safe value \"\"\"\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/RetrieveInvoicePdf.xaml",
      "workflow": "RetrieveInvoicePdf",
      "activityType": "Assign",
      "propertyName": "Value",
      "originalValue": "[{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;bucketPathResolved&quot;}]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.Value> replaced with platform-safe value \"\"\"\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/ExtractInvoiceFields.xaml",
      "workflow": "ExtractInvoiceFields",
      "activityType": "Assign",
      "propertyName": "To",
      "originalValue": "\"{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;confidenceThreshold&quot;}\"",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.To> replaced with platform-safe value \"Nothing\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/ExtractInvoiceFields.xaml",
      "workflow": "ExtractInvoiceFields",
      "activityType": "Assign",
      "propertyName": "To",
      "originalValue": "\"{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;confidenceThresholdFraction&quot;}\"",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.To> replaced with platform-safe value \"Nothing\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/ExtractInvoiceFields.xaml",
      "workflow": "ExtractInvoiceFields",
      "activityType": "Assign",
      "propertyName": "To",
      "originalValue": "\"{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;rawPoNumber&quot;}\"",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.To> replaced with platform-safe value \"Nothing\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/ExtractInvoiceFields.xaml",
      "workflow": "ExtractInvoiceFields",
      "activityType": "Assign",
      "propertyName": "To",
      "originalValue": "\"{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;rawInvoiceNumber&quot;}\"",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.To> replaced with platform-safe value \"Nothing\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/ExtractInvoiceFields.xaml",
      "workflow": "ExtractInvoiceFields",
      "activityType": "Assign",
      "propertyName": "To",
      "originalValue": "\"{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;rawVendorName&quot;}\"",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.To> replaced with platform-safe value \"Nothing\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/ExtractInvoiceFields.xaml",
      "workflow": "ExtractInvoiceFields",
      "activityType": "Assign",
      "propertyName": "To",
      "originalValue": "\"{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;rawInvoiceTotal&quot;}\"",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.To> replaced with platform-safe value \"Nothing\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/ExtractInvoiceFields.xaml",
      "workflow": "ExtractInvoiceFields",
      "activityType": "Assign",
      "propertyName": "To",
      "originalValue": "\"{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;rawCurrency&quot;}\"",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.To> replaced with platform-safe value \"Nothing\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/ExtractInvoiceFields.xaml",
      "workflow": "ExtractInvoiceFields",
      "activityType": "Assign",
      "propertyName": "To",
      "originalValue": "\"{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;rawInvoiceDate&quot;}\"",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.To> replaced with platform-safe value \"Nothing\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/ExtractInvoiceFields.xaml",
      "workflow": "ExtractInvoiceFields",
      "activityType": "Assign",
      "propertyName": "To",
      "originalValue": "\"{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;poNumberConfidenceDouble&quot;}\"",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.To> replaced with platform-safe value \"Nothing\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/ExtractInvoiceFields.xaml",
      "workflow": "ExtractInvoiceFields",
      "activityType": "Assign",
      "propertyName": "To",
      "originalValue": "\"{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;invoiceNumberConfidenceDouble&quot;}\"",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.To> replaced with platform-safe value \"Nothing\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/ExtractInvoiceFields.xaml",
      "workflow": "ExtractInvoiceFields",
      "activityType": "Assign",
      "propertyName": "To",
      "originalValue": "\"{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;vendorNameConfidence&quot;}\"",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.To> replaced with platform-safe value \"Nothing\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/ExtractInvoiceFields.xaml",
      "workflow": "ExtractInvoiceFields",
      "activityType": "Assign",
      "propertyName": "To",
      "originalValue": "\"{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;totalAmountConfidenceDouble&quot;}\"",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.To> replaced with platform-safe value \"Nothing\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/ExtractInvoiceFields.xaml",
      "workflow": "ExtractInvoiceFields",
      "activityType": "Assign",
      "propertyName": "To",
      "originalValue": "\"{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;fieldsBelowThreshold&quot;}\"",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.To> replaced with platform-safe value \"Nothing\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/ExtractInvoiceFields.xaml",
      "workflow": "ExtractInvoiceFields",
      "activityType": "Assign",
      "propertyName": "To",
      "originalValue": "\"{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;ExtractedPONumber&quot;}\"",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.To> replaced with platform-safe value \"Nothing\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/ExtractInvoiceFields.xaml",
      "workflow": "ExtractInvoiceFields",
      "activityType": "Assign",
      "propertyName": "To",
      "originalValue": "\"{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;ExtractedInvoiceNumber&quot;}\"",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.To> replaced with platform-safe value \"Nothing\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/ExtractInvoiceFields.xaml",
      "workflow": "ExtractInvoiceFields",
      "activityType": "Assign",
      "propertyName": "To",
      "originalValue": "\"{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;ExtractedVendorName&quot;}\"",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.To> replaced with platform-safe value \"Nothing\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/ExtractInvoiceFields.xaml",
      "workflow": "ExtractInvoiceFields",
      "activityType": "Assign",
      "propertyName": "To",
      "originalValue": "\"{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;ExtractedInvoiceTotal&quot;}\"",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.To> replaced with platform-safe value \"Nothing\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/ExtractInvoiceFields.xaml",
      "workflow": "ExtractInvoiceFields",
      "activityType": "Assign",
      "propertyName": "To",
      "originalValue": "\"{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;ExtractedCurrency&quot;}\"",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.To> replaced with platform-safe value \"Nothing\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/ExtractInvoiceFields.xaml",
      "workflow": "ExtractInvoiceFields",
      "activityType": "Assign",
      "propertyName": "To",
      "originalValue": "\"{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;ExtractionConfidence&quot;}\"",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.To> replaced with platform-safe value \"Nothing\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/ExtractInvoiceFields.xaml",
      "workflow": "ExtractInvoiceFields",
      "activityType": "Assign",
      "propertyName": "To",
      "originalValue": "\"{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;NeedsHumanValidation&quot;}\"",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.To> replaced with platform-safe value \"Nothing\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/ExtractInvoiceFields.xaml",
      "workflow": "ExtractInvoiceFields",
      "activityType": "Assign",
      "propertyName": "Value",
      "originalValue": "[{&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;CInt(Config(\\&quot;DU.ConfidenceThreshold\\&quot;))&quot;}]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.Value> replaced with platform-safe value \"\"\"\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/ExtractInvoiceFields.xaml",
      "workflow": "ExtractInvoiceFields",
      "activityType": "Assign",
      "propertyName": "Value",
      "originalValue": "[{&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;If(extractionResults IsNot Nothing AndAlso extractionResults.DataPoints.Exists(Function(dp) dp.FieldId = \\&quot;PONumber\\&quot;), e",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.Value> replaced with platform-safe value \"\"\"\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/ExtractInvoiceFields.xaml",
      "workflow": "ExtractInvoiceFields",
      "activityType": "Assign",
      "propertyName": "Value",
      "originalValue": "[{&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;If(extractionResults IsNot Nothing AndAlso extractionResults.DataPoints.Exists(Function(dp) dp.FieldId = \\&quot;InvoiceNumber\\&quot",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.Value> replaced with platform-safe value \"\"\"\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/ExtractInvoiceFields.xaml",
      "workflow": "ExtractInvoiceFields",
      "activityType": "Assign",
      "propertyName": "Value",
      "originalValue": "[{&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;If(extractionResults IsNot Nothing AndAlso extractionResults.DataPoints.Exists(Function(dp) dp.FieldId = \\&quot;VendorName\\&quot;),",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.Value> replaced with platform-safe value \"\"\"\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/ExtractInvoiceFields.xaml",
      "workflow": "ExtractInvoiceFields",
      "activityType": "Assign",
      "propertyName": "Value",
      "originalValue": "[{&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;If(extractionResults IsNot Nothing AndAlso extractionResults.DataPoints.Exists(Function(dp) dp.FieldId = \\&quot;TotalAmount\\&quot;)",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.Value> replaced with platform-safe value \"\"\"\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/ExtractInvoiceFields.xaml",
      "workflow": "ExtractInvoiceFields",
      "activityType": "Assign",
      "propertyName": "Value",
      "originalValue": "[{&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;If(extractionResults IsNot Nothing AndAlso extractionResults.DataPoints.Exists(Function(dp) dp.FieldId = \\&quot;Currency\\&quot;), e",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.Value> replaced with platform-safe value \"\"\"\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/ExtractInvoiceFields.xaml",
      "workflow": "ExtractInvoiceFields",
      "activityType": "Assign",
      "propertyName": "Value",
      "originalValue": "[{&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;If(extractionResults IsNot Nothing AndAlso extractionResults.DataPoints.Exists(Function(dp) dp.FieldId = \\&quot;InvoiceDate\\&quot;)",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.Value> replaced with platform-safe value \"\"\"\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/ExtractInvoiceFields.xaml",
      "workflow": "ExtractInvoiceFields",
      "activityType": "Assign",
      "propertyName": "Value",
      "originalValue": "[{&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;If(extractionResults IsNot Nothing AndAlso extractionResults.DataPoints.Exists(Function(dp) dp.FieldId = \\&quot;PONumber\\&quot;), C",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.Value> replaced with platform-safe value \"\"\"\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/ExtractInvoiceFields.xaml",
      "workflow": "ExtractInvoiceFields",
      "activityType": "Assign",
      "propertyName": "Value",
      "originalValue": "[{&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;If(extractionResults IsNot Nothing AndAlso extractionResults.DataPoints.Exists(Function(dp) dp.FieldId = \\&quot;InvoiceNumber\\&quot",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.Value> replaced with platform-safe value \"\"\"\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/ExtractInvoiceFields.xaml",
      "workflow": "ExtractInvoiceFields",
      "activityType": "Assign",
      "propertyName": "Value",
      "originalValue": "[{&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;If(extractionResults IsNot Nothing AndAlso extractionResults.DataPoints.Exists(Function(dp) dp.FieldId = \\&quot;VendorName\\&quot;),",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.Value> replaced with platform-safe value \"\"\"\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/ExtractInvoiceFields.xaml",
      "workflow": "ExtractInvoiceFields",
      "activityType": "Assign",
      "propertyName": "Value",
      "originalValue": "[{&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;If(extractionResults IsNot Nothing AndAlso extractionResults.DataPoints.Exists(Function(dp) dp.FieldId = \\&quot;TotalAmount\\&quot;)",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.Value> replaced with platform-safe value \"\"\"\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/ExtractInvoiceFields.xaml",
      "workflow": "ExtractInvoiceFields",
      "activityType": "Assign",
      "propertyName": "Value",
      "originalValue": "[{&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;CDbl(poNumberConfidenceDouble) &lt; CDbl(confidenceThresholdFraction) OrElse CDbl(invoiceNumberConfidenceDouble) &lt; CDbl(confiden",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.Value> replaced with platform-safe value \"\"\"\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/ExtractInvoiceFields.xaml",
      "workflow": "ExtractInvoiceFields",
      "activityType": "Assign",
      "propertyName": "Value",
      "originalValue": "[{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;rawPoNumber&quot;}]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.Value> replaced with platform-safe value \"\"\"\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/ExtractInvoiceFields.xaml",
      "workflow": "ExtractInvoiceFields",
      "activityType": "Assign",
      "propertyName": "Value",
      "originalValue": "[{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;rawInvoiceNumber&quot;}]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.Value> replaced with platform-safe value \"\"\"\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/ExtractInvoiceFields.xaml",
      "workflow": "ExtractInvoiceFields",
      "activityType": "Assign",
      "propertyName": "Value",
      "originalValue": "[{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;rawVendorName&quot;}]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.Value> replaced with platform-safe value \"\"\"\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/ExtractInvoiceFields.xaml",
      "workflow": "ExtractInvoiceFields",
      "activityType": "Assign",
      "propertyName": "Value",
      "originalValue": "[{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;rawInvoiceTotal&quot;}]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.Value> replaced with platform-safe value \"\"\"\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/ExtractInvoiceFields.xaml",
      "workflow": "ExtractInvoiceFields",
      "activityType": "Assign",
      "propertyName": "Value",
      "originalValue": "[{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;rawCurrency&quot;}]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.Value> replaced with platform-safe value \"\"\"\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/ExtractInvoiceFields.xaml",
      "workflow": "ExtractInvoiceFields",
      "activityType": "Assign",
      "propertyName": "Value",
      "originalValue": "[{&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;Math.Min(Math.Min(CDbl(poNumberConfidenceDouble), CDbl(invoiceNumberConfidenceDouble)), Math.Min(CDbl(totalAmountConfidenceDouble),",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.Value> replaced with platform-safe value \"\"\"\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/ExtractInvoiceFields.xaml",
      "workflow": "ExtractInvoiceFields",
      "activityType": "Assign",
      "propertyName": "Value",
      "originalValue": "[{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;fieldsBelowThreshold&quot;}]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.Value> replaced with platform-safe value \"\"\"\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/CreateValidationTask.xaml",
      "workflow": "CreateValidationTask",
      "activityType": "Assign",
      "propertyName": "To",
      "originalValue": "\"{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;slaHours&quot;}\"",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.To> replaced with platform-safe value \"Nothing\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/CreateValidationTask.xaml",
      "workflow": "CreateValidationTask",
      "activityType": "Assign",
      "propertyName": "To",
      "originalValue": "\"{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;taskDueUtc&quot;}\"",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.To> replaced with platform-safe value \"Nothing\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/CreateValidationTask.xaml",
      "workflow": "CreateValidationTask",
      "activityType": "Assign",
      "propertyName": "To",
      "originalValue": "\"{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;taskTitle&quot;}\"",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.To> replaced with platform-safe value \"Nothing\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/CreateValidationTask.xaml",
      "workflow": "CreateValidationTask",
      "activityType": "Assign",
      "propertyName": "To",
      "originalValue": "\"{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;invoiceCaseId&quot;}\"",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.To> replaced with platform-safe value \"Nothing\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/CreateValidationTask.xaml",
      "workflow": "CreateValidationTask",
      "activityType": "Assign",
      "propertyName": "To",
      "originalValue": "\"{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;formData&quot;}\"",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.To> replaced with platform-safe value \"Nothing\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/CreateValidationTask.xaml",
      "workflow": "CreateValidationTask",
      "activityType": "Assign",
      "propertyName": "To",
      "originalValue": "\"{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;taskExternalData&quot;}\"",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.To> replaced with platform-safe value \"Nothing\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/CreateValidationTask.xaml",
      "workflow": "CreateValidationTask",
      "activityType": "Assign",
      "propertyName": "To",
      "originalValue": "\"{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;ActionCenterTaskId&quot;}\"",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.To> replaced with platform-safe value \"Nothing\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/CreateValidationTask.xaml",
      "workflow": "CreateValidationTask",
      "activityType": "Assign",
      "propertyName": "Value",
      "originalValue": "[{&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;\\&quot;[Invoice Validation] \\&quot; &amp; CoupaInvoiceId &amp; \\&quot; — \\&quot; &amp; VendorName&quot;}]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.Value> replaced with platform-safe value \"\"\"\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/CreateValidationTask.xaml",
      "workflow": "CreateValidationTask",
      "activityType": "Assign",
      "propertyName": "Value",
      "originalValue": "[{&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;If(queriedCases IsNot Nothing AndAlso DirectCast(queriedCases, System.Collections.IList).Count &gt; 0, CStr(DirectCast(DirectCast(q",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.Value> replaced with platform-safe value \"\"\"\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/CreateValidationTask.xaml",
      "workflow": "CreateValidationTask",
      "activityType": "Assign",
      "propertyName": "Value",
      "originalValue": "[{&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;New Dictionary(Of String, Object) From {{\\&quot;CoupaInvoiceId\\&quot;, CoupaInvoiceId}, {\\&quot;VendorName\\&quot;, VendorName}, {\\&",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.Value> replaced with platform-safe value \"\"\"\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/CreateValidationTask.xaml",
      "workflow": "CreateValidationTask",
      "activityType": "Assign",
      "propertyName": "Value",
      "originalValue": "[{&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;New Dictionary(Of String, Object) From {{\\&quot;InvoiceCaseId\\&quot;, invoiceCaseId}, {\\&quot;CoupaInvoiceId\\&quot;, CoupaInvoiceId",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.Value> replaced with platform-safe value \"\"\"\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/CreateValidationTask.xaml",
      "workflow": "CreateValidationTask",
      "activityType": "Assign",
      "propertyName": "Value",
      "originalValue": "[{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;createdTaskId&quot;}]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.Value> replaced with platform-safe value \"\"\"\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/ValidateAndDecide.xaml",
      "workflow": "ValidateAndDecide",
      "activityType": "Assign",
      "propertyName": "To",
      "originalValue": "\"{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;coupaBaseUrl&quot;}\"",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.To> replaced with platform-safe value \"Nothing\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/ValidateAndDecide.xaml",
      "workflow": "ValidateAndDecide",
      "activityType": "Assign",
      "propertyName": "To",
      "originalValue": "\"{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;tolerancePercent&quot;}\"",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.To> replaced with platform-safe value \"Nothing\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/ValidateAndDecide.xaml",
      "workflow": "ValidateAndDecide",
      "activityType": "Assign",
      "propertyName": "To",
      "originalValue": "\"{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;toleranceBasis&quot;}\"",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.To> replaced with platform-safe value \"Nothing\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/ValidateAndDecide.xaml",
      "workflow": "ValidateAndDecide",
      "activityType": "Assign",
      "propertyName": "To",
      "originalValue": "\"{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;invoiceTotalDecimal&quot;}\"",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.To> replaced with platform-safe value \"Nothing\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/ValidateAndDecide.xaml",
      "workflow": "ValidateAndDecide",
      "activityType": "Assign",
      "propertyName": "To",
      "originalValue": "\"{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;poLookupUrl&quot;}\"",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.To> replaced with platform-safe value \"Nothing\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/ValidateAndDecide.xaml",
      "workflow": "ValidateAndDecide",
      "activityType": "Assign",
      "propertyName": "To",
      "originalValue": "\"{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;poFound&quot;}\"",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.To> replaced with platform-safe value \"Nothing\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/ValidateAndDecide.xaml",
      "workflow": "ValidateAndDecide",
      "activityType": "Assign",
      "propertyName": "To",
      "originalValue": "\"{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;rejectUrl&quot;}\"",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.To> replaced with platform-safe value \"Nothing\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/ValidateAndDecide.xaml",
      "workflow": "ValidateAndDecide",
      "activityType": "Assign",
      "propertyName": "To",
      "originalValue": "\"{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;rejectPayload&quot;}\"",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.To> replaced with platform-safe value \"Nothing\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/ValidateAndDecide.xaml",
      "workflow": "ValidateAndDecide",
      "activityType": "Assign",
      "propertyName": "To",
      "originalValue": "\"{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;invoiceCaseId&quot;}\"",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.To> replaced with platform-safe value \"Nothing\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/ValidateAndDecide.xaml",
      "workflow": "ValidateAndDecide",
      "activityType": "Assign",
      "propertyName": "To",
      "originalValue": "\"{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;FinalCaseStatus&quot;}\"",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.To> replaced with platform-safe value \"Nothing\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/ValidateAndDecide.xaml",
      "workflow": "ValidateAndDecide",
      "activityType": "Assign",
      "propertyName": "To",
      "originalValue": "\"{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;RejectionReasonCode&quot;}\"",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.To> replaced with platform-safe value \"Nothing\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/ValidateAndDecide.xaml",
      "workflow": "ValidateAndDecide",
      "activityType": "Assign",
      "propertyName": "To",
      "originalValue": "\"{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;CoupaActionResult&quot;}\"",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.To> replaced with platform-safe value \"Nothing\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/ValidateAndDecide.xaml",
      "workflow": "ValidateAndDecide",
      "activityType": "Assign",
      "propertyName": "To",
      "originalValue": "\"{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;poTotalAmount&quot;}\"",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.To> replaced with platform-safe value \"Nothing\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/ValidateAndDecide.xaml",
      "workflow": "ValidateAndDecide",
      "activityType": "Assign",
      "propertyName": "To",
      "originalValue": "\"{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;poRemainingAmount&quot;}\"",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.To> replaced with platform-safe value \"Nothing\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/ValidateAndDecide.xaml",
      "workflow": "ValidateAndDecide",
      "activityType": "Assign",
      "propertyName": "To",
      "originalValue": "\"{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;referenceAmount&quot;}\"",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.To> replaced with platform-safe value \"Nothing\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/ValidateAndDecide.xaml",
      "workflow": "ValidateAndDecide",
      "activityType": "Assign",
      "propertyName": "To",
      "originalValue": "\"{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;referenceAmount&quot;}\"",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.To> replaced with platform-safe value \"Nothing\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/ValidateAndDecide.xaml",
      "workflow": "ValidateAndDecide",
      "activityType": "Assign",
      "propertyName": "To",
      "originalValue": "\"{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;toleranceVariance&quot;}\"",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "Nothing",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.To> replaced with platform-safe value \"Nothing\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/ValidateAndDecide.xaml",
      "workflow": "ValidateAndDecide",
      "activityType": "Assign",
      "propertyName": "Value",
      "originalValue": "[{&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;If(Config.ContainsKey(\\&quot;Coupa.BaseUrl\\&quot;), CStr(Config(\\&quot;Coupa.BaseUrl\\&quot;)), \\&quot;\\&quot;)&quot;}]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.Value> replaced with platform-safe value \"\"\"\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/ValidateAndDecide.xaml",
      "workflow": "ValidateAndDecide",
      "activityType": "Assign",
      "propertyName": "Value",
      "originalValue": "[{&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;If(Config.ContainsKey(\\&quot;Business.TolerancePercent\\&quot;), CInt(Config(\\&quot;Business.TolerancePercent\\&quot;)), 5)&quot;}]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.Value> replaced with platform-safe value \"\"\"\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/ValidateAndDecide.xaml",
      "workflow": "ValidateAndDecide",
      "activityType": "Assign",
      "propertyName": "Value",
      "originalValue": "[{&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;If(Config.ContainsKey(\\&quot;Business.ToleranceBasis\\&quot;), CStr(Config(\\&quot;Business.ToleranceBasis\\&quot;)), \\&quot;PO_TOTAL\\",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.Value> replaced with platform-safe value \"\"\"\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/ValidateAndDecide.xaml",
      "workflow": "ValidateAndDecide",
      "activityType": "Assign",
      "propertyName": "Value",
      "originalValue": "[{&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;coupaBaseUrl.TrimEnd(\\&quot;/\\&quot;c) &amp; \\&quot;/api/purchase_orders?po_number=\\&quot; &amp; System.Net.WebUtility.UrlEncode(PO",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.Value> replaced with platform-safe value \"\"\"\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/ValidateAndDecide.xaml",
      "workflow": "ValidateAndDecide",
      "activityType": "Assign",
      "propertyName": "Value",
      "originalValue": "[{&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;poLookupResponse IsNot Nothing AndAlso CType(poLookupResponse, Newtonsoft.Json.Linq.JArray).Count &gt; 0&quot;}]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.Value> replaced with platform-safe value \"\"\"\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/ValidateAndDecide.xaml",
      "workflow": "ValidateAndDecide",
      "activityType": "Assign",
      "propertyName": "Value",
      "originalValue": "[{&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;coupaBaseUrl.TrimEnd(\\&quot;/\\&quot;c) &amp; \\&quot;/api/invoices/\\&quot; &amp; CoupaInvoiceId &amp; \\&quot;/reject\\&quot;&quot;}]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.Value> replaced with platform-safe value \"\"\"\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/ValidateAndDecide.xaml",
      "workflow": "ValidateAndDecide",
      "activityType": "Assign",
      "propertyName": "Value",
      "originalValue": "[{&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;\\&quot;{\\&quot;\\&quot;rejection_reason\\&quot;\\&quot;: \\&quot;\\&quot;PO_MISMATCH_OR_NOT_FOUND\\&quot;\\&quot;, \\&quot;\\&quot;comments\\",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.Value> replaced with platform-safe value \"\"\"\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/ValidateAndDecide.xaml",
      "workflow": "ValidateAndDecide",
      "activityType": "Assign",
      "propertyName": "Value",
      "originalValue": "[{&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;If(invoiceCaseQueryResult IsNot Nothing, CStr(invoiceCaseQueryResult(0)(\\&quot;Id\\&quot;)), \\&quot;\\&quot;)&quot;}]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.Value> replaced with platform-safe value \"\"\"\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/ValidateAndDecide.xaml",
      "workflow": "ValidateAndDecide",
      "activityType": "Assign",
      "propertyName": "Value",
      "originalValue": "[{&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;\\&quot;Rejected in Coupa: PO_MISMATCH_OR_NOT_FOUND | Response=\\&quot; &amp; CStr(coupaRejectResponse)&quot;}]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.Value> replaced with platform-safe value \"\"\"\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/ValidateAndDecide.xaml",
      "workflow": "ValidateAndDecide",
      "activityType": "Assign",
      "propertyName": "Value",
      "originalValue": "[{&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;CDec(CType(poLookupResponse, Newtonsoft.Json.Linq.JArray)(0)(\\&quot;total\\&quot;).ToString())&quot;}]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.Value> replaced with platform-safe value \"\"\"\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/ValidateAndDecide.xaml",
      "workflow": "ValidateAndDecide",
      "activityType": "Assign",
      "propertyName": "Value",
      "originalValue": "[{&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;CDec(CType(poLookupResponse, Newtonsoft.Json.Linq.JArray)(0)(\\&quot;amount_remaining\\&quot;).ToString())&quot;}]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.Value> replaced with platform-safe value \"\"\"\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/ValidateAndDecide.xaml",
      "workflow": "ValidateAndDecide",
      "activityType": "Assign",
      "propertyName": "Value",
      "originalValue": "[{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;poRemainingAmount&quot;}]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.Value> replaced with platform-safe value \"\"\"\" — non-deterministic canonicalization, degradation substitute"
    },
    {
      "file": "lib/net45/ValidateAndDecide.xaml",
      "workflow": "ValidateAndDecide",
      "activityType": "Assign",
      "propertyName": "Value",
      "originalValue": "[{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;poTotalAmount&quot;}]",
      "replacementType": "degradation_substitute",
      "safeReplacementValue": "\"\"",
      "originalDefectClass": "unresolvable_json_payload",
      "severity": "execution_blocking",
      "rationale": "Unresolvable JSON payload in <Assign.Value> replaced with platform-safe value \"\"\"\" — non-deterministic canonicalization, degradation substitute"
    }
  ],
  "requiredPropertyBindings": [
    {
      "file": "Main.xaml",
      "workflow": "Main",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;=== Starting: Main ===&quot;]",
      "resolvedValue": "[&quot;=== Starting: Main ===&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;=== Starting: Main ===&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "Main.xaml",
      "workflow": "Main",
      "activityType": "InvokeWorkflowFile",
      "propertyName": "WorkflowFileName",
      "sourceBinding": "attribute-value",
      "originalValue": "InitialiseConfig.xaml",
      "resolvedValue": "InitialiseConfig.xaml",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "InitialiseConfig.xaml",
        "precedenceTier": 4
      }
    },
    {
      "file": "Main.xaml",
      "workflow": "Main",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot captured for error diagnostics&quot;]",
      "resolvedValue": "[&quot;Screenshot captured for error diagnostics&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 2,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot captured for error diagnostics&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "Main.xaml",
      "workflow": "Main",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
      "resolvedValue": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 3,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
        "precedenceTier": 4
      }
    },
    {
      "file": "Main.xaml",
      "workflow": "Main",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;[Error] Initialise configuration from Orchestrator Assets via InitialiseConfig failed (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "resolvedValue": "[&quot;[Error] Initialise configuration from Orchestrator Assets via InitialiseConfig failed (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 4,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;[Error] Initialise configuration from Orchestrator Assets via InitialiseC",
        "precedenceTier": 4
      }
    },
    {
      "file": "Main.xaml",
      "workflow": "Main",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "[True]",
      "resolvedValue": "[True]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[True]",
        "precedenceTier": 4
      }
    },
    {
      "file": "Main.xaml",
      "workflow": "Main",
      "activityType": "If",
      "propertyName": "Condition",
      "sourceBinding": "attribute-value",
      "originalValue": "[{&quot;type&quot;:&quot;expression&quot;,&quot;left&quot;:&quot;initSuccess&quot;,&quot;operator&quot;:&quot;=&quot;,&quot;right&quot;:&quot;False&quot;}]",
      "resolvedValue": "[{&quot;type&quot;:&quot;expression&quot;,&quot;left&quot;:&quot;initSuccess&quot;,&quot;operator&quot;:&quot;=&quot;,&quot;right&quot;:&quot;False&quot;}]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[{&quot;type&quot;:&quot;expression&quot;,&quot;left&quot;:&quot;initSuccess&quo",
        "precedenceTier": 4
      }
    },
    {
      "file": "Main.xaml",
      "workflow": "Main",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Then path: Guard: abort if Init failed — check initSuccess before entering loop&quot;]",
      "resolvedValue": "[&quot;Then path: Guard: abort if Init failed — check initSuccess before entering loop&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 6,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Then path: Guard: abort if Init failed — check initSuccess before enterin",
        "precedenceTier": 4
      }
    },
    {
      "file": "Main.xaml",
      "workflow": "Main",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Else path: Guard: abort if Init failed — check initSuccess before entering loop&quot;]",
      "resolvedValue": "[&quot;Else path: Guard: abort if Init failed — check initSuccess before entering loop&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 7,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Else path: Guard: abort if Init failed — check initSuccess before enterin",
        "precedenceTier": 4
      }
    },
    {
      "file": "Main.xaml",
      "workflow": "Main",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot captured for error diagnostics&quot;]",
      "resolvedValue": "[&quot;Screenshot captured for error diagnostics&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 9,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot captured for error diagnostics&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "Main.xaml",
      "workflow": "Main",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
      "resolvedValue": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 10,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
        "precedenceTier": 4
      }
    },
    {
      "file": "Main.xaml",
      "workflow": "Main",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;[Error] Get next transaction item from Q_Coupa_InvoiceReconciliation failed (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "resolvedValue": "[&quot;[Error] Get next transaction item from Q_Coupa_InvoiceReconciliation failed (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 11,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;[Error] Get next transaction item from Q_Coupa_InvoiceReconciliation fail",
        "precedenceTier": 4
      }
    },
    {
      "file": "Main.xaml",
      "workflow": "Main",
      "activityType": "If",
      "propertyName": "Condition",
      "sourceBinding": "attribute-value",
      "originalValue": "[{&quot;type&quot;:&quot;expression&quot;,&quot;left&quot;:&quot;transactionItem&quot;,&quot;operator&quot;:&quot;Is&quot;,&quot;right&quot;:&quot;Nothing&quot;}]",
      "resolvedValue": "[{&quot;type&quot;:&quot;expression&quot;,&quot;left&quot;:&quot;transactionItem&quot;,&quot;operator&quot;:&quot;Is&quot;,&quot;right&quot;:&quot;Nothing&quot;}]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 1,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[{&quot;type&quot;:&quot;expression&quot;,&quot;left&quot;:&quot;transactionItem",
        "precedenceTier": 4
      }
    },
    {
      "file": "Main.xaml",
      "workflow": "Main",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Then path: Exit loop if no transaction item returned (queue empty or all items in progress)&quot;]",
      "resolvedValue": "[&quot;Then path: Exit loop if no transaction item returned (queue empty or all items in progress)&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 12,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Then path: Exit loop if no transaction item returned (queue empty or all ",
        "precedenceTier": 4
      }
    },
    {
      "file": "Main.xaml",
      "workflow": "Main",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Else path: Exit loop if no transaction item returned (queue empty or all items in progress)&quot;]",
      "resolvedValue": "[&quot;Else path: Exit loop if no transaction item returned (queue empty or all items in progress)&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 13,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Else path: Exit loop if no transaction item returned (queue empty or all ",
        "precedenceTier": 4
      }
    },
    {
      "file": "Main.xaml",
      "workflow": "Main",
      "activityType": "InvokeWorkflowFile",
      "propertyName": "WorkflowFileName",
      "sourceBinding": "attribute-value",
      "originalValue": "ProcessTransaction.xaml",
      "resolvedValue": "ProcessTransaction.xaml",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 1,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "ProcessTransaction.xaml",
        "precedenceTier": 4
      }
    },
    {
      "file": "Main.xaml",
      "workflow": "Main",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot captured for error diagnostics&quot;]",
      "resolvedValue": "[&quot;Screenshot captured for error diagnostics&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 16,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot captured for error diagnostics&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "Main.xaml",
      "workflow": "Main",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
      "resolvedValue": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 17,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
        "precedenceTier": 4
      }
    },
    {
      "file": "Main.xaml",
      "workflow": "Main",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;[Error] Invoke ProcessTransaction to handle full invoice reconciliation lifecycle failed (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "resolvedValue": "[&quot;[Error] Invoke ProcessTransaction to handle full invoice reconciliation lifecycle failed (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 18,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;[Error] Invoke ProcessTransaction to handle full invoice reconciliation l",
        "precedenceTier": 4
      }
    },
    {
      "file": "Main.xaml",
      "workflow": "Main",
      "activityType": "If",
      "propertyName": "Condition",
      "sourceBinding": "attribute-value",
      "originalValue": "[{&quot;type&quot;:&quot;expression&quot;,&quot;left&quot;:&quot;isBusinessException&quot;,&quot;operator&quot;:&quot;=&quot;,&quot;right&quot;:&quot;True&quot;}]",
      "resolvedValue": "[{&quot;type&quot;:&quot;expression&quot;,&quot;left&quot;:&quot;isBusinessException&quot;,&quot;operator&quot;:&quot;=&quot;,&quot;right&quot;:&quot;True&quot;}]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 2,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[{&quot;type&quot;:&quot;expression&quot;,&quot;left&quot;:&quot;isBusinessExcep",
        "precedenceTier": 4
      }
    },
    {
      "file": "Main.xaml",
      "workflow": "Main",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Then path: Branch on exception type to set correct queue transaction status&quot;]",
      "resolvedValue": "[&quot;Then path: Branch on exception type to set correct queue transaction status&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 20,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Then path: Branch on exception type to set correct queue transaction stat",
        "precedenceTier": 4
      }
    },
    {
      "file": "Main.xaml",
      "workflow": "Main",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Else path: Branch on exception type to set correct queue transaction status&quot;]",
      "resolvedValue": "[&quot;Else path: Branch on exception type to set correct queue transaction status&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 21,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Else path: Branch on exception type to set correct queue transaction stat",
        "precedenceTier": 4
      }
    },
    {
      "file": "Main.xaml",
      "workflow": "Main",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot captured for error diagnostics&quot;]",
      "resolvedValue": "[&quot;Screenshot captured for error diagnostics&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 22,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot captured for error diagnostics&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "Main.xaml",
      "workflow": "Main",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
      "resolvedValue": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 23,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
        "precedenceTier": 4
      }
    },
    {
      "file": "Main.xaml",
      "workflow": "Main",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;[Error] Set queue item Successful for business rule rejection (clean outcome) failed (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "resolvedValue": "[&quot;[Error] Set queue item Successful for business rule rejection (clean outcome) failed (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 24,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;[Error] Set queue item Successful for business rule rejection (clean outc",
        "precedenceTier": 4
      }
    },
    {
      "file": "Main.xaml",
      "workflow": "Main",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "\"\"",
      "resolvedValue": "\"\"",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 1,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "\"\"",
        "precedenceTier": 4
      }
    },
    {
      "file": "Main.xaml",
      "workflow": "Main",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot captured for error diagnostics&quot;]",
      "resolvedValue": "[&quot;Screenshot captured for error diagnostics&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 25,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot captured for error diagnostics&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "Main.xaml",
      "workflow": "Main",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
      "resolvedValue": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 26,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
        "precedenceTier": 4
      }
    },
    {
      "file": "Main.xaml",
      "workflow": "Main",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;[Error] Set queue item Failed for system exception (triggers queue retry) failed (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "resolvedValue": "[&quot;[Error] Set queue item Failed for system exception (triggers queue retry) failed (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 27,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;[Error] Set queue item Failed for system exception (triggers queue retry)",
        "precedenceTier": 4
      }
    },
    {
      "file": "Main.xaml",
      "workflow": "Main",
      "activityType": "If",
      "propertyName": "Condition",
      "sourceBinding": "attribute-value",
      "originalValue": "[{&quot;type&quot;:&quot;expression&quot;,&quot;left&quot;:&quot;consecutiveSystemExceptions&quot;,&quot;operator&quot;:&quot;&gt;=&quot;,&quot;right&quot;:&quot;maxConsecutiveSystemExceptions&quot;}]",
      "resolvedValue": "[{&quot;type&quot;:&quot;expression&quot;,&quot;left&quot;:&quot;consecutiveSystemExceptions&quot;,&quot;operator&quot;:&quot;&gt;=&quot;,&quot;right&quot;:&quot;maxConsecutiveSystemExceptions&quot;}]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 3,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[{&quot;type&quot;:&quot;expression&quot;,&quot;left&quot;:&quot;consecutiveSyst",
        "precedenceTier": 4
      }
    },
    {
      "file": "Main.xaml",
      "workflow": "Main",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Then path: Check if consecutive system exception threshold exceeded — abort loop if so&quot;]",
      "resolvedValue": "[&quot;Then path: Check if consecutive system exception threshold exceeded — abort loop if so&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 29,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Then path: Check if consecutive system exception threshold exceeded — abo",
        "precedenceTier": 4
      }
    },
    {
      "file": "Main.xaml",
      "workflow": "Main",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Else path: Check if consecutive system exception threshold exceeded — abort loop if so&quot;]",
      "resolvedValue": "[&quot;Else path: Check if consecutive system exception threshold exceeded — abort loop if so&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 30,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Else path: Check if consecutive system exception threshold exceeded — abo",
        "precedenceTier": 4
      }
    },
    {
      "file": "Main.xaml",
      "workflow": "Main",
      "activityType": "If",
      "propertyName": "Condition",
      "sourceBinding": "attribute-value",
      "originalValue": "[{&quot;type&quot;:&quot;expression&quot;,&quot;left&quot;:&quot;isBusinessException&quot;,&quot;operator&quot;:&quot;OrElse&quot;,&quot;right&quot;:&quot;transactionStatus&quot;}]",
      "resolvedValue": "[{&quot;type&quot;:&quot;expression&quot;,&quot;left&quot;:&quot;isBusinessException&quot;,&quot;operator&quot;:&quot;OrElse&quot;,&quot;right&quot;:&quot;transactionStatus&quot;}]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 4,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[{&quot;type&quot;:&quot;expression&quot;,&quot;left&quot;:&quot;isBusinessExcep",
        "precedenceTier": 4
      }
    },
    {
      "file": "Main.xaml",
      "workflow": "Main",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Then path: Reset consecutive exception counter on successful transaction (business or clean)&quot;]",
      "resolvedValue": "[&quot;Then path: Reset consecutive exception counter on successful transaction (business or clean)&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 32,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Then path: Reset consecutive exception counter on successful transaction ",
        "precedenceTier": 4
      }
    },
    {
      "file": "Main.xaml",
      "workflow": "Main",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Else path: Reset consecutive exception counter on successful transaction (business or clean)&quot;]",
      "resolvedValue": "[&quot;Else path: Reset consecutive exception counter on successful transaction (business or clean)&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 33,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Else path: Reset consecutive exception counter on successful transaction ",
        "precedenceTier": 4
      }
    },
    {
      "file": "Main.xaml",
      "workflow": "Main",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "\"\"",
      "resolvedValue": "\"\"",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 2,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "\"\"",
        "precedenceTier": 4
      }
    },
    {
      "file": "Main.xaml",
      "workflow": "Main",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "[DateTime.UtcNow]",
      "resolvedValue": "[DateTime.UtcNow]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 3,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[DateTime.UtcNow]",
        "precedenceTier": 4
      }
    },
    {
      "file": "Main.xaml",
      "workflow": "Main",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;=== Completed: Main ===&quot;]",
      "resolvedValue": "[&quot;=== Completed: Main ===&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 36,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;=== Completed: Main ===&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "Dispatcher.xaml",
      "workflow": "Dispatcher",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;=== Starting: Dispatcher ===&quot;]",
      "resolvedValue": "[&quot;=== Starting: Dispatcher ===&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;=== Starting: Dispatcher ===&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "Dispatcher.xaml",
      "workflow": "Dispatcher",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[Dispatcher] Starting CoupaInvoiceRecon Dispatcher. Initialising configuration from Orchestrator Assets.",
      "resolvedValue": "[Dispatcher] Starting CoupaInvoiceRecon Dispatcher. Initialising configuration from Orchestrator Assets.",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 1,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[Dispatcher] Starting CoupaInvoiceRecon Dispatcher. Initialising configuration f",
        "precedenceTier": 4
      }
    },
    {
      "file": "Dispatcher.xaml",
      "workflow": "Dispatcher",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "\"\"",
      "resolvedValue": "\"\"",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "\"\"",
        "precedenceTier": 4
      }
    },
    {
      "file": "Dispatcher.xaml",
      "workflow": "Dispatcher",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot captured for error diagnostics&quot;]",
      "resolvedValue": "[&quot;Screenshot captured for error diagnostics&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 2,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot captured for error diagnostics&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "Dispatcher.xaml",
      "workflow": "Dispatcher",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
      "resolvedValue": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 3,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
        "precedenceTier": 4
      }
    },
    {
      "file": "Dispatcher.xaml",
      "workflow": "Dispatcher",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;[Error] Read Coupa.BaseUrl asset failed (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "resolvedValue": "[&quot;[Error] Read Coupa.BaseUrl asset failed (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 4,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;[Error] Read Coupa.BaseUrl asset failed (&quot; &amp; exception.GetType()",
        "precedenceTier": 4
      }
    },
    {
      "file": "Dispatcher.xaml",
      "workflow": "Dispatcher",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot captured for error diagnostics&quot;]",
      "resolvedValue": "[&quot;Screenshot captured for error diagnostics&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 5,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot captured for error diagnostics&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "Dispatcher.xaml",
      "workflow": "Dispatcher",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
      "resolvedValue": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 6,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
        "precedenceTier": 4
      }
    },
    {
      "file": "Dispatcher.xaml",
      "workflow": "Dispatcher",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;[Error] Read Coupa.Polling.Enabled asset failed (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "resolvedValue": "[&quot;[Error] Read Coupa.Polling.Enabled asset failed (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 7,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;[Error] Read Coupa.Polling.Enabled asset failed (&quot; &amp; exception.G",
        "precedenceTier": 4
      }
    },
    {
      "file": "Dispatcher.xaml",
      "workflow": "Dispatcher",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot captured for error diagnostics&quot;]",
      "resolvedValue": "[&quot;Screenshot captured for error diagnostics&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 8,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot captured for error diagnostics&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "Dispatcher.xaml",
      "workflow": "Dispatcher",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
      "resolvedValue": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 9,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
        "precedenceTier": 4
      }
    },
    {
      "file": "Dispatcher.xaml",
      "workflow": "Dispatcher",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;[Error] Read Coupa.Polling.LookbackMinutes asset failed (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "resolvedValue": "[&quot;[Error] Read Coupa.Polling.LookbackMinutes asset failed (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 10,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;[Error] Read Coupa.Polling.LookbackMinutes asset failed (&quot; &amp; exc",
        "precedenceTier": 4
      }
    },
    {
      "file": "Dispatcher.xaml",
      "workflow": "Dispatcher",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot captured for error diagnostics&quot;]",
      "resolvedValue": "[&quot;Screenshot captured for error diagnostics&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 11,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot captured for error diagnostics&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "Dispatcher.xaml",
      "workflow": "Dispatcher",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
      "resolvedValue": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 12,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
        "precedenceTier": 4
      }
    },
    {
      "file": "Dispatcher.xaml",
      "workflow": "Dispatcher",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;[Error] Read Orchestrator.FolderName asset failed (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "resolvedValue": "[&quot;[Error] Read Orchestrator.FolderName asset failed (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 13,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;[Error] Read Orchestrator.FolderName asset failed (&quot; &amp; exception",
        "precedenceTier": 4
      }
    },
    {
      "file": "Dispatcher.xaml",
      "workflow": "Dispatcher",
      "activityType": "GetCredential",
      "propertyName": "AssetName",
      "sourceBinding": "attribute-value",
      "originalValue": "Cred_Coupa_API",
      "resolvedValue": "Cred_Coupa_API",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "Cred_Coupa_API",
        "precedenceTier": 4
      }
    },
    {
      "file": "Dispatcher.xaml",
      "workflow": "Dispatcher",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot captured for error diagnostics&quot;]",
      "resolvedValue": "[&quot;Screenshot captured for error diagnostics&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 14,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot captured for error diagnostics&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "Dispatcher.xaml",
      "workflow": "Dispatcher",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
      "resolvedValue": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 15,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
        "precedenceTier": 4
      }
    },
    {
      "file": "Dispatcher.xaml",
      "workflow": "Dispatcher",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;[Error] Read Cred_Coupa_API credential failed (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "resolvedValue": "[&quot;[Error] Read Cred_Coupa_API credential failed (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 16,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;[Error] Read Cred_Coupa_API credential failed (&quot; &amp; exception.Get",
        "precedenceTier": 4
      }
    },
    {
      "file": "Dispatcher.xaml",
      "workflow": "Dispatcher",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot captured for error diagnostics&quot;]",
      "resolvedValue": "[&quot;Screenshot captured for error diagnostics&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 17,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot captured for error diagnostics&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "Dispatcher.xaml",
      "workflow": "Dispatcher",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
      "resolvedValue": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 18,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
        "precedenceTier": 4
      }
    },
    {
      "file": "Dispatcher.xaml",
      "workflow": "Dispatcher",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;[Error] Read CoupaInvoiceRecon_LastRunUtc watermark asset failed (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "resolvedValue": "[&quot;[Error] Read CoupaInvoiceRecon_LastRunUtc watermark asset failed (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 19,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;[Error] Read CoupaInvoiceRecon_LastRunUtc watermark asset failed (&quot; ",
        "precedenceTier": 4
      }
    },
    {
      "file": "Dispatcher.xaml",
      "workflow": "Dispatcher",
      "activityType": "If",
      "propertyName": "Condition",
      "sourceBinding": "attribute-value",
      "originalValue": "[{&quot;type&quot;:&quot;expression&quot;,&quot;left&quot;:&quot;bool_PollingEnabled&quot;,&quot;operator&quot;:&quot;=&quot;,&quot;right&quot;:&quot;False&quot;}]",
      "resolvedValue": "[{&quot;type&quot;:&quot;expression&quot;,&quot;left&quot;:&quot;bool_PollingEnabled&quot;,&quot;operator&quot;:&quot;=&quot;,&quot;right&quot;:&quot;False&quot;}]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[{&quot;type&quot;:&quot;expression&quot;,&quot;left&quot;:&quot;bool_PollingEna",
        "precedenceTier": 4
      }
    },
    {
      "file": "Dispatcher.xaml",
      "workflow": "Dispatcher",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Then path: Abort early if polling disabled&quot;]",
      "resolvedValue": "[&quot;Then path: Abort early if polling disabled&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 21,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Then path: Abort early if polling disabled&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "Dispatcher.xaml",
      "workflow": "Dispatcher",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Else path: Abort early if polling disabled&quot;]",
      "resolvedValue": "[&quot;Else path: Abort early if polling disabled&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 22,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Else path: Abort early if polling disabled&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "Dispatcher.xaml",
      "workflow": "Dispatcher",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "\"\"",
      "resolvedValue": "\"\"",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 1,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "\"\"",
        "precedenceTier": 4
      }
    },
    {
      "file": "Dispatcher.xaml",
      "workflow": "Dispatcher",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot captured for error diagnostics&quot;]",
      "resolvedValue": "[&quot;Screenshot captured for error diagnostics&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 23,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot captured for error diagnostics&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "Dispatcher.xaml",
      "workflow": "Dispatcher",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
      "resolvedValue": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 24,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
        "precedenceTier": 4
      }
    },
    {
      "file": "Dispatcher.xaml",
      "workflow": "Dispatcher",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;[Error] Call Coupa API to retrieve new invoices with RetryScope for transient failures failed (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "resolvedValue": "[&quot;[Error] Call Coupa API to retrieve new invoices with RetryScope for transient failures failed (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 25,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;[Error] Call Coupa API to retrieve new invoices with RetryScope for trans",
        "precedenceTier": 4
      }
    },
    {
      "file": "Dispatcher.xaml",
      "workflow": "Dispatcher",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;[Dispatcher] Coupa API responded successfully. Response length=&quot; &amp; str_CoupaApiResponse.Length.ToString() &amp; &quot; chars. Proceeding to deserialise.&quot;]",
      "resolvedValue": "[&quot;[Dispatcher] Coupa API responded successfully. Response length=&quot; &amp; str_CoupaApiResponse.Length.ToString() &amp; &quot; chars. Proceeding to deserialise.&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 26,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;[Dispatcher] Coupa API responded successfully. Response length=&quot; &am",
        "precedenceTier": 4
      }
    },
    {
      "file": "Dispatcher.xaml",
      "workflow": "Dispatcher",
      "activityType": "DeserializeJson",
      "propertyName": "JsonString",
      "sourceBinding": "attribute-value",
      "originalValue": "{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;str_CoupaApiResponse&quot;}",
      "resolvedValue": "[str_CoupaApiResponse]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;str_CoupaApiRespon",
        "precedenceTier": 4
      }
    },
    {
      "file": "Dispatcher.xaml",
      "workflow": "Dispatcher",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot captured for error diagnostics&quot;]",
      "resolvedValue": "[&quot;Screenshot captured for error diagnostics&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 27,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot captured for error diagnostics&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "Dispatcher.xaml",
      "workflow": "Dispatcher",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
      "resolvedValue": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 28,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
        "precedenceTier": 4
      }
    },
    {
      "file": "Dispatcher.xaml",
      "workflow": "Dispatcher",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;[Error] Deserialise Coupa API JSON response failed (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "resolvedValue": "[&quot;[Error] Deserialise Coupa API JSON response failed (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 29,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;[Error] Deserialise Coupa API JSON response failed (&quot; &amp; exceptio",
        "precedenceTier": 4
      }
    },
    {
      "file": "Dispatcher.xaml",
      "workflow": "Dispatcher",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "\"\"",
      "resolvedValue": "\"\"",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 2,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "\"\"",
        "precedenceTier": 4
      }
    },
    {
      "file": "Dispatcher.xaml",
      "workflow": "Dispatcher",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "[0]",
      "resolvedValue": "[0]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 3,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[0]",
        "precedenceTier": 4
      }
    },
    {
      "file": "Dispatcher.xaml",
      "workflow": "Dispatcher",
      "activityType": "ForEach",
      "propertyName": "Values",
      "sourceBinding": "attribute-value",
      "originalValue": "[{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;arr_Invoices&quot;}]",
      "resolvedValue": "[{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;arr_Invoices&quot;}]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;arr_Invoices&quot",
        "precedenceTier": 4
      }
    },
    {
      "file": "Dispatcher.xaml",
      "workflow": "Dispatcher",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Processing item in: Iterate each invoice returned by Coupa API&quot;]",
      "resolvedValue": "[&quot;Processing item in: Iterate each invoice returned by Coupa API&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 30,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Processing item in: Iterate each invoice returned by Coupa API&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "Dispatcher.xaml",
      "workflow": "Dispatcher",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "\"\"",
      "resolvedValue": "\"\"",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 4,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "\"\"",
        "precedenceTier": 4
      }
    },
    {
      "file": "Dispatcher.xaml",
      "workflow": "Dispatcher",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot captured for error diagnostics&quot;]",
      "resolvedValue": "[&quot;Screenshot captured for error diagnostics&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 31,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot captured for error diagnostics&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "Dispatcher.xaml",
      "workflow": "Dispatcher",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
      "resolvedValue": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 32,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
        "precedenceTier": 4
      }
    },
    {
      "file": "Dispatcher.xaml",
      "workflow": "Dispatcher",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;[Error] Extract CoupaInvoiceId from current invoice item failed (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "resolvedValue": "[&quot;[Error] Extract CoupaInvoiceId from current invoice item failed (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 33,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;[Error] Extract CoupaInvoiceId from current invoice item failed (&quot; &",
        "precedenceTier": 4
      }
    },
    {
      "file": "Dispatcher.xaml",
      "workflow": "Dispatcher",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "\"\"",
      "resolvedValue": "\"\"",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 5,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "\"\"",
        "precedenceTier": 4
      }
    },
    {
      "file": "Dispatcher.xaml",
      "workflow": "Dispatcher",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "\"\"",
      "resolvedValue": "\"\"",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 6,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "\"\"",
        "precedenceTier": 4
      }
    },
    {
      "file": "Dispatcher.xaml",
      "workflow": "Dispatcher",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot captured for error diagnostics&quot;]",
      "resolvedValue": "[&quot;Screenshot captured for error diagnostics&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 34,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot captured for error diagnostics&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "Dispatcher.xaml",
      "workflow": "Dispatcher",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
      "resolvedValue": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 35,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
        "precedenceTier": 4
      }
    },
    {
      "file": "Dispatcher.xaml",
      "workflow": "Dispatcher",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;[Error] Extract InvoicePdfUrl from current invoice item attachments failed (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "resolvedValue": "[&quot;[Error] Extract InvoicePdfUrl from current invoice item attachments failed (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 36,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;[Error] Extract InvoicePdfUrl from current invoice item attachments faile",
        "precedenceTier": 4
      }
    },
    {
      "file": "Dispatcher.xaml",
      "workflow": "Dispatcher",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "\"\"",
      "resolvedValue": "\"\"",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 7,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "\"\"",
        "precedenceTier": 4
      }
    },
    {
      "file": "Dispatcher.xaml",
      "workflow": "Dispatcher",
      "activityType": "QueryEntity",
      "propertyName": "EntityType",
      "sourceBinding": "attribute-value",
      "originalValue": "InvoiceCase",
      "resolvedValue": "InvoiceCase",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "InvoiceCase",
        "precedenceTier": 4
      }
    },
    {
      "file": "Dispatcher.xaml",
      "workflow": "Dispatcher",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot captured for error diagnostics&quot;]",
      "resolvedValue": "[&quot;Screenshot captured for error diagnostics&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 38,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot captured for error diagnostics&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "Dispatcher.xaml",
      "workflow": "Dispatcher",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
      "resolvedValue": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 39,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
        "precedenceTier": 4
      }
    },
    {
      "file": "Dispatcher.xaml",
      "workflow": "Dispatcher",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;[Error] Query Data Service for existing open InvoiceCase (idempotency check) failed (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "resolvedValue": "[&quot;[Error] Query Data Service for existing open InvoiceCase (idempotency check) failed (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 40,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;[Error] Query Data Service for existing open InvoiceCase (idempotency che",
        "precedenceTier": 4
      }
    },
    {
      "file": "Dispatcher.xaml",
      "workflow": "Dispatcher",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "\"\"",
      "resolvedValue": "\"\"",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 8,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "\"\"",
        "precedenceTier": 4
      }
    },
    {
      "file": "Dispatcher.xaml",
      "workflow": "Dispatcher",
      "activityType": "If",
      "propertyName": "Condition",
      "sourceBinding": "attribute-value",
      "originalValue": "[{&quot;type&quot;:&quot;expression&quot;,&quot;left&quot;:&quot;bool_CaseExists&quot;,&quot;operator&quot;:&quot;=&quot;,&quot;right&quot;:&quot;True&quot;}]",
      "resolvedValue": "[{&quot;type&quot;:&quot;expression&quot;,&quot;left&quot;:&quot;bool_CaseExists&quot;,&quot;operator&quot;:&quot;=&quot;,&quot;right&quot;:&quot;True&quot;}]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 1,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[{&quot;type&quot;:&quot;expression&quot;,&quot;left&quot;:&quot;bool_CaseExists",
        "precedenceTier": 4
      }
    },
    {
      "file": "Dispatcher.xaml",
      "workflow": "Dispatcher",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Then path: Branch: skip if open case exists, else proceed to create/enqueue&quot;]",
      "resolvedValue": "[&quot;Then path: Branch: skip if open case exists, else proceed to create/enqueue&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 41,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Then path: Branch: skip if open case exists, else proceed to create/enque",
        "precedenceTier": 4
      }
    },
    {
      "file": "Dispatcher.xaml",
      "workflow": "Dispatcher",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Else path: Branch: skip if open case exists, else proceed to create/enqueue&quot;]",
      "resolvedValue": "[&quot;Else path: Branch: skip if open case exists, else proceed to create/enqueue&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 42,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Else path: Branch: skip if open case exists, else proceed to create/enque",
        "precedenceTier": 4
      }
    },
    {
      "file": "Dispatcher.xaml",
      "workflow": "Dispatcher",
      "activityType": "CreateEntityRecord",
      "propertyName": "EntityType",
      "sourceBinding": "attribute-value",
      "originalValue": "InvoiceCase",
      "resolvedValue": "InvoiceCase",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "InvoiceCase",
        "precedenceTier": 4
      }
    },
    {
      "file": "Dispatcher.xaml",
      "workflow": "Dispatcher",
      "activityType": "CreateEntityRecord",
      "propertyName": "EntityObject",
      "sourceBinding": "attribute-value",
      "originalValue": "{&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;New Dictionary(Of String, Object) From {{\\&quot;CoupaInvoiceId\\&quot;, str_CurrentInvoiceId}, {\\&quot;VendorName\\&quot;, str_CurrentVendorName}, {\\&quot;SubmittedUtc\\&quot;, str_CurrentSubmittedUtc}, {\\&quot;QueuedUtc\\&quot;, DateTime.UtcNow.ToString(\\&quot;yyyy-MM-ddTHH:mm:ssZ\\&quot;)}, {\\&quot;CaseStatus\\&quot;, \\&quot;Queued\\&quot;}, {\\&quot;NeedsHumanValidation\\&quot;, False}, {\\&quot;PdfBucketPath\\&quot;, String.Empty}, {\\&quot;ValidationOverdue\\&quot;, False}, {\\&quot;PONotFound\\&quot;, False}, {\\&quot;POMismatch\\&quot;, False}, {\\&quot;TolerancePercent\\&quot;, 5.0}}&quot;}",
      "resolvedValue": "[New Dictionary(Of String, Object) From {{\"CoupaInvoiceId\", str_CurrentInvoiceId}, {\"VendorName\", str_CurrentVendorName}, {\"SubmittedUtc\", str_CurrentSubmittedUtc}, {\"QueuedUtc\", DateTime.UtcNow.ToString(\"yyyy-MM-ddTHH:mm:ssZ\")}, {\"CaseStatus\", \"Queued\"}, {\"NeedsHumanValidation\", False}, {\"PdfBucketPath\", String.Empty}, {\"ValidationOverdue\", False}, {\"PONotFound\", False}, {\"POMismatch\", False}, {\"TolerancePercent\", 5.0}}]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "{&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;New Dictiona",
        "precedenceTier": 4
      }
    },
    {
      "file": "Dispatcher.xaml",
      "workflow": "Dispatcher",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot captured for error diagnostics&quot;]",
      "resolvedValue": "[&quot;Screenshot captured for error diagnostics&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 43,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot captured for error diagnostics&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "Dispatcher.xaml",
      "workflow": "Dispatcher",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
      "resolvedValue": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 44,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
        "precedenceTier": 4
      }
    },
    {
      "file": "Dispatcher.xaml",
      "workflow": "Dispatcher",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;[Error] Create InvoiceCase entity record in Data Service with status Queued failed (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "resolvedValue": "[&quot;[Error] Create InvoiceCase entity record in Data Service with status Queued failed (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 45,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;[Error] Create InvoiceCase entity record in Data Service with status Queu",
        "precedenceTier": 4
      }
    },
    {
      "file": "Dispatcher.xaml",
      "workflow": "Dispatcher",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "\"\"",
      "resolvedValue": "\"\"",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 9,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "\"\"",
        "precedenceTier": 4
      }
    },
    {
      "file": "Dispatcher.xaml",
      "workflow": "Dispatcher",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot captured for error diagnostics&quot;]",
      "resolvedValue": "[&quot;Screenshot captured for error diagnostics&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 47,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot captured for error diagnostics&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "Dispatcher.xaml",
      "workflow": "Dispatcher",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
      "resolvedValue": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 48,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
        "precedenceTier": 4
      }
    },
    {
      "file": "Dispatcher.xaml",
      "workflow": "Dispatcher",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;[Error] Add queue item to Q_Coupa_InvoiceReconciliation failed (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "resolvedValue": "[&quot;[Error] Add queue item to Q_Coupa_InvoiceReconciliation failed (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 49,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;[Error] Add queue item to Q_Coupa_InvoiceReconciliation failed (&quot; &a",
        "precedenceTier": 4
      }
    },
    {
      "file": "Dispatcher.xaml",
      "workflow": "Dispatcher",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "\"\"",
      "resolvedValue": "\"\"",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 10,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "\"\"",
        "precedenceTier": 4
      }
    },
    {
      "file": "Dispatcher.xaml",
      "workflow": "Dispatcher",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;=== Completed: Dispatcher ===&quot;]",
      "resolvedValue": "[&quot;=== Completed: Dispatcher ===&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 50,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;=== Completed: Dispatcher ===&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "InitialiseConfig.xaml",
      "workflow": "InitialiseConfig",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;=== Starting: InitialiseConfig ===&quot;]",
      "resolvedValue": "[&quot;=== Starting: InitialiseConfig ===&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;=== Starting: InitialiseConfig ===&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "InitialiseConfig.xaml",
      "workflow": "InitialiseConfig",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[InitialiseConfig] Starting configuration load from Orchestrator Assets.",
      "resolvedValue": "[InitialiseConfig] Starting configuration load from Orchestrator Assets.",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 1,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[InitialiseConfig] Starting configuration load from Orchestrator Assets.",
        "precedenceTier": 4
      }
    },
    {
      "file": "InitialiseConfig.xaml",
      "workflow": "InitialiseConfig",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "[New Dictionary(Of String, Object)()]",
      "resolvedValue": "[New Dictionary(Of String, Object)()]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[New Dictionary(Of String, Object)()]",
        "precedenceTier": 4
      }
    },
    {
      "file": "InitialiseConfig.xaml",
      "workflow": "InitialiseConfig",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot captured for error diagnostics&quot;]",
      "resolvedValue": "[&quot;Screenshot captured for error diagnostics&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 2,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot captured for error diagnostics&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "InitialiseConfig.xaml",
      "workflow": "InitialiseConfig",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
      "resolvedValue": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 3,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
        "precedenceTier": 4
      }
    },
    {
      "file": "InitialiseConfig.xaml",
      "workflow": "InitialiseConfig",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;[Error] Get Asset: Coupa.BaseUrl failed (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "resolvedValue": "[&quot;[Error] Get Asset: Coupa.BaseUrl failed (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 4,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;[Error] Get Asset: Coupa.BaseUrl failed (&quot; &amp; exception.GetType()",
        "precedenceTier": 4
      }
    },
    {
      "file": "InitialiseConfig.xaml",
      "workflow": "InitialiseConfig",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot captured for error diagnostics&quot;]",
      "resolvedValue": "[&quot;Screenshot captured for error diagnostics&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 5,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot captured for error diagnostics&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "InitialiseConfig.xaml",
      "workflow": "InitialiseConfig",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
      "resolvedValue": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 6,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
        "precedenceTier": 4
      }
    },
    {
      "file": "InitialiseConfig.xaml",
      "workflow": "InitialiseConfig",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;[Error] Get Asset: Coupa.Polling.Enabled failed (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "resolvedValue": "[&quot;[Error] Get Asset: Coupa.Polling.Enabled failed (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 7,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;[Error] Get Asset: Coupa.Polling.Enabled failed (&quot; &amp; exception.G",
        "precedenceTier": 4
      }
    },
    {
      "file": "InitialiseConfig.xaml",
      "workflow": "InitialiseConfig",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot captured for error diagnostics&quot;]",
      "resolvedValue": "[&quot;Screenshot captured for error diagnostics&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 8,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot captured for error diagnostics&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "InitialiseConfig.xaml",
      "workflow": "InitialiseConfig",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
      "resolvedValue": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 9,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
        "precedenceTier": 4
      }
    },
    {
      "file": "InitialiseConfig.xaml",
      "workflow": "InitialiseConfig",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;[Error] Get Asset: Coupa.Polling.LookbackMinutes failed (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "resolvedValue": "[&quot;[Error] Get Asset: Coupa.Polling.LookbackMinutes failed (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 10,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;[Error] Get Asset: Coupa.Polling.LookbackMinutes failed (&quot; &amp; exc",
        "precedenceTier": 4
      }
    },
    {
      "file": "InitialiseConfig.xaml",
      "workflow": "InitialiseConfig",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot captured for error diagnostics&quot;]",
      "resolvedValue": "[&quot;Screenshot captured for error diagnostics&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 11,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot captured for error diagnostics&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "InitialiseConfig.xaml",
      "workflow": "InitialiseConfig",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
      "resolvedValue": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 12,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
        "precedenceTier": 4
      }
    },
    {
      "file": "InitialiseConfig.xaml",
      "workflow": "InitialiseConfig",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;[Error] Get Asset: Business.TolerancePercent failed (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "resolvedValue": "[&quot;[Error] Get Asset: Business.TolerancePercent failed (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 13,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;[Error] Get Asset: Business.TolerancePercent failed (&quot; &amp; excepti",
        "precedenceTier": 4
      }
    },
    {
      "file": "InitialiseConfig.xaml",
      "workflow": "InitialiseConfig",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot captured for error diagnostics&quot;]",
      "resolvedValue": "[&quot;Screenshot captured for error diagnostics&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 14,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot captured for error diagnostics&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "InitialiseConfig.xaml",
      "workflow": "InitialiseConfig",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
      "resolvedValue": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 15,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
        "precedenceTier": 4
      }
    },
    {
      "file": "InitialiseConfig.xaml",
      "workflow": "InitialiseConfig",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;[Error] Get Asset: Business.ToleranceBasis failed (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "resolvedValue": "[&quot;[Error] Get Asset: Business.ToleranceBasis failed (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 16,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;[Error] Get Asset: Business.ToleranceBasis failed (&quot; &amp; exception",
        "precedenceTier": 4
      }
    },
    {
      "file": "InitialiseConfig.xaml",
      "workflow": "InitialiseConfig",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot captured for error diagnostics&quot;]",
      "resolvedValue": "[&quot;Screenshot captured for error diagnostics&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 17,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot captured for error diagnostics&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "InitialiseConfig.xaml",
      "workflow": "InitialiseConfig",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
      "resolvedValue": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 18,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
        "precedenceTier": 4
      }
    },
    {
      "file": "InitialiseConfig.xaml",
      "workflow": "InitialiseConfig",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;[Error] Get Asset: DU.ConfidenceThreshold failed (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "resolvedValue": "[&quot;[Error] Get Asset: DU.ConfidenceThreshold failed (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 19,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;[Error] Get Asset: DU.ConfidenceThreshold failed (&quot; &amp; exception.",
        "precedenceTier": 4
      }
    },
    {
      "file": "InitialiseConfig.xaml",
      "workflow": "InitialiseConfig",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot captured for error diagnostics&quot;]",
      "resolvedValue": "[&quot;Screenshot captured for error diagnostics&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 20,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot captured for error diagnostics&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "InitialiseConfig.xaml",
      "workflow": "InitialiseConfig",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
      "resolvedValue": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 21,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
        "precedenceTier": 4
      }
    },
    {
      "file": "InitialiseConfig.xaml",
      "workflow": "InitialiseConfig",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;[Error] Get Asset: ActionCenter.SLAHours failed (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "resolvedValue": "[&quot;[Error] Get Asset: ActionCenter.SLAHours failed (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 22,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;[Error] Get Asset: ActionCenter.SLAHours failed (&quot; &amp; exception.G",
        "precedenceTier": 4
      }
    },
    {
      "file": "InitialiseConfig.xaml",
      "workflow": "InitialiseConfig",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot captured for error diagnostics&quot;]",
      "resolvedValue": "[&quot;Screenshot captured for error diagnostics&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 23,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot captured for error diagnostics&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "InitialiseConfig.xaml",
      "workflow": "InitialiseConfig",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
      "resolvedValue": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 24,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
        "precedenceTier": 4
      }
    },
    {
      "file": "InitialiseConfig.xaml",
      "workflow": "InitialiseConfig",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;[Error] Get Asset: Storage.RetentionDays failed (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "resolvedValue": "[&quot;[Error] Get Asset: Storage.RetentionDays failed (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 25,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;[Error] Get Asset: Storage.RetentionDays failed (&quot; &amp; exception.G",
        "precedenceTier": 4
      }
    },
    {
      "file": "InitialiseConfig.xaml",
      "workflow": "InitialiseConfig",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot captured for error diagnostics&quot;]",
      "resolvedValue": "[&quot;Screenshot captured for error diagnostics&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 26,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot captured for error diagnostics&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "InitialiseConfig.xaml",
      "workflow": "InitialiseConfig",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
      "resolvedValue": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 27,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
        "precedenceTier": 4
      }
    },
    {
      "file": "InitialiseConfig.xaml",
      "workflow": "InitialiseConfig",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;[Error] Get Asset: Orchestrator.FolderName failed (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "resolvedValue": "[&quot;[Error] Get Asset: Orchestrator.FolderName failed (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 28,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;[Error] Get Asset: Orchestrator.FolderName failed (&quot; &amp; exception",
        "precedenceTier": 4
      }
    },
    {
      "file": "InitialiseConfig.xaml",
      "workflow": "InitialiseConfig",
      "activityType": "GetCredential",
      "propertyName": "AssetName",
      "sourceBinding": "attribute-value",
      "originalValue": "Cred_Coupa_API",
      "resolvedValue": "Cred_Coupa_API",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "Cred_Coupa_API",
        "precedenceTier": 4
      }
    },
    {
      "file": "InitialiseConfig.xaml",
      "workflow": "InitialiseConfig",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot captured for error diagnostics&quot;]",
      "resolvedValue": "[&quot;Screenshot captured for error diagnostics&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 29,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot captured for error diagnostics&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "InitialiseConfig.xaml",
      "workflow": "InitialiseConfig",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
      "resolvedValue": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 30,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
        "precedenceTier": 4
      }
    },
    {
      "file": "InitialiseConfig.xaml",
      "workflow": "InitialiseConfig",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;[Error] Get Credential: Cred_Coupa_API failed (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "resolvedValue": "[&quot;[Error] Get Credential: Cred_Coupa_API failed (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 31,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;[Error] Get Credential: Cred_Coupa_API failed (&quot; &amp; exception.Get",
        "precedenceTier": 4
      }
    },
    {
      "file": "InitialiseConfig.xaml",
      "workflow": "InitialiseConfig",
      "activityType": "If",
      "propertyName": "Condition",
      "sourceBinding": "attribute-value",
      "originalValue": "[{&quot;type&quot;:&quot;expression&quot;,&quot;left&quot;:&quot;String.IsNullOrWhiteSpace(str_CoupaBaseUrl)&quot;,&quot;operator&quot;:&quot;=&quot;,&quot;right&quot;:&quot;True&quot;}]",
      "resolvedValue": "[{&quot;type&quot;:&quot;expression&quot;,&quot;left&quot;:&quot;String.IsNullOrWhiteSpace(str_CoupaBaseUrl)&quot;,&quot;operator&quot;:&quot;=&quot;,&quot;right&quot;:&quot;True&quot;}]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[{&quot;type&quot;:&quot;expression&quot;,&quot;left&quot;:&quot;String.IsNullOr",
        "precedenceTier": 4
      }
    },
    {
      "file": "InitialiseConfig.xaml",
      "workflow": "InitialiseConfig",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Then path: Validate: Coupa.BaseUrl is not empty&quot;]",
      "resolvedValue": "[&quot;Then path: Validate: Coupa.BaseUrl is not empty&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 32,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Then path: Validate: Coupa.BaseUrl is not empty&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "InitialiseConfig.xaml",
      "workflow": "InitialiseConfig",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Else path: Validate: Coupa.BaseUrl is not empty&quot;]",
      "resolvedValue": "[&quot;Else path: Validate: Coupa.BaseUrl is not empty&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 33,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Else path: Validate: Coupa.BaseUrl is not empty&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "InitialiseConfig.xaml",
      "workflow": "InitialiseConfig",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "\"\"",
      "resolvedValue": "\"\"",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 1,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "\"\"",
        "precedenceTier": 4
      }
    },
    {
      "file": "InitialiseConfig.xaml",
      "workflow": "InitialiseConfig",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "\"\"",
      "resolvedValue": "\"\"",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 2,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "\"\"",
        "precedenceTier": 4
      }
    },
    {
      "file": "InitialiseConfig.xaml",
      "workflow": "InitialiseConfig",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "\"\"",
      "resolvedValue": "\"\"",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 3,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "\"\"",
        "precedenceTier": 4
      }
    },
    {
      "file": "InitialiseConfig.xaml",
      "workflow": "InitialiseConfig",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "\"\"",
      "resolvedValue": "\"\"",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 4,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "\"\"",
        "precedenceTier": 4
      }
    },
    {
      "file": "InitialiseConfig.xaml",
      "workflow": "InitialiseConfig",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "\"\"",
      "resolvedValue": "\"\"",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 5,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "\"\"",
        "precedenceTier": 4
      }
    },
    {
      "file": "InitialiseConfig.xaml",
      "workflow": "InitialiseConfig",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "\"\"",
      "resolvedValue": "\"\"",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 6,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "\"\"",
        "precedenceTier": 4
      }
    },
    {
      "file": "InitialiseConfig.xaml",
      "workflow": "InitialiseConfig",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "\"\"",
      "resolvedValue": "\"\"",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 7,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "\"\"",
        "precedenceTier": 4
      }
    },
    {
      "file": "InitialiseConfig.xaml",
      "workflow": "InitialiseConfig",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "\"\"",
      "resolvedValue": "\"\"",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 8,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "\"\"",
        "precedenceTier": 4
      }
    },
    {
      "file": "InitialiseConfig.xaml",
      "workflow": "InitialiseConfig",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "\"\"",
      "resolvedValue": "\"\"",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 9,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "\"\"",
        "precedenceTier": 4
      }
    },
    {
      "file": "InitialiseConfig.xaml",
      "workflow": "InitialiseConfig",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "\"\"",
      "resolvedValue": "\"\"",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 10,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "\"\"",
        "precedenceTier": 4
      }
    },
    {
      "file": "InitialiseConfig.xaml",
      "workflow": "InitialiseConfig",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "\"\"",
      "resolvedValue": "\"\"",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 11,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "\"\"",
        "precedenceTier": 4
      }
    },
    {
      "file": "InitialiseConfig.xaml",
      "workflow": "InitialiseConfig",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "\"\"",
      "resolvedValue": "\"\"",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 12,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "\"\"",
        "precedenceTier": 4
      }
    },
    {
      "file": "InitialiseConfig.xaml",
      "workflow": "InitialiseConfig",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "\"\"",
      "resolvedValue": "\"\"",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 13,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "\"\"",
        "precedenceTier": 4
      }
    },
    {
      "file": "InitialiseConfig.xaml",
      "workflow": "InitialiseConfig",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "\"\"",
      "resolvedValue": "\"\"",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 14,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "\"\"",
        "precedenceTier": 4
      }
    },
    {
      "file": "InitialiseConfig.xaml",
      "workflow": "InitialiseConfig",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;[InitialiseConfig] Asset validation complete. Error count (empty = none): &apos;&quot; &amp; str_ValidationErrors &amp; &quot;&apos;&quot;]",
      "resolvedValue": "[&quot;[InitialiseConfig] Asset validation complete. Error count (empty = none): &apos;&quot; &amp; str_ValidationErrors &amp; &quot;&apos;&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 34,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;[InitialiseConfig] Asset validation complete. Error count (empty = none):",
        "precedenceTier": 4
      }
    },
    {
      "file": "InitialiseConfig.xaml",
      "workflow": "InitialiseConfig",
      "activityType": "If",
      "propertyName": "Condition",
      "sourceBinding": "attribute-value",
      "originalValue": "[{&quot;type&quot;:&quot;expression&quot;,&quot;left&quot;:&quot;String.IsNullOrWhiteSpace(str_ValidationErrors)&quot;,&quot;operator&quot;:&quot;=&quot;,&quot;right&quot;:&quot;False&quot;}]",
      "resolvedValue": "[{&quot;type&quot;:&quot;expression&quot;,&quot;left&quot;:&quot;String.IsNullOrWhiteSpace(str_ValidationErrors)&quot;,&quot;operator&quot;:&quot;=&quot;,&quot;right&quot;:&quot;False&quot;}]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 1,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[{&quot;type&quot;:&quot;expression&quot;,&quot;left&quot;:&quot;String.IsNullOr",
        "precedenceTier": 4
      }
    },
    {
      "file": "InitialiseConfig.xaml",
      "workflow": "InitialiseConfig",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Then path: Throw BusinessRuleException if any validation errors accumulated&quot;]",
      "resolvedValue": "[&quot;Then path: Throw BusinessRuleException if any validation errors accumulated&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 35,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Then path: Throw BusinessRuleException if any validation errors accumulat",
        "precedenceTier": 4
      }
    },
    {
      "file": "InitialiseConfig.xaml",
      "workflow": "InitialiseConfig",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Else path: Throw BusinessRuleException if any validation errors accumulated&quot;]",
      "resolvedValue": "[&quot;Else path: Throw BusinessRuleException if any validation errors accumulated&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 36,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Else path: Throw BusinessRuleException if any validation errors accumulat",
        "precedenceTier": 4
      }
    },
    {
      "file": "InitialiseConfig.xaml",
      "workflow": "InitialiseConfig",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot captured for error diagnostics&quot;]",
      "resolvedValue": "[&quot;Screenshot captured for error diagnostics&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 37,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot captured for error diagnostics&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "InitialiseConfig.xaml",
      "workflow": "InitialiseConfig",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
      "resolvedValue": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 38,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
        "precedenceTier": 4
      }
    },
    {
      "file": "InitialiseConfig.xaml",
      "workflow": "InitialiseConfig",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;[Escalation Required] Throw initialisation exception with all accumulated error details failed (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "resolvedValue": "[&quot;[Escalation Required] Throw initialisation exception with all accumulated error details failed (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 39,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;[Escalation Required] Throw initialisation exception with all accumulated",
        "precedenceTier": 4
      }
    },
    {
      "file": "InitialiseConfig.xaml",
      "workflow": "InitialiseConfig",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "\"\"",
      "resolvedValue": "\"\"",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 15,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "\"\"",
        "precedenceTier": 4
      }
    },
    {
      "file": "InitialiseConfig.xaml",
      "workflow": "InitialiseConfig",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "\"\"",
      "resolvedValue": "\"\"",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 16,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "\"\"",
        "precedenceTier": 4
      }
    },
    {
      "file": "InitialiseConfig.xaml",
      "workflow": "InitialiseConfig",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "\"\"",
      "resolvedValue": "\"\"",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 17,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "\"\"",
        "precedenceTier": 4
      }
    },
    {
      "file": "InitialiseConfig.xaml",
      "workflow": "InitialiseConfig",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "\"\"",
      "resolvedValue": "\"\"",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 18,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "\"\"",
        "precedenceTier": 4
      }
    },
    {
      "file": "InitialiseConfig.xaml",
      "workflow": "InitialiseConfig",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "\"\"",
      "resolvedValue": "\"\"",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 19,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "\"\"",
        "precedenceTier": 4
      }
    },
    {
      "file": "InitialiseConfig.xaml",
      "workflow": "InitialiseConfig",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "\"\"",
      "resolvedValue": "\"\"",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 20,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "\"\"",
        "precedenceTier": 4
      }
    },
    {
      "file": "InitialiseConfig.xaml",
      "workflow": "InitialiseConfig",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "\"\"",
      "resolvedValue": "\"\"",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 21,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "\"\"",
        "precedenceTier": 4
      }
    },
    {
      "file": "InitialiseConfig.xaml",
      "workflow": "InitialiseConfig",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "\"\"",
      "resolvedValue": "\"\"",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 22,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "\"\"",
        "precedenceTier": 4
      }
    },
    {
      "file": "InitialiseConfig.xaml",
      "workflow": "InitialiseConfig",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "\"\"",
      "resolvedValue": "\"\"",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 23,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "\"\"",
        "precedenceTier": 4
      }
    },
    {
      "file": "InitialiseConfig.xaml",
      "workflow": "InitialiseConfig",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;=== Completed: InitialiseConfig ===&quot;]",
      "resolvedValue": "[&quot;=== Completed: InitialiseConfig ===&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 40,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;=== Completed: InitialiseConfig ===&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "ProcessTransaction.xaml",
      "workflow": "ProcessTransaction",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;=== Starting: ProcessTransaction ===&quot;]",
      "resolvedValue": "[&quot;=== Starting: ProcessTransaction ===&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;=== Starting: ProcessTransaction ===&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "ProcessTransaction.xaml",
      "workflow": "ProcessTransaction",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "[DateTime.UtcNow]",
      "resolvedValue": "[DateTime.UtcNow]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[DateTime.UtcNow]",
        "precedenceTier": 4
      }
    },
    {
      "file": "ProcessTransaction.xaml",
      "workflow": "ProcessTransaction",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "\"\"",
      "resolvedValue": "\"\"",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 1,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "\"\"",
        "precedenceTier": 4
      }
    },
    {
      "file": "ProcessTransaction.xaml",
      "workflow": "ProcessTransaction",
      "activityType": "QueryEntity",
      "propertyName": "EntityType",
      "sourceBinding": "attribute-value",
      "originalValue": "InvoiceCase",
      "resolvedValue": "InvoiceCase",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "InvoiceCase",
        "precedenceTier": 4
      }
    },
    {
      "file": "ProcessTransaction.xaml",
      "workflow": "ProcessTransaction",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot captured for error diagnostics&quot;]",
      "resolvedValue": "[&quot;Screenshot captured for error diagnostics&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 2,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot captured for error diagnostics&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "ProcessTransaction.xaml",
      "workflow": "ProcessTransaction",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
      "resolvedValue": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 3,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
        "precedenceTier": 4
      }
    },
    {
      "file": "ProcessTransaction.xaml",
      "workflow": "ProcessTransaction",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;[Error] Query Data Service for existing InvoiceCase by CoupaInvoiceId failed (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "resolvedValue": "[&quot;[Error] Query Data Service for existing InvoiceCase by CoupaInvoiceId failed (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 4,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;[Error] Query Data Service for existing InvoiceCase by CoupaInvoiceId fai",
        "precedenceTier": 4
      }
    },
    {
      "file": "ProcessTransaction.xaml",
      "workflow": "ProcessTransaction",
      "activityType": "UpdateEntity",
      "propertyName": "EntityType",
      "sourceBinding": "attribute-value",
      "originalValue": "InvoiceCase",
      "resolvedValue": "InvoiceCase",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "InvoiceCase",
        "precedenceTier": 4
      }
    },
    {
      "file": "ProcessTransaction.xaml",
      "workflow": "ProcessTransaction",
      "activityType": "UpdateEntity",
      "propertyName": "EntityObject",
      "sourceBinding": "attribute-value",
      "originalValue": "{&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;New With {.CoupaInvoiceId = CoupaInvoiceId, .CaseStatus = \\&quot;InProgress\\&quot;, .PickedUpUtc = pickedUpUtc}&quot;}",
      "resolvedValue": "[New With {.CoupaInvoiceId = CoupaInvoiceId, .CaseStatus = \"InProgress\", .PickedUpUtc = pickedUpUtc}]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "{&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;New With {.C",
        "precedenceTier": 4
      }
    },
    {
      "file": "ProcessTransaction.xaml",
      "workflow": "ProcessTransaction",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot captured for error diagnostics&quot;]",
      "resolvedValue": "[&quot;Screenshot captured for error diagnostics&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 6,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot captured for error diagnostics&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "ProcessTransaction.xaml",
      "workflow": "ProcessTransaction",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
      "resolvedValue": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 7,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
        "precedenceTier": 4
      }
    },
    {
      "file": "ProcessTransaction.xaml",
      "workflow": "ProcessTransaction",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;[Error] Update InvoiceCase status to InProgress and set PickedUpUtc failed (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "resolvedValue": "[&quot;[Error] Update InvoiceCase status to InProgress and set PickedUpUtc failed (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 8,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;[Error] Update InvoiceCase status to InProgress and set PickedUpUtc faile",
        "precedenceTier": 4
      }
    },
    {
      "file": "ProcessTransaction.xaml",
      "workflow": "ProcessTransaction",
      "activityType": "InvokeWorkflowFile",
      "propertyName": "WorkflowFileName",
      "sourceBinding": "attribute-value",
      "originalValue": "RetrieveInvoicePdf.xaml",
      "resolvedValue": "RetrieveInvoicePdf.xaml",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "RetrieveInvoicePdf.xaml",
        "precedenceTier": 4
      }
    },
    {
      "file": "ProcessTransaction.xaml",
      "workflow": "ProcessTransaction",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot captured for error diagnostics&quot;]",
      "resolvedValue": "[&quot;Screenshot captured for error diagnostics&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 10,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot captured for error diagnostics&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "ProcessTransaction.xaml",
      "workflow": "ProcessTransaction",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
      "resolvedValue": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 11,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
        "precedenceTier": 4
      }
    },
    {
      "file": "ProcessTransaction.xaml",
      "workflow": "ProcessTransaction",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;[Error] Invoke RetrieveInvoicePdf to download PDF and store to Storage Bucket failed (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "resolvedValue": "[&quot;[Error] Invoke RetrieveInvoicePdf to download PDF and store to Storage Bucket failed (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 12,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;[Error] Invoke RetrieveInvoicePdf to download PDF and store to Storage Bu",
        "precedenceTier": 4
      }
    },
    {
      "file": "ProcessTransaction.xaml",
      "workflow": "ProcessTransaction",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "\"\"",
      "resolvedValue": "\"\"",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 2,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "\"\"",
        "precedenceTier": 4
      }
    },
    {
      "file": "ProcessTransaction.xaml",
      "workflow": "ProcessTransaction",
      "activityType": "UpdateEntity",
      "propertyName": "EntityType",
      "sourceBinding": "attribute-value",
      "originalValue": "InvoiceCase",
      "resolvedValue": "InvoiceCase",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 1,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "InvoiceCase",
        "precedenceTier": 4
      }
    },
    {
      "file": "ProcessTransaction.xaml",
      "workflow": "ProcessTransaction",
      "activityType": "UpdateEntity",
      "propertyName": "EntityObject",
      "sourceBinding": "attribute-value",
      "originalValue": "New With {.CoupaInvoiceId = CoupaInvoiceId, .PdfBucketPath = pdfBucketPath}",
      "resolvedValue": "New With {.CoupaInvoiceId = CoupaInvoiceId, .PdfBucketPath = pdfBucketPath}",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 1,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "New With {.CoupaInvoiceId = CoupaInvoiceId, .PdfBucketPath = pdfBucketPath}",
        "precedenceTier": 4
      }
    },
    {
      "file": "ProcessTransaction.xaml",
      "workflow": "ProcessTransaction",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot captured for error diagnostics&quot;]",
      "resolvedValue": "[&quot;Screenshot captured for error diagnostics&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 14,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot captured for error diagnostics&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "ProcessTransaction.xaml",
      "workflow": "ProcessTransaction",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
      "resolvedValue": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 15,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
        "precedenceTier": 4
      }
    },
    {
      "file": "ProcessTransaction.xaml",
      "workflow": "ProcessTransaction",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;[Error] Update InvoiceCase with PdfBucketPath after successful retrieval failed (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "resolvedValue": "[&quot;[Error] Update InvoiceCase with PdfBucketPath after successful retrieval failed (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 16,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;[Error] Update InvoiceCase with PdfBucketPath after successful retrieval ",
        "precedenceTier": 4
      }
    },
    {
      "file": "ProcessTransaction.xaml",
      "workflow": "ProcessTransaction",
      "activityType": "InvokeWorkflowFile",
      "propertyName": "WorkflowFileName",
      "sourceBinding": "attribute-value",
      "originalValue": "ExtractInvoiceFields.xaml",
      "resolvedValue": "ExtractInvoiceFields.xaml",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 1,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "ExtractInvoiceFields.xaml",
        "precedenceTier": 4
      }
    },
    {
      "file": "ProcessTransaction.xaml",
      "workflow": "ProcessTransaction",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot captured for error diagnostics&quot;]",
      "resolvedValue": "[&quot;Screenshot captured for error diagnostics&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 17,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot captured for error diagnostics&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "ProcessTransaction.xaml",
      "workflow": "ProcessTransaction",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
      "resolvedValue": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 18,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
        "precedenceTier": 4
      }
    },
    {
      "file": "ProcessTransaction.xaml",
      "workflow": "ProcessTransaction",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;[Error] Invoke ExtractInvoiceFields to run DU extraction pipeline failed (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "resolvedValue": "[&quot;[Error] Invoke ExtractInvoiceFields to run DU extraction pipeline failed (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 19,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;[Error] Invoke ExtractInvoiceFields to run DU extraction pipeline failed ",
        "precedenceTier": 4
      }
    },
    {
      "file": "ProcessTransaction.xaml",
      "workflow": "ProcessTransaction",
      "activityType": "UpdateEntity",
      "propertyName": "EntityType",
      "sourceBinding": "attribute-value",
      "originalValue": "InvoiceCase",
      "resolvedValue": "InvoiceCase",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 2,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "InvoiceCase",
        "precedenceTier": 4
      }
    },
    {
      "file": "ProcessTransaction.xaml",
      "workflow": "ProcessTransaction",
      "activityType": "UpdateEntity",
      "propertyName": "EntityObject",
      "sourceBinding": "attribute-value",
      "originalValue": "New With {.CoupaInvoiceId = CoupaInvoiceId, .ExtractedPONumber = extractedPONumber, .ExtractedInvoiceNumber = extractedInvoiceNumber, .ExtractedInvoiceTotal = CDbl(extractedInvoiceTotal), .ExtractedCurrency = extractedCurrency, .ExtractionConfidence = CDbl(overallExtractionConfidence), .NeedsHumanValidation = needsHumanValidation}",
      "resolvedValue": "New With {.CoupaInvoiceId = CoupaInvoiceId, .ExtractedPONumber = extractedPONumber, .ExtractedInvoiceNumber = extractedInvoiceNumber, .ExtractedInvoiceTotal = CDbl(extractedInvoiceTotal), .ExtractedCurrency = extractedCurrency, .ExtractionConfidence = CDbl(overallExtractionConfidence), .NeedsHumanValidation = needsHumanValidation}",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 2,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "New With {.CoupaInvoiceId = CoupaInvoiceId, .ExtractedPONumber = extractedPONumb",
        "precedenceTier": 4
      }
    },
    {
      "file": "ProcessTransaction.xaml",
      "workflow": "ProcessTransaction",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot captured for error diagnostics&quot;]",
      "resolvedValue": "[&quot;Screenshot captured for error diagnostics&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 21,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot captured for error diagnostics&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "ProcessTransaction.xaml",
      "workflow": "ProcessTransaction",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
      "resolvedValue": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 22,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
        "precedenceTier": 4
      }
    },
    {
      "file": "ProcessTransaction.xaml",
      "workflow": "ProcessTransaction",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;[Error] Update InvoiceCase with extracted field values and confidence score failed (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "resolvedValue": "[&quot;[Error] Update InvoiceCase with extracted field values and confidence score failed (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 23,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;[Error] Update InvoiceCase with extracted field values and confidence sco",
        "precedenceTier": 4
      }
    },
    {
      "file": "ProcessTransaction.xaml",
      "workflow": "ProcessTransaction",
      "activityType": "If",
      "propertyName": "Condition",
      "sourceBinding": "attribute-value",
      "originalValue": "[{&quot;type&quot;:&quot;expression&quot;,&quot;left&quot;:&quot;needsHumanValidation&quot;,&quot;operator&quot;:&quot;=&quot;,&quot;right&quot;:&quot;True&quot;}]",
      "resolvedValue": "[{&quot;type&quot;:&quot;expression&quot;,&quot;left&quot;:&quot;needsHumanValidation&quot;,&quot;operator&quot;:&quot;=&quot;,&quot;right&quot;:&quot;True&quot;}]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[{&quot;type&quot;:&quot;expression&quot;,&quot;left&quot;:&quot;needsHumanValid",
        "precedenceTier": 4
      }
    },
    {
      "file": "ProcessTransaction.xaml",
      "workflow": "ProcessTransaction",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Then path: Branch: does this invoice need human validation (low confidence or IsResumedFromValidation)?&quot;]",
      "resolvedValue": "[&quot;Then path: Branch: does this invoice need human validation (low confidence or IsResumedFromValidation)?&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 24,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Then path: Branch: does this invoice need human validation (low confidenc",
        "precedenceTier": 4
      }
    },
    {
      "file": "ProcessTransaction.xaml",
      "workflow": "ProcessTransaction",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Else path: Branch: does this invoice need human validation (low confidence or IsResumedFromValidation)?&quot;]",
      "resolvedValue": "[&quot;Else path: Branch: does this invoice need human validation (low confidence or IsResumedFromValidation)?&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 25,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Else path: Branch: does this invoice need human validation (low confidenc",
        "precedenceTier": 4
      }
    },
    {
      "file": "ProcessTransaction.xaml",
      "workflow": "ProcessTransaction",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;[ProcessTransaction] WARN Low extraction confidence. CoupaInvoiceId=&quot; &amp; CoupaInvoiceId &amp; &quot; OverallConfidence=&quot; &amp; overallExtractionConfidence.ToString() &amp; &quot; Threshold=&quot; &amp; confidenceThreshold.ToString() &amp; &quot;. Invoking CreateValidationTask.&quot;]",
      "resolvedValue": "[&quot;[ProcessTransaction] WARN Low extraction confidence. CoupaInvoiceId=&quot; &amp; CoupaInvoiceId &amp; &quot; OverallConfidence=&quot; &amp; overallExtractionConfidence.ToString() &amp; &quot; Threshold=&quot; &amp; confidenceThreshold.ToString() &amp; &quot;. Invoking CreateValidationTask.&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 26,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;[ProcessTransaction] WARN Low extraction confidence. CoupaInvoiceId=&quot",
        "precedenceTier": 4
      }
    },
    {
      "file": "ProcessTransaction.xaml",
      "workflow": "ProcessTransaction",
      "activityType": "InvokeWorkflowFile",
      "propertyName": "WorkflowFileName",
      "sourceBinding": "attribute-value",
      "originalValue": "CreateValidationTask.xaml",
      "resolvedValue": "CreateValidationTask.xaml",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 2,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "CreateValidationTask.xaml",
        "precedenceTier": 4
      }
    },
    {
      "file": "ProcessTransaction.xaml",
      "workflow": "ProcessTransaction",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot captured for error diagnostics&quot;]",
      "resolvedValue": "[&quot;Screenshot captured for error diagnostics&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 27,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot captured for error diagnostics&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "ProcessTransaction.xaml",
      "workflow": "ProcessTransaction",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
      "resolvedValue": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 28,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
        "precedenceTier": 4
      }
    },
    {
      "file": "ProcessTransaction.xaml",
      "workflow": "ProcessTransaction",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;[Error] Invoke CreateValidationTask to create Action Center task for AP Clerk failed (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "resolvedValue": "[&quot;[Error] Invoke CreateValidationTask to create Action Center task for AP Clerk failed (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 29,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;[Error] Invoke CreateValidationTask to create Action Center task for AP C",
        "precedenceTier": 4
      }
    },
    {
      "file": "ProcessTransaction.xaml",
      "workflow": "ProcessTransaction",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "\"\"",
      "resolvedValue": "\"\"",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 3,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "\"\"",
        "precedenceTier": 4
      }
    },
    {
      "file": "ProcessTransaction.xaml",
      "workflow": "ProcessTransaction",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "\"\"",
      "resolvedValue": "\"\"",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 4,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "\"\"",
        "precedenceTier": 4
      }
    },
    {
      "file": "ProcessTransaction.xaml",
      "workflow": "ProcessTransaction",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;[ProcessTransaction] Action Center task created. CoupaInvoiceId=&quot; &amp; CoupaInvoiceId &amp; &quot; TransactionOutcome=PendingValidation. Exiting for queue-based AC resumption.&quot;]",
      "resolvedValue": "[&quot;[ProcessTransaction] Action Center task created. CoupaInvoiceId=&quot; &amp; CoupaInvoiceId &amp; &quot; TransactionOutcome=PendingValidation. Exiting for queue-based AC resumption.&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 30,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;[ProcessTransaction] Action Center task created. CoupaInvoiceId=&quot; &a",
        "precedenceTier": 4
      }
    },
    {
      "file": "ProcessTransaction.xaml",
      "workflow": "ProcessTransaction",
      "activityType": "InvokeWorkflowFile",
      "propertyName": "WorkflowFileName",
      "sourceBinding": "attribute-value",
      "originalValue": "ValidateAndDecide.xaml",
      "resolvedValue": "ValidateAndDecide.xaml",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 3,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "ValidateAndDecide.xaml",
        "precedenceTier": 4
      }
    },
    {
      "file": "ProcessTransaction.xaml",
      "workflow": "ProcessTransaction",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot captured for error diagnostics&quot;]",
      "resolvedValue": "[&quot;Screenshot captured for error diagnostics&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 31,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot captured for error diagnostics&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "ProcessTransaction.xaml",
      "workflow": "ProcessTransaction",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
      "resolvedValue": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 32,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
        "precedenceTier": 4
      }
    },
    {
      "file": "ProcessTransaction.xaml",
      "workflow": "ProcessTransaction",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;[Error] Invoke ValidateAndDecide for PO match, tolerance check, and Coupa routing/rejection failed (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "resolvedValue": "[&quot;[Error] Invoke ValidateAndDecide for PO match, tolerance check, and Coupa routing/rejection failed (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 33,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;[Error] Invoke ValidateAndDecide for PO match, tolerance check, and Coupa",
        "precedenceTier": 4
      }
    },
    {
      "file": "ProcessTransaction.xaml",
      "workflow": "ProcessTransaction",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "\"\"",
      "resolvedValue": "\"\"",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 5,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "\"\"",
        "precedenceTier": 4
      }
    },
    {
      "file": "ProcessTransaction.xaml",
      "workflow": "ProcessTransaction",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "\"\"",
      "resolvedValue": "\"\"",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 6,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "\"\"",
        "precedenceTier": 4
      }
    },
    {
      "file": "ProcessTransaction.xaml",
      "workflow": "ProcessTransaction",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "[DateTime.UtcNow]",
      "resolvedValue": "[DateTime.UtcNow]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 7,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[DateTime.UtcNow]",
        "precedenceTier": 4
      }
    },
    {
      "file": "ProcessTransaction.xaml",
      "workflow": "ProcessTransaction",
      "activityType": "UpdateEntity",
      "propertyName": "EntityType",
      "sourceBinding": "attribute-value",
      "originalValue": "InvoiceCase",
      "resolvedValue": "InvoiceCase",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 3,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "InvoiceCase",
        "precedenceTier": 4
      }
    },
    {
      "file": "ProcessTransaction.xaml",
      "workflow": "ProcessTransaction",
      "activityType": "UpdateEntity",
      "propertyName": "EntityObject",
      "sourceBinding": "attribute-value",
      "originalValue": "New With {.CoupaInvoiceId = CoupaInvoiceId, .CaseStatus = finalCaseStatus, .RejectionReasonCode = rejectionReasonCode, .CompletedUtc = completedUtc}",
      "resolvedValue": "New With {.CoupaInvoiceId = CoupaInvoiceId, .CaseStatus = finalCaseStatus, .RejectionReasonCode = rejectionReasonCode, .CompletedUtc = completedUtc}",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 3,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "New With {.CoupaInvoiceId = CoupaInvoiceId, .CaseStatus = finalCaseStatus, .Reje",
        "precedenceTier": 4
      }
    },
    {
      "file": "ProcessTransaction.xaml",
      "workflow": "ProcessTransaction",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot captured for error diagnostics&quot;]",
      "resolvedValue": "[&quot;Screenshot captured for error diagnostics&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 35,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot captured for error diagnostics&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "ProcessTransaction.xaml",
      "workflow": "ProcessTransaction",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
      "resolvedValue": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 36,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
        "precedenceTier": 4
      }
    },
    {
      "file": "ProcessTransaction.xaml",
      "workflow": "ProcessTransaction",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;[Error] Update InvoiceCase with final status, rejection reason, and timestamps failed (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "resolvedValue": "[&quot;[Error] Update InvoiceCase with final status, rejection reason, and timestamps failed (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 37,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;[Error] Update InvoiceCase with final status, rejection reason, and times",
        "precedenceTier": 4
      }
    },
    {
      "file": "ProcessTransaction.xaml",
      "workflow": "ProcessTransaction",
      "activityType": "CreateEntityRecord",
      "propertyName": "EntityType",
      "sourceBinding": "attribute-value",
      "originalValue": "InvoiceEventLog",
      "resolvedValue": "InvoiceEventLog",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "InvoiceEventLog",
        "precedenceTier": 4
      }
    },
    {
      "file": "ProcessTransaction.xaml",
      "workflow": "ProcessTransaction",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;=== Completed: ProcessTransaction ===&quot;]",
      "resolvedValue": "[&quot;=== Completed: ProcessTransaction ===&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 38,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;=== Completed: ProcessTransaction ===&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "RetrieveInvoicePdf.xaml",
      "workflow": "RetrieveInvoicePdf",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;=== Starting: RetrieveInvoicePdf ===&quot;]",
      "resolvedValue": "[&quot;=== Starting: RetrieveInvoicePdf ===&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;=== Starting: RetrieveInvoicePdf ===&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "RetrieveInvoicePdf.xaml",
      "workflow": "RetrieveInvoicePdf",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot captured for error diagnostics&quot;]",
      "resolvedValue": "[&quot;Screenshot captured for error diagnostics&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 2,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot captured for error diagnostics&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "RetrieveInvoicePdf.xaml",
      "workflow": "RetrieveInvoicePdf",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
      "resolvedValue": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 3,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
        "precedenceTier": 4
      }
    },
    {
      "file": "RetrieveInvoicePdf.xaml",
      "workflow": "RetrieveInvoicePdf",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;[Error] Read Coupa.BaseUrl asset for URL validation context failed (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "resolvedValue": "[&quot;[Error] Read Coupa.BaseUrl asset for URL validation context failed (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 4,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;[Error] Read Coupa.BaseUrl asset for URL validation context failed (&quot",
        "precedenceTier": 4
      }
    },
    {
      "file": "RetrieveInvoicePdf.xaml",
      "workflow": "RetrieveInvoicePdf",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "\"\"",
      "resolvedValue": "\"\"",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "\"\"",
        "precedenceTier": 4
      }
    },
    {
      "file": "RetrieveInvoicePdf.xaml",
      "workflow": "RetrieveInvoicePdf",
      "activityType": "If",
      "propertyName": "Condition",
      "sourceBinding": "attribute-value",
      "originalValue": "[{&quot;type&quot;:&quot;expression&quot;,&quot;left&quot;:&quot;tempPathExists&quot;,&quot;operator&quot;:&quot;&lt;&gt;&quot;,&quot;right&quot;:&quot;True&quot;}]",
      "resolvedValue": "[{&quot;type&quot;:&quot;expression&quot;,&quot;left&quot;:&quot;tempPathExists&quot;,&quot;operator&quot;:&quot;&lt;&gt;&quot;,&quot;right&quot;:&quot;True&quot;}]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[{&quot;type&quot;:&quot;expression&quot;,&quot;left&quot;:&quot;tempPathExists&",
        "precedenceTier": 4
      }
    },
    {
      "file": "RetrieveInvoicePdf.xaml",
      "workflow": "RetrieveInvoicePdf",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Then path: Create temp folder if it does not exist&quot;]",
      "resolvedValue": "[&quot;Then path: Create temp folder if it does not exist&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 5,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Then path: Create temp folder if it does not exist&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "RetrieveInvoicePdf.xaml",
      "workflow": "RetrieveInvoicePdf",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Else path: Create temp folder if it does not exist&quot;]",
      "resolvedValue": "[&quot;Else path: Create temp folder if it does not exist&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 6,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Else path: Create temp folder if it does not exist&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "RetrieveInvoicePdf.xaml",
      "workflow": "RetrieveInvoicePdf",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot captured for error diagnostics&quot;]",
      "resolvedValue": "[&quot;Screenshot captured for error diagnostics&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 7,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot captured for error diagnostics&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "RetrieveInvoicePdf.xaml",
      "workflow": "RetrieveInvoicePdf",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
      "resolvedValue": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 8,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
        "precedenceTier": 4
      }
    },
    {
      "file": "RetrieveInvoicePdf.xaml",
      "workflow": "RetrieveInvoicePdf",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;[Error] Create temp folder if it does not exist failed (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "resolvedValue": "[&quot;[Error] Create temp folder if it does not exist failed (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 9,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;[Error] Create temp folder if it does not exist failed (&quot; &amp; exce",
        "precedenceTier": 4
      }
    },
    {
      "file": "RetrieveInvoicePdf.xaml",
      "workflow": "RetrieveInvoicePdf",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "\"\"",
      "resolvedValue": "\"\"",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 1,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "\"\"",
        "precedenceTier": 4
      }
    },
    {
      "file": "RetrieveInvoicePdf.xaml",
      "workflow": "RetrieveInvoicePdf",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot captured for error diagnostics&quot;]",
      "resolvedValue": "[&quot;Screenshot captured for error diagnostics&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 11,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot captured for error diagnostics&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "RetrieveInvoicePdf.xaml",
      "workflow": "RetrieveInvoicePdf",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
      "resolvedValue": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 12,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
        "precedenceTier": 4
      }
    },
    {
      "file": "RetrieveInvoicePdf.xaml",
      "workflow": "RetrieveInvoicePdf",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;[Error] RetryScope: Download invoice PDF from Coupa with up to 3 attempts and 10s delay failed (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "resolvedValue": "[&quot;[Error] RetryScope: Download invoice PDF from Coupa with up to 3 attempts and 10s delay failed (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 13,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;[Error] RetryScope: Download invoice PDF from Coupa with up to 3 attempts",
        "precedenceTier": 4
      }
    },
    {
      "file": "RetrieveInvoicePdf.xaml",
      "workflow": "RetrieveInvoicePdf",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "\"\"",
      "resolvedValue": "\"\"",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 2,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "\"\"",
        "precedenceTier": 4
      }
    },
    {
      "file": "RetrieveInvoicePdf.xaml",
      "workflow": "RetrieveInvoicePdf",
      "activityType": "HttpClientRequest",
      "propertyName": "EndPoint",
      "sourceBinding": "attribute-value",
      "originalValue": "{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;InvoicePdfUrl&quot;}",
      "resolvedValue": "[InvoicePdfUrl]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;InvoicePdfUrl&quot",
        "precedenceTier": 4
      }
    },
    {
      "file": "RetrieveInvoicePdf.xaml",
      "workflow": "RetrieveInvoicePdf",
      "activityType": "HttpClientRequest",
      "propertyName": "Method",
      "sourceBinding": "attribute-value",
      "originalValue": "GET",
      "resolvedValue": "GET",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "GET",
        "precedenceTier": 4
      }
    },
    {
      "file": "RetrieveInvoicePdf.xaml",
      "workflow": "RetrieveInvoicePdf",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Retry exhausted for Download invoice PDF from Coupa URL to candidate local path, screenshot captured&quot;]",
      "resolvedValue": "[&quot;Retry exhausted for Download invoice PDF from Coupa URL to candidate local path, screenshot captured&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 15,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Retry exhausted for Download invoice PDF from Coupa URL to candidate loca",
        "precedenceTier": 4
      }
    },
    {
      "file": "RetrieveInvoicePdf.xaml",
      "workflow": "RetrieveInvoicePdf",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot capture failed: &quot; &amp; ssEx.Message]",
      "resolvedValue": "[&quot;Screenshot capture failed: &quot; &amp; ssEx.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 16,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot capture failed: &quot; &amp; ssEx.Message]",
        "precedenceTier": 4
      }
    },
    {
      "file": "RetrieveInvoicePdf.xaml",
      "workflow": "RetrieveInvoicePdf",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;[Retry Exhausted] Download invoice PDF from Coupa URL to candidate local path failed after retries — &quot; &amp; retryEx.Message]",
      "resolvedValue": "[&quot;[Retry Exhausted] Download invoice PDF from Coupa URL to candidate local path failed after retries — &quot; &amp; retryEx.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 17,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;[Retry Exhausted] Download invoice PDF from Coupa URL to candidate local ",
        "precedenceTier": 4
      }
    },
    {
      "file": "RetrieveInvoicePdf.xaml",
      "workflow": "RetrieveInvoicePdf",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "[True]",
      "resolvedValue": "[True]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 3,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[True]",
        "precedenceTier": 4
      }
    },
    {
      "file": "RetrieveInvoicePdf.xaml",
      "workflow": "RetrieveInvoicePdf",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Try block: TryCatch: Attempt to assign resolvedLocalPath; handle file lock with alternate name&quot;]",
      "resolvedValue": "[&quot;Try block: TryCatch: Attempt to assign resolvedLocalPath; handle file lock with alternate name&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 18,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Try block: TryCatch: Attempt to assign resolvedLocalPath; handle file loc",
        "precedenceTier": 4
      }
    },
    {
      "file": "RetrieveInvoicePdf.xaml",
      "workflow": "RetrieveInvoicePdf",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Error in TryCatch: Attempt to assign resolvedLocalPath; handle file lock with alternate name: &quot; &amp; exception.Message]",
      "resolvedValue": "[&quot;Error in TryCatch: Attempt to assign resolvedLocalPath; handle file lock with alternate name: &quot; &amp; exception.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 19,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Error in TryCatch: Attempt to assign resolvedLocalPath; handle file lock ",
        "precedenceTier": 4
      }
    },
    {
      "file": "RetrieveInvoicePdf.xaml",
      "workflow": "RetrieveInvoicePdf",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot captured for error diagnostics&quot;]",
      "resolvedValue": "[&quot;Screenshot captured for error diagnostics&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 20,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot captured for error diagnostics&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "RetrieveInvoicePdf.xaml",
      "workflow": "RetrieveInvoicePdf",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
      "resolvedValue": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 21,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
        "precedenceTier": 4
      }
    },
    {
      "file": "RetrieveInvoicePdf.xaml",
      "workflow": "RetrieveInvoicePdf",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;[Error] TryCatch: Attempt to assign resolvedLocalPath; handle file lock with alternate name failed (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "resolvedValue": "[&quot;[Error] TryCatch: Attempt to assign resolvedLocalPath; handle file lock with alternate name failed (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 22,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;[Error] TryCatch: Attempt to assign resolvedLocalPath; handle file lock w",
        "precedenceTier": 4
      }
    },
    {
      "file": "RetrieveInvoicePdf.xaml",
      "workflow": "RetrieveInvoicePdf",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "[DateTime.UtcNow.Ticks.ToString()]",
      "resolvedValue": "[DateTime.UtcNow.Ticks.ToString()]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 4,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[DateTime.UtcNow.Ticks.ToString()]",
        "precedenceTier": 4
      }
    },
    {
      "file": "RetrieveInvoicePdf.xaml",
      "workflow": "RetrieveInvoicePdf",
      "activityType": "If",
      "propertyName": "Condition",
      "sourceBinding": "attribute-value",
      "originalValue": "[{&quot;type&quot;:&quot;expression&quot;,&quot;left&quot;:&quot;fileLockDetected&quot;,&quot;operator&quot;:&quot;=&quot;,&quot;right&quot;:&quot;True&quot;}]",
      "resolvedValue": "[{&quot;type&quot;:&quot;expression&quot;,&quot;left&quot;:&quot;fileLockDetected&quot;,&quot;operator&quot;:&quot;=&quot;,&quot;right&quot;:&quot;True&quot;}]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 1,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[{&quot;type&quot;:&quot;expression&quot;,&quot;left&quot;:&quot;fileLockDetecte",
        "precedenceTier": 4
      }
    },
    {
      "file": "RetrieveInvoicePdf.xaml",
      "workflow": "RetrieveInvoicePdf",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Then path: Build alternate local path when file lock is detected&quot;]",
      "resolvedValue": "[&quot;Then path: Build alternate local path when file lock is detected&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 23,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Then path: Build alternate local path when file lock is detected&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "RetrieveInvoicePdf.xaml",
      "workflow": "RetrieveInvoicePdf",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Else path: Build alternate local path when file lock is detected&quot;]",
      "resolvedValue": "[&quot;Else path: Build alternate local path when file lock is detected&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 24,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Else path: Build alternate local path when file lock is detected&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "RetrieveInvoicePdf.xaml",
      "workflow": "RetrieveInvoicePdf",
      "activityType": "If",
      "propertyName": "Condition",
      "sourceBinding": "attribute-value",
      "originalValue": "[{&quot;type&quot;:&quot;expression&quot;,&quot;left&quot;:&quot;fileLockDetected&quot;,&quot;operator&quot;:&quot;=&quot;,&quot;right&quot;:&quot;True&quot;}]",
      "resolvedValue": "[{&quot;type&quot;:&quot;expression&quot;,&quot;left&quot;:&quot;fileLockDetected&quot;,&quot;operator&quot;:&quot;=&quot;,&quot;right&quot;:&quot;True&quot;}]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 2,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[{&quot;type&quot;:&quot;expression&quot;,&quot;left&quot;:&quot;fileLockDetecte",
        "precedenceTier": 4
      }
    },
    {
      "file": "RetrieveInvoicePdf.xaml",
      "workflow": "RetrieveInvoicePdf",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Then path: Copy downloaded file to resolved path if alternate path was chosen&quot;]",
      "resolvedValue": "[&quot;Then path: Copy downloaded file to resolved path if alternate path was chosen&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 26,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Then path: Copy downloaded file to resolved path if alternate path was ch",
        "precedenceTier": 4
      }
    },
    {
      "file": "RetrieveInvoicePdf.xaml",
      "workflow": "RetrieveInvoicePdf",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Else path: Copy downloaded file to resolved path if alternate path was chosen&quot;]",
      "resolvedValue": "[&quot;Else path: Copy downloaded file to resolved path if alternate path was chosen&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 27,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Else path: Copy downloaded file to resolved path if alternate path was ch",
        "precedenceTier": 4
      }
    },
    {
      "file": "RetrieveInvoicePdf.xaml",
      "workflow": "RetrieveInvoicePdf",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot captured for error diagnostics&quot;]",
      "resolvedValue": "[&quot;Screenshot captured for error diagnostics&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 28,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot captured for error diagnostics&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "RetrieveInvoicePdf.xaml",
      "workflow": "RetrieveInvoicePdf",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
      "resolvedValue": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 29,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
        "precedenceTier": 4
      }
    },
    {
      "file": "RetrieveInvoicePdf.xaml",
      "workflow": "RetrieveInvoicePdf",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;[Error] Copy downloaded file to resolved path if alternate path was chosen failed (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "resolvedValue": "[&quot;[Error] Copy downloaded file to resolved path if alternate path was chosen failed (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 30,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;[Error] Copy downloaded file to resolved path if alternate path was chose",
        "precedenceTier": 4
      }
    },
    {
      "file": "RetrieveInvoicePdf.xaml",
      "workflow": "RetrieveInvoicePdf",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "\"\"",
      "resolvedValue": "\"\"",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 5,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "\"\"",
        "precedenceTier": 4
      }
    },
    {
      "file": "RetrieveInvoicePdf.xaml",
      "workflow": "RetrieveInvoicePdf",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot captured for error diagnostics&quot;]",
      "resolvedValue": "[&quot;Screenshot captured for error diagnostics&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 31,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot captured for error diagnostics&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "RetrieveInvoicePdf.xaml",
      "workflow": "RetrieveInvoicePdf",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
      "resolvedValue": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 32,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
        "precedenceTier": 4
      }
    },
    {
      "file": "RetrieveInvoicePdf.xaml",
      "workflow": "RetrieveInvoicePdf",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;[Error] Read file size of resolved local PDF for logging and validation failed (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "resolvedValue": "[&quot;[Error] Read file size of resolved local PDF for logging and validation failed (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 33,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;[Error] Read file size of resolved local PDF for logging and validation f",
        "precedenceTier": 4
      }
    },
    {
      "file": "RetrieveInvoicePdf.xaml",
      "workflow": "RetrieveInvoicePdf",
      "activityType": "If",
      "propertyName": "Condition",
      "sourceBinding": "attribute-value",
      "originalValue": "[{&quot;type&quot;:&quot;expression&quot;,&quot;left&quot;:&quot;fileSizeBytes&quot;,&quot;operator&quot;:&quot;&lt;=&quot;,&quot;right&quot;:&quot;0&quot;}]",
      "resolvedValue": "[{&quot;type&quot;:&quot;expression&quot;,&quot;left&quot;:&quot;fileSizeBytes&quot;,&quot;operator&quot;:&quot;&lt;=&quot;,&quot;right&quot;:&quot;0&quot;}]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 3,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[{&quot;type&quot;:&quot;expression&quot;,&quot;left&quot;:&quot;fileSizeBytes&q",
        "precedenceTier": 4
      }
    },
    {
      "file": "RetrieveInvoicePdf.xaml",
      "workflow": "RetrieveInvoicePdf",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Then path: Guard: fail fast if downloaded file is empty (0 bytes)&quot;]",
      "resolvedValue": "[&quot;Then path: Guard: fail fast if downloaded file is empty (0 bytes)&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 34,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Then path: Guard: fail fast if downloaded file is empty (0 bytes)&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "RetrieveInvoicePdf.xaml",
      "workflow": "RetrieveInvoicePdf",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Else path: Guard: fail fast if downloaded file is empty (0 bytes)&quot;]",
      "resolvedValue": "[&quot;Else path: Guard: fail fast if downloaded file is empty (0 bytes)&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 35,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Else path: Guard: fail fast if downloaded file is empty (0 bytes)&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "RetrieveInvoicePdf.xaml",
      "workflow": "RetrieveInvoicePdf",
      "activityType": "HttpClientRequest",
      "propertyName": "EndPoint",
      "sourceBinding": "attribute-value",
      "originalValue": "{&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;\\&quot;https://cloud.uipath.com/orchestrator_/odata/Buckets/UiPath.Server.Configuration.OData.GetWriteUri?path=\\&quot; &amp; bucketPathResolved &amp; \\&quot;&amp;bucketName=SB_CoupaInvoiceRecon_Invoices\\&quot;&quot;}",
      "resolvedValue": "[\"https://cloud.uipath.com/orchestrator_/odata/Buckets/UiPath.Server.Configuration.OData.GetWriteUri?path=\" & bucketPathResolved & \"&bucketName=SB_CoupaInvoiceRecon_Invoices\"]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 1,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "{&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;\\&quot;https",
        "precedenceTier": 4
      }
    },
    {
      "file": "RetrieveInvoicePdf.xaml",
      "workflow": "RetrieveInvoicePdf",
      "activityType": "HttpClientRequest",
      "propertyName": "Method",
      "sourceBinding": "attribute-value",
      "originalValue": "POST",
      "resolvedValue": "POST",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 1,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "POST",
        "precedenceTier": 4
      }
    },
    {
      "file": "RetrieveInvoicePdf.xaml",
      "workflow": "RetrieveInvoicePdf",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Retry exhausted for Upload resolved local PDF to Storage Bucket SB_CoupaInvoiceRecon_Invoices, screenshot captured&quot;]",
      "resolvedValue": "[&quot;Retry exhausted for Upload resolved local PDF to Storage Bucket SB_CoupaInvoiceRecon_Invoices, screenshot captured&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 36,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Retry exhausted for Upload resolved local PDF to Storage Bucket SB_CoupaI",
        "precedenceTier": 4
      }
    },
    {
      "file": "RetrieveInvoicePdf.xaml",
      "workflow": "RetrieveInvoicePdf",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot capture failed: &quot; &amp; ssEx.Message]",
      "resolvedValue": "[&quot;Screenshot capture failed: &quot; &amp; ssEx.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 37,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot capture failed: &quot; &amp; ssEx.Message]",
        "precedenceTier": 4
      }
    },
    {
      "file": "RetrieveInvoicePdf.xaml",
      "workflow": "RetrieveInvoicePdf",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;[Retry Exhausted] Upload resolved local PDF to Storage Bucket SB_CoupaInvoiceRecon_Invoices failed after retries — &quot; &amp; retryEx.Message]",
      "resolvedValue": "[&quot;[Retry Exhausted] Upload resolved local PDF to Storage Bucket SB_CoupaInvoiceRecon_Invoices failed after retries — &quot; &amp; retryEx.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 38,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;[Retry Exhausted] Upload resolved local PDF to Storage Bucket SB_CoupaInv",
        "precedenceTier": 4
      }
    },
    {
      "file": "RetrieveInvoicePdf.xaml",
      "workflow": "RetrieveInvoicePdf",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "\"\"",
      "resolvedValue": "\"\"",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 6,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "\"\"",
        "precedenceTier": 4
      }
    },
    {
      "file": "RetrieveInvoicePdf.xaml",
      "workflow": "RetrieveInvoicePdf",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "\"\"",
      "resolvedValue": "\"\"",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 7,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "\"\"",
        "precedenceTier": 4
      }
    },
    {
      "file": "RetrieveInvoicePdf.xaml",
      "workflow": "RetrieveInvoicePdf",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;=== Completed: RetrieveInvoicePdf ===&quot;]",
      "resolvedValue": "[&quot;=== Completed: RetrieveInvoicePdf ===&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 40,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;=== Completed: RetrieveInvoicePdf ===&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "ExtractInvoiceFields.xaml",
      "workflow": "ExtractInvoiceFields",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;=== Starting: ExtractInvoiceFields ===&quot;]",
      "resolvedValue": "[&quot;=== Starting: ExtractInvoiceFields ===&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;=== Starting: ExtractInvoiceFields ===&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "ExtractInvoiceFields.xaml",
      "workflow": "ExtractInvoiceFields",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "\"\"",
      "resolvedValue": "\"\"",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "\"\"",
        "precedenceTier": 4
      }
    },
    {
      "file": "ExtractInvoiceFields.xaml",
      "workflow": "ExtractInvoiceFields",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot captured for error diagnostics&quot;]",
      "resolvedValue": "[&quot;Screenshot captured for error diagnostics&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 2,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot captured for error diagnostics&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "ExtractInvoiceFields.xaml",
      "workflow": "ExtractInvoiceFields",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
      "resolvedValue": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 3,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
        "precedenceTier": 4
      }
    },
    {
      "file": "ExtractInvoiceFields.xaml",
      "workflow": "ExtractInvoiceFields",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;[Error] Read confidence threshold from Config dictionary failed (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "resolvedValue": "[&quot;[Error] Read confidence threshold from Config dictionary failed (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 4,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;[Error] Read confidence threshold from Config dictionary failed (&quot; &",
        "precedenceTier": 4
      }
    },
    {
      "file": "ExtractInvoiceFields.xaml",
      "workflow": "ExtractInvoiceFields",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "\"\"",
      "resolvedValue": "\"\"",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 1,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "\"\"",
        "precedenceTier": 4
      }
    },
    {
      "file": "ExtractInvoiceFields.xaml",
      "workflow": "ExtractInvoiceFields",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot captured for error diagnostics&quot;]",
      "resolvedValue": "[&quot;Screenshot captured for error diagnostics&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 5,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot captured for error diagnostics&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "ExtractInvoiceFields.xaml",
      "workflow": "ExtractInvoiceFields",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
      "resolvedValue": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 6,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
        "precedenceTier": 4
      }
    },
    {
      "file": "ExtractInvoiceFields.xaml",
      "workflow": "ExtractInvoiceFields",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;[Error] Digitize invoice PDF document (OCR pipeline) failed (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "resolvedValue": "[&quot;[Error] Digitize invoice PDF document (OCR pipeline) failed (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 7,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;[Error] Digitize invoice PDF document (OCR pipeline) failed (&quot; &amp;",
        "precedenceTier": 4
      }
    },
    {
      "file": "ExtractInvoiceFields.xaml",
      "workflow": "ExtractInvoiceFields",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot captured for error diagnostics&quot;]",
      "resolvedValue": "[&quot;Screenshot captured for error diagnostics&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 9,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot captured for error diagnostics&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "ExtractInvoiceFields.xaml",
      "workflow": "ExtractInvoiceFields",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
      "resolvedValue": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 10,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
        "precedenceTier": 4
      }
    },
    {
      "file": "ExtractInvoiceFields.xaml",
      "workflow": "ExtractInvoiceFields",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;[Error] Extract invoice fields using ML extractor (Invoice taxonomy) failed (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "resolvedValue": "[&quot;[Error] Extract invoice fields using ML extractor (Invoice taxonomy) failed (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 11,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;[Error] Extract invoice fields using ML extractor (Invoice taxonomy) fail",
        "precedenceTier": 4
      }
    },
    {
      "file": "ExtractInvoiceFields.xaml",
      "workflow": "ExtractInvoiceFields",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "\"\"",
      "resolvedValue": "\"\"",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 2,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "\"\"",
        "precedenceTier": 4
      }
    },
    {
      "file": "ExtractInvoiceFields.xaml",
      "workflow": "ExtractInvoiceFields",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot captured for error diagnostics&quot;]",
      "resolvedValue": "[&quot;Screenshot captured for error diagnostics&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 13,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot captured for error diagnostics&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "ExtractInvoiceFields.xaml",
      "workflow": "ExtractInvoiceFields",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
      "resolvedValue": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 14,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
        "precedenceTier": 4
      }
    },
    {
      "file": "ExtractInvoiceFields.xaml",
      "workflow": "ExtractInvoiceFields",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;[Error] Read extracted PONumber value from results failed (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "resolvedValue": "[&quot;[Error] Read extracted PONumber value from results failed (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 15,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;[Error] Read extracted PONumber value from results failed (&quot; &amp; e",
        "precedenceTier": 4
      }
    },
    {
      "file": "ExtractInvoiceFields.xaml",
      "workflow": "ExtractInvoiceFields",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "\"\"",
      "resolvedValue": "\"\"",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 3,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "\"\"",
        "precedenceTier": 4
      }
    },
    {
      "file": "ExtractInvoiceFields.xaml",
      "workflow": "ExtractInvoiceFields",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot captured for error diagnostics&quot;]",
      "resolvedValue": "[&quot;Screenshot captured for error diagnostics&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 16,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot captured for error diagnostics&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "ExtractInvoiceFields.xaml",
      "workflow": "ExtractInvoiceFields",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
      "resolvedValue": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 17,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
        "precedenceTier": 4
      }
    },
    {
      "file": "ExtractInvoiceFields.xaml",
      "workflow": "ExtractInvoiceFields",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;[Error] Read extracted InvoiceNumber value from results failed (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "resolvedValue": "[&quot;[Error] Read extracted InvoiceNumber value from results failed (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 18,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;[Error] Read extracted InvoiceNumber value from results failed (&quot; &a",
        "precedenceTier": 4
      }
    },
    {
      "file": "ExtractInvoiceFields.xaml",
      "workflow": "ExtractInvoiceFields",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "\"\"",
      "resolvedValue": "\"\"",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 4,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "\"\"",
        "precedenceTier": 4
      }
    },
    {
      "file": "ExtractInvoiceFields.xaml",
      "workflow": "ExtractInvoiceFields",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot captured for error diagnostics&quot;]",
      "resolvedValue": "[&quot;Screenshot captured for error diagnostics&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 19,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot captured for error diagnostics&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "ExtractInvoiceFields.xaml",
      "workflow": "ExtractInvoiceFields",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
      "resolvedValue": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 20,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
        "precedenceTier": 4
      }
    },
    {
      "file": "ExtractInvoiceFields.xaml",
      "workflow": "ExtractInvoiceFields",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;[Error] Read extracted VendorName value from results failed (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "resolvedValue": "[&quot;[Error] Read extracted VendorName value from results failed (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 21,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;[Error] Read extracted VendorName value from results failed (&quot; &amp;",
        "precedenceTier": 4
      }
    },
    {
      "file": "ExtractInvoiceFields.xaml",
      "workflow": "ExtractInvoiceFields",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "\"\"",
      "resolvedValue": "\"\"",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 5,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "\"\"",
        "precedenceTier": 4
      }
    },
    {
      "file": "ExtractInvoiceFields.xaml",
      "workflow": "ExtractInvoiceFields",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot captured for error diagnostics&quot;]",
      "resolvedValue": "[&quot;Screenshot captured for error diagnostics&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 22,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot captured for error diagnostics&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "ExtractInvoiceFields.xaml",
      "workflow": "ExtractInvoiceFields",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
      "resolvedValue": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 23,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
        "precedenceTier": 4
      }
    },
    {
      "file": "ExtractInvoiceFields.xaml",
      "workflow": "ExtractInvoiceFields",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;[Error] Read extracted TotalAmount value from results failed (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "resolvedValue": "[&quot;[Error] Read extracted TotalAmount value from results failed (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 24,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;[Error] Read extracted TotalAmount value from results failed (&quot; &amp",
        "precedenceTier": 4
      }
    },
    {
      "file": "ExtractInvoiceFields.xaml",
      "workflow": "ExtractInvoiceFields",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "\"\"",
      "resolvedValue": "\"\"",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 6,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "\"\"",
        "precedenceTier": 4
      }
    },
    {
      "file": "ExtractInvoiceFields.xaml",
      "workflow": "ExtractInvoiceFields",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot captured for error diagnostics&quot;]",
      "resolvedValue": "[&quot;Screenshot captured for error diagnostics&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 25,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot captured for error diagnostics&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "ExtractInvoiceFields.xaml",
      "workflow": "ExtractInvoiceFields",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
      "resolvedValue": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 26,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
        "precedenceTier": 4
      }
    },
    {
      "file": "ExtractInvoiceFields.xaml",
      "workflow": "ExtractInvoiceFields",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;[Error] Read extracted Currency value from results failed (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "resolvedValue": "[&quot;[Error] Read extracted Currency value from results failed (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 27,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;[Error] Read extracted Currency value from results failed (&quot; &amp; e",
        "precedenceTier": 4
      }
    },
    {
      "file": "ExtractInvoiceFields.xaml",
      "workflow": "ExtractInvoiceFields",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "\"\"",
      "resolvedValue": "\"\"",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 7,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "\"\"",
        "precedenceTier": 4
      }
    },
    {
      "file": "ExtractInvoiceFields.xaml",
      "workflow": "ExtractInvoiceFields",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot captured for error diagnostics&quot;]",
      "resolvedValue": "[&quot;Screenshot captured for error diagnostics&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 28,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot captured for error diagnostics&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "ExtractInvoiceFields.xaml",
      "workflow": "ExtractInvoiceFields",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
      "resolvedValue": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 29,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
        "precedenceTier": 4
      }
    },
    {
      "file": "ExtractInvoiceFields.xaml",
      "workflow": "ExtractInvoiceFields",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;[Error] Read extracted InvoiceDate value from results failed (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "resolvedValue": "[&quot;[Error] Read extracted InvoiceDate value from results failed (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 30,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;[Error] Read extracted InvoiceDate value from results failed (&quot; &amp",
        "precedenceTier": 4
      }
    },
    {
      "file": "ExtractInvoiceFields.xaml",
      "workflow": "ExtractInvoiceFields",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "\"\"",
      "resolvedValue": "\"\"",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 8,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "\"\"",
        "precedenceTier": 4
      }
    },
    {
      "file": "ExtractInvoiceFields.xaml",
      "workflow": "ExtractInvoiceFields",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot captured for error diagnostics&quot;]",
      "resolvedValue": "[&quot;Screenshot captured for error diagnostics&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 31,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot captured for error diagnostics&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "ExtractInvoiceFields.xaml",
      "workflow": "ExtractInvoiceFields",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
      "resolvedValue": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 32,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
        "precedenceTier": 4
      }
    },
    {
      "file": "ExtractInvoiceFields.xaml",
      "workflow": "ExtractInvoiceFields",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;[Error] Read PONumber field confidence score from extraction results failed (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "resolvedValue": "[&quot;[Error] Read PONumber field confidence score from extraction results failed (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 33,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;[Error] Read PONumber field confidence score from extraction results fail",
        "precedenceTier": 4
      }
    },
    {
      "file": "ExtractInvoiceFields.xaml",
      "workflow": "ExtractInvoiceFields",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "\"\"",
      "resolvedValue": "\"\"",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 9,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "\"\"",
        "precedenceTier": 4
      }
    },
    {
      "file": "ExtractInvoiceFields.xaml",
      "workflow": "ExtractInvoiceFields",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot captured for error diagnostics&quot;]",
      "resolvedValue": "[&quot;Screenshot captured for error diagnostics&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 34,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot captured for error diagnostics&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "ExtractInvoiceFields.xaml",
      "workflow": "ExtractInvoiceFields",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
      "resolvedValue": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 35,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
        "precedenceTier": 4
      }
    },
    {
      "file": "ExtractInvoiceFields.xaml",
      "workflow": "ExtractInvoiceFields",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;[Error] Read InvoiceNumber field confidence score from extraction results failed (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "resolvedValue": "[&quot;[Error] Read InvoiceNumber field confidence score from extraction results failed (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 36,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;[Error] Read InvoiceNumber field confidence score from extraction results",
        "precedenceTier": 4
      }
    },
    {
      "file": "ExtractInvoiceFields.xaml",
      "workflow": "ExtractInvoiceFields",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "\"\"",
      "resolvedValue": "\"\"",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 10,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "\"\"",
        "precedenceTier": 4
      }
    },
    {
      "file": "ExtractInvoiceFields.xaml",
      "workflow": "ExtractInvoiceFields",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot captured for error diagnostics&quot;]",
      "resolvedValue": "[&quot;Screenshot captured for error diagnostics&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 37,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot captured for error diagnostics&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "ExtractInvoiceFields.xaml",
      "workflow": "ExtractInvoiceFields",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
      "resolvedValue": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 38,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
        "precedenceTier": 4
      }
    },
    {
      "file": "ExtractInvoiceFields.xaml",
      "workflow": "ExtractInvoiceFields",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;[Error] Read VendorName field confidence score from extraction results failed (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "resolvedValue": "[&quot;[Error] Read VendorName field confidence score from extraction results failed (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 39,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;[Error] Read VendorName field confidence score from extraction results fa",
        "precedenceTier": 4
      }
    },
    {
      "file": "ExtractInvoiceFields.xaml",
      "workflow": "ExtractInvoiceFields",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "\"\"",
      "resolvedValue": "\"\"",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 11,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "\"\"",
        "precedenceTier": 4
      }
    },
    {
      "file": "ExtractInvoiceFields.xaml",
      "workflow": "ExtractInvoiceFields",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot captured for error diagnostics&quot;]",
      "resolvedValue": "[&quot;Screenshot captured for error diagnostics&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 40,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot captured for error diagnostics&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "ExtractInvoiceFields.xaml",
      "workflow": "ExtractInvoiceFields",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
      "resolvedValue": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 41,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
        "precedenceTier": 4
      }
    },
    {
      "file": "ExtractInvoiceFields.xaml",
      "workflow": "ExtractInvoiceFields",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;[Error] Read TotalAmount field confidence score from extraction results failed (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "resolvedValue": "[&quot;[Error] Read TotalAmount field confidence score from extraction results failed (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 42,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;[Error] Read TotalAmount field confidence score from extraction results f",
        "precedenceTier": 4
      }
    },
    {
      "file": "ExtractInvoiceFields.xaml",
      "workflow": "ExtractInvoiceFields",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;[ExtractInvoiceFields] ExtractedValues — CoupaInvoiceId=&quot; &amp; CoupaInvoiceId &amp; &quot; | PONumber=&apos;&quot; &amp; rawPoNumber &amp; &quot;&apos; | InvoiceNumber=&apos;&quot; &amp; rawInvoiceNumber &amp; &quot;&apos; | VendorName=&apos;&quot; &amp; rawVendorName &amp; &quot;&apos; | TotalAmount=&apos;&quot; &amp; rawInvoiceTotal &amp; &quot;&apos; | Currency=&apos;&quot; &amp; rawCurrency &amp; &quot;&apos; | InvoiceDate=&apos;&quot; &amp; rawInvoiceDate &amp; &quot;&apos;&quot;]",
      "resolvedValue": "[&quot;[ExtractInvoiceFields] ExtractedValues — CoupaInvoiceId=&quot; &amp; CoupaInvoiceId &amp; &quot; | PONumber=&apos;&quot; &amp; rawPoNumber &amp; &quot;&apos; | InvoiceNumber=&apos;&quot; &amp; rawInvoiceNumber &amp; &quot;&apos; | VendorName=&apos;&quot; &amp; rawVendorName &amp; &quot;&apos; | TotalAmount=&apos;&quot; &amp; rawInvoiceTotal &amp; &quot;&apos; | Currency=&apos;&quot; &amp; rawCurrency &amp; &quot;&apos; | InvoiceDate=&apos;&quot; &amp; rawInvoiceDate &amp; &quot;&apos;&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 44,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;[ExtractInvoiceFields] ExtractedValues — CoupaInvoiceId=&quot; &amp; Coup",
        "precedenceTier": 4
      }
    },
    {
      "file": "ExtractInvoiceFields.xaml",
      "workflow": "ExtractInvoiceFields",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "\"\"",
      "resolvedValue": "\"\"",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 12,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "\"\"",
        "precedenceTier": 4
      }
    },
    {
      "file": "ExtractInvoiceFields.xaml",
      "workflow": "ExtractInvoiceFields",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "\"\"",
      "resolvedValue": "\"\"",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 13,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "\"\"",
        "precedenceTier": 4
      }
    },
    {
      "file": "ExtractInvoiceFields.xaml",
      "workflow": "ExtractInvoiceFields",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "\"\"",
      "resolvedValue": "\"\"",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 14,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "\"\"",
        "precedenceTier": 4
      }
    },
    {
      "file": "ExtractInvoiceFields.xaml",
      "workflow": "ExtractInvoiceFields",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "\"\"",
      "resolvedValue": "\"\"",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 15,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "\"\"",
        "precedenceTier": 4
      }
    },
    {
      "file": "ExtractInvoiceFields.xaml",
      "workflow": "ExtractInvoiceFields",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "\"\"",
      "resolvedValue": "\"\"",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 16,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "\"\"",
        "precedenceTier": 4
      }
    },
    {
      "file": "ExtractInvoiceFields.xaml",
      "workflow": "ExtractInvoiceFields",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "\"\"",
      "resolvedValue": "\"\"",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 17,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "\"\"",
        "precedenceTier": 4
      }
    },
    {
      "file": "ExtractInvoiceFields.xaml",
      "workflow": "ExtractInvoiceFields",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "\"\"",
      "resolvedValue": "\"\"",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 18,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "\"\"",
        "precedenceTier": 4
      }
    },
    {
      "file": "ExtractInvoiceFields.xaml",
      "workflow": "ExtractInvoiceFields",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "\"\"",
      "resolvedValue": "\"\"",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 19,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "\"\"",
        "precedenceTier": 4
      }
    },
    {
      "file": "ExtractInvoiceFields.xaml",
      "workflow": "ExtractInvoiceFields",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;[ExtractInvoiceFields] END — CoupaInvoiceId=&quot; &amp; CoupaInvoiceId &amp; &quot; | OverallConfidence=&quot; &amp; ExtractionConfidence &amp; &quot; | NeedsHumanValidation=&quot; &amp; NeedsHumanValidation.ToString() &amp; &quot; | ExtractedPO=&apos;&quot; &amp; ExtractedPONumber &amp; &quot;&apos; | ExtractedTotal=&apos;&quot; &amp; ExtractedInvoiceTotal &amp; &quot;&apos;&quot;]",
      "resolvedValue": "[&quot;[ExtractInvoiceFields] END — CoupaInvoiceId=&quot; &amp; CoupaInvoiceId &amp; &quot; | OverallConfidence=&quot; &amp; ExtractionConfidence &amp; &quot; | NeedsHumanValidation=&quot; &amp; NeedsHumanValidation.ToString() &amp; &quot; | ExtractedPO=&apos;&quot; &amp; ExtractedPONumber &amp; &quot;&apos; | ExtractedTotal=&apos;&quot; &amp; ExtractedInvoiceTotal &amp; &quot;&apos;&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 46,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;[ExtractInvoiceFields] END — CoupaInvoiceId=&quot; &amp; CoupaInvoiceId &",
        "precedenceTier": 4
      }
    },
    {
      "file": "ExtractInvoiceFields.xaml",
      "workflow": "ExtractInvoiceFields",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;=== Completed: ExtractInvoiceFields ===&quot;]",
      "resolvedValue": "[&quot;=== Completed: ExtractInvoiceFields ===&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 47,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;=== Completed: ExtractInvoiceFields ===&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "CreateValidationTask.xaml",
      "workflow": "CreateValidationTask",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;=== Starting: CreateValidationTask ===&quot;]",
      "resolvedValue": "[&quot;=== Starting: CreateValidationTask ===&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;=== Starting: CreateValidationTask ===&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "CreateValidationTask.xaml",
      "workflow": "CreateValidationTask",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot captured for error diagnostics&quot;]",
      "resolvedValue": "[&quot;Screenshot captured for error diagnostics&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 2,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot captured for error diagnostics&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "CreateValidationTask.xaml",
      "workflow": "CreateValidationTask",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
      "resolvedValue": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 3,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
        "precedenceTier": 4
      }
    },
    {
      "file": "CreateValidationTask.xaml",
      "workflow": "CreateValidationTask",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;[Error] Read ActionCenter.SLAHours asset from Orchestrator failed (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "resolvedValue": "[&quot;[Error] Read ActionCenter.SLAHours asset from Orchestrator failed (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 4,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;[Error] Read ActionCenter.SLAHours asset from Orchestrator failed (&quot;",
        "precedenceTier": 4
      }
    },
    {
      "file": "CreateValidationTask.xaml",
      "workflow": "CreateValidationTask",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "\"\"",
      "resolvedValue": "\"\"",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "\"\"",
        "precedenceTier": 4
      }
    },
    {
      "file": "CreateValidationTask.xaml",
      "workflow": "CreateValidationTask",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "\"\"",
      "resolvedValue": "\"\"",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 1,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "\"\"",
        "precedenceTier": 4
      }
    },
    {
      "file": "CreateValidationTask.xaml",
      "workflow": "CreateValidationTask",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "\"\"",
      "resolvedValue": "\"\"",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 2,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "\"\"",
        "precedenceTier": 4
      }
    },
    {
      "file": "CreateValidationTask.xaml",
      "workflow": "CreateValidationTask",
      "activityType": "QueryEntity",
      "propertyName": "EntityType",
      "sourceBinding": "attribute-value",
      "originalValue": "InvoiceCase",
      "resolvedValue": "InvoiceCase",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "InvoiceCase",
        "precedenceTier": 4
      }
    },
    {
      "file": "CreateValidationTask.xaml",
      "workflow": "CreateValidationTask",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot captured for error diagnostics&quot;]",
      "resolvedValue": "[&quot;Screenshot captured for error diagnostics&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 5,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot captured for error diagnostics&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "CreateValidationTask.xaml",
      "workflow": "CreateValidationTask",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
      "resolvedValue": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 6,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
        "precedenceTier": 4
      }
    },
    {
      "file": "CreateValidationTask.xaml",
      "workflow": "CreateValidationTask",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;[Error] Query Data Service for existing InvoiceCase by CoupaInvoiceId failed (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "resolvedValue": "[&quot;[Error] Query Data Service for existing InvoiceCase by CoupaInvoiceId failed (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 7,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;[Error] Query Data Service for existing InvoiceCase by CoupaInvoiceId fai",
        "precedenceTier": 4
      }
    },
    {
      "file": "CreateValidationTask.xaml",
      "workflow": "CreateValidationTask",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "\"\"",
      "resolvedValue": "\"\"",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 3,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "\"\"",
        "precedenceTier": 4
      }
    },
    {
      "file": "CreateValidationTask.xaml",
      "workflow": "CreateValidationTask",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "\"\"",
      "resolvedValue": "\"\"",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 4,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "\"\"",
        "precedenceTier": 4
      }
    },
    {
      "file": "CreateValidationTask.xaml",
      "workflow": "CreateValidationTask",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "\"\"",
      "resolvedValue": "\"\"",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 5,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "\"\"",
        "precedenceTier": 4
      }
    },
    {
      "file": "CreateValidationTask.xaml",
      "workflow": "CreateValidationTask",
      "activityType": "CreateFormTask",
      "propertyName": "Title",
      "sourceBinding": "attribute-value",
      "originalValue": "{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;taskTitle&quot;}",
      "resolvedValue": "[taskTitle]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;taskTitle&quot;}",
        "precedenceTier": 4
      }
    },
    {
      "file": "CreateValidationTask.xaml",
      "workflow": "CreateValidationTask",
      "activityType": "CreateFormTask",
      "propertyName": "FormSchemaPath",
      "sourceBinding": "attribute-value",
      "originalValue": "AC_CoupaInvoiceRecon_DUValidation",
      "resolvedValue": "AC_CoupaInvoiceRecon_DUValidation",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "AC_CoupaInvoiceRecon_DUValidation",
        "precedenceTier": 4
      }
    },
    {
      "file": "CreateValidationTask.xaml",
      "workflow": "CreateValidationTask",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot captured for error diagnostics&quot;]",
      "resolvedValue": "[&quot;Screenshot captured for error diagnostics&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 8,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot captured for error diagnostics&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "CreateValidationTask.xaml",
      "workflow": "CreateValidationTask",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
      "resolvedValue": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 9,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
        "precedenceTier": 4
      }
    },
    {
      "file": "CreateValidationTask.xaml",
      "workflow": "CreateValidationTask",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;[Error] Create Action Center form task in AC_CoupaInvoiceRecon_DUValidation catalog failed (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "resolvedValue": "[&quot;[Error] Create Action Center form task in AC_CoupaInvoiceRecon_DUValidation catalog failed (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 10,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;[Error] Create Action Center form task in AC_CoupaInvoiceRecon_DUValidati",
        "precedenceTier": 4
      }
    },
    {
      "file": "CreateValidationTask.xaml",
      "workflow": "CreateValidationTask",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;[CreateValidationTask] Action Center task created — CoupaInvoiceId=&quot; &amp; CoupaInvoiceId &amp; &quot; | TaskId=&quot; &amp; createdTaskId &amp; &quot; | DueUtc=&quot; &amp; taskDueUtc.ToString(&quot;o&quot;) &amp; &quot; | Catalog=AC_CoupaInvoiceRecon_DUValidation&quot;]",
      "resolvedValue": "[&quot;[CreateValidationTask] Action Center task created — CoupaInvoiceId=&quot; &amp; CoupaInvoiceId &amp; &quot; | TaskId=&quot; &amp; createdTaskId &amp; &quot; | DueUtc=&quot; &amp; taskDueUtc.ToString(&quot;o&quot;) &amp; &quot; | Catalog=AC_CoupaInvoiceRecon_DUValidation&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 11,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;[CreateValidationTask] Action Center task created — CoupaInvoiceId=&quot;",
        "precedenceTier": 4
      }
    },
    {
      "file": "CreateValidationTask.xaml",
      "workflow": "CreateValidationTask",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "\"\"",
      "resolvedValue": "\"\"",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 6,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "\"\"",
        "precedenceTier": 4
      }
    },
    {
      "file": "CreateValidationTask.xaml",
      "workflow": "CreateValidationTask",
      "activityType": "UpdateEntity",
      "propertyName": "EntityType",
      "sourceBinding": "attribute-value",
      "originalValue": "InvoiceCase",
      "resolvedValue": "InvoiceCase",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "InvoiceCase",
        "precedenceTier": 4
      }
    },
    {
      "file": "CreateValidationTask.xaml",
      "workflow": "CreateValidationTask",
      "activityType": "UpdateEntity",
      "propertyName": "EntityObject",
      "sourceBinding": "attribute-value",
      "originalValue": "{&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;New With {.CoupaInvoiceId = CoupaInvoiceId, .CaseStatus = \\&quot;PendingValidation\\&quot;, .NeedsHumanValidation = True, .ValidationDueUtc = taskDueUtc}&quot;}",
      "resolvedValue": "[New With {.CoupaInvoiceId = CoupaInvoiceId, .CaseStatus = \"PendingValidation\", .NeedsHumanValidation = True, .ValidationDueUtc = taskDueUtc}]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "{&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;New With {.C",
        "precedenceTier": 4
      }
    },
    {
      "file": "CreateValidationTask.xaml",
      "workflow": "CreateValidationTask",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot captured for error diagnostics&quot;]",
      "resolvedValue": "[&quot;Screenshot captured for error diagnostics&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 12,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot captured for error diagnostics&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "CreateValidationTask.xaml",
      "workflow": "CreateValidationTask",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
      "resolvedValue": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 13,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
        "precedenceTier": 4
      }
    },
    {
      "file": "CreateValidationTask.xaml",
      "workflow": "CreateValidationTask",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;[Error] Update InvoiceCase status to PendingValidation in Data Service failed (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "resolvedValue": "[&quot;[Error] Update InvoiceCase status to PendingValidation in Data Service failed (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 14,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;[Error] Update InvoiceCase status to PendingValidation in Data Service fa",
        "precedenceTier": 4
      }
    },
    {
      "file": "CreateValidationTask.xaml",
      "workflow": "CreateValidationTask",
      "activityType": "CreateEntityRecord",
      "propertyName": "EntityType",
      "sourceBinding": "attribute-value",
      "originalValue": "InvoiceEventLog",
      "resolvedValue": "InvoiceEventLog",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "InvoiceEventLog",
        "precedenceTier": 4
      }
    },
    {
      "file": "CreateValidationTask.xaml",
      "workflow": "CreateValidationTask",
      "activityType": "CreateEntityRecord",
      "propertyName": "EntityObject",
      "sourceBinding": "attribute-value",
      "originalValue": "{&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;New With {.CoupaInvoiceId = CoupaInvoiceId, .EventUtc = DateTime.UtcNow, .EventType = \\&quot;ValidationTaskCreated\\&quot;, .EventDetail = \\&quot;Action Center task created. TaskId=\\&quot; &amp; createdTaskId &amp; \\&quot;; DueUtc=\\&quot; &amp; taskDueUtc.ToString(\\&quot;o\\&quot;) &amp; \\&quot;; Catalog=AC_CoupaInvoiceRecon_DUValidation\\&quot;}&quot;}",
      "resolvedValue": "[New With {.CoupaInvoiceId = CoupaInvoiceId, .EventUtc = DateTime.UtcNow, .EventType = \"ValidationTaskCreated\", .EventDetail = \"Action Center task created. TaskId=\" & createdTaskId & \"; DueUtc=\" & taskDueUtc.ToString(\"o\") & \"; Catalog=AC_CoupaInvoiceRecon_DUValidation\"}]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "{&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;New With {.C",
        "precedenceTier": 4
      }
    },
    {
      "file": "CreateValidationTask.xaml",
      "workflow": "CreateValidationTask",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot captured for error diagnostics&quot;]",
      "resolvedValue": "[&quot;Screenshot captured for error diagnostics&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 15,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot captured for error diagnostics&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "CreateValidationTask.xaml",
      "workflow": "CreateValidationTask",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
      "resolvedValue": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 16,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
        "precedenceTier": 4
      }
    },
    {
      "file": "CreateValidationTask.xaml",
      "workflow": "CreateValidationTask",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;[Error] Create InvoiceEventLog entry for ValidationTaskCreated event failed (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "resolvedValue": "[&quot;[Error] Create InvoiceEventLog entry for ValidationTaskCreated event failed (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 17,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;[Error] Create InvoiceEventLog entry for ValidationTaskCreated event fail",
        "precedenceTier": 4
      }
    },
    {
      "file": "CreateValidationTask.xaml",
      "workflow": "CreateValidationTask",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;=== Completed: CreateValidationTask ===&quot;]",
      "resolvedValue": "[&quot;=== Completed: CreateValidationTask ===&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 19,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;=== Completed: CreateValidationTask ===&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "ValidateAndDecide.xaml",
      "workflow": "ValidateAndDecide",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;=== Starting: ValidateAndDecide ===&quot;]",
      "resolvedValue": "[&quot;=== Starting: ValidateAndDecide ===&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;=== Starting: ValidateAndDecide ===&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "ValidateAndDecide.xaml",
      "workflow": "ValidateAndDecide",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "\"\"",
      "resolvedValue": "\"\"",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "\"\"",
        "precedenceTier": 4
      }
    },
    {
      "file": "ValidateAndDecide.xaml",
      "workflow": "ValidateAndDecide",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "\"\"",
      "resolvedValue": "\"\"",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 1,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "\"\"",
        "precedenceTier": 4
      }
    },
    {
      "file": "ValidateAndDecide.xaml",
      "workflow": "ValidateAndDecide",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "\"\"",
      "resolvedValue": "\"\"",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 2,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "\"\"",
        "precedenceTier": 4
      }
    },
    {
      "file": "ValidateAndDecide.xaml",
      "workflow": "ValidateAndDecide",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "[CDec(InvoiceTotal.Trim())]",
      "resolvedValue": "[CDec(InvoiceTotal.Trim())]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 3,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[CDec(InvoiceTotal.Trim())]",
        "precedenceTier": 4
      }
    },
    {
      "file": "ValidateAndDecide.xaml",
      "workflow": "ValidateAndDecide",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot captured for error diagnostics&quot;]",
      "resolvedValue": "[&quot;Screenshot captured for error diagnostics&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 2,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot captured for error diagnostics&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "ValidateAndDecide.xaml",
      "workflow": "ValidateAndDecide",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
      "resolvedValue": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 3,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
        "precedenceTier": 4
      }
    },
    {
      "file": "ValidateAndDecide.xaml",
      "workflow": "ValidateAndDecide",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;[Error] Parse InvoiceTotal string to Decimal for arithmetic failed (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "resolvedValue": "[&quot;[Error] Parse InvoiceTotal string to Decimal for arithmetic failed (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 4,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;[Error] Parse InvoiceTotal string to Decimal for arithmetic failed (&quot",
        "precedenceTier": 4
      }
    },
    {
      "file": "ValidateAndDecide.xaml",
      "workflow": "ValidateAndDecide",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "\"\"",
      "resolvedValue": "\"\"",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 4,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "\"\"",
        "precedenceTier": 4
      }
    },
    {
      "file": "ValidateAndDecide.xaml",
      "workflow": "ValidateAndDecide",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot captured for error diagnostics&quot;]",
      "resolvedValue": "[&quot;Screenshot captured for error diagnostics&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 6,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot captured for error diagnostics&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "ValidateAndDecide.xaml",
      "workflow": "ValidateAndDecide",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
      "resolvedValue": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 7,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
        "precedenceTier": 4
      }
    },
    {
      "file": "ValidateAndDecide.xaml",
      "workflow": "ValidateAndDecide",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;[Error] RetryScope wrapper for Coupa PO lookup GET (2 attempts, 15s delay) failed (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "resolvedValue": "[&quot;[Error] RetryScope wrapper for Coupa PO lookup GET (2 attempts, 15s delay) failed (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 8,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;[Error] RetryScope wrapper for Coupa PO lookup GET (2 attempts, 15s delay",
        "precedenceTier": 4
      }
    },
    {
      "file": "ValidateAndDecide.xaml",
      "workflow": "ValidateAndDecide",
      "activityType": "HttpClient",
      "propertyName": "EndPoint",
      "sourceBinding": "attribute-value",
      "originalValue": "{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;poLookupUrl&quot;}",
      "resolvedValue": "[poLookupUrl]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;poLookupUrl&quot;}",
        "precedenceTier": 4
      }
    },
    {
      "file": "ValidateAndDecide.xaml",
      "workflow": "ValidateAndDecide",
      "activityType": "HttpClient",
      "propertyName": "Method",
      "sourceBinding": "attribute-value",
      "originalValue": "GET",
      "resolvedValue": "GET",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "GET",
        "precedenceTier": 4
      }
    },
    {
      "file": "ValidateAndDecide.xaml",
      "workflow": "ValidateAndDecide",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Retry exhausted for HTTP GET Coupa PO lookup via Integration Service HttpClient, screenshot captured&quot;]",
      "resolvedValue": "[&quot;Retry exhausted for HTTP GET Coupa PO lookup via Integration Service HttpClient, screenshot captured&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 9,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Retry exhausted for HTTP GET Coupa PO lookup via Integration Service Http",
        "precedenceTier": 4
      }
    },
    {
      "file": "ValidateAndDecide.xaml",
      "workflow": "ValidateAndDecide",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot capture failed: &quot; &amp; ssEx.Message]",
      "resolvedValue": "[&quot;Screenshot capture failed: &quot; &amp; ssEx.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 10,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot capture failed: &quot; &amp; ssEx.Message]",
        "precedenceTier": 4
      }
    },
    {
      "file": "ValidateAndDecide.xaml",
      "workflow": "ValidateAndDecide",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;[Retry Exhausted] HTTP GET Coupa PO lookup via Integration Service HttpClient failed after retries — &quot; &amp; retryEx.Message]",
      "resolvedValue": "[&quot;[Retry Exhausted] HTTP GET Coupa PO lookup via Integration Service HttpClient failed after retries — &quot; &amp; retryEx.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 11,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;[Retry Exhausted] HTTP GET Coupa PO lookup via Integration Service HttpCl",
        "precedenceTier": 4
      }
    },
    {
      "file": "ValidateAndDecide.xaml",
      "workflow": "ValidateAndDecide",
      "activityType": "DeserializeJson",
      "propertyName": "JsonString",
      "sourceBinding": "attribute-value",
      "originalValue": "CStr(poLookupResponse)",
      "resolvedValue": "CStr(poLookupResponse)",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "CStr(poLookupResponse)",
        "precedenceTier": 4
      }
    },
    {
      "file": "ValidateAndDecide.xaml",
      "workflow": "ValidateAndDecide",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot captured for error diagnostics&quot;]",
      "resolvedValue": "[&quot;Screenshot captured for error diagnostics&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 12,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot captured for error diagnostics&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "ValidateAndDecide.xaml",
      "workflow": "ValidateAndDecide",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
      "resolvedValue": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 13,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
        "precedenceTier": 4
      }
    },
    {
      "file": "ValidateAndDecide.xaml",
      "workflow": "ValidateAndDecide",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;[Error] Deserialize Coupa PO lookup JSON response failed (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "resolvedValue": "[&quot;[Error] Deserialize Coupa PO lookup JSON response failed (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 14,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;[Error] Deserialize Coupa PO lookup JSON response failed (&quot; &amp; ex",
        "precedenceTier": 4
      }
    },
    {
      "file": "ValidateAndDecide.xaml",
      "workflow": "ValidateAndDecide",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "\"\"",
      "resolvedValue": "\"\"",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 5,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "\"\"",
        "precedenceTier": 4
      }
    },
    {
      "file": "ValidateAndDecide.xaml",
      "workflow": "ValidateAndDecide",
      "activityType": "If",
      "propertyName": "Condition",
      "sourceBinding": "attribute-value",
      "originalValue": "[{&quot;type&quot;:&quot;expression&quot;,&quot;left&quot;:&quot;poFound&quot;,&quot;operator&quot;:&quot;=&quot;,&quot;right&quot;:&quot;False&quot;}]",
      "resolvedValue": "[{&quot;type&quot;:&quot;expression&quot;,&quot;left&quot;:&quot;poFound&quot;,&quot;operator&quot;:&quot;=&quot;,&quot;right&quot;:&quot;False&quot;}]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[{&quot;type&quot;:&quot;expression&quot;,&quot;left&quot;:&quot;poFound&quot;,&",
        "precedenceTier": 4
      }
    },
    {
      "file": "ValidateAndDecide.xaml",
      "workflow": "ValidateAndDecide",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Then path: Branch: PO found or not found?&quot;]",
      "resolvedValue": "[&quot;Then path: Branch: PO found or not found?&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 16,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Then path: Branch: PO found or not found?&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "ValidateAndDecide.xaml",
      "workflow": "ValidateAndDecide",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Else path: Branch: PO found or not found?&quot;]",
      "resolvedValue": "[&quot;Else path: Branch: PO found or not found?&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 17,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Else path: Branch: PO found or not found?&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "ValidateAndDecide.xaml",
      "workflow": "ValidateAndDecide",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "\"\"",
      "resolvedValue": "\"\"",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 6,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "\"\"",
        "precedenceTier": 4
      }
    },
    {
      "file": "ValidateAndDecide.xaml",
      "workflow": "ValidateAndDecide",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "\"\"",
      "resolvedValue": "\"\"",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 7,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "\"\"",
        "precedenceTier": 4
      }
    },
    {
      "file": "ValidateAndDecide.xaml",
      "workflow": "ValidateAndDecide",
      "activityType": "HttpClient",
      "propertyName": "EndPoint",
      "sourceBinding": "attribute-value",
      "originalValue": "{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;rejectUrl&quot;}",
      "resolvedValue": "[rejectUrl]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 1,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;rejectUrl&quot;}",
        "precedenceTier": 4
      }
    },
    {
      "file": "ValidateAndDecide.xaml",
      "workflow": "ValidateAndDecide",
      "activityType": "HttpClient",
      "propertyName": "Method",
      "sourceBinding": "attribute-value",
      "originalValue": "POST",
      "resolvedValue": "POST",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 1,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "POST",
        "precedenceTier": 4
      }
    },
    {
      "file": "ValidateAndDecide.xaml",
      "workflow": "ValidateAndDecide",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot captured for error diagnostics&quot;]",
      "resolvedValue": "[&quot;Screenshot captured for error diagnostics&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 18,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot captured for error diagnostics&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "ValidateAndDecide.xaml",
      "workflow": "ValidateAndDecide",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
      "resolvedValue": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 19,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
        "precedenceTier": 4
      }
    },
    {
      "file": "ValidateAndDecide.xaml",
      "workflow": "ValidateAndDecide",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;[Error] [PO NOT FOUND] POST reject to Coupa via HttpClient failed (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "resolvedValue": "[&quot;[Error] [PO NOT FOUND] POST reject to Coupa via HttpClient failed (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 20,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;[Error] [PO NOT FOUND] POST reject to Coupa via HttpClient failed (&quot;",
        "precedenceTier": 4
      }
    },
    {
      "file": "ValidateAndDecide.xaml",
      "workflow": "ValidateAndDecide",
      "activityType": "QueryEntity",
      "propertyName": "EntityType",
      "sourceBinding": "attribute-value",
      "originalValue": "InvoiceCase",
      "resolvedValue": "InvoiceCase",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "InvoiceCase",
        "precedenceTier": 4
      }
    },
    {
      "file": "ValidateAndDecide.xaml",
      "workflow": "ValidateAndDecide",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot captured for error diagnostics&quot;]",
      "resolvedValue": "[&quot;Screenshot captured for error diagnostics&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 21,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot captured for error diagnostics&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "ValidateAndDecide.xaml",
      "workflow": "ValidateAndDecide",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
      "resolvedValue": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 22,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
        "precedenceTier": 4
      }
    },
    {
      "file": "ValidateAndDecide.xaml",
      "workflow": "ValidateAndDecide",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;[Error] [PO NOT FOUND] Query InvoiceCase from Data Service by CoupaInvoiceId failed (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "resolvedValue": "[&quot;[Error] [PO NOT FOUND] Query InvoiceCase from Data Service by CoupaInvoiceId failed (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 23,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;[Error] [PO NOT FOUND] Query InvoiceCase from Data Service by CoupaInvoic",
        "precedenceTier": 4
      }
    },
    {
      "file": "ValidateAndDecide.xaml",
      "workflow": "ValidateAndDecide",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "\"\"",
      "resolvedValue": "\"\"",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 8,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "\"\"",
        "precedenceTier": 4
      }
    },
    {
      "file": "ValidateAndDecide.xaml",
      "workflow": "ValidateAndDecide",
      "activityType": "UpdateEntity",
      "propertyName": "EntityType",
      "sourceBinding": "attribute-value",
      "originalValue": "InvoiceCase",
      "resolvedValue": "InvoiceCase",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "InvoiceCase",
        "precedenceTier": 4
      }
    },
    {
      "file": "ValidateAndDecide.xaml",
      "workflow": "ValidateAndDecide",
      "activityType": "UpdateEntity",
      "propertyName": "EntityObject",
      "sourceBinding": "attribute-value",
      "originalValue": "{&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;New With {.CaseStatus = \\&quot;Rejected\\&quot;, .RejectionReasonCode = \\&quot;PO_MISMATCH_OR_NOT_FOUND\\&quot;, .CoupaActionResult = CStr(coupaRejectResponse), .CompletedUtc = DateTime.UtcNow}&quot;}",
      "resolvedValue": "[New With {.CaseStatus = \"Rejected\", .RejectionReasonCode = \"PO_MISMATCH_OR_NOT_FOUND\", .CoupaActionResult = CStr(coupaRejectResponse), .CompletedUtc = DateTime.UtcNow}]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "{&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;New With {.C",
        "precedenceTier": 4
      }
    },
    {
      "file": "ValidateAndDecide.xaml",
      "workflow": "ValidateAndDecide",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot captured for error diagnostics&quot;]",
      "resolvedValue": "[&quot;Screenshot captured for error diagnostics&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 24,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot captured for error diagnostics&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "ValidateAndDecide.xaml",
      "workflow": "ValidateAndDecide",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
      "resolvedValue": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 25,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
        "precedenceTier": 4
      }
    },
    {
      "file": "ValidateAndDecide.xaml",
      "workflow": "ValidateAndDecide",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;[Error] [PO NOT FOUND] Update InvoiceCase status to Rejected in Data Service failed (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "resolvedValue": "[&quot;[Error] [PO NOT FOUND] Update InvoiceCase status to Rejected in Data Service failed (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 26,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;[Error] [PO NOT FOUND] Update InvoiceCase status to Rejected in Data Serv",
        "precedenceTier": 4
      }
    },
    {
      "file": "ValidateAndDecide.xaml",
      "workflow": "ValidateAndDecide",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "\"\"",
      "resolvedValue": "\"\"",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 9,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "\"\"",
        "precedenceTier": 4
      }
    },
    {
      "file": "ValidateAndDecide.xaml",
      "workflow": "ValidateAndDecide",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "[PO_MISMATCH_OR_NOT_FOUND]",
      "resolvedValue": "[PO_MISMATCH_OR_NOT_FOUND]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 10,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[PO_MISMATCH_OR_NOT_FOUND]",
        "precedenceTier": 4
      }
    },
    {
      "file": "ValidateAndDecide.xaml",
      "workflow": "ValidateAndDecide",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "\"\"",
      "resolvedValue": "\"\"",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 11,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "\"\"",
        "precedenceTier": 4
      }
    },
    {
      "file": "ValidateAndDecide.xaml",
      "workflow": "ValidateAndDecide",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "\"\"",
      "resolvedValue": "\"\"",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 12,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "\"\"",
        "precedenceTier": 4
      }
    },
    {
      "file": "ValidateAndDecide.xaml",
      "workflow": "ValidateAndDecide",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot captured for error diagnostics&quot;]",
      "resolvedValue": "[&quot;Screenshot captured for error diagnostics&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 28,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot captured for error diagnostics&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "ValidateAndDecide.xaml",
      "workflow": "ValidateAndDecide",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
      "resolvedValue": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 29,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
        "precedenceTier": 4
      }
    },
    {
      "file": "ValidateAndDecide.xaml",
      "workflow": "ValidateAndDecide",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;[Error] [PO FOUND] Extract PO total amount from response failed (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "resolvedValue": "[&quot;[Error] [PO FOUND] Extract PO total amount from response failed (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 30,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;[Error] [PO FOUND] Extract PO total amount from response failed (&quot; &",
        "precedenceTier": 4
      }
    },
    {
      "file": "ValidateAndDecide.xaml",
      "workflow": "ValidateAndDecide",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "\"\"",
      "resolvedValue": "\"\"",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 13,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "\"\"",
        "precedenceTier": 4
      }
    },
    {
      "file": "ValidateAndDecide.xaml",
      "workflow": "ValidateAndDecide",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot captured for error diagnostics&quot;]",
      "resolvedValue": "[&quot;Screenshot captured for error diagnostics&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 31,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot captured for error diagnostics&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "ValidateAndDecide.xaml",
      "workflow": "ValidateAndDecide",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
      "resolvedValue": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 32,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Screenshot capture failed: &quot; &amp; screenshotEx.Message]",
        "precedenceTier": 4
      }
    },
    {
      "file": "ValidateAndDecide.xaml",
      "workflow": "ValidateAndDecide",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;[Error] [PO FOUND] Extract PO remaining amount from response failed (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "resolvedValue": "[&quot;[Error] [PO FOUND] Extract PO remaining amount from response failed (&quot; &amp; exception.GetType().Name &amp; &quot;): &quot; &amp; exception.Message]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 33,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;[Error] [PO FOUND] Extract PO remaining amount from response failed (&quo",
        "precedenceTier": 4
      }
    },
    {
      "file": "ValidateAndDecide.xaml",
      "workflow": "ValidateAndDecide",
      "activityType": "If",
      "propertyName": "Condition",
      "sourceBinding": "attribute-value",
      "originalValue": "[{&quot;type&quot;:&quot;expression&quot;,&quot;left&quot;:&quot;toleranceBasis&quot;,&quot;operator&quot;:&quot;=&quot;,&quot;right&quot;:&quot;PO_REMAINING&quot;}]",
      "resolvedValue": "[{&quot;type&quot;:&quot;expression&quot;,&quot;left&quot;:&quot;toleranceBasis&quot;,&quot;operator&quot;:&quot;=&quot;,&quot;right&quot;:&quot;PO_REMAINING&quot;}]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 1,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[{&quot;type&quot;:&quot;expression&quot;,&quot;left&quot;:&quot;toleranceBasis&",
        "precedenceTier": 4
      }
    },
    {
      "file": "ValidateAndDecide.xaml",
      "workflow": "ValidateAndDecide",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Then path: [PO FOUND] Determine ReferenceAmount based on ToleranceBasis&quot;]",
      "resolvedValue": "[&quot;Then path: [PO FOUND] Determine ReferenceAmount based on ToleranceBasis&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 34,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Then path: [PO FOUND] Determine ReferenceAmount based on ToleranceBasis&q",
        "precedenceTier": 4
      }
    },
    {
      "file": "ValidateAndDecide.xaml",
      "workflow": "ValidateAndDecide",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Else path: [PO FOUND] Determine ReferenceAmount based on ToleranceBasis&quot;]",
      "resolvedValue": "[&quot;Else path: [PO FOUND] Determine ReferenceAmount based on ToleranceBasis&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 35,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Else path: [PO FOUND] Determine ReferenceAmount based on ToleranceBasis&q",
        "precedenceTier": 4
      }
    },
    {
      "file": "ValidateAndDecide.xaml",
      "workflow": "ValidateAndDecide",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "\"\"",
      "resolvedValue": "\"\"",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 14,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "\"\"",
        "precedenceTier": 4
      }
    },
    {
      "file": "ValidateAndDecide.xaml",
      "workflow": "ValidateAndDecide",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "\"\"",
      "resolvedValue": "\"\"",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 15,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "\"\"",
        "precedenceTier": 4
      }
    },
    {
      "file": "ValidateAndDecide.xaml",
      "workflow": "ValidateAndDecide",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "\"\"",
      "resolvedValue": "\"\"",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 16,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "\"\"",
        "precedenceTier": 4
      }
    },
    {
      "file": "ValidateAndDecide.xaml",
      "workflow": "ValidateAndDecide",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;=== Completed: ValidateAndDecide ===&quot;]",
      "resolvedValue": "[&quot;=== Completed: ValidateAndDecide ===&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 37,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;=== Completed: ValidateAndDecide ===&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "InitAllSettings.xaml",
      "workflow": "InitAllSettings",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Reading configuration from Config.xlsx...&quot;]",
      "resolvedValue": "[&quot;Reading configuration from Config.xlsx...&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Reading configuration from Config.xlsx...&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "InitAllSettings.xaml",
      "workflow": "InitAllSettings",
      "activityType": "ExcelApplicationScope",
      "propertyName": "WorkbookPath",
      "sourceBinding": "variable",
      "originalValue": "[str_ConfigPath]",
      "resolvedValue": "[str_ConfigPath]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "variable",
        "sourceName": "str_ConfigPath",
        "sourceWorkflow": "InitAllSettings",
        "precedenceTier": 2
      }
    },
    {
      "file": "InitAllSettings.xaml",
      "workflow": "InitAllSettings",
      "activityType": "ExcelReadRange",
      "propertyName": "DataTable",
      "sourceBinding": "variable",
      "originalValue": "[dt_Settings]",
      "resolvedValue": "[dt_Settings]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "variable",
        "sourceName": "dt_Settings",
        "sourceWorkflow": "InitAllSettings",
        "precedenceTier": 2
      }
    },
    {
      "file": "InitAllSettings.xaml",
      "workflow": "InitAllSettings",
      "activityType": "ExcelReadRange",
      "propertyName": "DataTable",
      "sourceBinding": "variable",
      "originalValue": "[dt_Constants]",
      "resolvedValue": "[dt_Constants]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 1,
      "provenance": {
        "sourceKind": "variable",
        "sourceName": "dt_Constants",
        "sourceWorkflow": "InitAllSettings",
        "precedenceTier": 2
      }
    },
    {
      "file": "InitAllSettings.xaml",
      "workflow": "InitAllSettings",
      "activityType": "ForEach",
      "propertyName": "Values",
      "sourceBinding": "attribute-value",
      "originalValue": "[dt_Settings.Rows]",
      "resolvedValue": "[dt_Settings.Rows]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[dt_Settings.Rows]",
        "precedenceTier": 4
      }
    },
    {
      "file": "InitAllSettings.xaml",
      "workflow": "InitAllSettings",
      "activityType": "Assign",
      "propertyName": "To",
      "sourceBinding": "attribute-value",
      "originalValue": "[dict_Config(row(&quot;Name&quot;).ToString)]",
      "resolvedValue": "[dict_Config(row(&quot;Name&quot;).ToString)]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[dict_Config(row(&quot;Name&quot;).ToString)]",
        "precedenceTier": 4
      }
    },
    {
      "file": "InitAllSettings.xaml",
      "workflow": "InitAllSettings",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "[row(&quot;Value&quot;)]",
      "resolvedValue": "[row(&quot;Value&quot;)]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[row(&quot;Value&quot;)]",
        "precedenceTier": 4
      }
    },
    {
      "file": "InitAllSettings.xaml",
      "workflow": "InitAllSettings",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Processing setting: &quot; &amp; row(&quot;Name&quot;).ToString]",
      "resolvedValue": "[&quot;Processing setting: &quot; &amp; row(&quot;Name&quot;).ToString]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 1,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Processing setting: &quot; &amp; row(&quot;Name&quot;).ToString]",
        "precedenceTier": 4
      }
    },
    {
      "file": "InitAllSettings.xaml",
      "workflow": "InitAllSettings",
      "activityType": "GetCredential",
      "propertyName": "AssetName",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Cred_Coupa_API&quot;]",
      "resolvedValue": "[&quot;Cred_Coupa_API&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 0,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Cred_Coupa_API&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "InitAllSettings.xaml",
      "workflow": "InitAllSettings",
      "activityType": "Assign",
      "propertyName": "To",
      "sourceBinding": "attribute-value",
      "originalValue": "[dict_Config(&quot;Cred_Coupa_API&quot;)]",
      "resolvedValue": "[dict_Config(&quot;Cred_Coupa_API&quot;)]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 1,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[dict_Config(&quot;Cred_Coupa_API&quot;)]",
        "precedenceTier": 4
      }
    },
    {
      "file": "InitAllSettings.xaml",
      "workflow": "InitAllSettings",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "variable",
      "originalValue": "[str_TempUser]",
      "resolvedValue": "[str_TempUser]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 1,
      "provenance": {
        "sourceKind": "variable",
        "sourceName": "str_TempUser",
        "sourceWorkflow": "InitAllSettings",
        "precedenceTier": 2
      }
    },
    {
      "file": "InitAllSettings.xaml",
      "workflow": "InitAllSettings",
      "activityType": "Assign",
      "propertyName": "To",
      "sourceBinding": "attribute-value",
      "originalValue": "[dict_Config(&quot;Coupa.BaseUrl&quot;)]",
      "resolvedValue": "[dict_Config(&quot;Coupa.BaseUrl&quot;)]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 2,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[dict_Config(&quot;Coupa.BaseUrl&quot;)]",
        "precedenceTier": 4
      }
    },
    {
      "file": "InitAllSettings.xaml",
      "workflow": "InitAllSettings",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "variable",
      "originalValue": "[str_AssetValue]",
      "resolvedValue": "[str_AssetValue]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 2,
      "provenance": {
        "sourceKind": "variable",
        "sourceName": "str_AssetValue",
        "sourceWorkflow": "InitAllSettings",
        "precedenceTier": 2
      }
    },
    {
      "file": "InitAllSettings.xaml",
      "workflow": "InitAllSettings",
      "activityType": "Assign",
      "propertyName": "To",
      "sourceBinding": "attribute-value",
      "originalValue": "[dict_Config(&quot;Coupa.Polling.Enabled&quot;)]",
      "resolvedValue": "[dict_Config(&quot;Coupa.Polling.Enabled&quot;)]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 3,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[dict_Config(&quot;Coupa.Polling.Enabled&quot;)]",
        "precedenceTier": 4
      }
    },
    {
      "file": "InitAllSettings.xaml",
      "workflow": "InitAllSettings",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "variable",
      "originalValue": "[str_AssetValue]",
      "resolvedValue": "[str_AssetValue]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 3,
      "provenance": {
        "sourceKind": "variable",
        "sourceName": "str_AssetValue",
        "sourceWorkflow": "InitAllSettings",
        "precedenceTier": 2
      }
    },
    {
      "file": "InitAllSettings.xaml",
      "workflow": "InitAllSettings",
      "activityType": "Assign",
      "propertyName": "To",
      "sourceBinding": "attribute-value",
      "originalValue": "[dict_Config(&quot;Coupa.Polling.LookbackMinutes&quot;)]",
      "resolvedValue": "[dict_Config(&quot;Coupa.Polling.LookbackMinutes&quot;)]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 4,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[dict_Config(&quot;Coupa.Polling.LookbackMinutes&quot;)]",
        "precedenceTier": 4
      }
    },
    {
      "file": "InitAllSettings.xaml",
      "workflow": "InitAllSettings",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "variable",
      "originalValue": "[str_AssetValue]",
      "resolvedValue": "[str_AssetValue]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 4,
      "provenance": {
        "sourceKind": "variable",
        "sourceName": "str_AssetValue",
        "sourceWorkflow": "InitAllSettings",
        "precedenceTier": 2
      }
    },
    {
      "file": "InitAllSettings.xaml",
      "workflow": "InitAllSettings",
      "activityType": "Assign",
      "propertyName": "To",
      "sourceBinding": "attribute-value",
      "originalValue": "[dict_Config(&quot;Business.TolerancePercent&quot;)]",
      "resolvedValue": "[dict_Config(&quot;Business.TolerancePercent&quot;)]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 5,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[dict_Config(&quot;Business.TolerancePercent&quot;)]",
        "precedenceTier": 4
      }
    },
    {
      "file": "InitAllSettings.xaml",
      "workflow": "InitAllSettings",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "variable",
      "originalValue": "[str_AssetValue]",
      "resolvedValue": "[str_AssetValue]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 5,
      "provenance": {
        "sourceKind": "variable",
        "sourceName": "str_AssetValue",
        "sourceWorkflow": "InitAllSettings",
        "precedenceTier": 2
      }
    },
    {
      "file": "InitAllSettings.xaml",
      "workflow": "InitAllSettings",
      "activityType": "Assign",
      "propertyName": "To",
      "sourceBinding": "attribute-value",
      "originalValue": "[dict_Config(&quot;Business.ToleranceBasis&quot;)]",
      "resolvedValue": "[dict_Config(&quot;Business.ToleranceBasis&quot;)]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 6,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[dict_Config(&quot;Business.ToleranceBasis&quot;)]",
        "precedenceTier": 4
      }
    },
    {
      "file": "InitAllSettings.xaml",
      "workflow": "InitAllSettings",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "variable",
      "originalValue": "[str_AssetValue]",
      "resolvedValue": "[str_AssetValue]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 6,
      "provenance": {
        "sourceKind": "variable",
        "sourceName": "str_AssetValue",
        "sourceWorkflow": "InitAllSettings",
        "precedenceTier": 2
      }
    },
    {
      "file": "InitAllSettings.xaml",
      "workflow": "InitAllSettings",
      "activityType": "Assign",
      "propertyName": "To",
      "sourceBinding": "attribute-value",
      "originalValue": "[dict_Config(&quot;DU.ConfidenceThreshold&quot;)]",
      "resolvedValue": "[dict_Config(&quot;DU.ConfidenceThreshold&quot;)]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 7,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[dict_Config(&quot;DU.ConfidenceThreshold&quot;)]",
        "precedenceTier": 4
      }
    },
    {
      "file": "InitAllSettings.xaml",
      "workflow": "InitAllSettings",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "variable",
      "originalValue": "[str_AssetValue]",
      "resolvedValue": "[str_AssetValue]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 7,
      "provenance": {
        "sourceKind": "variable",
        "sourceName": "str_AssetValue",
        "sourceWorkflow": "InitAllSettings",
        "precedenceTier": 2
      }
    },
    {
      "file": "InitAllSettings.xaml",
      "workflow": "InitAllSettings",
      "activityType": "Assign",
      "propertyName": "To",
      "sourceBinding": "attribute-value",
      "originalValue": "[dict_Config(&quot;ActionCenter.SLAHours&quot;)]",
      "resolvedValue": "[dict_Config(&quot;ActionCenter.SLAHours&quot;)]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 8,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[dict_Config(&quot;ActionCenter.SLAHours&quot;)]",
        "precedenceTier": 4
      }
    },
    {
      "file": "InitAllSettings.xaml",
      "workflow": "InitAllSettings",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "variable",
      "originalValue": "[str_AssetValue]",
      "resolvedValue": "[str_AssetValue]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 8,
      "provenance": {
        "sourceKind": "variable",
        "sourceName": "str_AssetValue",
        "sourceWorkflow": "InitAllSettings",
        "precedenceTier": 2
      }
    },
    {
      "file": "InitAllSettings.xaml",
      "workflow": "InitAllSettings",
      "activityType": "Assign",
      "propertyName": "To",
      "sourceBinding": "attribute-value",
      "originalValue": "[dict_Config(&quot;Storage.RetentionDays&quot;)]",
      "resolvedValue": "[dict_Config(&quot;Storage.RetentionDays&quot;)]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 9,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[dict_Config(&quot;Storage.RetentionDays&quot;)]",
        "precedenceTier": 4
      }
    },
    {
      "file": "InitAllSettings.xaml",
      "workflow": "InitAllSettings",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "variable",
      "originalValue": "[str_AssetValue]",
      "resolvedValue": "[str_AssetValue]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 9,
      "provenance": {
        "sourceKind": "variable",
        "sourceName": "str_AssetValue",
        "sourceWorkflow": "InitAllSettings",
        "precedenceTier": 2
      }
    },
    {
      "file": "InitAllSettings.xaml",
      "workflow": "InitAllSettings",
      "activityType": "Assign",
      "propertyName": "To",
      "sourceBinding": "attribute-value",
      "originalValue": "[dict_Config(&quot;Orchestrator.FolderName&quot;)]",
      "resolvedValue": "[dict_Config(&quot;Orchestrator.FolderName&quot;)]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 10,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[dict_Config(&quot;Orchestrator.FolderName&quot;)]",
        "precedenceTier": 4
      }
    },
    {
      "file": "InitAllSettings.xaml",
      "workflow": "InitAllSettings",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "variable",
      "originalValue": "[str_AssetValue]",
      "resolvedValue": "[str_AssetValue]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 10,
      "provenance": {
        "sourceKind": "variable",
        "sourceName": "str_AssetValue",
        "sourceWorkflow": "InitAllSettings",
        "precedenceTier": 2
      }
    },
    {
      "file": "InitAllSettings.xaml",
      "workflow": "InitAllSettings",
      "activityType": "ForEach",
      "propertyName": "Values",
      "sourceBinding": "attribute-value",
      "originalValue": "[dt_Constants.Rows]",
      "resolvedValue": "[dt_Constants.Rows]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 1,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[dt_Constants.Rows]",
        "precedenceTier": 4
      }
    },
    {
      "file": "InitAllSettings.xaml",
      "workflow": "InitAllSettings",
      "activityType": "Assign",
      "propertyName": "To",
      "sourceBinding": "attribute-value",
      "originalValue": "[dict_Config(constRow(&quot;Name&quot;).ToString)]",
      "resolvedValue": "[dict_Config(constRow(&quot;Name&quot;).ToString)]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 11,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[dict_Config(constRow(&quot;Name&quot;).ToString)]",
        "precedenceTier": 4
      }
    },
    {
      "file": "InitAllSettings.xaml",
      "workflow": "InitAllSettings",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "attribute-value",
      "originalValue": "[constRow(&quot;Value&quot;)]",
      "resolvedValue": "[constRow(&quot;Value&quot;)]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 11,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[constRow(&quot;Value&quot;)]",
        "precedenceTier": 4
      }
    },
    {
      "file": "InitAllSettings.xaml",
      "workflow": "InitAllSettings",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Loaded constant: &quot; &amp; constRow(&quot;Name&quot;).ToString]",
      "resolvedValue": "[&quot;Loaded constant: &quot; &amp; constRow(&quot;Name&quot;).ToString]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 2,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Loaded constant: &quot; &amp; constRow(&quot;Name&quot;).ToString]",
        "precedenceTier": 4
      }
    },
    {
      "file": "InitAllSettings.xaml",
      "workflow": "InitAllSettings",
      "activityType": "Assign",
      "propertyName": "To",
      "sourceBinding": "workflowArgument",
      "originalValue": "[out_Config]",
      "resolvedValue": "[out_Config]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 12,
      "provenance": {
        "sourceKind": "workflowArgument",
        "sourceName": "out_Config",
        "sourceWorkflow": "InitAllSettings",
        "precedenceTier": 1
      }
    },
    {
      "file": "InitAllSettings.xaml",
      "workflow": "InitAllSettings",
      "activityType": "Assign",
      "propertyName": "Value",
      "sourceBinding": "variable",
      "originalValue": "[dict_Config]",
      "resolvedValue": "[dict_Config]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 12,
      "provenance": {
        "sourceKind": "variable",
        "sourceName": "dict_Config",
        "sourceWorkflow": "InitAllSettings",
        "precedenceTier": 2
      }
    },
    {
      "file": "InitAllSettings.xaml",
      "workflow": "InitAllSettings",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;Configuration loaded successfully&quot;]",
      "resolvedValue": "[&quot;Configuration loaded successfully&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 3,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;Configuration loaded successfully&quot;]",
        "precedenceTier": 4
      }
    },
    {
      "file": "InitAllSettings.xaml",
      "workflow": "InitAllSettings",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "sourceBinding": "attribute-value",
      "originalValue": "[&quot;=== Completed: InitAllSettings ===&quot;]",
      "resolvedValue": "[&quot;=== Completed: InitAllSettings ===&quot;]",
      "severity": "info",
      "packageModeOutcome": "bound",
      "occurrenceIndex": 4,
      "provenance": {
        "sourceKind": "attribute-value",
        "sourceName": "[&quot;=== Completed: InitAllSettings ===&quot;]",
        "precedenceTier": 4
      }
    }
  ],
  "unresolvedRequiredPropertyDefects": [
    {
      "file": "Main.xaml",
      "workflow": "Main",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "failureReason": "Required property \"Message\" on LogMessage contains generic type default \"\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "Main.xaml",
      "workflow": "Main",
      "activityType": "Assign",
      "propertyName": "To",
      "failureReason": "Required property \"To\" on Assign contains generic type default \"Nothing\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "Nothing",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "Main.xaml",
      "workflow": "Main",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "failureReason": "Required property \"Message\" on LogMessage contains generic type default \"\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "Main.xaml",
      "workflow": "Main",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "failureReason": "Required property \"Message\" on LogMessage contains generic type default \"\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "Main.xaml",
      "workflow": "Main",
      "activityType": "While",
      "propertyName": "Condition",
      "failureReason": "Required property \"Condition\" on While contains generic type default \"False\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "False",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "Main.xaml",
      "workflow": "Main",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "failureReason": "Required property \"Message\" on LogMessage contains generic type default \"\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "Main.xaml",
      "workflow": "Main",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "failureReason": "Required property \"Message\" on LogMessage contains generic type default \"\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "Main.xaml",
      "workflow": "Main",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "failureReason": "Required property \"Message\" on LogMessage contains generic type default \"\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "Main.xaml",
      "workflow": "Main",
      "activityType": "Assign",
      "propertyName": "To",
      "failureReason": "Required property \"To\" on Assign contains generic type default \"Nothing\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "Nothing",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "Main.xaml",
      "workflow": "Main",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "failureReason": "Required property \"Message\" on LogMessage contains generic type default \"\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "Main.xaml",
      "workflow": "Main",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "failureReason": "Required property \"Message\" on LogMessage contains generic type default \"\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "Main.xaml",
      "workflow": "Main",
      "activityType": "Assign",
      "propertyName": "To",
      "failureReason": "Required property \"To\" on Assign contains generic type default \"Nothing\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "Nothing",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "Main.xaml",
      "workflow": "Main",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "failureReason": "Required property \"Message\" on LogMessage contains generic type default \"\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "Main.xaml",
      "workflow": "Main",
      "activityType": "Assign",
      "propertyName": "To",
      "failureReason": "Required property \"To\" on Assign contains generic type default \"Nothing\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "Nothing",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "Main.xaml",
      "workflow": "Main",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "failureReason": "Required property \"Message\" on LogMessage contains generic type default \"\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "Dispatcher.xaml",
      "workflow": "Dispatcher",
      "activityType": "Assign",
      "propertyName": "To",
      "failureReason": "Required property \"To\" on Assign contains generic type default \"Nothing\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "Nothing",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "Dispatcher.xaml",
      "workflow": "Dispatcher",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "failureReason": "Required property \"Message\" on LogMessage contains generic type default \"\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "Dispatcher.xaml",
      "workflow": "Dispatcher",
      "activityType": "Assign",
      "propertyName": "To",
      "failureReason": "Required property \"To\" on Assign contains generic type default \"Nothing\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "Nothing",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "Dispatcher.xaml",
      "workflow": "Dispatcher",
      "activityType": "Assign",
      "propertyName": "To",
      "failureReason": "Required property \"To\" on Assign contains generic type default \"Nothing\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "Nothing",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "Dispatcher.xaml",
      "workflow": "Dispatcher",
      "activityType": "Assign",
      "propertyName": "To",
      "failureReason": "Required property \"To\" on Assign contains generic type default \"Nothing\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "Nothing",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "Dispatcher.xaml",
      "workflow": "Dispatcher",
      "activityType": "Assign",
      "propertyName": "To",
      "failureReason": "Required property \"To\" on Assign contains generic type default \"Nothing\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "Nothing",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "Dispatcher.xaml",
      "workflow": "Dispatcher",
      "activityType": "Assign",
      "propertyName": "To",
      "failureReason": "Required property \"To\" on Assign contains generic type default \"Nothing\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "Nothing",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "Dispatcher.xaml",
      "workflow": "Dispatcher",
      "activityType": "Assign",
      "propertyName": "To",
      "failureReason": "Required property \"To\" on Assign contains generic type default \"Nothing\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "Nothing",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "Dispatcher.xaml",
      "workflow": "Dispatcher",
      "activityType": "Assign",
      "propertyName": "To",
      "failureReason": "Required property \"To\" on Assign contains generic type default \"Nothing\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "Nothing",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "Dispatcher.xaml",
      "workflow": "Dispatcher",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "failureReason": "Required property \"Message\" on LogMessage contains generic type default \"\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "Dispatcher.xaml",
      "workflow": "Dispatcher",
      "activityType": "Assign",
      "propertyName": "To",
      "failureReason": "Required property \"To\" on Assign contains generic type default \"Nothing\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "Nothing",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "Dispatcher.xaml",
      "workflow": "Dispatcher",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "failureReason": "Required property \"Message\" on LogMessage contains generic type default \"\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "Dispatcher.xaml",
      "workflow": "Dispatcher",
      "activityType": "Assign",
      "propertyName": "To",
      "failureReason": "Required property \"To\" on Assign contains generic type default \"Nothing\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "Nothing",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "Dispatcher.xaml",
      "workflow": "Dispatcher",
      "activityType": "Assign",
      "propertyName": "To",
      "failureReason": "Required property \"To\" on Assign contains generic type default \"Nothing\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "Nothing",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "InitialiseConfig.xaml",
      "workflow": "InitialiseConfig",
      "activityType": "Assign",
      "propertyName": "To",
      "failureReason": "Required property \"To\" on Assign contains generic type default \"Nothing\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "Nothing",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "InitialiseConfig.xaml",
      "workflow": "InitialiseConfig",
      "activityType": "Assign",
      "propertyName": "To",
      "failureReason": "Required property \"To\" on Assign contains generic type default \"Nothing\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "Nothing",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "InitialiseConfig.xaml",
      "workflow": "InitialiseConfig",
      "activityType": "Assign",
      "propertyName": "To",
      "failureReason": "Required property \"To\" on Assign contains generic type default \"Nothing\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "Nothing",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "InitialiseConfig.xaml",
      "workflow": "InitialiseConfig",
      "activityType": "Assign",
      "propertyName": "To",
      "failureReason": "Required property \"To\" on Assign contains generic type default \"Nothing\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "Nothing",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "InitialiseConfig.xaml",
      "workflow": "InitialiseConfig",
      "activityType": "Assign",
      "propertyName": "To",
      "failureReason": "Required property \"To\" on Assign contains generic type default \"Nothing\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "Nothing",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "InitialiseConfig.xaml",
      "workflow": "InitialiseConfig",
      "activityType": "Assign",
      "propertyName": "To",
      "failureReason": "Required property \"To\" on Assign contains generic type default \"Nothing\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "Nothing",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "InitialiseConfig.xaml",
      "workflow": "InitialiseConfig",
      "activityType": "Assign",
      "propertyName": "To",
      "failureReason": "Required property \"To\" on Assign contains generic type default \"Nothing\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "Nothing",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "InitialiseConfig.xaml",
      "workflow": "InitialiseConfig",
      "activityType": "Assign",
      "propertyName": "To",
      "failureReason": "Required property \"To\" on Assign contains generic type default \"Nothing\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "Nothing",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "InitialiseConfig.xaml",
      "workflow": "InitialiseConfig",
      "activityType": "Assign",
      "propertyName": "To",
      "failureReason": "Required property \"To\" on Assign contains generic type default \"Nothing\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "Nothing",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "InitialiseConfig.xaml",
      "workflow": "InitialiseConfig",
      "activityType": "Assign",
      "propertyName": "To",
      "failureReason": "Required property \"To\" on Assign contains generic type default \"Nothing\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "Nothing",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "InitialiseConfig.xaml",
      "workflow": "InitialiseConfig",
      "activityType": "Assign",
      "propertyName": "To",
      "failureReason": "Required property \"To\" on Assign contains generic type default \"Nothing\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "Nothing",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "InitialiseConfig.xaml",
      "workflow": "InitialiseConfig",
      "activityType": "Assign",
      "propertyName": "To",
      "failureReason": "Required property \"To\" on Assign contains generic type default \"Nothing\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "Nothing",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "InitialiseConfig.xaml",
      "workflow": "InitialiseConfig",
      "activityType": "Assign",
      "propertyName": "To",
      "failureReason": "Required property \"To\" on Assign contains generic type default \"Nothing\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "Nothing",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "InitialiseConfig.xaml",
      "workflow": "InitialiseConfig",
      "activityType": "Assign",
      "propertyName": "To",
      "failureReason": "Required property \"To\" on Assign contains generic type default \"Nothing\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "Nothing",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "InitialiseConfig.xaml",
      "workflow": "InitialiseConfig",
      "activityType": "Assign",
      "propertyName": "To",
      "failureReason": "Required property \"To\" on Assign contains generic type default \"Nothing\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "Nothing",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "InitialiseConfig.xaml",
      "workflow": "InitialiseConfig",
      "activityType": "Assign",
      "propertyName": "To",
      "failureReason": "Required property \"To\" on Assign contains generic type default \"Nothing\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "Nothing",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "InitialiseConfig.xaml",
      "workflow": "InitialiseConfig",
      "activityType": "Assign",
      "propertyName": "To",
      "failureReason": "Required property \"To\" on Assign contains generic type default \"Nothing\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "Nothing",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "InitialiseConfig.xaml",
      "workflow": "InitialiseConfig",
      "activityType": "Assign",
      "propertyName": "To",
      "failureReason": "Required property \"To\" on Assign contains generic type default \"Nothing\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "Nothing",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "InitialiseConfig.xaml",
      "workflow": "InitialiseConfig",
      "activityType": "Assign",
      "propertyName": "To",
      "failureReason": "Required property \"To\" on Assign contains generic type default \"Nothing\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "Nothing",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "InitialiseConfig.xaml",
      "workflow": "InitialiseConfig",
      "activityType": "Assign",
      "propertyName": "To",
      "failureReason": "Required property \"To\" on Assign contains generic type default \"Nothing\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "Nothing",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "InitialiseConfig.xaml",
      "workflow": "InitialiseConfig",
      "activityType": "Assign",
      "propertyName": "To",
      "failureReason": "Required property \"To\" on Assign contains generic type default \"Nothing\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "Nothing",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "InitialiseConfig.xaml",
      "workflow": "InitialiseConfig",
      "activityType": "Assign",
      "propertyName": "To",
      "failureReason": "Required property \"To\" on Assign contains generic type default \"Nothing\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "Nothing",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "InitialiseConfig.xaml",
      "workflow": "InitialiseConfig",
      "activityType": "Assign",
      "propertyName": "To",
      "failureReason": "Required property \"To\" on Assign contains generic type default \"Nothing\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "Nothing",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "InitialiseConfig.xaml",
      "workflow": "InitialiseConfig",
      "activityType": "Assign",
      "propertyName": "To",
      "failureReason": "Required property \"To\" on Assign contains generic type default \"Nothing\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "Nothing",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "ProcessTransaction.xaml",
      "workflow": "ProcessTransaction",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "failureReason": "Required property \"Message\" on LogMessage contains generic type default \"\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "ProcessTransaction.xaml",
      "workflow": "ProcessTransaction",
      "activityType": "Assign",
      "propertyName": "To",
      "failureReason": "Required property \"To\" on Assign contains generic type default \"Nothing\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "Nothing",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "ProcessTransaction.xaml",
      "workflow": "ProcessTransaction",
      "activityType": "Assign",
      "propertyName": "To",
      "failureReason": "Required property \"To\" on Assign contains generic type default \"Nothing\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "Nothing",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "ProcessTransaction.xaml",
      "workflow": "ProcessTransaction",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "failureReason": "Required property \"Message\" on LogMessage contains generic type default \"\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "ProcessTransaction.xaml",
      "workflow": "ProcessTransaction",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "failureReason": "Required property \"Message\" on LogMessage contains generic type default \"\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "ProcessTransaction.xaml",
      "workflow": "ProcessTransaction",
      "activityType": "Assign",
      "propertyName": "To",
      "failureReason": "Required property \"To\" on Assign contains generic type default \"Nothing\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "Nothing",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "ProcessTransaction.xaml",
      "workflow": "ProcessTransaction",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "failureReason": "Required property \"Message\" on LogMessage contains generic type default \"\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "ProcessTransaction.xaml",
      "workflow": "ProcessTransaction",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "failureReason": "Required property \"Message\" on LogMessage contains generic type default \"\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "ProcessTransaction.xaml",
      "workflow": "ProcessTransaction",
      "activityType": "Assign",
      "propertyName": "To",
      "failureReason": "Required property \"To\" on Assign contains generic type default \"Nothing\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "Nothing",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "ProcessTransaction.xaml",
      "workflow": "ProcessTransaction",
      "activityType": "Assign",
      "propertyName": "To",
      "failureReason": "Required property \"To\" on Assign contains generic type default \"Nothing\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "Nothing",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "ProcessTransaction.xaml",
      "workflow": "ProcessTransaction",
      "activityType": "Assign",
      "propertyName": "To",
      "failureReason": "Required property \"To\" on Assign contains generic type default \"Nothing\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "Nothing",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "ProcessTransaction.xaml",
      "workflow": "ProcessTransaction",
      "activityType": "Assign",
      "propertyName": "To",
      "failureReason": "Required property \"To\" on Assign contains generic type default \"Nothing\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "Nothing",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "ProcessTransaction.xaml",
      "workflow": "ProcessTransaction",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "failureReason": "Required property \"Message\" on LogMessage contains generic type default \"\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "ProcessTransaction.xaml",
      "workflow": "ProcessTransaction",
      "activityType": "Assign",
      "propertyName": "To",
      "failureReason": "Required property \"To\" on Assign contains generic type default \"Nothing\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "Nothing",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "ProcessTransaction.xaml",
      "workflow": "ProcessTransaction",
      "activityType": "CreateEntityRecord",
      "propertyName": "EntityObject",
      "failureReason": "Required property \"EntityObject\" on CreateEntityRecord has no valid source binding and no contract-valid fallback",
      "originalValue": "",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "RetrieveInvoicePdf.xaml",
      "workflow": "RetrieveInvoicePdf",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "failureReason": "Required property \"Message\" on LogMessage contains generic type default \"\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "RetrieveInvoicePdf.xaml",
      "workflow": "RetrieveInvoicePdf",
      "activityType": "Assign",
      "propertyName": "To",
      "failureReason": "Required property \"To\" on Assign contains generic type default \"Nothing\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "Nothing",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "RetrieveInvoicePdf.xaml",
      "workflow": "RetrieveInvoicePdf",
      "activityType": "Assign",
      "propertyName": "To",
      "failureReason": "Required property \"To\" on Assign contains generic type default \"Nothing\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "Nothing",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "RetrieveInvoicePdf.xaml",
      "workflow": "RetrieveInvoicePdf",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "failureReason": "Required property \"Message\" on LogMessage contains generic type default \"\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "RetrieveInvoicePdf.xaml",
      "workflow": "RetrieveInvoicePdf",
      "activityType": "Assign",
      "propertyName": "To",
      "failureReason": "Required property \"To\" on Assign contains generic type default \"Nothing\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "Nothing",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "RetrieveInvoicePdf.xaml",
      "workflow": "RetrieveInvoicePdf",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "failureReason": "Required property \"Message\" on LogMessage contains generic type default \"\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "RetrieveInvoicePdf.xaml",
      "workflow": "RetrieveInvoicePdf",
      "activityType": "Assign",
      "propertyName": "To",
      "failureReason": "Required property \"To\" on Assign contains generic type default \"Nothing\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "Nothing",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "RetrieveInvoicePdf.xaml",
      "workflow": "RetrieveInvoicePdf",
      "activityType": "Assign",
      "propertyName": "To",
      "failureReason": "Required property \"To\" on Assign contains generic type default \"Nothing\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "Nothing",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "RetrieveInvoicePdf.xaml",
      "workflow": "RetrieveInvoicePdf",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "failureReason": "Required property \"Message\" on LogMessage contains generic type default \"\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "RetrieveInvoicePdf.xaml",
      "workflow": "RetrieveInvoicePdf",
      "activityType": "Assign",
      "propertyName": "To",
      "failureReason": "Required property \"To\" on Assign contains generic type default \"Nothing\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "Nothing",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "RetrieveInvoicePdf.xaml",
      "workflow": "RetrieveInvoicePdf",
      "activityType": "Assign",
      "propertyName": "To",
      "failureReason": "Required property \"To\" on Assign contains generic type default \"Nothing\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "Nothing",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "RetrieveInvoicePdf.xaml",
      "workflow": "RetrieveInvoicePdf",
      "activityType": "Assign",
      "propertyName": "To",
      "failureReason": "Required property \"To\" on Assign contains generic type default \"Nothing\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "Nothing",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "RetrieveInvoicePdf.xaml",
      "workflow": "RetrieveInvoicePdf",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "failureReason": "Required property \"Message\" on LogMessage contains generic type default \"\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "ExtractInvoiceFields.xaml",
      "workflow": "ExtractInvoiceFields",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "failureReason": "Required property \"Message\" on LogMessage contains generic type default \"\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "ExtractInvoiceFields.xaml",
      "workflow": "ExtractInvoiceFields",
      "activityType": "Assign",
      "propertyName": "To",
      "failureReason": "Required property \"To\" on Assign contains generic type default \"Nothing\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "Nothing",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "ExtractInvoiceFields.xaml",
      "workflow": "ExtractInvoiceFields",
      "activityType": "Assign",
      "propertyName": "To",
      "failureReason": "Required property \"To\" on Assign contains generic type default \"Nothing\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "Nothing",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "ExtractInvoiceFields.xaml",
      "workflow": "ExtractInvoiceFields",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "failureReason": "Required property \"Message\" on LogMessage contains generic type default \"\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "ExtractInvoiceFields.xaml",
      "workflow": "ExtractInvoiceFields",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "failureReason": "Required property \"Message\" on LogMessage contains generic type default \"\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "ExtractInvoiceFields.xaml",
      "workflow": "ExtractInvoiceFields",
      "activityType": "Assign",
      "propertyName": "To",
      "failureReason": "Required property \"To\" on Assign contains generic type default \"Nothing\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "Nothing",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "ExtractInvoiceFields.xaml",
      "workflow": "ExtractInvoiceFields",
      "activityType": "Assign",
      "propertyName": "To",
      "failureReason": "Required property \"To\" on Assign contains generic type default \"Nothing\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "Nothing",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "ExtractInvoiceFields.xaml",
      "workflow": "ExtractInvoiceFields",
      "activityType": "Assign",
      "propertyName": "To",
      "failureReason": "Required property \"To\" on Assign contains generic type default \"Nothing\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "Nothing",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "ExtractInvoiceFields.xaml",
      "workflow": "ExtractInvoiceFields",
      "activityType": "Assign",
      "propertyName": "To",
      "failureReason": "Required property \"To\" on Assign contains generic type default \"Nothing\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "Nothing",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "ExtractInvoiceFields.xaml",
      "workflow": "ExtractInvoiceFields",
      "activityType": "Assign",
      "propertyName": "To",
      "failureReason": "Required property \"To\" on Assign contains generic type default \"Nothing\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "Nothing",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "ExtractInvoiceFields.xaml",
      "workflow": "ExtractInvoiceFields",
      "activityType": "Assign",
      "propertyName": "To",
      "failureReason": "Required property \"To\" on Assign contains generic type default \"Nothing\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "Nothing",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "ExtractInvoiceFields.xaml",
      "workflow": "ExtractInvoiceFields",
      "activityType": "Assign",
      "propertyName": "To",
      "failureReason": "Required property \"To\" on Assign contains generic type default \"Nothing\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "Nothing",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "ExtractInvoiceFields.xaml",
      "workflow": "ExtractInvoiceFields",
      "activityType": "Assign",
      "propertyName": "To",
      "failureReason": "Required property \"To\" on Assign contains generic type default \"Nothing\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "Nothing",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "ExtractInvoiceFields.xaml",
      "workflow": "ExtractInvoiceFields",
      "activityType": "Assign",
      "propertyName": "To",
      "failureReason": "Required property \"To\" on Assign contains generic type default \"Nothing\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "Nothing",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "ExtractInvoiceFields.xaml",
      "workflow": "ExtractInvoiceFields",
      "activityType": "Assign",
      "propertyName": "To",
      "failureReason": "Required property \"To\" on Assign contains generic type default \"Nothing\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "Nothing",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "ExtractInvoiceFields.xaml",
      "workflow": "ExtractInvoiceFields",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "failureReason": "Required property \"Message\" on LogMessage contains generic type default \"\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "ExtractInvoiceFields.xaml",
      "workflow": "ExtractInvoiceFields",
      "activityType": "Assign",
      "propertyName": "To",
      "failureReason": "Required property \"To\" on Assign contains generic type default \"Nothing\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "Nothing",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "ExtractInvoiceFields.xaml",
      "workflow": "ExtractInvoiceFields",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "failureReason": "Required property \"Message\" on LogMessage contains generic type default \"\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "ExtractInvoiceFields.xaml",
      "workflow": "ExtractInvoiceFields",
      "activityType": "Assign",
      "propertyName": "To",
      "failureReason": "Required property \"To\" on Assign contains generic type default \"Nothing\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "Nothing",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "ExtractInvoiceFields.xaml",
      "workflow": "ExtractInvoiceFields",
      "activityType": "Assign",
      "propertyName": "To",
      "failureReason": "Required property \"To\" on Assign contains generic type default \"Nothing\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "Nothing",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "ExtractInvoiceFields.xaml",
      "workflow": "ExtractInvoiceFields",
      "activityType": "Assign",
      "propertyName": "To",
      "failureReason": "Required property \"To\" on Assign contains generic type default \"Nothing\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "Nothing",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "ExtractInvoiceFields.xaml",
      "workflow": "ExtractInvoiceFields",
      "activityType": "Assign",
      "propertyName": "To",
      "failureReason": "Required property \"To\" on Assign contains generic type default \"Nothing\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "Nothing",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "ExtractInvoiceFields.xaml",
      "workflow": "ExtractInvoiceFields",
      "activityType": "Assign",
      "propertyName": "To",
      "failureReason": "Required property \"To\" on Assign contains generic type default \"Nothing\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "Nothing",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "ExtractInvoiceFields.xaml",
      "workflow": "ExtractInvoiceFields",
      "activityType": "Assign",
      "propertyName": "To",
      "failureReason": "Required property \"To\" on Assign contains generic type default \"Nothing\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "Nothing",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "ExtractInvoiceFields.xaml",
      "workflow": "ExtractInvoiceFields",
      "activityType": "Assign",
      "propertyName": "To",
      "failureReason": "Required property \"To\" on Assign contains generic type default \"Nothing\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "Nothing",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "CreateValidationTask.xaml",
      "workflow": "CreateValidationTask",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "failureReason": "Required property \"Message\" on LogMessage contains generic type default \"\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "CreateValidationTask.xaml",
      "workflow": "CreateValidationTask",
      "activityType": "Assign",
      "propertyName": "To",
      "failureReason": "Required property \"To\" on Assign contains generic type default \"Nothing\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "Nothing",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "CreateValidationTask.xaml",
      "workflow": "CreateValidationTask",
      "activityType": "Assign",
      "propertyName": "To",
      "failureReason": "Required property \"To\" on Assign contains generic type default \"Nothing\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "Nothing",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "CreateValidationTask.xaml",
      "workflow": "CreateValidationTask",
      "activityType": "Assign",
      "propertyName": "To",
      "failureReason": "Required property \"To\" on Assign contains generic type default \"Nothing\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "Nothing",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "CreateValidationTask.xaml",
      "workflow": "CreateValidationTask",
      "activityType": "Assign",
      "propertyName": "To",
      "failureReason": "Required property \"To\" on Assign contains generic type default \"Nothing\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "Nothing",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "CreateValidationTask.xaml",
      "workflow": "CreateValidationTask",
      "activityType": "Assign",
      "propertyName": "To",
      "failureReason": "Required property \"To\" on Assign contains generic type default \"Nothing\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "Nothing",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "CreateValidationTask.xaml",
      "workflow": "CreateValidationTask",
      "activityType": "Assign",
      "propertyName": "To",
      "failureReason": "Required property \"To\" on Assign contains generic type default \"Nothing\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "Nothing",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "CreateValidationTask.xaml",
      "workflow": "CreateValidationTask",
      "activityType": "Assign",
      "propertyName": "To",
      "failureReason": "Required property \"To\" on Assign contains generic type default \"Nothing\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "Nothing",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "CreateValidationTask.xaml",
      "workflow": "CreateValidationTask",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "failureReason": "Required property \"Message\" on LogMessage contains generic type default \"\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "ValidateAndDecide.xaml",
      "workflow": "ValidateAndDecide",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "failureReason": "Required property \"Message\" on LogMessage contains generic type default \"\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "ValidateAndDecide.xaml",
      "workflow": "ValidateAndDecide",
      "activityType": "Assign",
      "propertyName": "To",
      "failureReason": "Required property \"To\" on Assign contains generic type default \"Nothing\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "Nothing",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "ValidateAndDecide.xaml",
      "workflow": "ValidateAndDecide",
      "activityType": "Assign",
      "propertyName": "To",
      "failureReason": "Required property \"To\" on Assign contains generic type default \"Nothing\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "Nothing",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "ValidateAndDecide.xaml",
      "workflow": "ValidateAndDecide",
      "activityType": "Assign",
      "propertyName": "To",
      "failureReason": "Required property \"To\" on Assign contains generic type default \"Nothing\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "Nothing",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "ValidateAndDecide.xaml",
      "workflow": "ValidateAndDecide",
      "activityType": "Assign",
      "propertyName": "To",
      "failureReason": "Required property \"To\" on Assign contains generic type default \"Nothing\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "Nothing",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "ValidateAndDecide.xaml",
      "workflow": "ValidateAndDecide",
      "activityType": "Assign",
      "propertyName": "To",
      "failureReason": "Required property \"To\" on Assign contains generic type default \"Nothing\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "Nothing",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "ValidateAndDecide.xaml",
      "workflow": "ValidateAndDecide",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "failureReason": "Required property \"Message\" on LogMessage contains generic type default \"\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "ValidateAndDecide.xaml",
      "workflow": "ValidateAndDecide",
      "activityType": "Assign",
      "propertyName": "To",
      "failureReason": "Required property \"To\" on Assign contains generic type default \"Nothing\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "Nothing",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "ValidateAndDecide.xaml",
      "workflow": "ValidateAndDecide",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "failureReason": "Required property \"Message\" on LogMessage contains generic type default \"\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "ValidateAndDecide.xaml",
      "workflow": "ValidateAndDecide",
      "activityType": "Assign",
      "propertyName": "To",
      "failureReason": "Required property \"To\" on Assign contains generic type default \"Nothing\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "Nothing",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "ValidateAndDecide.xaml",
      "workflow": "ValidateAndDecide",
      "activityType": "Assign",
      "propertyName": "To",
      "failureReason": "Required property \"To\" on Assign contains generic type default \"Nothing\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "Nothing",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "ValidateAndDecide.xaml",
      "workflow": "ValidateAndDecide",
      "activityType": "Assign",
      "propertyName": "To",
      "failureReason": "Required property \"To\" on Assign contains generic type default \"Nothing\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "Nothing",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "ValidateAndDecide.xaml",
      "workflow": "ValidateAndDecide",
      "activityType": "Assign",
      "propertyName": "To",
      "failureReason": "Required property \"To\" on Assign contains generic type default \"Nothing\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "Nothing",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "ValidateAndDecide.xaml",
      "workflow": "ValidateAndDecide",
      "activityType": "Assign",
      "propertyName": "To",
      "failureReason": "Required property \"To\" on Assign contains generic type default \"Nothing\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "Nothing",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "ValidateAndDecide.xaml",
      "workflow": "ValidateAndDecide",
      "activityType": "Assign",
      "propertyName": "To",
      "failureReason": "Required property \"To\" on Assign contains generic type default \"Nothing\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "Nothing",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "ValidateAndDecide.xaml",
      "workflow": "ValidateAndDecide",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "failureReason": "Required property \"Message\" on LogMessage contains generic type default \"\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "ValidateAndDecide.xaml",
      "workflow": "ValidateAndDecide",
      "activityType": "Assign",
      "propertyName": "To",
      "failureReason": "Required property \"To\" on Assign contains generic type default \"Nothing\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "Nothing",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "ValidateAndDecide.xaml",
      "workflow": "ValidateAndDecide",
      "activityType": "Assign",
      "propertyName": "To",
      "failureReason": "Required property \"To\" on Assign contains generic type default \"Nothing\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "Nothing",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "ValidateAndDecide.xaml",
      "workflow": "ValidateAndDecide",
      "activityType": "Assign",
      "propertyName": "To",
      "failureReason": "Required property \"To\" on Assign contains generic type default \"Nothing\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "Nothing",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "ValidateAndDecide.xaml",
      "workflow": "ValidateAndDecide",
      "activityType": "Assign",
      "propertyName": "To",
      "failureReason": "Required property \"To\" on Assign contains generic type default \"Nothing\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "Nothing",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "ValidateAndDecide.xaml",
      "workflow": "ValidateAndDecide",
      "activityType": "LogMessage",
      "propertyName": "Message",
      "failureReason": "Required property \"Message\" on LogMessage contains generic type default \"\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    },
    {
      "file": "ValidateAndDecide.xaml",
      "workflow": "ValidateAndDecide",
      "activityType": "Assign",
      "propertyName": "To",
      "failureReason": "Required property \"To\" on Assign contains generic type default \"Nothing\" — source resolution attempted but no valid upstream source found — invalid substitution blocked",
      "originalValue": "Nothing",
      "severity": "execution_blocking",
      "packageModeOutcome": "structured_defect"
    }
  ],
  "expressionLoweringFixes": [
    {
      "file": "Dispatcher.xaml",
      "workflow": "Dispatcher",
      "activityType": "DeserializeJson",
      "propertyName": "JsonString",
      "originalValue": "{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;str_CoupaApiResponse&quot;}",
      "resolvedValue": "[str_CoupaApiResponse]",
      "severity": "info",
      "packageModeOutcome": "lowered",
      "occurrenceIndex": 0
    },
    {
      "file": "Dispatcher.xaml",
      "workflow": "Dispatcher",
      "activityType": "CreateEntityRecord",
      "propertyName": "EntityObject",
      "originalValue": "{&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;New Dictionary(Of String, Object) From {{\\&quot;CoupaInvoiceId\\&quot;, str_CurrentInvoiceId}, {\\&quot;VendorName\\&quot;, str_CurrentVendorName}, {\\&quot;SubmittedUtc\\&quot;, str_CurrentSubmittedUtc}, {\\&quot;QueuedUtc\\&quot;, DateTime.UtcNow.ToString(\\&quot;yyyy-MM-ddTHH:mm:ssZ\\&quot;)}, {\\&quot;CaseStatus\\&quot;, \\&quot;Queued\\&quot;}, {\\&quot;NeedsHumanValidation\\&quot;, False}, {\\&quot;PdfBucketPath\\&quot;, String.Empty}, {\\&quot;ValidationOverdue\\&quot;, False}, {\\&quot;PONotFound\\&quot;, False}, {\\&quot;POMismatch\\&quot;, False}, {\\&quot;TolerancePercent\\&quot;, 5.0}}&quot;}",
      "resolvedValue": "[New Dictionary(Of String, Object) From {{\"CoupaInvoiceId\", str_CurrentInvoiceId}, {\"VendorName\", str_CurrentVendorName}, {\"SubmittedUtc\", str_CurrentSubmittedUtc}, {\"QueuedUtc\", DateTime.UtcNow.ToString(\"yyyy-MM-ddTHH:mm:ssZ\")}, {\"CaseStatus\", \"Queued\"}, {\"NeedsHumanValidation\", False}, {\"PdfBucketPath\", String.Empty}, {\"ValidationOverdue\", False}, {\"PONotFound\", False}, {\"POMismatch\", False}, {\"TolerancePercent\", 5.0}}]",
      "severity": "info",
      "packageModeOutcome": "lowered",
      "occurrenceIndex": 0
    },
    {
      "file": "ProcessTransaction.xaml",
      "workflow": "ProcessTransaction",
      "activityType": "UpdateEntity",
      "propertyName": "EntityObject",
      "originalValue": "{&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;New With {.CoupaInvoiceId = CoupaInvoiceId, .CaseStatus = \\&quot;InProgress\\&quot;, .PickedUpUtc = pickedUpUtc}&quot;}",
      "resolvedValue": "[New With {.CoupaInvoiceId = CoupaInvoiceId, .CaseStatus = \"InProgress\", .PickedUpUtc = pickedUpUtc}]",
      "severity": "info",
      "packageModeOutcome": "lowered",
      "occurrenceIndex": 0
    },
    {
      "file": "RetrieveInvoicePdf.xaml",
      "workflow": "RetrieveInvoicePdf",
      "activityType": "HttpClientRequest",
      "propertyName": "EndPoint",
      "originalValue": "{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;InvoicePdfUrl&quot;}",
      "resolvedValue": "[InvoicePdfUrl]",
      "severity": "info",
      "packageModeOutcome": "lowered",
      "occurrenceIndex": 0
    },
    {
      "file": "RetrieveInvoicePdf.xaml",
      "workflow": "RetrieveInvoicePdf",
      "activityType": "HttpClientRequest",
      "propertyName": "EndPoint",
      "originalValue": "{&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;\\&quot;https://cloud.uipath.com/orchestrator_/odata/Buckets/UiPath.Server.Configuration.OData.GetWriteUri?path=\\&quot; &amp; bucketPathResolved &amp; \\&quot;&amp;bucketName=SB_CoupaInvoiceRecon_Invoices\\&quot;&quot;}",
      "resolvedValue": "[\"https://cloud.uipath.com/orchestrator_/odata/Buckets/UiPath.Server.Configuration.OData.GetWriteUri?path=\" & bucketPathResolved & \"&bucketName=SB_CoupaInvoiceRecon_Invoices\"]",
      "severity": "info",
      "packageModeOutcome": "lowered",
      "occurrenceIndex": 1
    },
    {
      "file": "CreateValidationTask.xaml",
      "workflow": "CreateValidationTask",
      "activityType": "CreateFormTask",
      "propertyName": "Title",
      "originalValue": "{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;taskTitle&quot;}",
      "resolvedValue": "[taskTitle]",
      "severity": "info",
      "packageModeOutcome": "lowered",
      "occurrenceIndex": 0
    },
    {
      "file": "CreateValidationTask.xaml",
      "workflow": "CreateValidationTask",
      "activityType": "UpdateEntity",
      "propertyName": "EntityObject",
      "originalValue": "{&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;New With {.CoupaInvoiceId = CoupaInvoiceId, .CaseStatus = \\&quot;PendingValidation\\&quot;, .NeedsHumanValidation = True, .ValidationDueUtc = taskDueUtc}&quot;}",
      "resolvedValue": "[New With {.CoupaInvoiceId = CoupaInvoiceId, .CaseStatus = \"PendingValidation\", .NeedsHumanValidation = True, .ValidationDueUtc = taskDueUtc}]",
      "severity": "info",
      "packageModeOutcome": "lowered",
      "occurrenceIndex": 0
    },
    {
      "file": "CreateValidationTask.xaml",
      "workflow": "CreateValidationTask",
      "activityType": "CreateEntityRecord",
      "propertyName": "EntityObject",
      "originalValue": "{&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;New With {.CoupaInvoiceId = CoupaInvoiceId, .EventUtc = DateTime.UtcNow, .EventType = \\&quot;ValidationTaskCreated\\&quot;, .EventDetail = \\&quot;Action Center task created. TaskId=\\&quot; &amp; createdTaskId &amp; \\&quot;; DueUtc=\\&quot; &amp; taskDueUtc.ToString(\\&quot;o\\&quot;) &amp; \\&quot;; Catalog=AC_CoupaInvoiceRecon_DUValidation\\&quot;}&quot;}",
      "resolvedValue": "[New With {.CoupaInvoiceId = CoupaInvoiceId, .EventUtc = DateTime.UtcNow, .EventType = \"ValidationTaskCreated\", .EventDetail = \"Action Center task created. TaskId=\" & createdTaskId & \"; DueUtc=\" & taskDueUtc.ToString(\"o\") & \"; Catalog=AC_CoupaInvoiceRecon_DUValidation\"}]",
      "severity": "info",
      "packageModeOutcome": "lowered",
      "occurrenceIndex": 0
    },
    {
      "file": "ValidateAndDecide.xaml",
      "workflow": "ValidateAndDecide",
      "activityType": "HttpClient",
      "propertyName": "EndPoint",
      "originalValue": "{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;poLookupUrl&quot;}",
      "resolvedValue": "[poLookupUrl]",
      "severity": "info",
      "packageModeOutcome": "lowered",
      "occurrenceIndex": 0
    },
    {
      "file": "ValidateAndDecide.xaml",
      "workflow": "ValidateAndDecide",
      "activityType": "HttpClient",
      "propertyName": "EndPoint",
      "originalValue": "{&quot;type&quot;:&quot;variable&quot;,&quot;name&quot;:&quot;rejectUrl&quot;}",
      "resolvedValue": "[rejectUrl]",
      "severity": "info",
      "packageModeOutcome": "lowered",
      "occurrenceIndex": 1
    },
    {
      "file": "ValidateAndDecide.xaml",
      "workflow": "ValidateAndDecide",
      "activityType": "UpdateEntity",
      "propertyName": "EntityObject",
      "originalValue": "{&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;New With {.CaseStatus = \\&quot;Rejected\\&quot;, .RejectionReasonCode = \\&quot;PO_MISMATCH_OR_NOT_FOUND\\&quot;, .CoupaActionResult = CStr(coupaRejectResponse), .CompletedUtc = DateTime.UtcNow}&quot;}",
      "resolvedValue": "[New With {.CaseStatus = \"Rejected\", .RejectionReasonCode = \"PO_MISMATCH_OR_NOT_FOUND\", .CoupaActionResult = CStr(coupaRejectResponse), .CompletedUtc = DateTime.UtcNow}]",
      "severity": "info",
      "packageModeOutcome": "lowered",
      "occurrenceIndex": 0
    }
  ],
  "expressionLoweringFailures": [],
  "requiredPropertyEnforcementSummary": "473 required property binding(s) resolved; 137 unresolved required property defect(s); 11 structured expression(s) lowered; 136 invalid generic substitution(s) blocked",
  "preComplianceGuardPassed": true,
  "preComplianceGuardViolationCount": 0,
  "canonicalizationArchiveParity": [
    {
      "file": "Main.xaml",
      "preCanonicalizationHash": "53a70c603eb06f06582906c40dcf7be3ae7053ec8644daf797b8105e25de00a8",
      "canonicalizedHash": "95e2b3a56dd6f2f7e089df88f84c5c533061ad4ef1ab0108722082962d66ca28",
      "archivedHash": "95e2b3a56dd6f2f7e089df88f84c5c533061ad4ef1ab0108722082962d66ca28",
      "identical": true,
      "mutated": true
    },
    {
      "file": "Dispatcher.xaml",
      "preCanonicalizationHash": "4097d1b5d5a138ebb9cb1177f8b6da0d2ebeb039461c44f705473d8b121ceef6",
      "canonicalizedHash": "98bb31d721f2fb47a79ace4ac3a050b07c5450a250a3b919709b5bc942abed6e",
      "archivedHash": "98bb31d721f2fb47a79ace4ac3a050b07c5450a250a3b919709b5bc942abed6e",
      "identical": true,
      "mutated": true
    },
    {
      "file": "InitialiseConfig.xaml",
      "preCanonicalizationHash": "7f7907e4ef548d69559a60a246b821e646261843c54c0c0e553cc715d4f1157c",
      "canonicalizedHash": "a93a316afc5150edb94288ae5a238d0d82ac3321af6a9c39a9b001feac43c658",
      "archivedHash": "a93a316afc5150edb94288ae5a238d0d82ac3321af6a9c39a9b001feac43c658",
      "identical": true,
      "mutated": true
    },
    {
      "file": "ProcessTransaction.xaml",
      "preCanonicalizationHash": "88795396df483d629f85103276db97c609c71b38627e90b49ed015ea8b3151aa",
      "canonicalizedHash": "67ca8703cf90f9af3572a29913c42927ba3b1a79de5011e0145978351bf2fcef",
      "archivedHash": "67ca8703cf90f9af3572a29913c42927ba3b1a79de5011e0145978351bf2fcef",
      "identical": true,
      "mutated": true
    },
    {
      "file": "RetrieveInvoicePdf.xaml",
      "preCanonicalizationHash": "894884fb148e2f14a35a49f5ff126f85ce687347cc63d9bee471933a4fc8a90d",
      "canonicalizedHash": "f692bab3ec60059aae9243b3293942e36fd44ed8faacfa7d619ec4d76f3ca11b",
      "archivedHash": "f692bab3ec60059aae9243b3293942e36fd44ed8faacfa7d619ec4d76f3ca11b",
      "identical": true,
      "mutated": true
    },
    {
      "file": "ExtractInvoiceFields.xaml",
      "preCanonicalizationHash": "0e014b02a58fc809298dd656c9b094ca2081cb7ffb30239c1ff2ed3ee919769b",
      "canonicalizedHash": "bd20252928a59768810a45d76aec152cd665ef0910d01b93f8c5f8bd410ae524",
      "archivedHash": "bd20252928a59768810a45d76aec152cd665ef0910d01b93f8c5f8bd410ae524",
      "identical": true,
      "mutated": true
    },
    {
      "file": "CreateValidationTask.xaml",
      "preCanonicalizationHash": "ffd0ab0bf72fd32c92dc1ead2d33445e5eb855acbe9b5eb073c0cfcfc6ee453c",
      "canonicalizedHash": "57d34e562b76d7be80ddb9fe6c76332651d1f6ec238749c0751b896fbf1bd062",
      "archivedHash": "57d34e562b76d7be80ddb9fe6c76332651d1f6ec238749c0751b896fbf1bd062",
      "identical": true,
      "mutated": true
    },
    {
      "file": "ValidateAndDecide.xaml",
      "preCanonicalizationHash": "fa4fe7f5098f358c13d71c5b433742020646fb6eca805abce23bd31f6d1e4abe",
      "canonicalizedHash": "d6b3824f73afe05c901a88c6dcfa89fa07ccd3e87e747ac520ed398780b50074",
      "archivedHash": "d6b3824f73afe05c901a88c6dcfa89fa07ccd3e87e747ac520ed398780b50074",
      "identical": true,
      "mutated": true
    },
    {
      "file": "InitAllSettings.xaml",
      "preCanonicalizationHash": "64e6306774a67dc60a66faed3c0cf330e8c34a6fde53339854591e49c02b9fff",
      "canonicalizedHash": "64e6306774a67dc60a66faed3c0cf330e8c34a6fde53339854591e49c02b9fff",
      "archivedHash": "64e6306774a67dc60a66faed3c0cf330e8c34a6fde53339854591e49c02b9fff",
      "identical": true,
      "mutated": false
    }
  ],
  "preArchiveStructuralDefects": [
    {
      "file": "Main.xaml",
      "pattern": "object_payload_in_target_value_slot",
      "detail": "Object payload in target/value slot: <Assign.To><OutArgument x:TypeArguments=\"x:String\">Nothing</OutArgument></Assign.To>\n              <Assign.Value><InArgu"
    },
    {
      "file": "Dispatcher.xaml",
      "pattern": "object_payload_in_target_value_slot",
      "detail": "Object payload in target/value slot: <Assign.To><OutArgument x:TypeArguments=\"x:String\">Nothing</OutArgument></Assign.To>\n              <Assign.Value><InArgu"
    },
    {
      "file": "InitialiseConfig.xaml",
      "pattern": "object_payload_in_target_value_slot",
      "detail": "Object payload in target/value slot: <Assign.To><OutArgument x:TypeArguments=\"x:String\">Nothing</OutArgument></Assign.To>\n              <Assign.Value><InArgu"
    },
    {
      "file": "ProcessTransaction.xaml",
      "pattern": "object_payload_in_target_value_slot",
      "detail": "Object payload in target/value slot: <Assign.To><OutArgument x:TypeArguments=\"x:String\">Nothing</OutArgument></Assign.To>\n              <Assign.Value><InArgu"
    },
    {
      "file": "RetrieveInvoicePdf.xaml",
      "pattern": "object_payload_in_target_value_slot",
      "detail": "Object payload in target/value slot: <Assign.To><OutArgument x:TypeArguments=\"x:String\">Nothing</OutArgument></Assign.To>\n              <Assign.Value><InArgu"
    },
    {
      "file": "ExtractInvoiceFields.xaml",
      "pattern": "object_payload_in_target_value_slot",
      "detail": "Object payload in target/value slot: <Assign.To><OutArgument x:TypeArguments=\"x:String\">Nothing</OutArgument></Assign.To>\n              <Assign.Value><InArgu"
    },
    {
      "file": "ValidateAndDecide.xaml",
      "pattern": "object_payload_in_target_value_slot",
      "detail": "Object payload in target/value slot: <Assign.To><OutArgument x:TypeArguments=\"x:String\">Nothing</OutArgument></Assign.To>\n              <Assign.Value><InArgu"
    },
    {
      "file": "InitAllSettings.xaml",
      "pattern": "malformed_attribute_quoting",
      "detail": "Malformed attribute quoting detected: AssetName=\"[&quot;Cred_Coupa_API&quot;]"
    }
  ],
  "postClassifierMutationTrace": {
    "entries": [
      {
        "stage": "pre-freeze-snapshot",
        "function": "freezeArchiveWorkflows",
        "file": "CreateValidationTask.xaml",
        "mutationType": "xaml_bytes",
        "preHash": "N/A",
        "postHash": "57d34e562b76d7be80ddb9fe6c76332651d1f6ec238749c0751b896fbf1bd062",
        "allowed": true,
        "reason": "Workflow \"CreateValidationTask.xaml\" content captured at freeze point (status=non-stub)",
        "changedBytes": false,
        "changedStatus": false,
        "enforcementAction": "none"
      },
      {
        "stage": "pre-freeze-snapshot",
        "function": "freezeArchiveWorkflows",
        "file": "Dispatcher.xaml",
        "mutationType": "xaml_bytes",
        "preHash": "N/A",
        "postHash": "98bb31d721f2fb47a79ace4ac3a050b07c5450a250a3b919709b5bc942abed6e",
        "allowed": true,
        "reason": "Workflow \"Dispatcher.xaml\" content captured at freeze point (status=non-stub)",
        "changedBytes": false,
        "changedStatus": false,
        "enforcementAction": "none"
      },
      {
        "stage": "pre-freeze-snapshot",
        "function": "freezeArchiveWorkflows",
        "file": "ExtractInvoiceFields.xaml",
        "mutationType": "xaml_bytes",
        "preHash": "N/A",
        "postHash": "bd20252928a59768810a45d76aec152cd665ef0910d01b93f8c5f8bd410ae524",
        "allowed": true,
        "reason": "Workflow \"ExtractInvoiceFields.xaml\" content captured at freeze point (status=non-stub)",
        "changedBytes": false,
        "changedStatus": false,
        "enforcementAction": "none"
      },
      {
        "stage": "pre-freeze-snapshot",
        "function": "freezeArchiveWorkflows",
        "file": "InitAllSettings.xaml",
        "mutationType": "xaml_bytes",
        "preHash": "N/A",
        "postHash": "64e6306774a67dc60a66faed3c0cf330e8c34a6fde53339854591e49c02b9fff",
        "allowed": true,
        "reason": "Workflow \"InitAllSettings.xaml\" content captured at freeze point (status=non-stub)",
        "changedBytes": false,
        "changedStatus": false,
        "enforcementAction": "none"
      },
      {
        "stage": "pre-freeze-snapshot",
        "function": "freezeArchiveWorkflows",
        "file": "InitialiseConfig.xaml",
        "mutationType": "xaml_bytes",
        "preHash": "N/A",
        "postHash": "a93a316afc5150edb94288ae5a238d0d82ac3321af6a9c39a9b001feac43c658",
        "allowed": true,
        "reason": "Workflow \"InitialiseConfig.xaml\" content captured at freeze point (status=non-stub)",
        "changedBytes": false,
        "changedStatus": false,
        "enforcementAction": "none"
      },
      {
        "stage": "pre-freeze-snapshot",
        "function": "freezeArchiveWorkflows",
        "file": "Main.xaml",
        "mutationType": "xaml_bytes",
        "preHash": "N/A",
        "postHash": "95e2b3a56dd6f2f7e089df88f84c5c533061ad4ef1ab0108722082962d66ca28",
        "allowed": true,
        "reason": "Workflow \"Main.xaml\" content captured at freeze point (status=non-stub)",
        "changedBytes": false,
        "changedStatus": false,
        "enforcementAction": "none"
      },
      {
        "stage": "pre-freeze-snapshot",
        "function": "freezeArchiveWorkflows",
        "file": "ProcessTransaction.xaml",
        "mutationType": "xaml_bytes",
        "preHash": "N/A",
        "postHash": "67ca8703cf90f9af3572a29913c42927ba3b1a79de5011e0145978351bf2fcef",
        "allowed": true,
        "reason": "Workflow \"ProcessTransaction.xaml\" content captured at freeze point (status=non-stub)",
        "changedBytes": false,
        "changedStatus": false,
        "enforcementAction": "none"
      },
      {
        "stage": "pre-freeze-snapshot",
        "function": "freezeArchiveWorkflows",
        "file": "RetrieveInvoicePdf.xaml",
        "mutationType": "xaml_bytes",
        "preHash": "N/A",
        "postHash": "f692bab3ec60059aae9243b3293942e36fd44ed8faacfa7d619ec4d76f3ca11b",
        "allowed": true,
        "reason": "Workflow \"RetrieveInvoicePdf.xaml\" content captured at freeze point (status=non-stub)",
        "changedBytes": false,
        "changedStatus": false,
        "enforcementAction": "none"
      },
      {
        "stage": "pre-freeze-snapshot",
        "function": "freezeArchiveWorkflows",
        "file": "ValidateAndDecide.xaml",
        "mutationType": "xaml_bytes",
        "preHash": "N/A",
        "postHash": "d6b3824f73afe05c901a88c6dcfa89fa07ccd3e87e747ac520ed398780b50074",
        "allowed": true,
        "reason": "Workflow \"ValidateAndDecide.xaml\" content captured at freeze point (status=non-stub)",
        "changedBytes": false,
        "changedStatus": false,
        "enforcementAction": "none"
      }
    ],
    "perFileMutationCounts": {
      "CreateValidationTask.xaml": 1,
      "Dispatcher.xaml": 1,
      "ExtractInvoiceFields.xaml": 1,
      "InitAllSettings.xaml": 1,
      "InitialiseConfig.xaml": 1,
      "Main.xaml": 1,
      "ProcessTransaction.xaml": 1,
      "RetrieveInvoicePdf.xaml": 1,
      "ValidateAndDecide.xaml": 1
    },
    "filesChangedAfterFreeze": [],
    "summary": {
      "totalAttemptedMutations": 9,
      "totalBlockedMutations": 0,
      "totalAllowedPreFreezeMutations": 9,
      "totalPostFreezeViolations": 0,
      "totalUnexpectedPostFreezeMutations": 0,
      "filesChangedAfterFreeze": 0
    }
  },
  "postFreezeMutationTrace": {
    "entries": [
      {
        "stage": "pre-freeze-snapshot",
        "function": "freezeArchiveWorkflows",
        "file": "CreateValidationTask.xaml",
        "mutationType": "xaml_bytes",
        "preHash": "N/A",
        "postHash": "57d34e562b76d7be80ddb9fe6c76332651d1f6ec238749c0751b896fbf1bd062",
        "allowed": true,
        "reason": "Workflow \"CreateValidationTask.xaml\" content captured at freeze point (status=non-stub)",
        "changedBytes": false,
        "changedStatus": false,
        "enforcementAction": "none"
      },
      {
        "stage": "pre-freeze-snapshot",
        "function": "freezeArchiveWorkflows",
        "file": "Dispatcher.xaml",
        "mutationType": "xaml_bytes",
        "preHash": "N/A",
        "postHash": "98bb31d721f2fb47a79ace4ac3a050b07c5450a250a3b919709b5bc942abed6e",
        "allowed": true,
        "reason": "Workflow \"Dispatcher.xaml\" content captured at freeze point (status=non-stub)",
        "changedBytes": false,
        "changedStatus": false,
        "enforcementAction": "none"
      },
      {
        "stage": "pre-freeze-snapshot",
        "function": "freezeArchiveWorkflows",
        "file": "ExtractInvoiceFields.xaml",
        "mutationType": "xaml_bytes",
        "preHash": "N/A",
        "postHash": "bd20252928a59768810a45d76aec152cd665ef0910d01b93f8c5f8bd410ae524",
        "allowed": true,
        "reason": "Workflow \"ExtractInvoiceFields.xaml\" content captured at freeze point (status=non-stub)",
        "changedBytes": false,
        "changedStatus": false,
        "enforcementAction": "none"
      },
      {
        "stage": "pre-freeze-snapshot",
        "function": "freezeArchiveWorkflows",
        "file": "InitAllSettings.xaml",
        "mutationType": "xaml_bytes",
        "preHash": "N/A",
        "postHash": "64e6306774a67dc60a66faed3c0cf330e8c34a6fde53339854591e49c02b9fff",
        "allowed": true,
        "reason": "Workflow \"InitAllSettings.xaml\" content captured at freeze point (status=non-stub)",
        "changedBytes": false,
        "changedStatus": false,
        "enforcementAction": "none"
      },
      {
        "stage": "pre-freeze-snapshot",
        "function": "freezeArchiveWorkflows",
        "file": "InitialiseConfig.xaml",
        "mutationType": "xaml_bytes",
        "preHash": "N/A",
        "postHash": "a93a316afc5150edb94288ae5a238d0d82ac3321af6a9c39a9b001feac43c658",
        "allowed": true,
        "reason": "Workflow \"InitialiseConfig.xaml\" content captured at freeze point (status=non-stub)",
        "changedBytes": false,
        "changedStatus": false,
        "enforcementAction": "none"
      },
      {
        "stage": "pre-freeze-snapshot",
        "function": "freezeArchiveWorkflows",
        "file": "Main.xaml",
        "mutationType": "xaml_bytes",
        "preHash": "N/A",
        "postHash": "95e2b3a56dd6f2f7e089df88f84c5c533061ad4ef1ab0108722082962d66ca28",
        "allowed": true,
        "reason": "Workflow \"Main.xaml\" content captured at freeze point (status=non-stub)",
        "changedBytes": false,
        "changedStatus": false,
        "enforcementAction": "none"
      },
      {
        "stage": "pre-freeze-snapshot",
        "function": "freezeArchiveWorkflows",
        "file": "ProcessTransaction.xaml",
        "mutationType": "xaml_bytes",
        "preHash": "N/A",
        "postHash": "67ca8703cf90f9af3572a29913c42927ba3b1a79de5011e0145978351bf2fcef",
        "allowed": true,
        "reason": "Workflow \"ProcessTransaction.xaml\" content captured at freeze point (status=non-stub)",
        "changedBytes": false,
        "changedStatus": false,
        "enforcementAction": "none"
      },
      {
        "stage": "pre-freeze-snapshot",
        "function": "freezeArchiveWorkflows",
        "file": "RetrieveInvoicePdf.xaml",
        "mutationType": "xaml_bytes",
        "preHash": "N/A",
        "postHash": "f692bab3ec60059aae9243b3293942e36fd44ed8faacfa7d619ec4d76f3ca11b",
        "allowed": true,
        "reason": "Workflow \"RetrieveInvoicePdf.xaml\" content captured at freeze point (status=non-stub)",
        "changedBytes": false,
        "changedStatus": false,
        "enforcementAction": "none"
      },
      {
        "stage": "pre-freeze-snapshot",
        "function": "freezeArchiveWorkflows",
        "file": "ValidateAndDecide.xaml",
        "mutationType": "xaml_bytes",
        "preHash": "N/A",
        "postHash": "d6b3824f73afe05c901a88c6dcfa89fa07ccd3e87e747ac520ed398780b50074",
        "allowed": true,
        "reason": "Workflow \"ValidateAndDecide.xaml\" content captured at freeze point (status=non-stub)",
        "changedBytes": false,
        "changedStatus": false,
        "enforcementAction": "none"
      }
    ],
    "perFileMutationCounts": {
      "CreateValidationTask.xaml": 1,
      "Dispatcher.xaml": 1,
      "ExtractInvoiceFields.xaml": 1,
      "InitAllSettings.xaml": 1,
      "InitialiseConfig.xaml": 1,
      "Main.xaml": 1,
      "ProcessTransaction.xaml": 1,
      "RetrieveInvoicePdf.xaml": 1,
      "ValidateAndDecide.xaml": 1
    },
    "filesChangedAfterFreeze": [],
    "summary": {
      "totalAttemptedMutations": 9,
      "totalBlockedMutations": 0,
      "totalAllowedPreFreezeMutations": 9,
      "totalPostFreezeViolations": 0,
      "totalUnexpectedPostFreezeMutations": 0,
      "filesChangedAfterFreeze": 0
    }
  },
  "workflowAutoWiringDiagnostics": {
    "entries": [
      {
        "file": "Main.xaml",
        "generated": true,
        "required": true,
        "workflowRole": "entrypoint",
        "classificationSourceRule": "basename_match:Main",
        "requiredByPath": "Main.xaml (entry point)",
        "expectedCaller": null,
        "callerCandidates": [],
        "invokeAttempted": false,
        "invokeSucceeded": false,
        "invokeSkippedReason": "entrypoint workflow — wired by framework structure",
        "invokeRejectedReason": null,
        "actualCallers": [],
        "reachableFromMain": true,
        "finalWiringStatus": "wired_and_reachable",
        "rootCauseCategory": "none",
        "remediationHint": null,
        "unwiredSeverity": "none"
      },
      {
        "file": "Dispatcher.xaml",
        "generated": true,
        "required": true,
        "workflowRole": "decomposed_child",
        "classificationSourceRule": "generated_by_spec_decomposition",
        "requiredByPath": "Main.xaml → Process.xaml → spec-decomposition:Dispatcher",
        "expectedCaller": "Process.xaml",
        "callerCandidates": [
          "Process.xaml",
          "Main.xaml"
        ],
        "invokeAttempted": true,
        "invokeSucceeded": false,
        "invokeSkippedReason": null,
        "invokeRejectedReason": "Process.xaml content is empty or not found — no wiring target available",
        "actualCallers": [],
        "reachableFromMain": false,
        "finalWiringStatus": "unwired_but_retained",
        "rootCauseCategory": "invoke_emission_skipped_no_process_xaml",
        "remediationHint": "Process.xaml content is empty or not found — no wiring target available",
        "unwiredSeverity": "package_fatal"
      },
      {
        "file": "InitialiseConfig.xaml",
        "generated": true,
        "required": true,
        "workflowRole": "decomposed_child",
        "classificationSourceRule": "generated_by_spec_decomposition",
        "requiredByPath": "Main.xaml → Main.xaml → spec-decomposition:InitialiseConfig",
        "expectedCaller": "Main.xaml",
        "callerCandidates": [
          "Main.xaml",
          "Process.xaml"
        ],
        "invokeAttempted": true,
        "invokeSucceeded": true,
        "invokeSkippedReason": null,
        "invokeRejectedReason": null,
        "actualCallers": [
          "Main.xaml"
        ],
        "reachableFromMain": true,
        "finalWiringStatus": "wired_and_reachable",
        "rootCauseCategory": "none",
        "remediationHint": null,
        "unwiredSeverity": "none"
      },
      {
        "file": "ProcessTransaction.xaml",
        "generated": true,
        "required": true,
        "workflowRole": "transaction_handler",
        "classificationSourceRule": "transaction_pattern_match:ProcessTransaction",
        "requiredByPath": "Main.xaml → state-machine transition",
        "expectedCaller": "Main.xaml",
        "callerCandidates": [
          "Main.xaml"
        ],
        "invokeAttempted": true,
        "invokeSucceeded": true,
        "invokeSkippedReason": null,
        "invokeRejectedReason": null,
        "actualCallers": [
          "Main.xaml"
        ],
        "reachableFromMain": true,
        "finalWiringStatus": "wired_and_reachable",
        "rootCauseCategory": "none",
        "remediationHint": null,
        "unwiredSeverity": "none"
      },
      {
        "file": "RetrieveInvoicePdf.xaml",
        "generated": true,
        "required": true,
        "workflowRole": "decomposed_child",
        "classificationSourceRule": "generated_by_spec_decomposition",
        "requiredByPath": "Main.xaml → ProcessTransaction.xaml → spec-decomposition:RetrieveInvoicePdf",
        "expectedCaller": "ProcessTransaction.xaml",
        "callerCandidates": [
          "ProcessTransaction.xaml",
          "Process.xaml",
          "Main.xaml"
        ],
        "invokeAttempted": true,
        "invokeSucceeded": true,
        "invokeSkippedReason": null,
        "invokeRejectedReason": null,
        "actualCallers": [
          "ProcessTransaction.xaml"
        ],
        "reachableFromMain": true,
        "finalWiringStatus": "wired_and_reachable",
        "rootCauseCategory": "none",
        "remediationHint": null,
        "unwiredSeverity": "none"
      },
      {
        "file": "ExtractInvoiceFields.xaml",
        "generated": true,
        "required": true,
        "workflowRole": "decomposed_child",
        "classificationSourceRule": "generated_by_spec_decomposition",
        "requiredByPath": "Main.xaml → ProcessTransaction.xaml → spec-decomposition:ExtractInvoiceFields",
        "expectedCaller": "ProcessTransaction.xaml",
        "callerCandidates": [
          "ProcessTransaction.xaml",
          "Process.xaml",
          "Main.xaml"
        ],
        "invokeAttempted": true,
        "invokeSucceeded": true,
        "invokeSkippedReason": null,
        "invokeRejectedReason": null,
        "actualCallers": [
          "ProcessTransaction.xaml"
        ],
        "reachableFromMain": true,
        "finalWiringStatus": "wired_and_reachable",
        "rootCauseCategory": "none",
        "remediationHint": null,
        "unwiredSeverity": "none"
      },
      {
        "file": "CreateValidationTask.xaml",
        "generated": true,
        "required": true,
        "workflowRole": "decomposed_child",
        "classificationSourceRule": "generated_by_spec_decomposition",
        "requiredByPath": "Main.xaml → ProcessTransaction.xaml → spec-decomposition:CreateValidationTask",
        "expectedCaller": "ProcessTransaction.xaml",
        "callerCandidates": [
          "ProcessTransaction.xaml",
          "Process.xaml",
          "Main.xaml"
        ],
        "invokeAttempted": true,
        "invokeSucceeded": true,
        "invokeSkippedReason": null,
        "invokeRejectedReason": null,
        "actualCallers": [
          "ProcessTransaction.xaml"
        ],
        "reachableFromMain": true,
        "finalWiringStatus": "wired_and_reachable",
        "rootCauseCategory": "none",
        "remediationHint": null,
        "unwiredSeverity": "none"
      },
      {
        "file": "ValidateAndDecide.xaml",
        "generated": true,
        "required": true,
        "workflowRole": "decomposed_child",
        "classificationSourceRule": "generated_by_spec_decomposition",
        "requiredByPath": "Main.xaml → ProcessTransaction.xaml → spec-decomposition:ValidateAndDecide",
        "expectedCaller": "ProcessTransaction.xaml",
        "callerCandidates": [
          "ProcessTransaction.xaml",
          "Process.xaml",
          "Main.xaml"
        ],
        "invokeAttempted": true,
        "invokeSucceeded": true,
        "invokeSkippedReason": null,
        "invokeRejectedReason": null,
        "actualCallers": [
          "ProcessTransaction.xaml"
        ],
        "reachableFromMain": true,
        "finalWiringStatus": "wired_and_reachable",
        "rootCauseCategory": "none",
        "remediationHint": null,
        "unwiredSeverity": "none"
      },
      {
        "file": "InitAllSettings.xaml",
        "generated": false,
        "required": false,
        "workflowRole": "helper",
        "classificationSourceRule": "infrastructure_basename_match:initallsettings",
        "unwiredSeverity": "none",
        "requiredByPath": "infrastructure utility",
        "expectedCaller": "Main.xaml",
        "callerCandidates": [
          "Main.xaml"
        ],
        "invokeAttempted": false,
        "invokeSucceeded": false,
        "invokeSkippedReason": "infrastructure file — always included",
        "invokeRejectedReason": null,
        "actualCallers": [],
        "reachableFromMain": false,
        "finalWiringStatus": "skipped_infrastructure",
        "rootCauseCategory": "none",
        "remediationHint": null
      }
    ],
    "summary": {
      "totalGeneratedWorkflows": 8,
      "totalRequiredWorkflows": 8,
      "totalRequiredWorkflowsWired": 7,
      "totalGeneratedButUnwired": 1,
      "totalUnreachableFromMain": 1,
      "totalMissingInvokeEdges": 0,
      "totalCallerMismatchDefects": 0,
      "totalInvokeEmissionFailures": 1
    },
    "activePathProof": {
      "reachabilityComputedOnFinalizedSet": true,
      "reachabilityPruningSkipped": false,
      "wiringComputedOnFinalizedSet": true,
      "workflowSetHashAtWiringTime": "eb9e5602c6eb992a",
      "workflowSetHashAtReachabilityTime": "eb9e5602c6eb992a",
      "consistent": true
    }
  },
  "catalogFilterAdoption": [
    {
      "stage": "quality-gate",
      "adopted": true,
      "lookups": {
        "total": 1767,
        "approved": 1767,
        "deprecated": 0,
        "nonEmissionApproved": 0,
        "targetIncompatible": 0,
        "unknown": 0
      }
    },
    {
      "stage": "deterministic-validators",
      "adopted": true,
      "lookups": {
        "total": 15018,
        "approved": 8250,
        "deprecated": 0,
        "nonEmissionApproved": 0,
        "targetIncompatible": 0,
        "unknown": 6768
      }
    },
    {
      "stage": "iterative-llm-corrector",
      "adopted": true,
      "lookups": {
        "total": 0,
        "approved": 0,
        "deprecated": 0,
        "nonEmissionApproved": 0,
        "targetIncompatible": 0,
        "unknown": 0
      }
    },
    {
      "stage": "workflow-tree-assembler",
      "adopted": true,
      "lookups": {
        "total": 0,
        "approved": 0,
        "deprecated": 0,
        "nonEmissionApproved": 0,
        "targetIncompatible": 0,
        "unknown": 0
      }
    },
    {
      "stage": "xaml-compliance",
      "adopted": true,
      "lookups": {
        "total": 13098,
        "approved": 7908,
        "deprecated": 0,
        "nonEmissionApproved": 2475,
        "targetIncompatible": 0,
        "unknown": 2715
      }
    },
    {
      "stage": "executable-path-validator",
      "adopted": true,
      "lookups": {
        "total": 939,
        "approved": 789,
        "deprecated": 0,
        "nonEmissionApproved": 0,
        "targetIncompatible": 0,
        "unknown": 150
      }
    },
    {
      "stage": "post-emission-dependency-analyzer",
      "adopted": true,
      "lookups": {
        "total": 10,
        "approved": 10,
        "deprecated": 0,
        "nonEmissionApproved": 0,
        "targetIncompatible": 0,
        "unknown": 0
      }
    }
  ]
}
```
