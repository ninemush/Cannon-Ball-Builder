# Developer Handoff Guide

**Project:** BirthdayGreetingsV5
**Generated:** 2026-03-29
**Generation Mode:** Baseline Openable (minimal, deterministic)
**Deployment Readiness:** Not Ready (19%)

**Total Estimated Effort: ~740 minutes (12.3 hours)**
**Remediations:** 42 total (0 property, 30 activity, 2 sequence, 8 structural-leaf, 2 workflow)
**Auto-Repairs:** 8
**Quality Warnings:** 7

---

## 1. Completed Work

No workflows were generated without remediation.

### Workflow Inventory

| # | Workflow | Status |
|---|----------|--------|
| 1 | `Main.xaml` | Structurally invalid (stub) |
| 2 | `WF_GetTodaysBirthdays.xaml` | Structurally invalid (stub) |
| 3 | `InitAllSettings.xaml` | Generated with Remediations |

### Studio Compatibility

| # | Workflow | Compatibility | Blockers |
|---|----------|--------------|----------|
| 1 | `Main.xaml` | Structurally invalid — requires fixes | [STUB_WORKFLOW_GENERATOR_FAILURE] Workflow was replaced with a stub due to ge... |
| 2 | `WF_GetTodaysBirthdays.xaml` | Structurally invalid — requires fixes | [STUB_WORKFLOW_GENERATOR_FAILURE] Workflow was replaced with a stub due to ge... |
| 3 | `InitAllSettings.xaml` | Studio-openable | — |

**Summary:** 1 clean, 0 with warnings, 2 blocked

> **⚠ 2 workflow(s) have structural defects that will prevent Studio from loading or executing them.** Address the blockers listed above before importing into Studio.

## 2. AI-Resolved with Smart Defaults

The following 8 issue(s) were automatically corrected during the build pipeline. **No developer action required.**

| # | Code | File | Description | Est. Minutes |
|---|------|------|-------------|-------------|
| 1 | `REPAIR_LOG_LEVEL_NORMALIZE` | `Main.xaml` | Normalised LogMessage Level="Information" → "Info" in Main.xaml | undefined |
| 2 | `REPAIR_LOG_LEVEL_NORMALIZE` | `Main.xaml` | Normalised LogMessage Level="Warning" → "Warn" in Main.xaml | undefined |
| 3 | `REPAIR_LOG_LEVEL_NORMALIZE` | `WF_GetTodaysBirthdays.xaml` | Normalised LogMessage Level="Information" → "Info" in WF_GetTodaysBirthdays.xaml | undefined |
| 4 | `REPAIR_LOG_LEVEL_NORMALIZE` | `WF_GetTodaysBirthdays.xaml` | Normalised LogMessage Level="Warning" → "Warn" in WF_GetTodaysBirthdays.xaml | undefined |
| 5 | `REPAIR_GENERIC` | `unknown` | Structural preservation: Main.xaml preserved unchanged — XML is valid but blocking issues could n... | undefined |
| 6 | `REPAIR_GENERIC` | `unknown` | Structural preservation: WF_GetTodaysBirthdays.xaml preserved unchanged — XML is valid but blocki... | undefined |
| 7 | `REPAIR_GENERIC` | `unknown` | Structural preservation: InitAllSettings.xaml preserved unchanged — XML is valid but blocking iss... | undefined |
| 8 | `REPAIR_GENERIC` | `unknown` | Skipped full-package stub escalation — structural-preservation stubs already cover affected files | undefined |

## 3. Manual Action Required

### Activity-Level Stubs (30)

Entire activities were replaced with TODO stubs. The surrounding workflow structure is preserved.

| # | File | Activity | Code | Developer Action | Est. Minutes |
|---|------|----------|------|-----------------|-------------|
| 1 | `Main.xaml` | OutArgument | `STUB_ACTIVITY_UNKNOWN` | Manually implement activity in Main.xaml — estimated 15 min | 15 |
| 2 | `Main.xaml` | InArgument | `STUB_ACTIVITY_UNKNOWN` | Manually implement activity in Main.xaml — estimated 15 min | 15 |
| 3 | `Main.xaml` | Stub: InArgument | `STUB_ACTIVITY_UNKNOWN` | Manually implement "Stub: InArgument" activity in Main.xaml — estimated 15 min | 15 |
| 4 | `Main.xaml` | OutArgument | `STUB_ACTIVITY_UNKNOWN` | Manually implement activity in Main.xaml — estimated 15 min | 15 |
| 5 | `Main.xaml` | InArgument | `STUB_ACTIVITY_UNKNOWN` | Manually implement activity in Main.xaml — estimated 15 min | 15 |
| 6 | `Main.xaml` | Stub: InArgument | `STUB_ACTIVITY_UNKNOWN` | Manually implement "Stub: InArgument" activity in Main.xaml — estimated 15 min | 15 |
| 7 | `Main.xaml` | Stub: Stub: InArgument | `STUB_ACTIVITY_UNKNOWN` | Manually implement "Stub: Stub: InArgument" activity in Main.xaml — estimated... | 15 |
| 8 | `Main.xaml` | OutArgument | `STUB_ACTIVITY_UNKNOWN` | Manually implement activity in Main.xaml — estimated 15 min | 15 |
| 9 | `Main.xaml` | OutArgument | `STUB_ACTIVITY_UNKNOWN` | Manually implement activity in Main.xaml — estimated 15 min | 15 |
| 10 | `Main.xaml` | OutArgument | `STUB_ACTIVITY_UNKNOWN` | Manually implement activity in Main.xaml — estimated 15 min | 15 |
| 11 | `Main.xaml` | InArgument | `STUB_ACTIVITY_UNKNOWN` | Manually implement activity in Main.xaml — estimated 15 min | 15 |
| 12 | `Main.xaml` | PHASE 1 — Init — Try: Validate critical assets non-empty | `STUB_ACTIVITY_UNKNOWN` | Manually implement "PHASE 1 — Init — Try: Validate critical assets non-empty"... | 15 |
| 13 | `Main.xaml` | Stub: PHASE 1 — Init — Try: Validate critical assets non-empty | `STUB_ACTIVITY_UNKNOWN` | Manually implement "Stub: PHASE 1 — Init — Try: Validate critical assets non-... | 15 |
| 14 | `Main.xaml` | Stub: Stub: PHASE 1 — Init — Try: Validate critical assets non-empty | `STUB_ACTIVITY_UNKNOWN` | Manually implement "Stub: Stub: PHASE 1 — Init — Try: Validate critical asset... | 15 |
| 15 | `Main.xaml` | Stub: Stub: Stub: PHASE 1 — Init — Try: Validate critical assets non-empty | `STUB_ACTIVITY_UNKNOWN` | Manually implement "Stub: Stub: Stub: PHASE 1 — Init — Try: Validate critical... | 15 |
| 16 | `Main.xaml` | PHASE 1 — Init: Initialise in-memory dedupe HashSet | `STUB_ACTIVITY_UNKNOWN` | Manually implement "PHASE 1 — Init: Initialise in-memory dedupe HashSet" acti... | 15 |
| 17 | `Main.xaml` | Try: PHASE 1 — Init: TryCatch — Create BirthdayEventRun record in Data Service | `STUB_ACTIVITY_UNKNOWN` | Manually implement "Try: PHASE 1 — Init: TryCatch — Create BirthdayEventRun r... | 15 |
| 18 | `Main.xaml` | Stub: Try: PHASE 1 — Init: TryCatch — Create BirthdayEventRun record in Data Service | `STUB_ACTIVITY_UNKNOWN` | Manually implement "Stub: Try: PHASE 1 — Init: TryCatch — Create BirthdayEven... | 15 |
| 19 | `Main.xaml` | Execute: PHASE 1 — Init — DS Try: Create BirthdayEventRun entity record | `STUB_ACTIVITY_UNKNOWN` | Manually implement "Execute: PHASE 1 — Init — DS Try: Create BirthdayEventRun... | 15 |
| 20 | `Main.xaml` | Stub: Execute: PHASE 1 — Init — DS Try: Create BirthdayEventRun entity record | `STUB_ACTIVITY_UNKNOWN` | Manually implement "Stub: Execute: PHASE 1 — Init — DS Try: Create BirthdayEv... | 15 |
| 21 | `Main.xaml` | Stub: Stub: Execute: PHASE 1 — Init — DS Try: Create BirthdayEventRun entity record | `STUB_ACTIVITY_UNKNOWN` | Manually implement "Stub: Stub: Execute: PHASE 1 — Init — DS Try: Create Birt... | 15 |
| 22 | `Main.xaml` | Stub: Stub: Stub: Execute: PHASE 1 — Init — DS Try: Create BirthdayEventRun entity record | `STUB_ACTIVITY_UNKNOWN` | Manually implement "Stub: Stub: Stub: Execute: PHASE 1 — Init — DS Try: Creat... | 15 |
| 23 | `Main.xaml` | ActivityAction | `STUB_ACTIVITY_UNKNOWN` | Manually implement activity in Main.xaml — estimated 15 min | 15 |
| 24 | `Main.xaml` | Stub: ActivityAction | `STUB_ACTIVITY_UNKNOWN` | Manually implement "Stub: ActivityAction" activity in Main.xaml — estimated 1... | 15 |
| 25 | `Main.xaml` | Stub: Stub: ActivityAction | `STUB_ACTIVITY_UNKNOWN` | Manually implement "Stub: Stub: ActivityAction" activity in Main.xaml — estim... | 15 |
| 26 | `Main.xaml` | Stub: Stub: Stub: ActivityAction | `STUB_ACTIVITY_UNKNOWN` | Manually implement "Stub: Stub: Stub: ActivityAction" activity in Main.xaml —... | 15 |
| 27 | `Main.xaml` | PHASE 1 — Init — DS Catch: Log Data Service create warning | `STUB_ACTIVITY_UNKNOWN` | Manually implement "PHASE 1 — Init — DS Catch: Log Data Service create warnin... | 15 |
| 28 | `WF_GetTodaysBirthdays.xaml` | If retryAttemptCount &gt; 1: apply exponential backoff delay | `STUB_ACTIVITY_UNKNOWN` | Manually implement "If retryAttemptCount &gt; 1: apply exponential backoff de... | 15 |
| 29 | `WF_GetTodaysBirthdays.xaml` | Delay 20 seconds for attempt-3 exponential backoff | `STUB_ACTIVITY_UNKNOWN` | Manually implement "Delay 20 seconds for attempt-3 exponential backoff" activ... | 15 |
| 30 | `WF_GetTodaysBirthdays.xaml` | If.Then — Assign empty JArray and log info | `STUB_ACTIVITY_UNKNOWN` | Manually implement "If.Then — Assign empty JArray and log info" activity in W... | 15 |

### Sequence-Level Stubs (2)

Sequence children were replaced with a single TODO stub because multiple activities in the sequence had issues.

| # | File | Sequence | Code | Developer Action | Est. Minutes |
|---|------|----------|------|-----------------|-------------|
| 1 | `Main.xaml` | Main | `STUB_SEQUENCE_MULTIPLE_FAILURES` | Re-implement 10 activities in sequence "Main" in Main.xaml | 150 |
| 2 | `WF_GetTodaysBirthdays.xaml` | WF_GetTodaysBirthdays | `STUB_SEQUENCE_MULTIPLE_FAILURES` | Re-implement 2 activities in sequence "WF_GetTodaysBirthdays" in WF_GetTodays... | 30 |

### Structural-Leaf Stubs (8)

Individual leaf activities were stubbed while preserving the workflow skeleton (sequences, branches, try/catch, loops, invocations).

| # | File | Activity | Original Tag | Code | Developer Action | Est. Minutes |
|---|------|----------|-------------|------|-----------------|-------------|
| 1 | `Main.xaml` | — | `—` | `STUB_STRUCTURAL_LEAF` | Review and fix ENUM_VIOLATION issue in Main.xaml — workflow structure was pre... | 5 |
| 2 | `Main.xaml` | — | `—` | `STUB_STRUCTURAL_LEAF` | Review and fix ENUM_VIOLATION issue in Main.xaml — workflow structure was pre... | 5 |
| 3 | `WF_GetTodaysBirthdays.xaml` | — | `—` | `STUB_STRUCTURAL_LEAF` | Review and fix CATALOG_STRUCTURAL_VIOLATION issue in WF_GetTodaysBirthdays.xa... | 15 |
| 4 | `WF_GetTodaysBirthdays.xaml` | — | `—` | `STUB_STRUCTURAL_LEAF` | Review and fix CATALOG_STRUCTURAL_VIOLATION issue in WF_GetTodaysBirthdays.xa... | 15 |
| 5 | `WF_GetTodaysBirthdays.xaml` | — | `—` | `STUB_STRUCTURAL_LEAF` | Review and fix ENUM_VIOLATION issue in WF_GetTodaysBirthdays.xaml — workflow ... | 5 |
| 6 | `WF_GetTodaysBirthdays.xaml` | — | `—` | `STUB_STRUCTURAL_LEAF` | Review and fix ENUM_VIOLATION issue in WF_GetTodaysBirthdays.xaml — workflow ... | 5 |
| 7 | `InitAllSettings.xaml` | — | `—` | `STUB_STRUCTURAL_LEAF` | Review and fix CATALOG_STRUCTURAL_VIOLATION issue in InitAllSettings.xaml — w... | 15 |
| 8 | `InitAllSettings.xaml` | — | `—` | `STUB_STRUCTURAL_LEAF` | Review and fix CATALOG_STRUCTURAL_VIOLATION issue in InitAllSettings.xaml — w... | 15 |

#### Structural Preservation Metrics

| File | Total Activities | Preserved | Stubbed | Preservation Rate | Preserved Structures |
|------|-----------------|-----------|---------|-------------------|---------------------|
| `Main.xaml` | 1 | 1 | 0 | 100% | Activity, Sequence (Main), Sequence.Variables |
| `WF_GetTodaysBirthdays.xaml` | 1 | 1 | 0 | 100% | Activity, Sequence (WF_GetTodaysBirthdays), Sequence.Variables |
| `InitAllSettings.xaml` | 54 | 54 | 0 | 100% | Activity, Sequence (Initialize All Settings), Sequence.Variables... (+6) |

### Workflow-Level Stubs (2)

Entire workflows were replaced with Studio-openable stubs (XAML was not parseable for structural preservation).

| # | File | Code | Developer Action | Est. Minutes |
|---|------|------|-----------------|-------------|
| 1 | `Main.xaml` | `STUB_WORKFLOW_BLOCKING` | Fix XML structure in Main.xaml — ensure proper nesting and closing tags | 15 |
| 2 | `WF_GetTodaysBirthdays.xaml` | `STUB_WORKFLOW_BLOCKING` | Fix XML structure in WF_GetTodaysBirthdays.xaml — ensure proper nesting and c... | 15 |

### Quality Warnings (7)

| # | File | Check | Detail | Developer Action | Est. Minutes |
|---|------|-------|--------|-----------------|-------------|
| 1 | `InitAllSettings.xaml` | hardcoded-asset-name | Line 104: asset name "BGV5_GooglePeople_ClientSecret" is hardcoded — consider using a Config.xlsx... | — | undefined |
| 2 | `InitAllSettings.xaml` | hardcoded-asset-name | Line 116: asset name "BGV5_GooglePeople_ClientId" is hardcoded — consider using a Config.xlsx ent... | — | undefined |
| 3 | `InitAllSettings.xaml` | hardcoded-asset-name | Line 123: asset name "BGV5_GooglePeople_RefreshToken" is hardcoded — consider using a Config.xlsx... | — | undefined |
| 4 | `InitAllSettings.xaml` | hardcoded-asset-name | Line 130: asset name "BGV5_GooglePeople_TokenEndpoint" is hardcoded — consider using a Config.xls... | — | undefined |
| 5 | `InitAllSettings.xaml` | hardcoded-asset-name | Line 137: asset name "BGV5_CalendarName" is hardcoded — consider using a Config.xlsx entry or wor... | — | undefined |
| 6 | `InitAllSettings.xaml` | hardcoded-asset-name | Line 144: asset name "BGV5_TimeZone" is hardcoded — consider using a Config.xlsx entry or workflo... | — | undefined |
| 7 | `InitAllSettings.xaml` | hardcoded-asset-name | Line 151: asset name "BGV5_SubjectTemplate" is hardcoded — consider using a Config.xlsx entry or ... | — | undefined |

**Total manual remediation effort: ~740 minutes (12.3 hours)**

## 4. Process Context (from Pipeline)

### Idea Description

Automate birthday greetings to friends and family

### PDD Summary

## 1. Executive Summary
“birthday greetings v5” automates the daily birthday-check and email-greeting process you currently perform manually at 8:00 AM. The automated solution will run unattended in UiPath Orchestrator on a schedule set to `Asia/Dubai`, retrieve today’s events from the dedicated Google Calendar named **“Birthdays”**, look up the recipient’s email address in Google Contacts using the **Google People API via HTTPS**, generate a personalized greeting in your **warm, funny, sarcastic** voice using **UiPath native GenAI capabilities (no OpenAI/Azure OpenAI)**, and send the email via **Integration Service – Gmail connector** using the connected account **ninemush@gmail.com**. The workflow will **dedupe recipients by email** to ensure a person receives only one greeting per day even if multiple events exist. If no email is found for a contact, the automation will **silently skip** sending (per SME decision “B”).

## 2. Process Scope
The in-scope process begins each day at 8:00 AM with identifying whether any birthdays occur “today” and ends when all applicable birthday emails have been sent (or skipped) for that day. The birthdays are stored in a separate Google Calendar titled **“Birthdays”**. Calendar events provide the birthday person’s **full name**; relationship data is **not** stored in the calendar. Recipient email addresses are sourced from **Google Contacts**, where the relevant email is labeled as **Personal** or **Home** (when multiple emails exist, the automation must choose the **Personal/Home** email as preferred). Emails are sent from **ninemush@gmail.com** via UiPath Integration Service’s Gmail connector.

Out of scope for this version are the use of Google Drive, leveraging photos from Google Photos, and any outbound channel other than email (no Slack, Teams, Twilio). The solution is designed to run fully autonomously on **unattended robots** with no user interaction, while allowing optional human review via Action Center if policy or conf...

### SDD Summary

## 1. Automation Architecture Overview

### 1.1 Chosen automation type and rationale
This process is best delivered as a **Hybrid automation**:
- **Deterministic RPA/integration steps** for: scheduling, calendar retrieval, contact lookup, email selection rules (Home/Personal), dedupe, sending, logging. These steps must be predictable, auditable, and retryable.
- **Native GenAI step (UiPath GenAI Activities / Agents optional)** for: generating a “warm, funny, sarcastic” message in your voice, using only permitted context (recipient name + birthday occurrence). This is non-deterministic and benefits from guardrails and optional review.

We will run **fully unattended** (12 unattended slots available) via **Orchestrator schedule trigger** at **08:00 Asia/Dubai**. No user interaction is required in the happy path.

### 1.2 Platform services used (and why)
- **Orchestrator**: scheduling, deployment, assets, logs, retries, runtime environment management (since Environments feature is not accessible).
- **Triggers**: time-based schedule at 08:00 Asia/Dubai.
- **Integration Service**:
  - **Gmail connector** (required, already connected) to send greetings from **ninemush@gmail.com**.
  - **HTTP Webhook connector** to call **Google People API** for Contacts lookup (you requested HTTPS API; rule requires using Integration Service connector instead of raw HTTP activities).
  - **Google Calendar**: the PDD expects Integration Service Google Calendar. **Note**: no active Google Calendar connection is listed; this SDD provisions it as a required connection/artifact for deployment. If the tenant cannot authorize it automatically, deployment will block until an admin authorizes the connection.
- **Data Service**: persistent run-to-run storage for sent-message history (dedupe “once per email per day”), event traceability, and operational reporting.
- **Action Center** (optional but provisioned): human review only if GenAI output fails policy/quality checks. This remains unused in th...

**Automation Type:** hybrid
**Rationale:** Google Calendar/Gmail steps are structured and deterministic (RPA/API), but generating a highly personal message in your warm/funny/sarcastic voice requires LLM-based reasoning with human-like language control, best handled by an agent.
**Feasibility Complexity:** medium
**Effort Estimate:** 1-2 weeks

## 5. Business Process Overview

### Process Steps

| # | Step | Role | System | Type | Pain Point |
|---|------|------|--------|------|------------|
| 1 | Time Trigger 08:00 Asia/Dubai | System | Orchestrator Triggers | start | — |
| 2 | Retrieve Today’s Birthday Events | System | Integration Service - Google Calendar | task | — |
| 3 | Any Birthday Events Today? | System | Google Calendar Data | decision | — |
| 4 | End (No Birthdays Today) | System | Orchestrator | end | — |
| 5 | Build Birthday Recipient List (Full Names) | System | Data Service | task | — |
| 6 | Lookup Contact Emails via Google People API (HTTP) | System | Google People API (HTTP) | task | — |
| 7 | Email Available for Contact? | System | Contact Data | decision | — |
| 8 | Select Preferred Email (Personal/Home) | System | Contact Data | task | — |
| 9 | Dedupe Recipients by Email (Once Per Day) | System | Data Service | task | — |
| 10 | Generate Personalized Greeting in Your Voice | System | UiPath Agents (Native GenAI) | agent-task | — |
| 11 | Message Safe & On-Policy? | System | UiPath Agents | agent-decision | — |
| 12 | Create Human Review Task (Low Confidence/Policy) | System | Action Center | task | — |
| 13 | Apply Approved/Edited Message | System | Action Center | task | — |
| 14 | Send Birthday Email | System | Integration Service - Gmail (ninemush@gmail.com) | task | — |
| 15 | Send Birthday Email | System | Integration Service - Gmail (ninemush@gmail.com) | task | — |
| 16 | Log Sent Message (Recipient, Subject, Timestamp) | System | Data Service | task | — |
| 17 | Log Sent Message (Recipient, Subject, Timestamp) | System | Data Service | task | — |
| 18 | End (Birthday Emails Sent) | System | Orchestrator | end | — |
| 19 | Skip Contact (No Email Found) | System | Orchestrator | task | — |
| 20 | More Events to Process? | System | Orchestrator | decision | — |
| 21 | Loop to Next Birthday Person | System | Orchestrator | task | — |
| 22 | End (All Birthday Events Processed) | System | Orchestrator | end | — |
| 23 | More Deduped Recipients to Send? | System | Orchestrator | decision | — |
| 24 | Loop to Next Recipient | System | Orchestrator | task | — |
| 25 | End (All Deduped Emails Sent) | System | Orchestrator | end | — |

### Target Applications / Systems

The following applications were identified from the process map and must be accessible from the robot machine:

- Orchestrator Triggers
- Integration Service - Google Calendar
- Google Calendar Data
- Orchestrator
- Data Service
- Google People API (HTTP)
- Contact Data
- UiPath Agents (Native GenAI)
- UiPath Agents
- Action Center
- Integration Service - Gmail (ninemush@gmail.com)

### User Roles Involved

- System

### Decision Points (Process Map Topology)

**Any Birthday Events Today?**
  - [No] → End (No Birthdays Today)
  - [Yes] → Build Birthday Recipient List (Full Names)

**Email Available for Contact?**
  - [Yes] → Select Preferred Email (Personal/Home)
  - [No] → Skip Contact (No Email Found)

**More Events to Process?**
  - [Yes] → Loop to Next Birthday Person
  - [No] → End (All Birthday Events Processed)

**More Deduped Recipients to Send?**
  - [Yes] → Loop to Next Recipient
  - [No] → End (All Deduped Emails Sent)

## 6. Environment Setup

| Requirement | Value |
|---|---|
| Target Framework | Windows (required) |
| Robot Type | Unattended |
| Modern Activities | No |
| Studio Version | 25.10.0 |
| Orchestrator Connection | Required |
| Machine Template | Standard |

### Machine Template

**Recommended:** Standard
Standard unattended machine template

### Orchestrator Folder Structure

Create a Modern Folder with at least one unattended robot assignment. Use folder-level credential stores for asset isolation.

### NuGet Dependencies

| # | Package |
|---|--------|
| 1 | `UiPath.System.Activities` |
| 2 | `UiPath.Excel.Activities` |
| 3 | `UiPath.Web.Activities` |
| 4 | `Newtonsoft.Json` |

### Target Applications (from Process Map)

The following applications were identified from the business process map. Ensure network connectivity and access credentials are configured on the robot machine:

- Orchestrator Triggers
- Integration Service - Google Calendar
- Google Calendar Data
- Orchestrator
- Data Service
- Google People API (HTTP)
- Contact Data
- UiPath Agents (Native GenAI)
- UiPath Agents
- Action Center
- Integration Service - Gmail (ninemush@gmail.com)

## 7. Credential & Asset Inventory

**Total:** 15 activities (7 hardcoded, 8 variable-driven)

### Orchestrator Credentials to Provision

| # | Credential Name | Type | Consuming Activity | File | Action |
|---|----------------|------|-------------------|------|--------|
| 1 | `BGV5_GooglePeople_ClientSecret` | Credential | — | `InitAllSettings.xaml` | Create in Orchestrator before deployment |

### Orchestrator Assets to Provision

| # | Asset Name | Value Type | Consuming Activity | File | Action |
|---|-----------|-----------|-------------------|------|--------|
| 1 | `BGV5_GooglePeople_ClientId` | Unknown | — | `InitAllSettings.xaml` | Create in Orchestrator before deployment |
| 2 | `BGV5_GooglePeople_RefreshToken` | Unknown | — | `InitAllSettings.xaml` | Create in Orchestrator before deployment |
| 3 | `BGV5_GooglePeople_TokenEndpoint` | Unknown | — | `InitAllSettings.xaml` | Create in Orchestrator before deployment |
| 4 | `BGV5_CalendarName` | Unknown | — | `InitAllSettings.xaml` | Create in Orchestrator before deployment |
| 5 | `BGV5_TimeZone` | Unknown | — | `InitAllSettings.xaml` | Create in Orchestrator before deployment |
| 6 | `BGV5_SubjectTemplate` | Unknown | — | `InitAllSettings.xaml` | Create in Orchestrator before deployment |

### Detailed Usage Map

| File | Line | Activity | Asset/Credential | Type | Variable | Hardcoded |
|------|------|----------|-----------------|------|----------|----------|
| `InitAllSettings.xaml` | 106 | GetCredential | `BGV5_GooglePeople_ClientSecret` | Credential | — | Yes |
| `InitAllSettings.xaml` | 107 | GetCredential | `UNKNOWN` | Credential | — | No |
| `InitAllSettings.xaml` | 110 | GetCredential | `UNKNOWN` | Credential | — | No |
| `InitAllSettings.xaml` | 118 | GetAsset | `BGV5_GooglePeople_ClientId` | Unknown | — | Yes |
| `InitAllSettings.xaml` | 119 | GetAsset | `UNKNOWN` | Unknown | — | No |
| `InitAllSettings.xaml` | 125 | GetAsset | `BGV5_GooglePeople_RefreshToken` | Unknown | — | Yes |
| `InitAllSettings.xaml` | 126 | GetAsset | `UNKNOWN` | Unknown | — | No |
| `InitAllSettings.xaml` | 132 | GetAsset | `BGV5_GooglePeople_TokenEndpoint` | Unknown | — | Yes |
| `InitAllSettings.xaml` | 133 | GetAsset | `UNKNOWN` | Unknown | — | No |
| `InitAllSettings.xaml` | 139 | GetAsset | `BGV5_CalendarName` | Unknown | — | Yes |
| `InitAllSettings.xaml` | 140 | GetAsset | `UNKNOWN` | Unknown | — | No |
| `InitAllSettings.xaml` | 146 | GetAsset | `BGV5_TimeZone` | Unknown | — | Yes |
| `InitAllSettings.xaml` | 147 | GetAsset | `UNKNOWN` | Unknown | — | No |
| `InitAllSettings.xaml` | 153 | GetAsset | `BGV5_SubjectTemplate` | Unknown | — | Yes |
| `InitAllSettings.xaml` | 154 | GetAsset | `UNKNOWN` | Unknown | — | No |

> **Warning:** 7 asset/credential name(s) are hardcoded. Consider externalizing to Orchestrator Config assets for environment portability.

## 8. SDD × XAML Artifact Reconciliation

**Summary:** 7 aligned, 0 SDD-only, 0 XAML-only

| # | Name | Type | Status | SDD Config | XAML File | XAML Line |
|---|------|------|--------|-----------|----------|----------|
| 1 | `BGV5_GooglePeople_ClientId` | asset | **Aligned** | type: Text, value: , description: OAuth client id for Google People API token minting used with Integration Service HTTP Webhook connector. | `InitAllSettings.xaml` | 118 |
| 2 | `BGV5_GooglePeople_ClientSecret` | credential | **Aligned** | type: Credential, description: OAuth client secret for Google People API (stored as Credential or Text per policy). | `InitAllSettings.xaml` | 106 |
| 3 | `BGV5_GooglePeople_RefreshToken` | asset | **Aligned** | type: Text, value: , description: OAuth refresh token for Google People API (restricted). | `InitAllSettings.xaml` | 125 |
| 4 | `BGV5_GooglePeople_TokenEndpoint` | asset | **Aligned** | type: Text, value: , description: OAuth token endpoint used to exchange refresh token for access token for People API calls. | `InitAllSettings.xaml` | 132 |
| 5 | `BGV5_CalendarName` | asset | **Aligned** | type: Text, value: Birthdays, description: Google Calendar name to read birthday events from. | `InitAllSettings.xaml` | 139 |
| 6 | `BGV5_TimeZone` | asset | **Aligned** | type: Text, value: Asia/Dubai, description: Timezone used for date calculations and scheduling semantics. | `InitAllSettings.xaml` | 146 |
| 7 | `BGV5_SubjectTemplate` | asset | **Aligned** | type: Text, value: Happy Birthday, {{FirstName}}!, description: Email subject template for outgoing birthday greetings. | `InitAllSettings.xaml` | 153 |

## 9. Queue Management

No queue activities detected in the package.

## 10. Exception Handling Coverage

**Coverage:** 0/15 high-risk activities inside TryCatch (0%)

### Files Without TryCatch

- `Main.xaml`
- `WF_GetTodaysBirthdays.xaml`
- `InitAllSettings.xaml`

### Uncovered High-Risk Activities

| # | Location | Activity |
|---|----------|----------|
| 1 | `InitAllSettings.xaml:106` | Get BGV5_GooglePeople_ClientSecret |
| 2 | `InitAllSettings.xaml:107` | ui:GetCredential |
| 3 | `InitAllSettings.xaml:110` | ui:GetCredential |
| 4 | `InitAllSettings.xaml:118` | Get BGV5_GooglePeople_ClientId |
| 5 | `InitAllSettings.xaml:119` | ui:GetAsset |
| 6 | `InitAllSettings.xaml:125` | Get BGV5_GooglePeople_RefreshToken |
| 7 | `InitAllSettings.xaml:126` | ui:GetAsset |
| 8 | `InitAllSettings.xaml:132` | Get BGV5_GooglePeople_TokenEndpoint |
| 9 | `InitAllSettings.xaml:133` | ui:GetAsset |
| 10 | `InitAllSettings.xaml:139` | Get BGV5_CalendarName |
| 11 | `InitAllSettings.xaml:140` | ui:GetAsset |
| 12 | `InitAllSettings.xaml:146` | Get BGV5_TimeZone |
| 13 | `InitAllSettings.xaml:147` | ui:GetAsset |
| 14 | `InitAllSettings.xaml:153` | Get BGV5_SubjectTemplate |
| 15 | `InitAllSettings.xaml:154` | ui:GetAsset |

> **Recommendation:** Wrap these activities in TryCatch blocks with appropriate exception types (BusinessRuleException for data errors, System.Exception for general failures).

## 11. Trigger Configuration

Based on the process analysis, the following trigger configuration is recommended:

| # | Trigger Type | Reason | Configuration |
|---|-------------|--------|---------------|
| 1 | **Schedule** | Defined in SDD orchestrator_artifacts: BGV5_BirthdayGreetings_Daily_0800_Dubai | SDD-specified: BGV5_BirthdayGreetings_Daily_0800_Dubai | Cron: 0 0 8 * * ? | Daily schedule trigger at 08:00 Asia/Dubai to run BirthdayGreetingsV5_Autonomous. |

## 12. Upstream Quality Findings

The following quality warnings were produced by upstream pipeline stages (selector scoring, type validation, expression linting, etc.) and should be addressed during development:

| Code | Severity | Count | Sample Message |
|------|----------|-------|----------------|
| undefined | warning | 7 |  |

## 13. Pre-Deployment Checklist

| # | Category | Task | Required |
|---|----------|------|----------|
| 1 | Deployment | Publish package to Orchestrator feed | Yes |
| 2 | Deployment | Create Process in target folder | Yes |
| 3 | Environment | Verify Orchestrator connection from robot | Yes |
| 4 | Credentials | Provision credential: `BGV5_GooglePeople_ClientSecret` | Yes |
| 5 | Assets | Provision asset: `BGV5_GooglePeople_ClientId` | Yes |
| 6 | Assets | Provision asset: `BGV5_GooglePeople_RefreshToken` | Yes |
| 7 | Assets | Provision asset: `BGV5_GooglePeople_TokenEndpoint` | Yes |
| 8 | Assets | Provision asset: `BGV5_CalendarName` | Yes |
| 9 | Assets | Provision asset: `BGV5_TimeZone` | Yes |
| 10 | Assets | Provision asset: `BGV5_SubjectTemplate` | Yes |
| 11 | Trigger | Configure trigger (schedule/queue/API) | Yes |
| 12 | Testing | Run smoke test in target environment | Yes |
| 13 | Monitoring | Verify logging output in Orchestrator | Recommended |
| 14 | Governance | UAT test execution completed and sign-off obtained | Yes |
| 15 | Governance | Peer code review completed | Yes |
| 16 | Governance | All quality gate warnings addressed or risk-accepted | Yes |
| 17 | Governance | Business process owner validation obtained | Yes |
| 18 | Governance | CoE approval obtained | Yes |
| 19 | Governance | Production readiness assessment completed (monitoring, alerting, rollback plan documented) | Yes |

## 14. Deployment Readiness Score

**Overall: Not Ready — 27/50 (19%)**

| Section | Score | Notes |
|---------|-------|-------|
| Credentials & Assets | 5/10 | 7 hardcoded asset name(s) — use Orchestrator assets/config |
| Exception Handling | 2/10 | Only 0% of high-risk activities covered by TryCatch; 3 file(s) with no TryCatch blocks |
| Queue Management | 10/10 | No queue activities — section not applicable |
| Build Quality | 0/10 | 7 quality warnings to address; 42 remediations — stub replacements need developer attention; Entry point (Main.xaml) is stubbed — package has no runnable entry point; 2/3 workflow(s) are stubs (67%) — structurally invalid; 6 planned workflow(s) missing from archive |
| Environment Setup | 10/10 | Environment requirements are straightforward |

> **Action Required:** Address the items above before deploying to production. Focus on sections with the lowest scores first.

---

## 15. Structured Report (JSON)

The following JSON appendix contains the full pipeline outcome report for programmatic consumption:

```json
{
  "fullyGeneratedFiles": [],
  "autoRepairs": [
    {
      "repairCode": "REPAIR_LOG_LEVEL_NORMALIZE",
      "file": "Main.xaml",
      "description": "Normalised LogMessage Level=\"Information\" → \"Info\" in Main.xaml"
    },
    {
      "repairCode": "REPAIR_LOG_LEVEL_NORMALIZE",
      "file": "Main.xaml",
      "description": "Normalised LogMessage Level=\"Warning\" → \"Warn\" in Main.xaml"
    },
    {
      "repairCode": "REPAIR_LOG_LEVEL_NORMALIZE",
      "file": "WF_GetTodaysBirthdays.xaml",
      "description": "Normalised LogMessage Level=\"Information\" → \"Info\" in WF_GetTodaysBirthdays.xaml"
    },
    {
      "repairCode": "REPAIR_LOG_LEVEL_NORMALIZE",
      "file": "WF_GetTodaysBirthdays.xaml",
      "description": "Normalised LogMessage Level=\"Warning\" → \"Warn\" in WF_GetTodaysBirthdays.xaml"
    },
    {
      "repairCode": "REPAIR_GENERIC",
      "file": "unknown",
      "description": "Structural preservation: Main.xaml preserved unchanged — XML is valid but blocking issues could not be mapped to specific leaf activities"
    },
    {
      "repairCode": "REPAIR_GENERIC",
      "file": "unknown",
      "description": "Structural preservation: WF_GetTodaysBirthdays.xaml preserved unchanged — XML is valid but blocking issues could not be mapped to specific leaf activities"
    },
    {
      "repairCode": "REPAIR_GENERIC",
      "file": "unknown",
      "description": "Structural preservation: InitAllSettings.xaml preserved unchanged — XML is valid but blocking issues could not be mapped to specific leaf activities"
    },
    {
      "repairCode": "REPAIR_GENERIC",
      "file": "unknown",
      "description": "Skipped full-package stub escalation — structural-preservation stubs already cover affected files"
    }
  ],
  "remediations": [
    {
      "level": "activity",
      "file": "Main.xaml",
      "remediationCode": "STUB_ACTIVITY_UNKNOWN",
      "originalTag": "OutArgument",
      "reason": "Line 62: Undeclared variable \"jobId\" in expression: jobId — variable is not declared in any <Variable> block in scope",
      "classifiedCheck": "UNDECLARED_VARIABLE",
      "developerAction": "Manually implement activity in Main.xaml — estimated 15 min",
      "estimatedEffortMinutes": 15
    },
    {
      "level": "activity",
      "file": "Main.xaml",
      "remediationCode": "STUB_ACTIVITY_UNKNOWN",
      "originalTag": "InArgument",
      "reason": "Line 63: Undeclared variable \"UIPATH_JOB_ID\" in expression: If(String.IsNullOrEmpty(System.Environment.GetEnvironmentVar... — variable is not declared in any <Variable> block in scope",
      "classifiedCheck": "UNDECLARED_VARIABLE",
      "developerAction": "Manually implement activity in Main.xaml — estimated 15 min",
      "estimatedEffortMinutes": 15
    },
    {
      "level": "activity",
      "file": "Main.xaml",
      "remediationCode": "STUB_ACTIVITY_UNKNOWN",
      "originalTag": "ui:Comment",
      "originalDisplayName": "Stub: InArgument",
      "reason": "Line 63: Undeclared variable \"yyyyMMddHHmmss\" in expression: If(String.IsNullOrEmpty(System.Environment.GetEnvironmentVar... — variable is not declared in any <Variable> block in scope",
      "classifiedCheck": "UNDECLARED_VARIABLE",
      "developerAction": "Manually implement \"Stub: InArgument\" activity in Main.xaml — estimated 15 min",
      "estimatedEffortMinutes": 15
    },
    {
      "level": "activity",
      "file": "Main.xaml",
      "remediationCode": "STUB_ACTIVITY_UNKNOWN",
      "originalTag": "OutArgument",
      "reason": "Line 66: Undeclared variable \"runId\" in expression: runId — variable is not declared in any <Variable> block in scope",
      "classifiedCheck": "UNDECLARED_VARIABLE",
      "developerAction": "Manually implement activity in Main.xaml — estimated 15 min",
      "estimatedEffortMinutes": 15
    },
    {
      "level": "activity",
      "file": "Main.xaml",
      "remediationCode": "STUB_ACTIVITY_UNKNOWN",
      "originalTag": "InArgument",
      "reason": "Line 67: Undeclared variable \"BGV5\" in expression: BGV5- + DateTime.UtcNow.ToString(yyyyMMdd) + - + jobId.Subst... — variable is not declared in any <Variable> block in scope",
      "classifiedCheck": "UNDECLARED_VARIABLE",
      "developerAction": "Manually implement activity in Main.xaml — estimated 15 min",
      "estimatedEffortMinutes": 15
    },
    {
      "level": "activity",
      "file": "Main.xaml",
      "remediationCode": "STUB_ACTIVITY_UNKNOWN",
      "originalTag": "ui:Comment",
      "originalDisplayName": "Stub: InArgument",
      "reason": "Line 67: Undeclared variable \"yyyyMMdd\" in expression: BGV5- + DateTime.UtcNow.ToString(yyyyMMdd) + - + jobId.Subst... — variable is not declared in any <Variable> block in scope",
      "classifiedCheck": "UNDECLARED_VARIABLE",
      "developerAction": "Manually implement \"Stub: InArgument\" activity in Main.xaml — estimated 15 min",
      "estimatedEffortMinutes": 15
    },
    {
      "level": "activity",
      "file": "Main.xaml",
      "remediationCode": "STUB_ACTIVITY_UNKNOWN",
      "originalTag": "ui:Comment",
      "originalDisplayName": "Stub: Stub: InArgument",
      "reason": "Line 67: Undeclared variable \"jobId\" in expression: BGV5- + DateTime.UtcNow.ToString(yyyyMMdd) + - + jobId.Subst... — variable is not declared in any <Variable> block in scope",
      "classifiedCheck": "UNDECLARED_VARIABLE",
      "developerAction": "Manually implement \"Stub: Stub: InArgument\" activity in Main.xaml — estimated 15 min",
      "estimatedEffortMinutes": 15
    },
    {
      "level": "activity",
      "file": "Main.xaml",
      "remediationCode": "STUB_ACTIVITY_UNKNOWN",
      "originalTag": "OutArgument",
      "reason": "Line 287: Undeclared variable \"peopleApiCredentialPassword\" in expression: peopleApiCredentialPassword — variable is not declared in any <Variable> block in scope",
      "classifiedCheck": "UNDECLARED_VARIABLE",
      "developerAction": "Manually implement activity in Main.xaml — estimated 15 min",
      "estimatedEffortMinutes": 15
    },
    {
      "level": "activity",
      "file": "Main.xaml",
      "remediationCode": "STUB_ACTIVITY_UNKNOWN",
      "originalTag": "OutArgument",
      "reason": "Line 290: Undeclared variable \"peopleApiCredentialUsername\" in expression: peopleApiCredentialUsername — variable is not declared in any <Variable> block in scope",
      "classifiedCheck": "UNDECLARED_VARIABLE",
      "developerAction": "Manually implement activity in Main.xaml — estimated 15 min",
      "estimatedEffortMinutes": 15
    },
    {
      "level": "activity",
      "file": "Main.xaml",
      "remediationCode": "STUB_ACTIVITY_UNKNOWN",
      "originalTag": "OutArgument",
      "reason": "Line 329: Undeclared variable \"peopleApiClientSecret\" in expression: peopleApiClientSecret — variable is not declared in any <Variable> block in scope",
      "classifiedCheck": "UNDECLARED_VARIABLE",
      "developerAction": "Manually implement activity in Main.xaml — estimated 15 min",
      "estimatedEffortMinutes": 15
    },
    {
      "level": "activity",
      "file": "Main.xaml",
      "remediationCode": "STUB_ACTIVITY_UNKNOWN",
      "originalTag": "InArgument",
      "reason": "Line 330: Undeclared variable \"peopleApiCredentialPassword\" in expression: peopleApiCredentialPassword — variable is not declared in any <Variable> block in scope",
      "classifiedCheck": "UNDECLARED_VARIABLE",
      "developerAction": "Manually implement activity in Main.xaml — estimated 15 min",
      "estimatedEffortMinutes": 15
    },
    {
      "level": "activity",
      "file": "Main.xaml",
      "remediationCode": "STUB_ACTIVITY_UNKNOWN",
      "originalTag": "If",
      "originalDisplayName": "PHASE 1 — Init — Try: Validate critical assets non-empty",
      "reason": "Line 413: Undeclared variable \"peopleApiClientId\" in expression: String.IsNullOrWhiteSpace(peopleApiClientId) OrElse String.I... — variable is not declared in any <Variable> block in scope",
      "classifiedCheck": "UNDECLARED_VARIABLE",
      "developerAction": "Manually implement \"PHASE 1 — Init — Try: Validate critical assets non-empty\" activity in Main.xaml — estimated 15 min",
      "estimatedEffortMinutes": 15
    },
    {
      "level": "activity",
      "file": "Main.xaml",
      "remediationCode": "STUB_ACTIVITY_UNKNOWN",
      "originalTag": "ui:Comment",
      "originalDisplayName": "Stub: PHASE 1 — Init — Try: Validate critical assets non-empty",
      "reason": "Line 413: Undeclared variable \"peopleApiClientSecret\" in expression: String.IsNullOrWhiteSpace(peopleApiClientId) OrElse String.I... — variable is not declared in any <Variable> block in scope",
      "classifiedCheck": "UNDECLARED_VARIABLE",
      "developerAction": "Manually implement \"Stub: PHASE 1 — Init — Try: Validate critical assets non-empty\" activity in Main.xaml — estimated 15 min",
      "estimatedEffortMinutes": 15
    },
    {
      "level": "activity",
      "file": "Main.xaml",
      "remediationCode": "STUB_ACTIVITY_UNKNOWN",
      "originalTag": "ui:Comment",
      "originalDisplayName": "Stub: Stub: PHASE 1 — Init — Try: Validate critical assets non-empty",
      "reason": "Line 413: Undeclared variable \"peopleApiRefreshToken\" in expression: String.IsNullOrWhiteSpace(peopleApiClientId) OrElse String.I... — variable is not declared in any <Variable> block in scope",
      "classifiedCheck": "UNDECLARED_VARIABLE",
      "developerAction": "Manually implement \"Stub: Stub: PHASE 1 — Init — Try: Validate critical assets non-empty\" activity in Main.xaml — estimated 15 min",
      "estimatedEffortMinutes": 15
    },
    {
      "level": "activity",
      "file": "Main.xaml",
      "remediationCode": "STUB_ACTIVITY_UNKNOWN",
      "originalTag": "ui:Comment",
      "originalDisplayName": "Stub: Stub: Stub: PHASE 1 — Init — Try: Validate critical assets non-empty",
      "reason": "Line 413: Undeclared variable \"calendarName\" in expression: String.IsNullOrWhiteSpace(peopleApiClientId) OrElse String.I... — variable is not declared in any <Variable> block in scope",
      "classifiedCheck": "UNDECLARED_VARIABLE",
      "developerAction": "Manually implement \"Stub: Stub: Stub: PHASE 1 — Init — Try: Validate critical assets non-empty\" activity in Main.xaml — estimated 15 min",
      "estimatedEffortMinutes": 15
    },
    {
      "level": "activity",
      "file": "Main.xaml",
      "remediationCode": "STUB_ACTIVITY_UNKNOWN",
      "originalTag": "Assign",
      "originalDisplayName": "PHASE 1 — Init: Initialise in-memory dedupe HashSet",
      "reason": "Line 545: Undeclared variable \"todayDubai\" in expression: todayDubai — variable is not declared in any <Variable> block in scope",
      "classifiedCheck": "UNDECLARED_VARIABLE",
      "developerAction": "Manually implement \"PHASE 1 — Init: Initialise in-memory dedupe HashSet\" activity in Main.xaml — estimated 15 min",
      "estimatedEffortMinutes": 15
    },
    {
      "level": "activity",
      "file": "Main.xaml",
      "remediationCode": "STUB_ACTIVITY_UNKNOWN",
      "originalTag": "TryCatch",
      "originalDisplayName": "Try: PHASE 1 — Init: TryCatch — Create BirthdayEventRun record in Data Service",
      "reason": "Line 546: Undeclared variable \"Asia\" in expression: TimeZoneInfo.ConvertTimeBySystemTimeZoneId(DateTime.UtcNow, ... — variable is not declared in any <Variable> block in scope",
      "classifiedCheck": "UNDECLARED_VARIABLE",
      "developerAction": "Manually implement \"Try: PHASE 1 — Init: TryCatch — Create BirthdayEventRun record in Data Service\" activity in Main.xaml — estimated 15 min",
      "estimatedEffortMinutes": 15
    },
    {
      "level": "activity",
      "file": "Main.xaml",
      "remediationCode": "STUB_ACTIVITY_UNKNOWN",
      "originalTag": "ui:Comment",
      "originalDisplayName": "Stub: Try: PHASE 1 — Init: TryCatch — Create BirthdayEventRun record in Data Service",
      "reason": "Line 546: Undeclared variable \"Dubai\" in expression: TimeZoneInfo.ConvertTimeBySystemTimeZoneId(DateTime.UtcNow, ... — variable is not declared in any <Variable> block in scope",
      "classifiedCheck": "UNDECLARED_VARIABLE",
      "developerAction": "Manually implement \"Stub: Try: PHASE 1 — Init: TryCatch — Create BirthdayEventRun record in Data Service\" activity in Main.xaml — estimated 15 min",
      "estimatedEffortMinutes": 15
    },
    {
      "level": "activity",
      "file": "Main.xaml",
      "remediationCode": "STUB_ACTIVITY_UNKNOWN",
      "originalTag": "Sequence",
      "originalDisplayName": "Execute: PHASE 1 — Init — DS Try: Create BirthdayEventRun entity record",
      "reason": "Line 549: Undeclared variable \"todayDubaiStr\" in expression: todayDubaiStr — variable is not declared in any <Variable> block in scope",
      "classifiedCheck": "UNDECLARED_VARIABLE",
      "developerAction": "Manually implement \"Execute: PHASE 1 — Init — DS Try: Create BirthdayEventRun entity record\" activity in Main.xaml — estimated 15 min",
      "estimatedEffortMinutes": 15
    },
    {
      "level": "activity",
      "file": "Main.xaml",
      "remediationCode": "STUB_ACTIVITY_UNKNOWN",
      "originalTag": "ui:Comment",
      "originalDisplayName": "Stub: Execute: PHASE 1 — Init — DS Try: Create BirthdayEventRun entity record",
      "reason": "Line 550: Undeclared variable \"todayDubai\" in expression: todayDubai.ToString(yyyy-MM-dd) — variable is not declared in any <Variable> block in scope",
      "classifiedCheck": "UNDECLARED_VARIABLE",
      "developerAction": "Manually implement \"Stub: Execute: PHASE 1 — Init — DS Try: Create BirthdayEventRun entity record\" activity in Main.xaml — estimated 15 min",
      "estimatedEffortMinutes": 15
    },
    {
      "level": "activity",
      "file": "Main.xaml",
      "remediationCode": "STUB_ACTIVITY_UNKNOWN",
      "originalTag": "ui:Comment",
      "originalDisplayName": "Stub: Stub: Execute: PHASE 1 — Init — DS Try: Create BirthdayEventRun entity record",
      "reason": "Line 550: Undeclared variable \"yyyy\" in expression: todayDubai.ToString(yyyy-MM-dd) — variable is not declared in any <Variable> block in scope",
      "classifiedCheck": "UNDECLARED_VARIABLE",
      "developerAction": "Manually implement \"Stub: Stub: Execute: PHASE 1 — Init — DS Try: Create BirthdayEventRun entity record\" activity in Main.xaml — estimated 15 min",
      "estimatedEffortMinutes": 15
    },
    {
      "level": "activity",
      "file": "Main.xaml",
      "remediationCode": "STUB_ACTIVITY_UNKNOWN",
      "originalTag": "ui:Comment",
      "originalDisplayName": "Stub: Stub: Stub: Execute: PHASE 1 — Init — DS Try: Create BirthdayEventRun entity record",
      "reason": "Line 550: Undeclared variable \"dd\" in expression: todayDubai.ToString(yyyy-MM-dd) — variable is not declared in any <Variable> block in scope",
      "classifiedCheck": "UNDECLARED_VARIABLE",
      "developerAction": "Manually implement \"Stub: Stub: Stub: Execute: PHASE 1 — Init — DS Try: Create BirthdayEventRun entity record\" activity in Main.xaml — estimated 15 min",
      "estimatedEffortMinutes": 15
    },
    {
      "level": "activity",
      "file": "Main.xaml",
      "remediationCode": "STUB_ACTIVITY_UNKNOWN",
      "originalTag": "ActivityAction",
      "reason": "Line 553: Undeclared variable \"runStorageFolderPath\" in expression: runStorageFolderPath — variable is not declared in any <Variable> block in scope",
      "classifiedCheck": "UNDECLARED_VARIABLE",
      "developerAction": "Manually implement activity in Main.xaml — estimated 15 min",
      "estimatedEffortMinutes": 15
    },
    {
      "level": "activity",
      "file": "Main.xaml",
      "remediationCode": "STUB_ACTIVITY_UNKNOWN",
      "originalTag": "ui:Comment",
      "originalDisplayName": "Stub: ActivityAction",
      "reason": "Line 554: Undeclared variable \"runs\" in expression: runs/ + todayDubaiStr + / + runId + / — variable is not declared in any <Variable> block in scope",
      "classifiedCheck": "UNDECLARED_VARIABLE",
      "developerAction": "Manually implement \"Stub: ActivityAction\" activity in Main.xaml — estimated 15 min",
      "estimatedEffortMinutes": 15
    },
    {
      "level": "activity",
      "file": "Main.xaml",
      "remediationCode": "STUB_ACTIVITY_UNKNOWN",
      "originalTag": "ui:Comment",
      "originalDisplayName": "Stub: Stub: ActivityAction",
      "reason": "Line 554: Undeclared variable \"todayDubaiStr\" in expression: runs/ + todayDubaiStr + / + runId + / — variable is not declared in any <Variable> block in scope",
      "classifiedCheck": "UNDECLARED_VARIABLE",
      "developerAction": "Manually implement \"Stub: Stub: ActivityAction\" activity in Main.xaml — estimated 15 min",
      "estimatedEffortMinutes": 15
    },
    {
      "level": "activity",
      "file": "Main.xaml",
      "remediationCode": "STUB_ACTIVITY_UNKNOWN",
      "originalTag": "ui:Comment",
      "originalDisplayName": "Stub: Stub: Stub: ActivityAction",
      "reason": "Line 554: Undeclared variable \"runId\" in expression: runs/ + todayDubaiStr + / + runId + / — variable is not declared in any <Variable> block in scope",
      "classifiedCheck": "UNDECLARED_VARIABLE",
      "developerAction": "Manually implement \"Stub: Stub: Stub: ActivityAction\" activity in Main.xaml — estimated 15 min",
      "estimatedEffortMinutes": 15
    },
    {
      "level": "activity",
      "file": "Main.xaml",
      "remediationCode": "STUB_ACTIVITY_UNKNOWN",
      "originalTag": "ui:LogMessage",
      "originalDisplayName": "PHASE 1 — Init — DS Catch: Log Data Service create warning",
      "reason": "Line 557: Undeclared variable \"inMemoryDedupeSet\" in expression: inMemoryDedupeSet — variable is not declared in any <Variable> block in scope",
      "classifiedCheck": "UNDECLARED_VARIABLE",
      "developerAction": "Manually implement \"PHASE 1 — Init — DS Catch: Log Data Service create warning\" activity in Main.xaml — estimated 15 min",
      "estimatedEffortMinutes": 15
    },
    {
      "level": "activity",
      "file": "WF_GetTodaysBirthdays.xaml",
      "remediationCode": "STUB_ACTIVITY_UNKNOWN",
      "originalTag": "If",
      "originalDisplayName": "If retryAttemptCount &gt; 1: apply exponential backoff delay",
      "reason": "Line 186: Undeclared variable \"retryAttemptCount\" in expression: retryAttemptCount &gt; 1 — variable is not declared in any <Variable> block in scope",
      "classifiedCheck": "UNDECLARED_VARIABLE",
      "developerAction": "Manually implement \"If retryAttemptCount &gt; 1: apply exponential backoff delay\" activity in WF_GetTodaysBirthdays.xaml — estimated 15 min",
      "estimatedEffortMinutes": 15
    },
    {
      "level": "activity",
      "file": "WF_GetTodaysBirthdays.xaml",
      "remediationCode": "STUB_ACTIVITY_UNKNOWN",
      "originalTag": "Delay",
      "originalDisplayName": "Delay 20 seconds for attempt-3 exponential backoff",
      "reason": "Line 200: Undeclared variable \"retryAttemptCount\" in expression: retryAttemptCount &gt;= 3 — variable is not declared in any <Variable> block in scope",
      "classifiedCheck": "UNDECLARED_VARIABLE",
      "developerAction": "Manually implement \"Delay 20 seconds for attempt-3 exponential backoff\" activity in WF_GetTodaysBirthdays.xaml — estimated 15 min",
      "estimatedEffortMinutes": 15
    },
    {
      "level": "activity",
      "file": "WF_GetTodaysBirthdays.xaml",
      "remediationCode": "STUB_ACTIVITY_UNKNOWN",
      "originalTag": "Sequence",
      "originalDisplayName": "If.Then — Assign empty JArray and log info",
      "reason": "Line 561: Undeclared variable \"parsedEventsArray\" in expression: parsedEventsArray Is Nothing — variable is not declared in any <Variable> block in scope",
      "classifiedCheck": "UNDECLARED_VARIABLE",
      "developerAction": "Manually implement \"If.Then — Assign empty JArray and log info\" activity in WF_GetTodaysBirthdays.xaml — estimated 15 min",
      "estimatedEffortMinutes": 15
    },
    {
      "level": "sequence",
      "file": "Main.xaml",
      "remediationCode": "STUB_SEQUENCE_MULTIPLE_FAILURES",
      "originalDisplayName": "Main",
      "reason": "10 activities in sequence failed validation",
      "classifiedCheck": "UNDECLARED_VARIABLE, ENUM_VIOLATION",
      "developerAction": "Re-implement 10 activities in sequence \"Main\" in Main.xaml",
      "estimatedEffortMinutes": 150
    },
    {
      "level": "sequence",
      "file": "WF_GetTodaysBirthdays.xaml",
      "remediationCode": "STUB_SEQUENCE_MULTIPLE_FAILURES",
      "originalDisplayName": "WF_GetTodaysBirthdays",
      "reason": "2 activities in sequence failed validation",
      "classifiedCheck": "UNDECLARED_VARIABLE, CATALOG_STRUCTURAL_VIOLATION, ENUM_VIOLATION",
      "developerAction": "Re-implement 2 activities in sequence \"WF_GetTodaysBirthdays\" in WF_GetTodaysBirthdays.xaml",
      "estimatedEffortMinutes": 30
    },
    {
      "level": "structural-leaf",
      "file": "Main.xaml",
      "remediationCode": "STUB_STRUCTURAL_LEAF",
      "reason": "ENUM_VIOLATION: Invalid value \"Information\" for \"Level\" on ui:LogMessage — valid values: Trace, Info, Warn, Error, Fatal. This is a generation failure — enum violations must not be auto-corrected.",
      "classifiedCheck": "ENUM_VIOLATION",
      "developerAction": "Review and fix ENUM_VIOLATION issue in Main.xaml — workflow structure was preserved intact",
      "estimatedEffortMinutes": 5
    },
    {
      "level": "structural-leaf",
      "file": "Main.xaml",
      "remediationCode": "STUB_STRUCTURAL_LEAF",
      "reason": "ENUM_VIOLATION: Invalid value \"Warning\" for \"Level\" on ui:LogMessage — valid values: Trace, Info, Warn, Error, Fatal. This is a generation failure — enum violations must not be auto-corrected.",
      "classifiedCheck": "ENUM_VIOLATION",
      "developerAction": "Review and fix ENUM_VIOLATION issue in Main.xaml — workflow structure was preserved intact",
      "estimatedEffortMinutes": 5
    },
    {
      "level": "structural-leaf",
      "file": "WF_GetTodaysBirthdays.xaml",
      "remediationCode": "STUB_STRUCTURAL_LEAF",
      "reason": "Property \"To\" on Assign must be a child element, not an attribute",
      "classifiedCheck": "CATALOG_STRUCTURAL_VIOLATION",
      "developerAction": "Review and fix CATALOG_STRUCTURAL_VIOLATION issue in WF_GetTodaysBirthdays.xaml — workflow structure was preserved intact",
      "estimatedEffortMinutes": 15
    },
    {
      "level": "structural-leaf",
      "file": "WF_GetTodaysBirthdays.xaml",
      "remediationCode": "STUB_STRUCTURAL_LEAF",
      "reason": "Property \"Value\" on Assign must be a child element, not an attribute",
      "classifiedCheck": "CATALOG_STRUCTURAL_VIOLATION",
      "developerAction": "Review and fix CATALOG_STRUCTURAL_VIOLATION issue in WF_GetTodaysBirthdays.xaml — workflow structure was preserved intact",
      "estimatedEffortMinutes": 15
    },
    {
      "level": "structural-leaf",
      "file": "WF_GetTodaysBirthdays.xaml",
      "remediationCode": "STUB_STRUCTURAL_LEAF",
      "reason": "ENUM_VIOLATION: Invalid value \"Information\" for \"Level\" on ui:LogMessage — valid values: Trace, Info, Warn, Error, Fatal. This is a generation failure — enum violations must not be auto-corrected.",
      "classifiedCheck": "ENUM_VIOLATION",
      "developerAction": "Review and fix ENUM_VIOLATION issue in WF_GetTodaysBirthdays.xaml — workflow structure was preserved intact",
      "estimatedEffortMinutes": 5
    },
    {
      "level": "structural-leaf",
      "file": "WF_GetTodaysBirthdays.xaml",
      "remediationCode": "STUB_STRUCTURAL_LEAF",
      "reason": "ENUM_VIOLATION: Invalid value \"Warning\" for \"Level\" on ui:LogMessage — valid values: Trace, Info, Warn, Error, Fatal. This is a generation failure — enum violations must not be auto-corrected.",
      "classifiedCheck": "ENUM_VIOLATION",
      "developerAction": "Review and fix ENUM_VIOLATION issue in WF_GetTodaysBirthdays.xaml — workflow structure was preserved intact",
      "estimatedEffortMinutes": 5
    },
    {
      "level": "structural-leaf",
      "file": "InitAllSettings.xaml",
      "remediationCode": "STUB_STRUCTURAL_LEAF",
      "reason": "Property \"WorkbookPath\" on uexcel:ExcelApplicationScope must be a child element, not an attribute",
      "classifiedCheck": "CATALOG_STRUCTURAL_VIOLATION",
      "developerAction": "Review and fix CATALOG_STRUCTURAL_VIOLATION issue in InitAllSettings.xaml — workflow structure was preserved intact",
      "estimatedEffortMinutes": 15
    },
    {
      "level": "structural-leaf",
      "file": "InitAllSettings.xaml",
      "remediationCode": "STUB_STRUCTURAL_LEAF",
      "reason": "Property \"DataTable\" on uexcel:ExcelReadRange must be a child element, not an attribute",
      "classifiedCheck": "CATALOG_STRUCTURAL_VIOLATION",
      "developerAction": "Review and fix CATALOG_STRUCTURAL_VIOLATION issue in InitAllSettings.xaml — workflow structure was preserved intact",
      "estimatedEffortMinutes": 15
    },
    {
      "level": "workflow",
      "file": "Main.xaml",
      "remediationCode": "STUB_WORKFLOW_BLOCKING",
      "reason": "Final validation: XAML well-formedness violations — replaced with stub",
      "classifiedCheck": "xml-wellformedness",
      "developerAction": "Fix XML structure in Main.xaml — ensure proper nesting and closing tags",
      "estimatedEffortMinutes": 15
    },
    {
      "level": "workflow",
      "file": "WF_GetTodaysBirthdays.xaml",
      "remediationCode": "STUB_WORKFLOW_BLOCKING",
      "reason": "Final validation: XAML well-formedness violations — replaced with stub",
      "classifiedCheck": "xml-wellformedness",
      "developerAction": "Fix XML structure in WF_GetTodaysBirthdays.xaml — ensure proper nesting and closing tags",
      "estimatedEffortMinutes": 15
    }
  ],
  "propertyRemediations": [],
  "downgradeEvents": [],
  "qualityWarnings": [
    {
      "check": "hardcoded-asset-name",
      "file": "InitAllSettings.xaml",
      "detail": "Line 104: asset name \"BGV5_GooglePeople_ClientSecret\" is hardcoded — consider using a Config.xlsx entry or workflow argument",
      "severity": "warning"
    },
    {
      "check": "hardcoded-asset-name",
      "file": "InitAllSettings.xaml",
      "detail": "Line 116: asset name \"BGV5_GooglePeople_ClientId\" is hardcoded — consider using a Config.xlsx entry or workflow argument",
      "severity": "warning"
    },
    {
      "check": "hardcoded-asset-name",
      "file": "InitAllSettings.xaml",
      "detail": "Line 123: asset name \"BGV5_GooglePeople_RefreshToken\" is hardcoded — consider using a Config.xlsx entry or workflow argument",
      "severity": "warning"
    },
    {
      "check": "hardcoded-asset-name",
      "file": "InitAllSettings.xaml",
      "detail": "Line 130: asset name \"BGV5_GooglePeople_TokenEndpoint\" is hardcoded — consider using a Config.xlsx entry or workflow argument",
      "severity": "warning"
    },
    {
      "check": "hardcoded-asset-name",
      "file": "InitAllSettings.xaml",
      "detail": "Line 137: asset name \"BGV5_CalendarName\" is hardcoded — consider using a Config.xlsx entry or workflow argument",
      "severity": "warning"
    },
    {
      "check": "hardcoded-asset-name",
      "file": "InitAllSettings.xaml",
      "detail": "Line 144: asset name \"BGV5_TimeZone\" is hardcoded — consider using a Config.xlsx entry or workflow argument",
      "severity": "warning"
    },
    {
      "check": "hardcoded-asset-name",
      "file": "InitAllSettings.xaml",
      "detail": "Line 151: asset name \"BGV5_SubjectTemplate\" is hardcoded — consider using a Config.xlsx entry or workflow argument",
      "severity": "warning"
    }
  ],
  "totalEstimatedEffortMinutes": 740,
  "structuralPreservationMetrics": [
    {
      "file": "Main.xaml",
      "totalActivities": 1,
      "preservedActivities": 1,
      "stubbedActivities": 0,
      "preservedStructures": [
        "Activity",
        "Sequence (Main)",
        "Sequence.Variables"
      ]
    },
    {
      "file": "WF_GetTodaysBirthdays.xaml",
      "totalActivities": 1,
      "preservedActivities": 1,
      "stubbedActivities": 0,
      "preservedStructures": [
        "Activity",
        "Sequence (WF_GetTodaysBirthdays)",
        "Sequence.Variables"
      ]
    },
    {
      "file": "InitAllSettings.xaml",
      "totalActivities": 54,
      "preservedActivities": 54,
      "stubbedActivities": 0,
      "preservedStructures": [
        "Activity",
        "Sequence (Initialize All Settings)",
        "Sequence.Variables",
        "ActivityAction",
        "Sequence (Read Config Sheets)",
        "ForEach (Process Settings Rows)",
        "Sequence (Process Setting Row)",
        "ForEach (Process Constants Rows)",
        "Sequence (Store Constant)"
      ]
    }
  ],
  "studioCompatibility": [
    {
      "file": "Main.xaml",
      "level": "studio-blocked",
      "blockers": [
        "[STUB_WORKFLOW_GENERATOR_FAILURE] Workflow was replaced with a stub due to generation/compliance failure — structurally invalid"
      ]
    },
    {
      "file": "WF_GetTodaysBirthdays.xaml",
      "level": "studio-blocked",
      "blockers": [
        "[STUB_WORKFLOW_GENERATOR_FAILURE] Workflow was replaced with a stub due to generation/compliance failure — structurally invalid"
      ]
    },
    {
      "file": "InitAllSettings.xaml",
      "level": "studio-clean",
      "blockers": []
    }
  ]
}
```
