## 1. Automation Architecture Overview

### 1.1 Chosen automation type and rationale
[AUTOMATION_TYPE: RPA (Unattended) + HITL (Action Center exceptions)]

- **Primary path is deterministic and rules-based** (PO exists/match; invoice amount within ±5% tolerance; route to DOA), which is best served by **unattended RPA**.
- **Human-in-the-loop is only needed** when Coupa’s structured header fields are **missing/invalid/ambiguous** or when Coupa/UI/API behavior is inconsistent (rare but operationally critical). This is implemented via **Action Center**, not attended robots (none available).
- **Agents** are not used in the critical path because the decisioning is explicit and auditable. Agents may be introduced later for non-critical enrichment (see Platform Recommendations).

### 1.2 Architecture pattern
**Queue-driven dispatcher/performer with REFramework-style robustness**:
- **Trigger** detects/receives “new invoice submitted” events and creates **Queue Items** (one per invoice).
- **Performer** processes queue items with retries, idempotency controls, and standardized exception handling.
- **Action Center** is invoked only for exceptions (missing data / ambiguity), enabling full unattended execution.

This is intentionally chosen over a single monolithic workflow because it:
- Provides **natural scaling** across **11 unattended slots**.
- Gives **retry semantics** and operational visibility per invoice via Queue analytics.
- Simplifies **SLA management** and dead-letter handling.

### 1.3 UiPath services used and why
- **Orchestrator (Queues, Assets, Triggers, Logs, Processes):** Core orchestration, scaling, retries, centralized audit.
- **Triggers:** Queue Trigger to auto-start performer jobs and/or invoke dispatcher on schedule/webhook.
- **Action Center:** Exception tasks for “missing/invalid data” with due dates/escalations.
- **Data Service (Data Fabric):** Persistent, queryable record of invoice decisions, exceptions, and outcomes across runs (for audit, reporting, and reprocessing without relying on Orchestrator logs).
- **Storage Buckets:** Evidence storage (optional but recommended): screenshots on error, minimal run artifacts, and (if accessible) invoice PDF copy for audit.
- **Test Manager:** Regression suite for tolerance logic, rejection routing, Coupa state transitions.
- **Document Understanding / Generative Extraction:** **Not in core path** (Coupa already surfaces PO and amount as structured data). Reserved as an enhancement when structured fields are missing and the PDF must be parsed.
- **Integration Service:** Mandatory preference over custom HTTP for connectors. (Coupa connector is not listed as active; see Integration Points for the planned approach.)

### 1.4 Deployment topology and robot model
- **Execution:** Fully **unattended** on existing **11 unattended robots**.
- **Target runtime:** Cloud / VM-based unattended (no attended). Design assumes headless/background execution; all exception handling is via Action Center.
- **Naming to avoid conflict:** New process name will not conflict with existing **InvoiceReconciliation YY**.

### 1.5 Operability model (monitoring, alerting, SLAs)
- **Primary operational dashboard:** Orchestrator Queues (New / In Progress / Successful / Failed / Retried).
- **SLA tracking:** Action Center tasks include Due date + escalation policy; queue aging monitored via Orchestrator.
- **Alerting:** Queue item failure thresholds + Action Center overdue tasks routed to AP team distribution list (via Microsoft Outlook 365 connector) and/or Teams channel (optional).

---

## 2. Process Components and Workflow Breakdown

### 2.1 High-level components
1) **Dispatcher – “CoupaInvoiceReconV2_Dispatcher” (Unattended)**
- Purpose: Identify newly submitted Coupa invoices eligible for first-pass validation and add to Orchestrator Queue.
- Output: One queue item per invoice with Coupa invoice identifiers and header fields (if available).

2) **Performer – “CoupaInvoiceReconV2_Performer” (Unattended)**
- Purpose: Process queue items:
  - Read invoice header fields (PO, amount, supplier)
  - Validate completeness
  - Validate PO exists/match
  - Compute variance and evaluate ±5% tolerance
  - Route for DOA approval OR reject in Coupa with standardized free text comment (comment remains **implicit** within the Reject action)
  - Create Action Center task when missing/invalid data prevents deterministic processing
- Output: Update Coupa invoice state + persist outcome in Data Service.

3) **HITL Task Handler – “CoupaInvoiceReconV2_ActionCenterCallback” (Unattended)**
- Purpose: On task completion, resume processing:
  - If AP provides missing fields, update invoice and re-run validations.
  - If AP indicates reject, reject in Coupa with standardized comment.
- Triggering: Action Center completion event (polled/scheduled) or queue-based follow-up.

> Note: Because only unattended robots exist, “callback” is an unattended resumption pattern, not a user-attended step.

### 2.2 Orchestrator objects (logical)
- **Queue:** `Q_Coupa_Invoice_ReconV2`
  - Reference: unique per invoice submission; supports retries and dead-letter handling.
- **Triggers:**
  - **Queue Trigger** on `Q_Coupa_Invoice_ReconV2` to start Performer when items arrive.
  - **Scheduled Trigger** (optional fallback) for Dispatcher every X minutes if Coupa eventing is not available.
- **Assets (examples):**
  - `A_Coupa_TolerancePct` = 5
  - `A_RejectionComment_PO_Mismatch`
  - `A_RejectionComment_OutOfTolerance`
  - `A_RejectionComment_InsufficientData`
  - `A_Coupa_BaseUrl` / `A_Coupa_Tenant` (depending on integration method)
  - Credential assets for Coupa (if UI automation) stored as **Orchestrator Credentials**.

### 2.3 Detailed workflow logic

#### 2.3.1 Dispatcher (Unattended)
- Input: Coupa “new invoices” list since last run (watermark).
- Steps:
  1. Read watermark from **Data Service** (last successful fetch time) or Orchestrator Asset.
  2. Query Coupa for invoices in “Submitted” (or equivalent) state since watermark.
  3. For each invoice:
     - Check idempotency (Data Service record exists for same Coupa invoice ID in “processed” state).
     - Create Queue Item with:
       - `InvoiceId`, `Supplier`, `InvoiceAmount`, `PONumber`, `InvoiceStatus`, `SubmittedTimestamp`.
  4. Update watermark.
- Notes:
  - If Coupa supports webhook/event notification, Dispatcher can be replaced with a webhook-triggered ingestion. If not, schedule-based polling is used.

#### 2.3.2 Performer (Unattended; queue item processing)
- Input: Queue item
- Steps:
  1. Load QueueItem data.
  2. Retrieve current invoice details from Coupa (to handle updates between dispatch and execution).
  3. **Completeness check**:
     - Required: `PONumber` present, `InvoiceAmount` numeric > 0, `Supplier` present.
     - If incomplete/invalid → create **Action Center task** (see schema below), persist status “PendingHuman” in Data Service, and set queue item to Successful (business exception handled).
  4. Validate PO:
     - Confirm PO exists in Coupa and retrieve PO amount.
     - If PO not found / mismatch → Reject invoice in Coupa with standardized free-text comment (implicit inside reject action) and persist outcome.
  5. Tolerance check:
     - Variance = (InvoiceAmount - POAmount) / POAmount
     - If abs(variance) > 0.05 → Reject in Coupa with standardized comment, persist.
  6. If within tolerance:
     - Route invoice for DOA approval in Coupa (automation ends at “progressed to next stage” as per PDD scope).
     - Persist outcome “RoutedForApproval”.
- Idempotency:
  - Before taking action, check Data Service `InvoiceCase.ProcessingStatus`. If already terminal (Rejected/Routed), skip and mark as “Duplicate”.

#### 2.3.3 Action Center exception handling (Unattended resumption)
- Trigger: periodic job (every 15 min) queries Data Service for cases `PendingHuman` where task is `Completed`.
- For each completed task:
  - If `Resolution = ProvideData`:
    - Update invoice in Coupa with provided values (if Coupa allows editing; otherwise proceed using the provided values for decisioning only).
    - Re-run PO and tolerance validations; route/reject accordingly.
  - If `Resolution = Reject`:
    - Reject invoice in Coupa with “insufficient data” comment.

### 2.4 Action Center task design (schema + SLA)
**Task name:** `Invoice Data Exception Review`  
**Purpose:** Resolve missing/invalid Coupa structured header fields.

**Form Schema (fields, types, rules):**
- `CoupaInvoiceId` (String, read-only, required)
- `SupplierName` (String, read-only)
- `CurrentPONumber` (String, read-only, nullable)
- `CurrentInvoiceAmount` (Number, read-only, nullable)
- `Resolution` (String enum, required) values:
  - `ProvideData`
  - `Reject`
- `ProvidedPONumber` (String, required if Resolution=ProvideData; regex: `^[A-Za-z0-9\-]+$`)
- `ProvidedInvoiceAmount` (Number, required if Resolution=ProvideData; min: 0.01)
- `APComment` (String, optional; stored for audit)
- `SystemSuggestedReason` (String, read-only; default e.g., “Missing PO number” / “Invalid amount format”)

**SLA configuration:**
- **Due time:** 4 business hours from task creation (configurable via Asset).
- **Warning threshold:** 2 business hours (50% of SLA) → notify AP lead.
- **Escalation policy:** If overdue:
  - Send notification via **Microsoft Outlook 365 connector** to AP distribution list
  - Optional: send Teams message to AP channel
- **Auto-close:** None (must be completed explicitly)

**Persistence linkage:**
- Action Center task stores/updates the corresponding **Data Service entity** record `InvoiceCase` and `InvoiceExceptionTask`.

---

## 3. UiPath Activities and Packages Required

> All versions below match the verified catalog list. Any missing capability is flagged explicitly.

### 3.1 Core workflow and orchestration
- **UiPath.System.Activities 26.2.4**
  - Logging, config loading, retry helpers, file ops
- **UiPath.UIAutomation.Activities 25.10.29**
  - Use Application/Browser, Take Screenshot (used if Coupa access is via UI)
- **UiPath.Persistence.Activities — version not verified (not in verified catalog)**
  - Required for **Action Center / create and manage tasks**.
- **UiPath.Form.Activities 25.10.1**
  - Form schema support if needed for task forms (depending on Action Center implementation approach)

### 3.2 Data persistence (Data Service / Data Fabric)
- **UiPath.DataService.Activities 25.9.3**
  - Create Entity Record, Update Entity Record, Query Entity, Get Entity By Id

### 3.3 Evidence and artifacts
- **UiPath.UIAutomation.Activities 25.10.29**
  - Take Screenshot on exceptions
- **Storage Buckets Activities — package not verified (not in verified catalog)**
  - If using Storage Buckets APIs from workflows, the specific package/version needs verification. Otherwise store evidence via Orchestrator logs only.

### 3.4 Integration Service activities (mandatory preference)
- **UiPath.IntegrationService.Activities — version not verified (not in verified catalog)**
  - Required to invoke Integration Service connectors (Outlook 365 / Teams / etc.) where used.

### 3.5 Optional: Document Understanding (enhancement path)
If later required to extract PO/amount from PDF when Coupa fields are missing:
- **UiPath.IntelligentOCR.Activities 6.27.3**
  - Digitize Document, Extract Document Data, Validate Document Data
- **UiPath.AzureFormRecognizerV3.Activities 1.0.1** (optional alternative)
- **Generative Extraction** activities would typically use **UiPath GenAI Activities** via Integration Service connection:
  - **UiPath GenAI Activities connector** (connection exists) via Integration Service activities (package version not verified)

---

## 4. Integration Points and API/System Connections

### 4.1 Coupa (Primary system)
**Preferred integration approach:** Integration Service connector for Coupa (API-based).  
- Current tenant “active connections” list does **not** show a Coupa connector/connection.
- Therefore, the design supports two modes (selected during build after confirming Coupa connector availability):

**Mode A (Preferred): Coupa via Integration Service (API)**
- Connector: *Coupa* (to be configured)
- Authentication: OAuth/API key per Coupa policy
- Operations needed:
  - List invoices by status/date
  - Get invoice details (PO number, amount, supplier, status)
  - Get PO details (PO amount)
  - Route invoice for approval
  - Reject invoice (with free-text comment)

**Mode B (Fallback): Coupa via UI Automation**
- Package: UiPath.UIAutomation.Activities 25.10.29
- Browser-based automation using modern **Use Browser**.
- Credentials stored in Orchestrator Credential asset.
- Evidence capture (screenshots) strongly enforced for operability.

> Custom HTTP is intentionally not selected because the instruction mandates using Integration Service connectors instead of custom HTTP activities. If no Coupa connector is feasible, UI automation becomes the compliant fallback.

### 4.2 Notifications (escalations only; supplier notifications remain Coupa-native)
- **Microsoft Outlook 365** (Integration Service connection)
  - Connector name: Microsoft Outlook 365
  - Connection ID: `615536ff-ca60-47d5-b7aa-130cf6942152`
  - Usage: Send escalation emails for overdue Action Center tasks / repeated system failures.
- **Microsoft Teams** (optional)
  - Connector name: Microsoft Teams
  - Connection IDs: `aa8b0863-9e43-4fc6-af77-625e8f6cf406` or `8165d13a-2713-4c23-9a12-d41df0b7f106`
  - Usage: Operational alerts to AP support channel.

### 4.3 Data Service (Data Fabric)
- Accessed via **UiPath.DataService.Activities 25.9.3** within workflows.
- Entities defined in Section 8.

---

## 5. Exception Handling Strategy

### 5.1 Exception categories
**Business exceptions (handled, no retry):**
- Missing/invalid PO number or amount in Coupa structured fields → Action Center task
- PO not found / mismatch → reject invoice in Coupa (standard comment)
- Out of tolerance (>5%) → reject invoice in Coupa (standard comment)

**System exceptions (retryable):**
- Coupa unavailable / timeout / transient UI selectors not found
- Orchestrator transient errors
- Data Service temporary failures

### 5.2 Retry strategy
- **Orchestrator Queue retries** for system exceptions:
  - Max retries: 2 (configurable)
  - Backoff: 5 min then 15 min (implemented via queue retry + delayed trigger/schedule)
- **In-workflow retries** for known transient Coupa issues:
  - 3 attempts with increasing delay before throwing system exception.

### 5.3 Dead-letter handling
- After retries exhausted:
  - Mark Queue item as Failed
  - Persist `ProcessingStatus = FailedSystem` in Data Service with error signature
  - Create Action Center task `System Failure Review` (optional) or notify support mailbox via Outlook 365.

### 5.4 Screenshot-on-error (mandatory best practice)
- Every Try/Catch catch block:
  - **Take Screenshot** (UiPath.UIAutomation.Activities 25.10.29) and store:
    - either in Storage Bucket (preferred, pending verified package),
    - or as base64/text reference logged to Orchestrator logs with correlation ID.
  - Log structured error context (InvoiceId, step, exception type, retry count).

### 5.5 Standardized rejection comments (implicit within Reject action)
- Comments stored as Orchestrator Assets for maintainability:
  - PO mismatch template
  - Out of tolerance template
  - Insufficient data template
- The workflow injects the correct template into Coupa’s reject action field.

---

## 6. Security Considerations

- **Credentials:** Stored in Orchestrator **Credential Assets** (Coupa login if UI automation; API secret if connector).
- **Least privilege:** Robot account restricted to invoice read/update, PO read, route/reject actions only.
- **RBAC:**
  - Orchestrator folders: segregate DEV/TEST/PROD with appropriate roles.
  - Action Center: only AP group can view/complete tasks.
  - Data Service: entity access limited to automation and AP supervisors (read-only for reporting).
- **Data protection:**
  - Avoid storing invoice PDFs unless required. If stored (audit), use **Storage Buckets** with restricted access.
  - Logs must not contain supplier PII beyond necessary identifiers.
- **Audit trail:**
  - Orchestrator logs + Queue history + Data Service `InvoiceCase` records provide end-to-end traceability.

---

## 7. Test Strategy

### 7.1 Test levels
- **Unit tests (workflow-level):**
  - Variance calculation and tolerance boundaries (exactly 5%, 5.01%, negative variance)
  - Comment template selection
- **Integration tests:**
  - Coupa invoice retrieval and PO retrieval
  - Route for approval
  - Reject action
- **Exception-path tests:**
  - Missing PO number → Action Center task created
  - Action Center resolution ProvideData → route/reject as expected
  - Coupa transient outage → queue retry and eventual fail

### 7.2 Test Manager usage
- Build a **Test Project** aligned to the Performer and Dispatcher components.
- Define **Regression Suite** executed:
  - before UAT
  - before production deployment
  - after Coupa UI/API changes
- Store test evidence (screenshots/log extracts) in Test Manager attachments.

### 7.3 UAT approach
- UAT dataset: representative invoices (matched, mismatched, out-of-tolerance, missing data)
- Acceptance criteria:
  - Correct Coupa end-state transitions
  - Correct routing to DOA for compliant invoices
  - Correct standardized rejection reasons
  - Action Center SLA adherence and escalation behaviors

---

## 7a. Governance Compliance

- **Activity usage:** Modern UI Automation activities (Use Browser / Take Screenshot) are used to support unattended stability.
- **Naming conventions:** New processes/queues/assets prefixed with `CoupaInvoiceReconV2_` / `Q_` / `A_`.
- **Error handling:** Standard Try/Catch with screenshot-on-error and structured logging for all critical steps.
- **No attended dependencies:** All human involvement via Action Center only, consistent with robot landscape.

*(If tenant governance policies exist but are not visible via current scopes, validate during build and adjust naming/activities accordingly.)*

---

## 8. Data Model and Entity Design (Data Service / Data Fabric)

### 8.1 Entity: `InvoiceCase`
**Purpose:** Single source of truth per Coupa invoice submission (resubmissions are new cases).

Fields:
- `InvoiceCaseId` (String, primary key or auto-generated)
- `CoupaInvoiceId` (String, required, indexed)
- `SupplierName` (String)
- `SupplierId` (String, optional if available)
- `SubmittedAt` (DateTime)
- `PONumber` (String, nullable)
- `InvoiceAmount` (Decimal, nullable)
- `POAmount` (Decimal, nullable)
- `VariancePct` (Decimal, nullable)
- `TolerancePct` (Decimal, default 5.0)
- `ProcessingStatus` (String enum, required):
  - `New`, `Queued`, `InProgress`, `PendingHuman`, `RoutedForApproval`, `Rejected`, `FailedSystem`, `DuplicateSkipped`
- `OutcomeReason` (String enum, nullable):
  - `PO_Mismatch`, `PO_NotFound`, `OutOfTolerance`, `InsufficientData`, `DOA_Rejected`, `SystemError`
- `RejectionCommentUsed` (String, nullable) (store template key, not free-text if sensitive)
- `OrchestratorJobKey` (String, nullable)
- `QueueItemKey` (String, nullable)
- `LastUpdatedAt` (DateTime)
- `CorrelationId` (String)

Relationships:
- 1-to-many with `InvoiceExceptionTask`
- 1-to-many with `InvoiceProcessingEvent`

Referenced by:
- Dispatcher (idempotency + watermark linkage)
- Performer (read/write status and outcomes)
- Action Center tasks (link task to case)

### 8.2 Entity: `InvoiceExceptionTask`
**Purpose:** Track Action Center tasks and their resolutions.

Fields:
- `ExceptionTaskId` (String)
- `InvoiceCaseId` (Relationship to InvoiceCase, required)
- `ActionCenterTaskId` (String, required)
- `ExceptionType` (String enum): `MissingData`, `InvalidData`, `SystemFailure`
- `CreatedAt` (DateTime)
- `DueAt` (DateTime)
- `CompletedAt` (DateTime, nullable)
- `Resolution` (String enum, nullable): `ProvideData`, `Reject`
- `ProvidedPONumber` (String, nullable)
- `ProvidedInvoiceAmount` (Decimal, nullable)
- `APComment` (String, nullable)
- `EscalationCount` (Int, default 0)
- `Status` (String enum): `Open`, `Completed`, `Overdue`, `Cancelled`

Referenced by:
- Performer (task creation)
- Callback handler (resolution processing)
- Operational reporting

### 8.3 Entity: `InvoiceProcessingEvent`
**Purpose:** Lightweight event log for audit beyond Orchestrator logs.

Fields:
- `EventId` (String)
- `InvoiceCaseId` (Relationship, required)
- `EventAt` (DateTime)
- `EventType` (String) (e.g., “QueueCreated”, “RejectedInCoupa”, “RoutedForApproval”, “ActionCenterCreated”)
- `DetailsJson` (String) (small JSON payload, no sensitive data)
- `Severity` (String enum): `Info`, `Warning`, `Error`

---

### Platform Recommendations (not available / not relied upon)
- **Autopilot (not available):** Would accelerate triage and generate operator summaries for exceptions, and potentially auto-draft rejection comments and resolution guidance for AP in Action Center.
- **Automation Ops (not available):** Would enforce governance (package allowlists, naming standards, logging requirements) and provide automated drift control across environments.
- **Apps External API (not available):** If available with full API support, an AP “Exception Workbench” app could be provisioned for richer dashboards and bulk handling beyond Action Center’s task list.

*(Environments feature noted as not accessible: solution will use Orchestrator modern folder-based runtime configuration instead.)*

## 9. Orchestrator & Platform Deployment Specification

```orchestrator_artifacts
{
  "queues": [
    {
      "name": "Coupa_InvoiceReconciliationV2_Invoices",
      "description": "Work queue for newly submitted Coupa invoices to be validated (PO existence/match and 5% tolerance) and routed or rejected.",
      "maxRetries": 3,
      "uniqueReference": true
    },
    {
      "name": "Coupa_InvoiceReconciliationV2_OperationsExceptions",
      "description": "Operational exceptions requiring support intervention (e.g., Coupa unavailable, repeated UI/API failures).",
      "maxRetries": 1,
      "uniqueReference": true
    }
  ],
  "assets": [
    {
      "name": "Coupa_IRV2_Credentials",
      "type": "Credential",
      "value": "",
      "description": "Credential for Coupa access used by unattended robot (service account)."
    },
    {
      "name": "Coupa_IRV2_BaseUrl",
      "type": "Text",
      "value": "https://<tenant>.coupahost.com",
      "description": "Coupa tenant base URL used to navigate/API-call invoice and PO resources."
    },
    {
      "name": "Coupa_IRV2_TolerancePercent",
      "type": "Integer",
      "value": "5",
      "description": "Invoice amount tolerance percentage vs PO amount (±). Default 5 per PDD."
    },
    {
      "name": "Coupa_IRV2_RejectComment_POMismatch",
      "type": "Text",
      "value": "PO mismatch—please resubmit with correct PO number.",
      "description": "Standardized Coupa rejection comment template for PO mismatch."
    },
    {
      "name": "Coupa_IRV2_RejectComment_OutOfTolerance",
      "type": "Text",
      "value": "Amount exceeds 5% tolerance vs PO—please correct and resubmit.",
      "description": "Standardized Coupa rejection comment template for out-of-tolerance invoices."
    },
    {
      "name": "Coupa_IRV2_RejectComment_InsufficientData",
      "type": "Text",
      "value": "Insufficient data (missing/invalid PO number and/or amount)—please correct and resubmit.",
      "description": "Standardized Coupa rejection comment template for missing/ambiguous data."
    },
    {
      "name": "Coupa_IRV2_MaxTransactionSeconds",
      "type": "Integer",
      "value": "600",
      "description": "Transaction-level timeout guardrail in seconds (default aligned to current ~10 minutes manual handling)."
    },
    {
      "name": "Coupa_IRV2_MaxConsecutiveSystemFailures",
      "type": "Integer",
      "value": "5",
      "description": "If exceeded, stop normal processing and route to OperationsExceptions queue to protect SLA/operability."
    },
    {
      "name": "Coupa_IRV2_EnableEvidenceSnapshots",
      "type": "Bool",
      "value": "true",
      "description": "When true, store minimal evidence (screenshots/log extracts) to Storage Bucket for audit/troubleshooting."
    }
  ],
  "machines": [
    {
      "name": "VM-Template-Unattended-AP-Prod",
      "type": "Unattended",
      "slots": 5,
      "description": "Unattended machine template for production execution (scalable up to available robot pool)."
    },
    {
      "name": "VM-Template-Unattended-AP-NonProd",
      "type": "Development",
      "slots": 2,
      "description": "Non-production machine template for development/testing and controlled validation."
    }
  ],
  "triggers": [
    {
      "name": "TRG_Coupa_IRV2_Queue_NewInvoices",
      "type": "Queue",
      "queueName": "Coupa_InvoiceReconciliationV2_Invoices",
      "cron": "",
      "description": "Queue trigger to process newly submitted Coupa invoices as they arrive (fan-out across unattended slots)."
    },
    {
      "name": "TRG_Coupa_IRV2_Time_SafetyNet_Poller",
      "type": "Time",
      "queueName": "",
      "cron": "0 0/30 * ? * MON-FRI *",
      "description": "Safety-net schedule every 30 minutes on business days to handle missed events/backlog recovery (e.g., transient trigger failures)."
    }
  ],
  "storageBuckets": [
    {
      "name": "SB_Coupa_IRV2_Evidence",
      "description": "Stores optional evidence snapshots (e.g., screenshots, key log extracts) for audit and troubleshooting."
    }
  ],
  "environments": [
    {
      "name": "ENV_Coupa_IRV2_Production",
      "type": "Production",
      "description": "Production environment scope for PO and invoice reconciliationV2 automations."
    },
    {
      "name": "ENV_Coupa_IRV2_Testing",
      "type": "Testing",
      "description": "Testing environment scope for UAT/regression execution."
    },
    {
      "name": "ENV_Coupa_IRV2_Development",
      "type": "Development",
      "description": "Development environment scope for build and integration validation."
    }
  ],
  "actionCenter": [
    {
      "taskCatalog": "AC_Coupa_IRV2_MissingOrAmbiguousData",
      "assignedRole": "AP Clerk/Approver",
      "sla": "24 hours",
      "escalation": "If SLA breached, reassign/escalate to AP Team Lead; if still unresolved after 48 hours, reject invoice with 'insufficient data' and add item to OperationsExceptions queue for reporting.",
      "description": "Human-in-the-loop review to supply missing/ambiguous invoice header data (PO number/amount) or confirm rejection."
    }
  ],
  "requirements": [
    {
      "name": "REQ-001: Event-driven intake of new Coupa invoices",
      "description": "Automation must detect newly submitted Coupa invoices and initiate unattended processing via Orchestrator triggers.",
      "source": "PDD Section 4 (To-Be), Operationally paragraph"
    },
    {
      "name": "REQ-002: Validate required invoice header data completeness",
      "description": "Automation must verify required fields (PO number, amount, supplier) are present; if incomplete/ambiguous, create Action Center task for AP review.",
      "source": "PDD Section 4 Step 4.0–5.x; Section 7"
    },
    {
      "name": "REQ-003: Validate PO existence and PO match in Coupa",
      "description": "Automation must validate referenced PO exists in Coupa and matches invoice PO identifier; if mismatch, reject invoice with standardized comment.",
      "source": "PDD Section 4 Steps 5.0–6.1"
    },
    {
      "name": "REQ-004: Enforce 5% tolerance rule",
      "description": "Automation must calculate invoice-to-PO amount variance and accept only if within ±5%; otherwise reject with standardized comment.",
      "source": "PDD Section 4 Steps 7.0–10.2; Section 7 assumptions"
    },
    {
      "name": "REQ-005: Route compliant invoices to Coupa DOA approval chain",
      "description": "For matched and in-tolerance invoices, automation must route invoice within Coupa for DOA approval; automation scope ends when DOA outcome is known.",
      "source": "PDD Section 4 Steps 9.0–11.0"
    },
    {
      "name": "REQ-006: Standardized Coupa rejection comments",
      "description": "Rejection action must include standardized free-text comments for PO mismatch, out-of-tolerance, and insufficient data scenarios.",
      "source": "PDD Section 4 rejection examples; Section 5"
    },
    {
      "name": "REQ-007: Queue-based workload management with retries",
      "description": "Orchestrator queues must be used to manage workload (~50/day) and provide retry semantics and traceability.",
      "source": "PDD Section 4 Operationally; Section 8"
    },
    {
      "name": "REQ-008: Fully unattended execution with controlled exception handling",
      "description": "Solution must run fully unattended using available unattended robots, with Action Center used only for exception handling.",
      "source": "PDD Section 1, Section 4, Section 6"
    }
  ],
  "testCases": [
    {
      "name": "TC001 - Happy path: PO match and within tolerance routes to DOA",
      "description": "Valid invoice header data; PO exists and matches; amount variance <= 5%; invoice routed for approval in Coupa.",
      "steps": [
        {
          "action": "Create/identify a newly submitted Coupa invoice with structured PO number, amount, supplier; PO exists; variance <= 5%. Add to queue with invoice identifier as reference.",
          "expected": "Queue item created successfully and picked by trigger."
        },
        {
          "action": "Run automation and monitor transaction completion.",
          "expected": "Invoice is routed into Coupa DOA chain; queue item marked Successful; logs include tolerance calculation."
        }
      ]
    },
    {
      "name": "TC002 - PO mismatch results in rejection with standardized comment",
      "description": "Invoice references a PO number that does not match/exist as required; automation rejects invoice with PO mismatch template.",
      "steps": [
        {
          "action": "Submit invoice with invalid/non-matching PO number; enqueue invoice ID.",
          "expected": "Automation detects PO mismatch."
        },
        {
          "action": "Automation executes Coupa reject action.",
          "expected": "Invoice rejected in Coupa with 'PO mismatch—please resubmit with correct PO number.'"
        }
      ]
    },
    {
      "name": "TC003 - Out of tolerance results in rejection with standardized comment",
      "description": "PO match exists but invoice amount variance > 5%; automation rejects with out-of-tolerance template.",
      "steps": [
        {
          "action": "Submit invoice referencing valid PO with variance > 5%; enqueue invoice ID.",
          "expected": "Automation calculates variance > tolerance."
        },
        {
          "action": "Automation rejects invoice in Coupa.",
          "expected": "Invoice rejected with 'Amount exceeds 5% tolerance vs PO—please correct and resubmit.'"
        }
      ]
    },
    {
      "name": "TC004 - Missing required data creates Action Center task",
      "description": "Invoice is missing/ambiguous PO number and/or amount; automation creates Action Center task and pauses appropriately.",
      "steps": [
        {
          "action": "Submit invoice with missing PO number or missing/invalid amount; enqueue invoice ID.",
          "expected": "Automation creates Action Center task in catalog AC_Coupa_IRV2_MissingOrAmbiguousData assigned to AP Clerk/Approver."
        },
        {
          "action": "AP supplies missing data in Action Center.",
          "expected": "Automation updates Coupa invoice data and continues processing to route/reject based on rules."
        }
      ]
    },
    {
      "name": "TC005 - Action Center rejection decision leads to insufficient data rejection",
      "description": "AP confirms rejection in Action Center; automation rejects invoice with insufficient data template.",
      "steps": [
        {
          "action": "Trigger Action Center task for missing data.",
          "expected": "Task available in Action Center catalog."
        },
        {
          "action": "AP selects 'Reject' decision (or equivalent) without providing missing values.",
          "expected": "Automation rejects invoice in Coupa with 'Insufficient data...' comment and completes transaction."
        }
      ]
    },
    {
      "name": "TC006 - Transient Coupa failure retries and then routes to operations exceptions",
      "description": "Simulate Coupa downtime/transient errors; verify queue retry behavior and operations routing after max retries/system failures.",
      "steps": [
        {
          "action": "Induce Coupa access failure (e.g., block access or simulate 5xx) during processing.",
          "expected": "Transaction fails with System exception; queue retry occurs up to maxRetries."
        },
        {
          "action": "After retries exhausted, confirm exception handling path.",
          "expected": "Item marked failed; a record is added to Coupa_InvoiceReconciliationV2_OperationsExceptions (or equivalent operational escalation) with diagnostic info."
        }
      ]
    },
    {
      "name": "TC007 - Duplicate invoice event does not reprocess due to unique reference",
      "description": "Ensure idempotency: duplicate enqueue attempt for same invoice identifier does not create duplicate work item.",
      "steps": [
        {
          "action": "Attempt to add the same invoice identifier twice to Coupa_InvoiceReconciliationV2_Invoices queue (same reference).",
          "expected": "Second add is rejected/ignored by uniqueReference constraint."
        }
      ]
    },
    {
      "name": "TC008 - Resubmission treated as new submission",
      "description": "Vendor resubmits corrected invoice as a new Coupa invoice; automation processes it independently from prior rejection.",
      "steps": [
        {
          "action": "Reject an invoice; then submit a corrected invoice as a new submission with a different Coupa invoice ID; enqueue new invoice ID.",
          "expected": "New invoice processed end-to-end based on current rules; prior invoice not referenced/required."
        }
      ]
    }
  ],
  "testSets": [
    {
      "name": "Happy Path Tests",
      "description": "Core end-to-end routing behavior for compliant invoices.",
      "testCaseNames": [
        "TC001 - Happy path: PO match and within tolerance routes to DOA"
      ]
    },
    {
      "name": "Business Rules Tests",
      "description": "Validation and rejection behavior for PO mismatch and tolerance violations.",
      "testCaseNames": [
        "TC002 - PO mismatch results in rejection with standardized comment",
        "TC003 - Out of tolerance results in rejection with standardized comment",
        "TC008 - Resubmission treated as new submission"
      ]
    },
    {
      "name": "Exception Handling Tests",
      "description": "Missing data HITL, operational resiliency, and idempotency.",
      "testCaseNames": [
        "TC004 - Missing required data creates Action Center task",
        "TC005 - Action Center rejection decision leads to insufficient data rejection",
        "TC006 - Transient Coupa failure retries and then routes to operations exceptions",
        "TC007 - Duplicate invoice event does not reprocess due to unique reference"
      ]
    }
  ]
}
```