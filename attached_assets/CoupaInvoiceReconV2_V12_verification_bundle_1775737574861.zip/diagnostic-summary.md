# Diagnostic Summary

## Run Metadata
- **Run ID:** d53c9058-80ee-4566-9b94-ec0594c18a36
- **Idea ID:** 71e79d15-265d-433c-a414-f8a2c7c0d290
- **Status:** failed
- **Generation Mode:** null
- **Triggered By:** chat
- **Created At:** Thu Apr 09 2026 12:21:10 GMT+0000 (Coordinated Universal Time)
- **Completed At:** Thu Apr 09 2026 12:25:30 GMT+0000 (Coordinated Universal Time)
- **Duration:** 260.5s
- **Error:** [Dependency CrossCheck] FATAL: Package "UiPath.DataService.Activities.Core" is referenced in emitted XAML but has no validated version. Found in XAML files: [CoupaInvoiceReconV2_ActionCenterCallback.xaml]. Authority layers checked: [activity-catalog (getPreferredVersion): no match; generation-metadata (getBaselineFallbackVersion): no match]. Cannot emit a fabricated version — build aborted. Add this package to the generation-metadata.json packageVersionRanges or activity catalog to resolve.

## Stage Timing

| Stage | Status | Duration (ms) |
|-------|--------|--------------|
| sdd_validation | succeeded | 13 |
| pipeline_sdd_validation | succeeded | 12 |
| spec_generation | succeeded | 244810 |
| spec_context_loading | succeeded | 3 |
| spec_prompt_assembly | succeeded | 1 |
| pre_complexity_estimation | succeeded | 0 |
| spec_scaffold | succeeded | 40569 |
| workflow_budget_check | succeeded | 0 |
| spec_merge | succeeded | 0 |
| spec_handoff | succeeded | 0 |
| build_pipeline | failed | 15629 |
| pipeline_build_pipeline | failed | 15630 |
| pipeline_decomposition | succeeded | 2 |
| pipeline_pre_complexity_estimation | succeeded | 0 |
| pipeline_workflow_budget_check | succeeded | 0 |
| pipeline_complexity_classification | succeeded | 0 |
| pipeline_xaml_emission | failed | 9568 |

## Deterministic Transforms

| Transform Type | Count |
|---------------|-------|
| compliance_normalization | 14 |
| activity_policy_filter | 4 |
| workflow_analyzer_autofix | 9 |
