# Diagnostic Summary

## Run Metadata
- **Run ID:** 12f5e097-cd9d-4953-8139-c93d8a92ab68
- **Idea ID:** 70f71d88-7802-4dd8-8ca1-06c0cfcd7548
- **Status:** structurally_invalid
- **Generation Mode:** full_implementation
- **Triggered By:** chat
- **Created At:** Mon Apr 13 2026 10:20:37 GMT+0000 (Coordinated Universal Time)
- **Completed At:** Mon Apr 13 2026 10:35:28 GMT+0000 (Coordinated Universal Time)
- **Duration:** 891.8s

## Stage Timing

| Stage | Status | Duration (ms) |
|-------|--------|--------------|
| sdd_validation | succeeded | 22 |
| pipeline_sdd_validation | succeeded | 21 |
| spec_generation | succeeded | 360841 |
| spec_context_loading | succeeded | 4 |
| spec_prompt_assembly | succeeded | 2 |
| pre_complexity_estimation | succeeded | 0 |
| spec_scaffold | succeeded | 44434 |
| workflow_budget_check | succeeded | 0 |
| spec_merge | succeeded | 1 |
| spec_handoff | succeeded | 0 |
| build_pipeline | succeeded | 530772 |
| pipeline_build_pipeline | succeeded | 530772 |
| pipeline_decomposition | succeeded | 3 |
| pipeline_pre_complexity_estimation | succeeded | 0 |
| pipeline_workflow_budget_check | succeeded | 1 |
| pipeline_complexity_classification | succeeded | 0 |
| pipeline_xaml_emission | succeeded | 525621 |
| pipeline_ai_enrichment_tree | succeeded | 510163 |
| pipeline_xaml_emission_fallback | degraded | 0 |
| pipeline_xaml_emission_fallback | degraded | 0 |
| pipeline_xaml_emission_fallback | degraded | 0 |
| pipeline_xaml_emission_fallback | degraded | 0 |
| pipeline_xaml_emission_fallback | degraded | 0 |
| pipeline_xaml_emission_fallback | degraded | 0 |
| pipeline_xaml_emission_fallback | degraded | 0 |
| pipeline_xaml_emission_fallback | degraded | 0 |
| pipeline_xaml_emission_fallback | degraded | 0 |
| pipeline_xaml_emission_fallback | degraded | 0 |
| pipeline_xaml_emission_fallback | degraded | 0 |
| pipeline_xaml_emission_fallback | degraded | 0 |
| pipeline_compliance_normalization | succeeded | 18 |
| pipeline_validation | succeeded | 3 |
| pipeline_packaging_dhg | succeeded | 0 |
| pipeline_final_artifact_validation | succeeded | 1695 |
| pipeline_packaging_dhg_guide | succeeded | 161 |
| pipeline_pre-emission-lowering_fallback | degraded | 0 |
| pipeline_pre-emission-lowering_fallback | degraded | 0 |
| pipeline_pre-emission-lowering_fallback | degraded | 0 |
| pipeline_pre-emission-lowering_fallback | degraded | 0 |
| pipeline_pre-emission-lowering_fallback | degraded | 0 |
| pipeline_spec-validation_fallback | degraded | 0 |
| pipeline_structural-deduplication_fallback | degraded | 0 |
| pipeline_structural-deduplication_fallback | degraded | 0 |
| pipeline_dependency-crosscheck_fallback | degraded | 0 |
| pipeline_post-assembly-validation_fallback | degraded | 0 |
| pipeline_post-assembly-validation_fallback | degraded | 0 |
| pipeline_post-assembly-validation_fallback | degraded | 0 |
| pipeline_complete | succeeded | 1 |

## LLM Call Summary

| Stage | Model | Duration (ms) | Input Tokens | Output Tokens | Status |
|-------|-------|--------------|-------------|--------------|--------|
| xaml_enrichment_tree | claude-sonnet-4-6 | 60022 | 51806 | 6193 | error |
| xaml_enrichment_tree | claude-sonnet-4-6 | 60003 | 51814 | 6358 | error |
| xaml_enrichment_tree | claude-sonnet-4-6 | 48480 | 51762 | 4152 | success |
| xaml_enrichment_tree | claude-sonnet-4-6 | 60002 | 51851 | 5480 | error |
| xaml_enrichment_tree | claude-sonnet-4-6 | 60002 | 51821 | 6160 | error |
| xaml_enrichment_tree | claude-sonnet-4-6 | 60001 | 51768 | 5333 | error |
| xaml_enrichment_tree | claude-sonnet-4-6 | 60003 | 51767 | 6126 | error |
| xaml_enrichment_tree | claude-sonnet-4-6 | 41212 | 51763 | 2894 | success |
| xaml_enrichment_tree | claude-sonnet-4-6 | 60002 | 51895 | 6180 | error |

**Totals:** 9 calls, 466247 input tokens, 48876 output tokens, 509.7s total LLM time

## Deterministic Transforms

| Transform Type | Count |
|---------------|-------|
| compliance_normalization | 23 |
| activity_policy_filter | 3 |
| workflow_analyzer_autofix | 20 |
| expression_lint | 2 |
| type_compatibility | 12 |
| required_property_enforcement | 2 |

## Quality Gate Summary

- **Passed:** false
- **Total Errors:** 2
- **Total Warnings:** 35
- **Completeness:** structural

## Meta-Validation Summary

- **Engaged:** false
- **Mode:** Always
- **Corrections Applied:** 0
- **Corrections Skipped:** 0
- **Corrections Failed:** 0
- **Confidence Score:** 0.5588235294117647
- **Duration:** 0ms

## Remediations

- {"level":"activity","file":"BGYY_SendGmail.xaml","remediationCode":"DEGRADED_ACTIVITY_MISSING_PROPERTY","reason":"Activity \"Send birthday email via Gmail Integration Service connector\" missing required properties: Body — degraded to handoff block","classifiedCheck":"critical-activity-degradation","developerAction":"Provide the missing properties for \"UiPath.GSuite.Activities.GmailSendMessage\": Body","estimatedEffortMinutes":5}
- {"level":"activity","file":"BGYY_WriteSendLog.xaml","remediationCode":"DEGRADED_ACTIVITY_MISSING_PROPERTY","reason":"Activity \"Update existing BGYY_BirthdaySendLog record with latest outcome fields\" missing required properties: EntityObject — degraded to handoff block","classifiedCheck":"critical-activity-degradation","developerAction":"Provide the missing properties for \"UiPath.DataService.Activities.UpdateEntity\": EntityObject","estimatedEffortMinutes":5}
- {"level":"activity","file":"BGYY_WriteSendLog.xaml","remediationCode":"DEGRADED_ACTIVITY_MISSING_PROPERTY","reason":"Activity \"Create new BGYY_BirthdaySendLog record with all audit fields\" missing required properties: EntityObject — degraded to handoff block","classifiedCheck":"critical-activity-degradation","developerAction":"Provide the missing properties for \"UiPath.DataService.Activities.CreateEntity\": EntityObject","estimatedEffortMinutes":5}
- {"level":"activity","file":"BGYY_CreateReviewTask.xaml","remediationCode":"DEGRADED_ACTIVITY_MISSING_PROPERTY","reason":"Activity \"Create Action Center Form Task in BGYY_DraftReview Catalog\" missing required properties: TaskTitle — degraded to handoff block","classifiedCheck":"critical-activity-degradation","developerAction":"Provide the missing properties for \"UiPath.Persistence.Activities.CreateFormTask\": TaskTitle","estimatedEffortMinutes":5}
- {"level":"activity","file":"BGYY_SendGmail.xaml","remediationCode":"DEGRADED_ACTIVITY_MISSING_PROPERTY","reason":"Mail activity in cluster \"BGYY_SendGmail.xaml:BGYY_SendGmail:mail-cluster-0\" missing required properties: Body — degraded to handoff block","classifiedCheck":"critical-activity-degradation","developerAction":"Provide the missing properties for mail activity \"UiPath.GSuite.Activities.GmailSendMessage\": Body","estimatedEffortMinutes":5}
- {"level":"validation-finding","file":"BGYY_Main.xaml","remediationCode":"STUB_ACTIVITY_UNKNOWN","reason":"Line 255: Undeclared variable \"BGYY_Main\" in expression: BGYY_Main &amp; &quot; Workflow started. Initializing run.&q... — variable is not declared in any <Variable> block in scope","classifiedCheck":"UNDECLARED_VARIABLE","developerAction":"Manually implement activity in BGYY_Main.xaml — estimated 15 min","estimatedEffortMinutes":15}
- {"level":"validation-finding","file":"BGYY_Main.xaml","remediationCode":"STUB_ACTIVITY_UNKNOWN","reason":"Line 330: Undeclared variable \"str_AssetValue\" in expression: str_AssetValue — variable is not declared in any <Variable> block in scope","classifiedCheck":"UNDECLARED_VARIABLE","developerAction":"Manually implement activity in BGYY_Main.xaml — estimated 15 min","estimatedEffortMinutes":15}
- {"level":"validation-finding","file":"BGYY_Main.xaml","remediationCode":"STUB_ACTIVITY_UNKNOWN","reason":"Line 483: Undeclared variable \"vb_expression\" in expression: vb_expression — variable is not declared in any <Variable> block in scope","classifiedCheck":"UNDECLARED_VARIABLE","developerAction":"Manually implement activity in BGYY_Main.xaml — estimated 15 min","estimatedEffortMinutes":15}
- {"level":"validation-finding","file":"BGYY_GetTodaysBirthdays.xaml","remediationCode":"STUB_ACTIVITY_UNKNOWN","reason":"Line 143: ui:BuildDataTable is missing required property \"TableInfo\"","classifiedCheck":"MISSING_REQUIRED_ACTIVITY_PROPERTY","developerAction":"Manually implement activity in BGYY_GetTodaysBirthdays.xaml — estimated 15 min","estimatedEffortMinutes":15}
- {"level":"validation-finding","file":"InitAllSettings.xaml","remediationCode":"STUB_ACTIVITY_UNKNOWN","reason":"Line 173: uexcel:ExcelApplicationScope is missing required property \"ExistingWorkbook\"","classifiedCheck":"MISSING_REQUIRED_ACTIVITY_PROPERTY","developerAction":"Manually implement activity in InitAllSettings.xaml — estimated 15 min","estimatedEffortMinutes":15}
- {"level":"validation-finding","file":"BGYY_GetTodaysBirthdays.xaml","remediationCode":"STUB_ACTIVITY_CATALOG_VIOLATION","reason":"Property \"To\" on Assign must be a child element, not an attribute","classifiedCheck":"CATALOG_STRUCTURAL_VIOLATION","developerAction":"Fix property syntax for activity in BGYY_GetTodaysBirthdays.xaml — move attribute to child-element or vice versa per UiPath catalog","estimatedEffortMinutes":15}
- {"level":"validation-finding","file":"BGYY_GetTodaysBirthdays.xaml","remediationCode":"STUB_ACTIVITY_CATALOG_VIOLATION","reason":"Property \"Value\" on Assign must be a child element, not an attribute","classifiedCheck":"CATALOG_STRUCTURAL_VIOLATION","developerAction":"Fix property syntax for activity in BGYY_GetTodaysBirthdays.xaml — move attribute to child-element or vice versa per UiPath catalog","estimatedEffortMinutes":15}
- {"level":"validation-finding","file":"BGYY_ResolveRecipient.xaml","remediationCode":"STUB_ACTIVITY_CATALOG_VIOLATION","reason":"Property \"To\" on Assign must be a child element, not an attribute","classifiedCheck":"CATALOG_STRUCTURAL_VIOLATION","developerAction":"Fix property syntax for activity in BGYY_ResolveRecipient.xaml — move attribute to child-element or vice versa per UiPath catalog","estimatedEffortMinutes":15}
- {"level":"validation-finding","file":"BGYY_ResolveRecipient.xaml","remediationCode":"STUB_ACTIVITY_CATALOG_VIOLATION","reason":"Property \"Value\" on Assign must be a child element, not an attribute","classifiedCheck":"CATALOG_STRUCTURAL_VIOLATION","developerAction":"Fix property syntax for activity in BGYY_ResolveRecipient.xaml — move attribute to child-element or vice versa per UiPath catalog","estimatedEffortMinutes":15}
- {"level":"validation-finding","file":"BGYY_CheckDedupe.xaml","remediationCode":"STUB_ACTIVITY_CATALOG_VIOLATION","reason":"Property \"Exception\" on Throw must be a child element, not an attribute","classifiedCheck":"CATALOG_STRUCTURAL_VIOLATION","developerAction":"Fix property syntax for activity in BGYY_CheckDedupe.xaml — move attribute to child-element or vice versa per UiPath catalog","estimatedEffortMinutes":15}
- {"level":"validation-finding","file":"BGYY_CheckDedupe.xaml","remediationCode":"STUB_ACTIVITY_CATALOG_VIOLATION","reason":"Property \"To\" on Assign must be a child element, not an attribute","classifiedCheck":"CATALOG_STRUCTURAL_VIOLATION","developerAction":"Fix property syntax for activity in BGYY_CheckDedupe.xaml — move attribute to child-element or vice versa per UiPath catalog","estimatedEffortMinutes":15}
- {"level":"validation-finding","file":"BGYY_CheckDedupe.xaml","remediationCode":"STUB_ACTIVITY_CATALOG_VIOLATION","reason":"Property \"Value\" on Assign must be a child element, not an attribute","classifiedCheck":"CATALOG_STRUCTURAL_VIOLATION","developerAction":"Fix property syntax for activity in BGYY_CheckDedupe.xaml — move attribute to child-element or vice versa per UiPath catalog","estimatedEffortMinutes":15}
- {"level":"validation-finding","file":"BGYY_GenerateDraft.xaml","remediationCode":"STUB_ACTIVITY_CATALOG_VIOLATION","reason":"Property \"Path\" on ucas:ReadStorageText must be a child element, not an attribute","classifiedCheck":"CATALOG_STRUCTURAL_VIOLATION","developerAction":"Fix property syntax for activity in BGYY_GenerateDraft.xaml — move attribute to child-element or vice versa per UiPath catalog","estimatedEffortMinutes":15}
- {"level":"validation-finding","file":"BGYY_GenerateDraft.xaml","remediationCode":"STUB_ACTIVITY_CATALOG_VIOLATION","reason":"Property \"StorageBucketName\" on ucas:ReadStorageText must be a child element, not an attribute","classifiedCheck":"CATALOG_STRUCTURAL_VIOLATION","developerAction":"Fix property syntax for activity in BGYY_GenerateDraft.xaml — move attribute to child-element or vice versa per UiPath catalog","estimatedEffortMinutes":15}
- {"level":"validation-finding","file":"BGYY_GenerateDraft.xaml","remediationCode":"STUB_ACTIVITY_CATALOG_VIOLATION","reason":"Property \"Destination\" on ucas:UploadStorageFile must be a child element, not an attribute","classifiedCheck":"CATALOG_STRUCTURAL_VIOLATION","developerAction":"Fix property syntax for activity in BGYY_GenerateDraft.xaml — move attribute to child-element or vice versa per UiPath catalog","estimatedEffortMinutes":15}
- {"level":"validation-finding","file":"BGYY_GenerateDraft.xaml","remediationCode":"STUB_ACTIVITY_CATALOG_VIOLATION","reason":"Property \"FileResource\" on ucas:UploadStorageFile must be a child element, not an attribute","classifiedCheck":"CATALOG_STRUCTURAL_VIOLATION","developerAction":"Fix property syntax for activity in BGYY_GenerateDraft.xaml — move attribute to child-element or vice versa per UiPath catalog","estimatedEffortMinutes":15}
- {"level":"validation-finding","file":"BGYY_GenerateDraft.xaml","remediationCode":"STUB_ACTIVITY_CATALOG_VIOLATION","reason":"Property \"Path\" on ucas:UploadStorageFile must be a child element, not an attribute","classifiedCheck":"CATALOG_STRUCTURAL_VIOLATION","developerAction":"Fix property syntax for activity in BGYY_GenerateDraft.xaml — move attribute to child-element or vice versa per UiPath catalog","estimatedEffortMinutes":15}
- {"level":"validation-finding","file":"BGYY_GenerateDraft.xaml","remediationCode":"STUB_ACTIVITY_CATALOG_VIOLATION","reason":"Property \"StorageBucketName\" on ucas:UploadStorageFile must be a child element, not an attribute","classifiedCheck":"CATALOG_STRUCTURAL_VIOLATION","developerAction":"Fix property syntax for activity in BGYY_GenerateDraft.xaml — move attribute to child-element or vice versa per UiPath catalog","estimatedEffortMinutes":15}
- {"level":"validation-finding","file":"BGYY_GenerateDraft.xaml","remediationCode":"STUB_ACTIVITY_CATALOG_VIOLATION","reason":"Property \"To\" on Assign must be a child element, not an attribute","classifiedCheck":"CATALOG_STRUCTURAL_VIOLATION","developerAction":"Fix property syntax for activity in BGYY_GenerateDraft.xaml — move attribute to child-element or vice versa per UiPath catalog","estimatedEffortMinutes":15}
- {"level":"validation-finding","file":"BGYY_GenerateDraft.xaml","remediationCode":"STUB_ACTIVITY_CATALOG_VIOLATION","reason":"Property \"Value\" on Assign must be a child element, not an attribute","classifiedCheck":"CATALOG_STRUCTURAL_VIOLATION","developerAction":"Fix property syntax for activity in BGYY_GenerateDraft.xaml — move attribute to child-element or vice versa per UiPath catalog","estimatedEffortMinutes":15}
- {"level":"validation-finding","file":"BGYY_ValidateDraft.xaml","remediationCode":"STUB_ACTIVITY_CATALOG_VIOLATION","reason":"Property \"To\" on Assign must be a child element, not an attribute","classifiedCheck":"CATALOG_STRUCTURAL_VIOLATION","developerAction":"Fix property syntax for activity in BGYY_ValidateDraft.xaml — move attribute to child-element or vice versa per UiPath catalog","estimatedEffortMinutes":15}
- {"level":"validation-finding","file":"BGYY_ValidateDraft.xaml","remediationCode":"STUB_ACTIVITY_CATALOG_VIOLATION","reason":"Property \"Value\" on Assign must be a child element, not an attribute","classifiedCheck":"CATALOG_STRUCTURAL_VIOLATION","developerAction":"Fix property syntax for activity in BGYY_ValidateDraft.xaml — move attribute to child-element or vice versa per UiPath catalog","estimatedEffortMinutes":15}
- {"level":"validation-finding","file":"BGYY_ValidateDraft.xaml","remediationCode":"STUB_ACTIVITY_CATALOG_VIOLATION","reason":"Property \"Input\" on ui:IsMatch must be a child element, not an attribute","classifiedCheck":"CATALOG_STRUCTURAL_VIOLATION","developerAction":"Fix property syntax for activity in BGYY_ValidateDraft.xaml — move attribute to child-element or vice versa per UiPath catalog","estimatedEffortMinutes":15}
- {"level":"validation-finding","file":"BGYY_ValidateDraft.xaml","remediationCode":"STUB_ACTIVITY_CATALOG_VIOLATION","reason":"Property \"Pattern\" on ui:IsMatch must be a child element, not an attribute","classifiedCheck":"CATALOG_STRUCTURAL_VIOLATION","developerAction":"Fix property syntax for activity in BGYY_ValidateDraft.xaml — move attribute to child-element or vice versa per UiPath catalog","estimatedEffortMinutes":15}
- {"level":"validation-finding","file":"BGYY_ValidateDraft.xaml","remediationCode":"STUB_ACTIVITY_CATALOG_VIOLATION","reason":"Property \"Path\" on ucas:ReadStorageText must be a child element, not an attribute","classifiedCheck":"CATALOG_STRUCTURAL_VIOLATION","developerAction":"Fix property syntax for activity in BGYY_ValidateDraft.xaml — move attribute to child-element or vice versa per UiPath catalog","estimatedEffortMinutes":15}
- {"level":"validation-finding","file":"BGYY_ValidateDraft.xaml","remediationCode":"STUB_ACTIVITY_CATALOG_VIOLATION","reason":"Property \"StorageBucketName\" on ucas:ReadStorageText must be a child element, not an attribute","classifiedCheck":"CATALOG_STRUCTURAL_VIOLATION","developerAction":"Fix property syntax for activity in BGYY_ValidateDraft.xaml — move attribute to child-element or vice versa per UiPath catalog","estimatedEffortMinutes":15}
- {"level":"validation-finding","file":"BGYY_SendGmail.xaml","remediationCode":"STUB_ACTIVITY_CATALOG_VIOLATION","reason":"Property \"To\" on Assign must be a child element, not an attribute","classifiedCheck":"CATALOG_STRUCTURAL_VIOLATION","developerAction":"Fix property syntax for activity in BGYY_SendGmail.xaml — move attribute to child-element or vice versa per UiPath catalog","estimatedEffortMinutes":15}
- {"level":"validation-finding","file":"BGYY_SendGmail.xaml","remediationCode":"STUB_ACTIVITY_CATALOG_VIOLATION","reason":"Property \"Value\" on Assign must be a child element, not an attribute","classifiedCheck":"CATALOG_STRUCTURAL_VIOLATION","developerAction":"Fix property syntax for activity in BGYY_SendGmail.xaml — move attribute to child-element or vice versa per UiPath catalog","estimatedEffortMinutes":15}
- {"level":"validation-finding","file":"BGYY_SendGmail.xaml","remediationCode":"STUB_ACTIVITY_CATALOG_VIOLATION","reason":"Property \"Destination\" on ucas:UploadStorageFile must be a child element, not an attribute","classifiedCheck":"CATALOG_STRUCTURAL_VIOLATION","developerAction":"Fix property syntax for activity in BGYY_SendGmail.xaml — move attribute to child-element or vice versa per UiPath catalog","estimatedEffortMinutes":15}
- {"level":"validation-finding","file":"BGYY_SendGmail.xaml","remediationCode":"STUB_ACTIVITY_CATALOG_VIOLATION","reason":"Property \"FileResource\" on ucas:UploadStorageFile must be a child element, not an attribute","classifiedCheck":"CATALOG_STRUCTURAL_VIOLATION","developerAction":"Fix property syntax for activity in BGYY_SendGmail.xaml — move attribute to child-element or vice versa per UiPath catalog","estimatedEffortMinutes":15}
- {"level":"validation-finding","file":"BGYY_SendGmail.xaml","remediationCode":"STUB_ACTIVITY_CATALOG_VIOLATION","reason":"Property \"Path\" on ucas:UploadStorageFile must be a child element, not an attribute","classifiedCheck":"CATALOG_STRUCTURAL_VIOLATION","developerAction":"Fix property syntax for activity in BGYY_SendGmail.xaml — move attribute to child-element or vice versa per UiPath catalog","estimatedEffortMinutes":15}
- {"level":"validation-finding","file":"BGYY_SendGmail.xaml","remediationCode":"STUB_ACTIVITY_CATALOG_VIOLATION","reason":"Property \"StorageBucketName\" on ucas:UploadStorageFile must be a child element, not an attribute","classifiedCheck":"CATALOG_STRUCTURAL_VIOLATION","developerAction":"Fix property syntax for activity in BGYY_SendGmail.xaml — move attribute to child-element or vice versa per UiPath catalog","estimatedEffortMinutes":15}
- {"level":"validation-finding","file":"BGYY_WriteSendLog.xaml","remediationCode":"STUB_ACTIVITY_CATALOG_VIOLATION","reason":"Property \"To\" on Assign must be a child element, not an attribute","classifiedCheck":"CATALOG_STRUCTURAL_VIOLATION","developerAction":"Fix property syntax for activity in BGYY_WriteSendLog.xaml — move attribute to child-element or vice versa per UiPath catalog","estimatedEffortMinutes":15}
- {"level":"validation-finding","file":"BGYY_WriteSendLog.xaml","remediationCode":"STUB_ACTIVITY_CATALOG_VIOLATION","reason":"Property \"Value\" on Assign must be a child element, not an attribute","classifiedCheck":"CATALOG_STRUCTURAL_VIOLATION","developerAction":"Fix property syntax for activity in BGYY_WriteSendLog.xaml — move attribute to child-element or vice versa per UiPath catalog","estimatedEffortMinutes":15}
- {"level":"validation-finding","file":"BGYY_CreateReviewTask.xaml","remediationCode":"STUB_ACTIVITY_CATALOG_VIOLATION","reason":"Property \"To\" on Assign must be a child element, not an attribute","classifiedCheck":"CATALOG_STRUCTURAL_VIOLATION","developerAction":"Fix property syntax for activity in BGYY_CreateReviewTask.xaml — move attribute to child-element or vice versa per UiPath catalog","estimatedEffortMinutes":15}
- {"level":"validation-finding","file":"BGYY_CreateReviewTask.xaml","remediationCode":"STUB_ACTIVITY_CATALOG_VIOLATION","reason":"Property \"Value\" on Assign must be a child element, not an attribute","classifiedCheck":"CATALOG_STRUCTURAL_VIOLATION","developerAction":"Fix property syntax for activity in BGYY_CreateReviewTask.xaml — move attribute to child-element or vice versa per UiPath catalog","estimatedEffortMinutes":15}
- {"level":"validation-finding","file":"BGYY_Main.xaml","remediationCode":"STUB_ACTIVITY_CATALOG_VIOLATION","reason":"Property \"To\" on Assign must be a child element, not an attribute","classifiedCheck":"CATALOG_STRUCTURAL_VIOLATION","developerAction":"Fix property syntax for activity in BGYY_Main.xaml — move attribute to child-element or vice versa per UiPath catalog","estimatedEffortMinutes":15}
- {"level":"validation-finding","file":"BGYY_Main.xaml","remediationCode":"STUB_ACTIVITY_CATALOG_VIOLATION","reason":"Property \"Value\" on Assign must be a child element, not an attribute","classifiedCheck":"CATALOG_STRUCTURAL_VIOLATION","developerAction":"Fix property syntax for activity in BGYY_Main.xaml — move attribute to child-element or vice versa per UiPath catalog","estimatedEffortMinutes":15}
- {"level":"validation-finding","file":"InitAllSettings.xaml","remediationCode":"STUB_ACTIVITY_CATALOG_VIOLATION","reason":"Property \"ExistingWorkbook\" on uexcel:ExcelApplicationScope must be a child element, not an attribute","classifiedCheck":"CATALOG_STRUCTURAL_VIOLATION","developerAction":"Fix property syntax for activity in InitAllSettings.xaml — move attribute to child-element or vice versa per UiPath catalog","estimatedEffortMinutes":15}
- {"level":"validation-finding","file":"InitAllSettings.xaml","remediationCode":"STUB_ACTIVITY_CATALOG_VIOLATION","reason":"Property \"To\" on Assign must be a child element, not an attribute","classifiedCheck":"CATALOG_STRUCTURAL_VIOLATION","developerAction":"Fix property syntax for activity in InitAllSettings.xaml — move attribute to child-element or vice versa per UiPath catalog","estimatedEffortMinutes":15}
- {"level":"validation-finding","file":"InitAllSettings.xaml","remediationCode":"STUB_ACTIVITY_CATALOG_VIOLATION","reason":"Property \"Value\" on Assign must be a child element, not an attribute","classifiedCheck":"CATALOG_STRUCTURAL_VIOLATION","developerAction":"Fix property syntax for activity in InitAllSettings.xaml — move attribute to child-element or vice versa per UiPath catalog","estimatedEffortMinutes":15}
- {"level":"validation-finding","file":"Main.xaml","remediationCode":"STUB_ACTIVITY_CATALOG_VIOLATION","reason":"Property \"To\" on Assign must be a child element, not an attribute","classifiedCheck":"CATALOG_STRUCTURAL_VIOLATION","developerAction":"Fix property syntax for activity in Main.xaml — move attribute to child-element or vice versa per UiPath catalog","estimatedEffortMinutes":15}
- {"level":"validation-finding","file":"Main.xaml","remediationCode":"STUB_ACTIVITY_CATALOG_VIOLATION","reason":"Property \"Value\" on Assign must be a child element, not an attribute","classifiedCheck":"CATALOG_STRUCTURAL_VIOLATION","developerAction":"Fix property syntax for activity in Main.xaml — move attribute to child-element or vice versa per UiPath catalog","estimatedEffortMinutes":15}
- {"level":"validation-finding","file":"GetTransactionData.xaml","remediationCode":"STUB_ACTIVITY_CATALOG_VIOLATION","reason":"Property \"To\" on Assign must be a child element, not an attribute","classifiedCheck":"CATALOG_STRUCTURAL_VIOLATION","developerAction":"Fix property syntax for activity in GetTransactionData.xaml — move attribute to child-element or vice versa per UiPath catalog","estimatedEffortMinutes":15}
- {"level":"validation-finding","file":"GetTransactionData.xaml","remediationCode":"STUB_ACTIVITY_CATALOG_VIOLATION","reason":"Property \"Value\" on Assign must be a child element, not an attribute","classifiedCheck":"CATALOG_STRUCTURAL_VIOLATION","developerAction":"Fix property syntax for activity in GetTransactionData.xaml — move attribute to child-element or vice versa per UiPath catalog","estimatedEffortMinutes":15}
- {"level":"validation-finding","file":"Init.xaml","remediationCode":"STUB_ACTIVITY_CATALOG_VIOLATION","reason":"Property \"To\" on Assign must be a child element, not an attribute","classifiedCheck":"CATALOG_STRUCTURAL_VIOLATION","developerAction":"Fix property syntax for activity in Init.xaml — move attribute to child-element or vice versa per UiPath catalog","estimatedEffortMinutes":15}
- {"level":"validation-finding","file":"Init.xaml","remediationCode":"STUB_ACTIVITY_CATALOG_VIOLATION","reason":"Property \"Value\" on Assign must be a child element, not an attribute","classifiedCheck":"CATALOG_STRUCTURAL_VIOLATION","developerAction":"Fix property syntax for activity in Init.xaml — move attribute to child-element or vice versa per UiPath catalog","estimatedEffortMinutes":15}
- {"level":"validation-finding","file":"Init.xaml","remediationCode":"STUB_ACTIVITY_CATALOG_VIOLATION","reason":"Property \"Exception\" on Throw must be a child element, not an attribute","classifiedCheck":"CATALOG_STRUCTURAL_VIOLATION","developerAction":"Fix property syntax for activity in Init.xaml — move attribute to child-element or vice versa per UiPath catalog","estimatedEffortMinutes":15}
- {"level":"validation-finding","file":"RetryCurrentTransaction.xaml","remediationCode":"STUB_ACTIVITY_CATALOG_VIOLATION","reason":"Property \"To\" on Assign must be a child element, not an attribute","classifiedCheck":"CATALOG_STRUCTURAL_VIOLATION","developerAction":"Fix property syntax for activity in RetryCurrentTransaction.xaml — move attribute to child-element or vice versa per UiPath catalog","estimatedEffortMinutes":15}
- {"level":"validation-finding","file":"RetryCurrentTransaction.xaml","remediationCode":"STUB_ACTIVITY_CATALOG_VIOLATION","reason":"Property \"Value\" on Assign must be a child element, not an attribute","classifiedCheck":"CATALOG_STRUCTURAL_VIOLATION","developerAction":"Fix property syntax for activity in RetryCurrentTransaction.xaml — move attribute to child-element or vice versa per UiPath catalog","estimatedEffortMinutes":15}
- {"level":"validation-finding","file":"RetryInit.xaml","remediationCode":"STUB_ACTIVITY_CATALOG_VIOLATION","reason":"Property \"To\" on Assign must be a child element, not an attribute","classifiedCheck":"CATALOG_STRUCTURAL_VIOLATION","developerAction":"Fix property syntax for activity in RetryInit.xaml — move attribute to child-element or vice versa per UiPath catalog","estimatedEffortMinutes":15}
- {"level":"validation-finding","file":"RetryInit.xaml","remediationCode":"STUB_ACTIVITY_CATALOG_VIOLATION","reason":"Property \"Value\" on Assign must be a child element, not an attribute","classifiedCheck":"CATALOG_STRUCTURAL_VIOLATION","developerAction":"Fix property syntax for activity in RetryInit.xaml — move attribute to child-element or vice versa per UiPath catalog","estimatedEffortMinutes":15}
- {"level":"workflow","file":"BGYY_Main.xaml","remediationCode":"STUB_WORKFLOW_BLOCKING","reason":"Final validation: XAML well-formedness violations — replaced with stub. Details: [xml-wellformedness] XML parse error at line 863, col 150 (code: InvalidChar): char '&' is not expected.","classifiedCheck":"xml-wellformedness","developerAction":"Fix XML structure in BGYY_Main.xaml — [xml-wellformedness] XML parse error at line 863, col 150 (code: InvalidChar): char '&' is not expected.","estimatedEffortMinutes":15}
- {"level":"activity","file":"BGYY_Main.xaml","remediationCode":"UNDECLARED_VARIABLE_MANUAL","reason":"Undeclared variable \"str_AssetValue\" — type cannot be auto-inferred (no recognized naming prefix)","classifiedCheck":"UNDECLARED_VARIABLE","developerAction":"Declare variable \"str_AssetValue\" in BGYY_Main.xaml with the appropriate type. Expression context: Line 330: variable \"str_AssetValue\" is used in expression but not declared in this workflow","estimatedEffortMinutes":5,"inferredType":"x:String"}
- {"level":"activity","file":"BGYY_Main.xaml","remediationCode":"UNDECLARED_VARIABLE_MANUAL","reason":"Undeclared variable \"BGYY_Main\" — type cannot be auto-inferred (no recognized naming prefix)","classifiedCheck":"UNDECLARED_VARIABLE","developerAction":"Declare variable \"BGYY_Main\" in BGYY_Main.xaml with the appropriate type. Expression context: BGYY_Main &amp; &quot; Workflow started. Initializing run.&q...","estimatedEffortMinutes":5}
- {"level":"activity","file":"BGYY_Main.xaml","remediationCode":"UNDECLARED_VARIABLE_MANUAL","reason":"Undeclared variable \"str_AssetValue\" — type cannot be auto-inferred (no recognized naming prefix)","classifiedCheck":"UNDECLARED_VARIABLE","developerAction":"Declare variable \"str_AssetValue\" in BGYY_Main.xaml with the appropriate type. Expression context: str_AssetValue","estimatedEffortMinutes":5,"inferredType":"x:String"}
- {"level":"activity","file":"BGYY_Main.xaml","remediationCode":"UNDECLARED_VARIABLE_MANUAL","reason":"Undeclared variable \"vb_expression\" — type cannot be auto-inferred (no recognized naming prefix)","classifiedCheck":"UNDECLARED_VARIABLE","developerAction":"Declare variable \"vb_expression\" in BGYY_Main.xaml with the appropriate type. Expression context: vb_expression","estimatedEffortMinutes":5}
- {"level":"activity","file":"","remediationCode":"POST_ASSEMBLY_REPAIR","reason":"[MISSING_REQUIRED_PROPERTY_DEFECT] ui:BuildDataTable.TableInfo has no valid source binding and no contract-valid fallback — structured defect, property left absent","classifiedCheck":"post-assembly-repair","developerAction":"ui:BuildDataTable.TableInfo has no valid source binding and no contract-valid fallback — structured defect, property left absent","estimatedEffortMinutes":5}
- {"level":"activity","file":"","remediationCode":"POST_ASSEMBLY_REPAIR","reason":"[MISSING_REQUIRED_PROPERTY_DEFECT] uexcel:ExcelApplicationScope.ExistingWorkbook has no valid source binding and no contract-valid fallback — structured defect, property left absent","classifiedCheck":"post-assembly-repair","developerAction":"uexcel:ExcelApplicationScope.ExistingWorkbook has no valid source binding and no contract-valid fallback — structured defect, property left absent","estimatedEffortMinutes":5}
- {"level":"workflow","file":"BGYY_GenerateDraft.xaml","remediationCode":"STUB_WORKFLOW_BLOCKING","reason":"Pre-archive assertion: malformed_attribute_quoting — Malformed attribute quoting detected: Message=\"[&quot;logMessage&quot;]","classifiedCheck":"pre-archive-canonicalization","developerAction":"Resolve malformed_attribute_quoting in BGYY_GenerateDraft.xaml","estimatedEffortMinutes":10}
- {"level":"workflow","file":"InitAllSettings.xaml","remediationCode":"STUB_WORKFLOW_BLOCKING","reason":"Pre-archive assertion: malformed_attribute_quoting — Malformed attribute quoting detected: AssetName=\"[&quot;BGYY_DryRun&quot;]","classifiedCheck":"pre-archive-canonicalization","developerAction":"Resolve malformed_attribute_quoting in InitAllSettings.xaml","estimatedEffortMinutes":10}

## Auto-Repairs

- {"repairCode":"REPAIR_PLACEHOLDER_CLEANUP","file":"BGYY_GetTodaysBirthdays.xaml","description":"Stripped 3 placeholder token(s) from BGYY_GetTodaysBirthdays.xaml","developerAction":"Review BGYY_GetTodaysBirthdays.xaml for Comment elements marking where placeholder activities were removed","estimatedEffortMinutes":5}
- {"repairCode":"REPAIR_PLACEHOLDER_CLEANUP","file":"BGYY_ResolveRecipient.xaml","description":"Stripped 5 placeholder token(s) from BGYY_ResolveRecipient.xaml","developerAction":"Review BGYY_ResolveRecipient.xaml for Comment elements marking where placeholder activities were removed","estimatedEffortMinutes":5}
- {"repairCode":"REPAIR_PLACEHOLDER_CLEANUP","file":"BGYY_GenerateDraft.xaml","description":"Stripped 4 placeholder token(s) from BGYY_GenerateDraft.xaml","developerAction":"Review BGYY_GenerateDraft.xaml for Comment elements marking where placeholder activities were removed","estimatedEffortMinutes":5}
- {"repairCode":"REPAIR_PLACEHOLDER_CLEANUP","file":"BGYY_ValidateDraft.xaml","description":"Stripped 9 placeholder token(s) from BGYY_ValidateDraft.xaml","developerAction":"Review BGYY_ValidateDraft.xaml for Comment elements marking where placeholder activities were removed","estimatedEffortMinutes":5}
- {"repairCode":"REPAIR_PLACEHOLDER_CLEANUP","file":"BGYY_SendGmail.xaml","description":"Stripped 5 placeholder token(s) from BGYY_SendGmail.xaml","developerAction":"Review BGYY_SendGmail.xaml for Comment elements marking where placeholder activities were removed","estimatedEffortMinutes":5}
- {"repairCode":"REPAIR_PLACEHOLDER_CLEANUP","file":"BGYY_WriteSendLog.xaml","description":"Stripped 2 placeholder token(s) from BGYY_WriteSendLog.xaml","developerAction":"Review BGYY_WriteSendLog.xaml for Comment elements marking where placeholder activities were removed","estimatedEffortMinutes":5}
- {"repairCode":"REPAIR_PLACEHOLDER_CLEANUP","file":"BGYY_Main.xaml","description":"Stripped 6 placeholder token(s) from BGYY_Main.xaml","developerAction":"Review BGYY_Main.xaml for Comment elements marking where placeholder activities were removed","estimatedEffortMinutes":5}
- {"repairCode":"REPAIR_PLACEHOLDER_CLEANUP","file":"InitAllApplications.xaml","description":"Stripped 1 placeholder token(s) from InitAllApplications.xaml","developerAction":"Review InitAllApplications.xaml for Comment elements marking where placeholder activities were removed","estimatedEffortMinutes":5}
- {"repairCode":"REPAIR_GENERIC","file":"BGYY_Main.xaml","description":"Catalog (DOM): move-to-child-element ForEach.Values in BGYY_Main.xaml"}
- {"repairCode":"REPAIR_GENERIC","file":"InitAllSettings.xaml","description":"Catalog (DOM): move-to-child-element ForEach.Values in InitAllSettings.xaml"}
- {"repairCode":"REPAIR_GENERIC","file":"InitAllSettings.xaml","description":"Catalog (DOM): move-to-child-element ForEach.Values in InitAllSettings.xaml"}
- {"repairCode":"REPAIR_GENERIC","file":"GetTransactionData.xaml","description":"Catalog (DOM): move-to-child-element ui:GetTransactionItem.QueueName in GetTransactionData.xaml"}
- {"repairCode":"REPAIR_MIXED_EXPRESSION_SYNTAX","file":"BGYY_Main.xaml","description":"Mixed-expression: [BGYY_Main] Workflow started. Initializing run. → [BGYY_Main &amp; &quot; Workflow started. Initializing run.&quot;] in BGYY_Main.xaml"}
- {"repairCode":"REPAIR_TYPE_MISMATCH","file":"BGYY_GenerateDraft.xaml","description":"No known conversion from System.String to UiPath.Platform.ResourceHandling.IResource — review the variable type or activity property"}
- {"repairCode":"REPAIR_TYPE_MISMATCH","file":"BGYY_SendGmail.xaml","description":"No known conversion from System.String to UiPath.Platform.ResourceHandling.IResource — review the variable type or activity property"}
- {"repairCode":"REPAIR_TYPE_MISMATCH","file":"BGYY_WriteSendLog.xaml"}
- {"repairCode":"REPAIR_TYPE_MISMATCH","file":"Main.xaml","description":"No known conversion from scg:Dictionary(x:String, x:Object) to System.Collections.Generic.Dictionary`<System.String, System.Activities.Argument> — review the variable type or activity property"}
- {"repairCode":"REPAIR_TYPE_MISMATCH","file":"Main.xaml","description":"No known conversion from UiPath.Core.QueueItem to System.Collections.Generic.Dictionary`<System.String, System.Activities.Argument> — review the variable type or activity property"}
- {"repairCode":"REPAIR_TYPE_MISMATCH","file":"Init.xaml","description":"No known conversion from scg:Dictionary(x:String, x:Object) to System.Collections.Generic.Dictionary`<System.String, System.Activities.Argument> — review the variable type or activity property"}
