## 1. Automation Architecture Overview

### 1.1 Chosen automation approach (with rationale)
**Pattern:** *Schedule-driven unattended orchestration with deterministic RPA + GenAI drafting + persistent dedupe state*.

**[AUTOMATION_TYPE: Hybrid (Deterministic RPA + UiPath native GenAI)]**

- **Why not “pure RPA”:** drafting a “warm / funny / sarcastic” message in your voice is non-deterministic and benefits from controlled GenAI generation + guardrails.
- **Why not “Agent-only”:** the process is primarily rules-based (calendar query, contact lookup, dedupe, send email). A full agent adds unpredictability and operational risk without clear benefit.
- **Why Hybrid is optimal:** RPA handles the repeatable integrations and business rules; UiPath native GenAI is invoked only for message generation and (optionally) self-checking.

### 1.2 Execution model and topology
- **Execution:** 100% **unattended** (11 unattended slots available). No human participation is required for normal flow.
- **Triggering:** **Orchestrator time trigger** daily at **08:00 America/New_York**.
- **Robot type:** background execution (no UI dependency). Prefer Integration Service activities over UI automation.

### 1.3 Platform services used (and why)
- **Orchestrator:** schedules, assets, logging, job control, alerts via failed jobs, and artifact deployment.
- **Integration Service:** for Google integrations and Gmail send using the existing connection **“ninemush@gmail.com”** (no custom HTTP).
- **Data Service:** persistent dedupe (“one email per person per year”), plus optional “voice profile” storage.
- **Storage Buckets:** store prompt templates, safe phrase lists, and run artifacts (e.g., generated drafts JSON) for audit/traceability.
- **Action Center (exceptional only):** used only if governance requires human approval for flagged drafts (content safety) or ambiguous contact match. Default is fully autonomous.
- **Test Manager:** automated regression suite to validate dedupe, email selection rules, and timezone boundaries.

### 1.4 Orchestrator queues vs Data Service vs Maestro (trade-offs)
- **Dedupe state:** **Data Service** is the right fit (queryable by PersonKey + Year, easy upsert, schema-driven, cross-run persistence).  
  - **Why not Orchestrator Queue:** queues are great for work distribution, but dedupe is not “work items”; you’d still need durable lookup keys and query patterns that Data Service provides more naturally.
- **Process orchestration:** **Orchestrator trigger** is sufficient (single daily run, limited branching).  
  - **Why not Maestro:** Maestro is best when there’s a multi-step case lifecycle with multiple human/service tasks and SLAs as first-class constructs. Here, HITL is exceptional; using Maestro would be heavier than needed.

### 1.5 Monitoring, SLA adherence, and operability
- **SLA target:** emails sent by **08:05 America/New_York** (assuming typical small volume of birthdays/day).
- **Operational telemetry:**
  - Orchestrator job status + logs (info/warn/error).
  - Data Service records: Sent, SkippedNoEmail, SkippedDedupe, PendingReview.
  - Storage Bucket run artifact per execution (summary JSON).
- **Alerting approach:** failed job = Orchestrator alert; business anomalies (e.g., Calendar connector failure, no access, repeated skips) logged as warnings and optionally create an Action Center task “Operational Attention Required”.

---

## 2. Process Components and Workflow Breakdown

### 2.1 Solution components (deployed artifacts)
**Process name (unique):** `BirthdayGreetingsYY`  
**Folder structure (recommended):** `YY / BirthdayGreetings`

**Workflows (REFramework-inspired but lightweight):**
1. `BGYY_Main.xaml` (Orchestrator entrypoint)
2. `BGYY_GetTodaysBirthdays.xaml` (Calendar read + normalization)
3. `BGYY_ResolveRecipient.xaml` (Contacts lookup + email selection)
4. `BGYY_CheckDedupe.xaml` (Data Service read)
5. `BGYY_GenerateDraft.xaml` (UiPath native GenAI generation)
6. `BGYY_ValidateDraft.xaml` (rules-based safety checks)
7. `BGYY_SendGmail.xaml` (Gmail connector send)
8. `BGYY_WriteDedupe.xaml` (Data Service create)
9. `BGYY_CreateReviewTask.xaml` (Action Center task, exceptional path)
10. `BGYY_WriteRunSummary.xaml` (Storage Bucket artifact)

### 2.2 End-to-end orchestration flow
1. **Trigger** runs daily 8:00 AM **America/New_York**
2. Read today’s birthday event occurrences from Google Calendar **“Birthdays”** (events may be all-day or time-bound).
3. If none: end successfully (no “forgot” scenario).
4. For each event:
   - Extract **FullName** from event title/summary.
   - Resolve contact in Google Contacts; select email:
     - If multiple emails: choose **personal** first, else **home**
     - If no personal/home: **do nothing** for that person (log “SkippedNoEmail”).
   - Dedupe check in Data Service by **PersonKey + Year**; if exists: skip.
   - Generate email draft using **UiPath native GenAI** with your voice settings.
   - Validate draft (no offensive content, no mismatched name, no placeholders).
   - If passes: send via **Gmail connector using “ninemush@gmail.com”**, then write dedupe record.
   - If fails: create **Action Center** review task (exceptional), do not send.

### 2.3 Human-in-the-loop (exception-only) design
**Task catalog:** `BGYY_DraftReview`  
Created only when:
- Contact match is ambiguous (multiple contacts with same name)
- Generated draft fails safety/quality rules
- Gmail send fails after retries but draft is ready (optional)

**Action Center form schema (stored + linked to Data Service):**
- `RunId` (Text, required, read-only)
- `EventId` (Text, required, read-only)
- `FullName` (Text, required, read-only)
- `SelectedEmail` (Text, required, editable with email regex validation)
- `Subject` (Text, required, editable)
- `DraftBody` (Multiline Text, required, editable)
- `Decision` (Choice: `ApproveSend`, `RejectSkip`, `EditAndSend`, required)
- `ReviewerComments` (Multiline Text, optional)
- `DueBy` (DateTime, read-only)

**SLA configuration**
- Due time: **2 hours** from creation
- Warning: **60 minutes** remaining
- Escalation: create second task `BGYY_OperationalAttention` (or reassign) if breached (implementation depends on Action Center capabilities in tenant; if not supported, log + mark status “PendingOverdue” in Data Service)

> Note: This does not violate “fully autonomous” for normal operation; it is a safety net for edge cases.

---

## 3. UiPath Activities and Packages Required

### 3.1 Verified packages (exact versions)
- **UiPath.System.Activities 26.2.4**
- **UiPath.UIAutomation.Activities 25.10.29** (used only for *Take Screenshot* on error; no UI automation required otherwise)

### 3.2 Packages required but version not verified (not in verified catalog)
These are necessary to meet requirements but are not present in the provided verified list:
- **UiPath.IntegrationService.Activities** — version not verified (not in verified catalog)  
  (required to use Integration Service connectors for Gmail / Google Calendar / Google Contacts)
- **UiPath.Persistence.Activities** — version not verified (not in verified catalog)  
  (required for Action Center tasks)
- **UiPath.DataService.Activities** (or equivalent Data Service activity pack) — version not verified (not in verified catalog)
- **UiPath.GenAI.Activities / UiPath GenAI Activities** — version not verified (not in verified catalog)  
  (must use **UiPath native GenAI**, and tenant has Integration Service connection “UiPath GenAI Activities”)

### 3.3 Key activities by component (high-level)
- Orchestrator assets/config: `Get Asset`, `Get Credential` (if applicable)
- Calendar retrieval: Integration Service activity “List Events / Get Events” (Google Calendar connector)
- Contacts lookup: Integration Service activity “Search Contacts / List Contacts” (Google Contacts/People connector)
- Data Service: `Get Entity Records`, `Create Entity Record`, `Update Entity Record`
- GenAI: `Generate Text` / `Invoke GenAI` (UiPath native)
- Gmail: Integration Service `Send Email` (Gmail connector via connection “ninemush@gmail.com”)
- Action Center: `Create Form Task`, `Wait for Form Task and Resume` (optional path)
- Error evidence: `Take Screenshot` (UiPath.UIAutomation.Activities 25.10.29) + write to Storage Bucket

---

## 4. Integration Points and API/System Connections

### 4.1 Integration Service connectors (mandated: no custom HTTP)
1. **Gmail**
   - **Connection name:** `ninemush@gmail.com`
   - **Connection ID:** `0a0d5ee1-a1e8-477a-a943-58161e6f3272`
   - **Used for:** send email; optionally retrieve sent message id if connector returns it
2. **Google Calendar**
   - **Connector/connection:** *to be confirmed in Integration Service tenant*  
   - **Used for:** list event occurrences for “today” in **America/New_York**, calendar name **“Birthdays”**
3. **Google Contacts / People**
   - **Connector/connection:** *to be confirmed in Integration Service tenant*  
   - **Used for:** lookup by full name; fetch labeled emails; choose personal > home

> If Calendar/Contacts connectors are not available in Integration Service, the fallback is **UiPath Google Workspace activities** (still no custom HTTP). This will be confirmed during build; design assumes Integration Service first.

### 4.2 UiPath native services
- **Data Service:** entities defined in Section 8 (dedupe + optional voice profile)
- **Storage Buckets:** store:
  - `prompt_templates/voice_prompt.txt`
  - `guardrails/banned_phrases.txt`
  - `runs/<RunId>/summary.json`
  - `runs/<RunId>/drafts/<FullName>.json`
  - `runs/<RunId>/error/<workflow>_<timestamp>.png`

---

## 5. Exception Handling Strategy

### 5.1 Business exceptions (handled, no retries)
- **No birthdays today:** end success.
- **Contact not found / no personal or home email:** skip; write status `SkippedNoEmail`.
- **Dedupe hit:** skip; write status `SkippedDedupe`.
- **Ambiguous match (multiple contacts):** create Action Center task `BGYY_DraftReview` (optional) or skip if strict autonomy is preferred (configurable).

### 5.2 System exceptions (retries + escalation)
- Connector transient failures (Calendar/Contacts/Gmail): retry policy:
  - 3 attempts with exponential backoff (e.g., 5s, 15s, 45s)
- Persistent failures:
  - Mark run as failed (Orchestrator) + write partial run summary to Storage Bucket
  - If failure occurs after draft generation but before send, store draft in Storage Bucket for recovery

### 5.3 Evidence capture (mandatory best practice)
- Every Try/Catch:
  - **Take Screenshot** before logging the exception (even for API-based flows; screenshot captures runtime desktop state; additionally log request/response safely without PII).
  - Write screenshot to Storage Bucket under `runs/<RunId>/error/`.

### 5.4 Dead-letter handling
- Items that cannot be processed due to repeated system failures are written to Data Service with status:
  - `FailedSystem` + `FailureReason` + `LastAttemptAt`
- A future enhancement can add a small “retry runner” process triggered hourly for failed items.

---

## 6. Security Considerations

- **Connections:** Gmail uses Integration Service connection `ninemush@gmail.com` (OAuth managed by platform).
- **Secrets:** store non-OAuth secrets (if any) in **Orchestrator Assets**; do not hardcode.
- **RBAC:**
  - Separate roles for developers vs operators.
  - Restrict Data Service entity permissions to the automation folder/service account.
- **PII:**
  - Store minimal necessary PII (name, selected email) in Data Service for dedupe.
  - Avoid logging full email body at Info level; store drafts in Storage Bucket with restricted access if needed for audit.
- **Auditability:** Data Service + Orchestrator logs + Storage Bucket run artifacts provide traceability of what was sent and when.

---

## 7. Test Strategy (Test Manager)

### 7.1 Test levels
- **Unit tests (workflow-level):**
  - Email selection logic: personal preferred over home
  - “Today” time window calculation in America/New_York (DST boundary tests)
  - Dedupe key generation consistency
- **Integration tests:**
  - Calendar read returns correct occurrences (all-day and timed)
  - Contacts lookup returns correct labeled emails
  - Gmail send succeeds and returns message id (if supported)
- **Regression suite (Test Manager):**
  - Test set executed before promotion to prod or after connector updates

### 7.2 Test data strategy
- Dedicated test calendar (e.g., “Birthdays_TEST”) and test contacts (or a controlled subset) to avoid emailing real recipients during testing.
- Mock mode via Orchestrator Asset `BGYY_DryRun` (true = generate drafts and write artifacts, do not send).

---

## 7a. Governance Compliance
Automation Ops is not enabled, so enforce governance by design:
- Naming conventions: `BGYY_*` prefixes for workflows/assets/entities.
- No custom HTTP usage for Google/Gmail (Integration Service only).
- Mandatory Try/Catch with screenshot + structured logs.
- Minimal PII retention and controlled access to Storage Bucket artifacts.

---

## 8. Data Model and Entity Design (Data Service)

### 8.1 Entity: `BGYY_BirthdaySendLog` (dedupe + audit)
**Purpose:** enforce *one email per person per year* across reruns and provide audit trail.

Fields:
- `Id` (Auto)
- `PersonName` (Text, required)
- `PersonKey` (Text, required, indexed)  
  - Suggested: normalized lowercase name (trim, collapse spaces). Optionally include selected email once known to reduce collisions.
- `SelectedEmail` (Text, required)
- `SendYear` (Number, required, indexed)
- `CalendarEventId` (Text, optional)
- `CalendarOccurrenceStart` (DateTime, optional)
- `GmailMessageId` (Text, optional)
- `SentTimestamp` (DateTime, optional)
- `Status` (Choice, required): `Sent`, `SkippedNoEmail`, `SkippedDedupe`, `PendingReview`, `FailedSystem`
- `FailureReason` (Text, optional)
- `RunId` (Text, required)
- `CreatedAt` (DateTime, auto)
- `UpdatedAt` (DateTime, auto)

Uniqueness rule (logical):
- Unique combination: `PersonKey + SendYear` (enforced in workflow; if Data Service supports unique constraints in tenant, configure it there as well).

### 8.2 Entity: `BGYY_VoiceProfile` (optional but recommended)
**Purpose:** stable “voice grounding” without external services.

Fields:
- `Id` (Auto)
- `ProfileName` (Text, required) e.g., `Default`
- `ToneTags` (Text, required) e.g., `warm,friendly,funny,sarcastic`
- `DoList` (Multiline Text, optional) (e.g., “keep it short”, “no profanity”)
- `DontList` (Multiline Text, optional)
- `ExampleSnippets` (Multiline Text, optional) (pasted prior emails)
- `SubjectTemplate` (Text, optional)
- `SignatureBlock` (Multiline Text, optional)
- `LastUpdated` (DateTime)

### 8.3 Entity: `BGYY_RunSummary` (optional)
Fields:
- `Id` (Auto)
- `RunId` (Text, required, indexed)
- `RunDate` (Date, required)
- `Timezone` (Text, required)
- `TotalEvents` (Number, required)
- `SentCount` (Number, required)
- `SkippedNoEmailCount` (Number, required)
- `SkippedDedupeCount` (Number, required)
- `PendingReviewCount` (Number, required)
- `FailedCount` (Number, required)
- `ArtifactPath` (Text, optional) (Storage Bucket location)

---

## 8. Agent Architecture

### 8.1 Agent usage decision
Because **Agents availability is detected with limited confidence**, the design treats Agents as **optional enhancement**, not critical path.

**Primary design:** GenAI drafting via UiPath GenAI Activities (deterministic invocation inside workflow).  
**Optional enhancement:** an **Autonomous Agent** for richer drafting + self-critique if Agents is confirmed enabled.

### 8.2 Optional Agent definition (if enabled)
- **Agent Type:** Autonomous
- **Agent Identity:** `BGYY_MessageComposerAgent`
- **Purpose:** produce subject + body in your “warm, funny, sarcastic” voice with strict guardrails.
- **System prompt (behavioral):**
  - “Write a short birthday email in a warm, funny, lightly sarcastic voice. No profanity. No sensitive personal data. Must include the recipient name exactly as provided. Avoid mentioning age unless provided. Output JSON with Subject and Body.”
- **Tools (mapped to Orchestrator processes):**
  1. Tool: `GetVoiceProfile`
     - Maps to process: `BirthdayGreetingsYY_GetVoiceProfile` (sub-process) *(to be created if agent is enabled)*
     - Input: `{ "ProfileName": "Default" }`
     - Output: `{ "ToneTags": "...", "ExampleSnippets": "...", "DontList": "..." }`
  2. Tool: `WriteDraftArtifact`
     - Maps to process: `BirthdayGreetingsYY_WriteDraftArtifact`
     - Input: `{ "RunId": "...", "FullName": "...", "DraftJson": "..." }`
     - Output: `{ "Path": "..." }`
- **Context grounding strategy:**
  - Source: Data Service `BGYY_VoiceProfile` + Storage Bucket prompt templates
  - Refresh cadence: each run loads latest profile; no embeddings required for v1
- **Escalation rules:**
  - If output is not valid JSON, missing name, or violates banned phrases → create Action Center task `BGYY_DraftReview`
- **Guardrails:**
  - Max 1 generation + 1 self-rewrite attempt
  - Hard length limits (e.g., 80–150 words)
  - PII: do not add facts beyond provided name and “birthday”
- **Interaction flow:**
  - RPA process calls agent → receives `{subject, body}` → runs validation → sends Gmail → writes dedupe

---

## Platform Recommendations (capabilities not available)
1. **Automation Ops (Governance):** would enforce policies (no disallowed activities, mandatory Try/Catch templates, logging standards) automatically across the project.
2. **Autopilot:** could accelerate iterative prompt tuning and generate test cases; not required for runtime.
3. **Environments feature:** not accessible; once enabled it can simplify separation of dev/test/prod runtime configs.
4. **Apps external API:** not required; if Apps API were available, a lightweight “Birthday Greetings Dashboard” could be provisioned programmatically (review queue, stats, voice profile editing).

## 9. Orchestrator & Platform Deployment Specification

```orchestrator_artifacts
{
  "processes": [
    {
      "name": "BirthdayGreetingsYY",
      "folder": "YY / BirthdayGreetings",
      "entrypoint": "BGYY_Main.xaml",
      "description": "Schedule-driven unattended process to send birthday greetings via Gmail with Data Service dedupe and optional Action Center review."
    }
  ],
  "folders": [
    {
      "name": "YY / BirthdayGreetings",
      "description": "Recommended folder structure for BirthdayGreetingsYY automation artifacts."
    }
  ],
  "queues": [],
  "assets": [
    {
      "name": "BGYY_DryRun",
      "type": "Bool",
      "value": "",
      "description": "Mock mode. true = generate drafts and write artifacts, do not send emails."
    }
  ],
  "machines": [
    {
      "name": "BirthdayGreetingsYY_Unattended",
      "type": "Unattended",
      "slots": 11,
      "description": "Unattended execution capacity for the solution (11 unattended slots available)."
    }
  ],
  "triggers": [
    {
      "name": "BGYY_Daily_0800_ET",
      "type": "Time",
      "queueName": "",
      "cron": "0 8 * * *",
      "timezone": "America/New_York",
      "processName": "BirthdayGreetingsYY",
      "description": "Daily time trigger to start the process at 08:00 America/New_York."
    }
  ],
  "storageBuckets": [
    {
      "name": "BGYY_RunArtifacts",
      "description": "Stores prompt templates, guardrails lists, and per-run artifacts for audit/traceability (summaries, drafts, error screenshots).",
      "paths": [
        "prompt_templates/voice_prompt.txt",
        "guardrails/banned_phrases.txt",
        "runs/<RunId>/summary.json",
        "runs/<RunId>/drafts/<FullName>.json",
        "runs/<RunId>/error/<workflow>_<timestamp>.png"
      ]
    }
  ],
  "environments": [],
  "actionCenter": [
    {
      "taskCatalog": "BGYY_DraftReview",
      "assignedRole": "",
      "sla": "2 hours",
      "escalation": "Warning at 60 minutes remaining. If breached, create second task BGYY_OperationalAttention (or reassign); if not supported, log and mark Data Service status PendingOverdue.",
      "description": "Exceptional human review for flagged drafts, ambiguous contact matches, or post-draft send failures."
    },
    {
      "taskCatalog": "BGYY_OperationalAttention",
      "assignedRole": "",
      "sla": "",
      "escalation": "",
      "description": "Escalation/ops attention task created when DraftReview breaches SLA or business anomalies require intervention."
    }
  ],
  "documentUnderstanding": [],
  "communicationsMining": [],
  "dataService": [
    {
      "name": "BGYY_BirthdaySendLog",
      "description": "Dedupe + audit entity enforcing one email per person per year and tracking outcomes.",
      "uniqueConstraints": [
        {
          "fields": [
            "PersonKey",
            "SendYear"
          ],
          "enforcement": "workflow_enforced; configure in Data Service if tenant supports unique constraints"
        }
      ],
      "fields": [
        {
          "name": "Id",
          "type": "Auto"
        },
        {
          "name": "PersonName",
          "type": "Text",
          "required": true
        },
        {
          "name": "PersonKey",
          "type": "Text",
          "required": true,
          "indexed": true
        },
        {
          "name": "SelectedEmail",
          "type": "Text",
          "required": true
        },
        {
          "name": "SendYear",
          "type": "Number",
          "required": true,
          "indexed": true
        },
        {
          "name": "CalendarEventId",
          "type": "Text",
          "required": false
        },
        {
          "name": "CalendarOccurrenceStart",
          "type": "DateTime",
          "required": false
        },
        {
          "name": "GmailMessageId",
          "type": "Text",
          "required": false
        },
        {
          "name": "SentTimestamp",
          "type": "DateTime",
          "required": false
        },
        {
          "name": "Status",
          "type": "Choice",
          "required": true,
          "choices": [
            "Sent",
            "SkippedNoEmail",
            "SkippedDedupe",
            "PendingReview",
            "FailedSystem"
          ]
        },
        {
          "name": "FailureReason",
          "type": "Text",
          "required": false
        },
        {
          "name": "RunId",
          "type": "Text",
          "required": true
        },
        {
          "name": "CreatedAt",
          "type": "DateTime",
          "auto": true
        },
        {
          "name": "UpdatedAt",
          "type": "DateTime",
          "auto": true
        }
      ]
    },
    {
      "name": "BGYY_VoiceProfile",
      "description": "Optional entity to store stable voice grounding configuration for GenAI drafting.",
      "fields": [
        {
          "name": "Id",
          "type": "Auto"
        },
        {
          "name": "ProfileName",
          "type": "Text",
          "required": true
        },
        {
          "name": "ToneTags",
          "type": "Text",
          "required": true
        },
        {
          "name": "DoList",
          "type": "MultilineText",
          "required": false
        },
        {
          "name": "DontList",
          "type": "MultilineText",
          "required": false
        },
        {
          "name": "ExampleSnippets",
          "type": "MultilineText",
          "required": false
        },
        {
          "name": "SubjectTemplate",
          "type": "Text",
          "required": false
        },
        {
          "name": "SignatureBlock",
          "type": "MultilineText",
          "required": false
        },
        {
          "name": "LastUpdated",
          "type": "DateTime",
          "required": false
        }
      ]
    },
    {
      "name": "BGYY_RunSummary",
      "description": "Optional entity to persist per-run KPIs and pointer to Storage Bucket artifacts.",
      "fields": [
        {
          "name": "Id",
          "type": "Auto"
        },
        {
          "name": "RunId",
          "type": "Text",
          "required": true,
          "indexed": true
        },
        {
          "name": "RunDate",
          "type": "Date",
          "required": true
        },
        {
          "name": "Timezone",
          "type": "Text",
          "required": true
        },
        {
          "name": "TotalEvents",
          "type": "Number",
          "required": true
        },
        {
          "name": "SentCount",
          "type": "Number",
          "required": true
        },
        {
          "name": "SkippedNoEmailCount",
          "type": "Number",
          "required": true
        },
        {
          "name": "SkippedDedupeCount",
          "type": "Number",
          "required": true
        },
        {
          "name": "PendingReviewCount",
          "type": "Number",
          "required": true
        },
        {
          "name": "FailedCount",
          "type": "Number",
          "required": true
        },
        {
          "name": "ArtifactPath",
          "type": "Text",
          "required": false
        }
      ]
    }
  ],
  "integrationService": [
    {
      "connector": "Gmail",
      "connectionName": "ninemush@gmail.com",
      "connectionId": "0a0d5ee1-a1e8-477a-a943-58161e6f3272",
      "description": "Used to send birthday greeting emails; optionally retrieve sent message id if supported by connector."
    },
    {
      "connector": "Google Calendar",
      "connectionName": "",
      "connectionId": "",
      "description": "List today's event occurrences in America/New_York from calendar named 'Birthdays' (connection to be confirmed in tenant)."
    },
    {
      "connector": "Google Contacts / People",
      "connectionName": "",
      "connectionId": "",
      "description": "Lookup contacts by full name and retrieve labeled emails; choose personal > home (connection to be confirmed in tenant)."
    }
  ],
  "testManager": [
    {
      "name": "BGYY_RegressionSuite",
      "description": "Automated regression suite to validate dedupe, email selection rules, and timezone boundaries before promotion or after connector updates."
    }
  ],
  "requirements": [],
  "testCases": [],
  "testSets": [],
  "agents": [
    {
      "name": "BGYY_MessageComposerAgent",
      "type": "Autonomous",
      "description": "Optional enhancement if Agents is enabled; drafts subject+body with guardrails and escalates to DraftReview on violations.",
      "tools": [
        {
          "name": "GetVoiceProfile",
          "mapsToProcess": "BirthdayGreetingsYY_GetVoiceProfile",
          "description": "Loads the latest voice profile grounding data from Data Service."
        },
        {
          "name": "WriteDraftArtifact",
          "mapsToProcess": "BirthdayGreetingsYY_WriteDraftArtifact",
          "description": "Writes draft JSON artifact to Storage Bucket and returns the path."
        }
      ],
      "actionCenterEscalationTaskCatalog": "BGYY_DraftReview"
    }
  ]
}
```