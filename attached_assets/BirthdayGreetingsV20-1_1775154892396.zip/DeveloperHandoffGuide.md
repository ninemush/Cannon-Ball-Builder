# Developer Handoff Guide

**Project:** BirthdayGreetingsV20
**Generated:** 2026-04-02
**Generation Mode:** Baseline Openable (minimal, deterministic)
**Deployment Readiness:** Not Ready (19%)

**13 workflows: 3 fully generated, 0 with handoff blocks, 10 workflow-level stubs**
**Total Estimated Effort: ~150 minutes (2.5 hours)**
**Remediations:** 10 total (0 property, 0 activity, 0 sequence, 0 structural-leaf, 6 workflow)
**Auto-Repairs:** 7
**Quality Warnings:** 82

---

### Per-Workflow Preservation Summary

| # | Workflow | Tier | Business Steps (SDD) | Preserved | Degraded (Handoff) | Manual | Bind Points |
|---|----------|------|-------------|-----------|-------------------|--------|-------------|
| 1 | `Main.xaml` | Stub | 1 | 0 | 0 | 1 | 0 |
| 2 | `ReadCalendarEvents.xaml` | Stub | 1 | 0 | 0 | 1 | 0 |
| 3 | `DispatchBirthdayQueue.xaml` | Generated | 1 | 1 | 0 | 0 | 0 |
| 4 | `PerformerMain.xaml` | Generated | 1 | 1 | 0 | 0 | 0 |
| 5 | `ProcessBirthdayTransaction.xaml` | Stub | 1 | 0 | 0 | 1 | 0 |
| 6 | `ResolveRecipientEmail.xaml` | Stub | 1 | 0 | 0 | 1 | 0 |
| 7 | `GenerateBirthdayMessage.xaml` | Stub | 1 | 0 | 0 | 1 | 0 |
| 8 | `InitAllSettings.xaml` | Stub | 1 | 0 | 0 | 1 | 0 |
| 9 | `ReadCalendarEvents.xaml` | Stub | 1 | 0 | 0 | 1 | 0 |
| 10 | `DispatchBirthdayQueue.xaml` | Generated | 1 | 1 | 0 | 0 | 0 |
| 11 | `ProcessBirthdayTransaction.xaml` | Stub | 1 | 0 | 0 | 1 | 0 |
| 12 | `ResolveRecipientEmail.xaml` | Stub | 1 | 0 | 0 | 1 | 0 |
| 13 | `GenerateBirthdayMessage.xaml` | Stub | 1 | 0 | 0 | 1 | 0 |

## 1. Generated Logic (ready to use)

Generated XAML that is Studio-openable and does not contain handoff blocks or workflow-level stubs. May include auto-resolved property remediations or placeholders for fine-tuning.

The following 3 workflow(s) were fully generated and are ready to use:

| # | Workflow | Status | Studio Compatibility |
|---|----------|--------|---------------------|
| 1 | `DispatchBirthdayQueue.xaml` | Generated with Placeholders | Studio-openable |
| 2 | `PerformerMain.xaml` | Fully Generated | Openable with warnings |
| 3 | `DispatchBirthdayQueue.xaml` | Generated with Placeholders | Studio-openable |

### AI-Resolved with Smart Defaults (7)

The following issue(s) were automatically corrected during the build pipeline. **No developer action required.**

| # | Code | File | Description | Est. Minutes Saved |
|---|------|------|-------------|-------------------|
| 1 | `REPAIR_GENERIC` | `Main.xaml` | Catalog (fallback): Moved ui:GetAsset.Value from attribute to child-element in Main.xaml | undefined |
| 2 | `REPAIR_GENERIC` | `Main.xaml` | Catalog (fallback): Moved ui:GetAsset.Value from attribute to child-element in Main.xaml | undefined |
| 3 | `REPAIR_GENERIC` | `Main.xaml` | Catalog (fallback): Moved ui:GetAsset.Value from attribute to child-element in Main.xaml | undefined |
| 4 | `REPAIR_GENERIC` | `Main.xaml` | Catalog (fallback): Moved ui:GetAsset.Value from attribute to child-element in Main.xaml | undefined |
| 5 | `REPAIR_GENERIC` | `Main.xaml` | Catalog (fallback): Moved uds:CreateEntity.EntityObject from attribute to child-element in Main.xaml | undefined |
| 6 | `REPAIR_GENERIC` | `Main.xaml` | Catalog (fallback): Moved uds:CreateEntity.Result from attribute to child-element in Main.xaml | undefined |
| 7 | `REPAIR_GENERIC` | `Main.xaml` | Catalog (fallback): Moved Throw.Exception from attribute to child-element in Main.xaml | undefined |

### Studio Compatibility

| # | Workflow | Compatibility | Failure Category | Blockers |
|---|----------|--------------|-----------------|----------|
| 1 | `Main.xaml` | Openable with warnings | Unclassified | — |
| 2 | `ReadCalendarEvents.xaml` | Openable with warnings | Unclassified | — |
| 3 | `DispatchBirthdayQueue.xaml` | Studio-openable | — | — |
| 4 | `PerformerMain.xaml` | Openable with warnings | Unclassified | — |
| 5 | `ProcessBirthdayTransaction.xaml` | Openable with warnings | Unclassified | — |
| 6 | `ResolveRecipientEmail.xaml` | Openable with warnings | Unclassified | — |
| 7 | `GenerateBirthdayMessage.xaml` | Openable with warnings | Unclassified | — |
| 8 | `InitAllSettings.xaml` | Studio-openable | — | — |
| 9 | `ReadCalendarEvents` | Openable with warnings | Unclassified | — |
| 10 | `DispatchBirthdayQueue` | Openable with warnings | Unclassified | — |
| 11 | `ProcessBirthdayTransaction` | Openable with warnings | Unclassified | — |
| 12 | `ResolveRecipientEmail` | Openable with warnings | Unclassified | — |
| 13 | `GenerateBirthdayMessage` | Openable with warnings | Unclassified | — |

**Summary:** 2 Studio-loadable, 11 with warnings, 0 not Studio-loadable

## 2. Handoff Blocks (business logic preserved, implementation required)

Blocks where business logic is preserved as documentation but implementation requires manual Studio work. Each entry includes the workflow file, block type, business description from the SDD (when available), expected inputs/outputs, and the developer action required.

No handoff blocks — all logic was fully generated.

## 3. Manual Work Remaining

Consolidated developer TODO list organized by workflow, with estimated effort per item.

**92 items remaining — ~970 minutes (16.2 hours) total estimated effort**

### GenerateBirthdayMessage.xaml (3 items, ~35 min)

| # | Priority | Category | Description | Developer Action | Est. Minutes |
|---|----------|----------|-------------|-----------------|-------------|
| 1 | High | Workflow Stub | Entire workflow `GenerateBirthdayMessage.xaml` replaced with Studio-openable ... | Fix XML structure in GenerateBirthdayMessage.xaml — ensure proper nesting and... | 15 |
| 2 | Low | Implementation Required | Contains 1 placeholder value(s) matching "\bPLACEHOLDER\b" [Developer Impleme... | Implement in Studio | 10 |
| 3 | Low | Quality Warning | COMPLEX_EXPRESSION_PASSTHROUGH: Line 244: Complex expression (lambdas, LINQ, ... | Review and address | 10 |

### InitAllSettings.xaml (31 items, ~315 min)

| # | Priority | Category | Description | Developer Action | Est. Minutes |
|---|----------|----------|-------------|-----------------|-------------|
| 4 | High | Workflow Stub | Entire workflow `InitAllSettings.xaml` replaced with Studio-openable stub | Fix XML structure in InitAllSettings.xaml — ensure proper nesting and closing... | 15 |
| 5 | Low | Quality Warning | hardcoded-asset-name: Line 100: asset name "BGV20_GoogleOAuth_Credential" is ... | Review and address | 10 |
| 6 | Low | Quality Warning | hardcoded-asset-name: Line 105: asset name "BGV20_GoogleCalendar_Name" is har... | Review and address | 10 |
| 7 | Low | Quality Warning | hardcoded-asset-name: Line 114: asset name "BGV20_Gmail_FromConnectionName" i... | Review and address | 10 |
| 8 | Low | Quality Warning | hardcoded-asset-name: Line 123: asset name "BGV20_RunTimeZone" is hardcoded —... | Review and address | 10 |
| 9 | Low | Quality Warning | hardcoded-asset-name: Line 132: asset name "BGV20_EmailSubjectTemplate" is ha... | Review and address | 10 |
| 10 | Low | Quality Warning | hardcoded-asset-name: Line 141: asset name "BGV20_EmailPreferenceLabels" is h... | Review and address | 10 |
| 11 | Low | Quality Warning | hardcoded-asset-name: Line 150: asset name "BGV20_SkipIfAmbiguousContactMatch... | Review and address | 10 |
| 12 | Low | Quality Warning | hardcoded-asset-name: Line 159: asset name "BGV20_QueueItemDeferMinutes_OnRat... | Review and address | 10 |
| 13 | Low | Quality Warning | hardcoded-asset-name: Line 168: asset name "BGV20_LogMaskEmails" is hardcoded... | Review and address | 10 |
| 14 | Low | Quality Warning | hardcoded-asset-name: Line 177: asset name "BGV20_GenAI_Temperature" is hardc... | Review and address | 10 |
| 15 | Low | Quality Warning | hardcoded-asset-name: Line 186: asset name "BGV20_GenAI_MaxChars" is hardcode... | Review and address | 10 |
| 16 | Low | Quality Warning | hardcoded-asset-name: Line 195: asset name "BGV20_MaxBirthdaysPerRun" is hard... | Review and address | 10 |
| 17 | Low | Quality Warning | hardcoded-asset-name: Line 204: asset name "BGV20_BusinessSLA_SendByLocalTime... | Review and address | 10 |
| 18 | Low | Quality Warning | hardcoded-asset-name: Line 213: asset name "BGV20_OrchestratorFolderName" is ... | Review and address | 10 |
| 19 | Low | Quality Warning | BARE_TOKEN_QUOTED: Auto-quoted bare token "Settings" for uexcel:ExcelReadRang... | Review and address | 10 |
| 20 | Low | Quality Warning | BARE_TOKEN_QUOTED: Auto-quoted bare token "Constants" for uexcel:ExcelReadRan... | Review and address | 10 |
| 21 | Low | Quality Warning | BARE_TOKEN_QUOTED: Auto-quoted bare token "BGV20_GoogleOAuth_Credential" for ... | Review and address | 10 |
| 22 | Low | Quality Warning | BARE_TOKEN_QUOTED: Auto-quoted bare token "BGV20_GoogleCalendar_Name" for ui:... | Review and address | 10 |
| 23 | Low | Quality Warning | BARE_TOKEN_QUOTED: Auto-quoted bare token "BGV20_Gmail_FromConnectionName" fo... | Review and address | 10 |
| 24 | Low | Quality Warning | BARE_TOKEN_QUOTED: Auto-quoted bare token "BGV20_RunTimeZone" for ui:GetAsset... | Review and address | 10 |
| 25 | Low | Quality Warning | BARE_TOKEN_QUOTED: Auto-quoted bare token "BGV20_EmailSubjectTemplate" for ui... | Review and address | 10 |
| 26 | Low | Quality Warning | BARE_TOKEN_QUOTED: Auto-quoted bare token "BGV20_EmailPreferenceLabels" for u... | Review and address | 10 |
| 27 | Low | Quality Warning | BARE_TOKEN_QUOTED: Auto-quoted bare token "BGV20_SkipIfAmbiguousContactMatch"... | Review and address | 10 |
| 28 | Low | Quality Warning | BARE_TOKEN_QUOTED: Auto-quoted bare token "BGV20_QueueItemDeferMinutes_OnRate... | Review and address | 10 |
| 29 | Low | Quality Warning | BARE_TOKEN_QUOTED: Auto-quoted bare token "BGV20_LogMaskEmails" for ui:GetAss... | Review and address | 10 |
| 30 | Low | Quality Warning | BARE_TOKEN_QUOTED: Auto-quoted bare token "BGV20_GenAI_Temperature" for ui:Ge... | Review and address | 10 |
| 31 | Low | Quality Warning | BARE_TOKEN_QUOTED: Auto-quoted bare token "BGV20_GenAI_MaxChars" for ui:GetAs... | Review and address | 10 |
| 32 | Low | Quality Warning | BARE_TOKEN_QUOTED: Auto-quoted bare token "BGV20_MaxBirthdaysPerRun" for ui:G... | Review and address | 10 |
| 33 | Low | Quality Warning | BARE_TOKEN_QUOTED: Auto-quoted bare token "BGV20_BusinessSLA_SendByLocalTime"... | Review and address | 10 |
| 34 | Low | Quality Warning | BARE_TOKEN_QUOTED: Auto-quoted bare token "BGV20_OrchestratorFolderName" for ... | Review and address | 10 |

### Main.xaml (19 items, ~200 min)

| # | Priority | Category | Description | Developer Action | Est. Minutes |
|---|----------|----------|-------------|-----------------|-------------|
| 35 | High | Workflow Stub | Entire workflow `Main.xaml` replaced with Studio-openable stub | Fix XML structure in Main.xaml — ensure proper nesting and closing tags | 15 |
| 36 | Low | Validation Finding | Quality gate finding: `CATALOG_STRUCTURAL_VIOLATION` | Fix property syntax for activity in Main.xaml — move attribute to child-eleme... | 15 |
| 37 | Low | Quality Warning | invalid-activity-property: Line 283: property "in_CalendarName" is not a know... | Review and address | 10 |
| 38 | Low | Quality Warning | invalid-activity-property: Line 283: property "in_RunDate" is not a known pro... | Review and address | 10 |
| 39 | Low | Quality Warning | invalid-activity-property: Line 283: property "in_RunTimeZone" is not a known... | Review and address | 10 |
| 40 | Low | Quality Warning | invalid-activity-property: Line 283: property "in_MaxBirthdaysPerRun" is not ... | Review and address | 10 |
| 41 | Low | Quality Warning | invalid-activity-property: Line 283: property "out_BirthdayPersonsDT" is not ... | Review and address | 10 |
| 42 | Low | Quality Warning | invalid-activity-property: Line 283: property "out_BirthdaysFoundCount" is no... | Review and address | 10 |
| 43 | Low | Quality Warning | invalid-activity-property: Line 339: property "in_BirthdayPersonsDT" is not a... | Review and address | 10 |
| 44 | Low | Quality Warning | invalid-activity-property: Line 339: property "in_RunId" is not a known prope... | Review and address | 10 |
| 45 | Low | Quality Warning | invalid-activity-property: Line 339: property "in_RunDate" is not a known pro... | Review and address | 10 |
| 46 | Low | Quality Warning | invalid-activity-property: Line 339: property "in_RunDateLocal" is not a know... | Review and address | 10 |
| 47 | Low | Quality Warning | invalid-activity-property: Line 339: property "out_QueueItemsEnqueuedCount" i... | Review and address | 10 |
| 48 | Low | Quality Warning | invalid-activity-property: Line 339: property "out_QueueItemsSkippedCount" is... | Review and address | 10 |
| 49 | Low | Quality Warning | hardcoded-asset-name: Line 76: asset name "{&quot;type&quot;:&quot;literal&qu... | Review and address | 10 |
| 50 | Low | Quality Warning | hardcoded-asset-name: Line 115: asset name "{&quot;type&quot;:&quot;literal&q... | Review and address | 10 |
| 51 | Low | Quality Warning | hardcoded-asset-name: Line 154: asset name "{&quot;type&quot;:&quot;literal&q... | Review and address | 10 |
| 52 | Low | Quality Warning | hardcoded-asset-name: Line 197: asset name "{&quot;type&quot;:&quot;literal&q... | Review and address | 10 |
| 53 | Low | Quality Warning | COMPLEX_EXPRESSION_PASSTHROUGH: Line 69: Complex expression (lambdas, LINQ, n... | Review and address | 10 |

### ProcessBirthdayTransaction.xaml (8 items, ~90 min)

| # | Priority | Category | Description | Developer Action | Est. Minutes |
|---|----------|----------|-------------|-----------------|-------------|
| 54 | High | Workflow Stub | Entire workflow `ProcessBirthdayTransaction.xaml` replaced with Studio-openab... | Fix XML structure in ProcessBirthdayTransaction.xaml — ensure proper nesting ... | 15 |
| 55 | Low | Validation Finding | Quality gate finding: `unprefixed-activity` | Manually implement activity in ProcessBirthdayTransaction.xaml — estimated 15... | 15 |
| 56 | Low | Implementation Required | Contains 1 placeholder value(s) matching "\bPLACEHOLDER\b" [Developer Impleme... | Implement in Studio | 10 |
| 57 | Low | Quality Warning | invalid-activity-property: Line 208: property "Arguments" is not a known prop... | Review and address | 10 |
| 58 | Low | Quality Warning | invalid-activity-property: Line 302: property "Arguments" is not a known prop... | Review and address | 10 |
| 59 | Low | Quality Warning | hardcoded-retry-interval: Line 366: retry interval hardcoded as "{&quot;type&... | Review and address | 10 |
| 60 | Low | Quality Warning | hardcoded-asset-name: Line 72: asset name "{&quot;type&quot;:&quot;literal&qu... | Review and address | 10 |
| 61 | Low | Quality Warning | hardcoded-asset-name: Line 111: asset name "{&quot;type&quot;:&quot;literal&q... | Review and address | 10 |

### ReadCalendarEvents.xaml (3 items, ~40 min)

| # | Priority | Category | Description | Developer Action | Est. Minutes |
|---|----------|----------|-------------|-----------------|-------------|
| 62 | High | Workflow Stub | Entire workflow `ReadCalendarEvents.xaml` replaced with Studio-openable stub | Fix XML structure in ReadCalendarEvents.xaml — ensure proper nesting and clos... | 15 |
| 63 | Low | Validation Finding | Quality gate finding: `unprefixed-activity` | Manually implement activity in ReadCalendarEvents.xaml — estimated 15 min | 15 |
| 64 | Low | Implementation Required | Contains 1 placeholder value(s) matching "\bPLACEHOLDER\b" [Developer Impleme... | Implement in Studio | 10 |

### ResolveRecipientEmail.xaml (6 items, ~70 min)

| # | Priority | Category | Description | Developer Action | Est. Minutes |
|---|----------|----------|-------------|-----------------|-------------|
| 65 | High | Workflow Stub | Entire workflow `ResolveRecipientEmail.xaml` replaced with Studio-openable stub | Fix XML structure in ResolveRecipientEmail.xaml — ensure proper nesting and c... | 15 |
| 66 | Low | Validation Finding | Quality gate finding: `unprefixed-activity` | Manually implement activity in ResolveRecipientEmail.xaml — estimated 15 min | 15 |
| 67 | Low | Implementation Required | Contains 2 placeholder value(s) matching "\bPLACEHOLDER\b" [Developer Impleme... | Implement in Studio | 10 |
| 68 | Low | Implementation Required | Contains 1 placeholder value(s) matching "\bPLACEHOLDER\b" [Developer Impleme... | Implement in Studio | 10 |
| 69 | Low | Quality Warning | invalid-activity-property: Line 246: property "Condition" is not a known prop... | Review and address | 10 |
| 70 | Low | Quality Warning | hardcoded-retry-interval: Line 79: retry interval hardcoded as "{&quot;type&q... | Review and address | 10 |

### DispatchBirthdayQueue.xaml (1 item, ~10 min)

| # | Priority | Category | Description | Developer Action | Est. Minutes |
|---|----------|----------|-------------|-----------------|-------------|
| 71 | Low | Implementation Required | Contains 1 placeholder value(s) matching "\bPLACEHOLDER\b" [Developer Impleme... | Implement in Studio | 10 |

### orchestrator.xaml (8 items, ~80 min)

| # | Priority | Category | Description | Developer Action | Est. Minutes |
|---|----------|----------|-------------|-----------------|-------------|
| 72 | Low | Quality Warning | undeclared-asset: Asset "{type:literal,value:BGV20_GoogleCalendar_Name}" is r... | Review and address | 10 |
| 73 | Low | Quality Warning | undeclared-asset: Asset "{type:literal,value:BGV20_RunTimeZone}" is reference... | Review and address | 10 |
| 74 | Low | Quality Warning | undeclared-asset: Asset "{type:literal,value:BGV20_MaxBirthdaysPerRun}" is re... | Review and address | 10 |
| 75 | Low | Quality Warning | undeclared-asset: Asset "{type:literal,value:BGV20_OrchestratorFolderName}" i... | Review and address | 10 |
| 76 | Low | Quality Warning | undeclared-asset: Asset "{type:literal,value:BGV20_QueueItemDeferMinutes_OnRa... | Review and address | 10 |
| 77 | Low | Quality Warning | undeclared-asset: Asset "{type:literal,value:BGV20_LogMaskEmails}" is referen... | Review and address | 10 |
| 78 | Low | Quality Warning | undeclared-asset: Asset "{type:literal,value:BGV20_Gmail_FromConnectionName}"... | Review and address | 10 |
| 79 | Low | Quality Warning | undeclared-asset: Asset "{type:literal,value:BGV20_EmailSubjectTemplate}" is ... | Review and address | 10 |

### PerformerMain.xaml (13 items, ~130 min)

| # | Priority | Category | Description | Developer Action | Est. Minutes |
|---|----------|----------|-------------|-----------------|-------------|
| 80 | Low | Quality Warning | invalid-activity-property: Line 384: property "in_TransactionItem" is not a k... | Review and address | 10 |
| 81 | Low | Quality Warning | invalid-activity-property: Line 384: property "in_FullName" is not a known pr... | Review and address | 10 |
| 82 | Low | Quality Warning | invalid-activity-property: Line 384: property "in_EventId" is not a known pro... | Review and address | 10 |
| 83 | Low | Quality Warning | invalid-activity-property: Line 384: property "in_EventStartDate" is not a kn... | Review and address | 10 |
| 84 | Low | Quality Warning | invalid-activity-property: Line 384: property "in_RunId" is not a known prope... | Review and address | 10 |
| 85 | Low | Quality Warning | invalid-activity-property: Line 384: property "in_LogMaskEmails" is not a kno... | Review and address | 10 |
| 86 | Low | Quality Warning | invalid-activity-property: Line 384: property "out_Outcome" is not a known pr... | Review and address | 10 |
| 87 | Low | Quality Warning | invalid-activity-property: Line 384: property "out_ErrorMessage" is not a kno... | Review and address | 10 |
| 88 | Low | Quality Warning | invalid-activity-property: Line 384: property "out_ErrorType" is not a known ... | Review and address | 10 |
| 89 | Low | Quality Warning | invalid-activity-property: Line 384: property "out_IsBusinessException" is no... | Review and address | 10 |
| 90 | Low | Quality Warning | hardcoded-asset-name: Line 69: asset name "{&quot;type&quot;:&quot;literal&qu... | Review and address | 10 |
| 91 | Low | Quality Warning | hardcoded-asset-name: Line 108: asset name "{&quot;type&quot;:&quot;literal&q... | Review and address | 10 |
| 92 | Low | Quality Warning | hardcoded-asset-name: Line 147: asset name "{&quot;type&quot;:&quot;literal&q... | Review and address | 10 |

## 4. Process Context (from Pipeline)

### Idea Description

Automate birthday greetings to friends and family

### PDD Summary

## 1. Executive Summary
The “birthday greetings V20” project automates the daily routine of checking a dedicated Google Calendar (“Birthdays”) at 8:00 AM and sending personalized birthday greetings from the user’s Gmail account. Today, the user manually reviews the calendar, looks up an email address in Google Contacts, writes a message in a warm, funny, sarcastic voice, and sends an email. Because the activity is manual, birthdays can occasionally be missed. The future-state design uses UiPath Orchestrator scheduling and queue-based processing to run fully autonomously in the background using unattended robots. The automation reads today’s birthday events from the “Birthdays” calendar, determines the correct recipient email from Google Contacts (preferring “Personal/Home” when multiple exist), generates a highly personal message in the user’s voice using UiPath’s native GenAI/Agents capabilities (without OpenAI), and sends exactly one email per person using the Gmail Integration Service connector configured as `ninemush@gmail.com`. If no email is found, the automation will take no action.

## 2. Process Scope
This PDD covers the end-to-end automated process for sending one birthday email per person whose birthday appears on the current day in the Google Calendar named “Birthdays.” The calendar entries contain the person’s full name (no relationship metadata is stored). Recipient email addresses are sourced from Google Contacts and are labeled as “home” or “personal” when present. The automation’s scope includes: daily scheduling, calendar event retrieval, transaction creation (one transaction per birthday person), contacts lookup, selection of the preferred email address when multiple are available, AI-based message generation in the user’s warm/funny/sarcastic voice using UiPath native capabilities, and sending via Gmail Integration Service using connection `ninemush@gmail.com`.

Out of scope for this iteration are: attaching or selecting photos (e.g., from Google...

### SDD Summary

## 1. Automation Architecture Overview

### 1.1 Chosen automation pattern and rationale
**Pattern:** **Queue-driven fan-out with Dispatcher/Performer** (REFramework-style transaction handling, modernized for integration activities).

**Why this pattern fits:**
- **One email per person** is naturally modeled as **one queue item per birthday person**.
- Provides **transaction-level traceability**, retries, and isolation of failures (one bad contact does not stop all greetings).
- Scales horizontally if multiple birthdays exist (11 unattended slots available).

### 1.2 Automation type selection (RPA vs Agent vs Hybrid)
**Automation type:** **Hybrid (Deterministic RPA + GenAI/Agent)**  
- Deterministic steps (schedule, calendar read, queue, contacts lookup, email send) are best as **unattended RPA** for reliability and auditability.
- Message drafting in a “warm, funny, sarcastic voice” benefits from **UiPath-native GenAI** (Agents / GenAI Activities) to generate natural language while staying on-platform and avoiding OpenAI/Azure OpenAI connectors.

**No Human-in-the-Loop**: The PDD explicitly requires fully autonomous execution and “if no email is found, don’t do anything.” Therefore:
- **Action Center is not in the critical path** and no approval/review tasks are created.
- Action Center will be used only for **optional operational escalation** (non-blocking) if platform operations request it; by default it’s disabled.

### 1.3 Platform services used and why
- **Orchestrator**: schedules 8:00 AM run, manages assets/config, queues, logging, alerts, package deployment.
- **Triggers**: time trigger at 08:00 daily; optional queue trigger for performer scale-out.
- **Queues**: enforces one transaction per birthday person; supports retries and reporting.
- **Integration Service**:
  - **Gmail connector** (connection **`ninemush@gmail.com`**, ID **0a0d5ee1-a1e8-477a-a943-58161e6f3272**) for sending emails.
  - **UiPath GenAI Activities connector** (connection **`prajwal.sha...

**Automation Type:** hybrid
**Rationale:** Calendar/contact retrieval and email sending are deterministic (RPA), but generating a “your voice” warm/funny/sarcastic message is best handled by an AI Agent/GenAI step with guardrails and fallback.
**Feasibility Complexity:** medium
**Effort Estimate:** 1-2 weeks

## 5. Business Process Overview

### Process Steps

| # | Step | Role | System | Type | Pain Point |
|---|------|------|--------|------|------------|
| 1 | 8am Daily Trigger | System | Orchestrator Triggers | start | — |
| 2 | Read Today’s Events from "Birthdays" Calendar | System | Google Calendar (UiPath activity) | task | — |
| 3 | Any Birthday Events Today? | System | Google Calendar (UiPath activity) | decision | — |
| 4 | Create Queue Items (1 per birthday person) | System | Orchestrator Queue | task | — |
| 5 | No Birthdays End | System | Orchestrator | end | — |
| 6 | Dequeue Birthday Person | System | Orchestrator Queue | task | — |
| 7 | Look Up Contact Record by Full Name | System | Google Contacts (UiPath activity) | task | — |
| 8 | Any Email Addresses Found? | System | Google Contacts (UiPath activity) | decision | — |
| 9 | Determine Recipient Email (prefer Personal/Home) | System | Google Contacts (UiPath activity) | task | — |
| 10 | Generate Birthday Message in My Voice | System | UiPath Agents / UiPath GenAI Activities (native) | agent-task | — |
| 11 | Message Meets Tone & Safety Rules? | System | UiPath Agents | agent-decision | — |
| 12 | Send Birthday Email | System | Gmail (Integration Service) - connection "ninemush@gmail.com" | task | — |
| 13 | Greeting Sent End | System | Orchestrator | end | — |
| 14 | Create Human Review Task (low confidence / unsafe content) | System | Action Center | task | — |
| 15 | Approved to Send? | You | Action Center | decision | — |
| 16 | Send Birthday Email (post-approval) | System | Gmail (Integration Service) - connection "ninemush@gmail.com" | task | — |
| 17 | Do Not Send End | System | Orchestrator | end | — |
| 18 | Skip (No Email Found) | System | Orchestrator | task | — |
| 19 | Done End | System | Orchestrator | end | — |

### Target Applications / Systems

The following applications were identified from the process map and must be accessible from the robot machine:

- Orchestrator Triggers
- Google Calendar (UiPath activity)
- Orchestrator Queue
- Orchestrator
- Google Contacts (UiPath activity)
- UiPath Agents / UiPath GenAI Activities (native)
- UiPath Agents
- Gmail (Integration Service) - connection "ninemush@gmail.com"
- Action Center

### User Roles Involved

- System
- You

### Decision Points (Process Map Topology)

**Any Birthday Events Today?**
  - [Yes] → Create Queue Items (1 per birthday person)
  - [No] → No Birthdays End

**Any Email Addresses Found?**
  - [Yes] → Determine Recipient Email (prefer Personal/Home)
  - [No] → Skip (No Email Found)

**Approved to Send?**
  - [Yes] → Send Birthday Email (post-approval)
  - [No] → Do Not Send End

## 6. Environment Setup

| Requirement | Value |
|---|---|
| Target Framework | Windows or Portable |
| Robot Type | Unattended |
| Modern Activities | No |
| Studio Version | 25.10.0 |
| Orchestrator Connection | Required |
| Machine Template | Standard |

### Machine Template

**Recommended:** Standard
Standard unattended machine template

### Orchestrator Folder Structure

Create a Modern Folder with unattended robot pool (2+ robots recommended for queue-based processing). Enable Auto-scaling if available.

### NuGet Dependencies

| # | Package |
|---|--------|
| 1 | `UiPath.System.Activities` |
| 2 | `UiPath.DataService.Activities` |
| 3 | `UiPath.ComplexScenarios.Activities` |
| 4 | `UiPath.WebAPI.Activities` |
| 5 | `UiPath.UIAutomation.Activities` |
| 6 | `UiPath.Excel.Activities` |
| 7 | `UiPath.Database.Activities` |

### Target Applications (from Process Map)

The following applications were identified from the business process map. Ensure network connectivity and access credentials are configured on the robot machine:

- Orchestrator Triggers
- Google Calendar (UiPath activity)
- Orchestrator Queue
- Orchestrator
- Google Contacts (UiPath activity)
- UiPath Agents / UiPath GenAI Activities (native)
- UiPath Agents
- Gmail (Integration Service) - connection "ninemush@gmail.com"
- Action Center

## 7. Credential & Asset Inventory

**Total:** 3 activities (0 hardcoded, 3 variable-driven)

### Orchestrator Assets to Provision

| # | Asset Name | Value Type | Consuming Activity | File | Action |
|---|-----------|-----------|-------------------|------|--------|
| 1 | `[` | Unknown | — | `PerformerMain.xaml` | Verify exists in target environment |

### Detailed Usage Map

| File | Line | Activity | Asset/Credential | Type | Variable | Hardcoded |
|------|------|----------|-----------------|------|----------|----------|
| `PerformerMain.xaml` | 81 | GetAsset | `[` | Unknown | — | No |
| `PerformerMain.xaml` | 120 | GetAsset | `[` | Unknown | — | No |
| `PerformerMain.xaml` | 159 | GetAsset | `[` | Unknown | — | No |

## 8. SDD × XAML Artifact Reconciliation

**Summary:** 1 aligned, 14 SDD-only, 2 XAML-only

> **Warning:** 14 artifact(s) declared in the SDD were not found in the generated XAML. These must be provisioned in Orchestrator but are not referenced in code — verify the SDD spec or add the corresponding activities.

> **Warning:** 2 artifact(s) found in XAML are not declared in the SDD. Update the SDD orchestrator_artifacts block to include these, or the deployment manifest will be incomplete.

| # | Name | Type | Status | SDD Config | XAML File | XAML Line |
|---|------|------|--------|-----------|----------|----------|
| 1 | `BGV20_GoogleCalendar_Name` | asset | **SDD Only** | type: Text, value: Birthdays, description: Target Google Calendar name to read birthday events from. | — | — |
| 2 | `BGV20_Gmail_FromConnectionName` | asset | **SDD Only** | type: Text, value: ninemush@gmail.com, description: Integration Service Gmail connection name used as the sender identity. | — | — |
| 3 | `BGV20_RunTimeZone` | asset | **SDD Only** | type: Text, value: America/New_York, description: Time zone used to compute 'today' for calendar queries and to align the 8:00 AM schedule. | — | — |
| 4 | `BGV20_EmailSubjectTemplate` | asset | **SDD Only** | type: Text, value: Happy Birthday, {FirstName}!, description: Email subject template. Workflow replaces tokens using contact/event-derived data. | — | — |
| 5 | `BGV20_EmailPreferenceLabels` | asset | **SDD Only** | type: Text, value: home,personal, description: Comma-separated preferred Google Contacts email labels (case-insensitive). | — | — |
| 6 | `BGV20_SkipIfAmbiguousContactMatch` | asset | **SDD Only** | type: Bool, value: true, description: If multiple Google Contacts match the same full name, skip sending to avoid wrong recipient. If false, use deterministic first exact match and log ambiguity. | — | — |
| 7 | `BGV20_QueueItemDeferMinutes_OnRateLimit` | asset | **SDD Only** | type: Integer, value: 15, description: If rate limits/transient connector errors occur, defer queue item by N minutes before retry. | — | — |
| 8 | `BGV20_LogMaskEmails` | asset | **SDD Only** | type: Bool, value: true, description: Mask recipient emails in logs to reduce PII exposure while preserving traceability. | — | — |
| 9 | `BGV20_GenAI_Temperature` | asset | **SDD Only** | type: Integer, value: 30, description: GenAI creativity control expressed as an integer percent (0-100). Workflow maps to model temperature (e.g., 0.30). | — | — |
| 10 | `BGV20_GenAI_MaxChars` | asset | **SDD Only** | type: Integer, value: 1200, description: Maximum characters for generated email body to keep messages concise and reduce quota risk. | — | — |
| 11 | `BGV20_MaxBirthdaysPerRun` | asset | **SDD Only** | type: Integer, value: 50, description: Safety cap to prevent runaway runs if the calendar query returns unexpected results. | — | — |
| 12 | `BGV20_BusinessSLA_SendByLocalTime` | asset | **SDD Only** | type: Text, value: 09:00, description: Operational SLA target: all greetings should be sent by this local time on the run day (best-effort; monitoring/alerts should key off this). | — | — |
| 13 | `BGV20_OrchestratorFolderName` | asset | **SDD Only** | type: Text, value: BirthdayGreetings, description: Target Orchestrator folder name where processes/queues/triggers are deployed (used for operator clarity). | — | — |
| 14 | `BGV20_GoogleOAuth_Credential` | credential | **SDD Only** | type: Credential, description: Reserved credential asset for Google OAuth/client secrets if a non-Integration-Service fallback is ever required (not used when Integration Service connections are healthy). | — | — |
| 15 | `[` | asset | **XAML Only** | — | `PerformerMain.xaml` | 81 |
| 16 | `BGV20_BirthdayGreetings_Transactions` | queue | **Aligned** | maxRetries: 2, uniqueReference: true, description: One transaction per birthday person (from Google Calendar 'Birthdays') to enforce exactly one email per person, enable retries, and provide auditability. | `PerformerMain.xaml` | 205 |
| 17 | `[` | queue | **XAML Only** | — | `DispatchBirthdayQueue.xaml` | 197 |

## 9. Queue Management

**Pattern:** Transactional (Dispatcher/Performer)

### Queues to Provision

| # | Queue Name | Activities | Unique Reference | Auto Retry | SLA | Action |
|---|-----------|------------|-----------------|------------|-----|--------|
| 1 | `[` | AddQueueItem | Recommended | Yes (3x) | — | Verify exists |
| 2 | `BGV20_BirthdayGreetings_Transactions` | GetTransactionItem | Yes (SDD) | Yes (2x, SDD) | — | Create in Orchestrator |

### Queue Activity Summary

| Capability | Present |
|---|---|
| Add Queue Item | Yes |
| Get Transaction Item | Yes |
| Set Transaction Status | Yes |

### Retry Policy

Transactional pattern detected — configure Auto Retry (recommended: 3 retries) in Orchestrator Queue settings

### SLA Guidance

Configure SLA in Orchestrator: set Maximum Execution Time per transaction item and monitor Queue SLA reports. Recommended: base SLA on observed P95 processing time + 20% buffer.

### Dead-Letter / Failed Items Handling

Items exceeding max retries are marked as Failed. Review failed items in Orchestrator Queues dashboard. Consider: (1) Create a separate cleanup/reprocessing workflow for DLQ items, (2) Set up email alerts for failed transaction counts exceeding threshold, (3) Log detailed failure context in SetTransactionStatus output for troubleshooting.

## 10. Exception Handling Coverage

**Coverage:** 8/8 high-risk activities inside TryCatch (100%)

### Files Without TryCatch

- `Main.xaml`
- `ReadCalendarEvents.xaml`
- `ProcessBirthdayTransaction.xaml`
- `ResolveRecipientEmail.xaml`
- `GenerateBirthdayMessage.xaml`
- `InitAllSettings.xaml`
- `ReadCalendarEvents`
- `DispatchBirthdayQueue`
- `ProcessBirthdayTransaction`
- `ResolveRecipientEmail`
- `GenerateBirthdayMessage`

## 11. Trigger Configuration

Based on the process analysis, the following trigger configuration is recommended:

| # | Trigger Type | Reason | Configuration |
|---|-------------|--------|---------------|
| 1 | **Schedule** | Defined in SDD orchestrator_artifacts: BGV20_08AM_Daily_Dispatcher | SDD-specified: BGV20_08AM_Daily_Dispatcher | Cron: 0 0 8 ? * * * | Daily 8:00 AM local-time dispatcher trigger: reads today's birthdays and enqueues one transaction per person. |
| 2 | **Queue** | Defined in SDD orchestrator_artifacts: BGV20_Queue_Consumer | SDD-specified: BGV20_Queue_Consumer | Queue: BGV20_BirthdayGreetings_Transactions | Queue trigger to process birthday-person transactions (lookup contact, generate message, send email). |

## 12. Upstream Quality Findings

The following quality warnings were produced by upstream pipeline stages (selector scoring, type validation, expression linting, etc.) and should be addressed during development:

| Code | Severity | Count | Sample Message |
|------|----------|-------|----------------|
| placeholder-value | warning | 6 | Contains 2 placeholder value(s) matching "\bPLACEHOLDER\b" [Developer Implementation Required] |
| undeclared-asset | warning | 8 | Asset "{type:literal,value:BGV20_GoogleCalendar_Name}" is referenced in XAML but not declared in orchestrator artifacts |
| invalid-activity-property | warning | 25 | Line 283: property "in_CalendarName" is not a known property of ui:InvokeWorkflowFile |
| hardcoded-asset-name | warning | 23 | Line 76: asset name "{&quot;type&quot;:&quot;literal&quot;,&quot;value&quot;:&quot;BGV20_GoogleCalendar_Name&quot;}" is ... |
| hardcoded-retry-interval | warning | 2 | Line 366: retry interval hardcoded as "{&quot;type&quot;:&quot;literal&quot;,&quot;value&quot;:&quot;00:00:30&quot;}" — ... |
| COMPLEX_EXPRESSION_PASSTHROUGH | warning | 2 | Line 69: Complex expression (lambdas, LINQ, nested calls, or 3+ operators) — emitting as-is to avoid regex corruption in... |
| BARE_TOKEN_QUOTED | warning | 16 | Auto-quoted bare token "Settings" for uexcel:ExcelReadRange.SheetName (expected String type) — wrapped in VB string quot... |

## 13. Pre-Deployment Checklist

| # | Category | Task | Required |
|---|----------|------|----------|
| 1 | Deployment | Publish package to Orchestrator feed | Yes |
| 2 | Deployment | Create Process in target folder | Yes |
| 3 | Environment | Verify Orchestrator connection from robot | Yes |
| 4 | Assets | Provision asset: `[` | Yes |
| 5 | Queues | Create queue: `[` | Yes |
| 6 | Queues | Create queue: `BGV20_BirthdayGreetings_Transactions` | Yes |
| 7 | Trigger | Configure trigger (schedule/queue/API) | Yes |
| 8 | Testing | Run smoke test in target environment | Yes |
| 9 | Monitoring | Verify logging output in Orchestrator | Recommended |
| 10 | Governance | UAT test execution completed and sign-off obtained | Yes |
| 11 | Governance | Peer code review completed | Yes |
| 12 | Governance | All quality gate warnings addressed or risk-accepted | Yes |
| 13 | Governance | Business process owner validation obtained | Yes |
| 14 | Governance | CoE approval obtained | Yes |
| 15 | Governance | Production readiness assessment completed (monitoring, alerting, rollback plan documented) | Yes |

## 14. Deployment Readiness Score

**Overall: Not Ready — 36/50 (19%)**

| Section | Score | Notes |
|---------|-------|-------|
| Credentials & Assets | 10/10 | All credentials/assets properly configured |
| Exception Handling | 7/10 | 11 file(s) with no TryCatch blocks |
| Queue Management | 9/10 | 1 hardcoded queue name(s) — externalize to config |
| Build Quality | 0/10 | 82 quality warnings — significant remediation needed; 10 remediations — stub replacements need developer attention; Entry point (Main.xaml) is stubbed — package has no runnable entry point |
| Environment Setup | 10/10 | Environment requirements are straightforward |

> **Action Required:** Address the items above before deploying to production. Focus on sections with the lowest scores first.

## 15. Pre-emission Spec Validation

Validation was performed on the WorkflowSpec tree before XAML assembly. Issues caught at this stage are cheaper to fix than post-emission quality gate findings.

| Metric | Count |
|---|---|
| Total activities checked | 0 |
| Valid activities | 0 |
| Unknown → Comment stubs | 0 |
| Non-catalog properties stripped | 0 |
| Enum values auto-corrected | 0 |
| Missing required props filled | 0 |
| Total issues | 0 |

### Pre-emission vs Post-emission

| Stage | Issues Caught/Fixed |
|---|---|
| Pre-emission (spec validation) | 0 auto-fixed, 0 total issues |
| Post-emission (quality gate) | 92 warnings/remediations |

---

## 16. Structured Report (JSON)

The following JSON appendix contains the full pipeline outcome report for programmatic consumption:

```json
{
  "fullyGeneratedFiles": [],
  "autoRepairs": [
    {
      "repairCode": "REPAIR_GENERIC",
      "file": "Main.xaml",
      "description": "Catalog (fallback): Moved ui:GetAsset.Value from attribute to child-element in Main.xaml"
    },
    {
      "repairCode": "REPAIR_GENERIC",
      "file": "Main.xaml",
      "description": "Catalog (fallback): Moved ui:GetAsset.Value from attribute to child-element in Main.xaml"
    },
    {
      "repairCode": "REPAIR_GENERIC",
      "file": "Main.xaml",
      "description": "Catalog (fallback): Moved ui:GetAsset.Value from attribute to child-element in Main.xaml"
    },
    {
      "repairCode": "REPAIR_GENERIC",
      "file": "Main.xaml",
      "description": "Catalog (fallback): Moved ui:GetAsset.Value from attribute to child-element in Main.xaml"
    },
    {
      "repairCode": "REPAIR_GENERIC",
      "file": "Main.xaml",
      "description": "Catalog (fallback): Moved uds:CreateEntity.EntityObject from attribute to child-element in Main.xaml"
    },
    {
      "repairCode": "REPAIR_GENERIC",
      "file": "Main.xaml",
      "description": "Catalog (fallback): Moved uds:CreateEntity.Result from attribute to child-element in Main.xaml"
    },
    {
      "repairCode": "REPAIR_GENERIC",
      "file": "Main.xaml",
      "description": "Catalog (fallback): Moved Throw.Exception from attribute to child-element in Main.xaml"
    }
  ],
  "remediations": [
    {
      "level": "validation-finding",
      "file": "ReadCalendarEvents.xaml",
      "remediationCode": "STUB_ACTIVITY_UNKNOWN",
      "reason": "Line 227: Activity \"GmailGetMessages\" has no namespace prefix — Studio will fail to resolve it. Expected a prefix like \"ui:GmailGetMessages\"",
      "classifiedCheck": "unprefixed-activity",
      "developerAction": "Manually implement activity in ReadCalendarEvents.xaml — estimated 15 min",
      "estimatedEffortMinutes": 15
    },
    {
      "level": "validation-finding",
      "file": "ProcessBirthdayTransaction.xaml",
      "remediationCode": "STUB_ACTIVITY_UNKNOWN",
      "reason": "Line 415: Activity \"GmailSendMessage\" has no namespace prefix — Studio will fail to resolve it. Expected a prefix like \"ui:GmailSendMessage\"",
      "classifiedCheck": "unprefixed-activity",
      "developerAction": "Manually implement activity in ProcessBirthdayTransaction.xaml — estimated 15 min",
      "estimatedEffortMinutes": 15
    },
    {
      "level": "validation-finding",
      "file": "ResolveRecipientEmail.xaml",
      "remediationCode": "STUB_ACTIVITY_UNKNOWN",
      "reason": "Line 206: Activity \"DeserializeJSON\" has no namespace prefix — Studio will fail to resolve it. Expected a prefix like \"ui:DeserializeJSON\"",
      "classifiedCheck": "unprefixed-activity",
      "developerAction": "Manually implement activity in ResolveRecipientEmail.xaml — estimated 15 min",
      "estimatedEffortMinutes": 15
    },
    {
      "level": "validation-finding",
      "file": "Main.xaml",
      "remediationCode": "STUB_ACTIVITY_CATALOG_VIOLATION",
      "reason": "Property \"To\" on Assign must be a child element, not an attribute",
      "classifiedCheck": "CATALOG_STRUCTURAL_VIOLATION",
      "developerAction": "Fix property syntax for activity in Main.xaml — move attribute to child-element or vice versa per UiPath catalog",
      "estimatedEffortMinutes": 15
    },
    {
      "level": "workflow",
      "file": "InitAllSettings.xaml",
      "remediationCode": "STUB_WORKFLOW_BLOCKING",
      "reason": "Final validation: XAML well-formedness violations — replaced with stub",
      "classifiedCheck": "xml-wellformedness",
      "developerAction": "Fix XML structure in InitAllSettings.xaml — ensure proper nesting and closing tags",
      "estimatedEffortMinutes": 15
    },
    {
      "level": "workflow",
      "file": "Main.xaml",
      "remediationCode": "STUB_WORKFLOW_BLOCKING",
      "reason": "Final validation: XAML well-formedness violations — replaced with stub",
      "classifiedCheck": "xml-wellformedness",
      "developerAction": "Fix XML structure in Main.xaml — ensure proper nesting and closing tags",
      "estimatedEffortMinutes": 15
    },
    {
      "level": "workflow",
      "file": "ReadCalendarEvents.xaml",
      "remediationCode": "STUB_WORKFLOW_BLOCKING",
      "reason": "Final validation: XAML well-formedness violations — replaced with stub",
      "classifiedCheck": "xml-wellformedness",
      "developerAction": "Fix XML structure in ReadCalendarEvents.xaml — ensure proper nesting and closing tags",
      "estimatedEffortMinutes": 15
    },
    {
      "level": "workflow",
      "file": "ProcessBirthdayTransaction.xaml",
      "remediationCode": "STUB_WORKFLOW_BLOCKING",
      "reason": "Final validation: XAML well-formedness violations — replaced with stub",
      "classifiedCheck": "xml-wellformedness",
      "developerAction": "Fix XML structure in ProcessBirthdayTransaction.xaml — ensure proper nesting and closing tags",
      "estimatedEffortMinutes": 15
    },
    {
      "level": "workflow",
      "file": "ResolveRecipientEmail.xaml",
      "remediationCode": "STUB_WORKFLOW_BLOCKING",
      "reason": "Final validation: XAML well-formedness violations — replaced with stub",
      "classifiedCheck": "xml-wellformedness",
      "developerAction": "Fix XML structure in ResolveRecipientEmail.xaml — ensure proper nesting and closing tags",
      "estimatedEffortMinutes": 15
    },
    {
      "level": "workflow",
      "file": "GenerateBirthdayMessage.xaml",
      "remediationCode": "STUB_WORKFLOW_BLOCKING",
      "reason": "Final validation: XAML well-formedness violations — replaced with stub",
      "classifiedCheck": "xml-wellformedness",
      "developerAction": "Fix XML structure in GenerateBirthdayMessage.xaml — ensure proper nesting and closing tags",
      "estimatedEffortMinutes": 15
    }
  ],
  "propertyRemediations": [],
  "downgradeEvents": [],
  "qualityWarnings": [
    {
      "check": "placeholder-value",
      "file": "ResolveRecipientEmail.xaml",
      "detail": "Contains 2 placeholder value(s) matching \"\\bPLACEHOLDER\\b\" [Developer Implementation Required]",
      "severity": "warning",
      "stubCategory": "handoff"
    },
    {
      "check": "placeholder-value",
      "file": "ReadCalendarEvents",
      "detail": "Contains 1 placeholder value(s) matching \"\\bPLACEHOLDER\\b\" [Developer Implementation Required]",
      "severity": "warning",
      "stubCategory": "handoff"
    },
    {
      "check": "placeholder-value",
      "file": "DispatchBirthdayQueue",
      "detail": "Contains 1 placeholder value(s) matching \"\\bPLACEHOLDER\\b\" [Developer Implementation Required]",
      "severity": "warning",
      "stubCategory": "handoff"
    },
    {
      "check": "placeholder-value",
      "file": "ProcessBirthdayTransaction",
      "detail": "Contains 1 placeholder value(s) matching \"\\bPLACEHOLDER\\b\" [Developer Implementation Required]",
      "severity": "warning",
      "stubCategory": "handoff"
    },
    {
      "check": "placeholder-value",
      "file": "ResolveRecipientEmail",
      "detail": "Contains 1 placeholder value(s) matching \"\\bPLACEHOLDER\\b\" [Developer Implementation Required]",
      "severity": "warning",
      "stubCategory": "handoff"
    },
    {
      "check": "placeholder-value",
      "file": "GenerateBirthdayMessage",
      "detail": "Contains 1 placeholder value(s) matching \"\\bPLACEHOLDER\\b\" [Developer Implementation Required]",
      "severity": "warning",
      "stubCategory": "handoff"
    },
    {
      "check": "undeclared-asset",
      "file": "orchestrator",
      "detail": "Asset \"{type:literal,value:BGV20_GoogleCalendar_Name}\" is referenced in XAML but not declared in orchestrator artifacts",
      "severity": "warning"
    },
    {
      "check": "undeclared-asset",
      "file": "orchestrator",
      "detail": "Asset \"{type:literal,value:BGV20_RunTimeZone}\" is referenced in XAML but not declared in orchestrator artifacts",
      "severity": "warning"
    },
    {
      "check": "undeclared-asset",
      "file": "orchestrator",
      "detail": "Asset \"{type:literal,value:BGV20_MaxBirthdaysPerRun}\" is referenced in XAML but not declared in orchestrator artifacts",
      "severity": "warning"
    },
    {
      "check": "undeclared-asset",
      "file": "orchestrator",
      "detail": "Asset \"{type:literal,value:BGV20_OrchestratorFolderName}\" is referenced in XAML but not declared in orchestrator artifacts",
      "severity": "warning"
    },
    {
      "check": "undeclared-asset",
      "file": "orchestrator",
      "detail": "Asset \"{type:literal,value:BGV20_QueueItemDeferMinutes_OnRateLimit}\" is referenced in XAML but not declared in orchestrator artifacts",
      "severity": "warning"
    },
    {
      "check": "undeclared-asset",
      "file": "orchestrator",
      "detail": "Asset \"{type:literal,value:BGV20_LogMaskEmails}\" is referenced in XAML but not declared in orchestrator artifacts",
      "severity": "warning"
    },
    {
      "check": "undeclared-asset",
      "file": "orchestrator",
      "detail": "Asset \"{type:literal,value:BGV20_Gmail_FromConnectionName}\" is referenced in XAML but not declared in orchestrator artifacts",
      "severity": "warning"
    },
    {
      "check": "undeclared-asset",
      "file": "orchestrator",
      "detail": "Asset \"{type:literal,value:BGV20_EmailSubjectTemplate}\" is referenced in XAML but not declared in orchestrator artifacts",
      "severity": "warning"
    },
    {
      "check": "invalid-activity-property",
      "file": "Main.xaml",
      "detail": "Line 283: property \"in_CalendarName\" is not a known property of ui:InvokeWorkflowFile",
      "severity": "warning"
    },
    {
      "check": "invalid-activity-property",
      "file": "Main.xaml",
      "detail": "Line 283: property \"in_RunDate\" is not a known property of ui:InvokeWorkflowFile",
      "severity": "warning"
    },
    {
      "check": "invalid-activity-property",
      "file": "Main.xaml",
      "detail": "Line 283: property \"in_RunTimeZone\" is not a known property of ui:InvokeWorkflowFile",
      "severity": "warning"
    },
    {
      "check": "invalid-activity-property",
      "file": "Main.xaml",
      "detail": "Line 283: property \"in_MaxBirthdaysPerRun\" is not a known property of ui:InvokeWorkflowFile",
      "severity": "warning"
    },
    {
      "check": "invalid-activity-property",
      "file": "Main.xaml",
      "detail": "Line 283: property \"out_BirthdayPersonsDT\" is not a known property of ui:InvokeWorkflowFile",
      "severity": "warning"
    },
    {
      "check": "invalid-activity-property",
      "file": "Main.xaml",
      "detail": "Line 283: property \"out_BirthdaysFoundCount\" is not a known property of ui:InvokeWorkflowFile",
      "severity": "warning"
    },
    {
      "check": "invalid-activity-property",
      "file": "Main.xaml",
      "detail": "Line 339: property \"in_BirthdayPersonsDT\" is not a known property of ui:InvokeWorkflowFile",
      "severity": "warning"
    },
    {
      "check": "invalid-activity-property",
      "file": "Main.xaml",
      "detail": "Line 339: property \"in_RunId\" is not a known property of ui:InvokeWorkflowFile",
      "severity": "warning"
    },
    {
      "check": "invalid-activity-property",
      "file": "Main.xaml",
      "detail": "Line 339: property \"in_RunDate\" is not a known property of ui:InvokeWorkflowFile",
      "severity": "warning"
    },
    {
      "check": "invalid-activity-property",
      "file": "Main.xaml",
      "detail": "Line 339: property \"in_RunDateLocal\" is not a known property of ui:InvokeWorkflowFile",
      "severity": "warning"
    },
    {
      "check": "invalid-activity-property",
      "file": "Main.xaml",
      "detail": "Line 339: property \"out_QueueItemsEnqueuedCount\" is not a known property of ui:InvokeWorkflowFile",
      "severity": "warning"
    },
    {
      "check": "invalid-activity-property",
      "file": "Main.xaml",
      "detail": "Line 339: property \"out_QueueItemsSkippedCount\" is not a known property of ui:InvokeWorkflowFile",
      "severity": "warning"
    },
    {
      "check": "invalid-activity-property",
      "file": "PerformerMain.xaml",
      "detail": "Line 384: property \"in_TransactionItem\" is not a known property of ui:InvokeWorkflowFile",
      "severity": "warning"
    },
    {
      "check": "invalid-activity-property",
      "file": "PerformerMain.xaml",
      "detail": "Line 384: property \"in_FullName\" is not a known property of ui:InvokeWorkflowFile",
      "severity": "warning"
    },
    {
      "check": "invalid-activity-property",
      "file": "PerformerMain.xaml",
      "detail": "Line 384: property \"in_EventId\" is not a known property of ui:InvokeWorkflowFile",
      "severity": "warning"
    },
    {
      "check": "invalid-activity-property",
      "file": "PerformerMain.xaml",
      "detail": "Line 384: property \"in_EventStartDate\" is not a known property of ui:InvokeWorkflowFile",
      "severity": "warning"
    },
    {
      "check": "invalid-activity-property",
      "file": "PerformerMain.xaml",
      "detail": "Line 384: property \"in_RunId\" is not a known property of ui:InvokeWorkflowFile",
      "severity": "warning"
    },
    {
      "check": "invalid-activity-property",
      "file": "PerformerMain.xaml",
      "detail": "Line 384: property \"in_LogMaskEmails\" is not a known property of ui:InvokeWorkflowFile",
      "severity": "warning"
    },
    {
      "check": "invalid-activity-property",
      "file": "PerformerMain.xaml",
      "detail": "Line 384: property \"out_Outcome\" is not a known property of ui:InvokeWorkflowFile",
      "severity": "warning"
    },
    {
      "check": "invalid-activity-property",
      "file": "PerformerMain.xaml",
      "detail": "Line 384: property \"out_ErrorMessage\" is not a known property of ui:InvokeWorkflowFile",
      "severity": "warning"
    },
    {
      "check": "invalid-activity-property",
      "file": "PerformerMain.xaml",
      "detail": "Line 384: property \"out_ErrorType\" is not a known property of ui:InvokeWorkflowFile",
      "severity": "warning"
    },
    {
      "check": "invalid-activity-property",
      "file": "PerformerMain.xaml",
      "detail": "Line 384: property \"out_IsBusinessException\" is not a known property of ui:InvokeWorkflowFile",
      "severity": "warning"
    },
    {
      "check": "invalid-activity-property",
      "file": "ProcessBirthdayTransaction.xaml",
      "detail": "Line 208: property \"Arguments\" is not a known property of ui:InvokeWorkflowFile",
      "severity": "warning"
    },
    {
      "check": "invalid-activity-property",
      "file": "ProcessBirthdayTransaction.xaml",
      "detail": "Line 302: property \"Arguments\" is not a known property of ui:InvokeWorkflowFile",
      "severity": "warning"
    },
    {
      "check": "invalid-activity-property",
      "file": "ResolveRecipientEmail.xaml",
      "detail": "Line 246: property \"Condition\" is not a known property of ui:ShouldRetry",
      "severity": "warning"
    },
    {
      "check": "hardcoded-asset-name",
      "file": "Main.xaml",
      "detail": "Line 76: asset name \"{&quot;type&quot;:&quot;literal&quot;,&quot;value&quot;:&quot;BGV20_GoogleCalendar_Name&quot;}\" is hardcoded — consider using a Config.xlsx entry or workflow argument",
      "severity": "warning"
    },
    {
      "check": "hardcoded-asset-name",
      "file": "Main.xaml",
      "detail": "Line 115: asset name \"{&quot;type&quot;:&quot;literal&quot;,&quot;value&quot;:&quot;BGV20_RunTimeZone&quot;}\" is hardcoded — consider using a Config.xlsx entry or workflow argument",
      "severity": "warning"
    },
    {
      "check": "hardcoded-asset-name",
      "file": "Main.xaml",
      "detail": "Line 154: asset name \"{&quot;type&quot;:&quot;literal&quot;,&quot;value&quot;:&quot;BGV20_MaxBirthdaysPerRun&quot;}\" is hardcoded — consider using a Config.xlsx entry or workflow argument",
      "severity": "warning"
    },
    {
      "check": "hardcoded-asset-name",
      "file": "Main.xaml",
      "detail": "Line 197: asset name \"{&quot;type&quot;:&quot;literal&quot;,&quot;value&quot;:&quot;BGV20_OrchestratorFolderName&quot;}\" is hardcoded — consider using a Config.xlsx entry or workflow argument",
      "severity": "warning"
    },
    {
      "check": "hardcoded-asset-name",
      "file": "PerformerMain.xaml",
      "detail": "Line 69: asset name \"{&quot;type&quot;:&quot;literal&quot;,&quot;value&quot;:&quot;BGV20_QueueItemDeferMinutes_OnRateLimit&quot;}\" is hardcoded — consider using a Config.xlsx entry or workflow argument",
      "severity": "warning"
    },
    {
      "check": "hardcoded-asset-name",
      "file": "PerformerMain.xaml",
      "detail": "Line 108: asset name \"{&quot;type&quot;:&quot;literal&quot;,&quot;value&quot;:&quot;BGV20_LogMaskEmails&quot;}\" is hardcoded — consider using a Config.xlsx entry or workflow argument",
      "severity": "warning"
    },
    {
      "check": "hardcoded-asset-name",
      "file": "PerformerMain.xaml",
      "detail": "Line 147: asset name \"{&quot;type&quot;:&quot;literal&quot;,&quot;value&quot;:&quot;BGV20_OrchestratorFolderName&quot;}\" is hardcoded — consider using a Config.xlsx entry or workflow argument",
      "severity": "warning"
    },
    {
      "check": "hardcoded-retry-interval",
      "file": "ProcessBirthdayTransaction.xaml",
      "detail": "Line 366: retry interval hardcoded as \"{&quot;type&quot;:&quot;literal&quot;,&quot;value&quot;:&quot;00:00:30&quot;}\" — consider externalizing to Config.xlsx",
      "severity": "warning"
    },
    {
      "check": "hardcoded-asset-name",
      "file": "ProcessBirthdayTransaction.xaml",
      "detail": "Line 72: asset name \"{&quot;type&quot;:&quot;literal&quot;,&quot;value&quot;:&quot;BGV20_Gmail_FromConnectionName&quot;}\" is hardcoded — consider using a Config.xlsx entry or workflow argument",
      "severity": "warning"
    },
    {
      "check": "hardcoded-asset-name",
      "file": "ProcessBirthdayTransaction.xaml",
      "detail": "Line 111: asset name \"{&quot;type&quot;:&quot;literal&quot;,&quot;value&quot;:&quot;BGV20_EmailSubjectTemplate&quot;}\" is hardcoded — consider using a Config.xlsx entry or workflow argument",
      "severity": "warning"
    },
    {
      "check": "hardcoded-retry-interval",
      "file": "ResolveRecipientEmail.xaml",
      "detail": "Line 79: retry interval hardcoded as \"{&quot;type&quot;:&quot;literal&quot;,&quot;value&quot;:&quot;00:00:05&quot;}\" — consider externalizing to Config.xlsx",
      "severity": "warning"
    },
    {
      "check": "hardcoded-asset-name",
      "file": "InitAllSettings.xaml",
      "detail": "Line 100: asset name \"BGV20_GoogleOAuth_Credential\" is hardcoded — consider using a Config.xlsx entry or workflow argument",
      "severity": "warning"
    },
    {
      "check": "hardcoded-asset-name",
      "file": "InitAllSettings.xaml",
      "detail": "Line 105: asset name \"BGV20_GoogleCalendar_Name\" is hardcoded — consider using a Config.xlsx entry or workflow argument",
      "severity": "warning"
    },
    {
      "check": "hardcoded-asset-name",
      "file": "InitAllSettings.xaml",
      "detail": "Line 114: asset name \"BGV20_Gmail_FromConnectionName\" is hardcoded — consider using a Config.xlsx entry or workflow argument",
      "severity": "warning"
    },
    {
      "check": "hardcoded-asset-name",
      "file": "InitAllSettings.xaml",
      "detail": "Line 123: asset name \"BGV20_RunTimeZone\" is hardcoded — consider using a Config.xlsx entry or workflow argument",
      "severity": "warning"
    },
    {
      "check": "hardcoded-asset-name",
      "file": "InitAllSettings.xaml",
      "detail": "Line 132: asset name \"BGV20_EmailSubjectTemplate\" is hardcoded — consider using a Config.xlsx entry or workflow argument",
      "severity": "warning"
    },
    {
      "check": "hardcoded-asset-name",
      "file": "InitAllSettings.xaml",
      "detail": "Line 141: asset name \"BGV20_EmailPreferenceLabels\" is hardcoded — consider using a Config.xlsx entry or workflow argument",
      "severity": "warning"
    },
    {
      "check": "hardcoded-asset-name",
      "file": "InitAllSettings.xaml",
      "detail": "Line 150: asset name \"BGV20_SkipIfAmbiguousContactMatch\" is hardcoded — consider using a Config.xlsx entry or workflow argument",
      "severity": "warning"
    },
    {
      "check": "hardcoded-asset-name",
      "file": "InitAllSettings.xaml",
      "detail": "Line 159: asset name \"BGV20_QueueItemDeferMinutes_OnRateLimit\" is hardcoded — consider using a Config.xlsx entry or workflow argument",
      "severity": "warning"
    },
    {
      "check": "hardcoded-asset-name",
      "file": "InitAllSettings.xaml",
      "detail": "Line 168: asset name \"BGV20_LogMaskEmails\" is hardcoded — consider using a Config.xlsx entry or workflow argument",
      "severity": "warning"
    },
    {
      "check": "hardcoded-asset-name",
      "file": "InitAllSettings.xaml",
      "detail": "Line 177: asset name \"BGV20_GenAI_Temperature\" is hardcoded — consider using a Config.xlsx entry or workflow argument",
      "severity": "warning"
    },
    {
      "check": "hardcoded-asset-name",
      "file": "InitAllSettings.xaml",
      "detail": "Line 186: asset name \"BGV20_GenAI_MaxChars\" is hardcoded — consider using a Config.xlsx entry or workflow argument",
      "severity": "warning"
    },
    {
      "check": "hardcoded-asset-name",
      "file": "InitAllSettings.xaml",
      "detail": "Line 195: asset name \"BGV20_MaxBirthdaysPerRun\" is hardcoded — consider using a Config.xlsx entry or workflow argument",
      "severity": "warning"
    },
    {
      "check": "hardcoded-asset-name",
      "file": "InitAllSettings.xaml",
      "detail": "Line 204: asset name \"BGV20_BusinessSLA_SendByLocalTime\" is hardcoded — consider using a Config.xlsx entry or workflow argument",
      "severity": "warning"
    },
    {
      "check": "hardcoded-asset-name",
      "file": "InitAllSettings.xaml",
      "detail": "Line 213: asset name \"BGV20_OrchestratorFolderName\" is hardcoded — consider using a Config.xlsx entry or workflow argument",
      "severity": "warning"
    },
    {
      "check": "COMPLEX_EXPRESSION_PASSTHROUGH",
      "file": "Main.xaml",
      "detail": "Line 69: Complex expression (lambdas, LINQ, nested calls, or 3+ operators) — emitting as-is to avoid regex corruption in expression: {&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;\\&quot;BGV20...",
      "severity": "warning"
    },
    {
      "check": "COMPLEX_EXPRESSION_PASSTHROUGH",
      "file": "GenerateBirthdayMessage.xaml",
      "detail": "Line 244: Complex expression (lambdas, LINQ, nested calls, or 3+ operators) — emitting as-is to avoid regex corruption in expression: {&quot;type&quot;:&quot;vb_expression&quot;,&quot;value&quot;:&quot;\\&quot;Forbi...",
      "severity": "warning"
    },
    {
      "check": "BARE_TOKEN_QUOTED",
      "file": "InitAllSettings.xaml",
      "detail": "Auto-quoted bare token \"Settings\" for uexcel:ExcelReadRange.SheetName (expected String type) — wrapped in VB string quotes",
      "severity": "warning"
    },
    {
      "check": "BARE_TOKEN_QUOTED",
      "file": "InitAllSettings.xaml",
      "detail": "Auto-quoted bare token \"Constants\" for uexcel:ExcelReadRange.SheetName (expected String type) — wrapped in VB string quotes",
      "severity": "warning"
    },
    {
      "check": "BARE_TOKEN_QUOTED",
      "file": "InitAllSettings.xaml",
      "detail": "Auto-quoted bare token \"BGV20_GoogleOAuth_Credential\" for ui:GetCredential.AssetName (expected String type) — wrapped in VB string quotes",
      "severity": "warning"
    },
    {
      "check": "BARE_TOKEN_QUOTED",
      "file": "InitAllSettings.xaml",
      "detail": "Auto-quoted bare token \"BGV20_GoogleCalendar_Name\" for ui:GetAsset.AssetName (expected String type) — wrapped in VB string quotes",
      "severity": "warning"
    },
    {
      "check": "BARE_TOKEN_QUOTED",
      "file": "InitAllSettings.xaml",
      "detail": "Auto-quoted bare token \"BGV20_Gmail_FromConnectionName\" for ui:GetAsset.AssetName (expected String type) — wrapped in VB string quotes",
      "severity": "warning"
    },
    {
      "check": "BARE_TOKEN_QUOTED",
      "file": "InitAllSettings.xaml",
      "detail": "Auto-quoted bare token \"BGV20_RunTimeZone\" for ui:GetAsset.AssetName (expected String type) — wrapped in VB string quotes",
      "severity": "warning"
    },
    {
      "check": "BARE_TOKEN_QUOTED",
      "file": "InitAllSettings.xaml",
      "detail": "Auto-quoted bare token \"BGV20_EmailSubjectTemplate\" for ui:GetAsset.AssetName (expected String type) — wrapped in VB string quotes",
      "severity": "warning"
    },
    {
      "check": "BARE_TOKEN_QUOTED",
      "file": "InitAllSettings.xaml",
      "detail": "Auto-quoted bare token \"BGV20_EmailPreferenceLabels\" for ui:GetAsset.AssetName (expected String type) — wrapped in VB string quotes",
      "severity": "warning"
    },
    {
      "check": "BARE_TOKEN_QUOTED",
      "file": "InitAllSettings.xaml",
      "detail": "Auto-quoted bare token \"BGV20_SkipIfAmbiguousContactMatch\" for ui:GetAsset.AssetName (expected String type) — wrapped in VB string quotes",
      "severity": "warning"
    },
    {
      "check": "BARE_TOKEN_QUOTED",
      "file": "InitAllSettings.xaml",
      "detail": "Auto-quoted bare token \"BGV20_QueueItemDeferMinutes_OnRateLimit\" for ui:GetAsset.AssetName (expected String type) — wrapped in VB string quotes",
      "severity": "warning"
    },
    {
      "check": "BARE_TOKEN_QUOTED",
      "file": "InitAllSettings.xaml",
      "detail": "Auto-quoted bare token \"BGV20_LogMaskEmails\" for ui:GetAsset.AssetName (expected String type) — wrapped in VB string quotes",
      "severity": "warning"
    },
    {
      "check": "BARE_TOKEN_QUOTED",
      "file": "InitAllSettings.xaml",
      "detail": "Auto-quoted bare token \"BGV20_GenAI_Temperature\" for ui:GetAsset.AssetName (expected String type) — wrapped in VB string quotes",
      "severity": "warning"
    },
    {
      "check": "BARE_TOKEN_QUOTED",
      "file": "InitAllSettings.xaml",
      "detail": "Auto-quoted bare token \"BGV20_GenAI_MaxChars\" for ui:GetAsset.AssetName (expected String type) — wrapped in VB string quotes",
      "severity": "warning"
    },
    {
      "check": "BARE_TOKEN_QUOTED",
      "file": "InitAllSettings.xaml",
      "detail": "Auto-quoted bare token \"BGV20_MaxBirthdaysPerRun\" for ui:GetAsset.AssetName (expected String type) — wrapped in VB string quotes",
      "severity": "warning"
    },
    {
      "check": "BARE_TOKEN_QUOTED",
      "file": "InitAllSettings.xaml",
      "detail": "Auto-quoted bare token \"BGV20_BusinessSLA_SendByLocalTime\" for ui:GetAsset.AssetName (expected String type) — wrapped in VB string quotes",
      "severity": "warning"
    },
    {
      "check": "BARE_TOKEN_QUOTED",
      "file": "InitAllSettings.xaml",
      "detail": "Auto-quoted bare token \"BGV20_OrchestratorFolderName\" for ui:GetAsset.AssetName (expected String type) — wrapped in VB string quotes",
      "severity": "warning"
    }
  ],
  "totalEstimatedEffortMinutes": 150,
  "studioCompatibility": [
    {
      "file": "Main.xaml",
      "level": "studio-blocked",
      "blockers": [
        "[XML-WELLFORMEDNESS] XML well-formedness failure in tree assembler"
      ],
      "failureCategory": "xml-wellformedness",
      "failureSummary": "XML well-formedness failure in tree assembler"
    },
    {
      "file": "ReadCalendarEvents.xaml",
      "level": "studio-blocked",
      "blockers": [
        "[XML-WELLFORMEDNESS] XML well-formedness failure in tree assembler"
      ],
      "failureCategory": "xml-wellformedness",
      "failureSummary": "XML well-formedness failure in tree assembler"
    },
    {
      "file": "DispatchBirthdayQueue.xaml",
      "level": "studio-blocked",
      "blockers": [
        "[STUDIO_LOADABILITY] First child of Activity is <sap2010> instead of Sequence/Flowchart/StateMachine — Studio requires a direct implementation child"
      ],
      "failureCategory": "structural-invalid",
      "failureSummary": "Structural preservation — valid XML but not Studio-loadable"
    },
    {
      "file": "PerformerMain.xaml",
      "level": "studio-blocked",
      "blockers": [
        "[STUDIO_LOADABILITY] First child of Activity is <sap2010> instead of Sequence/Flowchart/StateMachine — Studio requires a direct implementation child"
      ],
      "failureCategory": "structural-invalid",
      "failureSummary": "Structural preservation — valid XML but not Studio-loadable"
    },
    {
      "file": "ProcessBirthdayTransaction.xaml",
      "level": "studio-blocked",
      "blockers": [
        "[XML-WELLFORMEDNESS] XML well-formedness failure in tree assembler"
      ],
      "failureCategory": "xml-wellformedness",
      "failureSummary": "XML well-formedness failure in tree assembler"
    },
    {
      "file": "ResolveRecipientEmail.xaml",
      "level": "studio-blocked",
      "blockers": [
        "[XML-WELLFORMEDNESS] XML well-formedness failure in tree assembler"
      ],
      "failureCategory": "xml-wellformedness",
      "failureSummary": "XML well-formedness failure in tree assembler"
    },
    {
      "file": "GenerateBirthdayMessage.xaml",
      "level": "studio-blocked",
      "blockers": [
        "[XML-WELLFORMEDNESS] XML well-formedness failure in tree assembler"
      ],
      "failureCategory": "xml-wellformedness",
      "failureSummary": "XML well-formedness failure in tree assembler"
    },
    {
      "file": "InitAllSettings.xaml",
      "level": "studio-blocked",
      "blockers": [
        "[XML-WELLFORMEDNESS] XML well-formedness failure in tree assembler"
      ],
      "failureCategory": "xml-wellformedness",
      "failureSummary": "XML well-formedness failure in tree assembler"
    },
    {
      "file": "ReadCalendarEvents",
      "level": "studio-blocked",
      "blockers": [
        "[COMPLIANCE-FAILURE] Compliance or quality gate failure requiring manual remediation"
      ],
      "failureCategory": "compliance-failure",
      "failureSummary": "Compliance or quality gate failure requiring manual remediation"
    },
    {
      "file": "DispatchBirthdayQueue",
      "level": "studio-blocked",
      "blockers": [
        "[COMPLIANCE-FAILURE] Compliance or quality gate failure requiring manual remediation"
      ],
      "failureCategory": "compliance-failure",
      "failureSummary": "Compliance or quality gate failure requiring manual remediation"
    },
    {
      "file": "ProcessBirthdayTransaction",
      "level": "studio-blocked",
      "blockers": [
        "[COMPLIANCE-FAILURE] Compliance or quality gate failure requiring manual remediation"
      ],
      "failureCategory": "compliance-failure",
      "failureSummary": "Compliance or quality gate failure requiring manual remediation"
    },
    {
      "file": "ResolveRecipientEmail",
      "level": "studio-blocked",
      "blockers": [
        "[COMPLIANCE-FAILURE] Compliance or quality gate failure requiring manual remediation"
      ],
      "failureCategory": "compliance-failure",
      "failureSummary": "Compliance or quality gate failure requiring manual remediation"
    },
    {
      "file": "GenerateBirthdayMessage",
      "level": "studio-blocked",
      "blockers": [
        "[COMPLIANCE-FAILURE] Compliance or quality gate failure requiring manual remediation"
      ],
      "failureCategory": "compliance-failure",
      "failureSummary": "Compliance or quality gate failure requiring manual remediation"
    }
  ],
  "preEmissionValidation": {
    "totalActivities": 0,
    "validActivities": 0,
    "unknownActivities": 0,
    "strippedProperties": 0,
    "enumCorrections": 0,
    "missingRequiredFilled": 0,
    "commentConversions": 0,
    "issueCount": 0
  }
}
```
